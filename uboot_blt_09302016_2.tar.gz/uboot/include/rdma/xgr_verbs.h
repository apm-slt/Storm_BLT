/*
 * APM RDMA hardware specific verbs API implementation
 *
 * Copyright (c) 2014 Applied Micro Circuits Corporation.
 *
 * Author: Ravi Patel <rapatel@apm.com>
 *         Tanmay Inamdar <tinamdar@apm.com>
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 */

#ifndef __XGR_VERBS__
#define __XGR_VERBS__

#include <rdma/ib_verbs.h>

struct ib_device *xgr_get_device(void);
void xgr_dump_stats(int);
void xgr_dump_qp_state(struct ib_qp *qp);
int xgr_query_device(struct ib_device *ibdev,
		struct ib_device_attr *attr);
int xgr_query_port(struct ib_device *ibdev,
		u8 port, struct ib_port_attr *props);
int xgr_query_pkey(struct ib_device *ibdev,
		u8 port, u16 index, u16 *pkey);
int xgr_query_gid(struct ib_device *ibdev,
		u8 port, int index, union ib_gid *sgid);
struct ib_pd *xgr_alloc_pd(struct ib_device *ibdev,
		struct ib_ucontext *context, struct ib_udata *udata);
int xgr_dealloc_pd(struct ib_pd *ibpd);
struct ib_qp *xgr_create_qp(struct ib_pd *ibpd,
		struct ib_qp_init_attr *attrs, struct ib_udata *udata);
int xgr_modify_qp(struct ib_qp *ibqp,
		struct ib_qp_attr *attr, int attr_mask, struct ib_udata *udata);
int xgr_destroy_qp(struct ib_qp *ibqp);
int xgr_post_send(struct ib_qp *ibqp,
		struct ib_send_wr *wr, struct ib_send_wr **bad_wr);
int xgr_post_recv(struct ib_qp *ibqp,
		struct ib_recv_wr *wr, struct ib_recv_wr **bad_wr);
struct ib_cq *xgr_create_cq(struct ib_device *ibdev, int entries,
		int vector, struct ib_ucontext *ib_ctx, struct ib_udata *udata);
int xgr_destroy_cq(struct ib_cq *ibcq);
int xgr_poll_cq(struct ib_cq *ibcq,
		int num_entries, struct ib_wc *wc);
struct ib_mr *xgr_reg_user_mr(struct ib_pd *pd, u64 start, u64 length,
		u64 virt_addr, int access_flags, struct ib_udata *udata);
int xgr_dereg_mr(struct ib_mr *ib_mr);

#endif

