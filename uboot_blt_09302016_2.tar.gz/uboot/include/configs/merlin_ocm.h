/*
 * Configuration for APM Merlin based Ref board
 * This is the OCM uboot build
 *
 * Copyright (c) 2010 Applied Micro Circuits Corporation.
 * All rights reserved. Keyur Chudgar <kchudgar@apm.com>.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 * MA 02111-1307 USA
 */

#ifndef __CONFIG_H
#define __CONFIG_H

#include <asm/arch/hardware.h>

/* BOARD ID Definition */
#define CONFIG_BOARD_TYPE_TIGERSHARK    1
#define CONFIG_BOARD_TYPE_MERLIN        0
 
/*
 * High Level Configuration Options
 */
#define CONFIG_OCM_U_BOOT		1
#define CONFIG_CPU_ARMV8
#define CONFIG_POTENZA			1		/* This is an ARM V8 CPU core */
#define CONFIG_SHADOWCAT				/* Shadowcat SOC */
#define CONFIG_ARM_FDT					/* Support FDT in u-boot for ARM Linux */
#define CONFIG_OF_LIBFDT		1		/* Use u-boot FDT support */
#define CONFIG_ARM_V8_MP
#define CONFIG_OF_BOARD_SETUP
#define CONFIG_ARMV8_MP
#define CONFIG_ARCH_EARLY_INIT_R	1
#define CONFIG_BOARD_EARLY_INIT_F	1

/*
 * Undefine the relocate flag will allow the code to relocate to ddr.
 */
#define CONFIG_NEEDS_MANUAL_RELOC

/*-----------------------------------------------------------------------
 * Boot Memory Configuration
 */
#define CONFIG_NR_DRAM_BANKS		4
#define CONFIG_SYS_SDRAM_BASE   	CONFIG_SYS_OCM_BASE

#ifdef CONFIG_UBOOT_NORELOCATE
#define PHYS_SDRAM_1			CONFIG_SYS_OCM_BASE
#define PHYS_SDRAM_1_SIZE		0x80000			/* 512KB */
#define OCM_END_ADDR			0x1D080000
#define CONFIG_NEEDS_MANUAL_RELOC
#endif

#define SMP_JUMP_PTR_OFFSET     0xFFF8
#define CONFIG_SYS_MCU_BASE     0x4000000000
#define CONFIG_SYS_MCU_BASE_ALT 0x80000000

#define CONFIG_SYS_TEXT_BASE		0x1D000000
#define CONFIG_DW_SPI						/* Enable SPI NOR Flash */

#define EFUSE0_SHADOW_ADDR		(MPA_EFUSE_SHADOW_CSR_I_BASE_ADDR + \
						SOC_EFUSE0_SHADOW_ADDR)
#define EFUSE1_SHADOW_ADDR		(MPA_EFUSE_SHADOW_CSR_I_BASE_ADDR + \
						SOC_EFUSE1_SHADOW_ADDR)

#define KERNEL_MAILBOX_ADDR     	(CONFIG_SYS_SDRAM_BASE + 0x0000fff8)

#define CONFIG_SYS_CLK_FREQ		100000000 		/* External Clock Freq */
#define CONFIG_SYS_CNT_FREQ		50000000
#define CONFIG_SYS_HZ  		    	1000

#define CONFIG_DISPLAY_BOARDINFO

#undef CONFIG_USE_IRQ						/* No support for IRQs */
#define CONFIG_MISC_INIT_R
#define CONFIG_ARCH_MISC_INIT					/* CPU release and etc */

#define CONFIG_ARCH_TIMER					/* ARM architecture timer supprt */
#define CONFIG_CMD_MEMORY

#ifdef CONFIG_ARM_FDT
#define CONFIG_SYS_BOOTMAPSZ 		(16 << 20) 		/* Initial Memory map for Linux	*/
#define CONFIG_SYS_BOOTM_LEN 		(16 << 20) 	/* Increase max gunzip size */
#endif

#define CONFIG_GICV2
#define GICC_BASE                       0x78020000
#define GICD_BASE                       0x78010000

/* OCM */
#define CONFIG_SYS_OCM_BASE		0x1D000000
#define CONFIG_SYS_INIT_SP_ADDR		(CONFIG_SYS_OCM_BASE + 0x70000)
#define CONFIG_SPL_STACK		(CONFIG_SYS_OCM_BASE + 0x80000)

/* Fabric Map */
#define CONFIG_SYS_QM0_FABRIC_BASE	0x20000000

/* Address Map */
#define CONFIG_SYS_ETH4_CSR_BASE	0x1F610000	
#define CONFIG_SYS_CLE4_CSR_BASE	0x1F612600
#define CONFIG_SYS_CSR_BASE		0x1F200000
#define CONFIG_SYS_QM1_CSR_BASE		(CONFIG_SYS_CSR_BASE + 0x000000)
#define CONFIG_SYS_ETH01_CSR_BASE	(CONFIG_SYS_CSR_BASE + 0x010000)
#define CONFIG_SYS_CLE01_CSR_BASE	(CONFIG_SYS_CSR_BASE + 0x016000)
#define CONFIG_SYS_ETH23_CSR_BASE	(CONFIG_SYS_CSR_BASE + 0x020000)
#define CONFIG_SYS_CLE23_CSR_BASE	(CONFIG_SYS_CSR_BASE + 0x026000)

#define CONFIG_SYS_QM0_CSR_BASE		(CONFIG_SYS_CSR_BASE + 0x400000)
#define CONFIG_SYS_XGE0_CSR_BASE	(CONFIG_SYS_CSR_BASE + 0x410000)
#define CONFIG_SYS_XGC0_CSR_BASE	(CONFIG_SYS_CSR_BASE + 0x416000)
#define CONFIG_SYS_XGE1_CSR_BASE	(CONFIG_SYS_CSR_BASE + 0x420000)
#define CONFIG_SYS_XGC1_CSR_BASE	(CONFIG_SYS_CSR_BASE + 0x426000)

#define CONFIG_UART_BASE                SHADOWCAT_UART0_CSR_BASE
#define CONFIG_SYS_AHBC_BASE            SHADOWCAT_AHBC_CSR_BASE

/*****************************************************************************
 * SLIMPRO
 *****************************************************************************/
#define CONFIG_SYS_SLIMPRO_CSR_BASE     SHADOWCAT_SLIMPRO_CSR_BASE

/*****************************************************************************
 * GIC
 ****************************************************************************/
#define CONFIG_GICV2
#define GICC_BASE			0x78020000
#define GICD_BASE			0x78010000

/*****************************************************************************
 * I2C
 * Physically I2C -> I2C1, I2C1 -> I2C2, I2C2 -> I2C3, I2C3 -> I2C4
 *****************************************************************************/
#define CONFIG_CMD_I2C
#ifdef CONFIG_CMD_I2C
#define CONFIG_SYS_I2C_INIT_BOARD		1
#define CONFIG_CMD_EEPROM
#define CONFIG_SYS_EEPROM_PAGE_WRITE_BITS	8
#define CONFIG_DW_I2C
#define CONFIG_HARD_I2C                		1
#define CONFIG_SYS_SPD_BUS_NUM			1
#define CONFIG_SYS_MAX_I2C_BUS 			4

#define CONFIG_I2C_CLK_FREQ			100000000	/* CONFIG_SYS_CLK_FREQ */

#define CONFIG_DW_I2C_TX_BUFFER_DEPTH		16
#define CONFIG_DW_I2C_RX_BUFFER_DEPTH		16
#define CONFIG_I2C_MULTI_BUS    		1

#define CONFIG_I2C_BASE_ADDRESS			SHADOWCAT_SLIMPRO_IIC1_SPACE_BASE
#define CONFIG_SYS_I2C_SPEED	    		100000
#define CONFIG_SYS_I2C_EEPROM_ADDR		0x52
#define CONFIG_SYS_I2C_EEPROM_ADDR_LEN		2
#define CONFIG_SYS_I2C_EEPROM_PAGE_WRITE_LEN	8

#define CONFIG_I2C1_BASE_ADDRESS		SHADOWCAT_SLIMPRO_IIC2_SPACE_BASE
#define CONFIG_SYS_I2C1_SPEED	    		100000
#define CONFIG_SYS_I2C1_EEPROM_ADDR		0x50
#define CONFIG_SYS_I2C1_EEPROM_ADDR_LEN		2
#define CONFIG_SYS_I2C1_EEPROM_PAGE_WRITE_LEN	8

#define CONFIG_I2C2_BASE_ADDRESS		SHADOWCAT_SLIMPRO_IIC3_SPACE_BASE
#define CONFIG_SYS_I2C2_SPEED	    		100000
#define CONFIG_SYS_I2C2_EEPROM_ADDR		0x50
#define CONFIG_SYS_I2C2_EEPROM_ADDR_LEN		2
#define CONFIG_SYS_I2C2_EEPROM_PAGE_WRITE_LEN	8

#define CONFIG_I2C3_BASE_ADDRESS		SHADOWCAT_SLIMPRO_IIC4_SPACE_BASE
#define CONFIG_SYS_I2C3_SPEED	    		100000
#define CONFIG_SYS_I2C3_EEPROM_ADDR		0x50
#define CONFIG_SYS_I2C3_EEPROM_ADDR_LEN		2
#define CONFIG_SYS_I2C3_EEPROM_PAGE_WRITE_LEN	8

#define CONFIG_SYS_I2C_SLAVE			CONFIG_SYS_I2C_EEPROM_ADDR
#define CONFIG_SYS_I2C_BOOT_ADDR                CONFIG_SYS_I2C_EEPROM_ADDR
#define CONFIG_SYS_I2C_BOOT_BUSNUM              0
#define CONFIG_SYS_I2C_BOOT_EEPROM_ADDR_LEN     CONFIG_SYS_I2C_EEPROM_ADDR_LEN
#endif /* CONFIG_CMD_I2C */

/*****************************************************************************
 * SPI
 *****************************************************************************/
#if defined CONFIG_DW_SPI
#define CONFIG_HARD_SPI    			1
#define CONFIG_CMD_SF
#define CONFIG_SPI_FLASH
#define CONFIG_SPI_FLASH_STMICRO
#define CONFIG_SPI_FLASH_WINBOND
#define CONFIG_SF_DEFAULT_SPEED			12500000
#define CONFIG_ENV_SPI_MAX_HZ			12500000
#define CONFIG_DW_SPI_BASE	        	0x10610000
#define CONFIG_DW_SPI_MAX_CS			1
#define CONFIG_DW_SPI_FIFO_DEPTH        	256
#define CONFIG_DW_SPI_SYSCLK			100000000
#define CONFIG_DW_SPI_VER_ID			0x3331352a
#define CONFIG_SYS_HZ 				1000
#endif

/*****************************************************************************
 * GFC (NOR Flash)
 *****************************************************************************/
#define CONFIG_GFC
#if !defined(CONFIG_GFC)
#define CONFIG_SYS_NO_FLASH
#else
#define CONFIG_NOR		    		1
#define CONFIG_HAS_NOR_FLASH 	    		1
#define CONFIG_GFC_BASE		    		SHADOWCAT_GFC_CSR_BASE
#define CONFIG_SYS_FLASH_BASE       		0x8100000000ULL
#define CONFIG_SYS_MONITOR_BASE         	CONFIG_SYS_FLASH_BASE
#define CONFIG_SYS_FLASH_LEN        		(64 << 20)
#define PHYS_FLASH_SIZE             		(64 << 20)
#define CONFIG_SYS_MONITOR_LEN          	(128 << 10)
#define CONFIG_SYS_HZ  		        	1000
#define CONFIG_FLASH_CFI_DRIVER                    		/* Use CFI flash driver */
#define CONFIG_SYS_FLASH_CFI                       		/* Uses CFI structure   */
#define CONFIG_SYS_FLASH_CFI_AMD_RESET             		/* Uses AMD Reset command F0 */
#define CONFIG_SYS_MAX_FLASH_BANKS      	1          	/* max number of flash banks */
#define CONFIG_SYS_FLASH_CFI_WIDTH      	FLASH_CFI_16BIT
#define CONFIG_SYS_FLASH_EMPTY_INFO                		/* flinfo 'E' for empty */
#define CONFIG_SYS_MAX_FLASH_SECT		518
#define CONFIG_SYS_FLASH_USE_BUFFER_WRITE          		/* Uses Buffer Write, 20x faster than single write */
#define CONFIG_SYS_FLASH_CHECK_BLANK_BEFORE_ERASE  		/*Uses to check blank sector before erase */
#define CONFIG_SYS_CFI_FLASH_STATUS_POLL           		/* Uses S29WS Polling Algorithm */
#define CONFIG_CMD_FLASH
#endif

/*****************************************************************************
 * ENV IN SPI AND NOR FLASH
 *****************************************************************************/
#define CONFIG_ENV_IS_NOWHERE
#if defined (CONFIG_GFC)
#define CONFIG_ENV_ADDR 			(CONFIG_SYS_FLASH_BASE + (256 << 10))
#define CONFIG_ENV_SECT_SIZE 			(128 << 10)
#else
#if defined (CONFIG_SPI_FLASH)
#define CONFIG_ENV_SECT_SIZE 			0x40000
#define CONFIG_ENV_ADDR 			0xC0000
#define CONFIG_ENV_OFFSET 			0xC0000
#define CONFIG_SYS_NO_FLASH
#else
#define CONFIG_SYS_NO_FLASH
#endif
#endif

#define CONFIG_CMD_IPP
#define CONFIG_IPP_MESSAGING

#define CONFIG_64BIT_PHYS_ADDR
#define CONFIG_SYS_64BIT_STRTOUL
#define CONFIG_SYS_64BIT_VSPRINTF

/* Size of malloc() pool */
#define CONFIG_ENV_SIZE				(4 << 10)		/* 4 KiB */

/* Linux interfacing */
#define CONFIG_CMDLINE_TAG
#define CONFIG_INITRD_TAG
#define CONFIG_SYS_BARGSIZE			1024			/* Bootarg Size */
#define CONFIG_SYS_LOAD_ADDR			0x100008000		/* kernel address */
#define CONFIG_INITRD_ADDR			0x100700000

#define CONFIG_SYS_MALLOC_LEN			(100*1024)
#define CONFIG_SYS_GBL_DATA_SIZE		128
#define CONFIG_SYS_MEMTEST_START		CONFIG_LOADADDR + 0x100000
#define CONFIG_SYS_MEMTEST_END			CONFIG_LOADADDR + 0x10000000
#define CONFIG_DISPLAY_CPUINFO

#define CONFIG_APM_TESTS

/*****************************************************************************
 * CACHE
 ****************************************************************************/
#define CONFIG_SYS_CACHE_ENABLED
#ifdef CONFIG_SYS_CACHE_ENABLED
#define CONFIG_XGENE_TTB_ADDR           0x1D070000ULL
#else
#define CONFIG_SYS_ICACHE_OFF
#define CONFIG_SYS_DCACHE_OFF
#endif

#define CONFIG_USB_CSR_BASE            { 0x1F230000ULL, 0x0ULL }

/*****************************************************************************
 * SATA configuration
 *****************************************************************************/
#undef CONFIG_XGENE_SATA
#ifdef CONFIG_XGENE_SATA
#define CONFIG_SATA_CSR_BASE			{ 0x1f200000ULL, 0x1f210000ULL, 0x1f220000ULL, 0x0ULL }
#define CONFIG_SATA_AHCI_BASE			{ 0x1A000000ULL, 0x1A200000ULL, 0x1A400000ULL, 0x0ULL }
#define CONFIG_SATA_SERDES_DIFF_CLK     	{ 0, 0, 0} /* Internal differential clk for sata01, sata23, sata45 */
#define CONFIG_SATA_GEN_SELECT          	{ 3, 3, 3} /* gen select for sata01, sata23, sata45 */
#define CONFIG_SCSI_AHCI
#define CONFIG_AHCI_SETFEATURES_XFER
#define CONFIG_NO_ILOG2
#define CONFIG_SCSI_AHCI_PLAT
#define CONFIG_CMD_SCSI
#define CONFIG_SATA_MAX_DEVICE_AHCI     	3                   /* <num> device ahci */
#define CONFIG_LIBATA
#define CONFIG_LBA48
#define CONFIG_SYS_SCSI_MAX_LUN         	1	/* number of supported LUNs */
#define CONFIG_SYS_SCSI_MAX_SCSI_ID     	2	/* maximum SCSI ID (0..6) */
#define CONFIG_SYS_SCSI_MAX_DEVICE     		(CONFIG_SATA_MAX_DEVICE_AHCI * CONFIG_SYS_SCSI_MAX_SCSI_ID * CONFIG_SYS_SCSI_MAX_LUN) /* maximum Target devices */
#endif

/*****************************************************************************
 * GPIO
 *****************************************************************************/
#define CONFIG_XGENE_GPIO
#define CONFIG_CMD_GPIO
#define gpio_status()            gpio_info()

#ifdef CONFIG_XGENE_GPIO
#define CONFIG_XGENE_GPIO_SOC
#define CONFIG_XGENE_GPIO_SB
#endif

/*****************************************************************************
 * Ethernet
 *****************************************************************************/
#define ENABLE_ENET
#ifdef ENABLE_ENET
#define CONFIG_APM88XXXX_CLE
#define ENABLE_QM
#define CONFIG_NET_MULTI
#define CONFIG_CMD_NET
/* #define CONFIG_CMD_APM88XXXX_ENET */
#undef CONFIG_NETCONSOLE

#define CONFIG_APM88XXXX_ENET
#define CONFIG_APM88XXXX_XGENET

#ifdef CONFIG_APM88XXXX_ENET
#define CONFIG_HAS_XG0
#endif

#ifdef CONFIG_APM88XXXX_XGENET
#define CONFIG_HAS_XG0
#endif

#define CONFIG_SGMII_MARVELL_88E1512

#define CONFIG_CMD_MII
#define CONFIG_CMD_ARP
#define CONFIG_CMD_PING

#ifdef ENABLE_QM
#define CONFIG_APM88XXXX_QM
/* #define CONFIG_CMD_APM88XXXX_QM */
#endif

#endif /* ENABLE_ENET */

/*****************************************************************************
 * RDMA
 *****************************************************************************/
#undef CONFIG_RDMA
#ifdef CONFIG_RDMA
#ifndef CONFIG_CMD_NET
#define CONFIG_CMD_NET
#endif
#define CONFIG_CMD_RDMA
#define CONFIG_XGENE_ROCE_HV
#define CONFIG_XGENE_ROCE
#define CONFIG_SYS_RDMA0_CSR_BASE	(CONFIG_SYS_CSR_BASE + 0x600000)
#define CONFIG_SYS_RDMA0_QPS_BASE	0x1a800000
#endif /* CONFIG_RDMA */

/* NS16550 Configuration */
#define V_NS16550_CLK				18432000	/* 10MHz */
#define CONFIG_SYS_NS16550_CLK			V_NS16550_CLK
#define CONFIG_CONS_INDEX			1
#define CONFIG_SYS_NS16550_COM1			CONFIG_UART_BASE
#define CONFIG_SERIAL3				3

/* allow to overwrite serial and ethaddr */
#define CONFIG_ENV_OVERWRITE
#define CONFIG_BAUDRATE				115200
#define CONFIG_SYS_BAUDRATE_TABLE		{4800, 9600, 19200, 38400, 57600, \
						115200}
#undef CONFIG_CMD_IMLS
#define CONFIG_CMD_RUN

#define CONFIG_CMD_ASKENV
#define CONFIG_CMD_EDITENV
#define CONFIG_CMD_SAVEENV

/* Environment information */
#define CONFIG_HOSTNAME		  		merlin
#define CONFIG_BOOTDELAY			5
#if !defined(CONFIG_USE_TTY)
#define CONFIG_USE_TTY  ttyS1
#endif
#if !defined(CONFIG_USE_NETDEV)
#define CONFIG_USE_NETDEV       		eth0
#endif
#define CONFIG_BOOTCOMMAND      		"print flash_self"
#define CONFIG_ADDMISC  			"addmisc=setenv bootargs ${bootargs} "	\
						"earlycon=uart8250,mmio32,0x10600000 " \
						"debug maxcpus=${num_cores}\0"

#define xstr(s) str(s)
#define str(s)  #s

#define SHADOWCAT_BOOT_MAP			\
	"uboot_addr_r=0x4001000000\0"		\
	"kern_addr_r=0x4002000000\0"		\
	"fdt_addr_r=0x4003000000\0"		\
	"ramdisk_addr_r=0x4004000000\0"		\
	"uboot_addr_f=0x8100000000\0"		\
	"kern_addr_f=0x8100200000\0"		\
	"fdt_addr_f=0x8100a00000\0"		\
	"ramdisk_addr_f=0x8100b00000\0"		\
	"initrd_high=0x2000000\0"		\
        "media_addr_r=0x4001000000\0"  		\
	"fw_pm_addr_r=0x1d060000\0"		\
	"fw_addr_r=0x1d050000\0"

#define SHADOWCAT_UPD_NOR_UBOOT						\
	"u-boot=u-boot.bin\0"						\
	"load=tftp ${uboot_addr_r} ${user_dir}/${u-boot}\0"		\
	"update=protect off ${uboot_addr_f} +${uboot_size}; "		\
		"erase ${uboot_addr_f} +${uboot_size}; "		\
		"cp.b ${uboot_addr_r} ${uboot_addr_f} ${uboot_size}\0"	\
	"upd=run load; setenv uboot_size ${filesize};run update\0"

#define SHADOWCAT_UPD_SPINOR_MEDIA					\
	"media_img=uboot_"xstr(CONFIG_HOSTNAME)"_media.img\0"		\
	"spi_load=tftp ${media_addr_r} ${user_dir}/${media_img}\0"   	\
	"spi_update=sf probe 0; "					\
		"sf erase 0x0 ${filesize}; "				\
		"sf write ${media_addr_r} 0x0 ${filesize}\0"		\
	"spi_upd=run spi_load;run spi_update\0"

#define SHADOWCAT_UPD_SPI_FW						\
	"fw_img="xstr(CONFIG_HOSTNAME)"_fw_ext_spi.bin\0"		\
	"fw_load=tftp ${fw_addr_r} ${user_dir}/${fw_img}\0"		\
	"fw_update=i2c dev 0; "						\
		"eeprom write ${fw_addr_r} 0x0 0xf800; "		\
		"eeprom write ${fw_pm_addr_r} 0x10000 0x10000\0"	\
	"fw_upd=run fw_load;run fw_update\0"

#define SHADOWCAT_UPD_NOR_KERNEL					\
	"load_kern=tftp ${kern_addr_r} ${user_dir}/${bootfile}\0"	\
	"update_kern=protect off ${kern_addr_f} +${kern_size}; "	\
		"erase ${kern_addr_f} +${kern_size}; "			\
		"cp.b ${kern_addr_r} ${kern_addr_f} ${kern_size}\0"	\
	"updkern=run load_kern; sete kern_size ${filesize}; run update_kern\0"


#define SHADOWCAT_UPD_NOR_RAMDISK							\
	"load_ramdisk=tftp ${ramdisk_addr_r} ${user_dir}/${ramdisk_file}\0"		\
	"update_ramdisk=protect off ${ramdisk_addr_f} +${ramdisk_size}; " 		\
			"erase ${ramdisk_addr_f} +${ramdisk_size}; " 			\
			"cp.b ${ramdisk_addr_r} ${ramdisk_addr_f} ${ramdisk_size}\0"	\
	"updramdisk=run load_ramdisk; sete ramdisk_size ${filesize};run update_ramdisk\0"

#define SHADOWCAT_UPD_NOR_FDT                                                       	\
        "load_fdt=tftp ${fdt_addr_r} ${user_dir}/${fdt_file}\0" 			\
        "update_fdt=protect off ${fdt_addr_f} +${fdt_size}; "   			\
                        "erase ${fdt_addr_f} +${fdt_size}; "            		\
                        "cp.b ${fdt_addr_r} ${fdt_addr_f} ${fdt_size}\0"		\
        "updfdt=run load_fdt; sete fdt_size ${filesize};run update_fdt\0"

#define SHADOWCAT_UPD_NOR_ALL					\
	"updall=run updkern; run updramdisk; run updfdt\0"	\

#define SHADOWCAT_DEF_ENV						\
	"netdev=" xstr(CONFIG_USE_NETDEV) "\0"				\
	"nfsargs=setenv bootargs root=/dev/nfs rw "			\
		"nfsroot=${serverip}:${rootpath},vers=3,tcp\0"			\
	"ramargs=setenv bootargs root=/dev/ram rw\0"			\
	"sataargs=setenv bootargs root=/dev/sda1 rw\0"			\
	"addip=setenv bootargs ${bootargs} "				\
		"ip=${ipaddr}:${serverip}:${gatewayip}:${netmask}"	\
		":${hostname}:${netdev}:off panic=1\0"			\
	"addtty=setenv bootargs ${bootargs} "				\
		"console=" xstr(CONFIG_USE_TTY) ",${baudrate}\0"	\
	CONFIG_ADDMISC							\
	"bootfile=uImage\0"						\
	"ramdisk_file=uRamdisk\0"					\
	"fdt_file=apm-"xstr(CONFIG_HOSTNAME)".dtb\0"			\
	"user_dir="xstr(CONFIG_HOSTNAME)"\0"				\
	"enet=4\0"							\
	"ipaddr=192.168.1.2\0"						\
	"netmask=255.255.255.0\0"					\
	"gatewayip=192.168.1.254\0"					\
	"serverip=192.168.1.1\0"					\
	"mgmt_enet=e\0"							\
	"enet_mode=s:x\0"						\
	"xgmii_phyid=0:::\0"						\
	"sata=0x4\0"							\
	"pcie_mode=RP:NA:NA:NA:NA\0"					\
	"pcie_gen=3:3:3:3:3\0"						\
	"rootpath=/opt/nfsrootfs/arm64/release\0"

#define SHADOWCAT_BOOT_CMDS						\
	"flash_self=run ramargs addip addtty addmisc; "			\
		"bootm ${kern_addr_f} ${ramdisk_addr_f} ${fdt_addr_f}\0"\
	"flash_nfs=run nfsargs addip addtty addmisc; "			\
		"bootm ${kern_addr_f}\0"				\
	"ram_self=run ramargs addip addtty addmisc; "			\
		"bootm ${kern_addr_r} ${ramdisk_addr_r} ${fdt_addr_r}\0"\
	"ram_nfs=run nfsargs addip addtty addmisc; "			\
		"bootm ${kern_addr_r} - ${fdt_addr_r}\0"		\
	"net_self_load=run load_kern load_ramdisk load_fdt\0"		\
	"net_self=run net_self_load; "					\
		"run ramargs addip addtty addmisc; "			\
		"bootm ${kern_addr_r} ${ramdisk_addr_r} ${fdt_addr_r}\0"\
	"net_nfs=run load_kern load_fdt; "				\
		"run nfsargs addip addtty addmisc; "			\
		"bootm ${kern_addr_r} - ${fdt_addr_r}\0"		\
	"net_sata=run load_kern load_fdt; "				\
		"run sataargs addip addtty addmisc; "			\
		"bootm ${kern_addr_r} - ${fdt_addr_r}\0"


#define CONFIG_EXTRA_ENV_SETTINGS			\
	SHADOWCAT_DEF_ENV				\
	SHADOWCAT_UPD_NOR_UBOOT				\
        SHADOWCAT_UPD_SPINOR_MEDIA			\
	SHADOWCAT_UPD_SPI_FW                         	\
	SHADOWCAT_UPD_NOR_KERNEL			\
	SHADOWCAT_UPD_NOR_FDT				\
	SHADOWCAT_UPD_NOR_ALL				\
	SHADOWCAT_BOOT_CMDS				\
	SHADOWCAT_UPD_NOR_RAMDISK                       \
	SHADOWCAT_BOOT_MAP

/*
 * Miscellaneous configurable options
 */
#define V_PROMPT				"Merlin# "
#define CONFIG_NO_PCMCIA
#undef CONFIG_SYS_LONGHELP					/* undef to save memory */
#undef CONFIG_SYS_HUSH_PARSER					/* use "hush" command parser */
#undef CONFIG_SYS_PROMPT_HUSH_PS2
#define CONFIG_SYS_PROMPT			V_PROMPT
#define CONFIG_SYS_CBSIZE			256		/* Console I/O Buffer Siz */
/* Print Buffer Size */
#define CONFIG_SYS_PBSIZE			(CONFIG_SYS_CBSIZE + \
						sizeof(CONFIG_SYS_PROMPT) + 16)
#define CONFIG_SYS_MAXARGS			16		/* max number of command */
								/* args */
/*-----------------------------------------------------------------------
 * Stack sizes
 *
 * The stack sizes are set up in start.S using the settings below
 */
#define CONFIG_STACKSIZE			(16 << 10)	/* regular stack 16 KiB */
#ifdef CONFIG_USE_IRQ
#define CONFIG_STACKSIZE_IRQ			(4 << 10)	/* IRQ stack 4 KiB */
#define CONFIG_STACKSIZE_FIQ			(4 << 10)	/* FIQ stack 4 KiB */
#endif

/* XXX: Declare SHADOWCAT_DRAMB_BASE for PHYS_SDRAM_2  */

#endif	/* __CONFIG_H */
