/*
 * Configuration for APM MSLIM - Mustang Reference board
 *
 * Copyright (c) 2012 Applied Micro Circuits Corporation.
 * Author: Vinayak Kale <vkale@apm.com>.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 * MA 02111-1307 USA
 */

#ifndef __CONFIG_H
#define __CONFIG_H

#include <asm/arch/mslim_map.h>
/*
 * High Level Configuration Options
 */
#define CONFIG_MSLIM		1	/* MSLIM core */
#define CONFIG_MSLIM_SMP	1
/* #define CONFIG_MSLIM_VHP */

#define CONFIG_ARM_FDT                  /* Support FDT in u-boot for ARM Linux */
#define CONFIG_OF_LIBFDT        1       /* Use u-boot FDT support */
#define CONFIG_OF_BOARD_SETUP

#define CONFIG_SYS_TEXT_BASE	0x51E00000

#undef CONFIG_USE_IRQ			/* No support for IRQs */
#undef CONFIG_MISC_INIT_R

#define CONFIG_CMD_MEMORY

#ifdef CONFIG_ARM_FDT	
#define CONFIG_SYS_BOOTMAPSZ    (8 << 20) /* Initial Memory map for Linux */
#define CONFIG_SYS_BOOTM_LEN    (8 << 20) /* Increase max gunzip size */
#endif

#define	CONFIG_SYS_CLK_FREQ	(100000000)	/* SYS_REFCLK = 100MHz */
#define MSLIM_TIMER_CLK_FREQ	(250000000) 	

/* Address Map */
//#define CONFIG_MSLIM_UART0
#ifdef CONFIG_MSLIM_UART0
#define CONFIG_UART_BASE	MSLIM_UART0_CSR_BASE
#else
#define CONFIG_UART_BASE	MSLIM_UART1_CSR_BASE
#endif
#ifdef CONFIG_MSLIM_SMP
#define MSLIM_SMP_MAILBOX_ADDR 	MSLIM_CFG_COP_SCRATCH0
#endif

/* Size of malloc() pool */
#define CONFIG_ENV_SIZE		(128 << 10)	/* 128 KiB */
#define CONFIG_LOADADDR 	0x50000000

/* Linux interfacing */
#define CONFIG_CMDLINE_TAG
#define CONFIG_INITRD_TAG
#define CONFIG_SYS_BARGSIZE		1024		/* Bootarg Size */
#define CONFIG_SYS_LOAD_ADDR		0x50008000	/* kernel address */
#define CONFIG_INITRD_ADDR		0x50800000

#define CONFIG_SYS_MALLOC_LEN		(CONFIG_ENV_SIZE + (256*1024))
#define CONFIG_SYS_GBL_DATA_SIZE	512
#define CONFIG_SYS_MEMTEST_START	CONFIG_LOADADDR + 0x100000
#define CONFIG_SYS_MEMTEST_END		CONFIG_LOADADDR + 0x10000000
#define CONFIG_DISPLAY_CPUINFO
#define CONFIG_DISPLAY_BOARDINFO

#ifdef ENABLE_PAGING
#define CONFIG_PAGE_TABLE_ADDR		0x52000000 /* 32MB offset */
#endif

/* Hardware drivers */

/* NS16550 Configuration */
#define V_NS16550_CLK			18432000	
#define CONFIG_SYS_NS16550_CLK		V_NS16550_CLK
#define CONFIG_CONS_INDEX		1
#define CONFIG_SYS_NS16550_COM1		CONFIG_UART_BASE
#define CONFIG_SERIAL3			3

/* allow to overwrite serial and ethaddr */
#define CONFIG_ENV_OVERWRITE
#define CONFIG_BAUDRATE			115200	
#define CONFIG_SYS_BAUDRATE_TABLE	{4800, 9600, 19200, 38400, 57600, \
					115200}
#undef CONFIG_CMD_IMLS
#define CONFIG_CMD_RUN

#define CONFIG_SYS_NO_FLASH
#define CONFIG_ENV_IS_NOWHERE

/* Environment information */
#define CONFIG_HOSTNAME		mslim
#define CONFIG_BOOTDELAY	5
#if !defined(CONFIG_USE_TTY)
#define CONFIG_USE_TTY  ttyS0
#endif
#if !defined(CONFIG_USE_NETDEV)
#define CONFIG_USE_NETDEV       eth0
#endif
#define CONFIG_BOOTCOMMAND      "print ram_self"
#define CONFIG_ADDMISC  "addmisc=setenv bootargs ${bootargs} "	\
			"mem=256M lpj=2500000 earlyprintk debug maxcpus=${num_cores} libata.force=noncq\0"
#ifdef CONFIG_MSLIM_SMP
#define CONFIG_MSLIM_CORES	"num_cores=4\0"
#else
#define CONFIG_MSLIM_CORES	"num_cores=1\0"
#endif

#define xstr(s) str(s)
#define str(s)  #s

#define MSLIM_BOOT_MAP				\
	"kern_addr_r=0x51000000\0"		\
	"ramdisk_addr_r=0x52000000\0"		\
	"fdt_addr_r=0x50600000\0"		\
	"kern_size=0x400000\0"			\
	"ramdisk_size=0x400000\0"		\
        "initrd_high=0x54000000\0"

#define MSLIM_DEF_ENV							\
	"ramargs=setenv bootargs root=/dev/ram rw\0"			\
	"addtty=setenv bootargs ${bootargs} "				\
		"console=" xstr(CONFIG_USE_TTY) ",${baudrate}\0"	\
	CONFIG_ADDMISC							

#define MSLIM_BOOT_CMDS							\
        "ram_self=run ramargs addtty addmisc; "                         \
                "bootm ${kern_addr_r} ${ramdisk_addr_r} ${fdt_addr_r}\0"

#define CONFIG_EXTRA_ENV_SETTINGS		\
	MSLIM_DEF_ENV				\
	MSLIM_BOOT_CMDS				\
	CONFIG_MSLIM_CORES			\
	MSLIM_BOOT_MAP

/*
 * Miscellaneous configurable options
 */
#define V_PROMPT			"Mslim # "
#define CONFIG_NO_PCMCIA
#undef CONFIG_SYS_LONGHELP		/* undef to save memory */
#undef CONFIG_SYS_HUSH_PARSER		/* use "hush" command parser */
#undef CONFIG_SYS_PROMPT_HUSH_PS2
#define CONFIG_SYS_PROMPT		V_PROMPT
#define CONFIG_SYS_CBSIZE		256	/* Console I/O Buffer Size */
/* Print Buffer Size */
#define CONFIG_SYS_PBSIZE		(CONFIG_SYS_CBSIZE + \
					sizeof(CONFIG_SYS_PROMPT) + 16)
#define CONFIG_SYS_MAXARGS		16	/* max number of command */
						/* args */
/*-----------------------------------------------------------------------
 * Stack sizes
 *
 * The stack sizes are set up in start.S using the settings below
 */
#define CONFIG_STACKSIZE	(128 << 10)	/* regular stack 128 KiB */
#ifdef CONFIG_USE_IRQ
#define CONFIG_STACKSIZE_IRQ	(4 << 10)	/* IRQ stack 4 KiB */
#define CONFIG_STACKSIZE_FIQ	(4 << 10)	/* FIQ stack 4 KiB */
#endif

/*-----------------------------------------------------------------------
 * Physical Memory Map
 */
#define CONFIG_NR_DRAM_BANKS	1	/* CS1 may or may not be populated */
#define PHYS_SDRAM_1		MSLIM_DRAMA_BASE
#define PHYS_SDRAM_1_SIZE	(256 << 20)	/* 256MB */

#endif	/* __CONFIG_H */
