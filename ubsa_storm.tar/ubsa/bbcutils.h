#ifndef __BBCUTILS_H
#define __BBCUTILS_H

//#include <common.h>

#include "stdint.h"
#include "ubsa_membase.h"

#ifndef NULL
#define NULL ((void*)0)
#endif

#define noinline __attribute__((noinline))

typedef uint8_t  u8;
typedef uint32_t u32;
typedef uint64_t u64;

typedef enum {
  Status__Init = 0xaa,
  Status__Started = 0xab,
  Status__Passed = 0x00,
  Status__Failed = 0x02,
  Status__FailedMax = 0x1f
} test_status_e;

typedef struct {
  uint32_t signature;
  uint32_t num_test_starts;
  uint32_t num_test_passes;
  uint32_t num_test_fails;
  uint32_t fis_arg;
  uint32_t num_cores;
  uint32_t num_threads;
  uint32_t future;
  uint8_t status[8];
  uint8_t padding[8];
  uint64_t debug[9]; // 8 per-core private offsets + 1 master message
} test_status_s;

void puts(const char *x);
void putc(char x);
char getc();

uint64_t noinline  get_mpidr(void);
uint64_t noinline  get_midr(void);
uint64_t noinline  get_dczid(void);
uint64_t noinline  get_id_aa64pfr0(void);
uint64_t noinline  get_id_aa64pfr1(void);
uint64_t noinline  get_id_aa64isar0(void);
uint64_t noinline  get_revidr(void);
uint32_t cpuid(void);
uint32_t noinline  get_cores_started(void);
uint32_t * noinline get_semaphore_ptr(uint32_t);
//char * noinline get_console_buffer_ptr();
uint32_t noinline exchangeExclusive(volatile uint32_t *, volatile uint32_t *, uint32_t);
uint32_t noinline incrementExclusive(volatile uint32_t *, volatile uint32_t *, uint32_t);
int32_t noinline sync(uint32_t volatile *, int32_t);
int32_t noinline sync_dont_die(uint32_t volatile *, int32_t);
uint32_t noinline sync_dont_die_asm( uint32_t *, uint64_t );
uint32_t noinline sync_dont_die_asm_nowfe( uint32_t *, uint64_t );

uint32_t X__printf(const char *format_string, ...);
test_status_s *get_test_status_ptr(void);
uint32_t get_test_status_num_cores(void);
void dump_test_status(void);

typedef uint64_t size_t;
int strncmp(const char * cs,const char * ct,size_t count);
int strcmp(const char * cs,const char * ct);
char * strncpy(char * dest,const char *src,size_t count);
char * strcpy(char * dest,const char *src);
void * memmove(void * dest,const void *src,size_t count);
size_t strlen(const char * s);
size_t strnlen(const char * s, size_t count);



uint32_t __snprintf(char *dest, const uint32_t sz, const char *format_string, ...);

//void lock(uint32_t _sem_id);
//void unlock(uint32_t _sem_id);

#define NUM_UBSA_LOCKS 8

typedef enum {
  LK_CPU_MAP = 0,
  LK_PRINTF = 1,
  LK_PROC_STATE = 2,
  LK_MALLOC = 3,
  LK_ID_4 = 4,
  LK_ID_5 = 5,
  LK_ID_6 = 6,
  LK_ID_7 = 7,
} e_lock_id;

int64_t ubsa_lock(e_lock_id lock_id);
void ubsa_unlock(e_lock_id lock_id);
void ubsa_sync(e_lock_id lock_id, uint32_t volatile *counter, uint32_t cores);

void setup_cpu_map();

//void memset(void *s, int c, uint64_t n);
void init_pmu(void);
void enable_pmu(void);
uint64_t noinline  get_pmccntr(void);
void set_pmccntr(uint64_t count);
uint32_t noinline  get_pmu_overflow_status(void);
void set_pmu_event(uint32_t counter_num, uint32_t event_num);
uint64_t noinline  get_pmu_event_counter(uint32_t counter_num);

void mcu_phy_rdfifo_reset(u32 chan);
void mcu_phy_rdfifo_reset_all();

int mcu_phy_sw_adj_ctrlupdate(uint32_t mcu);

void set_rd_trim_delay(uint32_t chan, uint32_t byte, int32_t *data);
void get_rd_trim_delay(uint32_t chan, uint32_t byte, int32_t *data);
void set_wr_trim_delay(uint32_t chan, uint32_t byte, int32_t *data);
void get_wr_trim_delay(uint32_t chan, uint32_t byte, int32_t *data);

void wr_mcu_err_status(uint32_t chan, uint32_t rank, uint32_t data);
uint32_t rd_mcu_err_status(uint32_t chan, uint32_t rank);
void wr_mcu_sbe_count(uint32_t chan, uint32_t rank, uint32_t data);
uint32_t rd_mcu_sbe_count(uint32_t chan, uint32_t rank);


void *ubsa_malloc(uint64_t size);
void ubsa_free(void *a);

uint8_t *ubsa_dram_malloc(uint64_t size);
void ubsa_dram_alloc_reset();
void ubsa_dram_free(uint8_t *mem);

// allocates a block starting at the start of dram
uint8_t *ubsa_dram_malloc_block(uint64_t size);

// allocates a block inside the given rank
// assumes MCU interleave is enabled
// if rank interleave is enabled, this memory will be part of 2 (or more?) ranks
uint8_t *ubsa_dram_malloc_rank(uint64_t size, uint32_t rank);

void ubsa_dram_alloc_reset();

void setup_page_tables(void);

int ubsa_is_rank_intlv(uint64_t rank);
int32_t get_rank_intlv(uint64_t mcu, uint64_t rank);
int32_t ubsa_get_rank(void *ptr);
int ubsa_is_rank_valid(uint64_t mcu, uint64_t rank);
uint32_t ubsa_get_rank_intlv_way();
uint32_t ubsa_num_ranks(uint64_t mcu);

int arch_timer_setup(void);
void arch_timer_start(void);
void arch_timer_stop(void);
uint32_t arch_timer_start_reset();

uint64_t arch_timer_elapsed(uint64_t *tmr);

void arch_timer_udelay(u32 usec);

void lfsr( uint32_t *_lfsr_p );
uint64_t rand_val(uint32_t *_lfsr_p);

uint32_t read_rb(int page, int offset);
void write_rb(int page, int offset, uint32_t data);

uint32_t  get_csw_config_reg(void);
uint32_t  get_mcb_addr_config(uint32_t mcb);
uint32_t  get_mcu_rank_config(uint32_t chan, uint32_t rank);
uint32_t  get_mcu_rank_size(uint32_t chan, uint32_t rank);
uint32_t  get_mcu_rank_base(uint32_t chan, uint32_t rank);
uint32_t  get_mcu_rank_mask(uint32_t chan, uint32_t rank);

void set_csw_config_reg(uint32_t data);
void set_mcb_addr_config(uint32_t mcb, uint32_t data);
void set_mcu_rank_config(uint32_t chan, uint32_t rank, uint32_t data);
void set_mcu_rank_size(uint32_t chan, uint32_t rank, uint32_t data);
void set_mcu_rank_base_lower(uint32_t chan, uint32_t rank, uint32_t data);
void set_mcu_rank_base_upper(uint32_t chan, uint32_t rank, uint32_t data);
void set_mcu_rank_mask_lower(uint32_t chan, uint32_t rank, uint32_t data);
void set_mcu_rank_mask_upper(uint32_t chan, uint32_t rank, uint32_t data);

uint32_t get_iob_remap_rng(int reg);
void set_iob_remap_rng(int reg, uint32_t data);
uint32_t get_iob_remap_bar(int reg);
void set_iob_remap_bar(int reg, uint32_t data);
uint32_t get_iob_remap_tar5();
void set_iob_remap_tar5(uint32_t data);

uint32_t is_mcu_x4_en(uint32_t chan);
uint32_t is_x4_mode();

uint32_t is_sngl_rank_lvl(uint32_t chan);

uint32_t is_ecc_on(uint32_t mcu);

void print_memcfg(void);

uint64_t get_phys_dram_base();
uint64_t get_phys_dram_size();

uint32_t is_mcu_active(uint32_t mcu_num);

uint32_t mcu_mask_to_idx(uint32_t mask);
uint32_t mcu_idx_to_mcu(uint32_t idx);

#define NUM_PROCESSORS 8

uint64_t get_hwcpuid(); // HW CPU ID from MPIDR
uint64_t get_cpuid(); // mapped CPU ID, starts with 0
int32_t cpu_hw2m(uint32_t hw_cpu);
int32_t cpu_m2hw(int32_t mapped_cpu);


void print_cpu_map();

uint32_t start_processor(uint32_t proc, void *(*thread_func)(uint32_t, void *), void *param);

uint32_t get_processor_result(uint32_t proc, void **res);

uint32_t is_processor_valid(uint32_t proc);
uint32_t is_processor_running(uint32_t proc);
uint32_t num_processors();

void *command_interp(uint32_t proc, void *v);

char *ubsa_strtok(char * s,const char * ct, char **__tmp);

char *strsep(char **s, const char *ct);

void *memcpy(void *, const void *, uint64_t);
char * bcopy(const char * src, char * dest, int count);

enum ubsa_long_opt_e {
  OPT_STRING,
  OPT_UINT64,
  OPT_INT64,
  OPT_UINT32,
  OPT_INT32,
  OPT_MEMSIZE
};

typedef struct {
  char *longopt;
  char shortopt;
  enum ubsa_long_opt_e type;
  int need_arg;
  void *param;
  uint64_t arg_val; // sets *(uint64_t*)param to this
  char *desc; // description, not used by getopt
} ubsa_long_options_s;

// return "-1" on successful completion, "?" on error or option not found
int ubsa_getopt_long(char *arg_string, ubsa_long_options_s *opts, int *option_idx, char **tmp_var);
void ubsa_getopt_usage(ubsa_long_options_s *opts);

uint32_t simple_strtoul(const char *cp, char **endp, unsigned int base);
int32_t simple_strtol(const char *cp, char **endp, unsigned int base);
uint64_t simple_strtoull(const char *cp, char **endp, unsigned int base);
int64_t simple_strtoll(const char *cp, char **endp, unsigned int base);
uint64_t ustrtoull(const char *cp, char **endp, unsigned int base);

char tolower(char c);
char toupper(char c);

#define islower(c) (((c) >= 'a') && ((c) <= 'z'))
#define isdigit(c) ((c) >= '0' && (c) <= '9')
#define isxdigit(c) (isdigit(c) || ((c) >= 'a' && (c) <= 'f') || ((c) >= 'A' && (c) <= 'F'))

int readline_into_buffer(const char *const prompt, char *buffer, uint32_t len);

uint64_t get_memtest_bit_errors();
uint64_t get_memtest_bit_errors_rank(uint64_t rank);
uint64_t get_memtest_bit_errors_mcu(uint64_t mcu);
uint64_t get_memtest_bit_errors_mcu_rank(int64_t mcu, int64_t rank);

typedef enum {
  LVL_RD,
  LVL_RD_RISE,
  LVL_RD_FALL,
  LVL_RD_GATE,
  LVL_WR,
  LVL_WR_DQ,
  LVL_VREF,
  LVL_INVALID
} lvl_type_e;

int32_t get_saved_rdlvl(uint64_t mcu, uint64_t rank, uint64_t byte, uint32_t x4);
int32_t get_saved_rdlvl_gate(uint64_t mcu, uint64_t rank, uint64_t byte, uint32_t x4);
int32_t get_saved_wrlvl(uint64_t mcu, uint64_t rank, uint64_t byte, uint32_t x4);
int32_t get_saved_write_dq(uint64_t mcu, uint64_t byte, uint32_t x4);
int32_t get_saved_vref(uint64_t mcu);

int32_t get_saved_rdlvl_fall(uint64_t mcu, uint64_t rank, uint64_t byte, uint64_t bit, uint32_t x4);
int32_t get_saved_rdlvl_rise(uint64_t mcu, uint64_t rank, uint64_t byte, uint64_t bit, uint32_t x4);
int32_t get_saved_write_dq_bit(uint64_t mcu, uint64_t rank, uint64_t byte, uint64_t bit, uint32_t x4);

int set_rdlvl_offset(int32_t mcu, int32_t rank, int32_t lvl);
int set_wrlvl_offset(int32_t mcu, int32_t rank, int32_t lvl);
int set_rdgate_offset(int32_t mcu, int32_t rank, int32_t lvl);
int set_wrdq_offset(int32_t mcu, int32_t rank, int32_t lvl);
int set_vref_offset(int32_t mcu, int32_t lvl);
int set_rdlvl_rise_offset(int32_t mcu, int32_t rank, int32_t lvl);
int set_rdlvl_fall_offset(int32_t mcu, int32_t rank, int32_t lvl);

typedef enum {
  DS_DATA_MASK,
  DS_DQ_DQS,
  DS_ADDR_BANK,
  DS_COMMAND,
  DS_CONTROL,
  DS_CLOCK,
  DS_INVALID
} e_drive_slew_type;

void set_phy_slew(uint32_t mcu, e_drive_slew_type type, uint32_t val);
uint32_t get_phy_slew(uint32_t mcu, e_drive_slew_type type);
void set_phy_drive_strn(uint32_t mcu, e_drive_slew_type type, uint32_t val);
uint32_t get_phy_drive_strn(uint32_t mcu, e_drive_slew_type type);

// Shmoo interface

void set_rdlvl(int64_t mcu, int64_t rank, int64_t *rdlvl);
void set_rdlvl_rise(int64_t mcu, int64_t rank, int64_t *rdlvl);
void set_rdlvl_fall(int64_t mcu, int64_t rank, int64_t *rdlvl);
void set_rdlvl_g(int64_t mcu, int64_t rank, int64_t *rdlvl);
void set_wrlvl(int64_t mcu, int64_t rank, int64_t *rdlvl);
void set_write_dq(int64_t mcu, int64_t rank, int64_t *dq);
void set_vref(int64_t mcu, int64_t *data);

void set_trim(int rdlvl, int64_t trim);

// ELF file handling

void show_elf(uint8_t *mem);

uint8_t *get_next_file(uint8_t **mem_ptr, char *name);
int check_next_dual(uint8_t *mem_ptr, uint8_t **next_mem, char *name, char *ext);

uint32_t get_mode_matrix(uint8_t *mem_ptr);


void load_elf_mem(uint8_t *mem, int skip_zero, int verbose);
int find_symbol(char *sym_name, uint64_t *sym_addr, uint8_t *mem, int verbose);
int read_symbol_elf(char *sym_name, uint8_t **data_addr, uint8_t *mem, int verbose);


uint32_t is_elf_hdr_valid(uint8_t *mem);
uint32_t is_elf32(uint8_t *mem);
uint32_t is_elf64(uint8_t *mem);
uint64_t get_elf_entrty(uint8_t *mem);


// AVP loader

typedef void (*elf_start_func)();

typedef struct {
  uint64_t x0;
  uint64_t x1;
  uint64_t x3;
  uint64_t x11;
  uint64_t x12;
} s_avp_retval;

s_avp_retval start_avp( void (*elf_start_func)(), void *saved_state, uint64_t proc );
void return_avp();

void enable_caches(void);
int dcache_status(void);
void invalidate_icache_all(void);
void flush_dcache_range(uint64_t start, uint64_t stop);
void flush_cache(uint64_t start, uint64_t size);
void invalidate_dcache_all(void);
void flush_dcache_all(void);

int can_run_avps(char *dbg_str, uint32_t str_len);

int decompress_gzip(char *argv);

// error checks

void configure_l2_errors(uint32_t __pmd_id);
void configure_l2_rtos(uint32_t __pmd_id);
void configure_lsu_errors(uint32_t __pmd_id, uint32_t __cpu_id);
void configure_icf_errors(uint32_t __pmd_id, uint32_t __cpu_id);
void configure_mmu_errors(uint32_t __pmd_id, uint32_t __cpu_id);
void configure_cpu_errors(uint32_t __pmd_id, uint32_t __cpu_id);
void configure_pmd_errors(uint32_t __pmd_id);

uint32_t check_l2_errors(uint32_t proc, uint32_t verbose);
uint32_t check_l2_rtos(uint32_t proc, uint32_t verbose);
uint32_t check_mmu_errors(uint32_t proc, uint32_t verbose);
uint32_t check_lsu_errors(uint32_t proc, uint32_t verbose);
uint32_t check_icf_errors(uint32_t proc, uint32_t verbose);

uint32_t check_cpu_errors(uint32_t proc, uint32_t verbose);
uint32_t check_pmd_errors(uint32_t proc, uint32_t verbose);

void configure_system_errors();
uint32_t check_system_errors(uint32_t verbose);

// tests

int ubsa_memtest(char *argv);
int memreg(char *command_line);
int shmoo_rdlvl(char *argv);
int find_eye(char *argv);
int sw_deskew(char *argv);
int reset_cpu(char *argv);

int run_elf(char *argv);
int run_avp_base(char *argv);

int mem_screen(char *argv);

int mem_mod(char *argv);
int mem_display(char *argv);
int check_mapping(char *argv);

int reconfig_mem_test(char *argv);



#endif



