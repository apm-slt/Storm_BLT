/* Copyright (c) 2014 by Veloce Technologies.  All Rights Reserved. */
/* $Id: //depot/projects/osboot/MAIN/ubsa/ubsa_gzip.h#1 $ */

#ifndef __UBSA_GZIP_H__
#define __UBSA_GZIP_H__

#ifndef NIL
#  define NIL ((unsigned char *)0)      /* for no output option */
#endif

int32_t puff(uint8_t *dest,           /* pointer to destination pointer */
         uint32_t *destlen,        /* amount of output space */
         const uint8_t *source,   /* pointer to source data pointer */
         uint32_t *sourcelen);      /* amount of input available */

#endif // __UBSA_GZIP_H__
