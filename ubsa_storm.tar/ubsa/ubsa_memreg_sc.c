/* Copyright (c) 2014 by Veloce Technologies.  All Rights Reserved. */
/* $Id: //depot/projects/osboot/MAIN/ubsa/ubsa_memreg_sc.c#8 $ */

#include "bbcutils.h"
#include "mcu_cdn_phy_defines.AUTO.h"

#define MAX_RANK  8
#define MAX_MCU   4
#define N_BYTES   9
#define N_BITS    8
#define N_NIBBLES 2

#define PHY_SLICE_OFFSET          (64*4)

#define  MCU_REG_BY4_MODE__ADDR                             0xa4
#define  MCU_REG_MCUGECR__ADDR                              0x110
#define  MCU_REG_RDLVLCTL__ADDR                             0x1d8
#define  MCU_REG_DDR_INIT_CTL		(0x8d << 2)
#define  MCU_REG_DDR_INIT_SEQ   	(0x8e << 2)
#define  MCU_REG_DDR_INIT_STATUS  	(0x8f << 2)
#define  MCU_REG_CTLUPDTCFG	  	(0xb6 << 2)
#define  MCU_REG_DFICSLATENCY           (0x1d2 << 2)

#define MCU_RESET_FSM_stRESTART 0x3a
#define MCU_DDR_INIT_SEQ_TXPRENAB_LSB  		9U
#define MCU_DDR_INIT_SEQ_CTLUPDATE_LSB  		1U
#define MCU_DDR_INIT_SEQ_SETMEMINITDONE_LSB  		0U
#define MCU_DDR_INIT_CTL_CALIBGO_LSB  		31U
#define MCU_DDR_INIT_CTL_RCWAIT_LSB  		8U
#define MCU_DDR_INIT_CTL_REFRESHCNT_LSB  		4U
#define MCU_DDR_INIT_SEQ_PREREFRESHENAB_LSB  		12U
#define MCU_DDR_INIT_STATUS_MEMINITDONE_MSB	0U
#define MCU_RSTSTS_CTLUPDTOVER_RNG 0x1
#define MCU_RSTSTS_TXPROVER_RNG 0x9
#define MCU_RSTSTS_PREREFRESHOVER_RNG 0xc
#define MCU_BY4_MODE_ENABLED_LSB                 0U
#define MCU_DDR_INIT_SEQ_ZQCLENAB_LSB            6U
#define DO_SW_CTLUPDATE       0x1U

int mcu_phy_sw_adj_ctrlupdate(uint32_t mcu);

typedef struct {
  // valid if these need to be restored
  uint16_t rd_rise_v;
  uint16_t rd_fall_v;
  uint16_t rd_gate_v;
  uint16_t wr_v;
  uint16_t wr_dq_v;
  uint16_t vref_v;

  uint16_t rd_rise[N_BYTES][N_BITS];
  uint16_t rd_fall[N_BYTES][N_BITS];
  uint16_t rd_gate[N_BYTES][N_NIBBLES];
  uint16_t wr[N_BYTES][N_NIBBLES];
  uint16_t wr_dq[N_BYTES][N_BITS];
  uint16_t vref[1];
} s_rank_params;

typedef struct {
  uint32_t n_ranks[MAX_MCU];
  s_rank_params *mcu[MAX_MCU];
} s_saved_state;

uint32_t g_saved_state_init = 0;
s_saved_state g_saved_state;

uint32_t phy_read(uint32_t mcu, uint32_t addr) {
  return read_rb(0x282 + mcu*4, (addr >> 2));
}

void phy_write(uint32_t mcu, uint32_t addr, uint32_t data) {
  write_rb(0x282 + mcu*4, (addr >> 2), data);
}

uint32_t mcu_read(uint32_t mcu, uint32_t addr) {
  return read_rb(0x280 + mcu*4, (addr >> 2));
}

void mcu_write(uint32_t mcu, uint32_t addr, uint32_t data) {
  write_rb(0x280 + mcu*4, (addr >> 2), data);
}

static void parse_int_list(int *val, char *arg)
{
  char *tmp, *str;
  int idx = 0;

  while ((str = ubsa_strtok(((idx==0) ? arg : NULL), ",", &tmp)) && (idx < 9)) {
    val[idx] = simple_strtol(str, NULL, 0);
    idx++;
  }
}


void set_active_rank(uint64_t chan, uint64_t rank)
{
  uint32_t d, s;
//  uint32_t regd;

  if (is_sngl_rank_lvl(chan)) {
    return;
  }

  for (s = 0; s < N_BYTES; s++) {
    uint32_t addr;

    addr = MCU_PHY_13_ADDR + (s)*PHY_SLICE_OFFSET;
    d = phy_read(chan, addr);
    d = FIELD_MCU_PHY_13_PHY_PER_CS_TRAINING_INDEX_0_SET(d, rank);
    phy_write(chan, addr, d);
  }
}

void do_phy_init()
{
  return;
/*
  int mcu, r, by;
  uint32_t d;
  for (mcu = 0; mcu < MAX_MCU; mcu++) {
    if (is_mcu_active(mcu)) {
      uint32_t nr = ubsa_num_ranks(mcu);
      for (r = 0; r < nr; r++) {
        set_active_rank(mcu, r);
        for (by = 0; by < N_BYTES; by++) {
          uint32_t addr = MCU_PHY_13_ADDR + (by)*PHY_SLICE_OFFSET;
          d = phy_read(mcu, addr);
          d = FIELD_MCU_PHY_76_PHY_PER_CS_TRAINING_EN_1_SET(d, 1);
          phy_write(mcu, addr, d);
        }
      }
      mcu_phy_sw_adj_ctrlupdate(mcu);
    }
  }
*/
}


uint32_t is_mcu_x4_en(uint32_t chan) {
  uint32_t _tmp;

  _tmp = mcu_read(chan, MCU_REG_BY4_MODE__ADDR);
  return ((_tmp & (1 << MCU_BY4_MODE_ENABLED_LSB)) != 0);
}

uint32_t is_sngl_rank_lvl(uint32_t chan) {
  uint32_t d;
  d = phy_read(chan, MCU_PHY_12_ADDR);
  d &= (FIELD_MCU_PHY_12_PHY_PER_CS_TRAINING_MULTICAST_EN_0_MASK |
        FIELD_MCU_PHY_12_PHY_PER_RANK_CS_MAP_0_MASK);
  return (d == 0x01000100);
}

// not used
void set_rdlvl(int64_t mcu, int64_t rank, int64_t *rdlvl) { }

#define MCU_PHY_RDEDGE(b, s) \
               (MCU_PHY_20_ADDR + (b)*4 + (s)*PHY_SLICE_OFFSET)

#define MCU_PHY_RDEDGE_RISE_DELAY(d) \
        (FIELD_MCU_PHY_20_PHY_RDDQS_DQ0_RISE_SLAVE_DELAY_0_RD((d)))

#define MCU_PHY_RDEDGE_RISE_DELAY_SET(o, d) \
        (FIELD_MCU_PHY_20_PHY_RDDQS_DQ0_RISE_SLAVE_DELAY_0_SET((o), (d)))

#define MCU_PHY_RDEDGE_FALL_DELAY(d) \
        (FIELD_MCU_PHY_20_PHY_RDDQS_DQ0_FALL_SLAVE_DELAY_0_RD((d)))

#define MCU_PHY_RDEDGE_FALL_DELAY_SET(o, d) \
        (FIELD_MCU_PHY_20_PHY_RDDQS_DQ0_FALL_SLAVE_DELAY_0_SET((o), (d)))

/******** RdLvl Rise *******/

void get_rdlvl_rise(uint32_t chan, uint32_t rank, uint16_t data[N_BYTES][N_BITS])
{
  int i, slice;

  set_active_rank(chan, rank);

  for (slice = 0; slice < N_BYTES; slice++) {
    for (i = 0; i < N_BITS; i++) {
      uint32_t d;
      uint32_t addr = MCU_PHY_RDEDGE(i, slice);
      d = phy_read(chan, addr);
      data[slice][i] = MCU_PHY_RDEDGE_RISE_DELAY(d);
    }
  }
}

static void write_rdlvl_rise(int64_t chan, uint32_t slice, uint32_t bit, uint32_t data)
{
  uint32_t d;
  uint32_t addr = MCU_PHY_RDEDGE(bit, slice);
  d = phy_read(chan, addr);
  d = MCU_PHY_RDEDGE_RISE_DELAY_SET(d, data);
  phy_write(chan, addr, d);
}

void set_rdlvl_rise(int64_t chan, int64_t rank, int64_t *data)
{
  int i, slice;
  int64_t c, r;

  for (c = 0; c < MAX_MCU; c++) {
    if (((chan < 0) || (chan == c)) && is_mcu_active(c)) {
      uint32_t nr = (is_sngl_rank_lvl(c) ? 1 : ubsa_num_ranks(c));
      for (r = 0; r < nr; r++) {
        if ((nr == 1) || (rank < 0) || (rank == r)) {
          set_active_rank(c, r);
          for (slice = 0; slice < N_BYTES; slice++) {
            for (i = 0; (data[slice] != -1) && (i < N_BITS); i++) {
              write_rdlvl_rise(c, slice, i, data[slice]);
            }
          }
          if (g_saved_state_init)
            g_saved_state.mcu[c][r].rd_rise_v = 1;
        }
      }
    }
  }
}

void restore_rdlvl_rise(int64_t chan, int64_t rank, s_rank_params *p)
{
  int i, slice;

  if (!p->rd_rise_v)
    return;

  set_active_rank(chan, rank);

  for (slice = 0; slice < N_BYTES; slice++) {
    for (i = 0; i < N_BITS; i++) {
      write_rdlvl_rise(chan, slice, i, p->rd_rise[slice][i]);
    }
  }
}

/******** RdLvl Fall *******/

void get_rdlvl_fall(uint32_t chan, uint32_t rank, uint16_t data[N_BYTES][N_BITS])
{
  int i, slice;

  set_active_rank(chan, rank);

  for (slice = 0; slice < N_BYTES; slice++) {
    for (i = 0; i < N_BITS; i++) {
      uint32_t d;
      uint32_t addr = MCU_PHY_RDEDGE(i, slice);
      d = phy_read(chan, addr);
      data[slice][i] = MCU_PHY_RDEDGE_FALL_DELAY(d);
    }
  }
}

static void write_rdlvl_fall(int64_t chan, uint32_t slice, uint32_t bit, uint32_t data)
{
  uint32_t d;
  uint32_t addr = MCU_PHY_RDEDGE(bit, slice);
  d = phy_read(chan, addr);
  d = MCU_PHY_RDEDGE_FALL_DELAY_SET(d, data);
  phy_write(chan, addr, d);
}

void set_rdlvl_fall(int64_t chan, int64_t rank, int64_t *data)
{
  int i, slice;
  int64_t c, r;

  for (c = 0; c < MAX_MCU; c++) {
    if (((chan < 0) || (chan == c)) && is_mcu_active(c)) {
      uint32_t nr = (is_sngl_rank_lvl(c) ? 1 : ubsa_num_ranks(c));
      for (r = 0; r < nr; r++) {
        if ((nr == 1) || (rank < 0) || (rank == r)) {
          set_active_rank(c, r);
          for (slice = 0; slice < N_BYTES; slice++) {
            for (i = 0; (data[slice] != -1) && (i < N_BITS); i++) {
              write_rdlvl_fall(c, slice, i, data[slice]);
            }
          }
          if (g_saved_state_init)
            g_saved_state.mcu[c][r].rd_fall_v = 1;
        }
      }
    }
  }
}

void restore_rdlvl_fall(int64_t chan, int64_t rank, s_rank_params *p)
{
  int i, slice;

  if (!p->rd_fall_v)
    return;

  set_active_rank(chan, rank);

  for (slice = 0; slice < N_BYTES; slice++) {
    for (i = 0; i < N_BITS; i++) {
      write_rdlvl_fall(chan, slice, i, p->rd_fall[slice][i]);
    }
  }
}

/******** RdLvl Gate *******/

#define MCU_PHY_RDGATE(s) \
  (MCU_PHY_29_ADDR + (s)*PHY_SLICE_OFFSET)

void get_rdlvl_gate(uint32_t chan, uint32_t rank, uint16_t data[N_BYTES][N_NIBBLES])
{
  int slice;

  set_active_rank(chan, rank);

  for (slice = 0; slice < N_BYTES; slice++) {
    uint32_t d, rh, rl;
    uint32_t addr;
    addr = MCU_PHY_29_ADDR + (slice * PHY_SLICE_OFFSET);
    d = phy_read(chan, addr);
    rl = FIELD_MCU_PHY_29_PHY_RDDQS_GATE_SLAVE_DELAY_0_RD(d);
    rh = FIELD_MCU_PHY_29_PHY_RDDQS_LATENCY_ADJUST_0_RD(d);
    data[slice][0] = (rh * 512) + rl;

    if (is_x4_mode()) {
       addr = MCU_PHY_57_ADDR + (slice * PHY_SLICE_OFFSET);
       d = phy_read(chan, addr);
       rl = FIELD_MCU_PHY_57_PHY_X4_RDDQS_GATE_SLAVE_DELAY_0_RD(d);
       rh = FIELD_MCU_PHY_57_PHY_X4_RDDQS_LATENCY_ADJUST_0_RD(d);
       data[slice][1] = (rh * 512) + rl;
    }
  }
}

static void write_rdlvl_gate(int64_t chan, uint32_t slice, uint32_t data, uint32_t x4)
{
  uint32_t d, rh, rl;
  uint32_t addr;
  rh = data / 512;
  rl = data % 512;
  if (x4) {
    addr = MCU_PHY_57_ADDR + (slice * PHY_SLICE_OFFSET);
    d = phy_read(chan, addr);
    d = FIELD_MCU_PHY_57_PHY_X4_RDDQS_LATENCY_ADJUST_0_SET(d, rh);
    d = FIELD_MCU_PHY_57_PHY_X4_RDDQS_GATE_SLAVE_DELAY_0_SET(d, rl);
    phy_write(chan, addr, d);
  } else {
    addr = MCU_PHY_29_ADDR + (slice * PHY_SLICE_OFFSET);
    d = phy_read(chan, addr);
    d = FIELD_MCU_PHY_29_PHY_RDDQS_LATENCY_ADJUST_0_SET(d, rh);
    d = FIELD_MCU_PHY_29_PHY_RDDQS_GATE_SLAVE_DELAY_0_SET(d, rl);
    phy_write(chan, addr, d);
  }
}

void set_rdlvl_g(int64_t chan, int64_t rank, int64_t *data)
{
  int slice;
  int64_t c, r;

  for (c = 0; c < MAX_MCU; c++) {
    if (((chan < 0) || (chan == c)) && is_mcu_active(c)) {
      uint32_t nr = (is_sngl_rank_lvl(c) ? 1 : ubsa_num_ranks(c));
      for (r = 0; r < nr; r++) {
        if ((nr == 1) || (rank < 0) || (rank == r)) {
          set_active_rank(c, r);
          for (slice = 0; slice < N_BYTES; slice++) {
            if (data[slice] != -1) {
              write_rdlvl_gate(c, slice, data[slice], 0);
              if (is_x4_mode()) {
                write_rdlvl_gate(c, slice, data[slice], 1);
              }
            }
          }
          if (g_saved_state_init)
            g_saved_state.mcu[c][r].rd_gate_v = 1;
        }
      }
    }
  }
}

void restore_rdlvl_gate(int64_t chan, int64_t rank, s_rank_params *p)
{
  int slice;

  if (!p->rd_gate_v)
    return;

  set_active_rank(chan, rank);

  for (slice = 0; slice < N_BYTES; slice++) {
    write_rdlvl_gate(chan, slice, p->rd_gate[slice][0], 0);
    if (is_x4_mode()) {
      write_rdlvl_gate(chan, slice, p->rd_gate[slice][1], 1);
    }
  }
}

/******** WrLvl  *******/

void get_wrlvl(uint32_t chan, uint32_t rank, uint16_t data[N_BYTES][N_NIBBLES])
{
  int slice;

  set_active_rank(chan, rank);

  for (slice = 0; slice < N_BYTES; slice++) {
    uint32_t d, rlat, rslv, addr;

    addr = MCU_PHY_31_ADDR + (slice * PHY_SLICE_OFFSET);
    d = phy_read(chan, addr);
    rlat = FIELD_MCU_PHY_31_PHY_WRITE_PATH_LAT_ADD_0_RD(d);

    addr = MCU_PHY_04_ADDR + (slice * PHY_SLICE_OFFSET);
    d = phy_read(chan, addr);
    rslv = FIELD_MCU_PHY_04_PHY_CLK_WRDQS_SLAVE_DELAY_0_RD(d);

    data[slice][0] = (rlat * 512) + rslv;

    if (is_x4_mode()) {
        addr = MCU_PHY_58_ADDR + (slice * PHY_SLICE_OFFSET);
        d = phy_read(chan, addr);
        rlat = FIELD_MCU_PHY_58_PHY_X4_WRITE_PATH_LAT_ADD_0_RD(d);

        addr = MCU_PHY_54_ADDR + (slice * PHY_SLICE_OFFSET);
        d = phy_read(chan, addr);
        rslv = FIELD_MCU_PHY_54_PHY_X4_CLK_WRDQS_SLAVE_DELAY_0_RD(d);

        data[slice][1] = (rlat * 512) + rslv;
    }
  }
}

static void write_wrlvl(int64_t chan, uint32_t slice, uint32_t data, uint32_t x4)
{
  uint32_t d, rlat, rslv, addr;
  rlat = data / 512;
  rslv = data % 512;

  if (x4) {
      addr = MCU_PHY_58_ADDR + (slice * PHY_SLICE_OFFSET);
      d = phy_read(chan, addr);
      d = FIELD_MCU_PHY_58_PHY_X4_WRITE_PATH_LAT_ADD_0_SET(d, rlat);
      phy_write(chan, addr, d);

      addr = MCU_PHY_54_ADDR + (slice * PHY_SLICE_OFFSET);
      d = phy_read(chan, addr);
      d = FIELD_MCU_PHY_54_PHY_X4_CLK_WRDQS_SLAVE_DELAY_0_SET(d, rslv);
      phy_write(chan, addr, d);
  } else {
      addr = MCU_PHY_31_ADDR + (slice * PHY_SLICE_OFFSET);
      d = phy_read(chan, addr);
      d = FIELD_MCU_PHY_31_PHY_WRITE_PATH_LAT_ADD_0_SET(d, rlat);
      phy_write(chan, addr, d);

      addr = MCU_PHY_04_ADDR + (slice * PHY_SLICE_OFFSET);
      d = phy_read(chan, addr);
      d = FIELD_MCU_PHY_04_PHY_CLK_WRDQS_SLAVE_DELAY_0_SET(d, rslv);
      phy_write(chan, addr, d);
  }
}

void set_wrlvl(int64_t chan, int64_t rank, int64_t *data)
{
  int slice;
  int64_t c, r;

  for (c = 0; c < MAX_MCU; c++) {
    if (((chan < 0) || (chan == c)) && is_mcu_active(c)) {
      uint32_t nr = (is_sngl_rank_lvl(c) ? 1 : ubsa_num_ranks(c));
      for (r = 0; r < nr; r++) {
        if ((nr == 1) || (rank < 0) || (rank == r)) {
          set_active_rank(c, r);
          for (slice = 0; slice < N_BYTES; slice++) {
            if (data[slice] != -1) {
              write_wrlvl(c, slice, data[slice], 0);
              if (is_x4_mode()) {
                  write_wrlvl(c, slice, data[slice], 1);
              }
            }
          }
          if (g_saved_state_init)
            g_saved_state.mcu[c][r].wr_v = 1;
        }
      }
    }
  }
}

void restore_wrlvl(int64_t chan, int64_t rank, s_rank_params *p)
{
  int slice;

  if (!p->wr_v)
    return;

  set_active_rank(chan, rank);

  for (slice = 0; slice < N_BYTES; slice++) {
    write_wrlvl(chan, slice, p->wr[slice][0], 0);
    if (is_x4_mode()) {
        write_wrlvl(chan, slice, p->wr[slice][1], 1);
    }
  }
}

/******** WrLvl DQ/DQS *******/

#define MCU_PHY_WRDQ(b, s) \
  (MCU_PHY_00_ADDR + (b >> 1)*4 + (s)*PHY_SLICE_OFFSET)

void get_write_dq(uint32_t chan, uint32_t rank, uint16_t data[N_BYTES][N_BITS])
{
  int i, slice;

  set_active_rank(chan, rank);

  for (slice = 0; slice < N_BYTES; slice++) {
    for (i = 0; i < N_BITS/2; i++) {
      uint32_t d;
      uint32_t addr = MCU_PHY_WRDQ(i*2, slice);
      d = phy_read(chan, addr);
      data[slice][(i*2)]   = FIELD_MCU_PHY_00_PHY_CLK_WRDQ0_SLAVE_DELAY_0_RD(d);
      data[slice][(i*2)+1] = FIELD_MCU_PHY_00_PHY_CLK_WRDQ1_SLAVE_DELAY_0_RD(d);
    }
  }
}

static void write_write_dq(int64_t chan, uint32_t slice, uint32_t bit2, uint32_t data0, uint32_t data1)
{
  uint32_t d;
  uint32_t addr = MCU_PHY_WRDQ(bit2*2, slice);
  d = phy_read(chan, addr);
  d = FIELD_MCU_PHY_00_PHY_CLK_WRDQ0_SLAVE_DELAY_0_SET(d, data0);
  d = FIELD_MCU_PHY_00_PHY_CLK_WRDQ1_SLAVE_DELAY_0_SET(d, data1);
  phy_write(chan, addr, d);
}

void set_write_dq(int64_t chan, int64_t rank, int64_t *data)
{
  int i, slice;
  int64_t c, r;

  for (c = 0; c < MAX_MCU; c++) {
    if (((chan < 0) || (chan == c)) && is_mcu_active(c)) {
      uint32_t nr = (is_sngl_rank_lvl(c) ? 1 : ubsa_num_ranks(c));
      for (r = 0; r < nr; r++) {
        if ((nr == 1) || (rank < 0) || (rank == r)) {
          set_active_rank(c, r);
          for (slice = 0; slice < N_BYTES; slice++) {
            for (i = 0; (data[slice] != -1) && (i < N_BITS/2); i++) {
              write_write_dq(c, slice, i, data[slice], data[slice]);
            }
          }
          if (g_saved_state_init)
            g_saved_state.mcu[c][r].wr_dq_v = 1;
        }
      }
    }
  }
}

void restore_write_dq(int64_t chan, int64_t rank, s_rank_params *p)
{
  int i, slice;

  if (!p->wr_dq_v)
    return;

  set_active_rank(chan, rank);

  for (slice = 0; slice < N_BYTES; slice++) {
    for (i = 0; i < N_BITS/2; i++) {
      write_write_dq(chan, slice, i, p->wr_dq[slice][(i*2)], p->wr_dq[slice][(i*2)+1]);
    }
  }
}

/******** Vref  *******/

void get_vref(uint32_t chan, uint16_t data[1])
{
    uint32_t d = 0;

    d = phy_read(chan, MCU_PHY_604_ADDR);
    data[0] = FIELD_MCU_PHY_604_PHY_PAD_VREF_CTRL_RD(d);
}

static void write_vref(int64_t chan, uint32_t data)
{
  uint32_t d;

  d = phy_read(chan, MCU_PHY_604_ADDR);
  d = FIELD_MCU_PHY_604_PHY_PAD_VREF_CTRL_SET(d, data);
  phy_write(chan, MCU_PHY_604_ADDR, d);
}

void set_vref(int64_t chan, int64_t *data)
{
  int64_t c;

  for (c = 0; c < MAX_MCU; c++) {
    if (((chan < 0) || (chan == c)) && is_mcu_active(c)) {
      /* checking ECC byte (byte[8]) */
      if (data[0] == -1) {
        write_vref(c, data[8]);
      } else {
        write_vref(c, data[0]);
      }
          if (g_saved_state_init)
            g_saved_state.mcu[c][0].vref_v = 1;
    }
  }
}

void restore_vref(int64_t chan, s_rank_params *p)
{
  if (!p->vref_v)
    return;
  write_vref(chan, p->vref[0]);
}

/*****************************************************************************/

int set_rdlvl_offset(int32_t mcu, int32_t rank, int32_t lvl) { return 0; }

int set_rdlvl_rise_offset(int32_t mcu, int32_t rank, int32_t lvl)
{
  int m, r, slice, b, x;
  int32_t v;
  uint32_t data, nr;
  int all_zero = 1;

  for (m = 0; m < MAX_MCU; m++) {
    if (((mcu >= 0) && (mcu != m)) || !is_mcu_active(m))
      continue;

    nr = (is_sngl_rank_lvl(m) ? 1 : ubsa_num_ranks(m));
    for (r = 0; r < nr; r++) {
      if ((nr == 1) || (get_rank_intlv(m, r) == rank)) {
        set_active_rank(m, r);
        if (g_saved_state_init)
          g_saved_state.mcu[m][r].rd_rise_v = 1;

        for (x = 0; x <= is_x4_mode(); x++) {
          for (slice = 0; slice < N_BYTES; slice++) {
            for (b = 0; b < N_BITS; b++) {
              v = get_saved_rdlvl_rise(m, r, slice, b, x);
              if ((v + lvl) < 0) {
                data = 0;
              } else {
                data = (v + lvl);
                all_zero = 0;
              }
              write_rdlvl_rise(m, slice, b, data);
            }
          }
        }
      }
    }
  }
  return (!all_zero);
}

int set_rdlvl_fall_offset(int32_t mcu, int32_t rank, int32_t lvl)
{
  int m, r, slice, b, x;
  int32_t v;
  uint32_t data, nr;
  int all_zero = 1;

  for (m = 0; m < MAX_MCU; m++) {
    if (((mcu >= 0) && (mcu != m)) || !is_mcu_active(m))
      continue;

    nr = (is_sngl_rank_lvl(m) ? 1 : ubsa_num_ranks(m));
    for (r = 0; r < nr; r++) {
      if ((nr == 1) || (get_rank_intlv(m, r) == rank)) {
        set_active_rank(m, r);
        if (g_saved_state_init)
          g_saved_state.mcu[m][r].rd_fall_v = 1;

        for (x = 0; x <= is_x4_mode(); x++) {
          for (slice = 0; slice < N_BYTES; slice++) {
            for (b = 0; b < N_BITS; b++) {
              v = get_saved_rdlvl_fall(m, r, slice, b, x);
              if ((v + lvl) < 0) {
                data = 0;
              } else {
                data = (v + lvl);
                all_zero = 0;
              }
              write_rdlvl_fall(m, slice, b, data);
            }
          }
        }
      }
    }
  }
  return (!all_zero);
}

int set_wrlvl_offset(int32_t mcu, int32_t rank, int32_t lvl)
{
  int m, r, b, x;
  int32_t v;
  uint32_t data, nr;
  int all_zero = 1;

  for (m = 0; m < MAX_MCU; m++) {
    if (((mcu >= 0) && (mcu != m)) || !is_mcu_active(m))
      continue;

    nr = (is_sngl_rank_lvl(m) ? 1 : ubsa_num_ranks(m));
    for (r = 0; r < nr; r++) {
      if ((nr == 1) || (get_rank_intlv(m, r) == rank)) {
        set_active_rank(m, r);
        if (g_saved_state_init)
          g_saved_state.mcu[m][r].wr_v = 1;

        for (x = 0; x <= is_x4_mode(); x++) {
          for (b = 0; b < N_BYTES; b++) {
            v = get_saved_wrlvl(m, r, b, x);
            if ((v + lvl) < 0) {
              data = 0;
            } else {
              data = (v + lvl);
              all_zero = 0;
            }
            write_wrlvl(m, b, data, x);
          }
        }
      }
    }
  }
  return (!all_zero);
}

int set_rdgate_offset(int32_t mcu, int32_t rank, int32_t lvl)
{
  int m, r, b, x;
  int32_t v;
  uint32_t data, nr;
  int all_zero = 1;

  for (m = 0; m < MAX_MCU; m++) {
    int e;
    if (((mcu >= 0) && (mcu != m)) || !is_mcu_active(m))
      continue;

    nr = (is_sngl_rank_lvl(m) ? 1 : ubsa_num_ranks(m));
    for (r = 0; r < nr; r++) {
      if ((nr == 1) || (get_rank_intlv(m, r) == rank)) {
        set_active_rank(m, r);
        if (g_saved_state_init)
          g_saved_state.mcu[m][r].rd_gate_v = 1;

        for (x = 0; x <= is_x4_mode(); x++) {
          for (b = 0; b < N_BYTES; b++) {
            v = get_saved_rdlvl_gate(m, r, b, x);
            if ((v + lvl) < 0) {
              data = 0;
            } else {
              data = (v + lvl);
              all_zero = 0;
            }
            write_rdlvl_gate(m, b, data, x);
          }
        }


        e = mcu_phy_sw_adj_ctrlupdate(m);
        if (e) {
          X__printf("PHY SW ADJ CTRL UPDATE ERROR: mcu %d : 0x%x\n", m, e);
        }

      }
    }
  }
  return (!all_zero);
}

int set_wrdq_offset(int32_t mcu, int32_t rank, int32_t lvl)
{
  int m, r, slice, b, x;
  int32_t v;
  uint32_t nr, data[2];
  int all_zero = 1;

  for (m = 0; m < MAX_MCU; m++) {
    if (((mcu >= 0) && (mcu != m)) || !is_mcu_active(m))
      continue;

    nr = (is_sngl_rank_lvl(m) ? 1 : ubsa_num_ranks(m));
    for (r = 0; r < nr; r++) {
      if ((nr == 1) || (get_rank_intlv(m, r) == rank)) {
        set_active_rank(m, r);
        if (g_saved_state_init)
          g_saved_state.mcu[m][r].wr_dq_v = 1;

        for (x = 0; x <= is_x4_mode(); x++) {
          for (slice = 0; slice < N_BYTES; slice++) {
            for (b = 0; b < N_BITS; b++) {
              v = get_saved_write_dq_bit(m, r, slice, b, x);
              if ((v + lvl) < 0) {
                data[b&1] = 0;
              } else {
                data[b&1] = (v + lvl);
                all_zero = 0;
              }
              if ((b & 1) == 1)
                write_write_dq(m, slice, b>>1, data[0], data[1]);
            }
          }
        }
      }
    }
  }
  return (!all_zero);
}

int set_vref_offset(int32_t mcu, int32_t lvl)
{
  int m;
  uint32_t v;

  for (m = 0; m < MAX_MCU; m++) {
    if (((mcu >= 0) && (mcu != m)) || !is_mcu_active(m))
      continue;

    if (g_saved_state_init)
      g_saved_state.mcu[m][0].vref_v = 1;

    v = get_saved_vref(m);
    write_vref(m, v+lvl);
  }
  return (0);
}

/*****************************************************************************/
#define DELAY(i) { \
  int __delay_c; \
  for (__delay_c = 0; __delay_c < i*100; __delay_c++) { \
    asm volatile ("dsb sy"); \
    asm volatile ("isb"); \
  } \
}


// Enums for polling
#define POLL_GREATER    2
#define POLL_LESS       1
#define POLL_EQUAL      0


int mcu_reset_status_poll(uint32_t mcu, uint32_t status, uint32_t mask, uint32_t flag)
{
  // Same as SV code: rb_mcu_request_seq_base.svh:: task mcu_CSR_reset_status_poll
  // POLL MCU Reset status (RO) csr for FSM state , errors mem_init_done etc
  uint32_t done, rddata;

  done = 0;
  do {
    rddata = mcu_read(mcu, MCU_REG_DDR_INIT_STATUS);

    if (flag == POLL_EQUAL) {
      if ((rddata & mask) == (status & mask))
        done = 1;
      else
        DELAY(1);
    } else if (flag == POLL_LESS) {
      if ((rddata & mask) <= (status & mask))
        done = 1;
      else
        DELAY(1);
    } else if (flag == POLL_GREATER) {
      if ((rddata & mask) >= (status & mask))
        done = 1;
      else
        DELAY(1);
    }
  } while (done == 0);

  return rddata;
}

void mcu_reset_FSM_poll(uint32_t mcu, uint32_t status, uint32_t flag)
{
  uint32_t mask;

  status = (status & 0x7F) << 24;
  mask = 0x7F000000;
  mcu_reset_status_poll(mcu, status, mask, flag);
}

int mcu_phy_sw_adj_ctrlupdate(uint32_t mcu)
{
  uint32_t fsm_init_seq = 0;
  uint32_t fsm_init_ctl = 0;
  uint32_t rddata = 0;
  uint32_t txpren;
  uint32_t err = 0;
  uint32_t ctlupdtcfg = 0;

  if (!is_mcu_active(mcu)) {
    return 0;
  }

  /*
   * Setup initialization control
   */
  /* Disable periodic DFI Control Update Requests to PHY */
  ctlupdtcfg = mcu_read(mcu, MCU_REG_CTLUPDTCFG);
  ctlupdtcfg &= ~(0x1U);
  mcu_write(mcu, MCU_REG_CTLUPDTCFG, ctlupdtcfg);

  mcu_reset_FSM_poll(mcu, MCU_RESET_FSM_stRESTART, POLL_EQUAL);
  // Write FSM delay values - should be done is csr config
  rddata = mcu_read(mcu, MCU_REG_DDR_INIT_STATUS);
  txpren = (rddata >> MCU_RSTSTS_TXPROVER_RNG) & 0x1U;
  txpren = (~txpren) & 0x1U;
  rddata = (rddata >> MCU_DDR_INIT_SEQ_SETMEMINITDONE_LSB) & 0x1U;

  /* if traffic, then use REF to clear Ops b4 CtrlUp */
  fsm_init_seq = 
    (txpren << MCU_DDR_INIT_SEQ_TXPRENAB_LSB) |
    (1U << MCU_DDR_INIT_SEQ_CTLUPDATE_LSB) |
    (rddata << MCU_DDR_INIT_SEQ_SETMEMINITDONE_LSB);
  /* Preserve mem_init_done (traffic) */
  fsm_init_ctl =
      (0x1U << MCU_DDR_INIT_CTL_CALIBGO_LSB) |
      ((0x4U & 0xFU) << MCU_DDR_INIT_CTL_RCWAIT_LSB) |
      ((0x1U & 0x7U) << MCU_DDR_INIT_CTL_REFRESHCNT_LSB);

  mcu_write(mcu, MCU_REG_DDR_INIT_SEQ, fsm_init_seq);
  mcu_write(mcu, MCU_REG_DDR_INIT_CTL, fsm_init_ctl);
  /* Kick off FSM - initializing */
  DELAY(10);
  rddata =
      //(rddata  << MCU_RSTSTS_PREREFRESHOVER_RNG) |
      (txpren << MCU_RSTSTS_TXPROVER_RNG) |
      (1U << MCU_RSTSTS_CTLUPDTOVER_RNG) |
      (rddata << MCU_DDR_INIT_STATUS_MEMINITDONE_MSB);
  mcu_reset_status_poll(mcu, rddata, rddata, POLL_EQUAL);
  DELAY(10);
  mcu_reset_FSM_poll(mcu, MCU_RESET_FSM_stRESTART, POLL_EQUAL);

  /* Re-enable Periodic DFI Control Update Requests to PHY */
  ctlupdtcfg |= 0x1U;
  mcu_write(mcu, MCU_REG_CTLUPDTCFG, ctlupdtcfg);
  return err;
}        /* mcu_phy_sw_adj_ctrlupdate */


/*****************************************************************************/

// Register 60: MCUGECR (MCU Global Error Control Register )
// bit 7 R/W ECCErrEn 1’h0 1 ==> Enable recognition, handling, and logging ECC errors

void wr_mcu_err_ctl(u32 chan, u32 data) {
  mcu_write(chan, MCU_REG_MCUGECR__ADDR, data);
}

u32 rd_mcu_err_ctl(u32 chan) {
  u32 _tmp;
  _tmp = mcu_read(chan, MCU_REG_MCUGECR__ADDR);
  return _tmp;
}

uint32_t is_ecc_on(uint32_t mcu) {
  uint32_t d = rd_mcu_err_ctl(mcu);
  return ((d & 0x0080) != 0);
}

void mcu_phy_rdfifo_reset(u32 chan)
{
  // RDLVLCTL 0x76
  // bit[8] RdFifo_Reset
  u32 _tmp;

  asm volatile ("dsb sy");
  asm volatile ("isb");

  _tmp = mcu_read(chan, MCU_REG_RDLVLCTL__ADDR);

  _tmp |= 0x100;
  mcu_write(chan, MCU_REG_RDLVLCTL__ADDR, _tmp);

  _tmp &= ~0x100;
  mcu_write(chan, MCU_REG_RDLVLCTL__ADDR, _tmp);
  DELAY(10);
}

void mcu_phy_rdfifo_reset_all()
{
  u32 mcu;
  for (mcu = 0; mcu < 4; mcu++) {
    if (is_mcu_active(mcu)) {
      mcu_phy_rdfifo_reset(mcu);
    }
  }
}


/*****************************************************************************/


// Register 165: MCUESRR0 (Rank0 MCU Error Status Register )
// 0 COW CErr 1’h0 1 ==> Threshold of correctable Errors occurred during a requested operation

#define MCU_Error_Status_Register(rank) (0xc5 + (rank)*0x10) << 2

void wr_mcu_err_status(uint32_t chan, uint32_t rank, uint32_t data) {
  mcu_write(chan, MCU_Error_Status_Register(rank), data);
}

uint32_t rd_mcu_err_status(uint32_t chan, uint32_t rank) {
  uint32_t _tmp;
  _tmp = mcu_read(chan, MCU_Error_Status_Register(rank));
  return _tmp;
}

// Register 169: MCUSBECNT0 (MCU Rank0 Single Bit Error Count Register )
// 15:0 R/W Count -14’h0 Correctable Error count

#define MCU_SBE_Count_Register(rank) (0xc9 + (rank)*0x10) <<  2

void wr_mcu_sbe_count(uint32_t chan, uint32_t rank, uint32_t data) {
  mcu_write(chan, MCU_SBE_Count_Register(rank), data);
}

uint32_t rd_mcu_sbe_count(uint32_t chan, uint32_t rank) {
  uint32_t _tmp;
  _tmp = mcu_read(chan, MCU_SBE_Count_Register(rank));
  return _tmp;
}


/*****************************************************************************/

static void usage(ubsa_long_options_s *opts)
{
  X__printf("Usage:\n");
  ubsa_getopt_usage(opts);
}

void print_memcfg(void)
{
  int mcu, rank, mcb;
  int num_mcu, num_mcb;
  u32 data;

  u32 cswcr = get_csw_config_reg();

  X__printf("cswcr = %x\n", cswcr);
  X__printf("csw['dual_mcb']    = %d\n", cswcr & 1);
  X__printf("csw['mcb_intrlv']  = %d\n", (cswcr >> 1) & 1);
  X__printf("csw['addr_mode']   = %d\n", (cswcr >> 2) ^ 1); // 1 -> 42bit

  num_mcb = 1 + (cswcr & 1);

  for (mcb = 0; mcb < num_mcb; mcb++) {
    // initialize the mcb_config
    data = get_mcb_addr_config(mcb);
//    X__printf("mcb_cfg[%d] = {}\n");
    X__printf("mcb_cfg[%d]['dual_mcb'] = %d\n", mcb, 1);
    X__printf("mcb_cfg[%d]['mcb_intrlv'] = %d\n", mcb, (data >> 1) & 1);
    X__printf("mcb_cfg[%d]['dual_mcu'] = %d\n", mcb, (data >> 2) & 1);
    X__printf("mcb_cfg[%d]['mcu_intrlv'] = %d\n", mcb, (data >> 3) & 1);
    X__printf("mcb_cfg[%d]['addr_mode'] = %d\n", mcb, data & 1); // 1 -> 32bit

    num_mcu = 1 + ((data >> 2) & 1);

    for (mcu = 2*mcb; mcu < ((2*mcb)+num_mcu); mcu++) {
  //    X__printf("mcu_cfg[%d] = {}\n", mcu);
      for (rank = 0; rank < 4; rank++) {
        u32 size = get_mcu_rank_size(mcu, rank);
        u32 cfg = get_mcu_rank_config(mcu, rank);
        u32 base = get_mcu_rank_base(mcu, rank);
        u32 mask = get_mcu_rank_mask(mcu, rank);

        X__printf("mcu_cfg[%d]['rank%d_cfg'] = %d\n", mcu, rank, cfg);
        X__printf("mcu_cfg[%d]['rank%d_size'] = %d\n", mcu, rank, size);
        X__printf("mcu_cfg[%d]['rank%d_base'] = 0x%x\n", mcu, rank, base & 0x3FFF);
        X__printf("mcu_cfg[%d]['rank%d_base_lower'] = 0x%x\n", mcu, rank, (base >> 16) & 7);
        X__printf("mcu_cfg[%d]['rank%d_mask'] = 0x%x\n", mcu, rank, mask & 0x3FFF);
        X__printf("mcu_cfg[%d]['rank%d_mask_lower'] = 0x%x\n", mcu, rank, (mask >> 16) & 7);
        X__printf("mcu_cfg[%d] rank%d interleave = %d\n", mcu, rank, get_rank_intlv(mcu, rank));
      }
    }
  }
}

void print_mem_rank_config(void)
{
  int m, r;
  char *sz_str = "";

  for (m = 0; m < 4; m++) {
    if (is_mcu_active(m)) {
      for (r = 0; r < 8; r++) {
        u32 size = get_mcu_rank_size(m, r);
        u32 cfg = get_mcu_rank_config(m, r);
        u32 base = get_mcu_rank_base(m, r);
        u32 mask = get_mcu_rank_mask(m, r);
        u64 b64, m64;

        if (size == 7)
          continue;

        switch (size) {
          case 0: // 512 MB
            sz_str = "512 MB: 64M x 16";
            break;
          case 1: // 1 GB
            sz_str = "1 GB: 128M x 8, 128M x 16";
            break;
          case 2: // 2 GB
            if (cfg) {
              sz_str = "2 GB: 256M x 8, 256M x 16";
            } else {
              sz_str = "2 GB: 256M x 4";
            }
            break;
          case 3: // 4 GB
            if (cfg) {
              sz_str = "4 GB: 512M x 8, 512M x 16";
            } else {
              sz_str = "4 GB: 512M x 4";
            }
            break;
          case 4: // 8 GB
            sz_str = "8 GB: 1G x 4, 1G x 8";
            break;
          case 5: // 16 GB
            sz_str = "16 GB: 2G x 4";
            break;
        }
        b64 = (((u64)(base & 0x3FFF) << 28) | ((u64)(base & 0x70000) >> 10)) << 8;
        m64 = (((u64)(mask & 0x3FFF) << 28) | ((u64)(mask & 0x70000) >> 10)) << 8;
        X__printf("MCU%d Rank%d : 0x%012x 0x%012x (%s) (%08x,%08x)\n", m, r, b64, m64, sz_str, base, mask);
  /*
  Rank Base
  0x308
  [18:16] = ReqAddr[8:6]
  [13:0] = ReqAddr[41:28]

  Rank Mask
  0x30c
  [18:16] = ReqAddr[8:6]
  [13:0] = ReqAddr[41:28]
  */
      }
    }
  }
}

void print_rdlvl_rise()
{
  int i, r;
  uint16_t data[N_BYTES][N_BITS];

  X__printf("\n******************* Rd LVL Rise ******************\n");
  for (i = 0; i < MAX_MCU; i++) {
    if (is_mcu_active(i)) {
      uint32_t nr = (is_sngl_rank_lvl(i) ? 1 : ubsa_num_ranks(i));
      for (r = 0; r < nr; r++) {
        int bt, by;
        X__printf("MCU%d Rank %d\n", i, r);
        get_rdlvl_rise(i, r, data);
        for (by = 0; by < N_BYTES; by++) {
          X__printf("byte%d ", by);
          for (bt = 0; bt < N_BITS; bt++) {
            X__printf("%4x", data[by][bt]);
          }
          X__printf("\n");
        }
        X__printf("\n");
      }
    }
  }
}

void print_rdlvl_fall()
{
  int i, r;
  uint16_t data[N_BYTES][N_BITS];

  X__printf("\n******************* Rd LVL Fall ******************\n");
  for (i = 0; i < MAX_MCU; i++) {
    if (is_mcu_active(i)) {
      uint32_t nr = (is_sngl_rank_lvl(i) ? 1 : ubsa_num_ranks(i));
      for (r = 0; r < nr; r++) {
        int bt, by;
        X__printf("MCU%d Rank %d\n", i, r);
        get_rdlvl_fall(i, r, data);
        for (by = 0; by < N_BYTES; by++) {
          X__printf("byte%d ", by);
          for (bt = 0; bt < N_BITS; bt++) {
            X__printf("%4x", data[by][bt]);
          }
          X__printf("\n");
        }
        X__printf("\n");
      }
    }
  }
}

void print_write_dq()
{
  int i, r;
  uint16_t data[N_BYTES][N_BITS];

  X__printf("\n******************* Wr DQ/DQS ***********************\n");
  for (i = 0; i < MAX_MCU; i++) {
    if (is_mcu_active(i)) {
      uint32_t nr = (is_sngl_rank_lvl(i) ? 1 : ubsa_num_ranks(i));
      for (r = 0; r < nr; r++) {
        int bt, by;
        X__printf("MCU%d Rank %d\n", i, r);
        get_write_dq(i, r, data);
        for (by = 0; by < N_BYTES; by++) {
          X__printf("byte%d ", by);
          for (bt = 0; bt < N_BITS; bt++) {
            X__printf("%4x", data[by][bt]);
          }
          X__printf("\n");
        }
        X__printf("\n");
      }
    }
  }
}

void print_rdlvl_gate()
{
  int i, r, b;
  uint16_t data[N_BYTES][N_NIBBLES];

  X__printf("\n******************* Rd Gate **********************\n");
  for (i = 0; i < MAX_MCU; i++) {
    if (is_mcu_active(i)) {
      uint32_t nr = (is_sngl_rank_lvl(i) ? 1 : ubsa_num_ranks(i));
      X__printf("MCU%d   ", i);
      for (b = 0; b < N_BYTES; b++) {
        X__printf("b%d   ", b);
      }
      X__printf("\n");
      for (r = 0; r < nr; r++) {
        get_rdlvl_gate(i, r, data);
        X__printf("rank%d", r);
        for (b = 0; b < N_BYTES; b++) {
          X__printf(" %4x", data[b][0]);
          if (is_x4_mode()) {
            X__printf(" %4x", data[b][1]);
          }
        }
        X__printf("\n");
      }
      X__printf("\n");
    }
  }
}

void print_wrlvl()
{
  int i, r, b;
  uint16_t data[N_BYTES][N_NIBBLES];

  X__printf("\n******************* Wr LVL ***********************\n");
  for (i = 0; i < MAX_MCU; i++) {
    if (is_mcu_active(i)) {
      uint32_t nr = (is_sngl_rank_lvl(i) ? 1 : ubsa_num_ranks(i));
      X__printf("MCU%d   ", i);
      for (b = 0; b < N_BYTES; b++) {
        X__printf("b%d   ", b);
      }
      X__printf("\n");
      for (r = 0; r < nr; r++) {
        get_wrlvl(i, r, data);
        X__printf("rank%d", r);
        for (b = 0; b < N_BYTES; b++) {
          X__printf(" %4x", data[b][0]);
          if (is_x4_mode()) {
            X__printf(" %4x", data[b][1]);
          }
        }
        X__printf("\n");
      }
      X__printf("\n");
    }
  }
}

void print_vref()
{
  int i;
  uint16_t data[1];

  X__printf("\n******************* Vref ***********************\n");
  for (i = 0; i < MAX_MCU; i++) {
    if (is_mcu_active(i)) {
      X__printf("MCU%d   ", i);
      get_vref(i, data);
      X__printf(" %4x", data[0]);
      X__printf("\n");
    }
  }
}

typedef struct {
  char *str;
  void (*func)(void);
} s_print_funcs;

static s_print_funcs print_funcs[] = {
  { "memcfg", print_memcfg },
  { "rank", print_mem_rank_config },
  { "rdlvl_rise", print_rdlvl_rise },
  { "rdlvl_fall", print_rdlvl_fall },
  { "write_dq", print_write_dq },
  { "rdlvl_gate", print_rdlvl_gate },
  { "wrlvl", print_wrlvl },
  { "vref", print_vref},
  { NULL, NULL }
};

void do_print(char *prt)
{
  int i;
  for (i = 0; prt[i] != 0; i++) {
    prt[i] = tolower(prt[i]);
  }
  if (strcmp(prt, "all") == 0) {
    for (i = 0; print_funcs[i].str != NULL; i++) {
      print_funcs[i].func();
    }
    return;
  }

  for (i = 0; print_funcs[i].str != NULL; i++) {
    if (strcmp(prt, print_funcs[i].str) == 0) {
      print_funcs[i].func();
      return;
    }
  }

  X__printf("Invalid print type: ");
  for (i = 0; print_funcs[i].str != NULL; i++) {
    X__printf("%s ", print_funcs[i].str);
  }
  X__printf("\n");
}

// can only save and restore one type at a time
void do_save(lvl_type_e type, uint32_t x4)
{
  int i, r;

  if (!g_saved_state_init) {
    g_saved_state_init = 1;
    for (i = 0; i < MAX_MCU; i++) {
      if (is_mcu_active(i)) {
        uint32_t nr = (is_sngl_rank_lvl(i) ? 1 : ubsa_num_ranks(i));
        g_saved_state.n_ranks[i] = nr;
        g_saved_state.mcu[i] = ubsa_malloc(nr * sizeof(s_rank_params));
        // TODO: check malloc return
        for (r = 0; r < nr; r++) {
          g_saved_state.mcu[i][r].rd_rise_v = 1;
          g_saved_state.mcu[i][r].rd_fall_v = 1;
          g_saved_state.mcu[i][r].rd_gate_v = 1;
          g_saved_state.mcu[i][r].wr_v = 1;
          g_saved_state.mcu[i][r].wr_dq_v = 1;
          g_saved_state.mcu[i][r].vref_v = 1;
        }
      } else {
        g_saved_state.n_ranks[i] = 0;
        g_saved_state.mcu[i] = NULL;
      }
    }
  }

  for (i = 0; i < MAX_MCU; i++) {
    if (is_mcu_active(i)) {
      for (r = 0; r < g_saved_state.n_ranks[i]; r++) {
        get_rdlvl_rise(i, r, g_saved_state.mcu[i][r].rd_rise);
        get_rdlvl_fall(i, r, g_saved_state.mcu[i][r].rd_fall);
        get_write_dq(i, r, g_saved_state.mcu[i][r].wr_dq);
        get_rdlvl_gate(i, r, g_saved_state.mcu[i][r].rd_gate);
        get_wrlvl(i, r, g_saved_state.mcu[i][r].wr);
        get_vref(i, g_saved_state.mcu[i][r].vref);
      }
    }
  }
}

void do_restore(lvl_type_e type, uint32_t x4)
{
  int i, r;

  if (!g_saved_state_init) {
    return;
  }

  for (i = 0; i < MAX_MCU; i++) {
    if (is_mcu_active(i)) {
      for (r = 0; r < g_saved_state.n_ranks[i]; r++) {
        restore_rdlvl_rise(i, r, &(g_saved_state.mcu[i][r]));
        restore_rdlvl_fall(i, r, &(g_saved_state.mcu[i][r]));
        restore_write_dq(i, r, &(g_saved_state.mcu[i][r]));
        restore_rdlvl_gate(i, r, &(g_saved_state.mcu[i][r]));
        restore_wrlvl(i, r, &(g_saved_state.mcu[i][r]));
        restore_vref(i, &(g_saved_state.mcu[i][r]));
      }
      mcu_phy_sw_adj_ctrlupdate(i);
    }
  }
}

int memreg(char *argv)
{
  static int32_t lvl_mcu;
  static int32_t x4_nib;
  static int32_t print_regs;
  static int32_t save_regs;
  static int32_t restore_regs;
  static int32_t ecc_en;
  static int32_t do_help;
  static char *tmp_str;

  int x,y;
  int no_mcu_ok;
  lvl_type_e lvl_type;
  int lvl[4][9];
  int write_dq[9];
  int set_write_dq_;

  // option parsing vars
  char cmd[256];
  int c;
  int first;
  int option_idx;
  char *tmp_var;

  static ubsa_long_options_s opts[] = {
    {"mcu",               'm', OPT_INT32,   1, &lvl_mcu,      0, "Selected MCU"},
    {"lvl",               'Y', OPT_STRING,  1, &tmp_str,      0, "LVL Type: ('rd') 'wr' 'rd_gate'"},
    {"lvl_rank0",         'A', OPT_STRING,  1, &tmp_str,      0, "Rank 0 Lvl (x9, '-1' preserves that field)"},
    {"lvl_rank1",         'B', OPT_STRING,  1, &tmp_str,      0, "Rank 1 Lvl (x9, '-1' preserves that field)"},
    {"lvl_rank2",         'C', OPT_STRING,  1, &tmp_str,      0, "Rank 2 Lvl (x9, '-1' preserves that field)"},
    {"lvl_rank3",         'D', OPT_STRING,  1, &tmp_str,      0, "Rank 3 Lvl (x9, '-1' preserves that field)"},
    {"x4_nib",            'N', OPT_INT32,   1, &x4_nib,       0, "Nibble in X4 mode (1 = high, 0 = low, -1 = set both)"},
    {"write_dq",          'Q', OPT_STRING,  1, &tmp_str,      0, "Set Write DQ (x9, '-1' preserves that field)"},
    {"ecc_en",            'e', OPT_INT32,   1, &ecc_en,       0, "Set ECC Enable"},
    {"save",              's', OPT_INT32,   0, &save_regs,    1, "Save Register State"},
    {"restore",           'r', OPT_INT32,   0, &restore_regs, 1, "Restore Register State"},
    {"print",             'p', OPT_STRING,  1, &tmp_str,      0, "Dump Register State: all, rdlvl, memcfg"},
    {"help",              'h', OPT_INT32,   0, &do_help,      1, "Print Help"},
    // TODO: Seed
    { NULL, 0, 0, 0, 0, 0, 0 }
  };

  ecc_en = -1;
  do_help = 0;
  print_regs = 0;
  save_regs = 0;
  restore_regs = 0;
  option_idx = 0;
  lvl_mcu = -1;
  lvl_type = LVL_RD;
  no_mcu_ok = 0;
  set_write_dq_ = 0;
  x4_nib = -1;

//  X__printf("\nMEMREG: '%s'\n", argv);

  if (strlen(argv) >= 256) {
    X__printf("Command too long: %d\n", strlen(argv));
    X__printf("'%s'\n", argv);
    usage(opts);
    return (-1);
  }
  strcpy(cmd, argv);

  for (y = 0; y < 9; y++) {
    for (x = 0; x < 4; x++) {
      lvl[x][y] = -1;
    }
    write_dq[y] = -1;
  }

  first = 1;
  while (1) {
    c = ubsa_getopt_long((first ? cmd : NULL), opts, &option_idx, &tmp_var);
    first = 0;
    if (c == -1)
      break;

    switch (c) {
      case 'Y':
        if (strcmp(tmp_str, "rd") == 0) {
          lvl_type = LVL_RD;
        } else if (strcmp(tmp_str, "rd_gate") == 0) {
          lvl_type = LVL_RD_GATE;
        } else if (strcmp(tmp_str, "wr") == 0) {
          lvl_type = LVL_WR;
        } else {
          lvl_type = LVL_INVALID;
        }
        break;
      case 'A':
        // lvl_rank0
        parse_int_list(lvl[0], tmp_str);
        break;
      case 'B':
        // lvl_rank1
        parse_int_list(lvl[1], tmp_str);
        break;
      case 'C':
        // lvl_rank2
        parse_int_list(lvl[2], tmp_str);
        break;
      case 'D':
        // lvl_rank3
        parse_int_list(lvl[3], tmp_str);
        break;
      case 'Q':
        // Write DQ
        parse_int_list(write_dq, tmp_str);
        set_write_dq_ = 1;
        break;
      case 'p':
        do_print(tmp_str);
        print_regs = 1;
        break;
      case '?':
        usage(opts);
        return (-1);
    }
  }

  if (do_help || (lvl_type == LVL_INVALID)) {
    usage(opts);
    return (-1);
  }

  if (print_regs) {
    return (0);
  }

  if (!is_x4_mode()) {
    // X8 mode writes to nibble 0 of X4 regs
    x4_nib = 0;
  }

  if (save_regs) {
    do_save(lvl_type, 0);
    if (is_x4_mode())
      do_save(lvl_type, 1);
    return (0);
  }

  if (restore_regs) {
    do_restore(lvl_type, 0);
    if (is_x4_mode())
      do_restore(lvl_type, 1);
    return (0);
  }

  if ((lvl_mcu >= 0) && !is_mcu_active(lvl_mcu)) {
    X__printf("MCU %d is not active\n", lvl_mcu);
    return (1);
  }

  if (ecc_en == 0) {
//    X__printf("Set ECC OFF\n");
    for (x = 0; x < 4; x++) {
      if (is_mcu_active(x))
        wr_mcu_err_ctl(x, 0x010000);
    }
    no_mcu_ok = 1;
  } else if (ecc_en >= 1) {
//    X__printf("Set ECC ON\n");
    for (x = 0; x < 4; x++) {
      if (is_mcu_active(x))
        wr_mcu_err_ctl(x, 0x010080);
    }
    no_mcu_ok = 1;
  }
/*
  if (set_write_dq_) {
    for (y = 0; y < 4; y++) {
      if ((lvl_mcu < 0) || (y == lvl_mcu)) {
        for (x = 0; x < 9; x++) {
          if (is_mcu_active(y) && (write_dq[x] >= 0)) {
            if (x4_nib <= 0) {
              set_write_dq_delay_x4(y, x, 0, write_dq[x]);
            }
            if (x4_nib != 0) {
              set_write_dq_delay_x4(y, x, 1, write_dq[x]);
            }
          }
        }
      }
    }
    no_mcu_ok = 1;
  }

  if ((lvl_mcu < 0) || (lvl_mcu > 3)) {
    // must set MCU
    if (!no_mcu_ok) {
      X__printf("Must set MCU\n");
      usage(opts);
      return (-1);
    }
    return (0);
  }

  for (x = 0; x < 4; x++) {
    int set = 0;
    for (y=0;y<9;y++) if (lvl[x][y] >= 0) set = 1;
    if (set) {
      if (x4_nib <= 0) {
        switch (lvl_type) {
          case LVL_RD:      set_rdlvl_delay_x4(lvl_mcu, x, 0, lvl[x]); break;
          case LVL_RD_GATE: set_rdlvl_gate_x4(lvl_mcu, x, 0, lvl[x]); break;
          case LVL_WR:      set_wrlvl_delay_x4(lvl_mcu, x, 0, lvl[x]); break;
          default: break;
        }
      }
      if (x4_nib != 0) {
        switch (lvl_type) {
          case LVL_RD:      set_rdlvl_delay_x4(lvl_mcu, x, 1, lvl[x]); break;
          case LVL_RD_GATE: set_rdlvl_gate_x4(lvl_mcu, x, 1, lvl[x]); break;
          case LVL_WR:      set_wrlvl_delay_x4(lvl_mcu, x, 1, lvl[x]); break;
          default: break;
        }
      }
    }
  }
*/
set_write_dq_ = set_write_dq_;
no_mcu_ok = no_mcu_ok;

  return (0);
}

int32_t get_saved_rdlvl(uint64_t mcu, uint64_t rank, uint64_t byte, uint32_t x4) { return 0; }

int32_t get_saved_rdlvl_rise(uint64_t mcu, uint64_t rank, uint64_t byte, uint64_t bit, uint32_t x4)
{
  int32_t ret = -1;
  if (is_sngl_rank_lvl(mcu)) rank = 0;
  if (g_saved_state_init) {
    if (rank < g_saved_state.n_ranks[mcu]) {
      ret = g_saved_state.mcu[mcu][rank].rd_rise[byte][bit];
    }
  }
  return (ret);
}

int32_t get_saved_rdlvl_fall(uint64_t mcu, uint64_t rank, uint64_t byte, uint64_t bit, uint32_t x4)
{
  int32_t ret = -1;
  if (is_sngl_rank_lvl(mcu)) rank = 0;
  if (g_saved_state_init) {
    if (rank < g_saved_state.n_ranks[mcu]) {
      ret = g_saved_state.mcu[mcu][rank].rd_fall[byte][bit];
    }
  }
  return (ret);
}


int32_t get_saved_rdlvl_gate(uint64_t mcu, uint64_t rank, uint64_t byte, uint32_t x4)
{
  int32_t ret = -1;
  if (is_sngl_rank_lvl(mcu)) rank = 0;
  if (g_saved_state_init) {
    if (rank < g_saved_state.n_ranks[mcu]) {
      ret = g_saved_state.mcu[mcu][rank].rd_gate[byte][x4];
    }
  }
  return (ret);
}

int32_t get_saved_wrlvl(uint64_t mcu, uint64_t rank, uint64_t byte, uint32_t x4)
{
  int32_t ret = -1;
  if (is_sngl_rank_lvl(mcu)) rank = 0;
  if (g_saved_state_init) {
    if (rank < g_saved_state.n_ranks[mcu]) {
      ret = g_saved_state.mcu[mcu][rank].wr[byte][x4];
    }
  }
  return (ret);
}

int32_t get_saved_write_dq_bit(uint64_t mcu, uint64_t rank, uint64_t byte, uint64_t bit, uint32_t x4)
{
  int32_t ret = -1;
  if (is_sngl_rank_lvl(mcu)) rank = 0;
  if (g_saved_state_init) {
    if (rank < g_saved_state.n_ranks[mcu]) {
      ret = g_saved_state.mcu[mcu][rank].wr_dq[byte][bit];
    }
  }
  return (ret);
}

int32_t get_saved_vref(uint64_t mcu)
{
  int32_t ret = -1;
  if (g_saved_state_init) {
      ret = g_saved_state.mcu[mcu][0].vref[0];
  }
  return (ret);
}

void set_rd_trim_delay(uint32_t chan, uint32_t byte, int32_t *data) { }
void get_rd_trim_delay(uint32_t chan, uint32_t byte, int32_t *data) { }
void set_wr_trim_delay(uint32_t chan, uint32_t byte, int32_t *data) { }
void get_wr_trim_delay(uint32_t chan, uint32_t byte, int32_t *data) { }
void set_phy_slew(uint32_t mcu, e_drive_slew_type type, uint32_t val) { }
uint32_t get_phy_slew(uint32_t mcu, e_drive_slew_type type) { return (0); }
uint32_t get_phy_drive_slew_reg(uint32_t mcu, uint32_t idx) { return (0); }
void set_phy_drive_slew_reg(uint32_t mcu, uint32_t idx, uint32_t data) { }
void set_phy_drive_strn(uint32_t mcu, e_drive_slew_type type, uint32_t val) { }
uint32_t get_phy_drive_strn(uint32_t mcu, e_drive_slew_type type) { return (0); }

void set_trim(int rdlvl, int64_t trim) { }

