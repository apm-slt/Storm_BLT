/* Copyright (c) 2014 by Veloce Technologies.  All Rights Reserved. */
/* $Id: //depot/projects/osboot/MAIN/ubsa/ubsa_deskew.c#1 $ */

#include "bbcutils.h"
#include "ubsa_shmoo.h"

typedef struct {
  // 0 = left, 1 = right
  int32_t edge[2][64];
} eye_data_s;

// TODO support x4

#define ABS(x) (((x) < 0) ? -(x) : (x))

void find_edges(uint32_t rdlvl, uint32_t lvl_step, int64_t mcu, int64_t rank, char *memtest_opts, eye_data_s **eye_data, uint32_t verbose) // eye_data[mcu]
{
  uint64_t *test_pass[4];
  int i, b, w;
  int m;

  // deskew algo vars
  int left_edge;
  int all_zero;
  int check_pass;
  uint64_t lvl_offs;
  int64_t all_fail[2];
  int64_t all_pass[2];
  uint64_t bit_error;

  // large steps
  for (left_edge = 0; left_edge < 2; left_edge++) {
    int32_t max_iter = 0x200;
    all_fail[left_edge] = -1;
    all_pass[left_edge] = 0;
    lvl_offs = lvl_step;

    do {
      if (rdlvl) {
        all_zero = !set_rdlvl_offset(mcu, rank, (left_edge ? -lvl_offs : lvl_offs));
      } else {
        all_zero = !set_wrlvl_offset(mcu, rank, (left_edge ? -lvl_offs : lvl_offs));
      }

      memtest_all_bits_rank(memtest_opts, mcu, rank, 0);
      bit_error = get_memtest_bit_errors();

      if (verbose)
        X__printf("\rRunning LVL Offset %d  0x%016x   ", (left_edge ? -lvl_offs : lvl_offs), bit_error);

      if (bit_error == 0) {
        all_pass[left_edge] = lvl_offs;
      } else if (bit_error == ~0ull) {
        all_fail[left_edge] = lvl_offs;
        break;
      } else if (all_zero) {
        all_fail[left_edge] = lvl_offs;
        break;
      }
      lvl_offs += lvl_step;

      if (lvl_offs > max_iter) {
        X__printf("\nERROR: max iter\n");
        return;
      }
    } while (1);

    if (verbose) {
      X__printf("\n\n");

      X__printf("%s Edge\n", (left_edge ? "Left" : "Right"));
      X__printf("All pass offset: %d\nAll fail offset: %d\n", all_pass[left_edge], all_fail[left_edge]);
    }

    if (all_pass[left_edge] < 2) {
      all_pass[left_edge] = 2;
    }

//    arch_timer_udelay(100000);
    putc('*');
  }

  if (verbose) {
    X__printf("Edge check range: 0x%x to 0x%x, 0x%x to 0x%x\n",
      all_pass[0], all_fail[0], all_pass[1], all_fail[1]);
  }

  i = (all_fail[0] - all_pass[0])+2 + (all_fail[1] - all_pass[1])+2;
  for (m = 0; m < 4; m++) {
    test_pass[m] = (uint64_t *)ubsa_malloc(i*8); // this aligns to 16 bytes
    if (test_pass[m] == NULL) {
      X__printf("malloc failed : size %d\n", i*8);
      return;
    }
  }

  for (m = 0; m < 4; m++) {
    for (w = 0; w < i; w++)
      test_pass[m][w] = 0;
  }

  w = 0;
  for (left_edge = 0; left_edge < 2; left_edge++) {
    check_pass = 3; // min number of all pass
    for (lvl_offs = all_pass[left_edge]-2; lvl_offs < all_fail[left_edge]; lvl_offs++) {

      if (rdlvl) {
        set_rdlvl_offset(mcu, rank, (left_edge ? -lvl_offs : lvl_offs));
      } else {
        set_wrlvl_offset(mcu, rank, (left_edge ? -lvl_offs : lvl_offs));
      }

//      X__printf("\rRunning LVL Offset %d   ", (left_edge ? -lvl_offs : lvl_offs));
      memtest_all_bits_rank(memtest_opts, mcu, rank, 0);
      bit_error = get_memtest_bit_errors();

      if ((check_pass != 0) && (bit_error != 0) && (lvl_offs > all_pass[left_edge])) {
        X__printf("\n\nFail found in assumed passing range: 0x%016x ", bit_error);
        X__printf("%s Edge, offs %d, ", (left_edge ? "Left" : "Right"), lvl_offs);
        X__printf("All pass offset: %d. All fail offset: %d\n\n", all_pass[left_edge], all_fail[left_edge]);
        // TODO: make this case work.
      }
      check_pass = ((check_pass == 0) ? 0 : (check_pass - 1));

      // TODO: check for early all_fail and exit

      for (m = 0; m < 4; m++) {
        if (is_mcu_active(m)) {
          test_pass[m][w] = ~get_memtest_bit_errors_mcu(m);
        }
      }
      w++;

      // don't run out of memory
      ubsa_dram_alloc_reset();

      // reset MCU FIFO
      mcu_phy_rdfifo_reset_all();
    }
    putc('*');
  }

  for (m = 0; m < 4; m++) {
    w = 0;
    for (left_edge = 0; left_edge < 2; left_edge++) {
      for (lvl_offs = all_pass[left_edge]-2; lvl_offs < all_fail[left_edge]; lvl_offs++) {
  //      X__printf("P: 0x%016x\n", test_pass[w]);
        for (b = 0; b < 64; b++) {
          if (eye_data[m]->edge[left_edge][b] == -1) {
            if ((test_pass[m][w] & (uint64_t)(1ull << (uint64_t)b)) == 0) {
              eye_data[m]->edge[left_edge][b] = lvl_offs-1;
  //            X__printf("Bit %2d : 0x%03x\n", b, lvl_offs-1);
            }
          }
        }
        w++;
      }
      for (b = 0; b < 64; b++) {
        if (eye_data[m]->edge[left_edge][b] == -1) {
          eye_data[m]->edge[left_edge][b] = all_fail[left_edge];
  //        X__printf("Bit %2d X: 0x%03x\n", b, all_fail[left_edge]);
        }
      }
    }
  }


/*
  w = 0;
  for (left_edge = 0; left_edge < 2; left_edge++) {
    for (lvl_offs = all_pass[left_edge]-2; lvl_offs < all_fail[left_edge]; lvl_offs++) {
      for (i = 0; i < 64; i++) {
        putc( (GET_BIT(i+(w*64)) ? '1' : '0') );
      }
      w++;
      X__printf("\n");
    }
    X__printf("\n");
  }
  X__printf("\n");
*/

  mcu_phy_rdfifo_reset_all();

  for (b = 0; b < 4; b++)
    ubsa_free(test_pass[b]);
}

int sw_deskew(char *argv)
{
  static int64_t mcu;
  static uint64_t rank;
  static uint32_t lvl_step;
  static uint32_t rdlvl;
  static uint32_t verbose;
  static uint32_t do_help;
  static char *opt_str;

  // 4 mcus, 2 trim vals, 2 edges, 64 bits
  eye_data_s *eye_edges[2][4];

  int i, b, w, m;
  int64_t max_trim;
  char memtest_opts[256];

  // option parsing vars
  int c;
  int first;
  int option_idx;
  char *tmp_var;

  static ubsa_long_options_s opts[] = {
//    {"mcu",         'M', OPT_INT64,   1, &mcu,          0, "MCU to target"},
    {"rank",        'R', OPT_UINT64,  1, &rank,         0, "Rank to target"},
    {"step",        'S', OPT_UINT32,  1, &lvl_step,     0, "Initial step in search"},
    {"lvl",         'L', OPT_STRING,  1, &opt_str,      0, "RdLvl or WrLvl ('rd' 'wr')"},
    {"",            'C', OPT_STRING,  1, &opt_str,      0, "memtest command"},
    {"verbose",     'v', OPT_UINT32,  0, &verbose,      1, "Be Verbose"},
    {"help",        'h', OPT_UINT32,  0, &do_help,      1, "Print Help"},
    // TODO: Seed
    { NULL, 0, 0, 0, 0, 0, 0 }
  };

  rdlvl = 1;
  verbose = 0;
  do_help = 0;
  mcu = -1;
  rank = 0;
  lvl_step = 8;
  memtest_opts[0] = 0;

  first = 1;
  while (1) {
    c = ubsa_getopt_long((first ? argv : NULL), opts, &option_idx, &tmp_var);
    first = 0;
    if (c == -1)
      break;

    switch (c) {
      case 'L':
        if (strncmp(opt_str, "rd", 2) == 0) {
          rdlvl = 1;
        } else if (strncmp(opt_str, "wr", 2) == 0) {
          rdlvl = 0;
        } else {
          X__printf("Unknown lvl type '%s'\n", opt_str);
          do_help = 1;
        }
        break;
      case 'C':
        strncpy(memtest_opts, opt_str, 256);
        memtest_opts[255] = 0;
        X__printf("Memtest command '%s'\n", memtest_opts);
        break;
      case '?':
        do_help = 1;
        break;
    }
  }

  if (do_help || (memtest_opts[0] == 0) || (rank > 3)) // || (mcu < 0) || (mcu > 3))
  {
    X__printf("Usage:\n");
    ubsa_getopt_usage(opts);
    return (1);;
  }

  for (i = 0; i < 2; i++) {
    for (m = 0; m < 4; m++) {
      eye_edges[i][m] = ubsa_malloc(sizeof(eye_data_s));
    }
  }
  max_trim = (rdlvl ? MAX_RDLVL_TRIM : MAX_WRLVL_TRIM);

  memreg("--save");
  memreg("--ecc_en 0");

  for (m = 0; m < 4; m++)
    for (i = 0; i < 2; i++)
      for (w = 0; w < 2; w++)
        for (b = 0; b < 64; b++)
          eye_edges[i][m]->edge[w][b] = -1;

  set_trim(rdlvl, 0);
  mcu_phy_rdfifo_reset_all();

  // trim 0
  find_edges(rdlvl, lvl_step, mcu, rank, memtest_opts, eye_edges[0], verbose);
  X__printf("0\n");

  // set trim to max
  set_trim(rdlvl, max_trim);
  mcu_phy_rdfifo_reset_all();

  // trim MAX
  find_edges(rdlvl, lvl_step, mcu, rank, memtest_opts, eye_edges[1], verbose);
  X__printf("%d\n", max_trim);

  for (m = 0; m < 4; m++) {
    int32_t trim_data[9];
    if (!is_mcu_active(m)) { continue; }
    for (i = 0; i < 8; i++) {
      int64_t l;
      if (rdlvl) {
        l = get_saved_rdlvl(m, rank, i, 0);
      } else {
        l = get_saved_wrlvl(m, rank, i, 0);
      }

      trim_data[8] = -1;
      for (b = i*8, w=0; b < (i+1)*8; b++, w++) {
        int64_t shft;
        int64_t rw0 = eye_edges[0][m]->edge[0][b];
        int64_t rw7 = eye_edges[1][m]->edge[0][b];
        int64_t lw0 = eye_edges[0][m]->edge[1][b];
        int64_t lw7 = eye_edges[1][m]->edge[1][b];
        int64_t re0 = l + rw0;
        int64_t re7 = l + rw7;
        int64_t le0 = l - lw0;
        int64_t le7 = l - lw7;
        int64_t x0, x7;
        int64_t trim_val;
        le0 = ((le0 < 0) ? 0 : le0);
        le7 = ((le7 < 0) ? 0 : le7);
        re0 = ((re0 < 0) ? 0 : re0);
        re7 = ((re7 < 0) ? 0 : re7);
        lw0 = ((lw0 > l) ? l : lw0);
        lw7 = ((lw7 > l) ? l : lw7);
        shft = (le7+re7)/2 - (le0+re0)/2;
        shft = ABS(shft);

        x0 = l - (le0+re0)/2;
        x7 = l - (le7+re7)/2;

        // cases where edge is very close to the HW value
        if ((rw0 > rw7) && (rw0 > lw7) && (rw0 > lw0)) {
          trim_val = 0;
        } else if ((rw7 > rw0) && (rw7 > lw0) && (rw7 > lw7)) {
          trim_val = max_trim;
        }
        // full width for 0/7 is greater than the other
        else if ((x0 <= 0) && (x7 <= 0)) {
          trim_val = ((-x0 < -x7) ? 0 : max_trim);
        } else if ((x0 >= 0) && (x7 >= 0)) {
          trim_val = ((x0 < x7) ? 0 : max_trim);
        }
        // interpolate case
        else {
          x0 = (x0 < 0) ? -x0 : x0; // shouldn't happen
          // eye centers differences have different signs.
          trim_val = ((max_trim*x0)/shft);
        }
        if (verbose) {
          X__printf("MCU %d Bit %2d : HW 0x%03x : Trim 0 0x%03x - 0x%03x", m, b, l, le0, re0);
          X__printf(" : Trim MAX 0x%03x - 0x%03x", le7, re7);
          X__printf(" : Shift %2d : D %2d  %2d :: New Trim %d\n", shft, l - (le0+re0)/2, l - (le7+re7)/2, trim_val);
        }
        trim_data[w] = trim_val;
      }
      if (rdlvl) {
        set_rd_trim_delay(m, i, trim_data);
      } else {
        set_wr_trim_delay(m, i, trim_data);
      }
    }
  }

  memreg("--restore");
  memreg("--ecc_en 1");

  for (i = 0; i < 2; i++) {
    for (mcu = 0; mcu < 4; mcu++) {
      ubsa_free(eye_edges[i][mcu]);
    }
  }

  return (0);
}


