/* Copyright (c) 2014 by Veloce Technologies.  All Rights Reserved. */
/* $Id: //depot/projects/osboot/MAIN/ubsa/ubsa_memreg.c#4 $ */

#include "bbcutils.h"


static void parse_int_list(int *val, char *arg)
{
  char *tmp, *str;
  int idx = 0;

  while ((str = ubsa_strtok(((idx==0) ? arg : NULL), ",", &tmp)) && (idx < 9)) {
    val[idx] = simple_strtol(str, NULL, 0);
    idx++;
  }
}


void get_lvl_data(uint32_t addr_offset, uint32_t chan, uint32_t rank, int32_t *data)
{
  int32_t i;
  for (i = 0; i < 9; i++) {
    uint32_t addr = addr_offset + (i * 4 * 96) + (rank * 24);
    data[i] = read_rb(0x282 + chan*4, (addr >> 2)) & 0xFFF;
  }
}

void set_lvl_data(uint32_t addr_offset, uint32_t chan, uint32_t rank, int32_t *data)
{
  int32_t i;
  uint32_t _tmp;
  for (i = 0; i < 9; i++) {
    if (data[i] != -1) {
      uint32_t addr = addr_offset + (i * 4 * 96) + (rank * 24);
      _tmp = read_rb(0x282 + chan*4, (addr >> 2));
      _tmp = (_tmp & ~0xFFFull) | (data[i] & 0xFFF);
      write_rb(0x282 + chan*4, (addr >> 2), _tmp);
    }
  }
}


// 1.1 PHY CONFIGURATION REGISTER (OFFSET: 0X000) (CFG_PHY_CONFIG)J
//    [14] cfg_x4_en

uint32_t is_mcu_x4_en(uint32_t chan) {
  uint32_t _tmp;
  _tmp = read_rb(0x282 + chan*4, 0);
  return ((_tmp & (1 << 14)) != 0);
}

// RDLVL DELAY FOR RANK “M” MACRO”N” (OFFSET: 0X1F4 + (“N” X 96 X 4) + (“M” X 24)) (CFG_RDLVL_DELAYM_N_0)
// N = byte, M = rank.

void get_rdlvl_delay(uint32_t chan, uint32_t rank, int32_t *data) {
  get_lvl_data(0x1f4, chan, rank, data);
}

void set_rdlvl_delay(uint32_t chan, uint32_t rank, int32_t *data) {
  set_lvl_data(0x1f4, chan, rank, data);
}

void get_rdlvl_delay_x4(uint32_t chan, uint32_t rank, uint32_t high_nib, int32_t *data) {
  uint32_t a = (high_nib ? 0x1f8 : 0x1f4);
  get_lvl_data(a, chan, rank, data);
}

void set_rdlvl_delay_x4(uint32_t chan, uint32_t rank, uint32_t high_nib, int32_t *data) {
  uint32_t a = (high_nib ? 0x1f8 : 0x1f4);
  set_lvl_data(a, chan, rank, data);
}

// RDLVL GATE : 0x1fc : 12 bits

void get_rdlvl_gate(uint32_t chan, uint32_t rank, int32_t *data) {
  get_lvl_data(0x1fc, chan, rank, data);
}

void set_rdlvl_gate(uint32_t chan, uint32_t rank, int32_t *data) {
  set_lvl_data(0x1fc, chan, rank, data);
}

void get_rdlvl_gate_x4(uint32_t chan, uint32_t rank, uint32_t high_nib, int32_t *data) {
  uint32_t a = (high_nib ? 0x200 : 0x1fc);
  get_lvl_data(a, chan, rank, data);
}

void set_rdlvl_gate_x4(uint32_t chan, uint32_t rank, uint32_t high_nib, int32_t *data) {
  uint32_t a = (high_nib ? 0x200 : 0x1fc);
  set_lvl_data(a, chan, rank, data);
}

// WRLVL DELAY FOR RANK “M” MACRO”N” (OFFSET: 0X204)

void get_wrlvl_delay(uint32_t chan, uint32_t rank, int32_t *data) {
  get_lvl_data(0x204, chan, rank, data);
}

void set_wrlvl_delay(uint32_t chan, uint32_t rank, int32_t *data) {
  set_lvl_data(0x204, chan, rank, data);
}

void get_wrlvl_delay_x4(uint32_t chan, uint32_t rank, uint32_t high_nib, int32_t *data) {
  uint32_t a = (high_nib ? 0x208 : 0x204);
  get_lvl_data(a, chan, rank, data);
}

void set_wrlvl_delay_x4(uint32_t chan, uint32_t rank, uint32_t high_nib, int32_t *data) {
  uint32_t a = (high_nib ? 0x208 : 0x204);
  set_lvl_data(a, chan, rank, data);
}

// 1.137 RDLVL TRIM DELAY FOR MACRO”N” (OFFSET: 0X1C8 + (“N” X 96 X 4)) (CFG_RDLVL_TRIM_N)
void set_rd_trim_delay(uint32_t chan, uint32_t byte, int32_t *data) {
  int32_t i;
  uint32_t _tmp;
  uint32_t addr = 0x1c8 + (byte * 4 * 96);
  _tmp = read_rb(0x282 + chan*4, (addr >> 2));
  for (i = 0; i < 8; i++) {
    if (data[i] != -1) {
      _tmp &= ~(7 << (i*3));
      _tmp |= ((data[i] & 7) << (i*3));
    }
  }
  write_rb(0x282 + chan*4, (addr >> 2), _tmp);
}

void get_rd_trim_delay(uint32_t chan, uint32_t byte, int32_t *data) {
  int32_t i;
  uint32_t _tmp;
  uint32_t addr = 0x1c8 + (byte * 4 * 96);
  _tmp = read_rb(0x282 + chan*4, (addr >> 2));
  for (i = 0; i < 8; i++) {
    data[i] = (_tmp >> (i*3)) & 7;
  }
}

// 1.138 WRLVL TRIM DELAY FOR MACRO”N” (OFFSET: 0X1CC + (“N” X 96 X 4)) (CFG_WRLVL_TRIM_N)
void set_wr_trim_delay(uint32_t chan, uint32_t byte, int32_t *data) {
  int32_t i;
  uint32_t _tmp;
  uint32_t addr = 0x1cc + (byte * 4 * 96);
  _tmp = read_rb(0x282 + chan*4, (addr >> 2));
  for (i = 0; i < 9; i++) {
    if (data[i] != -1) {
      _tmp &= ~(7 << (i*3));
      _tmp |= ((data[i] & 7) << (i*3));
    }
  }
  write_rb(0x282 + chan*4, (addr >> 2), _tmp);
}

void get_wr_trim_delay(uint32_t chan, uint32_t byte, int32_t *data) {
  int32_t i;
  uint32_t _tmp;
  uint32_t addr = 0x1cc + (byte * 4 * 96);
  _tmp = read_rb(0x282 + chan*4, (addr >> 2));
  for (i = 0; i < 9; i++) {
    data[i] = (_tmp >> (i*3)) & 7;
  }
}


// 1.139 WRITE DQ DELAY FOR MACRO”N” (OFFSET: 0X1D0 + (“N” X 96 X 4)) (CFG_WRDQ_DEL_N)

void set_write_dq_delay(uint32_t chan, uint32_t byte, int32_t data) {
  uint32_t _tmp;
  uint32_t addr = 0x1d0 + (byte * 4 * 96);
  _tmp = read_rb(0x282 + chan*4, (addr >> 2));
  _tmp = (_tmp & ~0xFFFull) | (data & 0xFFF);
  write_rb(0x282 + chan*4, (addr >> 2), _tmp);
}

uint32_t get_write_dq_delay(uint32_t chan, uint32_t byte) {
  uint32_t _tmp;
  uint32_t addr = 0x1d0 + (byte * 4 * 96);
  _tmp = read_rb(0x282 + chan*4, (addr >> 2)) & 0xFFF;
  return _tmp;
}

void set_write_dq_delay_x4(uint32_t chan, uint32_t byte, uint32_t high_nib, int32_t data) {
  uint32_t _tmp;
  uint32_t addr = 0x1d0 + (byte * 4 * 96);
  _tmp = read_rb(0x282 + chan*4, (addr >> 2));
  if (high_nib) {
    _tmp = (_tmp & ~0x00FFF000) | ((data << 12) & 0x00FFF000);
  } else {
    _tmp = (_tmp & ~0xFFF) | (data & 0xFFF);
  }
  write_rb(0x282 + chan*4, (addr >> 2), _tmp);
}

uint32_t get_write_dq_delay_x4(uint32_t chan, uint32_t byte, uint32_t high_nib) {
  uint32_t _tmp;
  uint32_t addr = 0x1d0 + (byte * 4 * 96);
  _tmp = read_rb(0x282 + chan*4, (addr >> 2));
  _tmp = (high_nib ? (_tmp >> 12) : _tmp) & 0xFFF;
  return _tmp;
}

// Register 60: MCUGECR (MCU Global Error Control Register )
// bit 7 R/W ECCErrEn 1’h0 1 ==> Enable recognition, handling, and logging ECC errors

void wr_mcu_err_ctl(u32 chan, u32 data) {
  write_rb(0x280 + chan*4, 0x44, data);
}

u32 rd_mcu_err_ctl(u32 chan) {
  u32 _tmp;
  _tmp = read_rb(0x280 + chan*4, 0x44);
  return _tmp;
}

uint32_t is_ecc_on(uint32_t mcu) {
  uint32_t d = rd_mcu_err_ctl(mcu);
  return ((d & 0x0080) != 0);
}

void mcu_phy_rdfifo_reset(u32 chan)
{
  // RDLVLCTL 0x76
  // bit[8] RdFifo_Reset
  u32 _tmp;

  asm volatile ("dsb sy");
  asm volatile ("isb");

  _tmp = read_rb(0x280 + chan*4, 0x76);

  _tmp |= 0x100;
  write_rb(0x280 + chan*4, 0x76, _tmp);

  _tmp &= ~0x100;
  write_rb(0x280 + chan*4, 0x76, _tmp);
}

void mcu_phy_rdfifo_reset_all()
{
  u32 mcu;
  for (mcu = 0; mcu < 4; mcu++) {
    if (is_mcu_active(mcu)) {
      mcu_phy_rdfifo_reset(mcu);
    }
  }
}

// N/A on Storm
int mcu_phy_sw_adj_ctrlupdate(uint32_t mcu) { return 0; }

/*****************************************************************************/
// Deskew and Drive strength

static int get_phy_slew_info(e_drive_slew_type type, uint32_t *reg, uint32_t *shift)
{
  switch(type) {
    case DS_DATA_MASK: // 4:3 (3C)
      *reg = 0x3C;
      *shift = 3;
      break;
    case DS_DQ_DQS: // 9:8 (3C)
      *reg = 0x3C;
      *shift = 8;
      break;
    case DS_ADDR_BANK: // 17:16 (3C)
      *reg = 0x3C;
      *shift = 16;
      break;
    case DS_COMMAND: // 1:0 (40)
      *reg = 0x40;
      *shift = 0;
      break;
    case DS_CONTROL: // 6:5 (40)
      *reg = 0x40;
      *shift = 5;
      break;
    case DS_CLOCK: // 11:10 (40)
      // Decode table TBD
      *reg = 0x40;
      *shift = 10;
      break;
    default:
      // do nothing
      return (0);
  }
  return (1);
}

void set_phy_slew(uint32_t mcu, e_drive_slew_type type, uint32_t val)
{
  uint32_t _tmp;
  uint32_t reg;
  uint32_t shift;

  if (get_phy_slew_info(type, &reg, &shift)) {
    _tmp = read_rb(0x282 + mcu*4, (reg >> 2));
    _tmp = (_tmp & ~(3 << shift)) | ((val & 3) << shift);
    write_rb(0x282 + mcu*4, (reg >> 2), _tmp);
  }
}

uint32_t get_phy_slew(uint32_t mcu, e_drive_slew_type type)
{
  uint32_t _tmp;
  uint32_t reg;
  uint32_t shift;

  if (get_phy_slew_info(type, &reg, &shift)) {
    _tmp = read_rb(0x282 + mcu*4, (reg >> 2));
    return ((_tmp >> shift) & 3);
  }
  return (0);
}

uint32_t get_phy_drive_slew_reg(uint32_t mcu, uint32_t idx)
{
  uint32_t _tmp;

  if (idx == 0) {
    _tmp = read_rb(0x282 + mcu*4, (0x3C >> 2));
  } else {
    _tmp = read_rb(0x282 + mcu*4, (0x40 >> 2));
    _tmp &= 0xFFF;
  }

  return (_tmp);
}

void set_phy_drive_slew_reg(uint32_t mcu, uint32_t idx, uint32_t data)
{
  uint32_t _tmp;

  if (idx == 0) {
    write_rb(0x282 + mcu*4, (0x3C >> 2), data);
  } else {
    _tmp = read_rb(0x282 + mcu*4, (0x40 >> 2));
    _tmp = (_tmp & !0xFFF) | (data & 0xFFF);
    write_rb(0x282 + mcu*4, (0x40 >> 2), _tmp);
  }
}

static int get_phy_drive_info(e_drive_slew_type type, uint32_t *reg, uint32_t *shift)
{
  switch(type) {
    case DS_DATA_MASK:
      *reg = 0x3C;
      *shift = 0;
      break;
    case DS_DQ_DQS:
      *reg = 0x3C;
      *shift = 5;
      break;
    case DS_ADDR_BANK:
      *reg = 0x3C;
      *shift = 13;
      break;
    case DS_COMMAND:
      *reg = 0x3C;
      *shift = 18;
      break;
    case DS_CONTROL:
      *reg = 0x40;
      *shift = 2;
      break;
    case DS_CLOCK:
      *reg = 0x40;
      *shift = 7;
      break;
    default:
      // do nothing
      return (0);
  }
  return (1);
}

void set_phy_drive_strn(uint32_t mcu, e_drive_slew_type type, uint32_t val)
{
  uint32_t _tmp;
  uint32_t reg;
  uint32_t shift;

  if (get_phy_drive_info(type, &reg, &shift)) {
    _tmp = read_rb(0x282 + mcu*4, (reg >> 2));
    _tmp = (_tmp & ~(7 << shift)) | ((val & 7) << shift);
    write_rb(0x282 + mcu*4, (reg >> 2), _tmp);
  }
}

uint32_t get_phy_drive_strn(uint32_t mcu, e_drive_slew_type type)
{
  uint32_t _tmp;
  uint32_t reg;
  uint32_t shift;

  if (get_phy_drive_info(type, &reg, &shift)) {
    _tmp = read_rb(0x282 + mcu*4, (reg >> 2));
    return ((_tmp >> shift) & 7);
  }
  return (0);
}


/*****************************************************************************/

int set_rdlvl_offset(int32_t mcu, int32_t rank, int32_t lvl)
{
  int m, r, b, x;
  int32_t v;
  int32_t d[9];
  int all_zero = 1;

  for (m = 0; m < 4; m++) {
    if (((mcu >= 0) && (mcu != m)) || !is_mcu_active(m))
      continue;

    for (r = 0; r < 8; r++) {
      if (get_rank_intlv(m, r) == rank) {
        for (x = 0; x <= is_x4_mode(); x++) {
          for (b = 0; b < 9; b++) {
            v = get_saved_rdlvl(m, r, b, x);
            if ((v + lvl) < 0) {
              d[b] = 0;
            } else {
              d[b] = (v + lvl);
              all_zero = 0;
            }
          }
          set_rdlvl_delay_x4(m, r, x, d);
        }
      }
    }
  }
  return (!all_zero);
}

int set_wrlvl_offset(int32_t mcu, int32_t rank, int32_t lvl)
{
  int m, r, b, x;
  int32_t v;
  int32_t d[9];
  int all_zero = 1;

  for (m = 0; m < 4; m++) {
    if (((mcu >= 0) && (mcu != m)) || !is_mcu_active(m))
      continue;

    for (r = 0; r < 8; r++) {
      if (get_rank_intlv(m, r) == rank) {
        for (x = 0; x <= is_x4_mode(); x++) {
          for (b = 0; b < 9; b++) {
            v = get_saved_wrlvl(m, r, b, x);
            if ((v + lvl) < 0) {
              d[b] = 0;
            } else {
              d[b] = (v + lvl);
              all_zero = 0;
            }
          }
          set_wrlvl_delay_x4(m, r, x, d);
        }
      }
    }
  }
  return (!all_zero);
}

int set_rdgate_offset(int32_t mcu, int32_t rank, int32_t lvl)
{
  int m, r, b, x;
  int32_t v;
  int32_t d[9];
  int all_zero = 1;

  for (m = 0; m < 4; m++) {
    if (((mcu >= 0) && (mcu != m)) || !is_mcu_active(m))
      continue;

    for (r = 0; r < 8; r++) {
      if (get_rank_intlv(m, r) == rank) {
        for (x = 0; x <= is_x4_mode(); x++) {
          for (b = 0; b < 9; b++) {
            v = get_saved_rdlvl_gate(m, r, b, x);
            if ((v + lvl) < 0) {
              d[b] = 0;
            } else {
              d[b] = (v + lvl);
              all_zero = 0;
            }
          }
          set_rdlvl_gate_x4(m, r, x, d);
        }
      }
    }
  }
  return (!all_zero);
}

int set_wrdq_offset(int32_t mcu, int32_t rank, int32_t lvl)
{
  int m, b, x;
  int32_t v, d;
  int all_zero = 1;

  for (m = 0; m < 4; m++) {
    if (((mcu >= 0) && (mcu != m)) || !is_mcu_active(m))
      continue;

    for (x = 0; x <= is_x4_mode(); x++) {
      for (b = 0; b < 9; b++) {
        v = get_saved_write_dq(m, b, x);
        if ((v + lvl) < 0) {
          d = 0;
        } else {
          d = (v + lvl);
          all_zero = 0;
        }
        set_write_dq_delay_x4(m, b, x, d);
      }
    }
  }
  return (!all_zero);
}


// Register 165: MCUESRR0 (Rank0 MCU Error Status Register )
// 0 COW CErr 1’h0 1 ==> Threshold of correctable Errors occurred during a requested operation

#define MCU_Error_Status_Register(rank) (0xc5 + (rank)*0x10)

void wr_mcu_err_status(uint32_t chan, uint32_t rank, uint32_t data) {
  write_rb(0x280 + chan*4, MCU_Error_Status_Register(rank), data);
}

uint32_t rd_mcu_err_status(uint32_t chan, uint32_t rank) {
  uint32_t _tmp;
  _tmp = read_rb(0x280 + chan*4, MCU_Error_Status_Register(rank));
  return _tmp;
}

// Register 169: MCUSBECNT0 (MCU Rank0 Single Bit Error Count Register )
// 15:0 R/W Count -14’h0 Correctable Error count

#define MCU_SBE_Count_Register(rank) (0xc9 + (rank)*0x10)

void wr_mcu_sbe_count(uint32_t chan, uint32_t rank, uint32_t data) {
  write_rb(0x280 + chan*4, MCU_SBE_Count_Register(rank), data);
}

uint32_t rd_mcu_sbe_count(uint32_t chan, uint32_t rank) {
  uint32_t _tmp;
  _tmp = read_rb(0x280 + chan*4, MCU_SBE_Count_Register(rank));
  return _tmp;
}


/*****************************************************************************/

static void usage(ubsa_long_options_s *opts)
{
  X__printf("Usage:\n");
  ubsa_getopt_usage(opts);
}

void print_lvl(char *lstr, uint64_t mcu, uint64_t rank, int32_t *rdl)
{
    X__printf("MCU%d Rank%d %s : 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x\n",
      mcu, rank, lstr, (uint64_t)rdl[0], (uint64_t)rdl[1], (uint64_t)rdl[2], (uint64_t)rdl[3],
      (uint64_t)rdl[4], (uint64_t)rdl[5], (uint64_t)rdl[6], (uint64_t)rdl[7], (uint64_t)rdl[8]);
}

void print_rdlvl()
{
  int x,y;
  int32_t rdl[9];
  for (x = 0; x < 4; x++) {
    if (is_mcu_active(x)) {
      for (y = 0; y < 4; y++) {
        if (is_x4_mode()) {
          get_rdlvl_delay_x4(x, y, 1, rdl);
          print_lvl("RdLVL HI", x, y, rdl);

          get_rdlvl_delay_x4(x, y, 0, rdl);
          print_lvl("RdLVL LO", x, y, rdl);
        } else {
          get_rdlvl_delay(x, y, rdl);
          print_lvl("RdLVL", x, y, rdl);
        }
      }
    }
  }
}

void print_rdlvl_gate()
{
  int x,y;
  int32_t rdl[9];
  for (x = 0; x < 4; x++) {
    if (is_mcu_active(x)) {
      for (y = 0; y < 4; y++) {
        if (is_x4_mode()) {
          get_rdlvl_gate_x4(x, y, 1, rdl);
          print_lvl("RdLVL Gate HI", x, y, rdl);

          get_rdlvl_gate_x4(x, y, 0, rdl);
          print_lvl("RdLVL Gate LO", x, y, rdl);
        } else {
          get_rdlvl_gate(x, y, rdl);
          print_lvl("RdLVL Gate", x, y, rdl);
        }
      }
    }
  }
}

void print_wrlvl()
{
  int x,y;
  int32_t rdl[9];
  for (x = 0; x < 4; x++) {
    if (is_mcu_active(x)) {
      for (y = 0; y < 4; y++) {
        if (is_x4_mode()) {
          get_wrlvl_delay_x4(x, y, 1, rdl);
          print_lvl("WrLVL HI", x, y, rdl);

          get_wrlvl_delay_x4(x, y, 0, rdl);
          print_lvl("WrLVL LO", x, y, rdl);
        } else {
          get_wrlvl_delay(x, y, rdl);
          print_lvl("WrLVL", x, y, rdl);
        }
      }
    }
  }
}

void print_write_dq()
{
  int m, b;
  int32_t data[9];

  for (m = 0; m < 4; m++) {
    if (is_mcu_active(m)) {
      if (is_x4_mode()) {
        for (b = 0; b < 9; b++) { data[b] = get_write_dq_delay_x4(m, b, 1); }
        X__printf("MCU%d Write DQ HI : %d %d %d %d %d %d %d %d %d\n", m,
          (uint64_t)data[0], (uint64_t)data[1], (uint64_t)data[2],
          (uint64_t)data[3], (uint64_t)data[4], (uint64_t)data[5],
          (uint64_t)data[6], (uint64_t)data[7], (uint64_t)data[8]);
        for (b = 0; b < 9; b++) { data[b] = get_write_dq_delay_x4(m, b, 0); }
        X__printf("MCU%d Write DQ LO : %d %d %d %d %d %d %d %d %d\n", m,
          (uint64_t)data[0], (uint64_t)data[1], (uint64_t)data[2],
          (uint64_t)data[3], (uint64_t)data[4], (uint64_t)data[5],
          (uint64_t)data[6], (uint64_t)data[7], (uint64_t)data[8]);
      } else {
        for (b = 0; b < 9; b++) { data[b] = get_write_dq_delay(m, b); }
        X__printf("MCU%d Write DQ : %d %d %d %d %d %d %d %d %d\n", m,
          (uint64_t)data[0], (uint64_t)data[1], (uint64_t)data[2],
          (uint64_t)data[3], (uint64_t)data[4], (uint64_t)data[5],
          (uint64_t)data[6], (uint64_t)data[7], (uint64_t)data[8]);
      }
    }
  }
}

void print_drive_slew()
{
  int m;

  X__printf("             data_mask dq_dqs addr cmd control clock\n");
  for (m = 0; m < 4; m++) {
    if (is_mcu_active(m)) {
      X__printf("MCU%d slew  :     %d        %d     %d   %d     %d      %d\n", m,
          get_phy_slew(m, DS_DATA_MASK),
          get_phy_slew(m, DS_DQ_DQS),
          get_phy_slew(m, DS_ADDR_BANK),
          get_phy_slew(m, DS_COMMAND),
          get_phy_slew(m, DS_CONTROL),
          get_phy_slew(m, DS_CLOCK));
      X__printf("MCU%d drive :     %d        %d     %d   %d     %d      %d\n", m,
          get_phy_drive_strn(m, DS_DATA_MASK),
          get_phy_drive_strn(m, DS_DQ_DQS),
          get_phy_drive_strn(m, DS_ADDR_BANK),
          get_phy_drive_strn(m, DS_COMMAND),
          get_phy_drive_strn(m, DS_CONTROL),
          get_phy_drive_strn(m, DS_CLOCK));
    }
  }
}

void print_memcfg(void)
{
  int mcu, rank, mcb;
  int num_mcu, num_mcb;
  u32 data;

  u32 cswcr = get_csw_config_reg();

  X__printf("cswcr = %x\n", cswcr);
  X__printf("csw['dual_mcb']    = %d\n", cswcr & 1);
  X__printf("csw['mcb_intrlv']  = %d\n", (cswcr >> 1) & 1);
  X__printf("csw['addr_mode']   = %d\n", (cswcr >> 2) ^ 1); // 1 -> 42bit

  num_mcb = 1 + (cswcr & 1);

  for (mcb = 0; mcb < num_mcb; mcb++) {
    // initialize the mcb_config
    data = get_mcb_addr_config(mcb);
//    X__printf("mcb_cfg[%d] = {}\n");
    X__printf("mcb_cfg[%d]['dual_mcb'] = %d\n", mcb, 1);
    X__printf("mcb_cfg[%d]['mcb_intrlv'] = %d\n", mcb, (data >> 1) & 1);
    X__printf("mcb_cfg[%d]['dual_mcu'] = %d\n", mcb, (data >> 2) & 1);
    X__printf("mcb_cfg[%d]['mcu_intrlv'] = %d\n", mcb, (data >> 3) & 1);
    X__printf("mcb_cfg[%d]['addr_mode'] = %d\n", mcb, data & 1); // 1 -> 32bit

    num_mcu = 1 + ((data >> 2) & 1);

    for (mcu = 2*mcb; mcu < ((2*mcb)+num_mcu); mcu++) {
  //    X__printf("mcu_cfg[%d] = {}\n", mcu);
      for (rank = 0; rank < 4; rank++) {
        u32 size = get_mcu_rank_size(mcu, rank);
        u32 cfg = get_mcu_rank_config(mcu, rank);
        u32 base = get_mcu_rank_base(mcu, rank);
        u32 mask = get_mcu_rank_mask(mcu, rank);

        X__printf("mcu_cfg[%d]['rank%d_cfg'] = %d\n", mcu, rank, cfg);
        X__printf("mcu_cfg[%d]['rank%d_size'] = %d\n", mcu, rank, size);
        X__printf("mcu_cfg[%d]['rank%d_base'] = 0x%x\n", mcu, rank, base & 0x3FFF);
        X__printf("mcu_cfg[%d]['rank%d_base_lower'] = 0x%x\n", mcu, rank, (base >> 16) & 7);
        X__printf("mcu_cfg[%d]['rank%d_mask'] = 0x%x\n", mcu, rank, mask & 0x3FFF);
        X__printf("mcu_cfg[%d]['rank%d_mask_lower'] = 0x%x\n", mcu, rank, (mask >> 16) & 7);
      }
    }
  }
}

void print_mem_rank_config(void)
{
  int m, r;
  char *sz_str = "";

  for (m = 0; m < 4; m++) {
    if (is_mcu_active(m)) {
      for (r = 0; r < 8; r++) {
        u32 size = get_mcu_rank_size(m, r);
        u32 cfg = get_mcu_rank_config(m, r);
        u32 base = get_mcu_rank_base(m, r);
        u32 mask = get_mcu_rank_mask(m, r);
        u64 b64, m64;

        if (size == 7)
          continue;

        switch (size) {
          case 0: // 512 MB
            sz_str = "512 MB: 64M x 16";
            break;
          case 1: // 1 GB
            sz_str = "1 GB: 128M x 8, 128M x 16";
            break;
          case 2: // 2 GB
            if (cfg) {
              sz_str = "2 GB: 256M x 8, 256M x 16";
            } else {
              sz_str = "2 GB: 256M x 4";
            }
            break;
          case 3: // 4 GB
            if (cfg) {
              sz_str = "4 GB: 512M x 8, 512M x 16";
            } else {
              sz_str = "4 GB: 512M x 4";
            }
            break;
          case 4: // 8 GB
            sz_str = "8 GB: 1G x 4, 1G x 8";
            break;
          case 5: // 16 GB
            sz_str = "16 GB: 2G x 4";
            break;
        }
        b64 = (((u64)(base & 0x3FFF) << 28) | ((u64)(base & 0x70000) >> 10)) << 8;
        m64 = (((u64)(mask & 0x3FFF) << 28) | ((u64)(mask & 0x70000) >> 10)) << 8;
        X__printf("MCU%d Rank%d : 0x%012x 0x%012x (%s) (%08x,%08x)\n", m, r, b64, m64, sz_str, base, mask);
  /*
  Rank Base
  0x308
  [18:16] = ReqAddr[8:6]
  [13:0] = ReqAddr[41:28]

  Rank Mask
  0x30c
  [18:16] = ReqAddr[8:6]
  [13:0] = ReqAddr[41:28]
  */
      }
    }
  }
}

void print_trim()
{
  int m, b;
  int32_t data[9];

  for (m = 0; m < 4; m++) {
    if (is_mcu_active(m)) {
      for (b = 0; b < 9; b++) {
        get_rd_trim_delay(m, b, data);
        X__printf("MCU%d Byte%d RdLvl Trim : %d %d %d %d %d %d %d %d\n", m, b,
          (uint64_t)data[0], (uint64_t)data[1], (uint64_t)data[2], (uint64_t)data[3],
          (uint64_t)data[4], (uint64_t)data[5], (uint64_t)data[6], (uint64_t)data[7]);
        get_wr_trim_delay(m, b, data);
        X__printf("MCU%d Byte%d WrLvl Trim : %d %d %d %d %d %d %d %d\n", m, b,
          (uint64_t)data[0], (uint64_t)data[1], (uint64_t)data[2], (uint64_t)data[3],
          (uint64_t)data[4], (uint64_t)data[5], (uint64_t)data[6], (uint64_t)data[7]);
      }
    }
  }
}

typedef struct {
  char *str;
  void (*func)(void);
} s_print_funcs;

static s_print_funcs print_funcs[] = {
  { "rdlvl", print_rdlvl },
  { "rdlvl_gate", print_rdlvl_gate },
  { "wrlvl", print_wrlvl },
  { "memcfg", print_memcfg },
  { "rank", print_mem_rank_config },
  { "trim", print_trim },
  { "write_dq", print_write_dq },
  { "drive_slew", print_drive_slew },
  { NULL, NULL }
};

void do_print(char *prt)
{
  int i;
  for (i = 0; prt[i] != 0; i++) {
    prt[i] = tolower(prt[i]);
  }
  if (strcmp(prt, "all") == 0) {
    for (i = 0; print_funcs[i].str != NULL; i++) {
      print_funcs[i].func();
    }
    return;
  }

  for (i = 0; print_funcs[i].str != NULL; i++) {
    if (strcmp(prt, print_funcs[i].str) == 0) {
      print_funcs[i].func();
      return;
    }
  }

  X__printf("Invalid print type: ");
  for (i = 0; print_funcs[i].str != NULL; i++) {
    X__printf("%s ", print_funcs[i].str);
  }
  X__printf("\n");
}

// can only save and restore one type at a time
void do_save(int32_t **reg_state, lvl_type_e type, uint32_t x4)
{
  int x,y,z;
  int32_t *ptr;
  int32_t rdl[9];

  if (*reg_state == NULL) {
    *reg_state = (int32_t *)ubsa_malloc(4*4*4*9*3 + 4*9*4 + 4*4*2);
  }
  ptr = *reg_state;

  for (x = 0; x < 4; x++) {
    for (y = 0; y < 4; y++) {
      if (is_mcu_active(x))
        get_rdlvl_delay_x4(x, y, x4, rdl);
      for (z = 0; z < 9; z++) {
        *ptr++ = rdl[z];
      }
    }
  }
  for (x = 0; x < 4; x++) {
    for (y = 0; y < 4; y++) {
      if (is_mcu_active(x))
        get_rdlvl_gate_x4(x, y, x4, rdl);
      for (z = 0; z < 9; z++) {
        *ptr++ = rdl[z];
      }
    }
  }
  for (x = 0; x < 4; x++) {
    for (y = 0; y < 4; y++) {
      if (is_mcu_active(x))
        get_wrlvl_delay_x4(x, y, x4, rdl);
      for (z = 0; z < 9; z++) {
        *ptr++ = rdl[z];
      }
    }
  }
  for (x = 0; x < 4; x++) {
    if (is_mcu_active(x)) {
      for (y = 0; y < 9; y++) {
        *ptr++ = get_write_dq_delay_x4(x, y, x4);
      }
    } else {
      ptr += 9;
    }
  }
/*
  for (x = 0; x < 4; x++) {
    if (is_mcu_active(x)) {
      for (y = 0; y < 2; y++) {
        *ptr++ = get_phy_drive_slew_reg(x, y);
      }
    } else {
      ptr += 2;
    }
  }
*/
}

void do_restore(int32_t **reg_state, lvl_type_e type, uint32_t x4)
{
  int x,y,z;
  int32_t *ptr;
  int32_t rdl[9];

  if (*reg_state == NULL) {
    return;
  }
  ptr = *reg_state;

  for (x = 0; x < 4; x++) {
    for (y = 0; y < 4; y++) {
      for (z = 0; z < 9; z++) {
        rdl[z] = *ptr++;
      }
      if (is_mcu_active(x))
        set_rdlvl_delay_x4(x, y, x4, rdl);
    }
  }
  for (x = 0; x < 4; x++) {
    for (y = 0; y < 4; y++) {
      for (z = 0; z < 9; z++) {
        rdl[z] = *ptr++;
      }
      if (is_mcu_active(x))
        set_rdlvl_gate_x4(x, y, x4, rdl);
    }
  }
  for (x = 0; x < 4; x++) {
    for (y = 0; y < 4; y++) {
      for (z = 0; z < 9; z++) {
        rdl[z] = *ptr++;
      }
      if (is_mcu_active(x))
        set_wrlvl_delay_x4(x, y, x4, rdl);
    }
  }
  for (x = 0; x < 4; x++) {
    if (is_mcu_active(x)) {
      for (y = 0; y < 9; y++) {
        set_write_dq_delay_x4(x, y, x4, *ptr++);
      }
    } else {
      ptr += 9;
    }
  }
/*
  for (x = 0; x < 4; x++) {
    if (is_mcu_active(x)) {
      for (y = 0; y < 2; y++) {
        set_phy_drive_slew_reg(x, y, *ptr++);
      }
    } else {
      ptr += 2;
    }
  }
*/
}

static int32_t *s_reg_state = NULL;
static int32_t *s_reg_state_x4 = NULL;

int memreg(char *argv)
{
  static int32_t lvl_mcu;
  static int32_t x4_nib;
  static int32_t print_regs;
  static int32_t save_regs;
  static int32_t restore_regs;
  static int32_t ecc_en;
  static int32_t do_help;
  static char *tmp_str;

  int x,y;
  int no_mcu_ok;
  lvl_type_e lvl_type;
  int lvl[4][9];
  int rd_trim[8];
  int wr_trim[8];
  int set_rd_trim;
  int set_wr_trim;
  int write_dq[9];
  int set_write_dq;

  // option parsing vars
  char cmd[256];
  int c;
  int first;
  int option_idx;
  char *tmp_var;

  static ubsa_long_options_s opts[] = {
    {"mcu",               'm', OPT_INT32,   1, &lvl_mcu,      0, "Selected MCU"},
    {"lvl",               'Y', OPT_STRING,  1, &tmp_str,      0, "LVL Type: ('rd') 'wr' 'rd_gate'"},
    {"lvl_rank0",         'A', OPT_STRING,  1, &tmp_str,      0, "Rank 0 Lvl (x9, '-1' preserves that field)"},
    {"lvl_rank1",         'B', OPT_STRING,  1, &tmp_str,      0, "Rank 1 Lvl (x9, '-1' preserves that field)"},
    {"lvl_rank2",         'C', OPT_STRING,  1, &tmp_str,      0, "Rank 2 Lvl (x9, '-1' preserves that field)"},
    {"lvl_rank3",         'D', OPT_STRING,  1, &tmp_str,      0, "Rank 3 Lvl (x9, '-1' preserves that field)"},
    {"x4_nib",            'N', OPT_INT32,   1, &x4_nib,       0, "Nibble in X4 mode (1 = high, 0 = low, -1 = set both)"},
    {"wr_trim",           't', OPT_STRING,  1, &tmp_str,      0, "Set Trim bits for all bytes (x9, '-1' preserves that field)"},
    {"rd_trim",           'T', OPT_STRING,  1, &tmp_str,      0, "Set Trim bits for all bytes (x9, '-1' preserves that field)"},
    {"write_dq",          'Q', OPT_STRING,  1, &tmp_str,      0, "Set Write DQ (x9, '-1' preserves that field)"},
    {"ecc_en",            'e', OPT_INT32,   1, &ecc_en,       0, "Set ECC Enable"},
    {"save",              's', OPT_INT32,   0, &save_regs,    1, "Save Register State"},
    {"restore",           'r', OPT_INT32,   0, &restore_regs, 1, "Restore Register State"},
    {"print",             'p', OPT_STRING,  1, &tmp_str,      0, "Dump Register State: all, rdlvl, memcfg"},
    {"help",              'h', OPT_INT32,   0, &do_help,      1, "Print Help"},
    // TODO: Seed
    { NULL, 0, 0, 0, 0, 0, 0 }
  };

  ecc_en = -1;
  do_help = 0;
  print_regs = 0;
  save_regs = 0;
  restore_regs = 0;
  option_idx = 0;
  lvl_mcu = -1;
  lvl_type = LVL_RD;
  no_mcu_ok = 0;
  set_rd_trim = 0;
  set_wr_trim = 0;
  set_write_dq = 0;
  x4_nib = -1;

//  X__printf("\nMEMREG: '%s'\n", argv);

  if (strlen(argv) >= 256) {
    X__printf("Command too long: %d\n", strlen(argv));
    X__printf("'%s'\n", argv);
    usage(opts);
    return (-1);
  }
  strcpy(cmd, argv);

  for (y = 0; y < 9; y++) {
    for (x = 0; x < 4; x++) {
      lvl[x][y] = -1;
    }
    rd_trim[y] = -1;
    wr_trim[y] = -1;
    write_dq[y] = -1;
  }

  first = 1;
  while (1) {
    c = ubsa_getopt_long((first ? cmd : NULL), opts, &option_idx, &tmp_var);
    first = 0;
    if (c == -1)
      break;

    switch (c) {
      case 'Y':
        if (strcmp(tmp_str, "rd") == 0) {
          lvl_type = LVL_RD;
        } else if (strcmp(tmp_str, "rd_gate") == 0) {
          lvl_type = LVL_RD_GATE;
        } else if (strcmp(tmp_str, "wr") == 0) {
          lvl_type = LVL_WR;
        } else {
          lvl_type = LVL_INVALID;
        }
        break;
      case 'A':
        // lvl_rank0
        parse_int_list(lvl[0], tmp_str);
        break;
      case 'B':
        // lvl_rank1
        parse_int_list(lvl[1], tmp_str);
        break;
      case 'C':
        // lvl_rank2
        parse_int_list(lvl[2], tmp_str);
        break;
      case 'D':
        // lvl_rank3
        parse_int_list(lvl[3], tmp_str);
        break;
      case 'T':
        // read trim
        parse_int_list(rd_trim, tmp_str);
        set_rd_trim = 1;
        break;
      case 't':
        // write trim
        parse_int_list(wr_trim, tmp_str);
        set_wr_trim = 1;
        break;
      case 'Q':
        // Write DQ
        parse_int_list(write_dq, tmp_str);
        set_write_dq = 1;
        break;
      case 'p':
        do_print(tmp_str);
        print_regs = 1;
        break;
      case '?':
        usage(opts);
        return (-1);
    }
  }

  if (do_help || (lvl_type == LVL_INVALID)) {
    usage(opts);
    return (-1);
  }

  if (print_regs) {
    return (0);
  }

  if (!is_x4_mode()) {
    // X8 mode writes to nibble 0 of X4 regs
    x4_nib = 0;
  }

  if (save_regs) {
    do_save(&s_reg_state, lvl_type, 0);
    if (is_x4_mode())
      do_save(&s_reg_state_x4, lvl_type, 1);
    return (0);
  }

  if (restore_regs) {
    do_restore(&s_reg_state, lvl_type, 0);
    if (is_x4_mode())
      do_restore(&s_reg_state_x4, lvl_type, 1);
    return (0);
  }

  if ((lvl_mcu >= 0) && !is_mcu_active(lvl_mcu)) {
    X__printf("MCU %d is not active\n", lvl_mcu);
    return (1);
  }

  if (ecc_en == 0) {
//    X__printf("Set ECC OFF\n");
    for (x = 0; x < 4; x++) {
      if (is_mcu_active(x))
        wr_mcu_err_ctl(x, 0x010000);
    }
    no_mcu_ok = 1;
  } else if (ecc_en >= 1) {
//    X__printf("Set ECC ON\n");
    for (x = 0; x < 4; x++) {
      if (is_mcu_active(x))
        wr_mcu_err_ctl(x, 0x010080);
    }
    no_mcu_ok = 1;
  }

  if (set_rd_trim) {
    for (y = 0; y < 4; y++) {
      if ((lvl_mcu < 0) || (y == lvl_mcu)) {
        for (x = 0; x < 8; x++) {
          if (is_mcu_active(y))
            set_rd_trim_delay(y, x, rd_trim);
        }
      }
    }
    no_mcu_ok = 1;
  }

  if (set_wr_trim) {
    for (y = 0; y < 4; y++) {
      if ((lvl_mcu < 0) || (y == lvl_mcu)) {
        for (x = 0; x < 9; x++) {
          if (is_mcu_active(y))
            set_wr_trim_delay(y, x, wr_trim);
        }
      }
    }
    no_mcu_ok = 1;
  }

  if (set_write_dq) {
    for (y = 0; y < 4; y++) {
      if ((lvl_mcu < 0) || (y == lvl_mcu)) {
        for (x = 0; x < 9; x++) {
          if (is_mcu_active(y) && (write_dq[x] >= 0)) {
            if (x4_nib <= 0) {
              set_write_dq_delay_x4(y, x, 0, write_dq[x]);
            }
            if (x4_nib != 0) {
              set_write_dq_delay_x4(y, x, 1, write_dq[x]);
            }
          }
        }
      }
    }
    no_mcu_ok = 1;
  }

  if ((lvl_mcu < 0) || (lvl_mcu > 3)) {
    // must set MCU
    if (!no_mcu_ok) {
      X__printf("Must set MCU\n");
      usage(opts);
      return (-1);
    }
    return (0);
  }

  for (x = 0; x < 4; x++) {
    int set = 0;
    for (y=0;y<9;y++) if (lvl[x][y] >= 0) set = 1;
    if (set) {
      if (x4_nib <= 0) {
        switch (lvl_type) {
          case LVL_RD:      set_rdlvl_delay_x4(lvl_mcu, x, 0, lvl[x]); break;
          case LVL_RD_GATE: set_rdlvl_gate_x4(lvl_mcu, x, 0, lvl[x]); break;
          case LVL_WR:      set_wrlvl_delay_x4(lvl_mcu, x, 0, lvl[x]); break;
          default: break;
        }
      }
      if (x4_nib != 0) {
        switch (lvl_type) {
          case LVL_RD:      set_rdlvl_delay_x4(lvl_mcu, x, 1, lvl[x]); break;
          case LVL_RD_GATE: set_rdlvl_gate_x4(lvl_mcu, x, 1, lvl[x]); break;
          case LVL_WR:      set_wrlvl_delay_x4(lvl_mcu, x, 1, lvl[x]); break;
          default: break;
        }
      }
    }
  }

  return (0);
}

static int32_t get_saved_lvl(uint64_t mcu, uint64_t rank, uint64_t byte, uint64_t offs, uint32_t x4)
{
  int32_t *rs = (x4 ? s_reg_state_x4 : s_reg_state);
  if ((rs == NULL) || (mcu > 3) || (rank > 3) || (byte > 8))
    return (-1);

  // 4 mcu, 4 ranks, 9 bytes
  return rs[((mcu*4) + rank)*9 + byte + offs];
}

int32_t get_saved_rdlvl(uint64_t mcu, uint64_t rank, uint64_t byte, uint32_t x4) {
  return get_saved_lvl(mcu, rank, byte, 4*4*9*0, x4);
}

int32_t get_saved_rdlvl_gate(uint64_t mcu, uint64_t rank, uint64_t byte, uint32_t x4) {
  return get_saved_lvl(mcu, rank, byte, 4*4*9*1, x4);
}

int32_t get_saved_wrlvl(uint64_t mcu, uint64_t rank, uint64_t byte, uint32_t x4) {
  return get_saved_lvl(mcu, rank, byte, 4*4*9*2, x4);
}

int32_t get_saved_write_dq(uint64_t mcu, uint64_t byte, uint32_t x4) {
  if (x4) {
    return s_reg_state_x4[4*4*9*3 + (mcu*9) + byte];
  } else {
    return s_reg_state[4*4*9*3 + (mcu*9) + byte];
  }
}

int32_t get_saved_vref(uint64_t mcu) {
    return s_reg_state[4*4*9*4 + (mcu*9)];
}


// Shmoo interface //

char *rdlvl_str(int64_t *r) {
  static char str[256];

  __snprintf(str, 256, "%d,%d,%d,%d,%d,%d,%d,%d,%d",
    r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8]);

  return (str);
}

static void set_lvl(char *type, int64_t mcu, int64_t rank, int64_t *rdlvl)
{
  int i, m;
  char cmd[256];
  int32_t cmd_offs;
  for (m = 0; m < 4; m++ ) {
    if (!is_mcu_active(m)) { continue; }

    if ((mcu < 0) || (mcu == m)) {
      cmd_offs = 0;
      for (i = 0; i < 4; i++ ) {
        if ((rank < 0) || (rank == i)) {
          cmd_offs += __snprintf((cmd + cmd_offs), (256-cmd_offs), " --lvl_rank%d %s ", i, rdlvl_str(rdlvl))-1;
        }
      }
      cmd_offs += __snprintf((cmd + cmd_offs), (256-cmd_offs), " --mcu %d --lvl %s ", m, type)-1;

      memreg(cmd);
    }
  }
  mcu_phy_rdfifo_reset_all();
}

void set_rdlvl(int64_t mcu, int64_t rank, int64_t *rdlvl) {
  set_lvl("rd", mcu, rank, rdlvl);
}

void set_rdlvl_g(int64_t mcu, int64_t rank, int64_t *rdlvl) {
  set_lvl("rd_gate", mcu, rank, rdlvl);
}

void set_wrlvl(int64_t mcu, int64_t rank, int64_t *rdlvl) {
  set_lvl("wr", mcu, rank, rdlvl);
}

void set_write_dq(int64_t mcu, int64_t rank, int64_t *dq)
{
  int m;
  char cmd[256];
  int32_t cmd_offs;
  for (m = 0; m < 4; m++ ) {
    if (!is_mcu_active(m)) { continue; }

    if ((mcu < 0) || (mcu == m)) {
      cmd_offs = 0;
      cmd_offs += __snprintf((cmd + cmd_offs), (256-cmd_offs), " --write_dq %s ", rdlvl_str(dq))-1;
      cmd_offs += __snprintf((cmd + cmd_offs), (256-cmd_offs), " --mcu %d ", m)-1;
      memreg(cmd);
    }
  }
}

/*
void set_trim(int64_t mcu, int64_t trim)
{
  char cmd[256];
  int32_t cmd_offs;
  cmd_offs = 0;
  cmd_offs += __snprintf((cmd + cmd_offs), (256-cmd_offs), " --mcu %d ", mcu)-1;
  cmd_offs += __snprintf((cmd + cmd_offs), (256-cmd_offs), " --rd_trim %d,%d,%d,%d,%d,%d,%d,%d ",
    trim, trim, trim, trim, trim, trim, trim, trim)-1;
  memreg(cmd);
}
*/

void set_trim(int rdlvl, int64_t trim)
{
  int b, m;
  int32_t trim_data[8];

  for (b = 0; b < 8; b++)
    trim_data[b] = trim;

  for (m = 0; m < 4; m++) {
    if (is_mcu_active(m)) {
      for (b = 0; b < 8; b++) {
        if (rdlvl) {
          set_rd_trim_delay(m, b, trim_data);
        } else {
          set_wr_trim_delay(m, b, trim_data);
        }
      }
    }
  }
}

// stubs to cover parameters on other chips
void set_rdlvl_rise(int64_t mcu, int64_t rank, int64_t *rdlvl) { }
void set_rdlvl_fall(int64_t mcu, int64_t rank, int64_t *rdlvl) { }

int set_rdlvl_rise_offset(int32_t mcu, int32_t rank, int32_t lvl) { return 0; }
int set_rdlvl_fall_offset(int32_t mcu, int32_t rank, int32_t lvl) { return 0; }


