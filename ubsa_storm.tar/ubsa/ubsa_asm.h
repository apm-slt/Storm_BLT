/* Copyright (c) 2014 by Veloce Technologies.  All Rights Reserved. */
/* $Id: //depot/projects/osboot/MAIN/ubsa/ubsa_asm.h#1 $ */

#ifndef __UBSA_ASM_H__
#define __UBSA_ASM_H__


  .macro  push, xreg1, xreg2
  stp \xreg1, \xreg2, [sp, #-16]!
  .endm

  .macro  pop, xreg1, xreg2
  ldp \xreg1, \xreg2, [sp], #16
  .endm

  lr  .req  x30 // link register

  #define S_FRAME_SIZE 272

  #define S_LR 256
  #define S_PC 240

  .macro  UB_kernel_entry, el
  sub sp, sp, 32 // #S_FRAME_SIZE - S_LR  // room for LR, SP, SPSR, ELR
  push  x28, x29
  push  x26, x27
  push  x24, x25
  push  x22, x23
  push  x20, x21
  push  x18, x19
  push  x16, x17
  push  x14, x15
  push  x12, x13
  push  x10, x11
  push  x8, x9
  push  x6, x7
  push  x4, x5
  push  x2, x3
  push  x0, x1
  .if \el == 0
  mrs x21, sp_el0
  .else
  add x21, sp, #S_FRAME_SIZE
  .endif
  mrs x22, elr_el1
  mrs x23, spsr_el1
  stp lr, x21, [sp, #S_LR]
  stp x22, x23, [sp, #S_PC]

  /*
   * Set syscallno to -1 by default (overridden later if real syscall).
   */
  .if \el == 0
  mvn x21, xzr
  str x21, [sp, #S_SYSCALLNO]
  .endif

  /*
   * Registers that may be useful after this macro is invoked:
   *
   * x21 - aborted SP
   * x22 - aborted PC
   * x23 - aborted PSTATE
  */
  .endm

  .macro  kernel_exit, el, ret = 0
  ldp x21, x22, [sp, #S_PC]   // load ELR, SPSR
  .if \el == 0
  ldr x23, [sp, #S_SP]    // load return stack pointer
  .endif
  .if \ret
  ldr x1, [sp, #S_X1]     // preserve x0 (syscall return)
  add sp, sp, S_X2
  .else
  pop x0, x1
  .endif
  pop x2, x3        // load the rest of the registers
  pop x4, x5
  pop x6, x7
  pop x8, x9
  msr elr_el1, x21      // set up the return data
  msr spsr_el1, x22
  .if \el == 0
  msr sp_el0, x23
  .endif
  pop x10, x11
  pop x12, x13
  pop x14, x15
  pop x16, x17
  pop x18, x19
  pop x20, x21
  pop x22, x23
  pop x24, x25
  pop x26, x27
  pop x28, x29
  ldr lr, [sp], #S_FRAME_SIZE - S_LR  // load LR and restore SP
  eret          // return to kernel
  .endm




.macro load_reg64 reg, val
  movz \reg, #(\val & 0xFFFF)
  .if \val >= (1 << 16)
    movk  \reg, #((\val >> 16) & 0xFFFF), lsl #16
  .endif
  .if \val >= (1 << 32)
    movk  \reg, #((\val >> 32) & 0xFFFF), lsl #32
  .endif
  .if \val >= (1 << 48)
    movk  \reg, #((\val >> 48) & 0xFFFF), lsl #48
  .endif
.endm








#endif // __UBSA_ASM_H__

