/* Copyright (c) 2014 by Veloce Technologies.  All Rights Reserved. */
/* $Id: //depot/projects/osboot/MAIN/ubsa/ubsa_readline.c#1 $ */

#include "bbcutils.h"

#ifndef NULL
#define NULL ((void*)0)
#endif

#define CONFIG_SYS_CBSIZE 256

static const char erase_seq[] = "\b \b";    /* erase sequence */
static const char   tab_seq[] = "        ";   /* used to expand TABs  */

/*
 * cmdline-editing related codes from vivi.
 * Author: Janghoon Lyu <nandy@mizi.com>
 */

void putnstr(char *str, unsigned long n);

#define CTL_CH(c)   ((c) - 'a' + 1)
#define CTL_BACKSPACE   ('\b')
#define DEL     ((char)255)
#define DEL7      ((char)127)
#define CREAD_HIST_CHAR   ('!')

#define getcmd_putch(ch)  putc(ch)
#define getcmd_getch()    getc()
#define getcmd_cbeep()    getcmd_putch('\a')

#define HIST_MAX    20
#define HIST_SIZE   CONFIG_SYS_CBSIZE

static int hist_max;
static int hist_add_idx;
static int hist_cur = -1;
static unsigned hist_num;

static char *hist_list[HIST_MAX];
static char hist_lines[HIST_MAX][HIST_SIZE + 1];  /* Save room for NULL */

#define add_idx_minus_one() ((hist_add_idx == 0) ? hist_max : hist_add_idx-1)

static void hist_init(void)
{
  int i;

  hist_max = 0;
  hist_add_idx = 0;
  hist_cur = -1;
  hist_num = 0;

  for (i = 0; i < HIST_MAX; i++) {
    hist_list[i] = hist_lines[i];
    hist_list[i][0] = '\0';
  }
}

static void cread_add_to_hist(char *line)
{
  strcpy(hist_list[hist_add_idx], line);

  if (++hist_add_idx >= HIST_MAX)
    hist_add_idx = 0;

  if (hist_add_idx > hist_max)
    hist_max = hist_add_idx;

  hist_num++;
}

static char* hist_prev(void)
{
  char *ret;
  int old_cur;

  if (hist_cur < 0)
    return NULL;

  old_cur = hist_cur;
  if (--hist_cur < 0)
    hist_cur = hist_max;

  if (hist_cur == hist_add_idx) {
    hist_cur = old_cur;
    ret = NULL;
  } else
    ret = hist_list[hist_cur];

  return (ret);
}

static char* hist_next(void)
{
  char *ret;

  if (hist_cur < 0)
    return NULL;

  if (hist_cur == hist_add_idx)
    return NULL;

  if (++hist_cur > hist_max)
    hist_cur = 0;

  if (hist_cur == hist_add_idx) {
    ret = "";
  } else
    ret = hist_list[hist_cur];

  return (ret);
}

#define BEGINNING_OF_LINE() {     \
  while (num) {       \
    getcmd_putch(CTL_BACKSPACE);  \
    num--;        \
  }         \
}

#define ERASE_TO_EOL() {        \
  if (num < eol_num) {        \
    int _i; \
    for (_i=0;_i<(eol_num - num); _i++) { \
      getcmd_putch(' '); \
    } \
    do {          \
      getcmd_putch(CTL_BACKSPACE);  \
    } while (--eol_num > num);    \
  }           \
}

#define REFRESH_TO_EOL() {      \
  if (num < eol_num) {      \
    wlen = eol_num - num;   \
    putnstr(buf + num, wlen); \
    num = eol_num;      \
  }         \
}

static void cread_add_char(char ichar, int insert, unsigned long *num,
         unsigned long *eol_num, char *buf, unsigned long len)
{
  unsigned long wlen;

  /* room ??? */
  if (insert || *num == *eol_num) {
    if (*eol_num > len - 1) {
      getcmd_cbeep();
      return;
    }
    (*eol_num)++;
  }

  if (insert) {
    wlen = *eol_num - *num;
    if (wlen > 1) {
      memmove(&buf[*num+1], &buf[*num], wlen-1);
    }

    buf[*num] = ichar;
    putnstr(buf + *num, wlen);
    (*num)++;
    while (--wlen) {
      getcmd_putch(CTL_BACKSPACE);
    }
  } else {
    /* echo the character */
    wlen = 1;
    buf[*num] = ichar;
    putnstr(buf + *num, wlen);
    (*num)++;
  }
}

static void cread_add_str(char *str, int strsize, int insert, unsigned long *num,
        unsigned long *eol_num, char *buf, unsigned long len)
{
  while (strsize--) {
    cread_add_char(*str, insert, num, eol_num, buf, len);
    str++;
  }
}

int cread_line(const char *const prompt, char *buf, unsigned int *len)
{
  unsigned long num;
  unsigned long eol_num;
  unsigned long wlen;
  char ichar;
  int insert;
  int esc_len;
  char esc_save[8];
  int init_len;

  num = 0;
  eol_num = 0;
  insert = 1;
  esc_len = 0;
  init_len = strnlen(buf, CONFIG_SYS_CBSIZE);

  if (init_len)
    cread_add_str(buf, init_len, 1, &num, &eol_num, buf, *len);

  while (1) {
/*
#ifdef CONFIG_BOOT_RETRY_TIME
    while (!tstc()) { // while no incoming data
      if (retry_time >= 0 && get_ticks() > endtime)
        return (-2);  // timed out
      WATCHDOG_RESET();
    }
#endif
    if (first && timeout) {
      uint64_t etime = endtick(timeout);

      while (!tstc()) { // while no incoming data
        if (get_ticks() >= etime)
          return -2;  // timed out
        WATCHDOG_RESET();
      }
      first = 0;
    }
*/
    ichar = getcmd_getch();

    if ((ichar == '\n') || (ichar == '\r')) {
      putc('\n');
      break;
    }

    /*
     * handle standard linux xterm esc sequences for arrow key, etc.
     */
    if (esc_len != 0) {
      if (esc_len == 1) {
        if (ichar == '[') {
          esc_save[esc_len] = ichar;
          esc_len = 2;
        } else {
          cread_add_str(esc_save, esc_len, insert,
                  &num, &eol_num, buf, *len);
          esc_len = 0;
        }
        continue;
      }

      switch (ichar) {

      case 'D': /* <- key */
        ichar = CTL_CH('b');
        esc_len = 0;
        break;
      case 'C': /* -> key */
        ichar = CTL_CH('f');
        esc_len = 0;
        break;  /* pass off to ^F handler */
      case 'H': /* Home key */
        ichar = CTL_CH('a');
        esc_len = 0;
        break;  /* pass off to ^A handler */
      case 'A': /* up arrow */
        ichar = CTL_CH('p');
        esc_len = 0;
        break;  /* pass off to ^P handler */
      case 'B': /* down arrow */
        ichar = CTL_CH('n');
        esc_len = 0;
        break;  /* pass off to ^N handler */
      default:
        esc_save[esc_len++] = ichar;
        cread_add_str(esc_save, esc_len, insert,
                &num, &eol_num, buf, *len);
        esc_len = 0;
        continue;
      }
    }

    switch (ichar) {
    case 0x1b:
      if (esc_len == 0) {
        esc_save[esc_len] = ichar;
        esc_len = 1;
      } else {
        puts("impossible condition #876\n");
        esc_len = 0;
      }
      break;

    case CTL_CH('a'):
      BEGINNING_OF_LINE();
      break;
    case CTL_CH('c'): /* ^C - break */
      *buf = '\0';  /* discard input */
      return (-1);
    case CTL_CH('f'):
      if (num < eol_num) {
        getcmd_putch(buf[num]);
        num++;
      }
      break;
    case CTL_CH('b'):
      if (num) {
        getcmd_putch(CTL_BACKSPACE);
        num--;
      }
      break;
    case CTL_CH('d'):
      if (num < eol_num) {
        wlen = eol_num - num - 1;
        if (wlen) {
          memmove(&buf[num], &buf[num+1], wlen);
          putnstr(buf + num, wlen);
        }

        getcmd_putch(' ');
        do {
          getcmd_putch(CTL_BACKSPACE);
        } while (wlen--);
        eol_num--;
      }
      break;
    case CTL_CH('k'):
      ERASE_TO_EOL();
      break;
    case CTL_CH('e'):
      REFRESH_TO_EOL();
      break;
    case CTL_CH('o'):
      insert = !insert;
      break;
    case CTL_CH('x'):
    case CTL_CH('u'):
      BEGINNING_OF_LINE();
      ERASE_TO_EOL();
      break;
    case DEL:
    case DEL7:
    case 8:
      if (num) {
        wlen = eol_num - num;
        num--;
        memmove(&buf[num], &buf[num+1], wlen);
        getcmd_putch(CTL_BACKSPACE);
        putnstr(buf + num, wlen);
        getcmd_putch(' ');
        do {
          getcmd_putch(CTL_BACKSPACE);
        } while (wlen--);
        eol_num--;
      }
      break;
    case CTL_CH('p'):
    case CTL_CH('n'):
    {
      char * hline;

      esc_len = 0;

      if (ichar == CTL_CH('p'))
        hline = hist_prev();
      else
        hline = hist_next();

      if (!hline) {
        getcmd_cbeep();
        continue;
      }

      /* nuke the current line */
      /* first, go home */
      BEGINNING_OF_LINE();

      /* erase to end of line */
      ERASE_TO_EOL();

      /* copy new line into place and display */
      strcpy(buf, hline);
      eol_num = strlen(buf);
      REFRESH_TO_EOL();
      continue;
    }
#ifdef CONFIG_AUTO_COMPLETE
    case '\t': {
      int num2, col;

      /* do not autocomplete when in the middle */
      if (num < eol_num) {
        getcmd_cbeep();
        break;
      }

      buf[num] = '\0';
      col = strlen(prompt) + eol_num;
      num2 = num;
      if (cmd_auto_complete(prompt, buf, &num2, &col)) {
        col = num2 - num;
        num += col;
        eol_num += col;
      }
      break;
    }
#endif
    default:
      cread_add_char(ichar, insert, &num, &eol_num, buf, *len);
      break;
    }
  }
  *len = eol_num;
  buf[eol_num] = '\0';  /* lose the newline */

  if (buf[0] && (buf[0] != CREAD_HIST_CHAR))
    cread_add_to_hist(buf);

  hist_cur = hist_add_idx;

  return 0;
}


/*
 * Prompt for input and read a line.
 * If  CONFIG_BOOT_RETRY_TIME is defined and retry_time >= 0,
 * time out when time goes past endtime (timebase time in ticks).
 * Return:  number of read characters
 *    -1 if break
 *    -2 if timed out
 */

int readline_into_buffer(const char *const prompt, char *buffer, uint32_t len)
{
  unsigned int l;
  int rc;
  static int initted = 0;

  if (!initted) {
    hist_init();
    initted = 1;
  }

  if (prompt)
    puts (prompt);

  l = len;

  rc = cread_line(prompt, buffer, &l);
  return ((rc < 0) ? rc : l);

}

/****************************************************************************/
/*
static char * delete_char (char *buffer, char *p, int *colp, int *np, int plen);
static char * delete_char (char *buffer, char *p, int *colp, int *np, int plen)
{
  char *s;

  if (*np == 0) {
    return (p);
  }

  if (*(--p) == '\t') {     // will retype the whole line
    while (*colp > plen) {
      puts (erase_seq);
      (*colp)--;
    }
    for (s=buffer; s<p; ++s) {
      if (*s == '\t') {
        puts (tab_seq+((*colp) & 07));
        *colp += 8 - ((*colp) & 07);
      } else {
        ++(*colp);
        putc (*s);
      }
    }
  } else {
    puts (erase_seq);
    (*colp)--;
  }
  (*np)--;
  return (p);
}
*/
/****************************************************************************/

// return "-1" on successful completion, "?" on error or option not found
int ubsa_getopt_long(char *arg_string, ubsa_long_options_s *opts, int *option_idx, char **tmp_var)
{
  int i;
  char *str;

  str = ubsa_strtok(arg_string, " ", tmp_var);

  if (str == NULL)
    return (-1);

  // must be at least "-a"
  if (strlen(str) < 2) {
    X__printf("Invalid option: '%s'\n", str);
    return ('?');
  }

  if (str[0] != '-') {
    X__printf("Invalid option: '%s'\n", str);
    return ('?');
  }

  *option_idx = -1;
  if (str[1] == '-') {
    // long opt
    for (i = 0; opts[i].longopt != NULL; i++) {
      if (strcmp((str+2), opts[i].longopt) == 0) {
        *option_idx = i;
        break;
      }
    }
  } else {
    // short opt
    for (i = 0; opts[i].longopt != NULL; i++) {
      if (str[1] == opts[i].shortopt) {
        *option_idx = i;
        break;
      }
    }
  }

  if (*option_idx == -1) {
    X__printf("Option not found: '%s'\n", str);
    return ('?');
  }

  // '--' option is special
  if (strcmp("--", str) == 0) {
    char **p = (char **)opts[*option_idx].param;
    *p = *tmp_var;
    *tmp_var = NULL; // consume the rest of the line
    return (opts[*option_idx].shortopt);
  }

  if (opts[*option_idx].need_arg) {
    str = ubsa_strtok(NULL, " ", tmp_var);
    if (str == NULL) {
      X__printf("Option needs arg: '%s'\n", opts[*option_idx].longopt);
      return ('?');
    }

    switch (opts[*option_idx].type) {
      case OPT_STRING: {
        char **p = (char **)opts[*option_idx].param;
        *p = str;
        } break;
      case OPT_UINT64: {
        uint64_t *p = (uint64_t *)opts[*option_idx].param;
        *p = simple_strtoull(str, NULL, 0);
        } break;
      case OPT_INT64: {
        int64_t *p = (int64_t *)opts[*option_idx].param;
        *p = simple_strtoll(str, NULL, 0);
        } break;
      case OPT_UINT32: {
        uint32_t *p = (uint32_t *)opts[*option_idx].param;
        *p = simple_strtoul(str, NULL, 0);
        } break;
      case OPT_INT32: {
        int32_t *p = (int32_t *)opts[*option_idx].param;
        *p = simple_strtol(str, NULL, 0);
        } break;
      case OPT_MEMSIZE: {
        uint64_t *p = (uint64_t *)opts[*option_idx].param;
        *p = ustrtoull(str, NULL, 0);
        } break;
    }
  } else {
    switch (opts[*option_idx].type) {
      case OPT_UINT64:
      case OPT_INT64: {
        uint64_t *p = (uint64_t *)opts[*option_idx].param;
        *p = opts[*option_idx].arg_val;
        } break;
      case OPT_UINT32:
      case OPT_INT32: {
        uint32_t *p = (uint32_t *)opts[*option_idx].param;
        *p = opts[*option_idx].arg_val;
        } break;
      default:
        X__printf("Flag should be int type: '%s'\n", opts[*option_idx].longopt);
        return ('?');
    }
  }

  return (opts[*option_idx].shortopt);
}



void ubsa_getopt_usage(ubsa_long_options_s *opts)
{
  int i = 0;
  for (i = 0; (i < 25) && (opts[i].longopt != NULL); i++) {
    char *type;
    switch (opts[i].type) {
      case OPT_STRING: type = "str"; break;
      case OPT_UINT64: type = "u64"; break;
      case OPT_INT64:  type = "i64"; break;
      case OPT_UINT32: type = "u32"; break;
      case OPT_INT32:  type = "i32"; break;
      case OPT_MEMSIZE:type = "mem{G:M:K}"; break;
      default:         type = "unknown"; break;
    }
    if (opts[i].need_arg) {
      X__printf("\t--%s (-%c) <%s> \"%s\"\n", opts[i].longopt, opts[i].shortopt, type, opts[i].desc);
    } else {
      X__printf("\t--%s (-%c) \"%s\" (= %d)\n", opts[i].longopt, opts[i].shortopt, opts[i].desc, opts[i].arg_val);
    }
  }
}



