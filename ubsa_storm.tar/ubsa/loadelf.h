/* Copyright (c) 2014 by Veloce Technologies.  All Rights Reserved. */
/* $Id: //depot/projects/osboot/MAIN/ubsa/loadelf.h#1 $ */

#ifndef __LOADELF_H__
#define __LOADELF_H__


typedef uint32_t elf64_addr_;
typedef uint32_t elf64_off_;
typedef uint16_t elf64_half;
typedef uint32_t elf64_word;
typedef int32_t  elf64_sword;
typedef uint32_t elf64_xword_;
typedef int32_t  elf64_sxword_;
typedef uint8_t  elf64_char;

typedef uint32_t elf32_addr;
typedef uint16_t elf32_half;
typedef uint32_t elf32_off;
typedef int32_t  elf32_sword;
typedef uint32_t elf32_word;
typedef uint8_t  elf32_char;

#define EI_NIDENT 16


struct elf32_ehdr
{
    elf32_char      e_ident[ EI_NIDENT ];   // for idenification in elf object files
    elf32_half      e_type;                 // identifies object file type
    elf32_half      e_machine;              // hardware type for which object file is build
    elf32_word      e_version;              // holds current version
    elf32_addr      e_entry;                // virtual adress start of object file, if none, zero
    elf32_off       e_phoff;                // offset of program's header information table. if none, zero
    elf32_off       e_shoff;                // offset of program's section information table. if none, zero
    elf32_word      e_flags;                // machine dependent flags, in intel zero
    elf32_half      e_ehsize;               // elf header size in bytes
    elf32_half      e_phentsize;            // number of bytes of one entry in programs header table
    elf32_half      e_phnum;                // number of entries in programs header table
    elf32_half      e_shentsize;            // number of bytes of one entry in programs section table
    elf32_half      e_shnum;                // number of entries in programs section table
    elf32_half      e_shstrndx;             // section header table index of the section name string table
};

struct elf64_ehdr
{
    elf64_char      e_ident[ EI_NIDENT ];   // for idenification in elf object files
    elf64_half      e_type;                 // identifies object file type
    elf64_half      e_machine;              // hardware type for which object file is build
    elf64_word      e_version;              // holds current version
    elf64_addr_     e_entry_[2];            // virtual adress start of object file, if none, zero
    elf64_off_      e_phoff_[2];            // offset of program's header information table. if none, zero
    elf64_off_      e_shoff_[2];            // offset of program's section information table. if none, zero
    elf64_word      e_flags;                // machine dependent flags, in intel zero
    elf64_half      e_ehsize;               // elf header size in bytes
    elf64_half      e_phentsize;            // number of bytes of one entry in programs header table
    elf64_half      e_phnum;                // number of entries in programs header table
    elf64_half      e_shentsize;            // number of bytes of one entry in programs section table
    elf64_half      e_shnum;                // number of entries in programs section table
    elf64_half      e_shstrndx;             // section header table index of the section name string table
};

// definitions used in "e_type"
#define ET_NONE         0
#define ET_REL          1
#define ET_EXEC         2
#define ET_DYN          3
#define ET_CORE         4
#define ET_LOPROC       0xFF00
#define ET_HIPROC       0XFFFF

// definintions used in "e_machine"
#define EM_NONE         0       // no machine
#define EM_M32          1       // AT&T WE32100
#define EM_SPARC        2       // SPARC
#define EM_386          3       // intel x86
#define EM_68K          4       // motorola 68000
#define EM_88k          5       // motorola 88000
#define EM_860          7       // intel 80860
#define EM_MIPS         8       // MIPS RS3000
#define EM_ARM          40      // ARM

// definitions used in "e_version"
#define EV_NONE         0       // invalid version
#define EV_CURRENT      1       // current version of the opject file

// next definitions hold values that describe a position in "e_ident[]"
#define EI_MAG0         0       // file identification
#define EI_MAG1         1       //      "
#define EI_MAG2         2       //      "
#define EI_MAG3         3       //      "
#define EI_CLASS        4       // file class
#define EI_DATA         5       // data encoding
#define EI_VERSION      6       // file version, should be EV_CURRENT
#define EI_PAD          7       // start of padding bytes
#define EI_NIDENT       16      // size of e_ident[]

// values indexed by above definitions

// for elf identification
#define ELFMAG0         0x7F    // position: e_ident[ EI_MAG0 ]
#define ELFMAG1         'E'     // position: e_ident[ EI_MAG1 ]
#define ELFMAG2         'L'     // position: e_ident[ EI_MAG2 ]
#define ELFMAG3         'F'     // position: e_ident[ EI_MAG3 ]

// for file class
#define ELFCLASSNONE    0       // invalid class
#define ELFCLASS32      1       // 32bit objects        (for intel32)
#define ELFCLASS64      2       // 64bit objects

// for data encoding
#define ELFDATANONE     0       // invalid data encoding
#define ELFDATA2LSB     1       // (for intel32) - little endian
#define ELFDATA2MSB     2       // (for 68000) - big endian


// program header

// structure that stores information about an process's memory image
struct elf32_phdr
{
    elf32_word      p_type;
    elf32_off       p_offset;
    elf32_addr      p_vaddr;
    elf32_addr      p_paddr;
    elf32_word      p_filesz;
    elf32_word      p_memsz;
    elf32_word      p_flags;
    elf32_word      p_align;
};

struct elf64_phdr
{
    elf64_word      p_type;
    elf64_word      p_flags;
    elf64_off_      p_offset_[2];
    elf64_addr_     p_vaddr_[2];
    elf64_addr_     p_paddr_[2];
    elf64_xword_    p_filesz_[2];
    elf64_xword_    p_memsz_[2];
    elf64_xword_    p_align_[2];
};


// segment types
#define PT_NULL         0
#define PT_LOAD         1
#define PT_DYNAMIC      2
#define PT_INTERP       3
#define PT_NOTE         4
#define PT_SHLIB        5
#define PT_PHDR         6
#define PT_TLS          7
#define PT_ARM_ARCHEXT  0x70000000
#define PT_ARM_EXIDX    0x70000001


// section table stuff


// special section indexes
#define SHN_UNDEF       0       // marks an undefined or missing section reference
#define SHN_LORESERVE   0xFF00  // lower bound of range of reserved bytes
#define SHN_LOPROC      0xFF00  // reserved for processors specific semantics
#define SHN_HIPROC      0xFF1F  //                      "
#define SHN_ABS         0xFFF1  // absolute values for corresponding reference
#define SHN_COMMON      0xFFF2  // common sysmbols
#define SHN_HIRESERVE   0xFFFF  // upper bound of range of reserved bytes



// struct elf32_shdr describes the header for one section in an elf file

struct elf32_shdr
{
    elf32_word      sh_name;        // specifies the name of the section
    elf32_word      sh_type;        // section contents
    elf32_word      sh_flags;       // various attributes to the section
    elf32_addr      sh_addr;        // if in memory, this member gives the adress of the first byte
    elf32_off       sh_offset;      // offset from beginning of the file to first byte in the setion
    elf32_word      sh_size;        // section size in bytes
    elf32_word      sh_link;
    elf32_word      sh_info;        // extra information
    elf32_word      sh_addralign;   // alignment
    elf32_word      sh_entsize;
};

struct elf64_shdr
{
    elf64_word      sh_name;        // specifies the name of the section
    elf64_word      sh_type;        // section contents
    elf64_xword_    sh_flags_[2];   // various attributes to the section
    elf64_addr_     sh_addr_[2];    // if in memory, this member gives the adress of the first byte
    elf64_off_      sh_offset_[2];  // offset from beginning of the file to first byte in the setion
    elf64_xword_    sh_size_[2];    // section size in bytes
    elf64_word      sh_link;
    elf64_word      sh_info;        // extra information
    elf64_xword_    sh_addralign_[2];// alignment
    elf64_xword_    sh_entsize_[2];
};


// special section types
#define SHT_NULL        0
#define SHT_PROGBITS    1
#define SHT_SYMTAB      2
#define SHT_STRTAB      3
#define SHT_RELA        4
#define SHT_HASH        5
#define SHT_DYNAMIC     6
#define SHT_NOTE        7
#define SHT_NOBITS      8
#define SHT_REL         9
#define SHT_SHLIB       10
#define SHT_DYNSYM      11
#define SHT_LOPROC      0x70000000
#define SHT_HIPROC      0x7FFFFFFF
#define SHT_LOUSER      0x80000000
#define SHT_HIUSER      0xFFFFFFFF

// section attribute flags
#define SHF_WRITE       0x1
#define SHF_ALLOC       0x2
#define SHF_EXECINSTR   0x4
#define SHF_MASKPROC    0xF0000000


// symbol table stuff

#define STN_UNDEF       0

struct elf32_sym
{
    elf32_word      st_name;
    elf32_addr      st_value;
    elf32_word      st_size;
    elf32_char      st_info;
    elf32_char      st_other;       // always zero
    elf32_half      st_shndx;
};

struct elf64_sym
{
    elf64_word      st_name;
    elf64_char      st_info;
    elf64_char      st_other;       // always zero
    elf64_half      st_shndx;
    elf64_addr_     st_value_[2];
    elf64_xword_    st_size_[2];
};


// some operations on struct elf32_sym
/*
template<typename T>
inline T ELF32_ST_BIND( T i ) {
    return ( i >> 4 );
}
template<typename T>
inline T ELF32_ST_TYPE( T i ) {
    return ( i & 0xF );
}
template<typename T>
inline T ELF32_ST_INFO( T b, T t ) {
    return ( ( b << 4 ) + ( t & 0xF ) );
}
*/

// values for above operations

// for ELF32_ST_BIND
#define STB_LOCAl       0
#define STB_GLOBAL      1
#define STB_WEAK        2
#define STB_LOPROC      13
#define STB_HIPROC      15

// for ELF32_ST_TYPE
#define STT_NOTYPE      0
#define STT_OBJECT      1
#define STT_FUNC        2
#define STT_SECTION     3
#define STT_FILE        4
#define STT_LOPROC      13
#define STT_HIPROC      15


// relocation entries

struct elf32_rel
{
    elf32_addr      r_offset;
    elf32_word      r_info;
};

struct elf64_rel
{
    elf64_addr_     r_offset_[2];
    elf64_xword_    r_info_[2];
};

struct elf32_rela
{
    elf32_addr      r_offset;
    elf32_word      r_info;
    elf32_sword     r_addend;
};

struct elf64_rela
{
    elf64_addr_     r_offset_[2];
    elf64_xword_    r_info_[2];
    elf64_sxword_   r_addend_[2];
};


// some operations on above structres
#define ELF32_R_SYM(i)          ((i)>>8)
#define ELF32_R_TYPE(i)         ((unsigned char)i)
#define ELF32_R_INFO(s,t)       (((s)<<8)+(unsigned char)(t))

// relocation types
#define R_386_NONE      0
#define R_386_32        1
#define R_386_PC32      2
#define R_386_GOT32     3
#define R_386_PLT32     4
#define R_386_COPY      5
#define R_386_GLOB_DAT  6
#define R_386_JMP_SLOT  7
#define R_386_RELATIVE  8
#define R_386_GOTOFF    9
#define R_386_GOTPC     10



struct tar_header
{                              /* byte offset */
  char name[100];               /*   0 */
  char mode[8];                 /* 100 */
  char uid[8];                  /* 108 */
  char gid[8];                  /* 116 */
  char size[12];                /* 124 */
  char mtime[12];               /* 136 */
  char chksum[8];               /* 148 */
  char typeflag;                /* 156 */
  char linkname[100];           /* 157 */
  char magic[6];                /* 257 */
  char version[2];              /* 263 */
  char uname[32];               /* 265 */
  char gname[32];               /* 297 */
  char devmajor[8];             /* 329 */
  char devminor[8];             /* 337 */
  char prefix[155];             /* 345 */
                                /* 500 */
};


#endif // __LOADELF_H__


