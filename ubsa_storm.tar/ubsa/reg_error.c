/* Copyright (c) 2014 by Veloce Technologies.  All Rights Reserved. */
/* $Id: //depot/projects/osboot/MAIN/ubsa/reg_error.c#2 $ */

#include "bbcutils.h"

//------------------------------------------------------------------------------
// error configuration code
// TODO Iob, L3c, Mcu errors
//------------------------------------------------------------------------------

#define PCP_RB_CPU0_CPU_PAGE        0xC
#define PCP_RB_CPU0_L2C_PAGE        0xD
#define PCP_RB_CPU0_MEMERR_L2C_PAGE 0xE
#define PCP_RB_CPU0_MEMERR_CPU_PAGE 0xF

#define PCP_RB_CPUX_MEMERR_CPU_MMUECR_PAGE_OFFSET 0x04
#define PCP_RB_CPUX_MEMERR_CPU_MMUESR_PAGE_OFFSET 0x05
#define PCP_RB_CPUX_MEMERR_CPU_MMUESRA_PAGE_OFFSET 0x205
#define PCP_RB_CPUX_MEMERR_CPU_ICFECR_PAGE_OFFSET 0x00
#define PCP_RB_CPUX_MEMERR_CPU_ICFESR_PAGE_OFFSET 0x01
#define PCP_RB_CPUX_MEMERR_CPU_ICFESRA_PAGE_OFFSET 0x201
#define PCP_RB_CPUX_MEMERR_CPU_LSUECR_PAGE_OFFSET 0x02
#define PCP_RB_CPUX_MEMERR_CPU_LSUESR_PAGE_OFFSET 0x03
#define PCP_RB_CPUX_MEMERR_CPU_LSUESRA_PAGE_OFFSET 0x203

#define PCP_RB_CPUX_MEMERR_L2C_L2EAHR_PAGE_OFFSET 0x03
#define PCP_RB_CPUX_MEMERR_L2C_L2EALR_PAGE_OFFSET 0x02
#define PCP_RB_CPUX_MEMERR_L2C_L2ECR_PAGE_OFFSET 0x00
#define PCP_RB_CPUX_MEMERR_L2C_L2ESR_PAGE_OFFSET 0x01
#define PCP_RB_CPUX_MEMERR_L2C_L2ESRA_PAGE_OFFSET 0x201

#define PCP_RB_CPUX_L2C_L2RTOAHR_PAGE_OFFSET     0x07
#define PCP_RB_CPUX_L2C_L2RTOALR_PAGE_OFFSET     0x06
#define PCP_RB_CPUX_L2C_L2RTOCR_PAGE_OFFSET      0x04
#define PCP_RB_CPUX_L2C_L2RTOSR_PAGE_OFFSET      0x05


void clear_l2_errors(uint32_t __pmd_id) {
  write_rb(PCP_RB_CPU0_MEMERR_L2C_PAGE+0x20*__pmd_id, PCP_RB_CPUX_MEMERR_L2C_L2ESRA_PAGE_OFFSET, 0);
  write_rb(PCP_RB_CPU0_MEMERR_L2C_PAGE+0x20*__pmd_id, PCP_RB_CPUX_MEMERR_L2C_L2EALR_PAGE_OFFSET, 0);
  write_rb(PCP_RB_CPU0_MEMERR_L2C_PAGE+0x20*__pmd_id, PCP_RB_CPUX_MEMERR_L2C_L2EAHR_PAGE_OFFSET, 0);
}

void clear_l2_rtos(uint32_t __pmd_id) {
  write_rb(PCP_RB_CPU0_L2C_PAGE+0x20*__pmd_id, PCP_RB_CPUX_L2C_L2RTOSR_PAGE_OFFSET, 0);
  write_rb(PCP_RB_CPU0_L2C_PAGE+0x20*__pmd_id, PCP_RB_CPUX_L2C_L2RTOAHR_PAGE_OFFSET, 0);
  write_rb(PCP_RB_CPU0_L2C_PAGE+0x20*__pmd_id, PCP_RB_CPUX_L2C_L2RTOALR_PAGE_OFFSET, 0);
}

void clear_lsu_errors(uint32_t __pmd_id, uint32_t __cpu_id) {
  write_rb(PCP_RB_CPU0_MEMERR_CPU_PAGE+0x20*__pmd_id+0x10*__cpu_id, PCP_RB_CPUX_MEMERR_CPU_LSUESRA_PAGE_OFFSET, 0);
}

void clear_icf_errors(uint32_t __pmd_id, uint32_t __cpu_id) {
  write_rb(PCP_RB_CPU0_MEMERR_CPU_PAGE+0x20*__pmd_id+0x10*__cpu_id, PCP_RB_CPUX_MEMERR_CPU_ICFESRA_PAGE_OFFSET, 0);
}

void clear_mmu_errors(uint32_t __pmd_id, uint32_t __cpu_id) {
  write_rb(PCP_RB_CPU0_MEMERR_CPU_PAGE+0x20*__pmd_id+0x10*__cpu_id, PCP_RB_CPUX_MEMERR_CPU_MMUESRA_PAGE_OFFSET, 0);
}

#define PCP_RB_CPUX_MEMERR_L2C_L2ECR_TAGERREN_BIT 10
#define PCP_RB_CPUX_MEMERR_L2C_L2ECR_TAGERREN_LEN 1
#define PCP_RB_CPUX_MEMERR_L2C_L2ECR_DATAERREN_BIT 9
#define PCP_RB_CPUX_MEMERR_L2C_L2ECR_DATAERREN_LEN 1
#define PCP_RB_CPUX_MEMERR_L2C_L2ECR_SDBERREN_BIT 8
#define PCP_RB_CPUX_MEMERR_L2C_L2ECR_SDBERREN_LEN 1
#define PCP_RB_CPUX_MEMERR_L2C_L2ECR_UCINTREN_BIT 1
#define PCP_RB_CPUX_MEMERR_L2C_L2ECR_UCINTREN_LEN 1
#define PCP_RB_CPUX_MEMERR_L2C_L2ECR_CINTREN_BIT 0
#define PCP_RB_CPUX_MEMERR_L2C_L2ECR_CINTREN_LEN 1

void configure_l2_errors(uint32_t __pmd_id) {
  uint32_t _tmp = 0;
  clear_l2_errors(__pmd_id);
  _tmp |= 1 << PCP_RB_CPUX_MEMERR_L2C_L2ECR_TAGERREN_BIT;
  _tmp |= 1 << PCP_RB_CPUX_MEMERR_L2C_L2ECR_DATAERREN_BIT;
  _tmp |= 1 << PCP_RB_CPUX_MEMERR_L2C_L2ECR_SDBERREN_BIT;
  _tmp |= 1 << PCP_RB_CPUX_MEMERR_L2C_L2ECR_UCINTREN_BIT; // TBD
  _tmp |= 1 << PCP_RB_CPUX_MEMERR_L2C_L2ECR_CINTREN_BIT; // TBD
  write_rb(PCP_RB_CPU0_MEMERR_L2C_PAGE+0x20*__pmd_id, PCP_RB_CPUX_MEMERR_L2C_L2ECR_PAGE_OFFSET, _tmp);
}

#define PCP_RB_CPUX_L2C_L2RTOCR_RTODIS_BIT       9
#define PCP_RB_CPUX_L2C_L2RTOCR_RTODIS_LEN       1
#define PCP_RB_CPUX_L2C_L2RTOCR_RTOIRQEN_BIT     8
#define PCP_RB_CPUX_L2C_L2RTOCR_RTOIRQEN_LEN     1

void configure_l2_rtos(uint32_t __pmd_id) {
  uint32_t _tmp = 0;
  clear_l2_rtos(__pmd_id);
  _tmp &= ~(1U << PCP_RB_CPUX_L2C_L2RTOCR_RTODIS_BIT); // force off disable
  _tmp |= 1 << PCP_RB_CPUX_L2C_L2RTOCR_RTOIRQEN_BIT; // TBD if needed for vbios
  // insert count
  // PCP_RB_CPUX_L2C_L2RTOCR_COUNT_FLD_MSB 5
  // PCP_RB_CPUX_L2C_L2RTOCR_COUNT_FLD_LSB 0
  _tmp |= (0x03FU & 25); // not that 25 is decimal that fits into 6-bits
  write_rb(PCP_RB_CPU0_L2C_PAGE+0x20*__pmd_id, PCP_RB_CPUX_L2C_L2RTOCR_PAGE_OFFSET, _tmp);
}

#define PCP_RB_CPUX_MEMERR_CPU_LSUECR_CACHERREN_BIT 9
#define PCP_RB_CPUX_MEMERR_CPU_LSUECR_CACHERREN_LEN 1
#define PCP_RB_CPUX_MEMERR_CPU_LSUECR_DTBERREN_BIT 8
#define PCP_RB_CPUX_MEMERR_CPU_LSUECR_DTBERREN_LEN 1
#define PCP_RB_CPUX_MEMERR_CPU_LSUECR_INTRENC_BIT 0
#define PCP_RB_CPUX_MEMERR_CPU_LSUECR_INTRENC_LEN 1

void configure_lsu_errors(uint32_t __pmd_id, uint32_t __cpu_id) {
  uint32_t _tmp = 0;
  clear_lsu_errors(__pmd_id, __cpu_id);
  _tmp |= 1 << PCP_RB_CPUX_MEMERR_CPU_LSUECR_CACHERREN_BIT;
  _tmp |= 1 << PCP_RB_CPUX_MEMERR_CPU_LSUECR_DTBERREN_BIT;
  _tmp |= 1 << PCP_RB_CPUX_MEMERR_CPU_LSUECR_INTRENC_BIT; // TBD if this is needed in VBIOS
  write_rb(PCP_RB_CPU0_MEMERR_CPU_PAGE+0x20*__pmd_id+0x10*__cpu_id, PCP_RB_CPUX_MEMERR_CPU_LSUECR_PAGE_OFFSET, _tmp);
}

#define PCP_RB_CPUX_MEMERR_CPU_ICFECR_CACHERREN_BIT 9
#define PCP_RB_CPUX_MEMERR_CPU_ICFECR_CACHERREN_LEN 1
#define PCP_RB_CPUX_MEMERR_CPU_ICFECR_ITBERREN_BIT 8
#define PCP_RB_CPUX_MEMERR_CPU_ICFECR_ITBERREN_LEN 1
#define PCP_RB_CPUX_MEMERR_CPU_ICFECR_INTRENC_BIT 0
#define PCP_RB_CPUX_MEMERR_CPU_ICFECR_INTRENC_LEN 1

void configure_icf_errors(uint32_t __pmd_id, uint32_t __cpu_id) {
  uint32_t _tmp = 0;
  clear_icf_errors(__pmd_id, __cpu_id);
  _tmp |= 1 << PCP_RB_CPUX_MEMERR_CPU_ICFECR_CACHERREN_BIT;
  _tmp |= 1 << PCP_RB_CPUX_MEMERR_CPU_ICFECR_ITBERREN_BIT;
  _tmp |= 1 << PCP_RB_CPUX_MEMERR_CPU_ICFECR_INTRENC_BIT; // TBD if this is needed for VBIOS
  write_rb(PCP_RB_CPU0_MEMERR_CPU_PAGE+0x20*__pmd_id+0x10*__cpu_id, PCP_RB_CPUX_MEMERR_CPU_ICFECR_PAGE_OFFSET, _tmp);
}

#define PCP_RB_CPUX_MEMERR_CPU_MMUECR_UTBERREN_BIT 8
#define PCP_RB_CPUX_MEMERR_CPU_MMUECR_UTBERREN_LEN 1
#define PCP_RB_CPUX_MEMERR_CPU_MMUECR_INTRENC_BIT 0
#define PCP_RB_CPUX_MEMERR_CPU_MMUECR_INTRENC_LEN 1

void configure_mmu_errors(uint32_t __pmd_id, uint32_t __cpu_id) {
  uint32_t _tmp = 0;
  clear_mmu_errors(__pmd_id, __cpu_id);
  _tmp |= 1 << PCP_RB_CPUX_MEMERR_CPU_MMUECR_UTBERREN_BIT;
  _tmp |= 1 << PCP_RB_CPUX_MEMERR_CPU_MMUECR_INTRENC_BIT; // TBD if this is needed for VBIOS
  write_rb(PCP_RB_CPU0_MEMERR_CPU_PAGE+0x20*__pmd_id+0x10*__cpu_id, PCP_RB_CPUX_MEMERR_CPU_MMUECR_PAGE_OFFSET, _tmp);
}

void configure_cpu_errors(uint32_t __pmd_id, uint32_t __cpu_id) {
  configure_lsu_errors(__pmd_id, __cpu_id);
  configure_icf_errors(__pmd_id, __cpu_id);
  configure_mmu_errors(__pmd_id, __cpu_id);
}

void configure_pmd_errors(uint32_t __pmd_id) {
  configure_l2_errors(__pmd_id);
  configure_l2_rtos(__pmd_id);
  configure_cpu_errors(__pmd_id, 0);
  configure_cpu_errors(__pmd_id, 1);
}

//------------------------------------------------------------------------------
// error checking code
//------------------------------------------------------------------------------

#define PCP_RB_CPUX_MEMERR_L2C_L2ESR_MULTUCERR_BIT 3
#define PCP_RB_CPUX_MEMERR_L2C_L2ESR_MULTUCERR_LEN 1
#define PCP_RB_CPUX_MEMERR_L2C_L2ESR_MULTICERR_BIT 2
#define PCP_RB_CPUX_MEMERR_L2C_L2ESR_MULTICERR_LEN 1
#define PCP_RB_CPUX_MEMERR_L2C_L2ESR_UCERR_BIT   1
#define PCP_RB_CPUX_MEMERR_L2C_L2ESR_UCERR_LEN   1
#define PCP_RB_CPUX_MEMERR_L2C_L2ESR_ERR_BIT     0
#define PCP_RB_CPUX_MEMERR_L2C_L2ESR_ERR_LEN     1

uint32_t check_l2_errors(uint32_t pmd, uint32_t verbose) {
  uint32_t _tmp = 0;
  uint32_t errors = 0;
  // just check these for now
  _tmp = read_rb(PCP_RB_CPU0_MEMERR_L2C_PAGE+0x20*pmd, PCP_RB_CPUX_MEMERR_L2C_L2ESR_PAGE_OFFSET);
  if (_tmp & (1<<PCP_RB_CPUX_MEMERR_L2C_L2ESR_ERR_BIT)) {
    errors |= (1 << 0);
    if (verbose)
      X__printf("Pmd %d: L2 error L2ESR ERR (0x%08x)\n", pmd, _tmp);
  }
  if (_tmp & (1<<PCP_RB_CPUX_MEMERR_L2C_L2ESR_UCERR_BIT)) {
    errors |= (1 << 1);
    if (verbose)
      X__printf("Pmd %d: L2 error L2ESR UCERR (0x%08x)\n", pmd, _tmp);
  }
  if (_tmp & (1<<PCP_RB_CPUX_MEMERR_L2C_L2ESR_MULTICERR_BIT)) {
    errors |= (1 << 2);
    if (verbose)
      X__printf("Pmd %d: L2 error L2ESR MULTICERR (0x%08x)\n", pmd, _tmp);
  }
  if (_tmp & (1<<PCP_RB_CPUX_MEMERR_L2C_L2ESR_MULTUCERR_BIT)) {
    errors |= (1 << 3);
    if (verbose)
      X__printf("Pmd %d: L2 error L2ESR MULTUCERR (0x%08x)\n", pmd, _tmp);
  }
  return errors;
}

#define PCP_RB_CPUX_L2C_L2RTOSR_ERR_BIT          0
#define PCP_RB_CPUX_L2C_L2RTOSR_ERR_LEN          1

uint32_t check_l2_rtos(uint32_t pmd, uint32_t verbose) {
  uint32_t _tmp;
  uint32_t rtos = 0;
  _tmp = read_rb(PCP_RB_CPU0_L2C_PAGE+0x20*pmd, PCP_RB_CPUX_L2C_L2RTOSR_PAGE_OFFSET);
  // just check if occurred for now
  if (_tmp & (1<<PCP_RB_CPUX_L2C_L2RTOSR_ERR_BIT)) {
    rtos = 1;
    if (verbose)
      X__printf("Pmd %d: L2 error L2RTOSR ERR (0x%08x)\n", pmd, _tmp);
  }
  return rtos;
}

#define PCP_RB_CPUX_MEMERR_CPU_MMUESR_MULTCERR_BIT 2
#define PCP_RB_CPUX_MEMERR_CPU_MMUESR_MULTCERR_LEN 1
#define PCP_RB_CPUX_MEMERR_CPU_MMUESR_CERR_BIT   0
#define PCP_RB_CPUX_MEMERR_CPU_MMUESR_CERR_LEN   1

uint32_t check_mmu_errors(uint32_t proc, uint32_t verbose) {
  uint32_t _tmp;
  uint32_t errors = 0;
  _tmp = read_rb(PCP_RB_CPU0_MEMERR_CPU_PAGE+0x10*proc, PCP_RB_CPUX_MEMERR_CPU_MMUESR_PAGE_OFFSET);
  if (_tmp & (1<<PCP_RB_CPUX_MEMERR_CPU_MMUESR_MULTCERR_BIT)) {
    errors |= (1 << 0);
    if (verbose)
      X__printf("Proc %d: MMU error MMUESR MULTCERR (0x%08x)\n", proc, _tmp);
  }
  if (_tmp & (1<<PCP_RB_CPUX_MEMERR_CPU_MMUESR_CERR_BIT)) {
    errors |= (1 << 1);
    if (verbose)
      X__printf("Proc %d: MMU error MMUESR CERR (0x%08x)\n", proc, _tmp);
  }
  return errors;
}



#define PCP_RB_CPUX_MEMERR_CPU_LSUESR_MULTCERR_BIT 2
#define PCP_RB_CPUX_MEMERR_CPU_LSUESR_MULTCERR_LEN 1
#define PCP_RB_CPUX_MEMERR_CPU_LSUESR_CERR_BIT   0
#define PCP_RB_CPUX_MEMERR_CPU_LSUESR_CERR_LEN   1

uint32_t check_lsu_errors(uint32_t proc, uint32_t verbose) {
  uint32_t _tmp;
  uint32_t errors = 0;
  _tmp = read_rb(PCP_RB_CPU0_MEMERR_CPU_PAGE+0x10*proc, PCP_RB_CPUX_MEMERR_CPU_LSUESR_PAGE_OFFSET);
  if (_tmp & (1<<PCP_RB_CPUX_MEMERR_CPU_LSUESR_MULTCERR_BIT)) {
    errors |= (1 << 0);
    if (verbose)
      X__printf("Proc %d: LSU error LSUESR MULTCERR (0x%08x)\n", proc, _tmp);
  }
  if (_tmp & (1<<PCP_RB_CPUX_MEMERR_CPU_LSUESR_CERR_BIT)) {
    errors |= (1 << 1);
    if (verbose)
      X__printf("Proc %d: LSU error LSUESR CERR (0x%08x)\n", proc, _tmp);
  }
  return errors;
}

#define PCP_RB_CPUX_MEMERR_CPU_ICFESR_MULTCERR_BIT 2
#define PCP_RB_CPUX_MEMERR_CPU_ICFESR_MULTCERR_LEN 1
#define PCP_RB_CPUX_MEMERR_CPU_ICFESR_CERR_BIT   0
#define PCP_RB_CPUX_MEMERR_CPU_ICFESR_CERR_LEN   1

uint32_t check_icf_errors(uint32_t proc, uint32_t verbose) {
  uint32_t _tmp;
  uint32_t errors = 0;
  _tmp = read_rb(PCP_RB_CPU0_MEMERR_CPU_PAGE+0x10*proc, PCP_RB_CPUX_MEMERR_CPU_ICFESR_PAGE_OFFSET);
  if (_tmp & (1<<PCP_RB_CPUX_MEMERR_CPU_ICFESR_CERR_BIT)) {
    errors |= (1 << 0);
    if (verbose)
      X__printf("Proc %d: ICF error ICFESR CERR (0x%08x)\n", proc, _tmp);
  }
  if (_tmp & (1<<PCP_RB_CPUX_MEMERR_CPU_ICFESR_MULTCERR_BIT)) {
    errors |= (1 << 1);
    if (verbose)
      X__printf("Proc %d: ICF error ICFESR MULTCERR (0x%08x)\n", proc, _tmp);
  }
  return errors;
}

uint32_t check_cpu_errors(uint32_t proc, uint32_t verbose) {
  uint32_t result = 0;
  result |= (check_lsu_errors(proc, verbose) << 0);
  result |= (check_icf_errors(proc, verbose) << 2);
  result |= (check_mmu_errors(proc, verbose) << 4);
  return result;
}

void configure_system_errors() {
  uint32_t i;
  for (i = 0; i < 4; ++i) {
    if (cpu_hw2m(i*2) >= 0)
      configure_pmd_errors(i);
  }
  // TBD Iob L3c Mcu
}

uint32_t check_system_errors(uint32_t verbose) {
  uint32_t i;
  uint32_t result = 0;

  for (i = 0; i < 4; ++i) {
    if (cpu_hw2m(i*2) >= 0) {
      result |= (check_l2_errors(i, verbose) << 0);
      result |= (check_l2_rtos(i, verbose) << 4);
      result |= (check_cpu_errors((i*2), verbose) << 8);
      result |= (check_cpu_errors((i*2)+1, verbose) << 16);
    }
  }
  return result;
}

