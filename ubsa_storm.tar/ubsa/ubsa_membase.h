/* Copyright (c) 2014 by Veloce Technologies.  All Rights Reserved. */
/* $Id: //depot/projects/osboot/MAIN/ubsa/ubsa_membase.h#3 $ */

#ifndef __UBSA_MEMBASE__
#define __UBSA_MEMBASE__

#if defined(STORM) && defined(SHADOWCAT)
  #error
#endif

#if !defined(STORM) && !defined(SHADOWCAT)
  #error
#endif

#define MAX_THREADS 8

#define OCM_BASE 0x1d000000

#ifdef STORM

  #define OCM_SIZE          (1024*1024)

  #define UBSA_PT_BASE      (OCM_BASE + 0x00080000)
  #define UBSA_HEAP_BASE    (OCM_BASE + 0x00088000)
  #define UBSA_HEAP_SIZE    0x00018000
  #define UBSA_STACK_BASE   (OCM_BASE + 0x000FFFF0)
  #define UBSA_STACK_SIZE   0x2000

  #define STORM_IOA1_BASE           0x00000000000ull
  #define STORM_UART0_CSR_BASE      (STORM_IOA1_BASE + 0x1C020000ull)  /*    4KB */
  #define STORM_UART1_CSR_BASE      (STORM_IOA1_BASE + 0x1C021000ull)  /*    4KB */
  #define STORM_UART2_CSR_BASE      (STORM_IOA1_BASE + 0x1C022000ull)  /*    4KB */
  #define STORM_UART3_CSR_BASE      (STORM_IOA1_BASE + 0x1C023000ull)  /*    4KB */

  #define CONFIG_UART_BASE  STORM_UART0_CSR_BASE

  #define MAX_RDLVL_TRIM 3
  #define MAX_WRLVL_TRIM 7
#endif

#ifdef SHADOWCAT

  #define OCM_SIZE          (512*1024)

  #define UBSA_PT_BASE      (OCM_BASE + 0x00030000)
  #define UBSA_HEAP_BASE    (OCM_BASE + 0x00038000)
  #define UBSA_HEAP_SIZE    0x00018000
  #define UBSA_STACK_BASE   (OCM_BASE + 0x0007FFF0)
  #define UBSA_STACK_SIZE   0x2000

  #define SHADOWCAT_IOA1_BASE         0x00000000000ull
  #define SHADOWCAT_UART0_CSR_BASE    (SHADOWCAT_IOA1_BASE + 0x10600000ull) /*    4KB */
  #define SHADOWCAT_UART1_CSR_BASE    (SHADOWCAT_IOA1_BASE + 0x10601000ull) /*    4KB */
  #define SHADOWCAT_UART2_CSR_BASE    (SHADOWCAT_IOA1_BASE + 0x10602000ull) /*    4KB */
  #define SHADOWCAT_UART3_CSR_BASE    (SHADOWCAT_IOA1_BASE + 0x10603000ull) /*    4KB */

  #define CONFIG_UART_BASE  SHADOWCAT_UART0_CSR_BASE

  #define MAX_RDLVL_TRIM 3
  #define MAX_WRLVL_TRIM 7
#endif

#define MAILBOX_PTR_ADDR        0x1700118C
#define MAILBOX_OFFSET          0xFFF8

#endif // __UBSA_MEMBASE__
