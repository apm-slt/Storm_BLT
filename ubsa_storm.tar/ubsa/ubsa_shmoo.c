/* Copyright (c) 2014 by Veloce Technologies.  All Rights Reserved. */
/* $Id: //depot/projects/osboot/MAIN/ubsa/ubsa_shmoo.c#7 $ */

#include "bbcutils.h"
#include "ubsa_shmoo.h"

int memtest_bit(char *memtest_opts, int64_t mcu, int64_t bit)
{
  int ret;
  char cmd[256];
  int32_t cmd_offs;
  uint64_t compare_mask;

  compare_mask = ~(1ull << bit);

  strcpy(cmd, memtest_opts);
  cmd_offs = strnlen(cmd, 256);
  cmd_offs += __snprintf((cmd + cmd_offs), (256-cmd_offs), " --quiet --mcu %d ", ((mcu < 0) ? 0xF : (1<<mcu)) )-1;
  cmd_offs += __snprintf((cmd + cmd_offs), (256-cmd_offs), " --cmp_mask 0x%x ", compare_mask)-1;

  ret = ubsa_memtest(cmd);

  return (ret);
}

int memtest_bit_per_byte(char *memtest_opts, int64_t mcu, int64_t bit)
{
  int ret;
  char cmd[256];
  int32_t cmd_offs;
  uint64_t compare_mask;

  compare_mask = ~(0x0101010101010101ull << (bit%8));

  strcpy(cmd, memtest_opts);
  cmd_offs = strnlen(cmd, 256);
  cmd_offs += __snprintf((cmd + cmd_offs), (256-cmd_offs), " --quiet --mcu %d ", ((mcu < 0) ? 0xF : (1<<mcu)) )-1;
  cmd_offs += __snprintf((cmd + cmd_offs), (256-cmd_offs), " --cmp_mask 0x%x ", compare_mask)-1;

  ret = ubsa_memtest(cmd);

  return (ret);
}

int memtest_all_bits(char *memtest_opts, int64_t mcu)
{
  int ret;
  char cmd[256];
  int32_t cmd_offs;

  strcpy(cmd, memtest_opts);
  cmd_offs = strnlen(cmd, 256);
  if (mcu >= 0) {
    cmd_offs += __snprintf((cmd + cmd_offs), (256-cmd_offs), " --mcu %d ", (1<<mcu) )-1;
  }
  cmd_offs += __snprintf((cmd + cmd_offs), (256-cmd_offs), " --quiet " )-1;

  ret = ubsa_memtest(cmd);

  return (ret);
}

int memtest_all_bits_rank(char *memtest_opts, int32_t mcu, int32_t rank, uint32_t ecc_on)
{
  int ret;
  char cmd[256];
  int32_t cmd_offs;

  strcpy(cmd, memtest_opts);
  cmd_offs = strnlen(cmd, 256);
  if (mcu >= 0) {
    cmd_offs += __snprintf((cmd + cmd_offs), (256-cmd_offs), " --mcu %d ", (1<<mcu) )-1;
  }
  if (ecc_on) {
    cmd_offs += __snprintf((cmd + cmd_offs), (256-cmd_offs), " --ecc_on ")-1;
  }
  if (rank > 0) {
    cmd_offs += __snprintf((cmd + cmd_offs), (256-cmd_offs), " --rank_alloc %d ", (int64_t)rank )-1;
  }
  cmd_offs += __snprintf((cmd + cmd_offs), (256-cmd_offs), " --quiet " )-1;

  ret = ubsa_memtest(cmd);

  return (ret);
}

int find_eye(char *argv)
{
  static int64_t lvl_start;
  static int64_t lvl_end;
  static int64_t mcu;
  static int64_t rank;
  static int64_t step;
  static uint32_t ecc_on;
  static uint32_t with_ecc;
  static uint32_t do_help;
  static char *opt_str;

  int i, b, w;
  int ecc;
  uint64_t *test_pass;
  lvl_type_e lvl_type;
  e_drive_slew_type dr_slew_type;
  char *lvl_type_str;
  char memtest_opts[256];
  int32_t lvl_val;
  int32_t lvl_inc;
  int32_t lvl_num;

  int64_t lvl[9];

  // option parsing vars
  int c;
  int first;
  int option_idx;
  char *tmp_var;

  static ubsa_long_options_s opts[] = {
    {"lvl",         'Y', OPT_STRING,  1, &opt_str,      0, "LVL Type: 'rd' 'wr' 'rd_gate' 'wr_dq' 'vref'"},
    {"lvl_start",   'L', OPT_INT64,   1, &lvl_start,    0, "Low Lvl value"},
    {"lvl_end",     'H', OPT_INT64,   1, &lvl_end,      0, "High Lvl value"},
//    {"drive-slew",  'd', OPT_STRING,  1, &opt_str,      0, "Drive & Slew: 'data_mask' 'dq_dqs' 'addr' 'cmd' 'control' 'clock'"},
    {"mcu",         'M', OPT_INT64,   1, &mcu,          0, "MCU to target"},
    {"rank",        'R', OPT_INT64,   1, &rank,         0, "Rank to target"},
    {"step",        'S', OPT_INT64,   1, &step,         0, "Lvl Step size"},
    {"",            'C', OPT_STRING,  1, &opt_str,      0, "memtest command"},
    {"ecc_on",      'E', OPT_INT32,   0, &ecc_on,       1, "Run test with ECC ON"},
    {"with_ecc",    'e', OPT_INT32,   0, &with_ecc,     1, "Include ECC byte"},
    {"help",        'h', OPT_UINT32,  0, &do_help,      1, "Print Help"},
    // TODO: Seed
    { NULL, 0, 0, 0, 0, 0, 0 }
  };

  do_help = 0;
  lvl_start = -1;
  lvl_end = -1;
  mcu = -1;
  rank = -1;
  step = 2;
  ecc_on = 0;
  with_ecc = 0;
  lvl_type = LVL_INVALID;
  dr_slew_type = DS_INVALID;
  memtest_opts[0] = 0;

  first = 1;
  while (1) {
    c = ubsa_getopt_long((first ? argv : NULL), opts, &option_idx, &tmp_var);
    first = 0;
    if (c == -1)
      break;

    switch (c) {
      case 'C':
        strncpy(memtest_opts, opt_str, 256);
        memtest_opts[255] = 0;
        X__printf("Memtest command '%s'\n", memtest_opts);
        break;
      case 'Y':
        if (strcmp(opt_str, "rd_gate") == 0) {
          lvl_type = LVL_RD_GATE;
        } else if (strcmp(opt_str, "wr") == 0) {
          lvl_type = LVL_WR;
        } else if (strcmp(opt_str, "wr_dq") == 0) {
          lvl_type = LVL_WR_DQ;
        } else if (strcmp(opt_str, "vref") == 0) {
          lvl_type = LVL_VREF;
#ifdef SHADOWCAT
        } else if (strcmp(opt_str, "rd_rise") == 0) {
          lvl_type = LVL_RD_RISE;
        } else if (strcmp(opt_str, "rd_fall") == 0) {
          lvl_type = LVL_RD_FALL;
#endif
#ifdef STORM
        } else if (strcmp(opt_str, "rd") == 0) {
          lvl_type = LVL_RD;
#endif
        } else {
          X__printf("Invalid Level type : '%s'\n", opt_str);
          lvl_type = LVL_INVALID;
        }
        break;
#ifdef STORM
      case 'd':
        if (strcmp(opt_str, "data_mask") == 0) {
          dr_slew_type = DS_DATA_MASK;
        } else if (strcmp(opt_str, "dq_dqs") == 0) {
          dr_slew_type = DS_DQ_DQS;
        } else if (strcmp(opt_str, "addr") == 0) {
          dr_slew_type = DS_ADDR_BANK;
        } else if (strcmp(opt_str, "cmd") == 0) {
          dr_slew_type = DS_COMMAND;
        } else if (strcmp(opt_str, "control") == 0) {
          dr_slew_type = DS_CONTROL;
        } else if (strcmp(opt_str, "clock") == 0) {
          dr_slew_type = DS_CLOCK;
        } else {
          X__printf("Invalid Drive/Slew type : '%s'\n", opt_str);
          do_help = 1;
          dr_slew_type = DS_INVALID;
        }
        break;
#endif
      case '?':
        do_help = 1;
        break;
    }
  }

  switch (lvl_type) {
    case LVL_RD:      lvl_type_str = "RdLvl"; break;
    case LVL_RD_RISE: lvl_type_str = "RdLvl Rise"; break;
    case LVL_RD_FALL: lvl_type_str = "RdLvl Fall"; break;
    case LVL_RD_GATE: lvl_type_str = "RdLvl Gate"; break;
    case LVL_WR:      lvl_type_str = "WrLvl"; break;
    case LVL_WR_DQ:   lvl_type_str = "Wr DQ"; break;
    case LVL_VREF:    lvl_type_str = "Vref"; break;
    default:          lvl_type_str = "LVL"; break;
  }

  if (lvl_start <= lvl_end) {
    lvl_inc = step;
    lvl_num = (lvl_end - lvl_start) + 1;
  } else {
    lvl_inc = -step;
    lvl_num = (lvl_start - lvl_end) + 1;
  }
  lvl_num /= step;

  if ((mcu >= 0) && !is_mcu_active(mcu)) {
    X__printf("MCU %d is not active\n", mcu);
    return (1);
  }

  if (((lvl_type == LVL_INVALID) + (dr_slew_type == DS_INVALID)) != 1) {
    X__printf("Select exactly one lvl or drive-slew\n");
    do_help = 1;
  }

  if ((dr_slew_type != DS_INVALID) && with_ecc) {
    X__printf("Slew tests don't use ECC byte (run with 'ecc_on')\n");
    do_help = 1;
  }

  if ((lvl_type != LVL_INVALID) && ((lvl_end < 0) || (lvl_start < 0))) {
    X__printf("Set start and end values for lvl type %s\n", lvl_type_str);
    do_help = 1;
  }

  if (do_help || (memtest_opts[0] == 0) || (rank > ubsa_num_ranks(mcu)) || (mcu > 3) || (step < 1))
  {
    X__printf("Usage:\n");
    ubsa_getopt_usage(opts);
    return (1);;
  }

  if (dr_slew_type != DS_INVALID) {
    lvl_start = 0;
    lvl_end = 31;
    lvl_inc = 1;
    lvl_num = 32;
    step = 1;
  }

  X__printf("%s Start 0x%x, End 0x%x\n", lvl_type_str, lvl_start, lvl_end);

  memreg("--save");

  test_pass = (uint64_t *)ubsa_malloc(lvl_num*9); // this aligns to 16 bytes
  if (test_pass == NULL) {
    X__printf("malloc failed : size %d\n", lvl_num*9);
    return (-1);
  }

  for (w = 0; w < (lvl_num*9+7)/8; w++)
    test_pass[w] = 0;

  for (ecc = with_ecc; ecc >= 0; ecc--) {

    if (ecc_on | (ecc == 1)) {
      memreg("--ecc_en 1");
    } else {
      memreg("--ecc_en 0");
    }

    for (lvl_val = lvl_start, w = 0; w < lvl_num; lvl_val += lvl_inc, w++) {
      int ret, m;
      uint64_t bit_error;

      X__printf("Running %s 0x%03x : ", lvl_type_str, lvl_val);

      if (ecc == 0) {
        for (i = 0; i < 8; i++) {
          lvl[i] = lvl_val;
        }
        lvl[8] = (ecc_on ? lvl_val : -1);
      } else {
        for (i = 0; i < 8; i++) {
          lvl[i] = -1;
        }
        lvl[8] = lvl_val;
      }

      if (lvl_type == LVL_RD) {
        set_rdlvl(mcu, rank, lvl);
      }
      if (lvl_type == LVL_RD_RISE) {
        set_rdlvl_rise(mcu, rank, lvl);
      }
      if (lvl_type == LVL_RD_FALL) {
        set_rdlvl_fall(mcu, rank, lvl);
      }
      if (lvl_type == LVL_WR) {
        set_wrlvl(mcu, rank, lvl);
      }
      if (lvl_type == LVL_RD_GATE) {
        set_rdlvl_g(mcu, rank, lvl);
      }
      if (lvl_type == LVL_WR_DQ) {
        set_write_dq(mcu, rank, lvl);
      }
      if (lvl_type == LVL_VREF) {
#ifdef SHADOWCAT
        set_vref(mcu, lvl);
#endif
      }
      if (dr_slew_type != DS_INVALID) {
        for (m = 0; m < 4; m++) {
          if (((mcu < 0) || (mcu == m)) && is_mcu_active(m)) {
            set_phy_slew(m, dr_slew_type, ((lvl_val >> 3) & 3));
            set_phy_drive_strn(m, dr_slew_type, (lvl_val & 7));
          }
        }
      }

      for (m = 0; m < 4; m++) {
        int e;
        if ((mcu >= 0) && (mcu != m))
          continue;
        e = mcu_phy_sw_adj_ctrlupdate(m);
        if (e) {
          X__printf("PHY SW ADJ CTRL UPDATE ERROR: mcu %d : 0x%x\n", m, e);
        }
      }

      ret = memtest_all_bits_rank(memtest_opts, mcu, rank, ecc_on | (ecc == 1));
      bit_error = get_memtest_bit_errors();

      if (ecc == 0) {
        //  w lvls, 8 bits, 8 bytes
        for (i = 0; i < 64; i++) {
          if (bit_error & (1ull << i)) {
            CLEAR_BIT(i+(w*72));
          } else {
            SET_BIT(i+(w*72));
          }
        }
      } else {
        for (i = 64; i < 72; i++) {
          if (ret || (bit_error != 0)) {
            CLEAR_BIT(i+(w*72));
          } else {
            SET_BIT(i+(w*72));
          }
        }
      }
      putc(ret ? '0' : '1');

      // don't run out of memory
      ubsa_dram_alloc_reset();

      // reset MCU FIFO
      mcu_phy_rdfifo_reset_all();

      X__printf("\r");
    }

    if (with_ecc)
      memreg("--restore");

    X__printf("\n");
  }

  memreg("--restore");
  memreg("--ecc_en 1");

  #define NZ(x) (((x) < 0) ? 0 : (x))

  if (lvl_type != LVL_INVALID) {
    X__printf("\nFinal Results:\n");
    lvl_inc = ((lvl_inc < 0) ? -lvl_inc : lvl_inc);
    for (i = 0; i < (with_ecc ? 9 : 8); i++) {
      int x;
      int32_t hw_lvl[2];
      for (x = 0; x <= is_x4_mode(); x++) {
        switch (lvl_type) {
#ifdef STORM
          case LVL_RD:      hw_lvl[x] = get_saved_rdlvl(NZ(mcu), NZ(rank), i, x); break;
          case LVL_WR_DQ:   hw_lvl[x] = get_saved_write_dq(NZ(mcu), i, x); break;
#endif
          case LVL_RD_GATE: hw_lvl[x] = get_saved_rdlvl_gate(NZ(mcu), NZ(rank), i, x); break;
          case LVL_WR:      hw_lvl[x] = get_saved_wrlvl(NZ(mcu), NZ(rank), i, x); break;
          case LVL_VREF:    hw_lvl[x] = get_saved_vref(NZ(mcu)); break;
          default:          hw_lvl[x] = -1; break;
        }
      }
      X__printf("%s 0x%02x to 0x%02x step %d, ", lvl_type_str, lvl_start, lvl_end, step);
#ifdef SHADOWCAT
      if ((lvl_type == LVL_RD_RISE) || (lvl_type == LVL_RD_FALL) || (lvl_type == LVL_WR_DQ)) {
        X__printf("Byte %d (HW lvl", i);
        for (x = 0; x < 8; x++) {
          int32_t h;
          switch (lvl_type) {
            case LVL_RD_RISE: h = get_saved_rdlvl_rise(NZ(mcu), NZ(rank), i, x, 0); break;
            case LVL_RD_FALL: h = get_saved_rdlvl_fall(NZ(mcu), NZ(rank), i, x, 0); break;
            case LVL_WR_DQ:   h = get_saved_write_dq_bit(NZ(mcu), NZ(rank), i, x, 0); break;
            default:          h = 0;
          }
          X__printf(" 0x%02x", ((h >= 0) ? h : 0));
        }
        X__printf(")\n");
      } else
#endif
      if (is_x4_mode()) {
        X__printf("Byte %d (HW lvl 0x%02x,0x%02x)\n", i, ((hw_lvl[1] >= 0) ? hw_lvl[1] : 0), ((hw_lvl[0] >= 0) ? hw_lvl[0] : 0));
      } else {
        X__printf("Byte %d (HW lvl 0x%02x)\n", i, ((hw_lvl[0] >= 0) ? hw_lvl[0] : 0));
      }
      x = 0;
      for (b = 0; b < 8; b++) {
        if ((b == 4) && is_x4_mode()) x = 1;
#ifdef SHADOWCAT
        switch (lvl_type) {
          case LVL_RD_RISE: hw_lvl[x] = get_saved_rdlvl_rise(NZ(mcu), NZ(rank), i, b, x); break;
          case LVL_RD_FALL: hw_lvl[x] = get_saved_rdlvl_fall(NZ(mcu), NZ(rank), i, b, x); break;
          case LVL_WR_DQ:   hw_lvl[x] = get_saved_write_dq_bit(NZ(mcu), NZ(rank), i, b, x); break;
          default:          break;
        }
#endif
        X__printf("Bit %02d : ", b);
        for (lvl_val = ((lvl_start > lvl_end) ? lvl_end : lvl_start), w = 0; w < lvl_num; lvl_val += lvl_inc, w++) {
          if ((lvl_val <= hw_lvl[x]) && (lvl_val + lvl_inc > hw_lvl[x])) {
            putc( (GET_BIT(b+(i*8)+(w*72)) ? '*' : '%') );
          } else {
            putc( (GET_BIT(b+(i*8)+(w*72)) ? '1' : '0') );
          }
        }
        X__printf("\n");
      }
      X__printf("\n");
    }
  }

  if (lvl_type != LVL_INVALID) {
    uint32_t worst_bit = 100;
    uint32_t worst_edge = 100;
    uint32_t worst_bit_w = 0x100000;
    uint32_t worst_edge_w = 0x100000;

    lvl_inc = ((lvl_inc < 0) ? -lvl_inc : lvl_inc);
    for (i = 0; i < (with_ecc ? 9 : 8); i++) { // byte
      int x;
      int32_t h = 0;
      int32_t first_pass, last_pass;
      int32_t lstrt = ((lvl_start > lvl_end) ? lvl_end : lvl_start);
      x = 0;
      for (b = 0; b < 8; b++) { // bit

        if ((b == 4) && is_x4_mode()) x = 1;
#ifdef SHADOWCAT
        if ((lvl_type == LVL_RD_RISE) || (lvl_type == LVL_RD_FALL) || (lvl_type == LVL_WR_DQ)) {
          switch (lvl_type) {
            case LVL_RD_RISE: h = get_saved_rdlvl_rise(NZ(mcu), NZ(rank), i, b, x); break;
            case LVL_RD_FALL: h = get_saved_rdlvl_fall(NZ(mcu), NZ(rank), i, b, x); break;
            case LVL_WR_DQ:   h = get_saved_write_dq_bit(NZ(mcu), NZ(rank), i, b, x); break;
            default:          break;
          }
        } else
#endif
        if (b == (4*x)) {
          switch (lvl_type) {
#ifdef STORM
            case LVL_RD:      h = get_saved_rdlvl(NZ(mcu), NZ(rank), i, x); break;
            case LVL_WR_DQ:   h = get_saved_write_dq(NZ(mcu), i, x); break;
#endif
            case LVL_RD_GATE: h = get_saved_rdlvl_gate(NZ(mcu), NZ(rank), i, x); break;
            case LVL_WR:      h = get_saved_wrlvl(NZ(mcu), NZ(rank), i, x); break;
            case LVL_VREF:    h = get_saved_vref(NZ(mcu)); break;
            default:          h = -1; break;
          }
        }

        if (h < 0) {
          X__printf("Invalid saved param byte %d bit %d\n", i, b);
          continue;
        }

        if ((lstrt > h) || ((lstrt + lvl_num*lvl_inc) < h)) {
          X__printf("HW val outside range: s 0x%x n 0x%x hw 0x%x\n", lstrt, lvl_num, h);
          continue;
        }

        first_pass = -1;
        last_pass = -1;

        for (lvl_val = lstrt, w = 0; w < lvl_num; lvl_val += lvl_inc, w++) {
          if (GET_BIT(b+(i*8)+(w*72))) {
            if (lvl_val >= h)
              last_pass = lvl_val;
            if ((lvl_val <= h) && (first_pass == -1))
              first_pass = lvl_val;
          } else {
            // fail
            if (lvl_val <= h)
              first_pass = -1;
            if (lvl_val > h)
              break;
          }
        }
//        X__printf("byte %d bit %d : 0x%x -> 0x%x = %d\n", i, b, first_pass, last_pass, (last_pass - first_pass));
        if ((last_pass - first_pass) < worst_bit_w) {
          worst_bit_w = last_pass - first_pass;
          worst_bit = i*8 + b;
        }
        if ((h - first_pass) < worst_edge_w) {
          worst_edge_w = h - first_pass;
          worst_edge = i*8 + b;
        }
        if ((last_pass - h) < worst_edge_w) {
          worst_edge_w = last_pass - h;
          worst_edge = i*8 + b;
        }
      }
    }
    X__printf("Worst range bit %d : %d. Worst edge bit %d : %d.\n", worst_bit, worst_bit_w, worst_edge, worst_edge_w);
  }

  if (dr_slew_type != DS_INVALID) {
    X__printf("\nFinal Results:\n");
    for (i = 0; i < 8; i++) {
      X__printf("Drive 0 to 8, Byte %d \n", i);
      X__printf("          slew 0   slew 1   slew 2   slew 3\n");
      for (b = 0; b < 8; b++) {
        X__printf("Bit %02d : ", b);
        for (w = 0; w < lvl_num; w++) {
          putc( (GET_BIT(b+(i*8)+(w*72)) ? '1' : '0') );
          if ((w & 7) == 7) putc(' ');
        }
        X__printf("\n");
      }
      X__printf("\n");
    }
  }

  ubsa_free((uint8_t*)test_pass);

  return (0);
}


// ('rd') 'wr' 'rd_gate' 'wr_dq'"

// NOTES: if rank interleave, it will use the indicated rank, and the interleaved rank.
//   - EX: 4 rank: 0:1, 2:3

int mem_screen(char *argv)
{
  static int32_t mcu;
  static int32_t rank;
  static uint32_t all_ranks;
  static int32_t rdlvl_range;
  static int32_t rdrise_range;
  static int32_t rdfall_range;
  static int32_t wrlvl_range;
  static int32_t rdgate_range;
  static int32_t wrdq_range;
  static int32_t vref_range;
  static uint32_t ecc_on;
  static uint32_t verbose;
  static uint32_t print_fail;
  static uint32_t do_help;
  static char *opt_str;

  int i, m, w, t, r;
  char memtest_opts[256];
  #define SHMOO_RANGE_NUM 7
  int32_t range_list[SHMOO_RANGE_NUM];

  const int rdlvl_i = 0;
  const int wrlvl_i = 1;
  const int rdgate_i = 2;
  const int wrdq_i = 3;
  const int rdrise_i = 4;
  const int rdfall_i = 5;
  const int vref_i = 6;

  int32_t lvl_val;
  int max_lvl;

  uint64_t *test_pass;
  uint32_t all_pass;
  uint32_t all_pass_rank;
  uint32_t rank_mask;
  uint32_t rank_iter;

  // option parsing vars
  int c;
  int first;
  int option_idx;
  char *tmp_var;

  static ubsa_long_options_s opts[] = {
    {"mcu",         'M', OPT_INT32,   1, &mcu,          0, "MCU to target (-1 for all)"},
    {"rank",        'R', OPT_INT32,   1, &rank,         0, "Rank to target (default = 0)"},
    {"all_ranks",   'r', OPT_UINT32,  0, &all_ranks,    1, "Run on all ranks"},
#ifdef STORM
    {"rdlvl_range", 'a', OPT_INT32,   1, &rdlvl_range,  0, "RdLvl range"},
#endif
#ifdef SHADOWCAT
    {"rdrise_range", 'A', OPT_INT32,   1, &rdrise_range,  0, "RdLvl Rise range"},
    {"rdfall_range", 'B', OPT_INT32,   1, &rdfall_range,  0, "RdLvl Fall range"},
#endif
    {"wrlvl_range", 'b', OPT_INT32,   1, &wrlvl_range,  0, "WrLvl range"},
    {"rdgate_range",'c', OPT_INT32,   1, &rdgate_range, 0, "Rd Gate range"},
    {"wrdq_range",  'd', OPT_INT32,   1, &wrdq_range,   0, "Wr DQ range"},
    {"vref_range",  'e', OPT_INT32,   1, &vref_range,   0, "Vref range"},
    {"",            'C', OPT_STRING,  1, &opt_str,      0, "memtest command"},
    {"ecc_on",      'E', OPT_INT32,   0, &ecc_on,       1, "Run test with ECC ON"},
    {"verbose",     'v', OPT_UINT32,  0, &verbose,      1, "Output all results"},
    {"print_fail",  'V', OPT_UINT32,  0, &print_fail,   1, "Output all results only when there is a failure"},
    {"help",        'h', OPT_UINT32,  0, &do_help,      1, "Print Help"},
    // TODO: Seed
    { NULL, 0, 0, 0, 0, 0, 0 }
  };

  do_help = 0;
  verbose = 0;
  print_fail = 0;
  ecc_on = 0;
  rdlvl_range = -1;
  wrlvl_range = -1;
  rdgate_range = -1;
  wrdq_range = -1;
  vref_range = -1;
  rdrise_range = -1;
  rdfall_range = -1;
  mcu = -1;
  rank = 0;
  all_ranks = 0;
  memtest_opts[0] = 0;

  first = 1;
  while (1) {
    c = ubsa_getopt_long((first ? argv : NULL), opts, &option_idx, &tmp_var);
    first = 0;
    if (c == -1)
      break;

    switch (c) {
      case 'C':
        strncpy(memtest_opts, opt_str, 256);
        memtest_opts[255] = 0;
        X__printf("Memtest command '%s'\n", memtest_opts);
        break;
      case '?':
        do_help = 1;
        break;
    }
  }

  if ((mcu >= 0) && !is_mcu_active(mcu)) {
    X__printf("MCU %d is not active\n", mcu);
    return (1);
  }

  if ((rdlvl_range == -1) && (wrlvl_range == -1) && (rdgate_range == -1) && (wrdq_range == -1)
    && (rdrise_range == -1) && (rdfall_range == -1) && (vref_range == -1))
  {
    do_help = 1;
  }

  if (do_help || (memtest_opts[0] == 0) || (rank > 3) || (mcu > 3))
  {
    X__printf("Usage:\n");
    ubsa_getopt_usage(opts);
    return (1);;
  }

  range_list[rdlvl_i] = rdlvl_range;
  range_list[wrlvl_i] = wrlvl_range;
  range_list[rdgate_i] = rdgate_range;
  range_list[wrdq_i] = wrdq_range;

  range_list[rdrise_i] = rdrise_range;
  range_list[rdfall_i] = rdfall_range;
  range_list[vref_i] = vref_range;

  max_lvl = rdlvl_range;
  if (wrlvl_range > max_lvl) max_lvl = wrlvl_range;
  if (rdgate_range > max_lvl) max_lvl = rdgate_range;
  if (wrdq_range > max_lvl) max_lvl = wrdq_range;
  if (vref_range > max_lvl) max_lvl = vref_range;
  if (rdrise_range > max_lvl) max_lvl = rdrise_range;
  if (rdfall_range > max_lvl) max_lvl = rdfall_range;

  memreg("--save");
  if (ecc_on) {
    memreg("--ecc_en 1");
  } else {
    memreg("--ecc_en 0");
  }

  max_lvl = 2*max_lvl  + 1;

  test_pass = (uint64_t *)ubsa_malloc(max_lvl*8*4*8); // this aligns to 16 bytes
  if (test_pass == NULL) {
    X__printf("malloc failed : size %d\n", max_lvl*8*4*8);
    return (-1);
  }

  all_pass = 1;

  rank_mask = 0;
  for (m = 0; m < 4; m++) {
    if ((mcu >= 0) && (mcu != m))
      continue;
    for (r = 0; r < 8; r++) {
      if (ubsa_is_rank_valid(m, r) && (get_rank_intlv(m, r) == r)) {
        rank_mask |= (1 << r);
      }
    }
  }
  if (verbose)
    X__printf("Rank mask : 0x%x\n", rank_mask);

  for (rank_iter = 0; rank_iter < 8; rank_iter++) {
    char rank_str[32];

    if (!all_ranks && (rank_iter != rank))
      continue;

    if (all_ranks && ((rank_mask & (1 << rank_iter)) == 0))
      continue;

    all_pass_rank = 1;

    for (t = 0; t < SHMOO_RANGE_NUM; t++) {
      uint32_t got_fail = 0;
      int lvl_step;

      if (range_list[t] == -1) {
        continue;
      }

      for (w = 0; w < max_lvl*4*8; w++)
        test_pass[w] = 0;
        lvl_step = (t == vref_i) ? 1 : 2;
      for (lvl_val = -range_list[t], w = 0; lvl_val <= range_list[t]; lvl_val+=lvl_step, w++) {
        int ret;
        uint64_t bit_error;

        if (t == rdlvl_i) {
          X__printf("Running RdLvl %3d : ", (int64_t)lvl_val);
          set_rdlvl_offset(mcu, rank_iter, lvl_val);
        }
        if (t == rdrise_i) {
          X__printf("Running RdLvl Rise %3d : ", (int64_t)lvl_val);
          set_rdlvl_rise_offset(mcu, rank_iter, lvl_val);
        }
        if (t == rdfall_i) {
          X__printf("Running RdLvl Fall %3d : ", (int64_t)lvl_val);
          set_rdlvl_fall_offset(mcu, rank_iter, lvl_val);
        }
        if (t == wrlvl_i) {
          X__printf("Running WrLvl %3d : ", (int64_t)lvl_val);
          set_wrlvl_offset(mcu, rank_iter, lvl_val);
        }
        if (t == rdgate_i) {
          X__printf("Running Rd Gate %3d : ", (int64_t)lvl_val);
          set_rdgate_offset(mcu, rank_iter, lvl_val);
        }
        if (t == wrdq_i) {
          X__printf("Running Wr DQ %3d : ", (int64_t)lvl_val);
          set_wrdq_offset(mcu, rank_iter, lvl_val);
        }
        if (t == vref_i) {
#ifdef SHADOWCAT
          X__printf("Running Vref %3d : ", (int64_t)lvl_val);
          set_vref_offset(mcu, lvl_val);
#endif
        }

        for (m = 0; m < 4; m++) {
          int e;
          if ((mcu >= 0) && (mcu != m))
            continue;
          e = mcu_phy_sw_adj_ctrlupdate(m);
          if (e) {
            got_fail = 1;
            X__printf("PHY SW ADJ CTRL UPDATE ERROR: mcu %d : 0x%x\n", m, e);
          }
        }

        ret = memtest_all_bits_rank(memtest_opts, mcu, rank_iter, ecc_on);
        if (ret) {
          got_fail = 1;
        }

        for (m = 0; m < 4; m++) {
          if ((mcu >= 0) && (mcu != m))
            continue;
          for (r = 0; r < 8; r++) {
            if (get_rank_intlv(m, r) == rank_iter) {
              bit_error = get_memtest_bit_errors_mcu_rank(m, r);
              if (bit_error != 0) {
                // TODO: early exit
                got_fail = 1;
  //              X__printf("FAIL MCU %d Rank %d : %016x\n", m, r, bit_error);
              }
              //  w lvls, 8 bits, 8 bytes
              for (i = 0; i < 64; i++) {
                if (bit_error & (1ull << i)) {
                  CLEAR_BIT(i+(m+(r+(w*8))*4)*64);
                } else {
                  SET_BIT(i+(m+(r+(w*8))*4)*64);
                }
              }
            }
          }
        }

        putc(ret ? '0' : '1');

        // don't run out of memory
        ubsa_dram_alloc_reset();

        // reset MCU FIFO
        mcu_phy_rdfifo_reset_all();

        if (got_fail) {
          X__printf(" fail \r");
        } else {
          X__printf("\r");
        }
      }

      if (got_fail) {
        X__printf("\nFAIL\n");
        all_pass = 0;
        all_pass_rank = 0;
      } else {
        X__printf("\nPASS\n");
      }

      if (verbose || (print_fail && got_fail)) {
        for (m = 0; m < 4; m++) {
          if (((mcu >= 0) && (mcu != m)) || !is_mcu_active(m))
            continue;
          for (r = 0; r < 8; r++) {
            if (get_rank_intlv(m, r) == rank_iter) {
              //  w lvls, 8 bits, 8 bytes
              for (i = 0; i < 64; i++) {
                X__printf("MCU %d Rank %d Bit %2d : ", m, r, i);
                for (lvl_val = -range_list[t], w = 0; lvl_val <= range_list[t]; lvl_val+=lvl_step, w++) {
                  if (lvl_val == 0) {
                    putc( (GET_BIT(i+(m+(r+(w*8))*4)*64) ? '*' : '%') );
                  } else {
                    putc( (GET_BIT(i+(m+(r+(w*8))*4)*64) ? '1' : '0') );
                  }
                }
                X__printf("\n");
              }
            }
          }
        }
      }

      memreg("--restore");
    }

    m = 0;
    rank_str[0] = 0;
    for (r = 0; r < 8; r++) {
      if (get_rank_intlv(0, r) == rank_iter) {
        m += __snprintf((rank_str + m), (32-m), "%d ", r)-1;
      }
    }
    X__printf("mem_screen test result (rank %s): %s\n", rank_str, (all_pass_rank ? "PASS" : "FAIL"));

  }

  memreg("--ecc_en 1");

  ubsa_free((uint8_t*)test_pass);

  if (all_ranks)
    X__printf("\nmem_screen test result (ALL ranks): %s\n", (all_pass ? "PASS" : "FAIL"));

  return (0);
}

