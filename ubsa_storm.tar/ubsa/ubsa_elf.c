/* Copyright (c) 2014 by Veloce Technologies.  All Rights Reserved. */
/* $Id: //depot/projects/osboot/MAIN/ubsa/ubsa_elf.c#3 $ */

#include "bbcutils.h"
#include "loadelf.h"
#include "ubsa_gzip.h"

#define _to64(x) (((uint64_t)(x)[0] & 0xffffffffull) | (((uint64_t)(x)[1] & 0xffffffffull) << 32))

void load_elf_mem_32(uint8_t *mem, int skip_zero, int verbose);
void load_elf_mem_64(uint8_t *mem, int skip_zero, int verbose);
int find_symbol_64(char *sym_name, uint64_t *sym_addr, uint8_t *mem, int verbose);
int find_symbol_32(char *sym_name, uint64_t *sym_addr, uint8_t *mem, int verbose);


void show_elf(uint8_t *mem)
{
  uint64_t offs;

  if ((mem[ EI_MAG0 ] != ELFMAG0) || (mem[ EI_MAG1 ] != ELFMAG1) ||
    (mem[ EI_MAG2 ] != ELFMAG2) || (mem[ EI_MAG3 ] != ELFMAG3))
  {
    X__printf("ELF Header wrong\n");
    return;
  }

  if ((mem[ EI_CLASS ] == ELFCLASS32) && (mem[ EI_DATA ] == ELFDATA2LSB)) {
    int ph;
    struct elf32_ehdr *hdr32 = (struct elf32_ehdr *)mem;

    X__printf("Entry point 0x%08x\n", hdr32->e_entry);

    offs = hdr32->e_phoff;

    for (ph = 0; ph < hdr32->e_phnum; ph++) {
      struct elf32_phdr *phdr = (struct elf32_phdr *)(mem + offs);
      offs += hdr32->e_phentsize;

      if (phdr->p_type != PT_LOAD) {
        X__printf("Section %d type not supported: %d\n", ph, phdr->p_type);
        continue;
      }
      if (phdr->p_memsz > 0) {
        X__printf("Pgm Hdr %2d : pa 0x%08x va 0x%08x fsz %d memsz %d align 0x%x\n", ph,
          phdr->p_paddr, phdr->p_vaddr, phdr->p_filesz, phdr->p_memsz, phdr->p_align);
      }
    }

// struct elf32_shdr

// struct elf32_sym


  } else if ((mem[ EI_CLASS ] == ELFCLASS64) && (mem[ EI_DATA ] == ELFDATA2LSB)) {
    int ph;
    struct elf64_ehdr *hdr64 = (struct elf64_ehdr *)mem;

    X__printf("Entry point 0x%016x\n", _to64(hdr64->e_entry_));

    offs = _to64(hdr64->e_phoff_);

    X__printf("Hdr sz %d - Ph sz %d\n", hdr64->e_ehsize, hdr64->e_phentsize);

    for (ph = 0; ph < hdr64->e_phnum; ph++) {
      struct elf64_phdr *phdr = (struct elf64_phdr *)(mem + offs);
      offs += hdr64->e_phentsize;

      if (_to64(phdr->p_memsz_) > 0) {
        X__printf("Pgm Hdr %2d : pa 0x%016x va 0x%016x fsz %d memsz %d align 0x%x type %d\n", ph,
          _to64(phdr->p_paddr_), _to64(phdr->p_vaddr_), _to64(phdr->p_filesz_), _to64(phdr->p_memsz_), _to64(phdr->p_align_), phdr->p_type);
      }
//      if (phdr->p_type != PT_LOAD) {
//        X__printf("Section %d type not supported: %d\n", ph, phdr->p_type);
//        continue;
//      }
    }


// struct elf64_shdr

// struct elf64_sym


  } else {
    X__printf("ELF class or endianess invalid\n");
    return;
  }


}

uint32_t is_elf_hdr_valid(uint8_t *mem)
{
  if (mem == NULL) {
    X__printf("is_elf_hdr_valid : NULL\n");
    return (0);
  }
  if ((mem[ EI_MAG0 ] != ELFMAG0) || (mem[ EI_MAG1 ] != ELFMAG1) ||
    (mem[ EI_MAG2 ] != ELFMAG2) || (mem[ EI_MAG3 ] != ELFMAG3))
  {
    return (0);
  }

  if (is_elf32(mem) || is_elf64(mem)) {
    return (1);
  }

  return (0);
}

uint32_t is_elf32(uint8_t *mem)
{
  return ((mem[ EI_CLASS ] == ELFCLASS32) && (mem[ EI_DATA ] == ELFDATA2LSB));
}

uint32_t is_elf64(uint8_t *mem)
{
  return ((mem[ EI_CLASS ] == ELFCLASS64) && (mem[ EI_DATA ] == ELFDATA2LSB));
}

uint64_t get_elf_entrty(uint8_t *mem)
{
  uint64_t ret = 0;

  if (is_elf32(mem)) {
    struct elf32_ehdr *hdr32 = (struct elf32_ehdr *)mem;
    ret = (uint64_t)hdr32->e_entry;
  } else if (is_elf64(mem)) {
    struct elf64_ehdr *hdr64 = (struct elf64_ehdr *)mem;
    ret = _to64(hdr64->e_entry_);
  }

  return (ret);
}

void load_elf_mem(uint8_t *mem, int skip_zero, int verbose)
{
  if (is_elf32(mem)) {
    load_elf_mem_32(mem, skip_zero, verbose);
  } else if (is_elf64(mem)) {
    load_elf_mem_64(mem, skip_zero, verbose);
  }
}

void load_elf_mem_32(uint8_t *mem, int skip_zero, int verbose)
{
  int ph;
  uint64_t offs;
  struct elf32_ehdr *hdr32 = (struct elf32_ehdr *)mem;

  offs = hdr32->e_phoff;

  for (ph = 0; ph < hdr32->e_phnum; ph++) {
    struct elf32_phdr *phdr = (struct elf32_phdr *)(mem + offs);
    offs += hdr32->e_phentsize;

    if (phdr->p_memsz == 0) {
      continue;
    }

    if (skip_zero && (phdr->p_vaddr == 0)) {
      continue;
    }

    if (verbose) {
      X__printf("Pgm32 Hdr %2d : pa 0x%016x va 0x%016x fsz %d offs %d memsz %d align 0x%x type %d\n", ph,
        phdr->p_paddr, phdr->p_vaddr, phdr->p_filesz, phdr->p_offset, phdr->p_memsz, phdr->p_align, phdr->p_type);
      X__printf("[0x%x] -> [0x%x] sz %d (0x%x)\n", (uint64_t)(mem + phdr->p_offset),
        (uint64_t)(phdr->p_vaddr), (uint64_t)phdr->p_filesz);
    }

    if ((phdr->p_vaddr & 7) != ((uint64_t)(mem + phdr->p_offset) & 7)) {
      bcopy((char *)(mem + phdr->p_offset), (char *)((uint64_t)phdr->p_vaddr), phdr->p_filesz);
    } else {
      memcpy((void*)((uint64_t)phdr->p_vaddr), (mem + phdr->p_offset), phdr->p_filesz);
    }

    asm volatile("dsb sy");
    flush_cache((uint64_t)phdr->p_vaddr, phdr->p_filesz);
  }
}

void load_elf_mem_64(uint8_t *mem, int skip_zero, int verbose)
{
  int ph;
  uint64_t offs;
  uint64_t vaddr;
  struct elf64_ehdr *hdr64 = (struct elf64_ehdr *)mem;

  offs = _to64(hdr64->e_phoff_);

  for (ph = 0; ph < hdr64->e_phnum; ph++) {
    struct elf64_phdr *phdr = (struct elf64_phdr *)(mem + offs);
    offs += hdr64->e_phentsize;
    vaddr = _to64(phdr->p_vaddr_);

    if (_to64(phdr->p_memsz_) == 0) {
      continue;
    }

    if (skip_zero && (vaddr == 0)) {
      continue;
    }

    if (verbose) {
      X__printf("Pgm64 Hdr %2d : pa 0x%016x va 0x%016x fsz %d offs %d memsz %d align 0x%x type %d\n", ph,
        _to64(phdr->p_paddr_), vaddr, _to64(phdr->p_filesz_),
        _to64(phdr->p_offset_), _to64(phdr->p_memsz_), _to64(phdr->p_align_), phdr->p_type);
      X__printf("[0x%x] -> [0x%x] sz %d (0x%x)\n", (uint64_t)(mem + _to64(phdr->p_offset_)),
        (uint64_t)vaddr, _to64(phdr->p_filesz_));
    }

    if ((vaddr & 7) != ((uint64_t)(mem + _to64(phdr->p_offset_)) & 7)) {
      bcopy((char *)(mem + _to64(phdr->p_offset_)), (char *)vaddr, _to64(phdr->p_filesz_));
    } else {
      memcpy((void*)vaddr, (mem + _to64(phdr->p_offset_)), _to64(phdr->p_filesz_));
    }

    asm volatile("dsb sy");
    flush_cache(vaddr, _to64(phdr->p_filesz_));
  }
}

int find_symbol(char *sym_name, uint64_t *sym_addr, uint8_t *mem, int verbose)
{
  if (is_elf32(mem)) {
    return find_symbol_32(sym_name, sym_addr, mem, verbose);
  } else if (is_elf64(mem)) {
    return find_symbol_64(sym_name, sym_addr, mem, verbose);
  }

  return (0);
}

int find_symbol_64(char *sym_name, uint64_t *sym_addr, uint8_t *mem, int verbose)
{
  int ph;
  uint64_t offs;
  struct elf64_shdr *strsec;
  struct elf64_ehdr *hdr64 = (struct elf64_ehdr *)mem;

  struct elf64_sym *symtab;
  int symtab_size=0;
  struct elf64_shdr *symstr;

  offs = _to64(hdr64->e_shoff_);

  strsec = (struct elf64_shdr *)(mem + offs + (hdr64->e_shstrndx * hdr64->e_shentsize));

  symtab = NULL;
  symstr = NULL;

  for (ph = 0; (ph < hdr64->e_shnum) && (hdr64->e_shstrndx > 0); ph++) {
    char *str;
    struct elf64_shdr *shdr = (struct elf64_shdr *)(mem + offs);
    offs += hdr64->e_shentsize;

    str = (char *)(mem + _to64(strsec->sh_offset_) + shdr->sh_name);

    if (strcmp(".symtab", str) == 0) {
      symtab = (struct elf64_sym *)(mem + _to64(shdr->sh_offset_));
      symtab_size = (_to64(shdr->sh_size_)/sizeof(struct elf64_sym));
    }
    if (strcmp(".strtab", str) == 0) {
      symstr = shdr;
    }
  }

  if ((symtab == NULL) || (symstr == NULL)) {
    return (0);
  }

  for (ph = 0; ph < symtab_size; ph++) {
    char *str;
    str = (char *)(mem + _to64(symstr->sh_offset_) + symtab[ph].st_name);
    if (strcmp(sym_name, str) == 0) {
      if (verbose)
        X__printf("Symbol %d : (%d) '%s' 0x%x\n", ph, symtab[ph].st_name, str, _to64(symtab[ph].st_value_));
      *sym_addr = _to64(symtab[ph].st_value_);
      return (1);
    }
  }

  return (0);
}

int find_symbol_32(char *sym_name, uint64_t *sym_addr, uint8_t *mem, int verbose)
{
  int ph;
  uint64_t offs;
  struct elf32_shdr *strsec;
  struct elf32_ehdr *hdr32 = (struct elf32_ehdr *)mem;

  struct elf32_sym *symtab;
  int symtab_size=0;
  struct elf32_shdr *symstr;

  offs = hdr32->e_shoff;

  strsec = (struct elf32_shdr *)(mem + offs + (uint64_t)(hdr32->e_shstrndx * hdr32->e_shentsize));

  symtab = NULL;
  symstr = NULL;

  for (ph = 0; (ph < hdr32->e_shnum) && (hdr32->e_shstrndx > 0); ph++) {
    char *str;
    struct elf32_shdr *shdr = (struct elf32_shdr *)(mem + offs);
    offs += hdr32->e_shentsize;

    str = (char *)(mem + strsec->sh_offset + shdr->sh_name);

    if (strcmp(".symtab", str) == 0) {
      symtab = (struct elf32_sym *)(mem + shdr->sh_offset);
      symtab_size = (shdr->sh_size/sizeof(struct elf32_sym));
    }
    if (strcmp(".strtab", str) == 0) {
      symstr = shdr;
    }
  }

  if ((symtab == NULL) || (symstr == NULL)) {
    return (0);
  }

  for (ph = 0; ph < symtab_size; ph++) {
    char *str;
    str = (char *)(mem + symstr->sh_offset + symtab[ph].st_name);
    if (strcmp(sym_name, str) == 0) {
      if (verbose)
        X__printf("Symbol %d : (%d) '%s' 0x%x\n", ph, symtab[ph].st_name, str, symtab[ph].st_value);
      *sym_addr = symtab[ph].st_value;
      return (1);
    }
  }

  return (0);
}

static uint64_t name_base(char *str)
{
  uint64_t i, c;

  i = strlen(str);
  if (i == 0)
    return 0;
  i--;
  c = 0;
  while ((i > 0) && (str[i] != '\0') && (c < 2)) {
    if (str[i] == '.')
      c++;
    i--;
  }
  return (i);
}

int check_next_dual(uint8_t *mem_ptr, uint8_t **next_mem, char *_name, char *ext)
{
  char next_name[512];
  char e_name[512];
  uint8_t *mem;
  uint8_t *tmp_ptr;
  size_t s, e;

  tmp_ptr = mem_ptr;

  e = strlen(_name);
  if (e <= 4)
    return (0);
  strcpy(e_name, _name);
  e_name[e-4] = '\0';

  e = strlen(ext);

  while (1) {
    mem = get_next_file(&tmp_ptr, next_name);

    if ((mem != NULL) && (e_name != NULL)) {
      s = name_base(next_name);
      if (s <= 4)
        return (0);
      next_name[s+1] = '\0';

//      X__printf("check_next_dual (%s) next %s\n", e_name, next_name);

      if (strcmp(e_name, next_name) != 0) {
        // didn't find the file we wanted
        return (0);
      }

      // base of file e_name matches, check the extension
      if (strncmp(next_name + s+2, ext, e) == 0) {
        *next_mem = mem;
        return (1);
      }

    } else {
      return (0);
    }
  }
  return (0);
}

uint8_t *get_next_file(uint8_t **mem_ptr, char *name)
{
  uint8_t *ret;
  uint64_t flen;
  int eof_count;
  int long_name;
  struct tar_header *hdr;

  if (*mem_ptr == NULL)
    return (NULL);

  // check if this is an ELF file
  if (((*mem_ptr)[ EI_MAG0 ] == ELFMAG0) && ((*mem_ptr)[ EI_MAG1 ] == ELFMAG1) &&
    ((*mem_ptr)[ EI_MAG2 ] == ELFMAG2) && ((*mem_ptr)[ EI_MAG3 ] == ELFMAG3))
  {
    ret = *mem_ptr;
    *mem_ptr = NULL; // only one file here

    if (name != NULL) {
      strcpy(name, "*ELF*");
    }

    return (ret);
  }

  // should be a TAR file
  hdr = (struct tar_header *)(*mem_ptr);

  if (strncmp("ustar", hdr->magic, 5) != 0) {
    X__printf("tar error magic value not found at 0x%x\n", (uint64_t)(*mem_ptr));
    return (NULL);
  }

  flen = simple_strtoull(hdr->size, NULL, 8);

  if (strncmp("././@LongLink", hdr->name, 13) == 0) {
    long_name = 1;

    ret = (*mem_ptr + 512);

    if (name != NULL) {
      strncpy(name, (char *)ret, 512);
    }

//    X__printf("LongLink : 1'%s' 2'%s' 3'%s'\n", hdr->name, name, (char *)ret);

    flen = (flen + 511) & ~511;
    *mem_ptr += (512 + flen);

    hdr = (struct tar_header *)(*mem_ptr);
    flen = simple_strtoull(hdr->size, NULL, 8);

  } else {
    long_name = 0;
  }

  ret = (*mem_ptr + 512);
  if (!long_name && (name != NULL)) {
    strncpy(name, hdr->name, 512);
  }

  *mem_ptr += (flen + 0x1FF) & ~0x1FF;

  eof_count = 0;
  while (eof_count < 2) {
    hdr = (struct tar_header *)(*mem_ptr);
    if (strncmp("ustar", hdr->magic, 5) == 0) {
      break;
    } else{
      eof_count++;
      *mem_ptr += 512;
    }
  }

  if (eof_count == 2) {
    *mem_ptr = NULL;
  }

  return (ret);
}


int read_symbol_elf_64(char *sym_name, uint8_t **data_addr, uint8_t *mem, int verbose)
{
  int ph;
  uint64_t offs;
  uint64_t sym_addr;
  uint64_t vaddr;
  struct elf64_ehdr *hdr64 = (struct elf64_ehdr *)mem;

  if (!find_symbol_64(sym_name, &sym_addr, mem, verbose)) {
    if (verbose)
      X__printf("read_symbol_elf_64 symbol not found '%s'\n", sym_name);
    return 0;
  }

  offs = _to64(hdr64->e_phoff_);

  for (ph = 0; ph < hdr64->e_phnum; ph++) {
    struct elf64_phdr *phdr = (struct elf64_phdr *)(mem + offs);
    offs += hdr64->e_phentsize;
    vaddr = _to64(phdr->p_vaddr_);

    if (_to64(phdr->p_memsz_) == 0) {
      continue;
    }

    if ((sym_addr >= vaddr) && (sym_addr < (vaddr + _to64(phdr->p_filesz_)))) {
      *data_addr = (mem + _to64(phdr->p_offset_)) + (sym_addr - vaddr);
      if (verbose)
        X__printf("read_symbol_elf_64 '%s' : sym addr 0x%x, vaddr 0x%x, filesz 0x%x\n",
          sym_name, sym_addr, vaddr, _to64(phdr->p_filesz_));
      return 1;
    }
  }
  return 0;

}

int read_symbol_elf_32(char *sym_name, uint8_t **data_addr, uint8_t *mem, int verbose)
{
  int ph;
  uint64_t offs;
  uint64_t sym_addr;
  struct elf32_ehdr *hdr32 = (struct elf32_ehdr *)mem;

  if (!find_symbol_32(sym_name, &sym_addr, mem, verbose)) {
    if (verbose)
      X__printf("read_symbol_elf_32 symbol not found '%s'\n", sym_name);
    return 0;
  }

  offs = hdr32->e_phoff;

  for (ph = 0; ph < hdr32->e_phnum; ph++) {
    struct elf32_phdr *phdr = (struct elf32_phdr *)(mem + offs);
    offs += hdr32->e_phentsize;

    if (phdr->p_memsz == 0) {
      continue;
    }

    if ((sym_addr >= phdr->p_vaddr) && (sym_addr < (phdr->p_vaddr + phdr->p_filesz))) {
      *data_addr = (mem + phdr->p_offset) + (sym_addr - phdr->p_vaddr);
      if (verbose)
        X__printf("read_symbol_elf_32 '%s' : sym addr 0x%x, vaddr 0x%x, filesz 0x%x\n",
          sym_name, sym_addr, phdr->p_vaddr, phdr->p_filesz);
      return 1;
    }
  }
  return 0;
}

int read_symbol_elf(char *sym_name, uint8_t **data_addr, uint8_t *mem, int verbose)
{
  if (is_elf32(mem)) {
    return read_symbol_elf_32(sym_name, data_addr, mem, verbose);
  } else if (is_elf64(mem)) {
    return read_symbol_elf_64(sym_name, data_addr, mem, verbose);
  }

  return (0);
}


#define GZ_FLAG_FTEXT     (1 << 0)
#define GZ_FLAG_FHCRC     (1 << 1)
#define GZ_FLAG_FEXTRA    (1 << 2)
#define GZ_FLAG_FNAME     (1 << 3)
#define GZ_FLAG_FCOMMENT  (1 << 4)

int decompress_gzip(char *argv)
{
  static uint64_t gz_addr;
  static uint64_t uc_addr;
  static uint32_t check_size;
  static char *tmp_str;
  static uint32_t no_cache;
  static uint32_t do_help;

  uint8_t *gz_data;
  uint8_t *uc_data;
  uint8_t gz_flag;
  uint8_t gz_xfl;
  uint8_t gz_os;
  uint32_t gz_mtime;
  uint32_t fl_len;
  int got_uc_addr;
  int got_gz_addr;
  uint32_t do_verbose;
  uint64_t r;

  int puff_ret;
  uint32_t destlen;
  uint32_t sourcelen;

  // option parsing vars
  int c;
  int first;
  int option_idx;
  char *tmp_var;

  static ubsa_long_options_s opts[] = {
    {"from",        'f', OPT_UINT64,  1, &gz_addr,      0, "Compressed memory location"},
    {"to",          't', OPT_UINT64,  1, &uc_addr,      0, "Destination memory"},
    {"size",        's', OPT_UINT32,  0, &check_size,   1, "Check decompressed size"},
    {"no_cache",    'c', OPT_UINT32,  0, &no_cache,     1, "Don't turn on cache if it is off"},
    {"verbose",     'v', OPT_UINT32,  0, &tmp_str,      1, "Print Verbose Debug info"},
    {"help",        'h', OPT_UINT32,  0, &do_help,      1, "Print Help"},
    { NULL, 0, 0, 0, 0, 0, 0 }
  };

  no_cache = 0;
  do_verbose = 0;
  do_help = 0;
  got_uc_addr = 0;
  got_gz_addr = 0;
  check_size = 0;

  first = 1;
  while (1) {
    c = ubsa_getopt_long((first ? argv : NULL), opts, &option_idx, &tmp_var);
    first = 0;
    if (c == -1)
      break;

    switch (c) {
      case 'v':
        do_verbose++;
        break;
      case 'f':
        got_gz_addr = 1;
        break;
      case 't':
        got_uc_addr = 1;
        break;
      case '?':
        do_help = 1;
        break;
    }
  }

  if (do_help || !got_gz_addr || !(check_size || got_uc_addr) )
  {
    X__printf("Usage:\n");
    ubsa_getopt_usage(opts);
    return (1);;
  }

  if (dcache_status()) // cache is on
    no_cache = 1;

  gz_data = (uint8_t *)gz_addr;
  uc_data = (uint8_t *)uc_addr;
  uc_data = uc_data;

  if ((gz_data[0] != 31) || (gz_data[1] != 139) || (gz_data[2] != 8)) {
    X__printf("Gzip magic number not found : %x %x %x\n",
      (uint64_t)gz_data[0], (uint64_t)gz_data[1], (uint64_t)gz_data[2]);
    return (1);
  }

  if (!no_cache) {
    setup_page_tables();
    enable_caches();
  }

  gz_flag = gz_data[3];
  gz_mtime = ((uint32_t)gz_data[7] << 24) | ((uint32_t)gz_data[6] << 16) | ((uint32_t)gz_data[5] << 8) | (uint32_t)gz_data[4];
  gz_xfl = gz_data[8];
  gz_os = gz_data[9];

  if (do_verbose > 0)
    X__printf("Gzip time %d os %x xfl %x\n", gz_mtime, gz_os, gz_xfl);

  fl_len = 0;
  if (gz_flag != 0) {
    if (do_verbose > 0)
      X__printf("Flags: ");
    if (gz_flag & GZ_FLAG_FTEXT) {
      if (do_verbose > 0)
        X__printf("ftext ");
    }
    if (gz_flag & GZ_FLAG_FEXTRA) {
      uint16_t len;
      len = gz_data[10] | (gz_data[11] << 8);
      if (do_verbose > 0)
        X__printf("fextra %d ", len);
      fl_len += len + 2;
    }
    if (gz_flag & GZ_FLAG_FNAME) {
      uint32_t fnlen = 0;
      if (do_verbose > 0)
        X__printf("fname '");
      while (gz_data[fnlen + fl_len + 10] != 0) {
        if (do_verbose > 0)
          putc(gz_data[fnlen + fl_len + 10]);
        fnlen++;
      }
      fl_len += fnlen+1;
      if (do_verbose > 0)
        X__printf("' ");
    }
    if (gz_flag & GZ_FLAG_FCOMMENT) {
      uint32_t fclen = 0;
      if (do_verbose > 0)
        X__printf("fcomment ");
      while (gz_data[fclen + fl_len + 10] != 0) {
        if (do_verbose > 0)
          putc(gz_data[fclen + fl_len + 10]);
        fclen++;
      }
      fl_len += fclen+1;
      if (do_verbose > 0)
      X__printf("' ");
    }
    if (gz_flag & GZ_FLAG_FHCRC) {
      if (do_verbose > 0)
        X__printf("fhcrc ");
      fl_len += 2;
    }
    if (do_verbose > 0)
      X__printf("\n");
  }

  if (do_verbose > 0)
    X__printf("Data start : %d\n", fl_len + 10);

  gz_data += fl_len + 10;

  if (!got_uc_addr)
    uc_data = NULL;

  sourcelen = 0x80000000; // assume it's less than this much
  destlen = 0x80000000; // assume it's less than this much
  puff_ret = puff(uc_data, &destlen, gz_data, &sourcelen);

  if (do_verbose > 0)
    X__printf("Decompress : status %d processed %d output size %d\n", puff_ret, sourcelen, destlen);

  if (puff_ret != 0)
    X__printf("Decompress FAILED\n");

  if (!no_cache) {
    flush_dcache_all();

    // make sure caches are off
    r = 0x30c50830;
    asm volatile("msr sctlr_el2, %0"::"r" (r));
    invalidate_icache_all();

    asm volatile("msr   VTTBR_EL2, xzr");
    asm volatile("msr   VTCR_EL2, xzr");
    asm volatile("msr   TTBR0_EL2, xzr");
    asm volatile("msr   TTBR0_EL1, xzr");
    asm volatile("msr   TTBR1_EL1, xzr");
    asm volatile("msr   MAIR_EL2, xzr");
    asm volatile("msr   MAIR_EL1, xzr");
    asm volatile("tlbi  ALLE1");
    asm volatile("tlbi  ALLE2");
    asm volatile("dsb   SY");
    asm volatile("isb");
  }

  return (0);
}


