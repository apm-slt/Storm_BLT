/* Copyright (c) 2014 by Veloce Technologies.  All Rights Reserved. */
/* $Id: //depot/projects/osboot/MAIN/ubsa/ubsa_avp.c#6 $ */

#include "bbcutils.h"
#include "loadelf.h"


void load_elf(char *mem, int set_entry, uint64_t entry);
void *load_avp_base(uint32_t proc, void *arg);

void *avp_monitor_thread(uint32_t proc, void *arg);

//static void reconfig_phys_memory();

extern void *ubsa_exception_base;

extern uint32_t g_mmu_enable;

#define _to64(x) (((uint64_t)(x)[0] & 0xffffffffull) | (((uint64_t)(x)[1] & 0xffffffffull) << 32))

typedef struct {
  uint8_t *mem[3]; // a32 tum a64
  int verbose;
  int check_oslock;
  // proc which should load the ELF into memory
  uint32_t load_proc;
  uint32_t volatile load_ok;
  uint32_t lock_id;
  uint32_t cores;
  uint32_t volatile counter;
  elf_start_func func;
  uint32_t system_status[NUM_PROCESSORS];
  s_avp_retval ret[NUM_PROCESSORS];
} s_avp_base_args;

int check_avp()
{
  int r;
  char d[256];

  r = can_run_avps(d, 256);
  if (!r)
    X__printf("Cannot run AVPs with this config: %s\n", d);

  return (r);
}

typedef enum {
  AVP_TYPE_DUAL, // .a32 .a64
  AVP_TYPE_DUALA32, // .a32 .aa64
  AVP_TYPE_DUALTHUMB, // .tum .ta64
  AVP_TYPE_A32, // .a32
  AVP_TYPE_THUMB, // .tum
  AVP_TYPE_A64 // .a64
} avp_test_type_e;

typedef struct {
  avp_test_type_e type[6];
  uint32_t min_cores;
  uint32_t max_cores;
} avp_test_info_s;

uint64_t read_avp_file(uint8_t *mem, avp_test_info_s *avp)
{
  uint64_t avp_count = 0;
  uint32_t start, end;
  int state = 0;

  start = 0;
  end = 0;

  while (state < 3) {
    char str[512];

    while ((mem[end] != ' ') && (mem[end] != '\n') && (mem[end] != '\r') && (end < 512)) {
      end++;
    }
    if (end >= 512) { // error
      X__printf("read_avp_file .avp file parse error\n");
      return (0);
    }
//    strncpy(str, (char *)(mem + start), end-start);
//    X__printf("read_avp_file got '%s'\n", str);

    if (state == 0) {
      if (mem[end] != ' ')
        state = 1;

      if (strncmp("dual", (char *)(mem + start), end-start-1) == 0) {
        avp->type[avp_count] = AVP_TYPE_DUAL;
      } else if (strncmp("duala32", (char *)(mem + start), end-start-1) == 0) {
        avp->type[avp_count] = AVP_TYPE_DUALA32;
      } else if (strncmp("dualthumb", (char *)(mem + start), end-start-1) == 0) {
        avp->type[avp_count] = AVP_TYPE_DUALTHUMB;
      } else if (strncmp("a32", (char *)(mem + start), end-start-1) == 0) {
        avp->type[avp_count] = AVP_TYPE_A32;
      } else if (strncmp("thumb", (char *)(mem + start), end-start-1) == 0) {
        avp->type[avp_count] = AVP_TYPE_THUMB;
      } else if (strncmp("a64", (char *)(mem + start), end-start-1) == 0) {
        avp->type[avp_count] = AVP_TYPE_A64;
      } else {
        X__printf("read_avp_file test type not found '%s'\n", str);
        return (0);
      }
      avp_count++;
    } else if (state == 1) {
      avp->min_cores = simple_strtoul((char *)(mem + start), NULL, 0);
      state++;
    } else if (state == 2) {
      avp->max_cores = simple_strtoul((char *)(mem + start), NULL, 0);
      state++;
    }
    start = end + 1;
    end = start;

  }
//  X__printf("read_avp_file min %d max %d\n", avp->min_cores, avp->max_cores);

  return avp_count;
}

static void check_oslock()
{
  register uint64_t i;

  asm volatile("mrs     %0, OSLSR_EL1":"=r" (i));
  if ((i & 2) == 0) {
    // OS Lock is not set, set it and clear MDSCR_EL1
    asm volatile("msr   MDSCR_EL1, xzr");
    i = 1;
    asm volatile("msr   OSLAR_EL1, %0"::"r" (i));
    asm volatile("isb");
  }
}


static int s_did_iob_remap = 0;

static char *s_avp_exclude_list[] = {
  "app/branch/b_a1",
  "app/branch/b_t",
  "app/branch/bl",
  "app/branch/blx_imm",
#ifdef STORM
  "oapp/crypto/",
  "oapp/crc/",
#endif
  "osys/paging/el1_aarch32/s1s2/vmsa/ldm_interrupt", // trickbox

// To Debug //
  "sys/paging/v7/sctlr_wxn",
  "sys/paging/v7_lpae/sctlr_wxn",
  "sys/paging/v7_lpae/ttbr1",
  "osys/exceptions/priority/exception_vector_catch",
  "osys/paging/hyp/aptable",
  "osys/paging/hyp/xntable",

  // strega
#ifdef SHADOWCAT
  "osys/paging/el1_aarch64/s1only/par_",
  "sys/paging/v7/cache_faults",

  // memory out of range
  "osys/paging/hyp/permission_faults",
  "osys/paging/el1_aarch64/s1only/access_flag_el0.",
  "osys/paging/el1_aarch64/s1only/access_flag_el1.",
  "osys/paging/el1_aarch64/s1only/addr_size_faults.",
  "osys/paging/el1_aarch64/s1only/aptable_el0.",
  "osys/paging/el1_aarch64/s1only/aptable_el0.",
  "osys/paging/el1_aarch64/s1only/aptable_el1.",
  "osys/paging/el1_aarch64/s1only/g64_access_flag_el0.",
  "osys/paging/el1_aarch64/s1only/g64_access_flag_el1.",
  "osys/paging/el1_aarch64/s1only/g64_addr_size_faults_el0.",
  "osys/paging/el1_aarch64/s1only/g64_addr_size_faults_el1.",
  "osys/paging/el1_aarch64/s1only/g64_permission_faults_el0.",
  "osys/paging/el1_aarch64/s1only/g64_permission_faults_el1.",
  "osys/paging/el1_aarch64/s1only/g64_tcr_tb0.",
  "osys/paging/el1_aarch64/s1only/l3block.",
  "osys/paging/el1_aarch64/s1only/mmu_disabled.",
  "osys/paging/el1_aarch64/s1only/permission_faults_el0.",
  "osys/paging/el1_aarch64/s1only/permission_faults_el1.",
  "osys/paging/el1_aarch64/s1only/pxntable_el0.",
  "osys/paging/el1_aarch64/s1only/pxntable_el1.",
  "osys/paging/el1_aarch64/s1only/tcr_a1.",
  "osys/paging/el1_aarch64/s1only/tcr_t1sz_test2.",
  "osys/paging/el1_aarch64/s1only/tcr_tb0.",
  "osys/paging/el1_aarch64/s1only/tcr_tb0_el2.",
  "osys/paging/el1_aarch64/s1only/tcr_tb1_el2.",
  "osys/paging/el1_aarch64/s1only/xntable_el0.",
  "osys/paging/el1_aarch64/s1only/xntable_el1.",
  "osys/paging/el1_aarch64/s1s2/vtcr_t0sz_sl0.",
  "osys/paging/el1_aarch64/s2only/access_flag_el0.",
  "osys/paging/el1_aarch64/s2only/access_flag_el1.",
  "osys/paging/el1_aarch64/s2only/g64_access_flag_el0.",
  "osys/paging/el1_aarch64/s2only/g64_access_flag_el1.",
  "osys/paging/el1_aarch64/s2only/g64_permission_faults_el0.",
  "osys/paging/el1_aarch64/s2only/g64_permission_faults_el1.",
  "osys/paging/el1_aarch64/s2only/g64_tcr_t0sz.",
  "osys/paging/el1_aarch64/s2only/g64_tcr_t0sz_sl0.",
  "osys/paging/el1_aarch64/s2only/mmu_disabled.",
  "osys/paging/el1_aarch64/s2only/permission_faults_el0.",
  "osys/paging/el1_aarch64/s2only/permission_faults_el1.",
  "osys/paging/el1_aarch64/s2only/tcr_t0sz.",
  "osys/paging/el1_aarch64/s2only/tcr_t0sz_sl0.",
  "osys/paging/el1_aarch64/s2only/tcr_tbi_tge_on.",
  "osys/paging/hyp/access_flag.",
  "osys/paging/hyp/access_flag_g64.",
  "osys/paging/hyp/addr_size_fault.",
  "osys/paging/hyp/addr_size_fault_g64.",
  "osys/paging/hyp/cont_hint.",
  "osys/paging/hyp/l2blk.",
  "osys/paging/hyp/mmu_disabled.",
  "osys/paging/hyp/tcr_tbi.",


  "sys/paging/v7/par_ext_abort.",
  "sys/paging/v7/sctlr_uwxn1.",
  "sys/paging/v7/trans_table_ext_abort.",
  "sys/paging/v7/trans_table_pd0pd1_fault.",
  "sys/paging/v7/trans_table_supersections.",
  "sys/paging/v7_lpae/addr_size_trans_faults.",
  "sys/paging/v7_lpae/l1blk_t0sz0_t1sz0.",
  "sys/paging/v7_lpae/l1blk_t0sz0_t1sz7.",
  "sys/paging/v7_lpae/l1blk_t0szN_t1sz0.",
  "sys/paging/v7_lpae/l2blk_t0sz0_t1sz0.",
  "sys/paging/v7_lpae/l3page_t0sz0_t1sz0.",
  "sys/paging/v7_lpae/page_perm_fault_mul.",
  "sys/paging/v7_lpae/sctlr_uwxn1.",
  "sys/paging/v7_lpae/ttbr0.",
  "sys/paging/v7_lpae/v7_ext_supersections.",

  "app/branch/bx.",
  "app/branch/bxj.",

#endif

// Broken
  "osys/paging/el1_aarch64/s1only/par_access_flag",

  NULL
};

int run_avp_base(char *argv)
{
  static uint64_t addr;
  static char *tmp_str;
  static uint32_t no_chk_oslock;
  static uint32_t do_verbose;
  static uint32_t do_help;

  int i;
  int got_addr;
  uint8_t *test_mem;
  uint8_t *next_test;
  char name[512];
  char test_name[512];
  int skip_to, found_skipped;
  int tname_len;
  char *tok, *tt;
  uint32_t count;
  uint32_t pass_count;
  uint32_t fail_count;
  uint32_t skip_count;
  uint32_t got_fail;
  uint32_t sys_err;
  uint32_t x;
  uint32_t core_map[NUM_PROCESSORS];
  uint32_t core_set;
  uint32_t avp_test_count;
  avp_test_info_s avp_tests;
  s_avp_base_args *avp_args;
  uint32_t use_cpu0;

  // option parsing vars
  int c;
  int first;
  int option_idx;
  char *tmp_var;

  static ubsa_long_options_s opts[] = {
    {"addr",        'a', OPT_UINT64,  1, &addr,         0, "AVP ELF file load address"},
    {"name",        'n', OPT_STRING,  1, &tmp_str,      0, "Test to run"},
    {"skip_to",     's', OPT_STRING,  1, &tmp_str,      0, "Start running after this test"},
    {"core",        'c', OPT_STRING,  1, &tmp_str,      0, "Core order (0,1,2,3,4,5,6,7)"},
    {"no_oslock",   'o', OPT_STRING,  0, &no_chk_oslock,1, "Don't check OS LOCK state"},
    {"verbose",     'v', OPT_UINT32,  0, &tmp_str,      1, "Print Verbose Debug info"},
    {"help",        'h', OPT_UINT32,  0, &do_help,      1, "Print Help"},
    { NULL, 0, 0, 0, 0, 0, 0 }
  };

  do_verbose = 0;
  do_help = 0;
  no_chk_oslock = 0;
  addr = 0;
  got_addr = 0;
  skip_to = 0;
  test_name[0] = 0;
  core_set = 0;
  for (i = 0; i < NUM_PROCESSORS; i++)
    core_map[i] = i;

  first = 1;
  while (1) {
    c = ubsa_getopt_long((first ? argv : NULL), opts, &option_idx, &tmp_var);
    first = 0;
    if (c == -1)
      break;

    switch (c) {
      case 'v':
        do_verbose++;
        break;
      case 'a':
        got_addr = 1;
        break;
      case 'n':
        strncpy(test_name, tmp_str, 512);
        if (skip_to) do_help = 1;
        break;
      case 's':
        if (test_name[0] != 0) do_help = 1;
        strncpy(test_name, tmp_str, 512);
        skip_to = 1;
        break;
      case 'c':
        i = 0;
        tt = ubsa_strtok(tmp_str, ",", &tok);
        while ((tt != NULL) && (i < NUM_PROCESSORS)) {
          x = simple_strtoul(tt, NULL, 0);
          if ((core_set & (1 << x)) != 0) {
            X__printf("Dup core in list: %d ('%s')\n", x, tt);
            do_help = 1;
          }
          core_map[i] = x;
          core_set |= (1 << x);
          i++;
          tt = ubsa_strtok(NULL, ",", &tok);
        }
        for (x = 0; (x < NUM_PROCESSORS) && (i < NUM_PROCESSORS); x++) {
          if ((core_set & (1 << x)) == 0) {
            core_map[i] = x;
            i++;
          }
        }
        break;
      case '?':
        do_help = 1;
        break;
    }
  }

  if (do_help | !got_addr)
  {
    X__printf("Usage:\n");
    ubsa_getopt_usage(opts);
    return (1);;
  }

  if (!check_avp()) {
    return (-1);
  }

  if (!s_did_iob_remap) {
    set_iob_remap_tar5(0x000001d0);
    set_iob_remap_rng(5, 0x000007ff);
    set_iob_remap_bar(5, 0x00000000);
    s_did_iob_remap = 1;

    asm volatile("tlbi  ALLE1IS");
    asm volatile("tlbi  ALLE2IS");
    asm volatile("dsb   SY");
    asm volatile("isb");

    if (!no_chk_oslock)
      check_oslock();

    invalidate_icache_all();
    invalidate_dcache_all();

    X__printf("Wrote IOB Remap\n");
  }

//  X__printf("Core list: %d %d %d %d %d %d %d %d\n",
//    (uint64_t)core_map[0], (uint64_t)core_map[1], (uint64_t)core_map[2], (uint64_t)core_map[3],
//    (uint64_t)core_map[4], (uint64_t)core_map[5], (uint64_t)core_map[6], (uint64_t)core_map[7]);

  avp_args = (s_avp_base_args *)ubsa_malloc(sizeof(s_avp_base_args));
  if (avp_args == NULL) {
    X__printf("Malloc failed (%d)\n", sizeof(s_avp_base_args));
    return (-1);
  }

  test_mem = (uint8_t *)addr;

  tname_len = strlen(test_name);

  count = 0;
  pass_count = 0;
  fail_count = 0;
  skip_count = 0;
  found_skipped = 0;

  while ((next_test = get_next_file(&test_mem, name)) != NULL) {
    int i, subtest_cnt;
    uint64_t s;
    int good;

    if (strncmp(test_name, name, tname_len) != 0) {
      skip_count++;
      found_skipped = 1;
      if (do_verbose > 3)
        X__printf("Skipping test %d %s\n", count, name);
      continue;
    }
    if (skip_to) {
      if (found_skipped) {
        skip_to = 0;
        test_name[0] = 0;
        tname_len = 0;
      } else {
        continue;
      }
    }

    good = 1;
    for (i = 0; good && (s_avp_exclude_list[i] != NULL); i++) {
      s = strlen(s_avp_exclude_list[i]);
      if (strncmp(s_avp_exclude_list[i], name, s) == 0) {
        skip_count++;
        if (do_verbose > 3)
          X__printf("Exclude test %d %s\n", count, name);
        good = 0;
      }
    }
    if (!good) {
      continue;
    }

    s = strlen(name);
    good = 0;
    if (s > 4) {
      if (strcmp(".avp", name + (s-4)) == 0) {
        good = 1;
      }
    }
    if (!good) {
      X__printf("FAIL: Didn't find .avp file '%s'\n", name);
      return (-1);
    }

    avp_test_count = read_avp_file(next_test, &avp_tests);
    if (do_verbose > 1)
      X__printf("avp_test_count %d\n", avp_test_count);

    if (avp_test_count == 0) {
      X__printf("FAIL: problem with .avp file : %s\n", name);
      return (-1);
    }

    if (do_verbose)
      X__printf("Running: %s\n", name);

    avp_args->mem[0] = NULL;
    avp_args->mem[1] = NULL;
    avp_args->mem[2] = NULL;
    subtest_cnt = 0;

    for (i = 0; i < avp_test_count; i++) {
      char *test_type;
      uint8_t *next_avp_mem = NULL;

      if (avp_tests.type[i] == AVP_TYPE_DUAL) { // .a32 .a64
        test_type = "dual";
        if (!check_next_dual(test_mem, &next_avp_mem, name, "a32")) {
//          X__printf("FAIL: can't find correct ELF type dual %s - %s\n", "a32", name);
          continue; //return (-1);
        }
        avp_args->mem[0] = next_avp_mem;

        if (!check_next_dual(test_mem, &next_avp_mem, name, "a64")) {
//          X__printf("FAIL: can't find correct ELF type dual %s - %s\n", "a64", name);
          continue; //return (-1);
        }
        avp_args->mem[1] = next_avp_mem;

        subtest_cnt += 2;
      } else if (avp_tests.type[i] == AVP_TYPE_DUALA32) { // .a32 .aa64
        test_type = "duala32";
        if (!check_next_dual(test_mem, &next_avp_mem, name, "a32")) {
//          X__printf("FAIL: can't find correct ELF type duala32 %s - %s\n", "a32", name);
          continue; //return (-1);
        }
        avp_args->mem[0] = next_avp_mem;

        if (!check_next_dual(test_mem, &next_avp_mem, name, "aa64")) {
//          X__printf("FAIL: can't find correct ELF type duala32 %s - %s\n", "aa64", name);
          continue; //return (-1);
        }
        avp_args->mem[1] = next_avp_mem;

        subtest_cnt += 2;
      } else if (avp_tests.type[i] == AVP_TYPE_DUALTHUMB) { // .tum .ta64
        test_type = "dualthumb";
        if (!check_next_dual(test_mem, &next_avp_mem, name, "tum")) {
//          X__printf("FAIL: can't find correct ELF type dualthumb %s - %s\n", "tum", name);
          continue; //return (-1);
        }
        avp_args->mem[0] = next_avp_mem;

        if (!check_next_dual(test_mem, &next_avp_mem, name, "ta64")) {
//          X__printf("FAIL: can't find correct ELF type dualthumb %s - %s\n", "ta64", name);
          continue; //return (-1);
        }
        avp_args->mem[1] = next_avp_mem;

        subtest_cnt += 2;
      } else if (avp_tests.type[i] == AVP_TYPE_A32) { // .a32
        test_type = "a32";
        if (!check_next_dual(test_mem, &next_avp_mem, name, "a32")) {
//          X__printf("FAIL: can't find correct ELF type %s - %s\n", "a32", name);
          continue; //return (-1);
        }
        avp_args->mem[0] = next_avp_mem;

        subtest_cnt += 1;
      } else if (avp_tests.type[i] == AVP_TYPE_THUMB) { // .tum
        test_type = "thumb";
        if (!check_next_dual(test_mem, &next_avp_mem, name, "tum")) {
//          X__printf("FAIL: can't find correct ELF type %s - %s\n", "tum", name);
          continue; //return (-1);
        }
        avp_args->mem[0] = next_avp_mem;

        subtest_cnt += 1;
      } else if (avp_tests.type[i] == AVP_TYPE_A64) { // .a64
        test_type = "a64";
        if (!check_next_dual(test_mem, &next_avp_mem, name, "a64")) {
//          X__printf("FAIL: can't find correct ELF type %s - %s\n", "a64", name);
          continue; //return (-1);
        }
        avp_args->mem[0] = next_avp_mem;

        subtest_cnt += 1;
      } else {
        X__printf("FAIL: invalid AVP test type '%s'\n", name);
        return (-1);
      }

      count++;

      avp_args->verbose = (do_verbose > 1);
      avp_args->check_oslock = !no_chk_oslock;

      avp_args->verbose = (do_verbose > 1);
      avp_args->load_proc = core_map[0];

//      avp_tests.max_cores = 2;
      avp_args->cores = avp_tests.max_cores;
      avp_args->counter = 0;

      // num_cores @ 0x00000110 (byte)

      // FIXME : need something else for L2 errors with MP tests
      if (avp_args->verbose)
        X__printf("Clear CPU error regs\n");
      configure_system_errors();

      if (avp_args->verbose)
        X__printf("Starting on %d cores. Load core %d\n", avp_tests.max_cores, avp_args->load_proc);

      // use max_cores
      use_cpu0 = 0;
      for (c = 0; c < avp_tests.max_cores; c++) {
        avp_args->ret[core_map[c]].x0 = 0x1111deadbeef3333ull;
        avp_args->system_status[core_map[c]] = 0;

        if (core_map[c] == 0) {
          use_cpu0 = 1;
        } else {
          if (!start_processor(core_map[c], load_avp_base, avp_args)) {
            X__printf("Error starting thread %d\n", core_map[c]);
            fail_count++;
            continue;
          }
        }
      }
      if (use_cpu0) {
        load_avp_base(0, avp_args);
      }
      for (c = 0; c < avp_tests.max_cores; c++) {
        if (core_map[c] != 0) {
          while (is_processor_running(core_map[c])) {
            asm volatile ("wfe");
          }
        }
      }

      got_fail = 0;

      sys_err = check_system_errors(do_verbose > 1);
      if (sys_err != 0) {
        got_fail = 1;
        if (do_verbose > 0)
          X__printf("%d %s %s FAIL : System Error 0x%x\n", count, name, test_type, sys_err);
      }

      for (c = 0; c < avp_tests.max_cores; c++) {
        if ((avp_args->ret[core_map[c]].x0 == 0) && (avp_args->system_status[core_map[c]] == 0)) {
          // PASS
          if (do_verbose > 0)
            X__printf("%d CPU%d %s %s PASS\n", count, core_map[c], name, test_type);
        } else {
          // FAIL
          X__printf("%d CPU%d %s %s FAIL (sys: %x x0: 0x%x x1: 0x%x x3: 0x%x x11: 0x%x x12: 0x%x)\n",
            count, core_map[c], name, test_type, avp_args->system_status[core_map[c]],
            avp_args->ret[core_map[c]].x0, avp_args->ret[core_map[c]].x1, avp_args->ret[core_map[c]].x3,
            avp_args->ret[core_map[c]].x11, avp_args->ret[core_map[c]].x12);
          got_fail = 1;
        }
      }
      if (got_fail) {
        fail_count++;
      } else {
        pass_count++;
      }
    }

    for (i = 0; i < subtest_cnt; i++) {
      // skip the correct number of tests
      get_next_file(&test_mem, NULL);
    }

  }

  ubsa_free((uint8_t *)avp_args);

  X__printf("Pass %d Fail %d Skip %d\n", pass_count, fail_count, skip_count);

  return (fail_count);
}

void *load_avp_base(uint32_t proc, void *arg)
{
  uint64_t i;
  register uint64_t reg;
  volatile uint64_t *p;
  uint32_t hwproc;
  uint64_t *avp_state;
  uint64_t elf_entry;
  uint64_t loader_ret_ptr;
  int got_loader_ret_ptr;
  s_avp_base_args *avp_args;

  avp_args = (s_avp_base_args *)arg;
  hwproc = get_hwcpuid();

  i = 1;
  while ((avp_args->load_proc == proc) && i) {
    uint8_t *es_num_cores;

    avp_args->load_ok = 0;

    p = (uint64_t *)0;
    for (i = 0; i < 0x300/8; i++) {
      p[i] = 0;
    }

    got_loader_ret_ptr = 0;

    if (!is_elf_hdr_valid(avp_args->mem[0])) {
      if (avp_args->verbose)
        X__printf("ELF Header wrong (mem 0x%x)\n", (uint64_t)(avp_args->mem));
      break;
    }

    // need to check this for dual??
    elf_entry = get_elf_entrty(avp_args->mem[0]);

    for (i = 0; i < 3; i++) {
      if (avp_args->mem[i] != NULL) {
        load_elf_mem(avp_args->mem[i], 0, avp_args->verbose);

        if (find_symbol("fis_loader_return", &loader_ret_ptr, avp_args->mem[i], avp_args->verbose)) {
          got_loader_ret_ptr++;
        }
      }
    }

    if (avp_args->verbose)
      X__printf("Loader ret ptr symbol: 0x%x\n", loader_ret_ptr);

    if (got_loader_ret_ptr != 1) {
      if (avp_args->verbose)
        X__printf("Error: could not find symbol 'fis_loader_return_ptr'\n");
      break;
    }
    *((uint64_t *)loader_ret_ptr) = (uint64_t)&return_avp;

    if (avp_args->verbose)
      X__printf("Entry point 0x%08x\n", elf_entry);
    avp_args->func = (elf_start_func)elf_entry;

    es_num_cores = (uint8_t *)0x0110;
    *es_num_cores = (uint8_t)(avp_args->cores & 0xFF);

    p = (uint64_t *)0x120;
    *p = 0xaaaaaaaaaaaaaaaaULL;

    p = (uint64_t *)0x100;
    *p = 0x204d5041ULL;

//    p = (uint64_t *)0;
//    for (i = 0; i < 0x200/8; i++) {
//      X__printf("[0x%08x] = 0x%08x\n", (uint64_t)&(p[i]), p[i]);
//    }
    avp_args->load_ok = 1;
    asm volatile("dsb sy");
    i = 0;
// arch_timer_udelay(1000000);
  }

  ubsa_sync(avp_args->lock_id, &(avp_args->counter), avp_args->cores);

  if (!avp_args->load_ok) {
    X__printf("Load failed. proc %d\n", proc);
    return (0);
  }

  avp_state = ubsa_malloc(30*sizeof(uint64_t));
  if (avp_state == NULL) {
    X__printf("Malloc failed. proc %d\n", proc);
    return (0);
  }

  if (avp_args->verbose)
    X__printf("Running relocated ELF code (proc %d hw %d) (state [0x%x])\n", proc, hwproc, (uint64_t)avp_state);

  avp_args->ret[proc] = start_avp(avp_args->func, avp_state, hwproc);

  if (avp_args->verbose)
    X__printf("AVP %d returned x0: 0x%x x1: 0x%x x3: 0x%x x11: 0x%x x12: 0x%x\n", proc,
      avp_args->ret[proc].x0, avp_args->ret[proc].x1, avp_args->ret[proc].x3, avp_args->ret[proc].x11, avp_args->ret[proc].x12);

  avp_args->system_status[proc] = check_cpu_errors(hwproc, avp_args->verbose);

  ubsa_free(avp_state);

  // ** AVP cleanup ** //

  reg = (uint64_t)&ubsa_exception_base;
  asm volatile("msr VBAR_EL2, %0"::"r" (reg));

  // make sure caches are off in EL1
  reg = 0x00c50800;
  asm volatile("msr sctlr_el1, %0"::"r" (reg));
  asm volatile("isb");

  asm volatile("msr   VTTBR_EL2, xzr");
  asm volatile("msr   VTCR_EL2, xzr");
  asm volatile("msr   TTBR0_EL2, xzr");
  asm volatile("msr   TTBR0_EL1, xzr");
  asm volatile("msr   TTBR1_EL1, xzr");
  asm volatile("msr   MAIR_EL2, xzr");
  asm volatile("msr   MAIR_EL1, xzr");
  asm volatile("tlbi  ALLE1IS");
  asm volatile("tlbi  ALLE2IS");
  asm volatile("dsb   SY");
  asm volatile("isb");

  if (avp_args->check_oslock)
    check_oslock();

  // caches are off, invalidate just to be sure everything's cleaned up
  invalidate_icache_all();
  invalidate_dcache_all();

  return (0);
}

