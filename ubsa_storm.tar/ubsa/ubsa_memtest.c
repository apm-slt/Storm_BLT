
#include "stdint.h"
#include <stdarg.h>

#include "bbcutils.h"

extern void *memtest_exception_base;

/***************************************************************************
 * Program
 ***************************************************************************/

/*
static uint64_t patterns[] = { // 17
0,
0,
0xffffffffffffffffULL,
0x5555555555555555ULL,
0xaaaaaaaaaaaaaaaaULL,
0x1111111111111111ULL,
0x2222222222222222ULL,
0x4444444444444444ULL,
0x8888888888888888ULL,
0x3333333333333333ULL,
0x6666666666666666ULL,
0x9999999999999999ULL,
0xccccccccccccccccULL,
0x7777777777777777ULL,
0xbbbbbbbbbbbbbbbbULL,
0xddddddddddddddddULL,
0xeeeeeeeeeeeeeeeeULL,
};
*/


struct global_args {
  uint32_t runtime;
  int32_t thread_count;
//  pthread_mutex_t *mut;
//  pthread_cond_t *cond;
  volatile int32_t *count;
  uint32_t max_errors;
  uint32_t quiet;
};

enum testid_e {
  xor_rmw,
  bit_flip,
  bit_flip_rr,
  bit_flip_read,
  bit_flip_bank,
  bit_set_read,
  bit_set_cmpl,
  rand_burst,
  burst_pattern,
  write_value,
  read_write,
  incr_rmw,
  incr_rmw_rank,
  incr_burst,
  incr_burst_rr,
  addr_check,
  test_end
};

struct test_name_s {
  const char *name;
  enum testid_e tid;
  const char *desc;
} test_names[] = {
  { "xor_rmw",        xor_rmw, "      : RMW XOR rand vals" },
  { "bit_flip",       bit_flip, "     : Walking 1/0. Adj transfers are complimented." },
  { "bit_flip_rr",    bit_flip_rr, "  : bit_flip with re-read" },
//  { "bit_flip_read",  bit_flip_read, ": " },
//  { "bit_flip_bank",  bit_flip_bank, ": " },
  { "bit_set_read",   bit_set_read, " : " },
  { "bit_set_cmpl",   bit_set_cmpl, " : " },
  { "rand_burst",     rand_burst, "   : Random values, block r/w." },
  { "burst_pattern",  burst_pattern, ": " },
  { "write_value",    write_value, "  : " },
  { "read_write",     read_write, "   : " },
  { "incr_rmw",       incr_rmw, "     : RMW with bytes that increment in a cache line" },
  { "incr_rmw_rank",  incr_rmw_rank, ": " },
  { "incr_burst",     incr_burst, "   : Byte vals incr in each cache line" },
  { "incr_burst_rr",  incr_burst_rr, ": incr_burst with re-read" },
  { "addr_check",     addr_check, "   : check address decoder" },
  { "", test_end, NULL },
};

struct memtest_args {
  uint64_t *mem_ptr;
  int64_t num_elem;
  uint32_t iterations;
  int32_t thread_num;
  uint32_t mcu_mask;
  uint32_t rank_intlv;
  int32_t rank;
  uint32_t thread_id;
//  pthread_t thread_id;
  struct global_args *ga;
  uint32_t seed;
  uint32_t lfsrd;
  uint64_t set_value;
  uint64_t test_param;
  uint64_t init_val;
  uint32_t burst_mask;
  uint64_t compare_mask;
  int compare_addr_count;
  uint64_t *compare_addr;
  enum testid_e testid;
  int set_vbar;
  uint64_t saved_vbar;
  uint32_t got_except;
  uint32_t sys_err;
  uint32_t got_sys_err;
  uint64_t bit_errors[4][8];
};

int set_bit_errors_from_mcu(struct memtest_args *m);

void memtest_sync(struct global_args *g)
{
/* TODO
  if (g->cond == NULL) return;

  pthread_mutex_lock(g->mut);
  *(g->count) = *(g->count) + 1;
  if (*(g->count) == g->thread_count) {
    *(g->count) = 0;
    pthread_cond_broadcast(g->cond);
  } else {
    pthread_cond_wait(g->cond, g->mut);
  }
  pthread_mutex_unlock(g->mut);
*/
}

typedef int (*cmp_ne_func)(uint64_t *p1, uint64_t *p2, uint64_t q, struct memtest_args *m);

int compare_basic(uint64_t *p1, uint64_t *p2, uint64_t q, struct memtest_args *m)
{
  m = m;
  return ((*p1 != *p2) || (*p1 != q));
}

int compare_data_mask(uint64_t *p1, uint64_t *p2, uint64_t q, struct memtest_args *m)
{
  return (((*p1 & m->compare_mask) != (*p2 & m->compare_mask)) || ((*p1 & m->compare_mask) != (q & m->compare_mask)));
}

int compare_addr_mask(uint64_t *p1, uint64_t *p2, uint64_t q, struct memtest_args *m)
{
  int i;
  if ((*p1 != *p2) || (*p1 != q)) {
    for (i = 0; (i+1) < m->compare_addr_count; i+=2) {
      if (((uint64_t)p1 & m->compare_addr[i+1]) == m->compare_addr[i]) {
//        message(LOG_INFO, "%x & %x == %x", (uint64_t)p1, m->compare_addr[i+1], m->compare_addr[i]);
        return 0;
      }
      if (((uint64_t)p2 & m->compare_addr[i+1]) == m->compare_addr[i]) {
//        message(LOG_INFO, "%x & %x == %x", (uint64_t)p1, m->compare_addr[i+1], m->compare_addr[i]);
        return 0;
      }
    }
    return 1;
  }
  return 0;
}

int compare_data_addr_mask(uint64_t *p1, uint64_t *p2, uint64_t q, struct memtest_args *m)
{
  int i;
  if (((*p1 & m->compare_mask) != (*p2 & m->compare_mask)) || ((*p1 & m->compare_mask) != (q & m->compare_mask))) {
    for (i = 0; (i+1) < m->compare_addr_count; i+=2) {
      if (((uint64_t)p1 & m->compare_addr[i+1]) == m->compare_addr[i])
        return 0;
      if (((uint64_t)p2 & m->compare_addr[i+1]) == m->compare_addr[i])
        return 0;
    }
    return 1;
  }
  return 0;
}

void update_byte_err_count(uint64_t *d1, uint64_t *d2, uint64_t d3, uint32_t mcu, struct memtest_args *m)
{
  int i;
  uint64_t data_xor;
  data_xor = (*d1^d3)|(*d2^d3);

  i = ubsa_get_rank(d1);
  m->bit_errors[mcu_idx_to_mcu(mcu)][((i<0)||(i>7))?0:i] |= data_xor;
}

void *memtest_thread(uint32_t proc, void *arg)
{
  int32_t i;
  int32_t j;
  int32_t w;
  int32_t p;
  int32_t count;
  uint32_t err_count;
  uint64_t *ptr1, *ptr2;
  uint64_t q;
  uint64_t qs;
  uint32_t saved_lfsrd;
  uint32_t shadow_lfsrd;
  uint64_t shadow_xor;
  uint64_t tmr;
  uint64_t tmr_total;
  cmp_ne_func cmp;

  // rank
  uint32_t rank_sz;
  uint32_t rank_lo;
  uint32_t rank_hi;

  // MCU settings
  uint32_t mcu_idx;

  struct memtest_args *m;

  count = 0;
  err_count = 0;
  m = (struct memtest_args*)arg;
  cmp = compare_basic;

  if (!m->ga->quiet)
    X__printf("Thread %d e %d [%x-%x] mcu %x\n", m->thread_num, m->num_elem, (uint64_t)m->mem_ptr,
      (uint64_t)(m->mem_ptr + m->num_elem-1), m->mcu_mask);

  if (m->set_vbar) {
    asm volatile("mrs %0, VBAR_EL2":"=r" (m->saved_vbar));

    q = (uint64_t)&memtest_exception_base;
    asm volatile("msr VBAR_EL2, %0"::"r" (q));
    asm volatile("isb");
  }

  m->lfsrd = m->seed;
  for (i = 0; i < 63; i++) lfsr(&m->lfsrd);

  // figure out how to compare the data...
  if ((m->compare_mask != ~0ull) && (m->compare_addr_count > 1)) {
    cmp = compare_data_addr_mask;
  } else if (m->compare_addr_count > 1) {
    cmp = compare_addr_mask;
  } else if (m->compare_mask != ~0ull) {
    cmp = compare_data_mask;
  }

  // make some assumptions about rank config
  if (m->rank >= 0) {
    rank_sz = 32 * m->rank_intlv;
    rank_lo = (rank_sz/m->rank_intlv) * (m->rank % m->rank_intlv);
    rank_hi = (rank_sz/m->rank_intlv) * ((m->rank % m->rank_intlv) + 1);
  } else {
    rank_sz = 64;
    rank_lo = 0;
    rank_hi = rank_sz;
  }
    rank_lo = rank_lo;
    rank_hi = rank_hi;

  arch_timer_start_reset();
  arch_timer_elapsed(&tmr);
  tmr_total = 0;

  #define LOOP_CHECK \
    ((!m->iterations || (m->iterations > count)) && \
    (!m->ga->runtime || (m->ga->runtime > tmr_total)) && \
    ((m->ga->max_errors == 0) || (m->ga->max_errors > err_count)))

  #define UPDATE_ERROR_COUNT(Q, MCU) \
    update_byte_err_count(ptr1, ptr2, (Q), MCU, m); \
    err_count++; \
    if ((m->ga->max_errors != 0) && (err_count >= m->ga->max_errors)) { \
      goto max_error_count; \
    }

  #define TIMER_UPDATE \
      tmr_total += arch_timer_elapsed(&tmr);

//    for (i = 0; i < ((m->num_elem/2)/4)/rank_sz; i += 4*8*rank_sz) {

  #define LOOP_FRONT \
    ptr1 = m->mem_ptr; \
    ptr2 = m->mem_ptr + (m->num_elem/2); \
    while (ptr1 < (m->mem_ptr + (m->num_elem/2))) { \
      for (p = 0; p < rank_sz; p++ ) { \
        /*if ((p >= rank_lo) && (p < rank_hi))*/ if (1) { \
          for (w = 0; w < 16; w++) { \
            if (mcu_idx & (1 << w)) {

// -> 16 cache lines.

// Potenza -> MCU interleave is only SA[6], MCB interleave is SA[7]
// Strega -> MCU interleave can be any of: SA bit [9, 8, 7, or 6]


// MCB 0 -> MCU 0/1
// MCB 1 -> MCU 2/3




  #define LOOP_BACK \
            } else { \
              ptr1 += 8; \
              ptr2 += 8; \
            } \
          } \
        } else { \
          ptr1 += 8*4; \
          ptr2 += 8*4; \
        } \
      } \
    }

  mcu_idx = mcu_mask_to_idx(m->mcu_mask);

  saved_lfsrd = m->lfsrd;

  // only init memory we are going to use
  LOOP_FRONT
    for (j = 0; j < 8; j++) {
      uint64_t v = rand_val(&m->lfsrd);
      *ptr1++ = *ptr2++ = v;
    }
  LOOP_BACK

  if (m->testid == xor_rmw) {
    q = rand_val(&m->lfsrd);
    shadow_xor = q;

    while (LOOP_CHECK) {

      LOOP_FRONT
            for (j = 0; j < 8; j++) {
              *ptr1++ ^= q;
              *ptr2++ ^= q;
            }
      LOOP_BACK

      shadow_lfsrd = saved_lfsrd;

      LOOP_FRONT
            for (j = 0; j < 8; j++) {
              qs = rand_val(&shadow_lfsrd) ^ shadow_xor;
              if (cmp(ptr1, ptr2, qs, m)) {
                if (!m->ga->quiet)
                  X__printf("Mismatch (c %d t %d) [%013x][%012x] = (%016x,%016x) %016x (%016x)\n",
                    count, m->thread_num, (uint64_t)ptr1, (uint64_t)ptr2, *ptr1, *ptr2, *ptr1 ^ *ptr2, qs);
                UPDATE_ERROR_COUNT(qs, w);
                *ptr1 = *ptr2 = qs;
              }
              ++ptr1;
              ++ptr2;
            }
      LOOP_BACK

      count++;
      TIMER_UPDATE;

      q = rand_val(&m->lfsrd);
      shadow_xor ^= q;
    }
  }

  if ((m->testid == bit_flip) || (m->testid == bit_flip_rr)) {
    int32_t reread = 0;
    int32_t in_reread = 0;
    uint64_t m_and = ~(m->test_param);
    uint64_t m_or = m->set_value;

    q = 1;

    while (LOOP_CHECK) {
      q = ~q;

      LOOP_FRONT
            for (j = 0; j < 8; j++) {
              *ptr1++ = *ptr2++ = ((((j % 2) == 0) ? q : ~q) & m_and) | m_or;
            }
      LOOP_BACK

      reread = 1;
      in_reread = 0;
      while (reread > 0) {

        LOOP_FRONT
              for (j = 0; j < 8; j++) {
                qs = ((((j % 2) == 0) ? q : ~q) & m_and) | m_or;
                if (cmp(ptr1, ptr2, qs, m)) {
                  if (!m->ga->quiet)
                    X__printf("Mismatch (c %d t %d) %s[%013x][%012x] = (%016x,%016x) %016x (%016x)\n",
                      count, m->thread_num, (in_reread ? "reread " : ""), (uint64_t)ptr1, (uint64_t)ptr2, *ptr1, *ptr2, *ptr1 ^ *ptr2, qs);
                  //*ptr1 = *ptr2 = qs;
                  UPDATE_ERROR_COUNT(qs, w);

                  if (!in_reread && (m->testid == bit_flip_rr))
                    reread = 2;
                }
                ++ptr1;
                ++ptr2;
              }
        LOOP_BACK

        in_reread = 1;
        reread--;
      }

      count++;
      TIMER_UPDATE;

      if (count % 8 == 0) {
        q = (q << 1) | ((q >> 63) & 1);
      }
    }
  }

  if ((m->testid == bit_set_read) || (m->testid == bit_set_cmpl)) {
    q = m->set_value;

    if ((m->thread_num & 1) && (m->testid == bit_set_cmpl)) {
      q = ~q;
    }

    LOOP_FRONT
          for (j = 0; j < 8; j++) {
            if (m->testid == bit_set_cmpl) {
              *ptr1++ = *ptr2++ = (((j % 2) == (i % 2)) ? q : ~q);
            } else {
              *ptr1++ = *ptr2++ = q;
            }
          }
    LOOP_BACK

    while (LOOP_CHECK) {

      LOOP_FRONT
            for (j = 0; j < 8; j++) {
              if (m->testid == bit_set_cmpl) {
                qs = (((j % 2) == (i % 2)) ? q : ~q);
              } else {
                qs = q;
              }
              if (cmp(ptr1, ptr2, qs, m)) {
                if (!m->ga->quiet)
                  X__printf("Mismatch (c %d t %d) [%013x][%012x] = (%016x,%016x) %016x (%016x)\n",
                    count, m->thread_num, (uint64_t)ptr1, (uint64_t)ptr2, *ptr1, *ptr2, *ptr1 ^ *ptr2, qs);
                // *ptr1 = *ptr2 = qs;
                UPDATE_ERROR_COUNT(qs, w);
              }
              ++ptr1;
              ++ptr2;
            }
      LOOP_BACK

      count++;
      TIMER_UPDATE;
    }
  }

  if (m->testid == burst_pattern) {
    uint64_t qv = m->test_param;
    q = m->set_value;

    while (LOOP_CHECK) {

      LOOP_FRONT
            for (j = 0; j < 8; j++) {
              *ptr1++ = *ptr2++ = ((m->burst_mask & (1 << j)) ? q : qv);
            }
      LOOP_BACK

      LOOP_FRONT
            for (j = 0; j < 8; j++) {
              qs = ((m->burst_mask & (1 << j)) ? q : qv);
              if (cmp(ptr1, ptr2, qs, m)) {
                if (!m->ga->quiet)
                  X__printf("Mismatch (c %d t %d) [%013x][%012x] = (%016x,%016x) %016x (%016x)\n",
                    count, m->thread_num, (uint64_t)ptr1, (uint64_t)ptr2, *ptr1, *ptr2, *ptr1 ^ *ptr2, qs);
                // *ptr1 = *ptr2 = qs;
                UPDATE_ERROR_COUNT(qs, w);
              }
              ++ptr1;
              ++ptr2;
            }
      LOOP_BACK

      count++;
      TIMER_UPDATE;
    }
  }

  if (m->testid == rand_burst) {
    uint64_t m_and = ~(m->test_param);
    uint64_t m_or = m->set_value;

    while (LOOP_CHECK) {

      saved_lfsrd = m->lfsrd;

      LOOP_FRONT
            for (j = 0; j < 8; j++) {
              q = rand_val(&m->lfsrd);
              *ptr1++ = *ptr2++ = (q & m_and) | m_or;
            }
      LOOP_BACK

      LOOP_FRONT
            for (j = 0; j < 8; j++) {
              q = rand_val(&saved_lfsrd);
              qs = (q & m_and) | m_or;
              if (cmp(ptr1, ptr2, qs, m)) {
                if (!m->ga->quiet)
                  X__printf("Mismatch (c %d t %d) [%013x][%012x] = (%016x,%016x) %016x (%016x)\n",
                    count, m->thread_num, (uint64_t)ptr1, (uint64_t)ptr2, *ptr1, *ptr2, *ptr1 ^ *ptr2, qs);
                // *ptr1 = *ptr2 = qs;
                UPDATE_ERROR_COUNT(qs, w);
              }
              ++ptr1;
              ++ptr2;
            }
      LOOP_BACK

      count++;
      TIMER_UPDATE;
    }
  }

  if (m->testid == write_value) {
    uint64_t write_count = m->test_param;

    if (m->test_param == 0) {
      X__printf("Test Param should not be Zero (t %d)\n", m->thread_num);
      goto max_error_count;
    }

    while (LOOP_CHECK) {
      q = m->set_value;

      if (write_count > 0) {
        write_count--;

        LOOP_FRONT
              for (j = 0; j < 8; j++) {
                *ptr1++ = *ptr2++ = q;
              }
        LOOP_BACK

      } else {
        write_count = m->test_param;

        LOOP_FRONT
              for (j = 0; j < 8; j++) {
                if (cmp(ptr1, ptr2, q, m)) {
                  if (!m->ga->quiet)
                    X__printf("Mismatch (c %d t %d) [%013x][%012x] = (%016x,%016x) %016x (%016x)\n",
                      count, m->thread_num, (uint64_t)ptr1, (uint64_t)ptr2, *ptr1, *ptr2, *ptr1 ^ *ptr2, q);
                  UPDATE_ERROR_COUNT(q, w);
                }
                ++ptr1;
                ++ptr2;
              }
        LOOP_BACK
      }

      count++;
      TIMER_UPDATE;
    }
  }

  if (m->testid == read_write) {
    int read_thread = (m->thread_num & 1);

    if (read_thread) {
      q = m->test_param;

      LOOP_FRONT
            for (j = 0; j < 8; j++) {
              *ptr1++ = *ptr2++ = q;
            }
      LOOP_BACK
    }

    while (LOOP_CHECK) {

      if (!read_thread) {
        q = m->set_value;

        LOOP_FRONT
              for (j = 0; j < 8; j++) {
                *ptr1++ = *ptr2++ = q;
              }
        LOOP_BACK

      } else {
        q = m->test_param;

        LOOP_FRONT
              for (j = 0; j < 8; j++) {
                if (cmp(ptr1, ptr2, q, m)) {
                  if (!m->ga->quiet)
                    X__printf("Mismatch (c %d t %d) [%013x][%012x] = (%016x,%016x) %016x (%016x)\n",
                      count, m->thread_num, (uint64_t)ptr1, (uint64_t)ptr2, *ptr1, *ptr2, *ptr1 ^ *ptr2, q);
                  UPDATE_ERROR_COUNT(q, w);
                }
                ++ptr1;
                ++ptr2;
              }
        LOOP_BACK
      }

      count++;
      TIMER_UPDATE;
    }
  }

  if (m->testid == incr_rmw) {
    int32_t reread = 0;
    int32_t in_reread = 0;
    shadow_xor = 0x0101010101010101ull;

    saved_lfsrd = m->lfsrd;

    LOOP_FRONT
          q = rand_val(&m->lfsrd);
          for (j = 0; j < 8; j++) {
            *ptr1++ = *ptr2++ = q;
            q += 0x0101010101010101ull;
          }
    LOOP_BACK

    while (LOOP_CHECK) {

      LOOP_FRONT
            for (j = 0; j < 8; j++) {
              *ptr1++ += 0x0101010101010101ull;
              *ptr2++ += 0x0101010101010101ull;
            }
      LOOP_BACK

      reread = 1;
      in_reread = 0;
      while (reread > 0) {

        shadow_lfsrd = saved_lfsrd;

        LOOP_FRONT
              qs = rand_val(&shadow_lfsrd);
              qs += shadow_xor;
              for (j = 0; j < 8; j++) {
                if (cmp(ptr1, ptr2, qs, m)) {
                  if (!m->ga->quiet) {
                    X__printf("Mismatch (c %d t %d) [%013x][%012x] = (%016x,%016x) %016x (%016x) %s\n",
                      count, m->thread_num, (uint64_t)ptr1, (uint64_t)ptr2, *ptr1, *ptr2, *ptr1 ^ *ptr2, qs,
                      (in_reread ? "Reread" : ""));

                    if (!in_reread) {
                      reread = 2;
                    } else {
                      *ptr1 = *ptr2 = qs;
                    }
                  }
                  UPDATE_ERROR_COUNT(qs, w);
                }
                ++ptr1;
                ++ptr2;
                qs += 0x0101010101010101ull;
              }
        LOOP_BACK

        in_reread = 1;
        reread--;
      }

      shadow_xor += 0x0101010101010101ull;

      count++;
      TIMER_UPDATE;
    }
  }

  if (m->testid == incr_rmw_rank) {
    int32_t reread = 0;
    int32_t in_reread = 0;
    shadow_xor = 0x0101010101010101ull;

    saved_lfsrd = m->lfsrd;

    LOOP_FRONT
      q = rand_val(&m->lfsrd);
      for (j = 0; j < 8; j++) {
        *ptr1++ = *ptr2++ = q;
        q += 0x0101010101010101ull;
      }
    LOOP_BACK

    while (LOOP_CHECK) {

      LOOP_FRONT
        for (j = 0; j < 8; j++) {
          *ptr1++ += 0x0101010101010101ull;
          *ptr2++ += 0x0101010101010101ull;
        }
      LOOP_BACK

      reread = 1;
      in_reread = 0;
      while (reread > 0) {

        shadow_lfsrd = saved_lfsrd;

        LOOP_FRONT
          qs = rand_val(&shadow_lfsrd);
          qs += shadow_xor;
          for (j = 0; j < 8; j++) {
            if (cmp(ptr1, ptr2, qs, m)) {
              if (!m->ga->quiet) {
                X__printf("Mismatch (c %d t %d) [%013x][%012x] = (%016x,%016x) %016x (%016x) %s\n",
                  count, m->thread_num, (uint64_t)ptr1, (uint64_t)ptr2, *ptr1, *ptr2, *ptr1 ^ *ptr2, qs,
                  (in_reread ? "Reread" : ""));

                if (!in_reread) {
                  reread = 2;
                } else {
                  *ptr1 = *ptr2 = qs;
                }
              }
              UPDATE_ERROR_COUNT(qs, w);
            }
            ++ptr1;
            ++ptr2;
            qs += 0x0101010101010101ull;
          }
        LOOP_BACK

        in_reread = 1;
        reread--;
      }

      shadow_xor += 0x0101010101010101ull;

      count++;
      TIMER_UPDATE;
    }
  }

  if ((m->testid == incr_burst) || (m->testid == incr_burst_rr)) {
    int32_t reread = 0;
    int32_t in_reread = 0;

    while (LOOP_CHECK) {

      saved_lfsrd = m->lfsrd;

      LOOP_FRONT
            q = rand_val(&m->lfsrd);
            for (j = 0; j < 8; j++) {
              *ptr1++ = *ptr2++ = q;
              q += 0x0101010101010101ull;
            }
      LOOP_BACK

      reread = 1;
      in_reread = 0;
      shadow_lfsrd = saved_lfsrd;
      while (reread > 0) {
        saved_lfsrd = shadow_lfsrd;

        LOOP_FRONT
              qs = rand_val(&saved_lfsrd);
              for (j = 0; j < 8; j++) {
                if (cmp(ptr1, ptr2, qs, m)) {
                  if (!m->ga->quiet) {
                    X__printf("Mismatch (c %d t %d) [%013x][%012x] = (%016x,%016x) %016x (%016x) %s\n",
                      count, m->thread_num, (uint64_t)ptr1, (uint64_t)ptr2, *ptr1, *ptr2, *ptr1 ^ *ptr2, qs,
                      (in_reread ? "Reread" : ""));

                    if (!in_reread && (m->testid == incr_burst_rr))
                      reread = 2;
                  }
                  UPDATE_ERROR_COUNT(qs, w);
                  //*ptr1 = *ptr2 = qs;
                }
                ++ptr1;
                ++ptr2;
                qs += 0x0101010101010101ull;
              }
        LOOP_BACK

        in_reread = 1;
        reread--;
      }

      count++;
      TIMER_UPDATE;
    }
  }

  if (m->testid == addr_check) {

    while (LOOP_CHECK) {

      LOOP_FRONT
            for (j = 0; j < 8; j++) {
              q = ((count & 1) ? ((uint64_t)ptr2) : ((uint64_t)ptr1));
              *ptr1++ = *ptr2++ = q;
            }
      LOOP_BACK

      LOOP_FRONT
            for (j = 0; j < 8; j++) {
              qs = ((count & 1) ? ((uint64_t)ptr2) : ((uint64_t)ptr1));
              if (cmp(ptr1, ptr2, qs, m)) {
                if (!m->ga->quiet) {
                  X__printf("Mismatch (c %d t %d) [%013x][%012x] = (%016x,%016x) %016x (%016x)\n",
                    count, m->thread_num, (uint64_t)ptr1, (uint64_t)ptr2, *ptr1, *ptr2, *ptr1 ^ *ptr2, qs);
                }
                UPDATE_ERROR_COUNT(qs, w);
                //*ptr1 = *ptr2 = qs;
              }
              ++ptr1;
              ++ptr2;
            }
      LOOP_BACK

      count++;
      TIMER_UPDATE;
    }
  }

  if (m->sys_err) {
    int32_t hw_proc = cpu_m2hw(proc);
    if (hw_proc < 0) {
      m->got_sys_err = (1<<30);
    } else {
      m->got_sys_err = check_cpu_errors(hw_proc, !m->ga->quiet);
    }
  }

max_error_count: // sorry, there's no other way

  arch_timer_stop();

  // remove any bad stuff that may be left over in the cache
  invalidate_dcache_all();
  invalidate_dcache_all();

  if (!m->ga->quiet)
    X__printf("Thread Finished %d : Elem %d. Ptr 0x%x. Time %dms. Count %d. Errors %d\n",
      m->thread_num, m->num_elem, (uint64_t)(m->mem_ptr), tmr_total, count, err_count);

  if (m->set_vbar) {
    asm volatile("dsb sy");
    asm volatile("isb");

    asm volatile("msr VBAR_EL2, %0"::"r" (m->saved_vbar));
    asm volatile("isb");
  }

  return (0);
}

static void
usage(ubsa_long_options_s *opts)
{
  int i = 0;
  X__printf("Usage:\n");
  ubsa_getopt_usage(opts);

  X__printf("\t Testnames:\n");
  for (i = 0; test_names[i].tid != test_end; i++) {
    X__printf("\t   %s  %s\n", test_names[i].name, test_names[i].desc);
  }
}

static struct memtest_args mt_args[MAX_THREADS];

int ubsa_memtest(char *argv)
{
//  int32_t page_size;
//  int32_t huge_page_size;
//  unsigned long pid;
//  struct timeval tm;

  int o;
  int64_t i;
  uint64_t *inter_mem_ptr = NULL;
  int32_t t_count = 0;
  uint32_t seed;
  int compare_addr_count;
  uint64_t memtest_bit_errors;
  uint64_t memtest_exc_errors;
  uint64_t memtest_sys_errors;
  uint64_t compare_addr[64];
  char test_name[40];
  enum testid_e testid;

  static struct global_args gargs;

  static uint64_t mem_size;
  static int32_t time_sec;
  static int32_t iterations;
  static int32_t num_threads;
  static int32_t all_cores;
  static int32_t rank;
  static int32_t rank_alloc;
  static uint32_t mcu_mask;
  static uint32_t max_errors;
  static uint64_t set_value;
  static uint64_t init_val;
  static uint64_t test_param;
  static uint64_t compare_mask;
  static uint64_t burst_mask;
  static int32_t interleave;
//  static int32_t sync_access;
  static int32_t rand_size;
  static uint32_t init_seed;
  static char *tmp_str;
  static uint32_t do_dealloc;
  static uint32_t ecc_on;
  static uint32_t sys_err;
  static uint32_t quiet;
  static uint32_t print_fail;
  static uint32_t do_help;

  // rank info
  int32_t rank_intlv;

  // option parsing vars
  int c;
  int first;
  int option_idx;
  char *tmp_var;

  static ubsa_long_options_s opts[] = {
    {"memory",      'm', OPT_MEMSIZE, 1, &mem_size,     0, "memory size per thread"},
    {"runtime",     'n', OPT_UINT32,  1, &time_sec,     0, "run time in seconds"},
    {"iterations",  'i', OPT_UINT32,  1, &iterations,   0, "test iterations"},
    {"threads",     't', OPT_UINT32,  1, &num_threads,  0, "number of threads"},
    {"all_cores",   'C', OPT_UINT32,  0, &all_cores,    1, "start the max number of threads"},
    {"mcu",         'M', OPT_UINT32,  1, &mcu_mask,     0, "MCU mask"},
    {"test",        'T', OPT_STRING,  1, &tmp_str,      0, "Test Name"},
    {"max_errors",  'E', OPT_UINT32,  1, &max_errors,   0, "Stop after N errors"},
    {"set",         'F', OPT_UINT64,  1, &set_value,    0, "Fixed Value, Bitflip OR"},
    {"param",       'p', OPT_UINT64,  1, &test_param,   0, "Test Param, Bitflip ~AND"},
    {"seed",        'S', OPT_UINT32,  1, &init_seed,    0, "Seed for random values"},
    {"addr_mask",   'A', OPT_STRING,  1, &tmp_str,      0, "Addr Ignore Mask: <value>:<mask>,<value>:<mask>,..."},
    {"cmp_mask",    'L', OPT_UINT64,  1, &compare_mask, 0, "Ignore Compare Bit Mask"},
    {"init_val",    'Q', OPT_UINT64,  1, &init_val,     0, "Initial Value"},
    {"burst_mask",  'b', OPT_UINT64,  1, &burst_mask,   0, "Burst Mask (8 bits)"},
    {"rank",        'r', OPT_INT32,   1, &rank,         0, "Rank to test"},
    {"rank_alloc",  'R', OPT_INT32,   1, &rank_alloc,   0, "Rank for mem alloc"},
    {"rand_size",   'd', OPT_UINT32,  0, &rand_size,    1, "Random Thread Mem Block Size"},
    {"free",        'D', OPT_UINT32,  0, &do_dealloc,   1, "Deallocate memory on exit"},
    {"ecc_on",      'N', OPT_UINT32,  0, &ecc_on,       1, "Run with ECC enabled"},
    {"sys_err",     's', OPT_UINT32,  0, &sys_err,      1, "Check for system errors"},
    {"quiet",       'q', OPT_UINT32,  0, &quiet,        1, "No output - only for shmoo"},
    {"print_fail",  'f', OPT_UINT32,  0, &print_fail,   1, "Only Print a summary at the end if there were errors"},
    {"help",        'h', OPT_UINT32,  0, &do_help,      1, "Print Help"},
    // TODO: Seed
    { NULL, 0, 0, 0, 0, 0, 0 }
  };
//    {"interleave",  'I', OPT_UINT32,  0, &interleave,   1, "Interleave Cache Lines"},
//    {"sync",        's', OPT_UINT32,  0, &sync_access,  1, "Sync Each Loop"},

  mem_size = 0;
  time_sec = 0;
  iterations = 0;
  num_threads = 1;
  all_cores = 0;
  mcu_mask = 0xF;
  max_errors = 0;
  burst_mask = 0xFF;
  init_val = 1;
  test_name[0] = '\0';
  set_value = 0xdeadbeeff00dcafeull;
  test_param = 0;
  compare_mask = 0;
  init_seed = 10010;
  rank_intlv = 0;
  rank = -1;
  rank_alloc = -1;
  interleave = 0;
//  sync_access = 0;
  rand_size = 0;
  quiet = 0;
  print_fail = 0;
  do_help = 0;
  compare_addr_count = 1;
  do_dealloc = 0;
  ecc_on = 0;
  sys_err = 0;

  first = 1;
  while (1) {
    c = ubsa_getopt_long((first ? argv : NULL), opts, &option_idx, &tmp_var);
    first = 0;
    if (c == -1)
      break;

    switch (c) {
      case 'T':
        strncpy(test_name, tmp_str, 39);
        test_name[39] = 0;
        break;
      case 'A': {
        // value first, then mask
        char *pch, *tmp;
        pch = ubsa_strtok(tmp_str, ",:", &tmp);
        compare_addr_count = 0;
        while ((pch != NULL) && (compare_addr_count < 64)) {
          compare_addr[compare_addr_count] = simple_strtoull(pch, NULL, 0);
          compare_addr_count++;
          pch = ubsa_strtok(NULL, ",:", &tmp);
          if (compare_addr_count % 2 == 0) {
//            X__printf("addr mask %d : %x %x\n", compare_addr_count/2, compare_addr[compare_addr_count-2], compare_addr[compare_addr_count-1]);
          }
        }
      } break;
      case 'M':
        // only make this an error if the user sets the mcu mask
        for (i = 0; i < 4; i++) {
          if (!is_mcu_active(i) && (mcu_mask & (1 << i))) {
            X__printf("MCU %d is not active (mask 0x%x)\n", i, mcu_mask);
            do_help = 1;
          }
        }
        break;
      case '?':
        // already printed error
        usage(opts);
        return(1);
    }
  }

  if ((rank != -1) && (rank_alloc != -1)) {
    do_help = 1;
    X__printf("Only set one of 'rank' and 'rank_alloc'\n\n");
  }

  if (print_fail)
    quiet = 1;

  if (all_cores) {
    num_threads = num_processors();
  }

  if ((num_threads > MAX_THREADS) || (num_threads < 1)
    || (mcu_mask < 1) || (mcu_mask > 15) || (rank > 7) || (rank_alloc > 7)
    || (iterations + time_sec == 0) || (rand_size && (mem_size < 1024*1024))
    || (test_name[0] == '\0') || do_help)
  {
    if (do_dealloc)
      ubsa_dram_alloc_reset();

    usage(opts);
    return(1);
  }

  if ((mem_size % 128*1024) != 0) {
    X__printf("Memsize should be a multiple of 128KB: %d\n", mem_size);
    return(1);
  }

  i = 0;
  seed = init_seed;

  testid = test_end;
  while (test_names[i].tid != test_end) {
    if (strncmp(test_names[i].name, test_name, 40) == 0) {
      testid = test_names[i].tid;
    }
    i++;
  }
  if (testid == test_end) {
    X__printf("Can't find test '%s'\n", test_name);
    if (do_dealloc)
      ubsa_dram_alloc_reset();
    usage(opts);
    return(1);
  }

//  gettimeofday(&tm, NULL);
//  srandom(tm.tv_sec ^ tm.tv_usec ^ pid);

  if (!quiet)
    X__printf("Threads %d. Size %d\n", num_threads, mem_size);

  gargs.runtime = time_sec*1000;
  gargs.thread_count = num_threads;
  gargs.max_errors = max_errors;
  gargs.quiet = quiet;
//  gargs.mut = &mut;
  gargs.count = &t_count;

  if (rank >= 0) {
    // rank_alloc only handles allocation, all the mem in the interleaved ranks will be used.
    // for single ranks, allocate the same way
    rank_alloc = rank;
  }

  if (interleave || rand_size) {
    if (rank_alloc < 0) {
      inter_mem_ptr = (uint64_t *)ubsa_dram_malloc(mem_size*num_threads);
    } else {
      inter_mem_ptr = (uint64_t *)ubsa_dram_malloc_rank(mem_size*num_threads, rank_alloc);
    }
    if (!inter_mem_ptr) {
      X__printf("Mem allocate Error : Size %d. Ptr %x\n",
        mem_size, (uint64_t)(inter_mem_ptr));
      if (do_dealloc)
        ubsa_dram_alloc_reset();
      return (-1);
    }
  }

  if (rand_size) {
    uint64_t *ip = inter_mem_ptr;
    int ll = mem_size*num_threads;
    // use thread_num as temp var to hold mem size
    for (i = 0; i < num_threads; i++) {
      mt_args[i].num_elem = (1024*1024)/8; // give each thread one MB
      ll -= 1024*1024;
    }
    while (ll > 0) {
      int a;
      int mb = 1024*1024;
      if (ll > 32*mb) a = mb*(1+(rand_val(&seed) % 32));
      else if (ll >= 8*mb) a = mb*(1+(rand_val(&seed) % 8));
      else a = ll;
      mt_args[(rand_val(&seed) % num_threads)].num_elem += a/8;
      ll -= a;
    }
    for (i = 0; i < num_threads; i++) {
      mt_args[i].mem_ptr = ip;
      ip += mt_args[i].num_elem;
    }
  } else {
    for (i = 0; i < num_threads; i++) {
      if (interleave) {
        mt_args[i].mem_ptr = inter_mem_ptr;
      } else {
        if (rank_alloc < 0) {
          mt_args[i].mem_ptr = (uint64_t *)ubsa_dram_malloc(mem_size);
        } else {
          mt_args[i].mem_ptr = (uint64_t *)ubsa_dram_malloc_rank(mem_size, rank_alloc);
        }
      }

      if (!mt_args[i].mem_ptr) {
        X__printf("Mem allocate Error %d: Size %d. Ptr %x\n",
          i, mem_size, (uint64_t)(mt_args[i].mem_ptr));
        return (-1);
      }
      mt_args[i].num_elem = mem_size/8;
    }
  }

  rank_intlv = ((rank >= 0) ? ubsa_get_rank_intlv_way() : 0);

  for (i = 0; i < MAX_THREADS; i++) {
    int m,r;
    mt_args[i].got_except = 0;
    mt_args[i].got_sys_err = 0;
    for (m = 0; m < 4; m++) {
      for (r = 0; r < 8; r++) {
        mt_args[i].bit_errors[m][r] = 0;
      }
    }
  }

  for (i = 0; i < num_threads; i++) {
    mt_args[i].iterations = iterations;
    mt_args[i].testid = testid;
    mt_args[i].set_value = set_value;
    mt_args[i].test_param = test_param;
    mt_args[i].init_val = init_val;
    mt_args[i].compare_mask = ~compare_mask;
    mt_args[i].compare_addr_count = compare_addr_count;
    mt_args[i].compare_addr = compare_addr;
    mt_args[i].thread_num = i;
    mt_args[i].mcu_mask = mcu_mask;
    mt_args[i].rank = rank;
    mt_args[i].rank_intlv = rank_intlv;
    mt_args[i].ga = &gargs;
    mt_args[i].seed = init_seed + (0x10000100*i);
    mt_args[i].set_vbar = ecc_on;
    mt_args[i].sys_err = sys_err;

    mt_args[i].burst_mask = burst_mask;
    if (testid == bit_flip_bank) {
      if (burst_mask == 0xFF) {
        mt_args[i].burst_mask = 0x01; // bank 0 only by default
      } else if (burst_mask == 0) {
        mt_args[i].burst_mask = (1 << (i % 8));
      }
    }

  }

  if (!quiet)
    X__printf("memtest info: ptr 0x%x, num elem %d, iter %d, testid %d\n",
      (uint64_t)mt_args[0].mem_ptr, mt_args[0].num_elem, iterations, mt_args[0].testid);

  if ((num_threads == 1) && ecc_on) {
//    if (!quiet)
      X__printf("ERROR: must run with more than one thread in ECC ON mode\n");
    return(1);
  }

//  if (ecc_on)
  {
    int m, r;
    if (!quiet)
      X__printf("Clearing error counts\n");
    for (m = 0; m < 4; m++) {
      if (is_mcu_active(m)) {
        for (r = 0; r < 4; r++) {
          wr_mcu_sbe_count(m, r, 0);
          wr_mcu_err_status(m, r, 0xF);
        }
      }
    }
  }

  if (sys_err) {
    configure_system_errors();
  }

  for (i = 1; i < num_threads; i++) {
    mt_args[i].thread_id = i;
    if (!start_processor(i, memtest_thread, &(mt_args[i]))) {
      X__printf("Error starting thread %d\n", i);
    }
  }

  // start myself
  if (!ecc_on) {
    mt_args[0].thread_id = 0;
    memtest_thread(0, &(mt_args[0]));
  }

  // wait for all others to finish
  for (i = 1; i < num_threads; i++) {
    while (is_processor_running(i)) {
      asm volatile ("wfe");
    }
  }

  /* reset the rdfifo while there is no activity */
  mcu_phy_rdfifo_reset_all();

  if (ecc_on) {
    for (i = 1; i < num_threads; i++) {
      set_bit_errors_from_mcu(&(mt_args[i]));
    }
  }

  if (interleave || rand_size) {
    ubsa_dram_free((void *)inter_mem_ptr);
  } else {
    for (i = 0; i < num_threads; i++) {
      ubsa_dram_free((void *)(mt_args[i].mem_ptr));
    }
  }

  if (do_dealloc)
    ubsa_dram_alloc_reset();

  memtest_bit_errors = get_memtest_bit_errors();

  memtest_exc_errors = 0;
  memtest_sys_errors = 0;
  for (i = 0; i < num_threads; i++) {
    if (mt_args[i].got_except != 0) {
      memtest_exc_errors = 1;
    }
    if (mt_args[i].got_sys_err != 0) {
      memtest_sys_errors |= mt_args[i].got_sys_err;
    }
  }

  if (sys_err) {
    memtest_sys_errors |= check_system_errors(!quiet);
  }

  if (!quiet || print_fail) {
    if (memtest_bit_errors != 0) {
      X__printf("Memtest bit mismatch:\n");
      for (o = 0; o < 4; o++) {
        for (i = 0; i < 4; i++) {
          X__printf("    MCU %d Rank %d : 0x%016x\n", o, i, get_memtest_bit_errors_mcu_rank(o, i));
        }
      }
    }
    if (memtest_exc_errors) {
      X__printf("Memtest took exception\n");
    }
    if (memtest_sys_errors) {
      X__printf("Memtest got system error: 0x%x\n", memtest_sys_errors);
    }
  }

  if ((memtest_bit_errors != 0) || memtest_exc_errors || (memtest_sys_errors != 0)) {
    if (!quiet || print_fail)
      X__printf("Memtest FAILED\n");
    return(1);
  } else {
    if (!quiet || print_fail)
      X__printf("Memtest PASSED\n");
    return(0);
  }

}

// errors found on individual bits
uint64_t get_memtest_bit_errors() {
  return get_memtest_bit_errors_mcu_rank(-1, -1);
}

uint64_t get_memtest_bit_errors_mcu_rank(int64_t mcu, int64_t rank)
{
  int i, m, r;
  uint64_t ret = 0;
  for (i = 0; i < MAX_THREADS; i++) {
    for (m = 0; m < 4; m++) {
      if ((mcu < 0) || (m == mcu)) {
        for (r = 0; r < 8; r++) {
          if ((rank < 0) || (r == rank)) {
            ret |= mt_args[i].bit_errors[m][r];
          }
        }
      }
    }
  }
  return (ret);
}


uint64_t get_memtest_bit_errors_rank(uint64_t rank) {
  return get_memtest_bit_errors_mcu_rank(-1, rank);
}

uint64_t get_memtest_bit_errors_mcu(uint64_t mcu) {
  return get_memtest_bit_errors_mcu_rank(mcu, -1);
}

int set_bit_errors_from_mcu(struct memtest_args *m)
{
  int mcu, r, ret;

  ret = 0;
  for (mcu = 0; mcu < 4; mcu++) {
    if (is_mcu_active(mcu) && (m->mcu_mask & (1 << mcu))) {
      for (r = 0; r < 4; r++) {
        uint32_t cnt, st;
        st = rd_mcu_err_status(mcu, r);
        cnt = rd_mcu_sbe_count(mcu, r);
        if ((st != 0) || (cnt > 0)) {
          // set all bits on error
          m->bit_errors[mcu][r] = 0xFFFFFFFFFFFFFFFFull;
          ret = 1;
        }
      }
    }
  }
  return (ret);
}

void reschedule_cpu();

void memtest_exception(uint64_t exc_num)
{
  int sbe;
  uint64_t proc;

// Need to flush dcache & icache ??

  proc = get_cpuid();

  if (!mt_args[proc].ga->quiet)
    X__printf("Memtest exception %d proc %d\n", exc_num, proc);

  mt_args[proc].got_except = exc_num;

  sbe = set_bit_errors_from_mcu(&(mt_args[proc]));

  if (!sbe) {
    int mcu, r;
    // don't know where the error was, assume it was everywhere
    for (mcu = 0; mcu < 4; mcu++) {
      for (r = 0; r < 4; r++) {
        mt_args[proc].bit_errors[mcu][r] = 0xFFFFFFFFFFFFFFFFull;
      }
    }
  }

  if (mt_args[proc].set_vbar) {
    asm volatile("dsb sy");
    asm volatile("isb");

    asm volatile("msr VBAR_EL2, %0"::"r" (mt_args[proc].saved_vbar));
    asm volatile("isb");
  }

  invalidate_dcache_all();
  invalidate_dcache_all();

  reschedule_cpu();
}

// memtest graveyard
#if 0

  if (m->testid == bit_flip_bank) {
    int32_t reread = 0;
    int32_t in_reread = 0;
    uint64_t m_and = ~(m->test_param);
    uint64_t m_or = m->set_value;
    uint64_t bank_mask = 0x0038000 << m->rank_intlv;

    q = m->init_val;

    while (LOOP_CHECK) {
      q = ~q;

      ptr1 = m->mem_ptr;
      ptr2 = m->mem_ptr + (m->num_elem/2);
      if (((uint64_t)(ptr1) & bank_mask) != ((uint64_t)(ptr2) & bank_mask)) {
        X__printf("Bank Addr mismatch thread %d : mask %x : %016x %016x\n",
          m->thread_num, bank_mask, (uint64_t)(ptr1), (uint64_t)(ptr2));
        return 0;
      }

// 512 cache lines per bank, 8 banks

      for (i = 0; i < m->num_elem/2; i += 512*8*8) {
        int b;
        for (b = 0; b < 8; b++) {
          if (m->burst_mask & (1 << b)) {
            int r;
            for (r = 0; r < 512/4; r++) {
              for (w = 0; w < 4; w++) {
                if (mcu_idx & (1 << w)) {
                  for (j = 0; j < 8; j++) {
                    *ptr1++ = *ptr2++ = ((((j % 2) == 0) ? q : ~q) & m_and) | m_or;
                  }
                } else {
                  ptr1 += 8;
                  ptr2 += 8;
                }
              }
            }
          } else {
            ptr1 += 512*8;
            ptr2 += 512*8;
          }
        }
        // one row only
//        i += (32768-1) * (512*8*8);
//        ptr1 += (32768-1) * (512*8);
//        ptr2 += (32768-1) * (512*8);
      }

      reread = 1;
      in_reread = 0;
      while (reread > 0) {
        ptr1 = m->mem_ptr;
        ptr2 = m->mem_ptr + (m->num_elem/2);

        for (i = 0; i < m->num_elem/2; i += 512*8*8) {
          int b;
          for (b = 0; b < 8; b++) {
            if (m->burst_mask & (1 << b)) {
              int r;
              for (r = 0; r < 512/4; r++) {
                for (w = 0; w < 4; w++) {
                  if (mcu_idx & (1 << w)) {
                    for (j = 0; j < 8; j++) {
                      qs = ((((j % 2) == 0) ? q : ~q) & m_and) | m_or;
                      if (cmp(ptr1, ptr2, qs, m)) {
                        if (!m->ga->quiet)
                          X__printf("Mismatch (c %d t %d) %s[%013x][%012x] = (%016x,%016x) %016x (%016x)\n",
                            count, m->thread_num, (in_reread ? "reread " : ""), (uint64_t)ptr1, (uint64_t)ptr2, *ptr1, *ptr2, *ptr1 ^ *ptr2, qs);
                        //*ptr1 = *ptr2 = qs;
                        UPDATE_ERROR_COUNT(qs, w);

                        if (!in_reread && (m->testid == bit_flip_rr))
                          reread = 2;
                      }
                      ++ptr1;
                      ++ptr2;
                    }
                  } else {
                    ptr1 += 8;
                    ptr2 += 8;
                  }

                }
              }
            } else {
              ptr1 += 512*8;
              ptr2 += 512*8;
            }
          }
          // one row only
//          i += (32768-1) * (512*8*8);
//          ptr1 += (32768-1) * (512*8);
//          ptr2 += (32768-1) * (512*8);
        }
        in_reread = 1;
        reread--;
      }

//      if (count % 1000 == 0)
//        gettimeofday(&tm, NULL);

      count++;
      TIMER_UPDATE;

      if (count % 8 == 0) {
        q = (q << 1) | ((q >> 63) & 1);
      }
    }
  }

#define S 15ull
#define I 128
  if (m->testid == bit_flip_read) {
    q = m->init_val;
    ptr1 = m->mem_ptr;
    ptr2 = m->mem_ptr + (m->num_elem/2);

// 0 -> 32k
// skip 32k -> 256k
// 1/8

    for (i = 0; i < ((m->num_elem/2)/4)/I; i += 4*8*I) {
      if (((uint64_t)(ptr1) & (1 << S)) && m->rank_intlv) {
        ptr1 += I*4*8;
        ptr2 += I*4*8;
      } else {
        int r;
        for (r = 0; r < I; r++) {
          for (w = 0; w < 4; w++) {
            if (mcu_idx & (1 << w)) {
              for (j = 0; j < 8; j++) {
                *ptr1++ = *ptr2++ = (((j % 2) == 0) ? q : ~q);
              }
            } else {
              ptr1 += 8;
              ptr2 += 8;
            }
          }
        }
/*
    for (i = 0; i < (m->num_elem/2)/4; i += 4*8) {
      for (w = 0; w < 4; w++) {
        if (mcu_idx & (1 << w)) {
          for (j = 0; j < 8; j++) {
            *ptr1++ = *ptr2++ = (((j % 2) == 0) ? q : ~q);
          }
        } else {
          ptr1 += 8;
          ptr2 += 8;
        }
*/
      }
      if (i % 8 == 7) {
        q = (q << 1) | ((q >> 63) & 1);
      }
      q = ~q;
    }

    while (LOOP_CHECK) {
      q = m->init_val;
      ptr1 = m->mem_ptr;
      ptr2 = m->mem_ptr + (m->num_elem/2);

      for (i = 0; i < ((m->num_elem/2)/4)/I; i += 4*8*I) {
        if (((uint64_t)(ptr1) & (1 << S)) && m->rank_intlv) {
          ptr1 += I*4*8;
          ptr2 += I*4*8;
        } else {
          int r;
          for (r = 0; r < I; r++) {
            for (w = 0; w < 4; w++) {
              if (mcu_idx & (1 << w)) {
                for (j = 0; j < 8; j++) {
                  qs = (((j % 2) == 0) ? q : ~q);
                  if (cmp(ptr1, ptr2, qs, m)) {
                    if (!m->ga->quiet)
                      X__printf("Mismatch (c %d t %d) [%013x][%012x] = (%016x,%016x) %016x (%016x)\n",
                        count, m->thread_num, (uint64_t)ptr1, (uint64_t)ptr2, *ptr1, *ptr2, *ptr1 ^ *ptr2, qs);
                    // *ptr1 = *ptr2 = qs;
                    UPDATE_ERROR_COUNT(qs, w);
                  }
                  ++ptr1;
                  ++ptr2;
                }
              } else {
                ptr1 += 8;
                ptr2 += 8;
              }
            }
          }
/*
      for (i = 0; i < (m->num_elem/2)/4; i += 4*8) {
        for (w = 0; w < 4; w++) {
          if (mcu_idx & (1 << w)) {
            for (j = 0; j < 8; j++) {
              qs = (((j % 2) == 0) ? q : ~q);
              if (NCMP(*ptr1, *ptr2) || NCMP(*ptr1, qs)) {
                if (!m->ga->quiet)
                X__printf("Mismatch (c %d t %d) [%013x][%012x] = (%016x,%016x) %016x (%016x)\n",
                  count, m->thread_num, (uint64_t)ptr1, (uint64_t)ptr2, *ptr1, *ptr2, *ptr1 ^ *ptr2, qs);
                // *ptr1 = *ptr2 = qs;
                UPDATE_ERROR_COUNT(qs);
              }
              ++ptr1;
              ++ptr2;
            }
          } else {
            ptr1 += 8;
            ptr2 += 8;
          }
*/
        }
        if (i % 8 == 7) {
          q = (q << 1) | ((q >> 63) & 1);
        }
        q = ~q;
      }

//      gettimeofday(&tm, NULL);
      count++;
      TIMER_UPDATE;
    }
  }
#undef I
#undef S


//void (*message)(int, const char *, ...);

/***************************************************************************
 * Error logging
 ***************************************************************************/

#define LOG_INFO 1

static void message(int priority, const char *format_string, ...)
{
/* TODO: print the time
  struct timeval tv;
  struct tm *tm;

  out = priority == LOG_ERR ? stderr : stdout;
  gettimeofday(&tv, NULL);
  tm = gmtime(&tv.tv_sec);
  if(tm == NULL)
    abort();
  fprintf(out, "%4.4d-%2.2d-%2.2d %2.2d:%2.2d:%2.2d.%3.3d %s: ",
    tm->tm_year + 1900, tm->tm_mon + 1, tm->tm_mday,
    tm->tm_hour, tm->tm_min, tm->tm_sec,
    (int)(tv.tv_usec / 1000), PROGRAMNAME);
*/

  va_list argp;
  uint32_t printed;
  char obuf[256];
  uint32_t *__printf_sema;
  uint32_t __printf_sema_locked;

  // acquire semaphore, __sema3 is arbitrary chosen and reserved for __printf contentions
  __printf_sema = get_semaphore_ptr(3);

  do {
    __printf_sema_locked = get_semaphore(__printf_sema, 1000000);
  } while (__printf_sema_locked == 0);

  va_start(argp, format_string);
  printed = __vsnprintf(obuf, sizeof(obuf), format_string, argp);
  va_end(argp);
  obuf[printed-1] = 0; // Null term, this should be unnecessary
  puts(obuf);

  // release semaphore
  put_semaphore(__printf_sema);
}


#endif
