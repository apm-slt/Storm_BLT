
#include <bbcutils.h>

#ifdef SHADOWCAT
void do_phy_init();
#endif

void dump(void);

extern void _processor_start(void);

void start_all_processors(void);

static void ubsa_lib_init();

// global config vars
char *g_startup_command = NULL;
volatile uint32_t g_mmu_enable;

static volatile uint64_t g_ubsa_lock_state_e[MAX_THREADS][NUM_UBSA_LOCKS];
static volatile uint64_t g_ubsa_lock_state_n[MAX_THREADS][NUM_UBSA_LOCKS];

//static void ubsa_init_locks();

int ubsa (int argc, char * const argv[])
{
  int i;

  // shouldn't be necessary, will be loaded as all Zero
//  ubsa_init_locks();

  g_mmu_enable = 1;
  g_startup_command = NULL;
  for (i=0; (i<=argc) && (argv != NULL); ++i) {
    X__printf ("argv[%d] = \"%s\"\n", i, argv[i] ? argv[i] : "<NULL>");
    if (strncmp(argv[i], "cmd=", 4) == 0) {
      g_startup_command = (argv[i] + 4);
    }
    if (strcmp(argv[i], "mmu_off") == 0) {
      X__printf ("** MMU and CACHE OFF **\n");
      g_mmu_enable = 0;
    }
  }

//  g_mmu_enable = 0;

  ubsa_lib_init();

  if (g_mmu_enable) {
    setup_page_tables();
  }

  start_all_processors();

  // start this CPU the same as the others
  _processor_start(); // never returns

  return (0);
}

typedef struct {
  uint32_t start;
  uint32_t valid; // did this thread ever start?
  // ret_val = thread_func(processor_id, param);
  void *(*thread_func)(uint32_t, void *);
  void *param;
  void *ret_val;
} process_data_s;

process_data_s proc_data[NUM_PROCESSORS];

void start_all_processors(void)
{
  int i;
  uint64_t addr;
  unsigned int  *mailbox_addr;
  uint64_t *mailbox_jmp;

  for (i = 0; i < NUM_PROCESSORS; i++) {
    proc_data[i].valid = 0;
    proc_data[i].start = 0;
  }
  asm volatile ("dsb sy");

  mailbox_addr = (unsigned int *)MAILBOX_PTR_ADDR;
  addr = (((uint64_t)*mailbox_addr << 28) | 0xFFF8);

  mailbox_jmp = (uint64_t *)(addr);

  *mailbox_jmp = (uint64_t)&_processor_start;

  flush_cache(addr, 8);

  asm volatile ("dsb sy");
  asm volatile ("isb");

  asm volatile ("sev");
}

// use semaphore 5 when accessing process state
static void wait_schedule(uint32_t proc)
{
  // only need to protect "start" in proc_data
  while (1) {
    ubsa_lock(LK_PROC_STATE);
    if (proc_data[proc].start) {
      ubsa_unlock(LK_PROC_STATE);

      proc_data[proc].ret_val = (*(proc_data[proc].thread_func))(proc, proc_data[proc].param);

      proc_data[proc].start = 0;
      asm volatile ("dsb sy");
      asm volatile ("sev"); // wake others waiting for this thread
    } else {
      ubsa_unlock(LK_PROC_STATE);
      asm volatile ("wfe");
    }
  }
}

void _processor_start_main()
{
  uint32_t proc;

  arch_timer_setup();

  if (g_mmu_enable) {
    enable_caches();
  } else {
    // make sure caches are off
    uint64_t r = 0x30c50830;
    asm volatile("msr sctlr_el2, %0"::"r" (r));
    invalidate_icache_all();
  }

  setup_cpu_map();
  proc = get_cpuid();

  // setup process state after caches are on
  proc_data[proc].valid = 1;

  // always start the command interpreter on thread 0
  if (proc == 0) {
    proc_data[0].start = 1;
    proc_data[0].thread_func = command_interp;
    proc_data[0].param = 0;
  } else {
    proc_data[proc].start = 0;
  }

  wait_schedule(proc);
  // never returns
}

uint32_t start_processor(uint32_t proc, void *(*thread_func)(uint32_t, void *), void *param)
{
  uint32_t ret;
  if (proc >= NUM_PROCESSORS) {
    return (0);
  }

  ubsa_lock(LK_PROC_STATE);
  if (!proc_data[proc].start && proc_data[proc].valid) {
    proc_data[proc].thread_func = thread_func;
    proc_data[proc].param = param;
    proc_data[proc].ret_val = (void*)0xfeed0000deadbeefull;
    asm volatile ("dsb sy");
    proc_data[proc].start = 1;
    ret = 1;
    asm volatile ("dsb sy");
    asm volatile ("sev"); // wake the thread
  } else {
    ret = 0;
  }
  ubsa_unlock(LK_PROC_STATE);

  return (ret);
}

uint32_t is_processor_valid(uint32_t proc)
{
  uint32_t ret;
  if (proc >= NUM_PROCESSORS) {
    return (0);
  }

  ubsa_lock(LK_PROC_STATE);
  ret = proc_data[proc].valid;
  ubsa_unlock(LK_PROC_STATE);
  return (ret);
}


uint32_t is_processor_running(uint32_t proc)
{
  uint32_t ret;
  if (proc >= NUM_PROCESSORS) {
    return (0);
  }

  ubsa_lock(LK_PROC_STATE);
  ret = proc_data[proc].start;
  ubsa_unlock(LK_PROC_STATE);
  return (ret);
}

uint32_t num_processors()
{
  uint32_t i, p;

  p = 0;
  for (i = 0; i < NUM_PROCESSORS; i++) {
    if (is_processor_valid(i))
      p++;
  }
  return p;
}

// return thread result if it is finished
uint32_t get_processor_result(uint32_t proc, void **res)
{
  uint32_t ret;
  if (proc >= NUM_PROCESSORS) {
    return (0);
  }

  ubsa_lock(LK_PROC_STATE);
  if (!proc_data[proc].start) {
    *res = proc_data[proc].ret_val;
    ret = 1;
  } else {
    ret = 0;
  }
  ubsa_unlock(LK_PROC_STATE);
  return (ret);
}

void _reschedule_cpu(uint32_t proc)
{
  proc_data[proc].start = 0;
  asm volatile ("dsb sy");
  asm volatile ("sev");
  wait_schedule(proc);
}

int reset_cpu(char *argv)
{
  uint32_t *rstreq = (uint32_t *)0x17000014;

  X__printf("cold reset ...\n\n");
  asm volatile ("dsb sy");
  asm volatile ("isb");

  arch_timer_udelay(250000);

  *rstreq = 0x1;
  asm volatile ("dsb sy");
  asm volatile ("isb");

  return (1);
}

extern volatile uint64_t avp_saved_state;

// svc args in x0, x1, x2. Return value in x0.
uint64_t ubsa_syscall(uint32_t imm, uint64_t x0, uint64_t x1, uint64_t x2)
{

  X__printf("Syscall(0x%02x) : 0x%x, 0x%x, 0x%x\n", imm, x0, x1, x2);

  if (imm == 0x12) {
    if (avp_saved_state != 0) {
      // context switch back to test loader
      return_avp();
    }
  }

  return (0);
}

void unhandled_exception(uint64_t type)
{

  uint64_t r1, r2, r3;

  asm volatile("mrs %0, far_el1":"=r" (r1));
  asm volatile("mrs %0, esr_el1":"=r" (r2));
  asm volatile("mrs %0, elr_el1":"=r" (r3));

  X__printf("CPU %d Unhandled Exception. %d far_el1 0x%x esr_el1 0x%x elr_el1 0x%x\n", get_hwcpuid(), type, r1, r2, r3);
  X__printf("ESR: EC 0x%x %sISS 0x%x\n", (r2 >> 26) & 0x3F, ((r2 & (1<<25)) ? "IL " : ""), r2 & 0x1FFFFFF);

  asm volatile("mrs %0, far_el2":"=r" (r1));
  asm volatile("mrs %0, esr_el2":"=r" (r2));
  asm volatile("mrs %0, elr_el2":"=r" (r3));

  X__printf("CPU %d Unhandled Exception. %d far_el2 0x%x esr_el2 0x%x elr_el2 0x%x\n", get_hwcpuid(), type, r1, r2, r3);
  X__printf("ESR: EC 0x%x %sISS 0x%x\n", (r2 >> 26) & 0x3F, ((r2 & (1<<25)) ? "IL " : ""), r2 & 0x1FFFFFF);

  asm volatile("mrs %0, sctlr_el2":"=r" (r1));
  X__printf("sctlr_el2 0x%x\n", r1);

  getc();
  reset_cpu(NULL);

  asm volatile ("1: \n wfi \n b 1b \n");

}

/*
static void irq_handler (void *arg);

static void irq_handler (void *arg)
{
  // just for demonstration
  putc('+');
}

install_hdlr (irq, irq_handler, NULL);
free_hdlr (irq);

if (argc > 1)
  irq = simple_strtoul (argv[1], NULL, 0);
if ((irq < 0) || (irq > NR_IRQS))
  irq = DFL_IRQ;
*/


int arch_timer_setup(void);

void arch_timer_udelay(u32 usec);

uint32_t read_rb_w_p(uint64_t base, int page, int word) {
  volatile uint32_t *_tmp_p = (uint32_t *)(base + (word << 2) + (page << 16));
  volatile uint32_t _tmp=0;
  _tmp =  *_tmp_p;
  return _tmp;
}

void write_rb_w_p(uint64_t base, int page, int offset, uint32_t data) {
  volatile uint32_t *_tmp_p1 = (uint32_t *)(base + (offset << 2) + (page << 16));
  *_tmp_p1 = data;
  asm volatile ("dsb sy");
  asm volatile ("isb");
/*
  asm volatile ("dc civac, %0" : : "r" (_tmp_p1));
  asm volatile ("dsb sy");
  asm volatile ("isb");
*/
  return;
}

#define IOB_RB_BASE     0x7e900000ull
#define PCP_RB_BASE     0x7C000000ull

uint32_t read_rb(int page, int offset) {
  return read_rb_w_p((uint64_t)PCP_RB_BASE, page, offset);
}

void write_rb(int page, int offset, uint32_t data) {
  write_rb_w_p((uint64_t)PCP_RB_BASE, page, offset, data);
}

uint32_t  get_csw_config_reg(void) { return read_rb(0x220, 0x00); }
uint32_t  get_mcb_addr_config(uint32_t mcb) { return read_rb(0x270 + mcb*2, 0x00); }
uint32_t  get_mcu_rank_config(uint32_t chan, uint32_t rank) { return read_rb(0x280 + chan*4, ((0x304 + 0x40*rank) >> 2)) & 0x01; }
uint32_t  get_mcu_rank_size(uint32_t chan, uint32_t rank)   { return read_rb(0x280 + chan*4, ((0x300 + 0x40*rank) >> 2)) & 0x07; }
uint32_t  get_mcu_rank_base(uint32_t chan, uint32_t rank)   { return read_rb(0x280 + chan*4, ((0x308 + 0x40*rank) >> 2)); }
uint32_t  get_mcu_rank_mask(uint32_t chan, uint32_t rank)   { return read_rb(0x280 + chan*4, ((0x30c + 0x40*rank) >> 2)); }

void set_csw_config_reg(uint32_t data) { return write_rb(0x220, 0x00, data); }
void set_mcb_addr_config(uint32_t mcb, uint32_t data) { return write_rb(0x270 + mcb*2, 0x00, data); }

void set_mcu_rank_config(uint32_t chan, uint32_t rank, uint32_t data) {
  write_rb(0x280 + chan*4, ((0x304 + 0x40*rank) >> 2), data & 0x01);
}

void set_mcu_rank_size(uint32_t chan, uint32_t rank, uint32_t data) {
  write_rb(0x280 + chan*4, ((0x300 + 0x40*rank) >> 2), data & 0x07);
}

void set_mcu_rank_base_lower(uint32_t chan, uint32_t rank, uint32_t data) {
  uint32_t r = read_rb(0x280 + chan*4, ((0x308 + 0x40*rank) >> 2));
  r = (r & 0x3FFF) | ((data & 7) << 16);
  write_rb(0x280 + chan*4, ((0x308 + 0x40*rank) >> 2), r);
}

void set_mcu_rank_base_upper(uint32_t chan, uint32_t rank, uint32_t data) {
  uint32_t r = read_rb(0x280 + chan*4, ((0x308 + 0x40*rank) >> 2));
  r = (r & (7 << 16)) | (data & 0x3FFF);
  write_rb(0x280 + chan*4, ((0x308 + 0x40*rank) >> 2), r);
}

void set_mcu_rank_mask_lower(uint32_t chan, uint32_t rank, uint32_t data) {
  uint32_t r = read_rb(0x280 + chan*4, ((0x30c + 0x40*rank) >> 2));
  r = (r & 0x3FFF) | ((data & 7) << 16);
  write_rb(0x280 + chan*4, ((0x30c + 0x40*rank) >> 2), r);
}

void set_mcu_rank_mask_upper(uint32_t chan, uint32_t rank, uint32_t data) {
  uint32_t r = read_rb(0x280 + chan*4, ((0x30c + 0x40*rank) >> 2));
  r = (r & (7 << 16)) | (data & 0x3FFF);
  write_rb(0x280 + chan*4, ((0x30c + 0x40*rank) >> 2), r);
}

uint32_t get_iob_remap_rng(int reg) { // 0 - 5
  return read_rb_w_p((uint64_t)IOB_RB_BASE, 0x2, (8+reg));
}

void set_iob_remap_rng(int reg, uint32_t data) { // 0 - 5
  write_rb_w_p((uint64_t)IOB_RB_BASE, 0x2, (8+reg), data);
}

uint32_t get_iob_remap_bar(int reg) { // 0 - 5
  return read_rb_w_p((uint64_t)IOB_RB_BASE, 0x2, (0x10+reg));
}

void set_iob_remap_bar(int reg, uint32_t data) { // 0 - 5
  write_rb_w_p((uint64_t)IOB_RB_BASE, 0x2, (0x10+reg), data);
}

uint32_t get_iob_remap_tar5() { // one reg
  return read_rb_w_p((uint64_t)IOB_RB_BASE, 0x2, 0x1d);
}

void set_iob_remap_tar5(uint32_t data) { // one reg
  write_rb_w_p((uint64_t)IOB_RB_BASE, 0x2, 0x1d, data);
}


void lfsr( uint32_t *_lfsr_p ) {
  /* taps: 32 31 29 1; feedback polynomial: x^32 + x^31 + x^29 + x + 1 */
  *_lfsr_p = (*_lfsr_p >> 1) ^ (-(*_lfsr_p & 1u) & 0xD0000001u);
}

uint64_t rand_val(uint32_t *_lfsr_p) {
  uint64_t ret = 0;
  lfsr(_lfsr_p);
  ret = *_lfsr_p;
  ret <<= 32ull;
  lfsr(_lfsr_p);
  ret |= (uint64_t)*_lfsr_p & 0xFFFFFFFFull;
  return (ret);
}

// this will be initalized to zero
static uint8_t g_cpu_map[MAX_THREADS];
static uint32_t g_next_cpu_map = 1;

void setup_cpu_map()
{
  uint32_t i;
  uint64_t hwid = get_hwcpuid();

  if (hwid >= MAX_THREADS) {
    X__printf("ERROR: cpu hw id %d, max %d\n", hwid, MAX_THREADS);
    return;
  }

  if (!ubsa_lock(LK_CPU_MAP)) {
    X__printf("ERROR: UBSA LOCK FAILED cpu hwid %d\n", hwid);
    return;
  }

  if (g_cpu_map[hwid] != 0) {
    // already added this core to the map
    ubsa_unlock(LK_CPU_MAP);
    return;
  }

  if (g_next_cpu_map <= MAX_THREADS) {
    // assign this CPU the next ID
    g_cpu_map[hwid] = g_next_cpu_map;
    g_next_cpu_map++;
    asm volatile ("dsb sy");
    flush_cache((uint64_t)g_cpu_map, MAX_THREADS);
    flush_cache((uint64_t)&g_next_cpu_map, sizeof(uint32_t));
    ubsa_unlock(LK_CPU_MAP);
    return;
  }

  // not already assigned and map full, error
  X__printf("ERROR: cpu map full:");
  for (i = 0; i < MAX_THREADS; i++) {
    X__printf("%d:%d ", i, g_cpu_map[i]);
  }
  X__printf("\n");

  ubsa_unlock(LK_CPU_MAP);
}

void print_cpu_map()
{
  uint32_t i;
  X__printf("CPU Map (hw:map): ");
  for (i = 0; i < MAX_THREADS; i++) {
    if (g_cpu_map[i] != 0)
      X__printf("%d:%d ", i, (g_cpu_map[i]-1));
  }
  X__printf("\n");
}

uint64_t get_cpuid()
{
  uint64_t hwid = get_hwcpuid();

  if (hwid >= MAX_THREADS) {
    X__printf("ERROR: cpu hw id %d, max %d\n", hwid, MAX_THREADS);
    return 1;
  }

  if (g_cpu_map[hwid] == 0) {
    setup_cpu_map();
  }

  return (g_cpu_map[hwid] - 1);
}

int32_t cpu_hw2m(uint32_t hw_cpu)
{
  int32_t c;

  if (hw_cpu >= MAX_THREADS) {
    return -1;
  }
  c = g_cpu_map[hw_cpu];
  return (c - 1);
}

int32_t cpu_m2hw(int32_t mapped_cpu)
{
  int i;

  for (i = 0; i < MAX_THREADS; i++) {
    if ((g_cpu_map[i] - 1) == mapped_cpu)
      return i;
  }
  return (-1);
}


// heap
uint64_t g_heap_head;

// TODO: add error checking
void *ubsa_malloc(uint64_t size)
{
  // Align 16 bytes (0x10) -- more?
  uint64_t sz_align = (size + 0x000Full) & ~0x000Full;
  uint8_t *ret = (void*)0;
  uint64_t *nxt;

  ubsa_lock(LK_MALLOC);

  // mem header:
  //  [0] status : 0 = unallocated, 1 = allocated but free, 3 = allocated & in use
  //  [1] next   : pointer to start of next mem header. user mem starts after this.
  nxt = ((uint64_t*)g_heap_head);

  // always allocates at the end ... TODO make it allocate in the first-fit place
  while (nxt[0] != 0) {
    nxt = (uint64_t *)nxt[1];
  }
  if (((uint64_t)nxt - (uint64_t)g_heap_head) + sz_align <= UBSA_HEAP_SIZE) {
    // have enough space
    nxt[0] = 3;
    ret = (uint8_t *)&(nxt[2]);
    nxt[1] = (uint64_t)ret + sz_align;

    nxt = (uint64_t *)nxt[1];
    nxt[0] = 0;
    nxt[1] = 0;
  }
  ubsa_unlock(LK_MALLOC);

  return (ret);

}

// TODO: add error checking
void ubsa_free(void *_a)
{
  uint64_t *nxt, *fnxt;
  uint8_t *a = _a;

  ubsa_lock(LK_MALLOC);

  nxt = ((uint64_t*)(a - 16));
  nxt[0] = 1;

  nxt = ((uint64_t*)g_heap_head);

  while (nxt[0] != 0) {
    if (nxt[0] == 1) {
      fnxt = nxt;
      while (fnxt[0] == 1) {
        fnxt = (uint64_t *)fnxt[1];
      }
      if (fnxt[0] == 0) {
        // everything to the end is freed
        nxt[0] = 0;
        nxt[1] = 0;
        ubsa_unlock(LK_MALLOC);
        return;
      }
      if (fnxt[0] == 3) {
        nxt[0] = 1;
        nxt[1] = (uint64_t)fnxt;
      }
    }
    nxt = (uint64_t *)nxt[1];
  }

  ubsa_unlock(LK_MALLOC);
}

void print_heap()
{
  uint64_t *nxt;

  nxt = ((uint64_t*)g_heap_head);

  if (nxt[0] == 0) {
    X__printf("Heap: Empty\n");
    return;
  }

  X__printf("Heap:\n");
  while (nxt[0] != 0) {
    uint64_t p = (uint64_t)&(nxt[2]);
    X__printf("stat %d : size %d : ptr 0x%016x\n", nxt[0], ((uint64_t)nxt[1]) - p, p);
    nxt = (uint64_t *)nxt[1];
  }
}

// simplify allocation of DRAM blocks for memory tests
// this does not check that the DRAM allocated actually exists
// start at DRAM start + 1GB
//#define DRAM_BASE 0x4040000000ull

#define NUM_RANKS 8
#define NUM_MCU   4

uint8_t *g_dram_base = NULL;
uint8_t *g_dram_head = NULL;
uint64_t g_dram_size = 0;

// -1 = rank not active, 0 to 7 = which rank to map alloc to
int32_t g_dram_rank_intlv[NUM_MCU][NUM_RANKS];

uint64_t g_dram_rank_intlv_mask[NUM_MCU][NUM_RANKS];
uint64_t g_dram_rank_intlv_base[NUM_MCU][NUM_RANKS];

uint8_t *g_dram_rank_head[NUM_MCU][NUM_RANKS];
uint64_t g_dram_rank_used[NUM_MCU][NUM_RANKS];
uint64_t g_dram_rank_size[NUM_MCU][NUM_RANKS];
uint32_t g_dram_mcu_intlv;
uint32_t g_dram_mcb_intlv;

static uint32_t g_active_mcu_mask = 0;
static uint32_t g_mcu_x4 = 0;

uint8_t *ubsa_dram_malloc(uint64_t size)
{
  // Align 64KB (0x10000) -- more?
  uint64_t sz_align = (size + 0xFFFFull) & ~0xFFFFull;
  uint8_t *ret;

  ubsa_lock(LK_MALLOC);
  ret = g_dram_head;
  g_dram_head += sz_align;
  ubsa_unlock(LK_MALLOC);

  return (ret);
}

void ubsa_dram_free(uint8_t *mem)
{
  // nothing yet
}

void ubsa_dram_alloc_reset()
{
  int mcu, rank;

  ubsa_lock(LK_MALLOC);
  g_dram_head = g_dram_base;

  for (mcu = 0; mcu < NUM_MCU; mcu++) {
    for (rank = 0; rank < NUM_RANKS; rank++) {
      g_dram_rank_used[mcu][rank] = 0;
    }
  }
  ubsa_unlock(LK_MALLOC);
}

uint8_t *ubsa_dram_malloc_rank(uint64_t size, uint32_t rank)
{
  uint8_t *ret = NULL;
  int mcu = 0;
  int32_t _r;

  if (g_dram_rank_intlv[mcu][rank] >= 0) {
    _r = g_dram_rank_intlv[mcu][rank];
  } else {
    _r = rank;
  }

  ubsa_lock(LK_MALLOC);

  // use MCU 0 to calc rank addrs, is this always ok?
  if (g_dram_rank_used[mcu][_r] + size < g_dram_rank_size[mcu][_r]) {
    ret = g_dram_rank_head[mcu][_r] + g_dram_rank_used[mcu][_r];
    g_dram_rank_used[mcu][_r] += size;
  }

  ubsa_unlock(LK_MALLOC);

  return (ret);
}

int ubsa_is_rank_intlv(uint64_t rank) {
  uint64_t mcu = 0;
  return (g_dram_rank_intlv[mcu][rank] >= 0);
}

int32_t get_rank_intlv(uint64_t mcu, uint64_t rank)
{
  if (ubsa_is_rank_valid(mcu, rank)) {
    return (g_dram_rank_intlv[mcu][rank]);
  }

  return (-1);
}

int ubsa_is_rank_valid(uint64_t mcu, uint64_t rank) {
  return (g_dram_rank_size[mcu][rank] != 0);
}

uint32_t ubsa_num_ranks(uint64_t mcu)
{
  int i;
  uint32_t rank_count = 0;
  for (i = 0; i < NUM_RANKS; i++) {
    if (ubsa_is_rank_valid(mcu, i))
      rank_count++;
  }
  return (rank_count);
}

// call this before malloc.
// only call once.
static void ubsa_lib_init()
{
  int mcb, mcu, rank;
  int num_mcu, num_mcb;
  int mcb_intlv, mcu_intlv;
  uint32_t x4_mcus;
  uint64_t total_mem;
  uint64_t mem_base = (1ull << 63);

  uint32_t cswcr;
  // setup heap allocation state
  // init dram rank info

  cswcr = get_csw_config_reg();
  num_mcb = 1 + (cswcr & 1);

  mcb_intlv = (cswcr >> 1) & 1; // csw['mcb_intrlv']
  total_mem = 0;
  x4_mcus = 0;

#ifdef STORM
  g_dram_mcu_intlv = 1;
  g_dram_mcb_intlv = 0;
#endif

  for (mcb = 0; mcb < num_mcb; mcb++) {
    uint32_t mcb_data = get_mcb_addr_config(mcb);

    num_mcu = 1 + ((mcb_data >> 2) & 1);
    mcu_intlv = (mcb_data >> 3) & 1;

#ifdef SHADOWCAT
    g_dram_mcu_intlv = ((mcb_data >> 6) & 3);
    g_dram_mcb_intlv = ((mcb_data >> 4) & 3);

    X__printf("MCB %d : MCU intlv %d MCB intlv %d\n", mcb, g_dram_mcu_intlv, g_dram_mcb_intlv);
#endif

    for (mcu = 2*mcb; mcu < ((2*mcb)+num_mcu); mcu++) {
      uint32_t size;
      uint64_t mask, rbase;
      x4_mcus |= (is_mcu_x4_en(mcu) << mcu);
      for (rank = 0; rank < NUM_RANKS; rank++) {
//        uint32_t cfg = get_mcu_rank_config(mcu, rank);
        uint64_t base;
        size = get_mcu_rank_size(mcu, rank);
        rbase = get_mcu_rank_base(mcu, rank);
        mask = get_mcu_rank_mask(mcu, rank);

  // NOTE: check this with different interleaves and configs

        base = rbase & 0x3FFFull;
        base &= mask;
        base <<= 28+mcb_intlv+mcu_intlv; // add 1 for each interleave
        if (base == 0)
          base = 0x0080000000ull;
        g_dram_rank_head[mcu][rank] = (uint8_t *)(base);
        g_dram_rank_used[mcu][rank] = 0;
        g_dram_rank_intlv_mask[mcu][rank] = 0;

        switch (size & 7) {
          case 0: g_dram_rank_size[mcu][rank] =        512ull*1024ull*1024ull; break;
          case 1: g_dram_rank_size[mcu][rank] =  1ull*1024ull*1024ull*1024ull; break;
          case 2: g_dram_rank_size[mcu][rank] =  2ull*1024ull*1024ull*1024ull; break;
          case 3: g_dram_rank_size[mcu][rank] =  4ull*1024ull*1024ull*1024ull; break;
          case 4: g_dram_rank_size[mcu][rank] =  8ull*1024ull*1024ull*1024ull; break;
          case 5: g_dram_rank_size[mcu][rank] = 16ull*1024ull*1024ull*1024ull; break;
          default: g_dram_rank_size[mcu][rank] = 0; break;
        }
        total_mem += g_dram_rank_size[mcu][rank];

        if ((base < mem_base) && (g_dram_rank_size[mcu][rank] > 0))
          mem_base = base;

        if (size != 7) {
          g_active_mcu_mask |= (1 << mcu);
        }

        if (size == 7) {
          g_dram_rank_intlv[mcu][rank] = -1;
          g_dram_rank_size[mcu][rank] = 0;
        } else if (((mask >> 16) & 7) == 0) {
          g_dram_rank_intlv[mcu][rank] = -1;
        }
      } // rank

      for (rank = 0; rank < NUM_RANKS; rank++) {
        size = get_mcu_rank_size(mcu, rank);
        if (size == 7)
          continue;

        mask = get_mcu_rank_mask(mcu, rank);
        mask = ((mask >> 16) & 7);
        rbase = get_mcu_rank_base(mcu, rank);

        if ((mask != 0) && ((mask & ((rbase >> 16) & 7)) == 0)) {
          int rr;
          uint64_t raddr;
          // first interleaved rank. find the others and mark them

          // set rank size to sum of all interleaved ranks
          //  mask = 1 : 2-way, mask = 3 : 4-way
          g_dram_rank_size[mcu][rank] *= (mask + 1);

          for (rr = 0; rr < NUM_RANKS; rr++) {
            raddr = get_mcu_rank_base(mcu, rr);
            if ((rbase & 0x3FFF) == (raddr & 0x3FFF)) {
              g_dram_rank_intlv[mcu][rr] = rank;
              g_dram_rank_intlv_mask[mcu][rr] = mask << 15;
              g_dram_rank_intlv_base[mcu][rr] = ((raddr >> 16) & 7) << 15;
//              X__printf("Rank config MCU%d Rank %d : intlv %d, mask 0x%x, ibase 0x%x\n",
//                mcu, rr, g_dram_rank_intlv[mcu][rr], g_dram_rank_intlv_mask[mcu][rr], g_dram_rank_intlv_base[mcu][rr]);
            }
          }
        }
      }

    } // mcu
  }

  if ((x4_mcus != 0) && (x4_mcus != g_active_mcu_mask)) {
    X__printf("Invalid X4 setting : x4 0x%x, mcu 0x%x\n", x4_mcus, g_active_mcu_mask);
  }
  g_mcu_x4 = (x4_mcus != 0);

  if (mem_base == 0) {
    mem_base = 0x0080000000ull;
    if (total_mem > 0x0080000000ull)
      total_mem -= 0x0080000000ull;
  }

  g_dram_base = (uint8_t *)mem_base;
  g_dram_head = g_dram_base;

  g_dram_size = total_mem;

  if (total_mem == 0)
    g_dram_size = 1ull << 32;

  g_heap_head = UBSA_HEAP_BASE;
  ((uint64_t*)g_heap_head)[0] = 0;
  ((uint64_t*)g_heap_head)[1] = 0;

  X__printf("DRAM size 0x%x (%dGB)\n", g_dram_size, g_dram_size/(1024ull*1024ull*1024ull));
  X__printf("DRAM base 0x%x\n", mem_base);
  X__printf("Num ranks %d %d %d %d\n", ubsa_num_ranks(0), ubsa_num_ranks(1),
                                       ubsa_num_ranks(2), ubsa_num_ranks(3));
  X__printf("Active MCU %s%s%s%s\n",
    ((g_active_mcu_mask & 1) ? "0 " : ""), ((g_active_mcu_mask & 2) ? "1 " : ""),
    ((g_active_mcu_mask & 4) ? "2 " : ""), ((g_active_mcu_mask & 8) ? "3 " : ""));

#ifdef SHADOWCAT
  do_phy_init();
#endif
}

int32_t ubsa_get_rank(void *ptr)
{
  uint64_t a = (uint64_t)ptr;
  int mcu = 0;
  int r, _r;
  uint64_t s0, s1;

  for (r = 0; r < NUM_RANKS; r++) {
    if (g_dram_rank_intlv[mcu][r] >= 0) {
      _r = g_dram_rank_intlv[mcu][r];
    } else {
      _r = r;
    }
    s0 = (uint64_t)g_dram_rank_head[mcu][_r];
    s1 = s0 + g_dram_rank_size[mcu][_r];
    if ((a >= s0) && (a < s1)) {
      if ((a & g_dram_rank_intlv_mask[mcu][r]) ==
          (g_dram_rank_intlv_base[mcu][r] & g_dram_rank_intlv_mask[mcu][r]))
      {
        return (r);
      }
    }
  }

  return (-1);
}

uint32_t ubsa_get_rank_intlv_way()
{
  // assumes a valid memory configuration
  return (((g_dram_rank_intlv_mask[0][0] >> 15) & 7) + 1);
}

uint64_t get_phys_dram_base()
{
  return ((uint64_t)g_dram_base);
}

uint64_t get_phys_dram_size()
{
  return (g_dram_size);
}

uint32_t is_mcu_active(uint32_t mcu_num)
{
  if (mcu_num < NUM_MCU) {
    return ((g_active_mcu_mask & (1 << mcu_num)) != 0);
  }
  return (0);
}

uint32_t is_x4_mode()
{
  return g_mcu_x4;
}

// based on active MCUs, create an index map for bits 9:6 of the addr
uint32_t mcu_mask_to_idx(uint32_t mask)
{
  int i;
  uint32_t mcu, mcu_idx, m_mask;
  mcu_idx = 0;

  if (g_active_mcu_mask == 0x1) {
    m_mask = 0xF;
  } else if (g_active_mcu_mask == 0x5) {
    m_mask = ((mask & 0x3) ? 0x3 : 0x0) | ((mask & 0xC) ? 0xC : 0x0);
  } else if (g_active_mcu_mask == 0xF) {
    m_mask = mask;
  } else {
    m_mask = 0xF;
    mcu_idx = 0xFFFF;
    X__printf("ERROR: Unsupported active MCU config: Active MCU %s%s%s%s\n",
      ((g_active_mcu_mask & 1) ? "0 " : ""), ((g_active_mcu_mask & 2) ? "1 " : ""),
      ((g_active_mcu_mask & 4) ? "2 " : ""), ((g_active_mcu_mask & 8) ? "3 " : ""));
  }

  for (i = 0; i < 16; i++) {
    mcu = ((i & (1 << g_dram_mcb_intlv)) ? 2 : 0) | ((i & (1 << g_dram_mcu_intlv)) ? 1 : 0);
    if (((1 << mcu) & m_mask) != 0) {
      mcu_idx |= (1 << i);
    }
  }
  if (mcu_idx == 0) {
    mcu_idx = 0xFFFF;
    X__printf("ERROR: No MCUs enabled : mask 0x%x Active MCU %s%s%s%s\n", mask,
      ((g_active_mcu_mask & 1) ? "0 " : ""), ((g_active_mcu_mask & 2) ? "1 " : ""),
      ((g_active_mcu_mask & 4) ? "2 " : ""), ((g_active_mcu_mask & 8) ? "3 " : ""));
  }

  return (mcu_idx);
}

uint32_t mcu_idx_to_mcu(uint32_t idx)
{
  uint32_t mcu;

  mcu = ((idx & (1 << g_dram_mcb_intlv)) ? 2 : 0) | ((idx & (1 << g_dram_mcu_intlv)) ? 1 : 0);

  if (g_active_mcu_mask == 0xF) {
    return (mcu);
  } else if (g_active_mcu_mask == 0x5) {
    // mcu 0 -> 0
    // mcu 1 -> 0
    // mcu 2 -> 2
    // mcu 3 -> 2
    return (mcu & 2);
  }
  return (0);
}

int can_run_avps(char *dbg_str, uint32_t str_len)
{
  int ret = 1;
  int32_t cmd_offs;
  uint32_t r1;

  cmd_offs = 0;

  if (get_phys_dram_base() != 0x80000000ull) {
    ret = 0;
    if (dbg_str != NULL) {
      cmd_offs += __snprintf((dbg_str + cmd_offs), (str_len-cmd_offs), "DRAM not at 0x80000000 : 0x%x. ", get_phys_dram_base())-1;
    }
  }

  // bit 0,2,12 should all be zero
  asm volatile("mrs %0, sctlr_el2":"=r" (r1));

  if ((r1 & 0x1005) != 0) {
    ret = 0;
    if (dbg_str != NULL) {
      cmd_offs += __snprintf((dbg_str + cmd_offs), (str_len-cmd_offs), "Cache and/or MMU enabled : SCTLR_EL2 0x%08x. ", r1)-1;
    }
  }

  return (ret);
}

int mem_mod(char *argv)
{

  return (0);
}

int mem_display(char *argv)
{

  return (0);
}


int check_mapping(char *argv)
{
  volatile uint64_t *p1, *p2;

  p1 = (uint64_t *)(0x0080010080ull);
  p2 = (uint64_t *)(0x0000010080ull + get_phys_dram_base());

  *p2 = 0x1111222233334444ull;
  X__printf("p1 = 0x%x, p2 = 0x%x\n", *p1, *p2);

  *p1 = 0x1234567890abcdull;
  X__printf("p1 = 0x%x, p2 = 0x%x\n", *p1, *p2);

  *p2 = 0xfeeddeadbeef1234ull;
  X__printf("p1 = 0x%x, p2 = 0x%x\n", *p1, *p2);

  return (0);
}


void ubsa_init_locks()
{
  int i, w;
  for (i = 0; i < NUM_UBSA_LOCKS; i++) {
    for (w = 0; w < MAX_THREADS; w++) {
      g_ubsa_lock_state_e[i][w] = 0;
      g_ubsa_lock_state_n[i][w] = 0;
    }
  }
}


// Lamport's bakery algorithm
int64_t ubsa_lock(e_lock_id lock_id)
{
  int i;
  uint64_t proc;
  uint64_t max;

  proc = get_hwcpuid();

  if (lock_id >= NUM_UBSA_LOCKS)
    return 0;
  if (proc >= MAX_THREADS)
    return 0;

  // store ordering is important
  g_ubsa_lock_state_e[proc][lock_id] = 1; // try to pick a number
  asm volatile ("dsb sy");

  max = 0;
  for (i = 0; i < MAX_THREADS; i++) {
    if (g_ubsa_lock_state_n[i][lock_id] > max) {
      max = g_ubsa_lock_state_n[i][lock_id];
    }
  }
  g_ubsa_lock_state_n[proc][lock_id] = 1 + max; // pick the next number
  asm volatile ("dsb sy");

  g_ubsa_lock_state_e[proc][lock_id] = 0; // done picking a number
  asm volatile ("dsb sy"); // may not need this last DSB

  for (i = 0; i < MAX_THREADS; i++) {
    while (g_ubsa_lock_state_e[i][lock_id]) { } // still picking a number

    // if 'i' has a number, then wait while his number is before mine
    // if we get the same number, the lower cpuid goes first
    while ((g_ubsa_lock_state_n[i][lock_id] != 0) &&
      ((g_ubsa_lock_state_n[i][lock_id] < g_ubsa_lock_state_n[proc][lock_id]) ||
      ((g_ubsa_lock_state_n[i][lock_id] == g_ubsa_lock_state_n[proc][lock_id]) && (i < proc)))) { }
  }

  return 1;
}

void ubsa_unlock(e_lock_id lock_id)
{
  uint64_t proc;

  proc = get_hwcpuid();

  if (lock_id >= NUM_UBSA_LOCKS)
    return;
  if (proc >= MAX_THREADS)
    return;

  g_ubsa_lock_state_n[proc][lock_id] = 0;
}

void ubsa_sync(e_lock_id lock_id, volatile uint32_t *counter, uint32_t cores)
{
  ubsa_lock(lock_id);
  *counter = *counter + 1;
  asm volatile ("dsb sy");
  asm volatile ("sev");
  ubsa_unlock(lock_id);

  while (*counter < cores) {
    asm volatile ("wfe");
  }
}


