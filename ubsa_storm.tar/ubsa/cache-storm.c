/*
 * (C) Copyright 2013 Applied Micro Inc.
 *
 * Vinayak Kale <vkale@apm.com>
 * Feng Kan <fkan@apm.com>
 *
 * See file CREDITS for list of people who contributed to this
 * project.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 * MA 02111-1307 USA
 */

#include <bbcutils.h>

void __v8_flush_dcache_all(void);
void __v8_flush_dcache_area(u64 addr, u64 size);

#define PAGE_SIZE   4096

#define MEM_ATTR_DEVICE_SO  0
#define MEM_ATTR_NORMAL_CACHE 1 //WB
#define MEM_ATTR_NORMAL_UNCACHED 2
//#define MEM_ATTR_NORMAL_CACHE 3 //Write through

enum tbl_type {
  TBL_TYPE_L0 = 0,
  TBL_TYPE_L1_0,
  TBL_TYPE_L1_1,
  TBL_TYPE_L2,
  TBL_TYPE_L3_OCM,
  TBL_TYPE_L3_UART,
  TBL_TYPE_END
};

static inline u64 __get_ttb_addr(enum tbl_type tbl)
{
  if (tbl < TBL_TYPE_L0 || tbl > TBL_TYPE_END)
    return 0;

  return (UBSA_PT_BASE + (PAGE_SIZE * tbl));
}

static inline void __zero_init_page_tbl(u64 ttb)
{
  u64 *pte = (u64 *)ttb;
  int i;

  if (NULL == pte)
    return;

  for (i=0; i<PAGE_SIZE; i+=8) {
    *(pte++) = 0;
  }
}

void add_l1_block_entry(u64 addr, u32 mem_attr)
{
  u64 ttb;
  u64 pte = 0;
  u64 index;

  if ((addr >> 39) > 1)
    return;

  if (addr >> 39)
    ttb = __get_ttb_addr(TBL_TYPE_L1_1);
  else
    ttb = __get_ttb_addr(TBL_TYPE_L1_0);

  pte |= addr & 0xFFFFC0000000ULL;// o/p addr bits[47:30]
  pte |= (0x1 << 10);   // AF bit[10]
  pte |= (0x2 << 8);    // SH bits[9:8]
  pte |= (0x1 << 5);    // NS bit[5]
  pte |= ((mem_attr & 0x7) << 2); // AttrIndx bits[4:2]
  pte |= 0x1;     // block entry bits[1:0]

  index = (addr >> 30) & 0x1FF;

  *((u64 *)(ttb + (index * 8))) = pte;
}

void add_l2_block_entry_ne(u64 va, u64 pa, u32 mem_attr)
{
  u64 ttb;
  u64 pte = 0;
  u64 index;

  if ((va >> 30) == 0)
    ttb = __get_ttb_addr(TBL_TYPE_L2);
  else
    return;

  pte |= pa & 0xFFFFFFE00000ULL;// o/p pa bits[47:21]
  pte |= (0x1 << 10);   // AF bit[10]
  pte |= (0x2 << 8);    // SH bits[9:8]
  pte |= (0x1 << 5);    // NS bit[5]
  pte |= ((mem_attr & 0x7) << 2); // AttrIndx bits[4:2]
  pte |= 0x1;     // block entry bits[1:0]

  index = (va >> 21) & 0x1FF;

  *((u64 *)(ttb + (index * 8))) = pte;
}

void add_l2_block_entry(u64 addr, u32 mem_attr)
{
  add_l2_block_entry_ne(addr, addr, mem_attr);
}

void add_l2_tbl_entry(enum tbl_type tbl, u64 va)
{
  u64 ttb;
  u64 index;
  u64 tbl_ptr = __get_ttb_addr(tbl);

  if ((va >> 30) == 0)
    ttb = __get_ttb_addr(TBL_TYPE_L2);
  else
    return;

  __zero_init_page_tbl(tbl_ptr);

  index = (va >> 21) & 0x1FF;

  *((u64 *)(ttb + (index * 8))) = (tbl_ptr | 0x3);
}

void add_l3_entry_ne(enum tbl_type tbl, u64 va, u64 pa, u32 mem_attr)
{
  u64 pte = 0;
  u64 index;
  u64 ttb = __get_ttb_addr(tbl);

  pte |= pa & 0xFFFFFFFFF000ULL;// o/p pa bits[47:12]
  pte |= (0x1 << 10);   // AF bit[10]
  pte |= (0x2 << 8);    // SH bits[9:8]
  pte |= (0x1 << 5);    // NS bit[5]
  pte |= ((mem_attr & 0x7) << 2); // AttrIndx bits[4:2]
  pte |= 0x3;     // block entry bits[1:0]

  index = (va >> 12) & 0x1FF;

  *((u64 *)(ttb + (index * 8))) = pte;
}

void add_l3_entry(enum tbl_type tbl, u64 addr, u32 mem_attr)
{
  add_l3_entry_ne(tbl, addr, addr, mem_attr);
}

void setup_l0_entries(void)
{
  u64 l0_ttb   = __get_ttb_addr(TBL_TYPE_L0);
  u64 l1_0_ttb = __get_ttb_addr(TBL_TYPE_L1_0);
  u64 l1_1_ttb = __get_ttb_addr(TBL_TYPE_L1_1);

  __zero_init_page_tbl(l0_ttb);

  /* Set L0 'Table' entries
   *  L0[0]   --> L1-0 TTB
   *  L0[1]   --> L1-1 TTB
   */

  *((u64 *)l0_ttb) = (l1_0_ttb | 0x3);
  *((u64 *)(l0_ttb + 8)) = (l1_1_ttb | 0x3);
}

void setup_l1_entries(void)
{
  u64 dram_base;
  u64 dram_size;
  u64 dram_mapped;
  u64 l1_0_ttb    = __get_ttb_addr(TBL_TYPE_L1_0);
  u64 l1_1_ttb    = __get_ttb_addr(TBL_TYPE_L1_1);
  u64 l2_ttb      = __get_ttb_addr(TBL_TYPE_L2);

  __zero_init_page_tbl(l1_0_ttb);
  __zero_init_page_tbl(l1_1_ttb);

  // Level 2 table for 0x00000000 to 0x40000000 (1GB)
  *((u64 *)l1_0_ttb) = (l2_ttb | 0x3);

  /* add 1GB 'Block' entries */

  /* For Address space 0x4000_0000 to 0x7FFF_FFFF
   *  - Device memory
   *  - 1GB block entry
   */
  add_l1_block_entry(0x40000000ULL, MEM_ATTR_DEVICE_SO);

  // Map DRAM in 1GB blocks
  // Dram Base will always be >= 2GB (0x80000000)

  dram_base = get_phys_dram_base();
  dram_size = get_phys_dram_size();
  dram_mapped = 0;

  while ((dram_mapped + 0x40000000ULL) <= dram_size) {

    add_l1_block_entry(dram_base, MEM_ATTR_NORMAL_CACHE);

    dram_base += 0x40000000ULL;
    dram_mapped += 0x40000000ULL;
  }


  // ** map any other pages as needed ...

//  /* For Address space 0x8000_0000 to 0xBFFF_FFFF
//   *  - Normal cacheable memory
//   *  - Map to DDR space for AVP ELF tests
//   */
////  *((u64 *)(l1_0_ttb+16)) = (l2_avp_ttb | 0x3);
//  add_l1_block_entry(0x80000000ULL, MEM_ATTR_NORMAL_CACHE);
//
//  /* For Address space 0xC000_0000 to 0x7F_FFFF_FFFF
//   *  - Normal cacheable memory
//   */
//  for (i=1; i<510; i++) {
//    add_l1_block_entry(0x80000000ULL + (i<<30), MEM_ATTR_NORMAL_CACHE);
//  }
//
//  /* For Address space 0x80_0000_0000 to 0x80_7FFF_FFFF
//   *  - Normal cacheable memory
//   */
//  for (i=0; i<2; i++) {
//    add_l1_block_entry(0x8000000000ULL + (i<<30), MEM_ATTR_NORMAL_CACHE);
//  }
//
//  /* For Address space 0x80_8000_0000 to 0xFF_FFFF_FFFF
//   *  - Device memory
//   */
//  for (i=0; i<510; i++) {
//    add_l1_block_entry(0x8080000000ULL + (i<<30), MEM_ATTR_DEVICE_SO);
//  }
//
}

void setup_l2_entries(void)
{
  u64 l2_ttb      = __get_ttb_addr(TBL_TYPE_L2);
  u64 i;
  u64 ocm_size;

  __zero_init_page_tbl(l2_ttb);

  ocm_size = OCM_SIZE / 4096;

  // setup L3 entries for 4k pages

  add_l2_tbl_entry(TBL_TYPE_L3_OCM, OCM_BASE);

  for (i = 0; i < ocm_size; i++) {
    add_l3_entry(TBL_TYPE_L3_OCM, OCM_BASE + (4096*i), MEM_ATTR_NORMAL_CACHE);
  }

  // map one 4KB page for the UART
  add_l2_tbl_entry(TBL_TYPE_L3_UART, CONFIG_UART_BASE);
  add_l3_entry(TBL_TYPE_L3_UART, CONFIG_UART_BASE, MEM_ATTR_DEVICE_SO);


  /* add 2MB 'Block' entries */

  // add a few device mem blocks to pick up some misc devices
  add_l2_block_entry(0x10400000, MEM_ATTR_DEVICE_SO); // Counter enable (0x10580000)
  add_l2_block_entry(0x17000000, MEM_ATTR_DEVICE_SO); // Reset (0x17000014)

  /* For Address space 0x0000_0000 to 0x3FFF_FFFF
   *  - Boot region: Normal memory cacheable
   *  - OCM region: Normal memory cacheable
   *  - Rest of the region: Device memory
   */
/*
  for (i=0; i<128; i++) {
    add_l2_block_entry(0ULL + (i<<21), MEM_ATTR_NORMAL_CACHE);
  }

  for (i=128; i<512; i++) {
    add_l2_block_entry(0ULL + (i<<21), MEM_ATTR_DEVICE_SO);
  }

  add_l2_block_entry(0x1D000000ULL, MEM_ATTR_NORMAL_CACHE);
*/
}

void arm_init_before_mmu(void)
{
  invalidate_icache_all();
  invalidate_dcache_all();
}

// only call this once.
// data cache shouldn't be on yet
void setup_page_tables(void)
{
  arm_init_before_mmu();

  /* setup pte */
  setup_l0_entries();
  setup_l1_entries();
  setup_l2_entries();

  asm volatile("isb");
  asm volatile("dsb sy");
}

void mmu_setup(void)
{
  u64 reg;

  // make sure MMU is off
  asm volatile("mrs %0, sctlr_el2":"=r" (reg));
  reg &= ~0x1ULL;
  asm volatile("msr sctlr_el2, %0"::"r" (reg));
  asm volatile("dsb sy");
  asm volatile("isb");
#ifdef STORM
// TODO: figure out why this doesn't work on Shadowcat
  asm volatile("tlbi  ALLE1IS");
  asm volatile("tlbi  ALLE2IS");
  asm volatile("dsb sy");
  asm volatile("isb");
#endif

  arm_init_before_mmu();

  /* setup pte */
//  setup_l0_entries();
//  setup_l1_entries();
//  setup_l2_entries();

  /* setup TTBR_EL2 */
  reg = __get_ttb_addr(TBL_TYPE_L0);
  asm volatile ("msr ttbr0_el2, %0" : : "r" (reg));

  /* setup TCR_EL2 */
  reg = 0x3 << 16;  // 42bit PA
  asm volatile ("msr tcr_el2, %0" : : "r" (reg));

  /* setup MAIR_EL2
   *  0 : 0x00 : Device Strongly ordered
   *  1 : 0xFF : Normal,WB-WA
   *  2 : 0x44 : Normal,no-cache
   *  3 : 0xAA : Normal,Write-through
   */
  reg = 0xAA44FF00;
  asm volatile ("msr mair_el2, %0" : : "r" (reg));

  asm volatile("tlbi  ALLE1IS");
  asm volatile("tlbi  ALLE2IS");
  asm volatile("tlbi  ALLE1");
  asm volatile("tlbi  ALLE2");

  asm volatile("isb");
  asm volatile("dsb sy");

  /* Enable MMU */
  asm volatile("mrs %0, sctlr_el2":"=r" (reg));
  reg |= 0x1ULL;
  asm volatile("msr sctlr_el2, %0"::"r" (reg));

  asm volatile("isb");
  asm volatile("dsb sy");
}

static int mmu_enabled(void)
{
  u64 reg;

  asm volatile("mrs %0, sctlr_el2":"=r" (reg));

  return (reg & 0x1ULL);
}

void dcache_enable(void)
{
  u64 reg;

  if (!mmu_enabled())
    mmu_setup();

  asm volatile("mrs %0, sctlr_el2":"=r" (reg));
  reg |= 0x4ULL;
  asm volatile("msr sctlr_el2, %0"::"r" (reg));

  asm volatile("isb");
  asm volatile("dsb sy");
}

void dcache_disable(void)
{
  u64 reg;

  if (!dcache_status())
    return;

  flush_dcache_all();

  asm volatile("mrs %0, sctlr_el2":"=r" (reg));
  reg &= ~(0x4ULL | 0x1ULL);
  asm volatile("msr sctlr_el2, %0"::"r" (reg));

  asm volatile("isb");
  asm volatile("dsb sy");
}

int dcache_status(void)
{
  u64 reg;

  asm volatile("mrs %0, sctlr_el2":"=r" (reg));

  return ((reg & 0x4ULL) ? 1 : 0);
}

void icache_enable(void)
{
  u64 reg;

  asm volatile("mrs %0, sctlr_el2":"=r" (reg));
  reg |= 0x1000ULL;
  asm volatile("msr sctlr_el2, %0"::"r" (reg));

  asm volatile("isb");
  asm volatile("dsb sy");
}

void icache_disable(void)
{
  u64 reg;

  asm volatile("mrs %0, sctlr_el2":"=r" (reg));
  reg &= ~0x1000ULL;
  asm volatile("msr sctlr_el2, %0"::"r" (reg));

  asm volatile("isb");
  asm volatile("dsb sy");
}

int icache_status(void)
{
  u64 reg;

  asm volatile("mrs %0, sctlr_el2":"=r" (reg));

  return ((reg & 0x1000ULL) ? 1 : 0);
}

void invalidate_dcache_all(void)
{
  /* On Potenza, invalidate is same as flush */
  __v8_flush_dcache_all();
}

/*
 * Invalidates range in all levels of D-cache/unified cache used:
 * Affects the range [start, stop - 1]
 */
void invalidate_dcache_range(uint64_t start, uint64_t stop)
{
  /* On Potenza, invalidate is same as flush */
  __v8_flush_dcache_area(start, stop-start);
}

/*
 * Flush range(clean & invalidate) from all levels of D-cache/unified
 * cache used:
 * Affects the range [start, stop - 1]
 */
void flush_dcache_range(uint64_t start, uint64_t stop)
{
  __v8_flush_dcache_area(start, stop-start);
}

/*
 * Performs a clean & invalidation of the entire data cache
 * at all levels
 */
void flush_dcache_all(void)
{
  __v8_flush_dcache_all();
}

/*
 * Flush range from all levels of d-cache/unified-cache used:
 * Affects the range [start, start + size - 1]
 */
void  flush_cache(uint64_t start, uint64_t size)
{
  __v8_flush_dcache_area(start, size);
}

/* Invalidate entire I-cache and branch predictor array */
void invalidate_icache_all(void)
{
  asm volatile("ic  ialluis");
  asm volatile("dsb sy");
  asm volatile("isb");
}

void enable_caches(void)
{
  icache_enable();
  dcache_enable();
}

void disable_caches(void)
{
  /*
   * Turn off I-cache and invalidate it
   */
  icache_disable();
  invalidate_icache_all();

  /*
   * turn off D-cache
   * dcache_disable() in turn flushes the d-cache and disables MMU
   */
  dcache_disable();
  invalidate_dcache_all();
}

/*
void __v8_flush_dcache_all(void)
{
  u64 clidr;
  u64 cache_levels;
  u64 cl, t;

  asm volatile("dsb sy");

  asm volatile("mrs %0, clidr_el1":"=r" (clidr));
  cache_levels = ((clidr >> 24) & 7);
  if (cache_levels == 0)
    return;

  for (cl = 0; cl < cache_levels; cl++) {
    u64 s, a;
    u64 line_sz, num_sets, assoc, assoc_2;

    if (((clidr >> (cl * 3)) & 7) < 2)
      continue; // no data cache here

    t = (cl << 1);
    asm volatile("msr csselr_el1, %0"::"r" (t));
    asm volatile("isb");
    asm volatile("mrs %0, ccsidr_el1":"=r" (t));
    line_sz = (t & 7) + 4; // log2 of line size
    assoc = ((t >> 3) & 0x3FF)+1;

    assoc_2 = 0;
    while ((assoc & (1 << (31-assoc_2))) != 0) { assoc_2++; }

    num_sets = ((t >> 13) & 0x7FFF)+1;

    for (a = 0; a < assoc; a++) {
      for (s = 0; s < num_sets; s++) {
        u64 cisw;
        cisw = a << assoc_2;
        cisw |= (cl << 1);
        cisw |= (s << line_sz);
        asm volatile("dc cisw, %0"::"r" (cisw));
      }
    }
  }

  t = 0;
  asm volatile("msr csselr_el1, %0"::"r" (t));

  asm volatile("dsb sy");
  asm volatile("isb");
}
*/


void __v8_flush_dcache_area(u64 addr, u64 size)
{
  u64 aligned_addr;
  u64 line_sz;

  asm volatile("mrs %0, ctr_el0":"=r" (line_sz));
  line_sz = ((line_sz >> 16) & 0xF) << 4;

  for (aligned_addr = addr & ~(line_sz-1);
       aligned_addr < (addr + size);
       aligned_addr += line_sz)
  {
    asm volatile("dc civac, %0"::"r" (aligned_addr));
  }

  asm volatile("dsb sy");
}

