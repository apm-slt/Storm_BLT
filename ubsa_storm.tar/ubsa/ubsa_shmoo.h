/* Copyright (c) 2014 by Veloce Technologies.  All Rights Reserved. */
/* $Id: //depot/projects/osboot/MAIN/ubsa/ubsa_shmoo.h#1 $ */

#ifndef __UBSA_SHMOO_H__
#define __UBSA_SHMOO_H__

#define SET_BIT(bit) \
  test_pass[(bit)/64] |= (1ull << ((bit) % 64));

#define CLEAR_BIT(bit) \
  test_pass[(bit)/64] &= ~(1ull << ((bit) % 64));

#define GET_BIT(bit) \
  ((test_pass[(bit)/64] & (1ull << ((bit) % 64))) != 0)



int memtest_bit(char *memtest_opts, int64_t mcu, int64_t bit);
int memtest_bit_per_byte(char *memtest_opts, int64_t mcu, int64_t bit);
int memtest_all_bits(char *memtest_opts, int64_t mcu);
int memtest_all_bits_rank(char *memtest_opts, int32_t mcu, int32_t rank, uint32_t ecc_on);




#endif // __UBSA_SHMOO_H__
