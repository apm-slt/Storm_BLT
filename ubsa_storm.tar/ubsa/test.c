/* Copyright (c) 2014 by Veloce Technologies.  All Rights Reserved. */
/* $Id: //depot/projects/osboot/MAIN/ubsa/test.c#5 $ */

#include "bbcutils.h"

#define CONFIG_SYS_CBSIZE 256

typedef struct {
  char *str;
  int (*func)(char *);
} s_commands;

int test_heap(char *argv);
int cmd_forever(char *argv);
int check_mp(char *argv);
int do_print_heap(char *argv);
int do_config_errors(char *argv);
int do_check_errors(char *argv);

static s_commands commands[] = {
  { "memtest", ubsa_memtest },
  { "memreg", memreg },
// depricated  { "shmoo", shmoo_rdlvl },
  { "eye", find_eye },
#ifdef STORM
  { "deskew", sw_deskew },
#endif
  { "mem_screen", mem_screen },
  { "mm", mem_mod },
  { "md", mem_display },
// depricated  { "run_elf", run_elf },
  { "run_avp_base", run_avp_base },
  { "uc", decompress_gzip },
  { "forever", cmd_forever },
  { "check_mp", check_mp },
  { "print_heap", do_print_heap },
  { "config_errors", do_config_errors },
  { "check_errors", do_check_errors },
  { "reset", reset_cpu },
// Test / debug functions
//  { "check_mapping", check_mapping },
//  { "test_heap", test_heap },
//  { "reconfig_mem_test", reconfig_mem_test },
  { NULL, NULL }
};

extern char *g_startup_command;

void *command_interp(uint32_t proc, void *v)
{
  int len, i;
  int found_cmd;

  static char lastcommand[CONFIG_SYS_CBSIZE] = { 0, };

  while (1) {
    if (g_startup_command != NULL) {
      strncpy(lastcommand, g_startup_command, CONFIG_SYS_CBSIZE-1);
      len = 1;
      g_startup_command = NULL;
    } else {
      lastcommand[0] = '\0';
      len = readline_into_buffer("ubsa # ", lastcommand, CONFIG_SYS_CBSIZE-1);
    }
    if (len > 0) {
      char *argv, *cmd;
      found_cmd = 0;
      argv = lastcommand;
      cmd = strsep(&argv, " ");
      if (argv == NULL) argv = "";

      for (i = 0; commands[i].str != NULL; i++) {
        if (strcmp(cmd, commands[i].str) == 0) {
          X__printf("Running: '%s' '%s' '%s'\n", cmd, argv, lastcommand);
          commands[i].func(argv);
          found_cmd = 1;
        }
      }
      if (!found_cmd) {
        X__printf("Command not found: '%s'\nAvailable commands:\n   ", cmd);
        for (i = 0; commands[i].str != NULL; i++) {
          X__printf(" %s", commands[i].str);
        }
        X__printf("\n");
      }
    } else if (len < 0) {
      X__printf("\n");
    }
  }
}


void print_heap();

int test_heap(char *argv)
{
  uint8_t *p1, *p2, *p3, *p4, *p5, *p6;

  print_heap();

  X__printf("p1 malloc 1024\n");
  p1 = ubsa_malloc(1024);
  if (p1 == NULL) {
    X__printf("p1 malloc failed\n");
    return (0);
  }

  print_heap();

  X__printf("free p1\n");
  ubsa_free(p1);
  print_heap();

  X__printf("p2 malloc 2048\n");
  p2 = ubsa_malloc(2048);
  if (p2 == NULL) {
    X__printf("p2 malloc failed\n");
    return (0);
  }

  X__printf("p3 malloc 4000\n");
  p3 = ubsa_malloc(4000);
  if (p3 == NULL) {
    X__printf("p3 malloc failed\n");
    return (0);
  }

  X__printf("free p2\n");
  ubsa_free(p2);
  print_heap();

  X__printf("free p3\n");
  ubsa_free(p3);
  print_heap();

  X__printf("p1 malloc 1024\n");
  p1 = ubsa_malloc(1024);
  if (p1 == NULL) {
    X__printf("p1 malloc failed\n");
    return (0);
  }

  X__printf("p2 malloc 2048\n");
  p2 = ubsa_malloc(2048);
  if (p2 == NULL) {
    X__printf("p2 malloc failed\n");
    return (0);
  }

  print_heap();

  X__printf("free p2\n");
  ubsa_free(p2);
  print_heap();

  X__printf("p3 malloc 4000\n");
  p3 = ubsa_malloc(4000);
  if (p3 == NULL) {
    X__printf("p3 malloc failed\n");
    return (0);
  }

  X__printf("free p1\n");
  ubsa_free(p1);
  print_heap();

  X__printf("free p3\n");
  ubsa_free(p3);
  print_heap();

  X__printf("Should be empty\n\n");

  p1 = ubsa_malloc(1024);
  p2 = ubsa_malloc(1024);
  p3 = ubsa_malloc(1024);
  p4 = ubsa_malloc(1024);
  p5 = ubsa_malloc(1024);
  p6 = ubsa_malloc(1024);
  print_heap();

  ubsa_free(p2);
  ubsa_free(p5);
  ubsa_free(p3);
  print_heap();

  ubsa_free(p4);
  print_heap();

  ubsa_free(p1);
  print_heap();

  ubsa_free(p6);
  print_heap();

  return (1);
}

int do_print_heap(char *argv)
{
  print_heap();
  return (0);
}


void *check_mp_thread(uint32_t proc, void *arg)
{
  uint64_t cpuid;
  cpuid = get_cpuid();

  X__printf("Processor %d running. Cpuid %d HW cpuid %d\n", proc, cpuid, get_hwcpuid());
  return ((void *)(uint64_t)proc);
}

int check_mp(char *argv)
{
  uint32_t proc;
  void *res;

  X__printf("Number of processors: %d\n", num_processors());

  print_cpu_map();

  for (proc = 1; proc < NUM_PROCESSORS; proc++) {

    if (is_processor_valid(proc)) {
      if (!is_processor_running(proc)) {
        X__printf("Starting Processor %d ...\n", proc);

        if (!start_processor(proc, check_mp_thread, NULL)) {
          X__printf("Error starting processor %d\n", proc);
        } else {
          while (is_processor_running(proc)) {
            asm volatile ("wfe");
          }
          if (get_processor_result(proc, &res)) {
            X__printf("Got processor %d result : %d\n", proc, (uint64_t)res);
          } else {
            X__printf("Error getting processor %d result\n", proc);
          }
        }
      } else {
        X__printf("Processor %d is currently running\n", proc);
      }
    } else {
      X__printf("Processor %d is not active\n", proc);
    }
    X__printf("\n");
  }

  return (0);
}


int cmd_forever(char *argv)
{
  char cmd_str[256];
  char *str;
  char *tmp_var, *tmp2;
  uint64_t iters;
  int i;
  s_commands *cmd;

  str = ubsa_strtok(argv, " ", &tmp_var);
//  while (str != NULL) {
//    X__printf("str '%s'\n", str);
//    str = ubsa_strtok(NULL, " ", &tmp_var);
//  }
//  return (0);

  if (str == NULL)
    return (-1);

  iters = simple_strtoull(str, &tmp2, 0);
  X__printf("i %d t %x %d\n", iters, (uint64_t)tmp2, (uint64_t)*tmp2);
  if (tmp2 == NULL) {
    iters = 0;
  } else if (*tmp2 != '\0') {
    iters = 0;
  }

  if (iters != 0) {
    str = ubsa_strtok(NULL, " ", &tmp_var);
  }
  if (str == NULL) {
    X__printf("Usage: forever <iterations> <command>\n");
    return (0);
  }

  cmd = NULL;
  for (i = 0; (cmd == NULL) && (commands[i].str != NULL); i++) {
    if (strcmp(str, commands[i].str) == 0) {
      cmd = &(commands[i]);
    }
  }

  if (cmd != NULL) {
    X__printf("Running: '%s' '%s' times '%d'\n", str, tmp_var, iters);

    for (i = 0; (i < iters) || (iters == 0); i++) {
      int ret;
      X__printf("************* Running %s %d **************\n", str, i);
      strncpy(cmd_str, tmp_var, 256);
      ret = cmd->func(cmd_str);
      if (ret != 0) {
        X__printf("Command returned %d\n", ret);
        return (1);
      }
    }
  } else {
    X__printf("Command not found : %s\n", str);
  }

  return (0);
}


int do_config_errors(char *argv)
{
  configure_system_errors();

  return (0);
}

int do_check_errors(char *argv)
{
  uint32_t res;

  res = check_system_errors(1);

  X__printf("Check system errors returned 0x%08x\n", res);

  return (0);
}


