/* Copyright (c) 2014 by Veloce Technologies.  All Rights Reserved. */
/* $Id: //depot/projects/osboot/MAIN/ubsa/strtol.c#1 $ */

#include "bbcutils.h"

uint32_t simple_strtoul(const char *cp, char **endp,
        unsigned int base)
{
  uint32_t result = 0;
  uint32_t value;

  if (*cp == '0') {
    cp++;
    if ((*cp == 'x') && isxdigit(cp[1])) {
      base = 16;
      cp++;
    }

    if (!base)
      base = 8;
  }

  if (!base)
    base = 10;

  while (isxdigit(*cp) && (value = isdigit(*cp) ? *cp-'0' : (islower(*cp)
      ? toupper(*cp) : *cp)-'A'+10) < base) {
    result = result*base + value;
    cp++;
  }

  if (endp)
    *endp = (char *)cp;

  return result;
}
/*
int strict_strtoul(const char *cp, unsigned int base, uint32_t *res)
{
  char *tail;
  uint32_t val;
  size_t len;

  *res = 0;
  len = strlen(cp);
  if (len == 0)
    return -EINVAL;

  val = simple_strtoul(cp, &tail, base);
  if (tail == cp)
    return -EINVAL;

  if ((*tail == '\0') ||
    ((len == (size_t)(tail - cp) + 1) && (*tail == '\n'))) {
    *res = val;
    return 0;
  }

  return -EINVAL;
}
*/
int32_t simple_strtol(const char *cp, char **endp, unsigned int base)
{
  if (*cp == '-')
    return -simple_strtoul(cp + 1, endp, base);

  return simple_strtoul(cp, endp, base);
}

int64_t simple_strtoll(const char *cp, char **endp, unsigned int base)
{
  if (*cp == '-')
    return -simple_strtoull(cp + 1, endp, base);

  return simple_strtoull(cp, endp, base);
}

uint64_t simple_strtoull(const char *cp, char **endp,
          unsigned int base)
{
  uint64_t result = 0, value;

  if (*cp == '0') {
    cp++;
    if ((*cp == 'x') && isxdigit(cp[1])) {
      base = 16;
      cp++;
    }

    if (!base)
      base = 8;
  }

  if (!base)
    base = 10;

  while (isxdigit(*cp) && (value = isdigit(*cp) ? *cp - '0'
    : (islower(*cp) ? toupper(*cp) : *cp) - 'A' + 10) < base) {
    result = result * base + value;
    cp++;
  }

  if (endp)
    *endp = (char *) cp;

  return result;
}

uint32_t ustrtoul(const char *cp, char **endp_, unsigned int base)
{
  char *__endp;
  char **endp = ((endp_ == NULL) ? &__endp : endp_);

  uint32_t result = simple_strtoul(cp, endp, base);

  switch (**endp) {
    case 'G':
      result *= 1024;
      /* fall through */
    case 'M':
      result *= 1024;
      /* fall through */
    case 'K':
    case 'k':
      result *= 1024;
      if ((*endp)[1] == 'i') {
        if ((*endp)[2] == 'B')
          (*endp) += 3;
        else
          (*endp) += 2;
      }
  }

  return result;
}

uint64_t ustrtoull(const char *cp, char **endp_, unsigned int base)
{
  char *__endp;
  char **endp = ((endp_ == NULL) ? &__endp : endp_);

  uint64_t result = simple_strtoull(cp, endp, base);

  switch (**endp) {
    case 'G':
      result *= 1024;
      /* fall through */
    case 'M':
      result *= 1024;
      /* fall through */
    case 'K':
    case 'k':
      result *= 1024;
      if ((*endp)[1] == 'i') {
        if ((*endp)[2] == 'B')
          (*endp) += 3;
        else
          (*endp) += 2;
      }
  }

  return result;
}


