#include "stdint.h"
#include <stdarg.h>


#include "bbcutils.h"

// these are marked noinline , Len knows why.
uint64_t noinline  get_mpidr() {
  uint32_t register retVal;
  asm(" mrs x0, MPIDR_EL1\n"
      "mov   %[retval], x0" // This is required to get the inlineing of this function to work.  You would hope gcc coould optimize it out
      : [retval] "=r" (retVal) : : "x0");
  return retVal;
}

uint64_t noinline  get_midr() {
  uint32_t register retVal;
  asm(" mrs x0, MIDR_EL1\n"
      "mov   %[retval], x0" // This is required to get the inlineing of this function to work.  You would hope gcc coould optimize it out
      : [retval] "=r" (retVal) : : "x0");
  return retVal;
}

uint64_t noinline  get_dczid() {
  uint32_t register retVal;
  asm(" mrs x0, DCZID_EL0\n"
      "mov   %[retval], x0" // This is required to get the inlineing of this function to work.  You would hope gcc coould optimize it out
      : [retval] "=r" (retVal) : : "x0");
  return retVal;
}

uint64_t noinline  get_id_aa64pfr0() {
  uint32_t register retVal;
  asm(" mrs x0, ID_AA64PFR0_EL1\n"
      "mov   %[retval], x0" // This is required to get the inlineing of this function to work.  You would hope gcc coould optimize it out
      : [retval] "=r" (retVal) : : "x0");
  return retVal;
}

uint64_t noinline  get_id_aa64isar0() {
  uint32_t register retVal;
  asm(" mrs x0, ID_AA64ISAR0_EL1\n"
      "mov   %[retval], x0" // This is required to get the inlineing of this function to work.  You would hope gcc coould optimize it out
      : [retval] "=r" (retVal) : : "x0");
  return retVal;
}

uint64_t noinline  get_revidr() {
  uint32_t register retVal;
  asm(" mrs x0, REVIDR_EL1\n"
      "mov   %[retval], x0" // This is required to get the inlineing of this function to work.  You would hope gcc coould optimize it out
      : [retval] "=r" (retVal) : : "x0");
  return retVal;
}

// returns 'logical' core number
uint32_t cpuid() {
  uint64_t mpidr;
  mpidr = get_mpidr();
  return (((mpidr>>8)&0x0FFU)<<1) + (mpidr&0x0FFU);
}

void init_pmu() {
  asm("mov    x0 , 0xf\n"
      "msr    PMUSERENR_EL0, x0\n"
      "mov    x0 , 0x08000000\n"      // enable cyc counter in hyp mode
      "msr    PMCCFILTR_EL0, x0\n"
      "msr    PMEVTYPER0_EL0, x0\n"
      "msr    PMEVTYPER1_EL0, x0\n"
      "msr    PMEVTYPER2_EL0, x0\n"
      "msr    PMEVTYPER3_EL0, x0\n"
      "movn   x0, #0\n"               // All 1s in x0
      "msr    PMOVSCLR_EL0, x0\n"     // Clear overflow status flags
      "msr    PMINTENCLR_EL1, x0\n"   // Disable interrupts from all four counters + cycle counter
      "msr    PMCNTENSET_EL0, x0\n"   // Enable all event counters
      "mov    x0, 0x46\n"
      "msr    PMCR_EL0, x0\n"         // enable long counter, cyc & event counters reset , keep counting disabled (bit 0)
      "isb\n");
}

void enable_pmu() { 
  //FIXME: Do a RMW of bit0 of PMCR_EL0 instead of writing 0x41
  asm(
      "mov x0 , 0x47\n"
      "msr PMCR_EL0, x0\n"  // enable and clear counters
      "isb\n");
}

void disable_pmu() { 
  //FIXME: Do a RMW of bit0 of PMCR_EL0 instead of writing 0x41
  asm("mov x0 , 0x40\n"
      "msr PMCR_EL0, x0\n"  // disable pmu , but retain cyc + other 4 counter values
      "isb\n");
}


uint64_t noinline  get_pmccntr() {
  uint64_t retVal;
  asm("mrs %[retval] , PMCCNTR_EL0\n"
      : [retval] "=r" (retVal) /* output operands*/
      : /* no input operands*/
      :  /* no clobbers*/  
      );
  return retVal;

}

uint32_t noinline  get_pmu_overflow_status() {
  uint32_t retVal;
  asm("mrs x0 , PMOVSSET_EL0\n"
      "mov %[retval], x0" // This is required to get the inlineing of this function to work.  You would hope gcc coould optimize it out
      : [retval] "=r" (retVal) : : "x0");
  return retVal;

}

void set_pmccntr(uint64_t count) {
  asm volatile ("mov x0 , %[cnt]\n"
      "msr PMCCNTR_EL0 , x0\n"
      "isb\n":
      [cnt] "=r" (count)
      );
}

void set_pmu_event(uint32_t counter_num, uint32_t event_num) {
  event_num += 0x08000000;  // set bit 26 to also enable counting in EL2

  asm volatile (
      "msr PMSELR_EL0 , %[cnt]\n"
      "isb\n"
      "msr PMXEVTYPER_EL0 , %[evt]\n"
      "isb\n"
      : /*no output operands*/
      : [evt] "r" (event_num) , [cnt] "r" (counter_num)   /*input operands*/
      : /* no clobbers*/
      );
}

uint64_t noinline  get_pmu_event_counter(uint32_t counter_num) {
  uint64_t retVal;

  asm volatile (
      "msr PMSELR_EL0 , %[cnt]\n"
      "isb\n"
      "mrs %[retval], PMXEVCNTR_EL0\n"
      : [retval] "=r" (retVal) /* output operands*/
      : [cnt] "r" (counter_num)   /*input operands*/
      : /*"x1"  /* no clobbers*/
      );
  return retVal;

}

#ifdef USE_BB_SEMAPHORES

//extern char core_count_bbmain;

// returns number of cores that got actually started by god (debugger)
// extern is declared global in bbmain.spy
// started cores exclusively increment a 32-bit word at this address (intialized to 0)

//uint32_t noinline  get_cores_started() {
//  uint32_t retVal = *((uint32_t *)&core_count_bbmain);
//  return retVal;
//}

// SEMA_DATA is the bbmain/linker defined section that has dedicated area (8 words, 128 bytes)
// that can be used for for 8 user defined semaphores
// __sema0 is a global that is exported to point to the beginning of SEMA_DATA section
// There's 4 cachelines pre-allocated for semaphores in SEMA_DATA
// although each is a 32-bit word, they are spaced out to be aligned on granule size

extern char *__sema0;

uint32_t * noinline get_semaphore_ptr(uint32_t _sem_id) {
  uint32_t *retVal = &(((uint32_t *)&__sema0)[_sem_id<<4]);
  return retVal;
}

/* gets a semaphore, waits with WFE if can't get it
   will only WFE limit times before returning 0.
   Returns 1 when sema aquired.
   *sema must point to an int that start off as zero */
uint32_t noinline get_semaphore(uint32_t *sema, int limit) {
  uint32_t result = 0;
  while (1) { //while (limit > 0) {
    volatile uint32_t status = 1;  // Compier warns that volatile is not necessary because it is volatile by default -- BUT it generates wrong code (-O3) without it
    // At least I can get rid of the warning by also declaring it volatile in the declaration of exchangeExclusive
    // Note that although the code now looks correct it is not very efficient -- even at -O3
    while(status) {
      // Keep trying the exchange in a one to lock the semaphore until we get good
      // status (i.e. status is zero) indicating the exchange worked.
      result = exchangeExclusive(&status, sema, 1);
    }
    // We did the exchange.
    if (result) {
      // It was already locked so wait for it to be released and try again
      asm volatile ("wfe");
      limit -= 1;
    } else {
      // It was not locked, so we have got it now.
      return 1;
    }
  }
  // Already tried limit times, so give up.
  return 0;
}

void noinline put_semaphore(uint32_t *sema) {
  asm volatile ("dmb sy");  // push out all the prior writes
  *sema = 0;
  asm volatile ("dsb sy"); // push the cleared sema out to all sys wide before waking others
  asm volatile ("sev");
}

// simple lock and unlock
void lock(uint32_t _sem_id) {
  uint32_t got_sema;
  uint32_t *s = get_semaphore_ptr(_sem_id);
  do {
    got_sema = get_semaphore(s, 1000000);
  } while (!got_sema);
}

void unlock(uint32_t _sem_id) {
  uint32_t *s = get_semaphore_ptr(_sem_id);
  put_semaphore(s);
}


// Attempt to exchange atomically the data at address by inserting newValue.
// Returns the old value found in address.
// Status contains the stxr flag indicating whether the exchange actually happened.
// Note == using w3 and w4 explictily because we do not know how to tell gcc that the =r is really a 32 bit register
uint32_t noinline exchangeExclusive(volatile uint32_t *status, volatile uint32_t *address, uint32_t newValue) {
  uint32_t retVal;
  //  uint32_t stxrStatus;
  asm volatile("ldxr  w4, [%[addrP]]\n\t"
               "stxr  w3, %[newval], [%[addrP]]\n\t"
               "str   w3, [%[statusP]]\n\t" 
               "mov   %[oldValue], x4" :
               [statusP] "+r" (status),
               [oldValue] "=r" (retVal)
               :
               [addrP] "r" (address),
               [newval] "r" (newValue)
               :
               "w3", "w4"
               );
  return retVal;
}

// Attempt to incremet atomically the data at address by inserting newValue.
// Returns the incremented value now at address (if the exchange actually happened).
// Status contains the stxr flag indicating whether the exchange actually happened.
// Note == using w3 and w4 explictily because we do not know how to tell gcc that the =r is really a 32 bit register
uint32_t noinline incrementExclusive(volatile uint32_t *status, volatile uint32_t *address, uint32_t incValue) {
  uint32_t retVal;
  //  uint32_t stxrStatus;
  asm volatile("ldxr  w4, [%[addrP]]\n\t"
               "add   x4, x4, %[incval]\n\t"
               "stxr  w3, w4, [%[addrP]]\n\t"
               "str   w3, [%[statusP]]\n\t" 
               "mov   %[oldValue], x4" :
               [statusP] "+r" (status),
               [oldValue] "=r" (retVal)
               :
               [addrP] "r" (address),
               [incval] "r" (incValue)
               :
               "w3", "w4"
               );
  return retVal;
}

int32_t noinline sync(uint32_t volatile *counter, int32_t cores) {
  // sync will use load/store exclusive to count in *counter to cores
  // it will not wait forever, adjustable in the source here with give up count (4k)
  // if the count doesn't get to cores in time -1 is returned as an error.
  // waiting is done with WFE, when a cores counts it SEV's to the others
  // input params -
  // *counter: pointer to a variable that is pre loaded with 0, best if done by linker/loader
  // cores: number of cores running
  // output -
  // returns 0 to cores-1, unique for each caller, so a "thread ID"
  //    but the returned value won't be the same from call to call
  //    all core must use the value from the 'same' call to sync.
  //    Or -1 is returned if waiting too long.

  uint32_t result;
  uint32_t limit = 0x10000; // give up count
  volatile uint32_t status;  // Compiler warns that volatile is not necessary because it is volatile by default -- BUT it generates wrong code (-O3) without it
  // At least I can get rid of the warning by also declaring it volatile in the declaration of exchangeExclusive
  // Note that although the code now looks correct it is not very efficient -- even at -O3
  do {
    // Keep trying the increment the counter by one atomically until we get the right
    // status (i.e. status is zero) indicating the increment worked.
    result = incrementExclusive(&status, counter, 1);
    asm volatile ("sev\n   dsb sy\n");
  } while(status);
  result--;
  // result now contains this core number to be returned.
  // Tell any waiters that the counter has changed
  asm volatile ("sev");

  // But now wait until all callers have reached this sync (i.e. *counter = cores)
  while (limit) {
    if (*counter >= cores) {
      return result;
    }
    // Not there yet, so wait
    asm volatile ("wfe");
    limit--;
  }

  // After many events we still did not find all callers at the sync, so return the error
  return -1;
}

int32_t noinline sync_dont_die(uint32_t volatile *counter, int32_t cores) {
  // sync will use load/store exclusive to count in *counter to cores
  // it will not wait forever, adjustable in the source here with give up count (4k)
  // if the count doesn't get to cores in time -1 is returned as an error.
  // waiting is done with WFE, when a cores counts it SEV's to the others
  // input params -
  // *counter: pointer to a variable that is pre loaded with 0, best if done by linker/loader
  // cores: number of cores running
  // output -
  // returns 0 to cores-1, unique for each caller, so a "thread ID"
  //    but the returned value won't be the same from call to call
  //    all core must use the value from the 'same' call to sync.
  //    Or -1 is returned if waiting too long.

  uint32_t result = 0;
  volatile uint32_t status;  // Compiler warns that volatile is not necessary because it is volatile by default -- BUT it generates wrong code (-O3) without it
  // At least I can get rid of the warning by also declaring it volatile in the declaration of exchangeExclusive
  // Note that although the code now looks correct it is not very efficient -- even at -O3
  do {
    // Keep trying the increment the counter by one atomically until we get the right
    // status (i.e. status is zero) indicating the increment worked.
    result = incrementExclusive(&status, counter, 1);
    asm volatile ("  sev");
  } while(status);
  result--;
  // result now contains this core number to be returned.

  // But now wait until all callers have reached this sync (i.e. *counter == cores)
  while (1) {
    if (*counter >= cores) {
      return result;
    }
    // Not there yet, so wait
    asm volatile ("  wfe");
  }

  // After many events we still did not find all callers at the sync, so return the error
  return -1;
}

uint32_t noinline sync_dont_die_asm( uint32_t *_sema, uint64_t _target_count ) {
  uint32_t retVal;
  asm volatile (
"__sync_attempt_inc:\n\t"
                "ldxr w4, [%[_sema_p]]\n\t"
                "add  x4, x4, 1\n\t"
                "stxr w3, w4, [%[_sema_p]]\n\t"
                "dsb sy\n\t"
                "cbnz w3, __sync_attempt_failed\n"
"__sync_wait_others:\n\t"
                "sev\n\t"
                "dsb sy\n\t"
                "ldr  w3, [%[_sema_p]]\n\t"
                "cmp x3, %[cmpval]\n\t"
                "b.ne __sync_wait_others\n\t"
                "b __sync_done\n"
"__sync_attempt_failed:\n\t"
                "wfe\n\t"
                "b __sync_attempt_inc\n"
"__sync_done:\n\t"
                "sub  %[threadid], x4, 1\n\t" :
                [threadid] "=r" (retVal)
                :
                [_sema_p] "r" (_sema),
                [cmpval] "r" (_target_count)
                :
                "w3", "w4"
                );
  return retVal;
}

uint32_t noinline sync_dont_die_asm_nowfe( uint32_t *_sema, uint64_t _target_count ) {
  uint32_t retVal;
  asm volatile (
"__sync_nowfe_attempt_inc:\n\t"
                "ldxr w4, [%[_sema_p]]\n\t"
                "add  x4, x4, 1\n\t"
                "stxr w3, w4, [%[_sema_p]]\n\t"
                "dsb sy\n\t"
                "cbnz w3, __sync_nowfe_attempt_inc\n"
"__sync_nowfe_wait_others:\n\t"
                "ldr  w3, [%[_sema_p]]\n\t"
                "cmp x3, %[cmpval]\n\t"
                "b.ne __sync_nowfe_wait_others\n\t"
                "sub  %[threadid], x4, 1\n\t" :
                [threadid] "=r" (retVal)
                :
                [_sema_p] "r" (_sema),
                [cmpval] "r" (_target_count)
                :
                "w3", "w4"
                );
  return retVal;
}

#endif // USE_BB_SEMAPHORES

// get pointer to the beginning of the snprintf buffer
// extern char CONSOLE_BUF;
// char * noinline get_console_buffer_ptr() {
//   return &CONSOLE_BUF;
// }

uint32_t __vsnprintf(char *dest, const uint32_t sz, const char *format_string, va_list argp) {
  /* 
     see description to original __printf in the comment below
     This is ripped and somewhat modified copy. Will write *directly* to the output buffer pointed by dest,
     upto sz-1 characters long. dest[sz-1] is always reserved for '\0' termination.
     User is reponsible for memory allocation.
  */

  /* 
     partial printf, supports %c,%s,%u,%d,%x.  For %u,%d and %x supports width and leading zeros
     so %08x works.  %u,%d,%x are treated as int64
     improvement would be to support %lu %ld %lx then treat the non l's as int
     the vararg stuff supports float so that should be added.
     supports %xxx.yyys for string limits
     Output is limited to 1k total, and 256 per field, one svc is made to print the
     string.  This routine could be made into sprintf with ease.
  */

  const char *p;
  int i, oi, hash, leading_zero, width, precision,neg;
  uint64_t val;
  char *s;
  char buf[256];

  oi = 0; // output buffer index and length

  for (p = format_string; *p != '\0'; p++)	{
    if (oi >= sz-2) break; // this is bad we exceeded the output size a while ago, need sz-2 for null character
    if (*p != '%') {
      dest[oi++] = *p;
      continue;
    }
    // Found a % look for specifier
    leading_zero=0;
    hash = 0;
    width = 0;
    precision = 0;
    p += 1;
    if (*p == '#') {
      hash = 1;
      p += 1;
    }
    if (*p == '0') {
      leading_zero = 1;
      p += 1;
    }
    while (*p >= '0' && *p <= '9') {
      // strip off the numbers - the width
      width = width*10 + *p++ -'0';
    }
    if (width >= sizeof(buf)) {
      // too big
      goto __null_term_and_return;
    }
    if (*p == '.') {
      // pull off precision
      p += 1;
      while (*p >= '0' && *p <= '9') {
        // strip off the numbers - the precision
        precision = precision*10 + *p++ -'0';
      }
      if (precision >= sizeof(buf)) {
        goto __null_term_and_return;
      }
    }
    switch(*p) {
    case 'c':
      dest[oi++] = va_arg(argp, int);
      break;

    case 'u':
      val = va_arg(argp, uint64_t);
      i = 0;
      if (val  == 0) {
        buf[i++] = '0';
      } else {
        while (val) {
          buf[i] = (uint64_t)val % 10 + '0';
          val = (uint64_t)val / 10;
          i += 1;
        }
      }
      while (i < width) {
        buf[i++] = leading_zero ? '0' : ' ';
      }
      // do not allow overrun
      for (width = i; width && (oi < sz-1); width--)
        dest[oi++] = buf[width-1];
      break;

    case 'd':                       // signed integer
      val = va_arg(argp, uint64_t);
      neg = ((val & (1ull << 63)) != 0);
      if (neg) {
        val = -val;
      }
      if (neg && width) width -= 1;
      i = 0;
      if (val  == 0) {
        buf[i++] = '0';
      } else {
        while (val) {
          buf[i] = val % 10 + '0';
          val /= 10;
          i += 1;
        }
      }
      while (i < width) {
        buf[i++] = leading_zero ? '0' : ' ';
      }
      if (neg) buf[i++] = '-';
      // do not allow overrun
      for (width = i; width && (oi < sz-1); width--)
        dest[oi++] = buf[width-1];
      break;

    case 's':                      // string
      // add  -xx support
      s = va_arg(argp, char *);
      while (*s && (oi < sz-1)) {
        dest[oi++] = *s++;
        if (width != 0) width -= 1;
        if (precision != 0) {
          precision -= 1;
          if (precision == 0) break;
        }
      }
      while ((width != 0) && (oi < sz-1)) {
        width -= 1;
        dest[oi++]  = ' ';
      }
      break;

    case 'x':                      //  hex
      // supports %#10x but maybe not exactly as ANSI version      if (hash) leading_zero = 1;
      val = va_arg(argp, uint64_t);
      i = 0;
      if (val  == 0) {
        buf[i++] = '0';
      } else {
        while (val) {
          buf[i] = val & 0xf;
          buf[i] += buf[i] > 9 ? 'a'-10 : '0';
          val = (uint64_t)val >> 4;
          i += 1;
        }
      }
      if (hash && width > 1) width -= 2;
      while (i < width) {
        buf[i++] = leading_zero ? '0' : ' ';
      }
      if (hash) {
        buf[i++] = 'x';
        buf[i++] = '0';
      }
      for (width = i; width && (oi < sz-1); width--)
        dest[oi++] = buf[width-1];
      break;

    case '%':
      dest[oi++] = '%';
      break;
    }
  }
  // DO NOT!!! call va_end(argp) here. This should be done by the caller *after* the call to __vsnprintf returned, on the same stack frame
 __null_term_and_return:
  dest[oi++] = 0; // null term
  return oi;
}

// variadic version of snprintf, using ellipsis
uint32_t __snprintf(char *dest, const uint32_t sz, const char *format_string, ...) {
  va_list argp;
  uint32_t printed;
  va_start(argp, format_string);
  printed = __vsnprintf(dest, sz, format_string, argp);
  va_end(argp);
  return printed;
}

// for the die hards, UART/trickbox __printf that calls __vsnprintf()
uint32_t X__printf(const char *format_string, ...) {
  va_list argp;
  uint32_t printed;
  static char obuf[1024];

  ubsa_lock(LK_PRINTF);

  va_start(argp, format_string);
  printed = __vsnprintf(obuf, sizeof(obuf), format_string, argp);
  va_end(argp);
  obuf[printed-1] = 0; // Null term, this should be unnecessary
  puts(obuf);

  ubsa_unlock(LK_PRINTF);

  return printed;
}

/*
void memset(void *s, int c, uint64_t n) {
  if (c != 0) {
    uint64_t i;
    for (i=0; i<n; ++i) {
      void *location;
      location = s + i;
      *(char *)location = c;
    }
  }
  else {
    uint64_t offset_mask;
    uint64_t cl_size;
    uint64_t i;
    cl_size = 1 << 6;
    offset_mask = cl_size - 1;
    for (i=0; i<n; ) {
      void *location;
      location = s + i;
      if (((uint64_t)location & offset_mask) || ((n - i) < cl_size)) {
        *(char *)location = c;
        i += 1;
      }
      else {
        // Cache line aligned and at least a line of data left.
        asm volatile(
          "dc zva, %[location]"
          :
          // No outputs.
          :
          [location] "r" (location)
          :
          // No clobber.
        );
        i += cl_size;
      }
    }
  }
  asm volatile("dmb sy");
}
*/
#define ARCH_TIMER_CTRL_ENABLE    (1 << 0)
#define ARCH_TIMER_CTRL_IT_MASK   (1 << 1)

#define ARCH_TIMER_REG_CTRL   0
#define ARCH_TIMER_REG_FREQ   1
#define ARCH_TIMER_REG_TVAL   2
#define ARCH_TIMER_REG_PCT    3




static void arch_timer_reg_write(int reg, u32 val)
{
  switch (reg) {
    case ARCH_TIMER_REG_CTRL:
      asm volatile("msr cntp_ctl_el0,  %0" : : "r" (val));
      break;
    case ARCH_TIMER_REG_TVAL:
      asm volatile("msr cntp_tval_el0, %0" : : "r" (val));
      break;
    case ARCH_TIMER_REG_PCT:
      asm volatile("msr cntpct_el0, %0" : : "r" (val));
      break;
    default:
      X__printf("Unknown option\n");
  }

  asm("isb");
}

static u64 arch_timer_reg_read(int reg)
{
  u64 val = 0;

  switch (reg) {
    case ARCH_TIMER_REG_CTRL:
      asm volatile("mrs %0, cntp_ctl_el0" : "=r" (val));
      break;
    case ARCH_TIMER_REG_FREQ:
      asm volatile("mrs %0, cntfrq_el0" : "=r" (val));
      break;
    case ARCH_TIMER_REG_TVAL:
      asm volatile("mrs %0, cntp_tval_el0" : "=r" (val));
      break;
    case ARCH_TIMER_REG_PCT:
      asm volatile("mrs %0, cntpct_el0" : "=r" (val));
      break;
    default:
      X__printf("Unknown option\n");
  }

  return val;
}

static void arch_counter_enable_user_access(void)
{
  u32 cntkctl;

  /* Disable user access to the timers and the virtual counter. */
  asm volatile("mrs %0, cntkctl_el1" : "=r" (cntkctl));
  cntkctl &= ~((3 << 8) | (1 << 0));

  /* Enable user access to the physical counter and frequency. */
  cntkctl |= (1 << 1);
  asm volatile("msr cntkctl_el1, %0" : : "r" (cntkctl));
}

int arch_timer_setup(void)
{
  u32 *cntcr = (u32 *)0x10580000;

  /* Enable Generic Ctr Ctrl */
  *cntcr = 0x1;

  /* Make sure timer is disabled and interrupt is masked */
  arch_timer_reg_write(ARCH_TIMER_REG_CTRL, ARCH_TIMER_CTRL_IT_MASK);
        arch_counter_enable_user_access();

  return 0;
}


void arch_timer_stop(void)
{
  unsigned long ctrl;

  ctrl = arch_timer_reg_read(ARCH_TIMER_REG_CTRL);
  ctrl &= ~ARCH_TIMER_CTRL_ENABLE;
  arch_timer_reg_write(ARCH_TIMER_REG_CTRL, ctrl);
}

void arch_timer_start(void)
{
  unsigned long ctrl;

  ctrl = arch_timer_reg_read(ARCH_TIMER_REG_CTRL);
  ctrl |= ARCH_TIMER_CTRL_ENABLE;
  arch_timer_reg_write(ARCH_TIMER_REG_CTRL, ctrl);
}

void arch_timer_udelay(u32 usec)
{
  volatile u32 val = 0;
  u32 rate = arch_timer_reg_read(ARCH_TIMER_REG_FREQ);
  u32 cnt = ((rate / 1000000) * usec);

  arch_timer_reg_write(ARCH_TIMER_REG_TVAL, cnt);

  arch_timer_start();
  while(1) {
    val = arch_timer_reg_read(ARCH_TIMER_REG_TVAL);
    if (val == 0 || val > cnt)
      break;
  }
  arch_timer_stop();
}

uint32_t arch_timer_start_reset()
{
  arch_timer_reg_write(ARCH_TIMER_REG_TVAL, 0);
  arch_timer_start();
  return (1);
}

uint64_t arch_timer_elapsed(uint64_t *tmr)
{
  uint64_t val, ret;
  uint32_t rate = arch_timer_reg_read(ARCH_TIMER_REG_FREQ);
  val = arch_timer_reg_read(ARCH_TIMER_REG_TVAL) & 0xFFFFFFFFull;
  if (val > *tmr) {
    ret = ((1ull << 32) | *tmr) - val;
  } else {
    ret = *tmr - val;
  }
  ret = ret / (rate/1000);
  if (ret > 0)
    *tmr = val;
  return (ret);
}

#define UART_MCR    0x10
#define UART_LCR    0xC
#define UART_DLL    0x0
#define UART_DLM    0x4
#define UART_FCR    0x8
#define UART_IER    0x4
#define UART_THR    0x0
#define UART_LSR    0x14
#define UART_RBR    0x0

static unsigned char readb(volatile unsigned char *addr) {
  return *addr;
}

static void writeb(unsigned char c, volatile unsigned char *addr) {
  *addr = c;
}

static void serial_putc_dev(uint64_t base, const char c)
{
  int i;

  if (c == '\n')
    serial_putc_dev(base, '\r');

  /* check THRE bit, wait for transmiter available */
  for (i = 1; i < 3500; i++) {
//    int d;
    if ((readb((u8 *)base + UART_LSR) & 0x20) == 0x20)
      break;

//    for (d = 0; d < 10; d++) {
//      asm volatile ("isb");
//    }
    arch_timer_udelay (10);
  }

  writeb(c, (u8 *)base + UART_THR); /* put character out */
}

static void serial_puts_dev (uint64_t base, const char *s)
{
  while (*s)
    serial_putc_dev (base, *s++);
}

void putc(char x) {
  serial_putc_dev(CONFIG_UART_BASE, x);
}

void puts(const char *x) {
  serial_puts_dev(CONFIG_UART_BASE, x);
}


/*-----------------------------------------------------------------------------+
  | Line Status Register.
  +-----------------------------------------------------------------------------*/
#define asyncLSRDataReady1            0x01
#define asyncLSROverrunError1         0x02
#define asyncLSRParityError1          0x04
#define asyncLSRFramingError1         0x08
#define asyncLSRBreakInterrupt1       0x10
#define asyncLSRTxHoldEmpty1          0x20
#define asyncLSRTxShiftEmpty1         0x40
#define asyncLSRRxFifoError1          0x80

int serial_getc_dev (uint64_t base)
{
  volatile unsigned char status = 0;

  while (1) {
    status = readb((u8 *)base + UART_LSR);
    if ((status & asyncLSRDataReady1) != 0x0)
      break;

    if ((status & ( asyncLSRFramingError1 |
        asyncLSROverrunError1 |
        asyncLSRParityError1  |
        asyncLSRBreakInterrupt1 )) != 0) {
      writeb(asyncLSRFramingError1 |
            asyncLSROverrunError1 |
            asyncLSRParityError1  |
            asyncLSRBreakInterrupt1, (u8 *)base + UART_LSR);
    }
  }

  return (0x000000ff & (int) readb((u8 *)base + UART_RBR));
}

int serial_tstc_dev (uint64_t base)
{
  unsigned char status;

  status = readb((u8 *)base + UART_LSR);
  if ((status & asyncLSRDataReady1) != 0x0)
    return (1);

  if ((status & ( asyncLSRFramingError1 |
      asyncLSROverrunError1 |
      asyncLSRParityError1  |
      asyncLSRBreakInterrupt1 )) != 0) {
    writeb(asyncLSRFramingError1 |
          asyncLSROverrunError1 |
          asyncLSRParityError1  |
          asyncLSRBreakInterrupt1, (u8 *)base + UART_LSR);
  }

  return 0;
}


char getc()
{
//  while (!serial_tstc_dev(CONFIG_UART_BASE)) { }
  return (char)serial_getc_dev(CONFIG_UART_BASE);
}

int tstc()
{
  return serial_tstc_dev(CONFIG_UART_BASE);
}


