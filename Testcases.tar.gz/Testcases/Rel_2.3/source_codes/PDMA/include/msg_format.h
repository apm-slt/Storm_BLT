#ifndef __MSG_FORMAT_H__
#define __MSG_FORMAT_H__

static int dequeue_slot[256];
static int freepool_slot[256];

////////////////////////////////////////
////Message Definitions
////////////////////////////////////////
typedef int msg_16b_array[4];

typedef struct {
   int DecrementByN:8;
   int MailboxID:6;
   int SlaveID:4;
   int reserved:12;
   int test_mode:2;
 } msg_4b_field_t;

typedef union {
  int       raw;
  msg_4b_field_t field;
} msg_4b_t;

typedef struct {
  int UserInfo:32;

  int FPQNum:12;
  int RSVD2:2;
  int ELErr:2;
  int LEI:2;
  int NV:1;
  int LL:1;
  int PB:1;
  int HB:1;
  int RSVD1:1;
  int IN:1;
  int RType:4;
  int LErr:3;
  int HL:1;

  unsigned long long DataAddr:42;
  int RSVD0:6;
  int BufDataLength:15;
  int C:1;

} msg_16b_field_0_t;

typedef struct {

  unsigned long long HopInfoMSBs:48;
  int TotDataLengthLinkListLSBs:12;
  int RSVD4:1;
  int DR:1;
  int RSVD3:1;
  int HR:1;

  unsigned long long HopInfoLSBs:48;
  int HEnqNum:12;
  int HFPSel:4;
} msg_16b_field_1_t;

typedef struct {
  unsigned long long NxtDataAddr2:42;
  int RSVD8:2;
  int NxtFPQNumMsbs:4;
  int NxtBufDataLength2:15;
  int RSVD7:1;

  unsigned long long NxtDataAddr1:42;
  int RSVD6:6;  
  int NxtBufDataLength1:15;
  int RSVD5:1;
} msg_16b_field_2_t;

typedef struct {
  unsigned long long NxtDataAddr4:42;
  int RSVD12:2;
  int NxtFPQNumLsbs:4;
  int NxtBufDataLength4:15;
  int RSVD11:1;

  unsigned long long NxtDataAddr3:42;
  int RSVD10:2;
  int NxtFPQNum:4;
  int NxtBufDataLength3:15;
  int RSVD9:1;
} msg_16b_field_3_t;

typedef union {
  msg_16b_array   raw;
  msg_16b_field_0_t field0;
  msg_16b_field_1_t field1;
  msg_16b_field_2_t field2;
  msg_16b_field_3_t field3;
} msg_16b_t;

#endif /*__MSG_FORMAT_H__*/

