/*
 * pdma_check.h
 *
 *  Created on: Jan 4, 2013
 *      Author: lxpham
 */

#ifndef PDMA_CHECK_H_
#define PDMA_CHECK_H_


#include "pdma_crc_lib.h"
#include "qm.h"
#include "global.h"
#include "pdma_lib.h"
#include "vPDMA_defines.h"


#define DMA_CHECK_PASS 0x0
#define DMA_CHECK_FAIL 0x1

//Tinh-SLT:
#define end_test end_test_pdma_copy
//End of Tinh-SLT


/*Function Declaration*/
/***************************************************************************************************************/
int dma_check_crc(dma_params_t dma_params);
void dma_check_status(int status);
void dma_error();
int dma_check_gather_scatter(dma_params_t dma_params);
int dma_check_gather_scatter_striding_mode(dma_params_t dma_params);
int dma_check_copy_dif(dma_params_t dma_params, dma_dif_result_ptr ptr_dma_dif_result);
int dma_sdp_check(dma_cmplt_msg_32b_ptr cmplt_msg);
int dma_check_raid(int CHID, dma_params_t dma_params);
int dma_check_ins_dif(dma_params_t dma_params, dma_dif_result_ptr ptr_dma_dif_result);
void test_fail();
void end_test();
/*************************************************************************************************************/


#endif /* PDMA_CHECK_H_ */

