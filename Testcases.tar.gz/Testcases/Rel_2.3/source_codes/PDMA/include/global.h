/*
 * global.h
 *
 *  Created on: Jan 4, 2013
 *      Author: lxpham
 */

#ifndef GLOBAL_H_
#define GLOBAL_H_

#include "vPDMA_defines.h"



#define  READ8(add)         (*(volatile unsigned char *)(add))
#define  READ16(add)         (*(volatile unsigned short *)(add))
#define  READ32(add)        (*(volatile unsigned *)(add))
#define  WRITE8(add, data)     *(unsigned char *)(add) = (unsigned char)(data)
#define  WRITE16(add, data)    *(unsigned short *)(add) = (unsigned short  )(data)
#define  WRITE32(add, data)    *(unsigned *)(add) = (unsigned )(data)

typedef unsigned char u8;

#ifndef u32
#define u32 unsigned int
#endif /*u32*/

#ifndef u64
#define u64 unsigned long long
#endif /*u64*/

#define in_le32		arm_in_le32
#define out_le32	arm_out_le32

#ifndef NULL
#define NULL ((void *)0)
#endif /*NULL*/

#define SM_CHK_PTR(p) \
		{if(!p) {{printf("%s, %s, line=%d, Null Ptr Passed.\n",\
				__FILE__, __FUNCTION__, __LINE__);}; return SM_FAIL;}}

#define SM_CHK_RET(ret)							\
  {if (ret != SM_OK) {printf("SM_CHK_RET:: %s\n", ret);return ret;}}


typedef enum{
    SM_OK,
    SM_INVALID_PARAM,
    SM_NO_RSC,
    SM_TIMEOUT,
    SM_FATAL,
    SM_FAIL

} sm_ret_t;



void *mem_set(void *s, int c, int n);
void putnum(unsigned int num);
void putnum_64(unsigned long num);
void print (const char* str);
int read(unsigned int *address);
void write(unsigned int *address, int data);
void reg_dump(unsigned int addr, unsigned int wordcount);
void mem_dump(unsigned int addr, unsigned int wordcount);
void mem_dump_64(u64 addr, unsigned int wordcount);

void msg_dump(u32* addr, u32 size);
void mdump(u32* addr, u32 size) ;


#endif /* GLOBAL_H_ */
