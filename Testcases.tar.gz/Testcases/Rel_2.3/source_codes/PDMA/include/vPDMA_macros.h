#ifndef _vPDMA_MACROS_H_
#define _vPDMA_MACROS_H_


#include "pdma_lib.h"
#include "qm.h"
/**********************************************************************************************/
/*These functions are used only for PDMA Virtual address and Physical Address conversion*/

/*
 * arg: virtual address
 * expect: physical address
 *
 * */
#ifdef VBIOS_USE_MAPPING
/*
 * Use this if VBIOS2 maps DDR physical addresses to different virtual addresses
 * It means VA != PA
 * */
#include "../include/mmu.h"

typedef enum {
	NORMAL,
	LINKLIST,
}dma_mode_t;

unsigned long long DDR_SYS_BASE =0;

#define my_pa_to_va(x)     ((unsigned long long)(CONFIG_DDR_VIRT_ADDRESS) + ((unsigned long long)(x) - DDR_SYS_BASE))
#define my_va_to_pa(x)     (DDR_SYS_BASE + ((unsigned long long)(x) -(unsigned long long)CONFIG_DDR_VIRT_ADDRESS))
#endif /*VBIOS_USE_MAPPING*/


#endif /*_vPDMA_MACROS_H_*/
/**********************************************************************************************/
