/* Author: automation@apm.com
*  Company: Applied Micro Circuits Corporation (AMCC)
*
* Describe the purpose of your Test here
*   - Include all common functions here
*/

#ifndef __COMMON_H__
#define __COMMON_H__

//Tinh-SLT:
#define printPASS printPASS_pdma_copy
#define printFAIL printFAIL_pdma_copy
//End of Tinh-SLT

void printPASS(void);
void printFail(void);
#endif /*__COMMON_H__*/
