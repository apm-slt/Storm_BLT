/*
 * pdma_crc_lib.h
 *
 *  Created on: Jan 4, 2013
 *      Author: lxpham
 */

#ifndef PDMA_CRC_LIB_H_
#define PDMA_CRC_LIB_H_
/*Function Declaration*/
/*******************************************************************************************************************************/

unsigned int crc(unsigned int width, unsigned int poly, unsigned int init_value, unsigned int refIn,
                 unsigned int refOut, unsigned int xorOut, unsigned char *l, unsigned int data_size);
unsigned int get_crc16(unsigned char *data, unsigned int data_size);
unsigned int get_crc16_seed(unsigned char *data, unsigned int data_size, unsigned int init);
unsigned int get_iscsi_crc32c(unsigned char *data, unsigned int data_size);
unsigned int get_iscsi_crc32c_seed(unsigned char *data, unsigned int data_size, unsigned int init);
unsigned int get_eth_crc32e(unsigned char *data, unsigned int data_size);
unsigned int get_eth_crc32e_seed(unsigned char *data, unsigned int data_size, unsigned int init);
unsigned int get_generic_crc32(unsigned char *data, unsigned int data_size, unsigned int poly_hash, unsigned int init);
unsigned int get_chksum16(unsigned char *l, unsigned int data_size, unsigned int chksum_seed);
unsigned char adg_mul (unsigned char data, unsigned char poly_mul, unsigned char adg_sel);

/*********************************************************************************************************************************/




#endif /* PDMA_CRC_LIB_H_ */

