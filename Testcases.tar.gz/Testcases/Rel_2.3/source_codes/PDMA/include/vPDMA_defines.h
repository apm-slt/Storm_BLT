#ifndef __vPDMA_defines_h__
#define __vPDMA_defines_h__

#define ARM_CC

/*Use ASIC CODE*/
#define ASIC_CODE

/*Use source code ported from BlackMamba*/
//#define VAL_CODE

/*Use Vbios*/
//#define ZZZVBIOS

#define BUFFER_16KB

#ifdef 	BUFFER_16KB
#define 	BUFFER_MAX		0x3FFF
#define 	BUFFER_SIZE		0x0
#endif /*BUFFER_16KB*/

#ifdef 	BUFFER_4KB
#define 	BUFFER_MAX		0xFFF
#define 	BUFFER_SIZE		0x4000
#endif /*BUFFER_4KB*/


#ifdef 	BUFFER_2KB
#define 	BUFFER_MAX		0x7FF
#define 	BUFFER_SIZE		0x5000
#endif /*BUFFER_2KB*/


#ifdef 	BUFFER_1KB
#define 	BUFFER_MAX		0x3FF
#define 	BUFFER_SIZE		0x6000
#endif /*BUFFER_1KB*/


#ifdef 	BUFFER_256B
#define 	BUFFER_MAX		0xFF
#define 	BUFFER_SIZE		0x7000
#endif /*BUFFER_256B*/
#endif /*__vPDMA_defines_h__*/



