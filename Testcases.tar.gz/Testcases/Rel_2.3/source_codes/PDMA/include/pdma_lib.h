/*
 * pdma_lib.h
 *
 *  Created on: Jan 4, 2013
 *      Author: lxpham
 */

#ifndef PDMA_LIB_H_
#define PDMA_LIB_H_

#include "msg_format.h"
#include "vPDMA_defines.h"
#include "vPDMA_regs.h"
#include "qm.h"
#include "sm_common_reg_offset.h"
#include "pdma_lib.h"
#include "pdma_crc_lib.h"
#include "global.h"





extern const unsigned int DMA_CSR_BASE;
//extern unsigned int dma_FP_length;
extern unsigned int m;// = (unsigned long)4294967295;
extern unsigned int a;// = 1664525;
extern unsigned int c;// = 1013904223;
extern unsigned int Xn;


#define DMA_CPU_MEM_ACCESS_MASK 0x00000000
#define DMA_QM_ID 0x1
//#endif
#define DMA_FB_NONE   0x0
#define DMA_FB_CRC16  0x1
#define DMA_FB_CRC32  0x2
#define DMA_FB_CRC32E 0x3
#define DMA_FB_CHKSM  0x4
#define DMA_FB_DIF    0x5
#define DMA_FB_XOR2   0x8
#define DMA_FB_XOR3   0x9
#define DMA_FB_XOR4   0xA
#define DMA_FB_XOR5   0xB
#define RAID6_MULT    0x20000000

typedef union {
  struct {
    unsigned long long CTL:4;
    unsigned long long FBY:4;
    unsigned long long SrcStridingSize:9;
    unsigned long long SrcDistance:9;
    unsigned long long DstStridingSize:9;
    unsigned long long DstDistance:9;
    unsigned long long Rsvd0:4;
    unsigned long long TotDataLengthLinkListLSBs:12;
    unsigned long long Rsvd1:1;
    unsigned long long DR:1;
    unsigned long long Rsvd2:1;
    unsigned long long HR:1;
    unsigned long long DestAddress:42;
    int Rsvd3:6;
    int HEnqNum:12;
    int HFPSel:4;
  } transfer;
  struct {
    unsigned long long CTL:4;
    unsigned long long FBY:4;
    unsigned long long SrcStridingSize:9;
    unsigned long long SrcDistance:9;
    unsigned long long DstStridingSize:9;
    unsigned long long DstDistance:9;
    unsigned long long Rsvd0:4;
    unsigned long long TotDataLengthLinkListLSBs:12;
    unsigned long long Rsvd1:1;
    unsigned long long DR:1;
    unsigned long long Rsvd2:1;
    unsigned long long HR:1;
    unsigned long long PtrDestLL:40;  //ASIC 38
//    int Rsvd3:2;
    int LinkSize:8;
    int HEnqNum:12;
    int HFPSel:4;
  } transfer_dest_ll;
  struct {
    unsigned long long CTL:4;
    unsigned long long FBY:4;
    unsigned long long Seed:32; // Used for CRC/Checksum
    /*modified 08Mar13*/
//    unsigned int Seed:32; // Used for CRC/Checksum
//    unsigned long long FBY:4;

    unsigned long long Rsvd0:8;
    unsigned long long TotDataLengthLinkListLSBs:12;
    unsigned long long Rsvd1:1;
    unsigned long long DR:1;
    unsigned long long Rsvd2:1;
    unsigned long long HR:1;
    unsigned long long ByteCnt:16;
    unsigned long long Rsvd3:32;
    unsigned long long HEnqNum:12;
    unsigned long long HFPSel:4;
  } crc_chksum;
  struct {
    unsigned long long BD:1;
    unsigned long long SD:1;
    unsigned long long GN:1;
    unsigned long long ST:1;
    unsigned long long FBY:4;
    unsigned long long Seed:32; // Used for CRC/Checksum
    /*modified 11Mar13*/
//    unsigned long long Seed:32; // Used for CRC/Checksum
//    unsigned long long FBY:4;

    unsigned long long Rsvd0:8;
    unsigned long long TotDataLengthLinkListLSBs:12;
    unsigned long long Rsvd1:1;
    unsigned long long DR:1;
    unsigned long long Rsvd2:1;
    unsigned long long HR:1;
    unsigned long long ByteCnt:16;
    unsigned long long Rsvd3:32;
    unsigned long long HEnqNum:12;
    unsigned long long HFPSel:4;
  } flyby;
  struct {
    unsigned long long CTL:4;
    unsigned long long FBY:4;
    unsigned long long Multi0:8;
    unsigned long long Multi1:8;
    unsigned long long Multi2:8;
    unsigned long long Multi3:8;
    unsigned long long Multi4:8;
    unsigned long long TotDataLengthLinkListLSBs:12;
    unsigned long long Rsvd1:1;
    unsigned long long DR:1;
    unsigned long long Rsvd2:1;
    unsigned long long HR:1;
    unsigned long long DestAddress:42;
    unsigned long long Rsvd3:6;
    unsigned long long HEnqNum:12;
    unsigned long long HFPSel:4;
  } raid;
  struct {
    unsigned long long CTL:4;
    unsigned long long FBY:4;
    unsigned long long Rsvd0:24;
    unsigned long long AppTag:16;
    unsigned long long TotDataLengthLinkListLSBs:12;
    unsigned long long Rsvd1:1;
    unsigned long long DR:1;
    unsigned long long Rsvd2:1;
    unsigned long long HR:1;
    unsigned long long RefTag:32;
    unsigned long long BlkSize:3;
    int Rsvd3:13;
    int HEnqNum:12;
    int HFPSel:4;
  } dif;
} dma_msg_16B_field_1;

typedef union {
  struct {
    unsigned long long NxtDataAddr4:42;
    int RSVD12:2;
    int NxtFPQNumLsbs:4;
    int NxtBufDataLength4:15;
    int RSVD11:1;

    unsigned long long NxtDataAddr3:42;
    int RSVD10:2;
    int NxtFPQNum:4;
    int NxtBufDataLength3:15;
    int RSVD9:1;
  } normal;
  struct {
    unsigned long long Ptr2SrcList:42;
    int RSVD12:2;
    int NxtFPQNumLsbs:4;
    int LinkSize:8;
    int TotLenMSB:8;

    unsigned long long NxtDataAddr3:42;
    int RSVD10:2;
    int NxtFPQNum:4;
    int NxtBufDataLength3:15;
    int RSVD9:1;
  } linklist;
} dma_msg_16B_field_3;

typedef union {
  unsigned char data[8];
  struct {
    unsigned int RefTag:32;
    unsigned int AppTag:16;
    unsigned int CRC:16;
  } dma_dif_result;
} dma_dif_result_t;

typedef union {
  unsigned int data[8];
  struct {
    unsigned int RefTag:32;
    unsigned int AppTag:16;
    unsigned int CRC:16;
  } dma_dif_result_chk;
} dma_dif_result_chk_t;

typedef union {
  unsigned int  data[8];
  struct {
    msg_16b_field_0_t field0;
    msg_16b_field_1_t field1;
  } dma_cmplt_msg_32b;
  struct {
    unsigned int UserInfo:32;

    unsigned int FPQNum:12;
    unsigned int RSVD2:2;
    unsigned int ELErr:2;
    unsigned int LEI:2;
    unsigned int NV:1;
    unsigned int LL:1;
    unsigned int PB:1;
    unsigned int HB:1;
    unsigned int RSVD1:1;
    unsigned int IN:1;
    unsigned int RType:4;
    unsigned int LErr:3;
    unsigned int HL:1;

    unsigned long long DataAddr:42;
    unsigned int RSVD0:6;
    unsigned int BufDataLength:15;
    unsigned int C:1;

    unsigned long long ChkResult:16;
    unsigned long long RSVD3:32;
    unsigned long long TotDataLengthLinkListLSBs:12;
    unsigned long long RSVD4:1;
    unsigned long long DR:1;
    unsigned long long RSVD5:1;
    unsigned long long HR:1;
    unsigned long long CRCResult:32;
    unsigned long long RSVD6:16;
    unsigned long long HEnqNum:12;
    unsigned long long HFPSel:4;

  } dma_cmplt_bufdest_1buf;
} dma_cmplt_msg_32b_t;
typedef union {
  unsigned int  data[16];
  struct {
    msg_16b_field_0_t field0;
    msg_16b_field_1_t field1;
    msg_16b_field_2_t field2;
    msg_16b_field_3_t field3;
  } dma_cmplt_msg_64b;
} dma_cmplt_msg_64b_t;

typedef union {
  unsigned int  data[8];
  struct {
    msg_16b_field_0_t field0;
    dma_msg_16B_field_1 field1;
  } dma_work_msg_32b;
} dma_work_msg_32b_t;

typedef union {
  unsigned int  data[16];
  struct {
    msg_16b_field_0_t field0;
    dma_msg_16B_field_1 field1;
    msg_16b_field_2_t field2;
  //msg_16b_field_3_t field3;
    dma_msg_16B_field_3 field3;
  } dma_work_msg_64b;
} dma_work_msg_64b_t;

typedef union {
  unsigned int  data[4];
  msg_16b_field_2_t ll;
} dma_ll_entries;

typedef struct {
  int num_src;
  int num_dst;
  int len_src[256];
  int len_dst[256];
  unsigned long long src[256];
  unsigned long long dst[256];
  unsigned short int SrcStridingSize:9;
  unsigned short int SrcDistance:9;
  unsigned short int DstStridingSize:9;
  unsigned short int DstDistance:9;
  unsigned char BlkSize:3;
  unsigned char FBY:4;
  unsigned int Seed:32;
  unsigned short int  ByteCnt:16;
  unsigned char BD:1;
  unsigned char SD:1;
  unsigned char GN:1;
  unsigned char ST:1;
  unsigned short int ChkResult:16;
  unsigned int CRCResult:32;
  unsigned char Multi0:8;
  unsigned char Multi1:8;
  unsigned char Multi2:8;
  unsigned char Multi3:8;
  unsigned char Multi4:8;
  unsigned char mode;
} dma_params_t;

/*modified 17Nov13
 * Use this for less than 8 sources and destinations because the limited size of OCM
 */
typedef struct {
  int num_src;
  int num_dst;
  int len_src[8];
  int len_dst[8];
  unsigned long long src[8];
  unsigned long long dst[8];
  unsigned short int SrcStridingSize:9;
  unsigned short int SrcDistance:9;
  unsigned short int DstStridingSize:9;
  unsigned short int DstDistance:9;
  unsigned char BlkSize:3;
  unsigned long long FBY:4;
  unsigned long long Seed:32;
  unsigned long long  ByteCnt:16;
  unsigned long long BD:1;
  unsigned long long SD:1;
  unsigned long long GN:1;
  unsigned long long ST:1;
  unsigned short int ChkResult:16;
  unsigned int CRCResult:32;
  unsigned char Multi0:8;
  unsigned char Multi1:8;
  unsigned char Multi2:8;
  unsigned char Multi3:8;
  unsigned char Multi4:8;
  unsigned char mode;
} dma_params_small_size_t;


typedef dma_dif_result_t *dma_dif_result_ptr;
typedef dma_params_t *dma_params_ptr;
typedef dma_work_msg_32b_t *dma_work_msg_32b_ptr;
typedef dma_work_msg_64b_t *dma_work_msg_64b_ptr;
typedef dma_cmplt_msg_32b_t *dma_cmplt_msg_32b_ptr;
typedef dma_cmplt_msg_64b_t *dma_cmplt_msg_64b_ptr;



/*Function Declaration*/
/*********************************************************************************************************************/
void _init_dma();
void _init_dma_msg32(dma_work_msg_32b_ptr ptr);
void _init_dma_msg64(dma_work_msg_64b_ptr ptr);
void init_dma_platform();
void setup_qm_dma();
void dma_setup_msg_32b(int fpqnum, int henqnum, int hfpsel, int bufdatalen, int bufaddr, int pb, int hb, dma_work_msg_32b_ptr ptr);
void dma_setup_msg_64b(int fpqnum, int henqnum, int hfpsel, int bufdatalen, int bufaddr, int pb, int hb, dma_work_msg_64b_ptr ptr);
void dma_set_copy_memdest_msg_32b(dma_work_msg_32b_ptr ptr);
void dma_set_copy_bufdest_msg_32b(dma_work_msg_32b_ptr ptr);
void dma_set_copy_memdest_striding_msg_32b(int SrcStridingSize, int SrcDistance, int DstStridingSize, int DstDistance, dma_work_msg_32b_ptr ptr);
void dma_set_gather_memdest_msg_32b(dma_work_msg_64b_ptr ptr);
void dma_set_gather_bufdest_msg_64b(dma_work_msg_64b_ptr ptr);
void poll_dma_queues(int QID,dma_cmplt_msg_32b_ptr ptr);
void poll_dma_queues_64b(int QID,dma_cmplt_msg_64b_ptr ptr);
void dma_read_cmplt_msg_64b(int qid, dma_cmplt_msg_64b_ptr ptr);
void dma_debug_QMI();
void dma_init_enq_deq_ptr();
unsigned long long dma_get_bufptrs_start_addr(unsigned int BufDataLength);
unsigned int dma_qm_get_allocated_fptr_num(unsigned short int buff_size);
unsigned int dma_get_blksize(int blksize);
unsigned int dma_get_bufsize(int Bufsize);
unsigned int dma_get_BufDataLength(int datalen);
unsigned int dma_get_lendata(int BufDataLength);
void dma_dump_cmplt_msg_32b(dma_cmplt_msg_32b_ptr ptr);
void dma_dump_cmplt_msg_64b(dma_cmplt_msg_64b_ptr ptr);
void dma_dump_work_msg_32b(dma_work_msg_32b_ptr ptr);
void dma_dump_work_msg_64b(dma_work_msg_64b_ptr ptr);
void dma_init_data(dma_work_msg_32b_ptr ptr);
void dma_enqueue_msg_32b(int qid, dma_work_msg_32b_ptr ptr);
void dma_init_data_64b_msg(dma_work_msg_64b_ptr ptr);
void dma_get_params_from_32b(dma_work_msg_32b_ptr ptr,dma_params_ptr ptr_params);
void dma_get_params_from_64b(dma_work_msg_64b_ptr ptr,dma_params_ptr ptr_params);
void dma_get_params_from_cmplt_64b(dma_cmplt_msg_64b_ptr ptr,dma_params_ptr ptr_params);
void dma_get_params_from_cmplt_32b(dma_cmplt_msg_32b_ptr ptr, dma_params_ptr ptr_params);
void dma_build_dest_linklist(unsigned long long dest_addr, int num_of_dest, int bufdatalen,dma_params_ptr dma_params);
void dma_set_gather_scatter_memdest_64b(dma_work_msg_64b_ptr ptr, dma_params_ptr dma_params);
void dma_setup_FP(int qid, int num_of_ptr);
void dma_set_gather_scatter_memdest_striding64b(int SrcStridingSize, int SrcDistance, int DstStridingSize, int DstDistance, dma_work_msg_64b_ptr ptr, dma_params_ptr dma_params);
void dma_set_scatter_memdest_msg_striding_32b(int SrcStridingSize, int SrcDistance, int DstStridingSize, int DstDistance, dma_work_msg_32b_ptr ptr, dma_params_ptr dma_params);
void dma_set_copy_dif_msg_32b(int BlkSize, int RefTag, int AppTag, int CTL, dma_work_msg_32b_ptr ptr,  dma_dif_result_ptr ptr_dma_dif_result);
void dma_build_src_linklist(unsigned long long src_addr, int num_of_src, int bufdatalen, dma_work_msg_64b_ptr ptr, dma_params_ptr dma_params);
int dma_get_gather_dif_BufDataLength(int bufdatalen, dma_work_msg_64b_ptr ptr);

void dma_setup_msg_64b_raid(int fpqnum, int henqnum, int hfpsel, int bufdatalen, int bufaddr, int pb, int hb, dma_work_msg_64b_ptr ptr);

void dma_get_params_from_32b_crc_gen(dma_work_msg_32b_ptr ptr, dma_params_ptr ptr_params);

/***************************** For OCM-DDR transfer test ************************************/
void dma_setup_msg_32b_ocm(int fpqnum, int henqnum, int hfpsel, int bufdatalen, int bufaddr, int pb, int hb, dma_work_msg_32b_ptr ptr);
/***************************** For PDMA performance test ************************************/
void performance_calculate(void);
void AXI_start_measure(unsigned int bytes_stop);

void dma_set_copy_memdest_msg_32b_ddr_ocm(dma_work_msg_32b_ptr ptr);
unsigned int dma_get_bufptrs_start_addr_ocm(unsigned int BufDataLength);

void dma_set_flyby_raid_64b_memdest(unsigned int FBY, unsigned char Multi0, unsigned char Multi1, unsigned char Multi2, unsigned char Multi3, unsigned char Multi4, dma_work_msg_64b_ptr ptr);
/***************************************************************************************************************************************************************************************************/



#endif /* PDMA_LIB_H_ */

