#ifndef __vPDMA_regs_H__
#define __vPDMA_regs_H__


#define SM_DMA_CSR_DMA_IPBRR__ADDR                         0x0
#define SM_DMA_CSR_DMA_GCR__ADDR                           0x10
#define SM_DMA_CSR_DMA_RAID6_CONT__ADDR                    0x14
#define SM_DMA_CSR_DMA_DFIFO_CONT0__ADDR                   0x18
#define SM_DMA_CSR_DMA_DFIFO_CONT1__ADDR                   0x1c
#define SM_DMA_CSR_DMA_RFMC__ADDR                          0x20
#define SM_DMA_CSR_DMA_RFMD0__ADDR                         0x30
#define SM_DMA_CSR_DMA_RFMD1__ADDR                         0x34
#define SM_DMA_CSR_DMA_RFMD2__ADDR                         0x38
#define SM_DMA_CSR_DMA_RFMD3__ADDR                         0x3c
#define SM_DMA_CSR_DMA_WFMC__ADDR                          0x40
#define SM_DMA_CSR_DMA_WFMD0__ADDR                         0x50
#define SM_DMA_CSR_DMA_WFMD1__ADDR                         0x54
#define SM_DMA_CSR_DMA_WFMD2__ADDR                         0x58
#define SM_DMA_CSR_DMA_WFMD3__ADDR                         0x5c
#define SM_DMA_CSR_DMA_WFMD4__ADDR                         0x60
#define SM_DMA_CSR_DMA_WFMD5__ADDR                         0x64
#define SM_DMA_CSR_DMA_INT__ADDR                           0x70
#define SM_DMA_CSR_DMA_INTMASK__ADDR                       0x74
#define SM_DMA_CSR_DMA_TIMEOC__ADDR                        0x80
#define SM_DMA_CSR_DMA_FPB_TIMEOC__ADDR                    0x84
#define SM_DMA_CSR_DMA_FIFO_LEV0__ADDR                     0x88
#define SM_DMA_CSR_DMA_FIFO_LEV1__ADDR                     0x8c
#define SM_DMA_CSR_DMA_FALSE_INT__ADDR                     0x90
#define SM_DMA_CSR_DMA_RST_CH__ADDR                        0x100


#define SM_QMI_SLAVE_CFGSSQMI0__ADDR                       0x9000
#define SM_QMI_SLAVE_CFGSSQMI1__ADDR                       0x9004
#define SM_QMI_SLAVE_CFGSSQMIQM0__ADDR                     0x9008
#define SM_QMI_SLAVE_CFGSSQMIQM1__ADDR                     0x900c
#define SM_QMI_SLAVE_CFGSSQMIFPDISABLE__ADDR               0x9010
#define SM_QMI_SLAVE_CFGSSQMIFPRESET__ADDR                 0x9014
#define SM_QMI_SLAVE_CFGSSQMIWQDISABLE__ADDR               0x9018
#define SM_QMI_SLAVE_CFGSSQMIWQRESET__ADDR                 0x901c
#define SM_QMI_SLAVE_STSSSQMIFPPTR0__ADDR                  0x9020
#define SM_QMI_SLAVE_STSSSQMIFPPTR1__ADDR                  0x9024
#define SM_QMI_SLAVE_STSSSQMIFPPTR2__ADDR                  0x9028
#define SM_QMI_SLAVE_STSSSQMIFPPTR3__ADDR                  0x902c
#define SM_QMI_SLAVE_STSSSQMIFPNUMENTRIES0__ADDR           0x9030
#define SM_QMI_SLAVE_STSSSQMIFPNUMENTRIES1__ADDR           0x9034
#define SM_QMI_SLAVE_STSSSQMIFPNUMENTRIES2__ADDR           0x9038
#define SM_QMI_SLAVE_STSSSQMIFPNUMENTRIES3__ADDR           0x903c
#define SM_QMI_SLAVE_STSSSQMIWQPTR0__ADDR                  0x9040
#define SM_QMI_SLAVE_STSSSQMIWQPTR1__ADDR                  0x9044
#define SM_QMI_SLAVE_STSSSQMIWQPTR2__ADDR                  0x9048
#define SM_QMI_SLAVE_STSSSQMIWQPTR3__ADDR                  0x904c
#define SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES0__ADDR           0x9050
#define SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES1__ADDR           0x9054
#define SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES2__ADDR           0x9058
#define SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES3__ADDR           0x905c
#define SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES4__ADDR           0x9060
#define SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES5__ADDR           0x9064
#define SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES6__ADDR           0x9068
#define SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES7__ADDR           0x906c
#define SM_QMI_SLAVE_CFGSSQMISABENABLE__ADDR               0x9070
#define SM_QMI_SLAVE_CFGSSQMISAB0__ADDR                    0x9074
#define SM_QMI_SLAVE_CFGSSQMISAB1__ADDR                    0x9078
#define SM_QMI_SLAVE_CFGSSQMISAB2__ADDR                    0x907c
#define SM_QMI_SLAVE_CFGSSQMISAB3__ADDR                    0x9080
#define SM_QMI_SLAVE_CFGSSQMISAB4__ADDR                    0x9084
#define SM_QMI_SLAVE_CFGSSQMISAB5__ADDR                    0x9088
#define SM_QMI_SLAVE_CFGSSQMISAB6__ADDR                    0x908c
#define SM_QMI_SLAVE_CFGSSQMISAB7__ADDR                    0x9090
#define SM_QMI_SLAVE_CFGSSQMISAB8__ADDR                    0x9094
#define SM_QMI_SLAVE_CFGSSQMISAB9__ADDR                    0x9098
#define SM_QMI_SLAVE_STSSSQMIINT0__ADDR                    0x909c
#define SM_QMI_SLAVE_STSSSQMIINT0MASK__ADDR                0x90a0
#define SM_QMI_SLAVE_STSSSQMIINT1__ADDR                    0x90a4
#define SM_QMI_SLAVE_STSSSQMIINT1MASK__ADDR                0x90a8
#define SM_QMI_SLAVE_STSSSQMIINT2__ADDR                    0x90ac
#define SM_QMI_SLAVE_STSSSQMIINT2MASK__ADDR                0x90b0
#define SM_QMI_SLAVE_STSSSQMIINT3__ADDR                    0x90b4
#define SM_QMI_SLAVE_STSSSQMIINT3MASK__ADDR                0x90b8
#define SM_QMI_SLAVE_STSSSQMIINT4__ADDR                    0x90bc
#define SM_QMI_SLAVE_STSSSQMIINT4MASK__ADDR                0x90c0
#define SM_QMI_SLAVE_CFGSSQMIDBGCTRL__ADDR                 0x90c4
#define SM_QMI_SLAVE_CFGSSQMIDBGDATA0__ADDR                0x90c8
#define SM_QMI_SLAVE_CFGSSQMIDBGDATA1__ADDR                0x90cc
#define SM_QMI_SLAVE_CFGSSQMIDBGDATA2__ADDR                0x90d0
#define SM_QMI_SLAVE_CFGSSQMIDBGDATA3__ADDR                0x90d4
#define SM_QMI_SLAVE_STSSSQMIDBGDATA__ADDR                 0x90d8
#define SM_QMI_SLAVE_CFGSSQMIFPQASSOC__ADDR                0x90dc
#define SM_QMI_SLAVE_CFGSSQMIWQASSOC__ADDR                 0x90e0
#define SM_QMI_SLAVE_CFGSSQMIMEMORY__ADDR                  0x90e4
#define SM_QMI_SLAVE_STSSSQMIFIFO__ADDR                    0x90e8
#define SM_QMI_SLAVE_CFGSSQMIQMLITE__ADDR                  0x90ec
#define SM_QMI_SLAVE_CFGSSQMIQMLITEFPQASSOC__ADDR          0x90f0
#define SM_QMI_SLAVE_CFGSSQMIQMLITEWQASSOC__ADDR           0x90f4
#define SM_QMI_SLAVE_CFGSSQMIQMHOLD__ADDR                  0x90f8
#define SM_QMI_SLAVE_STSSSQMIQMHOLD__ADDR                  0x90fc
#define SM_QMI_SLAVE_CFGSSQMIFPQVCASSOC0__ADDR             0x9100
#define SM_QMI_SLAVE_CFGSSQMIFPQVCASSOC1__ADDR             0x9104
#define SM_QMI_SLAVE_CFGSSQMIWQVCASSOC0__ADDR              0x9108
#define SM_QMI_SLAVE_CFGSSQMIWQVCASSOC1__ADDR              0x910c
#define SM_QMI_SLAVE_CFGSSQMIQM2__ADDR                     0x9110


#define SM_DMA_CLKRST_CSR_PDMA_SRST__ADDR                  0xc000
#define SM_DMA_CLKRST_CSR_PDMA_CLKEN__ADDR                 0xc008

#endif /*__vPDMA_regs_H__*/

