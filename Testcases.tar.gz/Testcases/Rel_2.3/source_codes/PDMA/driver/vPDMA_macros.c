/*
 * vPDMA_macros.c
 *
 *  Created on: May 5, 2014
 *      Author: lxpham
 */


#include "../include/vPDMA_macros.h"


#ifdef VBIOS_USE_MAPPING
/*
 * Use this if VBIOS2 maps DDR physical addresses to different virtual addresses
 * It means VA != PA
 * */
unsigned int PDMA_va_to_pa_16(msg_16b_field_0_t_ptr ptr)
{
	unsigned long long temp = 0;
	printf("vi_addr: 0x%12x\n", ptr->DataAddr);
	temp = my_va_to_pa(ptr->DataAddr);
	ptr->DataAddr=temp;
	printf("py_addr: 0x%12x\n", ptr->DataAddr);

	return 0;
}


unsigned int PDMA_va_to_pa(dma_work_msg_32b_ptr ptr)
{
	unsigned long long temp = 0;
	printf("vi_addr: 0x%12x\n", ptr->dma_work_msg_32b.field0.DataAddr);
	temp = my_va_to_pa(ptr->dma_work_msg_32b.field0.DataAddr);
	ptr->dma_work_msg_32b.field0.DataAddr=temp;
	printf("py_addr: 0x%12x\n", ptr->dma_work_msg_32b.field0.DataAddr);

	printf("vi_addr: 0x%12x\n", ptr->dma_work_msg_32b.field1.transfer.DestAddress);
	temp = my_va_to_pa(ptr->dma_work_msg_32b.field1.transfer.DestAddress);
	ptr->dma_work_msg_32b.field1.transfer.DestAddress=temp;
	printf("py_addr: 0x%12x\n", ptr->dma_work_msg_32b.field1.transfer.DestAddress);
	return 0;
}

/*
 * arg: virtual address
 * expect: physical address
 *
 * */

unsigned int PDMA_pa_to_va(dma_work_msg_32b_ptr ptr)
{
	unsigned long long temp = 0;
	printf("py_addr: 0x%12x\n", ptr->dma_work_msg_32b.field0.DataAddr);
	temp = my_pa_to_va(ptr->dma_work_msg_32b.field0.DataAddr);
	ptr->dma_work_msg_32b.field0.DataAddr=temp;
	printf("vi_addr: 0x%12x\n", ptr->dma_work_msg_32b.field0.DataAddr);

	printf("vi_addr: 0x%12x\n", ptr->dma_work_msg_32b.field1.transfer.DestAddress);
	temp = my_pa_to_va(ptr->dma_work_msg_32b.field1.transfer.DestAddress);
	ptr->dma_work_msg_32b.field1.transfer.DestAddress=temp;
	printf("py_addr: 0x%12x\n", ptr->dma_work_msg_32b.field1.transfer.DestAddress);
	return 0;
}


unsigned int PDMA_va_to_pa_msg_64b(dma_work_msg_64b_ptr ptr,int dma_mode)
{
	unsigned long long temp = 0;
	/*Data address 0*/
	printf("vi_addr: 0x%12x\n", ptr->dma_work_msg_64b.field0.DataAddr);
	temp = ddr_va_to_pa(ptr->dma_work_msg_64b.field0.DataAddr);
	ptr->dma_work_msg_64b.field0.DataAddr=temp;
	printf("py_addr: 0x%12x\n", ptr->dma_work_msg_64b.field0.DataAddr);

	/*Data Address 1*/
	printf("vi_addr: 0x%12x\n", ptr->dma_work_msg_64b.field2.NxtDataAddr1);
	temp = ddr_va_to_pa(ptr->dma_work_msg_64b.field2.NxtDataAddr1);
	ptr->dma_work_msg_64b.field2.NxtDataAddr1=temp;
	printf("py_addr: 0x%12x\n", ptr->dma_work_msg_64b.field2.NxtDataAddr1);

	/*Data Address 2*/
	printf("vi_addr: 0x%12x\n", ptr->dma_work_msg_64b.field2.NxtDataAddr2);
	temp = ddr_va_to_pa(ptr->dma_work_msg_64b.field2.NxtDataAddr2);
	ptr->dma_work_msg_64b.field2.NxtDataAddr2=temp;
	printf("py_addr: 0x%12x\n", ptr->dma_work_msg_64b.field2.NxtDataAddr2);

	if(dma_mode==NORMAL){
		/*Data Address 3*/
		printf("vi_addr: 0x%12x\n", ptr->dma_work_msg_64b.field3.normal.NxtDataAddr3);
		temp = ddr_va_to_pa(ptr->dma_work_msg_64b.field3.normal.NxtDataAddr3);
		ptr->dma_work_msg_64b.field3.normal.NxtDataAddr3=temp;
		printf("py_addr: 0x%12x\n", ptr->dma_work_msg_64b.field3.normal.NxtDataAddr3);

		/*Data Address 4*/
		printf("vi_addr: 0x%12x\n", ptr->dma_work_msg_64b.field3.normal.NxtDataAddr4);
		temp = ddr_va_to_pa(ptr->dma_work_msg_64b.field3.normal.NxtDataAddr4);
		ptr->dma_work_msg_64b.field3.normal.NxtDataAddr4=temp;
		printf("py_addr: 0x%12x\n", ptr->dma_work_msg_64b.field3.normal.NxtDataAddr4);
	}
	else if(dma_mode==LINKLIST){
		/*Data Address 3*/
		printf("vi_addr: 0x%12x\n", ptr->dma_work_msg_64b.field3.linklist.NxtDataAddr3);
		temp = ddr_va_to_pa(ptr->dma_work_msg_64b.field3.linklist.NxtDataAddr3);
		ptr->dma_work_msg_64b.field3.linklist.NxtDataAddr3=temp;
		printf("py_addr: 0x%12x\n", ptr->dma_work_msg_64b.field3.linklist.NxtDataAddr3);

		/*Data Address 4*/
		printf("vi_addr: 0x%12x\n", ptr->dma_work_msg_64b.field3.linklist.Ptr2SrcList);
		temp = ddr_va_to_pa(ptr->dma_work_msg_64b.field3.linklist.Ptr2SrcList);
		ptr->dma_work_msg_64b.field3.linklist.Ptr2SrcList=temp;
		printf("py_addr: 0x%12x\n", ptr->dma_work_msg_64b.field3.linklist.Ptr2SrcList);
	}

	/*Destination*/
	if(dma_mode==NORMAL){
		printf("vi_addr: 0x%12x\n", ptr->dma_work_msg_64b.field1.transfer.DestAddress);
		temp = ddr_va_to_pa(ptr->dma_work_msg_64b.field1.transfer.DestAddress);
		ptr->dma_work_msg_64b.field1.transfer.DestAddress=temp;
		printf("py_addr: 0x%12x\n", ptr->dma_work_msg_64b.field1.transfer.DestAddress);
	}
	else if(dma_mode==LINKLIST){
		printf("vi_addr: 0x%12x\n", ptr->dma_work_msg_64b.field1.transfer_dest_ll.PtrDestLL);
		temp = ddr_va_to_pa(ptr->dma_work_msg_64b.field1.transfer_dest_ll.PtrDestLL);
		ptr->dma_work_msg_64b.field1.transfer_dest_ll.PtrDestLL=temp;
		printf("py_addr: 0x%12x\n", ptr->dma_work_msg_64b.field1.transfer_dest_ll.PtrDestLL);

	}
	return 0;
}



/*
 * arg: virtual address
 * expect: physical address
 *
 * */

unsigned int PDMA_pa_to_va_msg_64b(dma_work_msg_64b_ptr ptr,int dma_mode)
{
	unsigned long long temp = 0;
	/*Data address 0*/
	printf("vi_addr: 0x%12x\n", ptr->dma_work_msg_64b.field0.DataAddr);
	temp = ddr_pa_to_va(ptr->dma_work_msg_64b.field0.DataAddr);
	ptr->dma_work_msg_64b.field0.DataAddr=temp;
	printf("py_addr: 0x%12x\n", ptr->dma_work_msg_64b.field0.DataAddr);

	/*Data Address 1*/
	printf("vi_addr: 0x%12x\n", ptr->dma_work_msg_64b.field2.NxtDataAddr1);
	temp = ddr_pa_to_va(ptr->dma_work_msg_64b.field2.NxtDataAddr1);
	ptr->dma_work_msg_64b.field2.NxtDataAddr1=temp;
	printf("py_addr: 0x%12x\n", ptr->dma_work_msg_64b.field2.NxtDataAddr1);

	/*Data Address 2*/
	printf("vi_addr: 0x%12x\n", ptr->dma_work_msg_64b.field2.NxtDataAddr2);
	temp = ddr_pa_to_va(ptr->dma_work_msg_64b.field2.NxtDataAddr2);
	ptr->dma_work_msg_64b.field2.NxtDataAddr2=temp;
	printf("py_addr: 0x%12x\n", ptr->dma_work_msg_64b.field2.NxtDataAddr2);

	if(dma_mode==NORMAL){
		/*Data Address 3*/
		printf("vi_addr: 0x%12x\n", ptr->dma_work_msg_64b.field3.normal.NxtDataAddr3);
		temp = ddr_pa_to_va(ptr->dma_work_msg_64b.field3.normal.NxtDataAddr3);
		ptr->dma_work_msg_64b.field3.normal.NxtDataAddr3=temp;
		printf("py_addr: 0x%12x\n", ptr->dma_work_msg_64b.field3.normal.NxtDataAddr3);

		/*Data Address 4*/
		printf("vi_addr: 0x%12x\n", ptr->dma_work_msg_64b.field3.normal.NxtDataAddr4);
		temp = ddr_pa_to_va(ptr->dma_work_msg_64b.field3.normal.NxtDataAddr4);
		ptr->dma_work_msg_64b.field3.normal.NxtDataAddr4=temp;
		printf("py_addr: 0x%12x\n", ptr->dma_work_msg_64b.field3.normal.NxtDataAddr4);
	}
	else if(dma_mode==LINKLIST){
		/*Data Address 3*/
		printf("vi_addr: 0x%12x\n", ptr->dma_work_msg_64b.field3.linklist.NxtDataAddr3);
		temp = ddr_pa_to_va(ptr->dma_work_msg_64b.field3.linklist.NxtDataAddr3);
		ptr->dma_work_msg_64b.field3.linklist.NxtDataAddr3=temp;
		printf("py_addr: 0x%12x\n", ptr->dma_work_msg_64b.field3.linklist.NxtDataAddr3);

		/*Data Address 4*/
		printf("vi_addr: 0x%12x\n", ptr->dma_work_msg_64b.field3.linklist.Ptr2SrcList);
		temp = ddr_pa_to_va(ptr->dma_work_msg_64b.field3.linklist.Ptr2SrcList);
		ptr->dma_work_msg_64b.field3.linklist.Ptr2SrcList=temp;
		printf("py_addr: 0x%12x\n", ptr->dma_work_msg_64b.field3.linklist.Ptr2SrcList);
	}

	/*Destination*/
	if(dma_mode==NORMAL){
		printf("vi_addr: 0x%12x\n", ptr->dma_work_msg_64b.field1.transfer.DestAddress);
		temp = ddr_pa_to_va(ptr->dma_work_msg_64b.field1.transfer.DestAddress);
		ptr->dma_work_msg_64b.field1.transfer.DestAddress=temp;
		printf("py_addr: 0x%12x\n", ptr->dma_work_msg_64b.field1.transfer.DestAddress);
	}
	else if(dma_mode==LINKLIST){
		printf("vi_addr: 0x%12x\n", ptr->dma_work_msg_64b.field1.transfer_dest_ll.PtrDestLL);
		temp = ddr_pa_to_va(ptr->dma_work_msg_64b.field1.transfer_dest_ll.PtrDestLL);
		ptr->dma_work_msg_64b.field1.transfer_dest_ll.PtrDestLL=temp;
		printf("py_addr: 0x%12x\n", ptr->dma_work_msg_64b.field1.transfer_dest_ll.PtrDestLL);

	}
	return 0;
}

#endif /*USE_VBIOS_MAPPING*/
