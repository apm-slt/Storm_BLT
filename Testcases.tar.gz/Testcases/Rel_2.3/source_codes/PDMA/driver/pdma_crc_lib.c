/*
 * pdma_crc_lib.c
 *
 *  Created on: May 5, 2014
 *      Author: lxpham
 */


#include "../include/pdma_crc_lib.h"


/*Function Protopyte*/
/*********************************************************************************************************************************/

  // return reflected version of value[bits-1:0]
  unsigned int reflect(unsigned int value, unsigned int bits){
    unsigned int i;
//    unsigned int j;
    unsigned int temp;
    temp = 0;
    for (i=0; i < bits; i++) {
//      j = (bits-1) - i;
//      reflect[j] = value[i];
      temp = (temp << 1) + (value % 2);
      value = value >> 1;
    }
    return temp;
  }

  unsigned int make_mask (unsigned int bits) {
    return (((1 << (bits - 1))-1)<<1)|1;
  }

  // -----------------------
  // generic crc function
  // -----------------------
  unsigned int crc(unsigned int width, unsigned int poly, unsigned int init_value, unsigned int refIn,
                   unsigned int refOut, unsigned int xorOut, unsigned char *l, unsigned int data_size) {

    int i;
    int j;
    unsigned char val;
    unsigned char mbit;
    unsigned int  mask;
    unsigned int  crc_value;
    crc_value = init_value;
    mask = make_mask(width);

    for (i=0; i<data_size; i++)  {
      if (refIn) {
        val = reflect(l[i], 8);
      }
      else {
        val = l[i];
        //print("val [");putnum(i);print("] :");putnum(val);print("\n\r");
      }

      for (j=7; j >=0; j--) {
        mbit = ((crc_value >> (width-1))&1);
        crc_value = crc_value <<  1;
        if (mbit != ((val >> j)&1))
          crc_value = crc_value ^ poly;
      }
      //print("data[");putnum(i);print("] :");putnum(l[i]);print("\n\r");
      //print("crc [");putnum(i);print("] :");putnum(crc_value);print("\n\r");
    }

    if (refOut) {
      crc_value = reflect(crc_value, width);
    }
    crc_value = (crc_value ^ xorOut) & mask;
    return crc_value;
  }// : crc

   // ------------------- API functions ---------------
  unsigned int get_crc16(unsigned char *data, unsigned int data_size) {
    return crc(16, 0x8bb7, 0, 0, 0, 0x0, data, data_size);
  }

  unsigned int get_crc16_seed(unsigned char *data, unsigned int data_size, unsigned int init) {
    /*
    unsigned int temp;
    temp = crc(16, 0x8bb7, init, 0, 0, 0x0, *data, data_size);
    print("DATA :");putnum(data);print("\n\r");
    print("INIT :");putnum(init);print("\n\r");
    print("TEMP :");putnum(temp);print("\n\r");
    return temp;*/
    return crc(16, 0x8bb7, init, 0, 0, 0x0, data, data_size);
  }//

  unsigned int get_iscsi_crc32c(unsigned char *data, unsigned int data_size) {
    return crc(32, 0x1edc6f41, 0xffffffff, 1, 1, 0xffffffff, data, data_size);
  }//

  unsigned int get_iscsi_crc32c_seed(unsigned char *data, unsigned int data_size, unsigned int init) {
    return crc(32, 0x1edc6f41, init, 1, 1, 0xffffffff, data, data_size);
  }//

  unsigned int get_eth_crc32e(unsigned char *data, unsigned int data_size) {
    return crc(32, 0x04c11db7, 0xffffffff, 1, 1, 0xffffffff, data, data_size);
  }//

  unsigned int get_eth_crc32e_seed(unsigned char *data, unsigned int data_size, unsigned int init) {
    return crc(32, 0x04c11db7, init, 1, 1, 0xffffffff, data, data_size);
  }//

  unsigned int get_generic_crc32(unsigned char *data, unsigned int data_size, unsigned int poly_hash, unsigned int init) {
    return crc(32, poly_hash, init, 1, 1, 0xffffffff, data, data_size);
  }//
/*
  unsigned int get_chksum16(unsigned char *l, unsigned int data_size, unsigned int chksum_seed) {


    unsigned int sum;
    unsigned int count;
    unsigned int bytecnt;
    unsigned int temp;


    sum = chksum_seed;
    count = data_size;

    bytecnt = 0;
    while( count > 1 )  {

      //sum = sum + (&l[bytecnt] << 8) +  &l[bytecnt+1];
      temp = &l[bytecnt];// << 8;
      temp = temp << 8;
      sum = sum + temp;
      temp = &l[bytecnt+1];
      sum = sum + temp;
      count = count -  2;
//SP-      `AMCC_MESSAGE_FULL("DMAFLYBY", $psprintf("sum[31:0]: %x, sum[31:16]+sum[15:0]: %x, byte[%p]: %x, byte[%p]: %x",sum,sum[31:16]+sum[15:0],bytecnt,l[bytecnt],bytecnt+1,l[bytecnt+1]));
      bytecnt = bytecnt + 2;
    }


    if( count > 0 ) {
      //sum = sum + (&l[bytecnt] << 8);
      temp = &l[bytecnt];
      temp = temp << 8;
      sum = sum + temp;
    }

//SP-      `AMCC_MESSAGE_FULL("DMAFLYBY", $psprintf("sum[31:0]: %x, sum[31:16]+sum[15:0]: %x, byte[%p]: %x",sum,sum[31:16]+sum[15:0],bytecnt,l[bytecnt]));

      while (sum>>16)
        sum = (sum & 0xffff) + (sum >> 16);

//SP-     `AMCC_MESSAGE_FULL("DMAFLYBY", $psprintf("SUM: %x (returned value)",sum));
     return sum;

  }// : get_chksum16
*/
unsigned char adg_mul (unsigned char data, unsigned char poly_mul, unsigned char adg_sel)
{
  int i;
  unsigned char p;
  unsigned char adg_byte;
  unsigned char adg_bit7;

//  printf("Enter adg_mul function\n");
//  printf("ADG_SEL = 0x%x\n",adg_sel);
    //Formula
    // A . {M} = A.M7.{02}^7 + A.M6^6.{02}^6 + A.M5^5.{02}^5 + A.M4.{02}^4 + A.M3.{02} + A.M2.{02} + A.M1.{02} + A.M0
    //         = (((((((A.M7.{02} + A.M6).{02} + A.M5).{02} + A.M4).{02} + A.M3).{02} + A.M2).{02} + A.M1).{02} + A.M0

  //print("ADG_SEL :");putnum(adg_sel);
  adg_byte = 0;
  for (i=7; i>=0 ; i--)
    {
//      print("ADG_MUL:");putnum(adg_byte);print("\n");
//      printf("i= %d\n",i);
      p = (poly_mul >> i) & 0x1;
      adg_bit7 = adg_byte >> 7;
      adg_byte = adg_byte << 1;
      adg_byte = (p!=0) ? adg_byte ^ data : adg_byte;
      adg_byte = adg_byte ^ (adg_bit7 ? adg_sel : 0);
      //print("ADG_MUL_:");putnum(adg_byte);print("\n");
    }
    return adg_byte;

  }

