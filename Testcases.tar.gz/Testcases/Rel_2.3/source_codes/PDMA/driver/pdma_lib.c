/*
 * pdma_lib.c
 *
 *  Created on: May 5, 2014
 *      Author: lxpham
 */


#include "../include/pdma_lib.h"

//Tinh-SLT
//function call
#define write write_pdma_copy
#define read read_pdma_copy
#define print print_pdma_copy
#define putnum putnum_pdma_copy
#define mem_dump mem_dump_pdma_copy
//End of Tinh-SLT



/*Function Declaration*/
/*********************************************************************************************************************/
void _init_dma();
void _init_dma_msg32(dma_work_msg_32b_ptr ptr);
void _init_dma_msg64(dma_work_msg_64b_ptr ptr);
void init_dma_platform();
void setup_qm_dma();
void dma_setup_msg_32b(int fpqnum, int henqnum, int hfpsel, int bufdatalen, int bufaddr, int pb, int hb, dma_work_msg_32b_ptr ptr);
void dma_setup_msg_64b(int fpqnum, int henqnum, int hfpsel, int bufdatalen, int bufaddr, int pb, int hb, dma_work_msg_64b_ptr ptr);
void dma_set_copy_memdest_msg_32b(dma_work_msg_32b_ptr ptr);
void dma_set_copy_bufdest_msg_32b(dma_work_msg_32b_ptr ptr);
void dma_set_copy_memdest_striding_msg_32b(int SrcStridingSize, int SrcDistance, int DstStridingSize, int DstDistance, dma_work_msg_32b_ptr ptr);
void dma_set_gather_memdest_msg_32b(dma_work_msg_64b_ptr ptr);
void dma_set_gather_bufdest_msg_64b(dma_work_msg_64b_ptr ptr);
void poll_dma_queues(int QID,dma_cmplt_msg_32b_ptr ptr);
void poll_dma_queues_64b(int QID,dma_cmplt_msg_64b_ptr ptr);
void dma_read_cmplt_msg_64b(int qid, dma_cmplt_msg_64b_ptr ptr);
void dma_debug_QMI();
void dma_init_enq_deq_ptr();
unsigned long long dma_get_bufptrs_start_addr(unsigned int BufDataLength);
unsigned int dma_qm_get_allocated_fptr_num(unsigned short int buff_size);
unsigned int dma_get_blksize(int blksize);
unsigned int dma_get_bufsize(int Bufsize);
unsigned int dma_get_BufDataLength(int datalen);
unsigned int dma_get_lendata(int BufDataLength);
void dma_dump_cmplt_msg_32b(dma_cmplt_msg_32b_ptr ptr);
void dma_dump_cmplt_msg_64b(dma_cmplt_msg_64b_ptr ptr);
void dma_dump_work_msg_32b(dma_work_msg_32b_ptr ptr);
void dma_dump_work_msg_64b(dma_work_msg_64b_ptr ptr);
void dma_init_data(dma_work_msg_32b_ptr ptr);
void dma_enqueue_msg_32b(int qid, dma_work_msg_32b_ptr ptr);
void dma_init_data_64b_msg(dma_work_msg_64b_ptr ptr);
void dma_get_params_from_32b(dma_work_msg_32b_ptr ptr,dma_params_ptr ptr_params);
void dma_get_params_from_64b(dma_work_msg_64b_ptr ptr,dma_params_ptr ptr_params);
void dma_get_params_from_cmplt_64b(dma_cmplt_msg_64b_ptr ptr,dma_params_ptr ptr_params);
void dma_get_params_from_cmplt_32b(dma_cmplt_msg_32b_ptr ptr, dma_params_ptr ptr_params);
void dma_build_dest_linklist(unsigned long long dest_addr, int num_of_dest, int bufdatalen,dma_params_ptr dma_params);
void dma_set_gather_scatter_memdest_64b(dma_work_msg_64b_ptr ptr, dma_params_ptr dma_params);
void dma_setup_FP(int qid, int num_of_ptr);
void dma_set_gather_scatter_memdest_striding64b(int SrcStridingSize, int SrcDistance, int DstStridingSize, int DstDistance, dma_work_msg_64b_ptr ptr, dma_params_ptr dma_params);
void dma_set_scatter_memdest_msg_striding_32b(int SrcStridingSize, int SrcDistance, int DstStridingSize, int DstDistance, dma_work_msg_32b_ptr ptr, dma_params_ptr dma_params);
void dma_set_copy_dif_msg_32b(int BlkSize, int RefTag, int AppTag, int CTL, dma_work_msg_32b_ptr ptr,  dma_dif_result_ptr ptr_dma_dif_result);
void dma_build_src_linklist(unsigned long long src_addr, int num_of_src, int bufdatalen, dma_work_msg_64b_ptr ptr, dma_params_ptr dma_params);
int dma_get_gather_dif_BufDataLength(int bufdatalen, dma_work_msg_64b_ptr ptr);

void dma_setup_msg_64b_raid(int fpqnum, int henqnum, int hfpsel, int bufdatalen, int bufaddr, int pb, int hb, dma_work_msg_64b_ptr ptr);

void dma_get_params_from_32b_crc_gen(dma_work_msg_32b_ptr ptr, dma_params_ptr ptr_params);

/***************************** For OCM-DDR transfer test ************************************/
void dma_setup_msg_32b_ocm(int fpqnum, int henqnum, int hfpsel, int bufdatalen, int bufaddr, int pb, int hb, dma_work_msg_32b_ptr ptr);
/***************************** For PDMA performance test ************************************/
void performance_calculate(void);
void AXI_start_measure(unsigned int bytes_stop);

void dma_set_copy_memdest_msg_32b_ocm(dma_work_msg_32b_ptr ptr);
unsigned int dma_get_bufptrs_start_addr_ocm(unsigned int BufDataLength);

void dma_set_flyby_raid_64b_memdest(unsigned int FBY, unsigned char Multi0, unsigned char Multi1, unsigned char Multi2, unsigned char Multi3, unsigned char Multi4, dma_work_msg_64b_ptr ptr);
/***************************************************************************************************************************************************************************************************/
void dma_setup_FP_ocm(int qid, int num_of_ptr);

#ifndef ARM_CC
const unsigned int DMA_CSR_BASE = 0x17020000 | DMA_CPU_MEM_ACCESS_MASK;
#else
const unsigned int DMA_CSR_BASE = 0x1F270000;
#endif
 unsigned int dma_FP_length = 0;
 unsigned int DataLength = 0;

///Use this declaration for OCM-DDR transfer test
unsigned int DataLength_ocm = 0;



unsigned int mm = 4294967295;
unsigned int aa = 1664525;
unsigned int cc = 1013904223;
unsigned int Xnn;

unsigned char DMA_RAND = 0;

#define LENGTH_MIN 0x100
#define LENGTH_MAX 0x200
void init_dma_platform() {
#ifndef ARM_CC
  print("\n=============== Init DMA Platform into FPGA  ============\n");
  //  write(0x9704000c, 0x00000008);

  init_platform();

  print("Initializing OCM ...  \n");
  ocm_init();

  read_svn_id();

  print("Virtualized-subsystem MUX select for DMA\n\r");
  write ((unsigned int *)0x9704000c, 0x00000010);
  print("\n=========================================================\n");
#else
  write((unsigned int *)(0x1F41c004),3);  // OCM clken
  write((unsigned int *)(0x1F41c000),0);  // OCM rst deassertion
#endif
}

void _init_dma() {
  int rdata;
  print("\n=============== Setting clock and reset for DMA  ============\n");
  print("Config PDMA_CLKEN \n\r");
  write((unsigned int *)(DMA_CSR_BASE + SM_DMA_CLKRST_CSR_PDMA_CLKEN__ADDR), 0x00000003);			// add changed because dma is mount on Enet slot

  print("Config PDMA_SRST \n\r");
  write((unsigned int *)(DMA_CSR_BASE + SM_DMA_CLKRST_CSR_PDMA_SRST__ADDR), 0x00000000);

  print("Config PDMA_GCR \n\r");
  write((unsigned int *)(DMA_CSR_BASE + SM_DMA_CSR_DMA_GCR__ADDR), 0xf9b99FFF);   // By default, enable for  4 channels
  read((unsigned int *)(DMA_CSR_BASE + SM_DMA_CSR_DMA_GCR__ADDR));
  print("config rf_raid6_mult \n\r");
  write((unsigned int *)(DMA_CSR_BASE + SM_DMA_CSR_DMA_RAID6_CONT__ADDR), RAID6_MULT);

  read((unsigned int *)(DMA_CSR_BASE + SM_DMA_CSR_DMA_RAID6_CONT__ADDR));

  print("Read IPBRR \n\r");
  read  ((unsigned int *)(DMA_CSR_BASE + SM_DMA_CSR_DMA_IPBRR__ADDR));

  print("Config DMA Time Out Control \n\r");
  read((unsigned int  *)(DMA_CSR_BASE + SM_DMA_CSR_DMA_FPB_TIMEOC__ADDR));
  write((unsigned int *)(DMA_CSR_BASE + SM_DMA_CSR_DMA_FPB_TIMEOC__ADDR), 0xFFFF);

  print("DMA_INTMASK \n\r");
  read((unsigned int  *)(DMA_CSR_BASE + SM_DMA_CSR_DMA_INT__ADDR));
  read((unsigned int  *)(DMA_CSR_BASE + SM_DMA_CSR_DMA_INTMASK__ADDR));
  write((unsigned int *)(DMA_CSR_BASE + SM_DMA_CSR_DMA_INTMASK__ADDR), 0x0);
  print("==============================================================\n");

#ifdef ARM_CC
  write((unsigned int *)(DMA_CSR_BASE + SM_GLBL_DIAG_CSR_CFG_MEM_RAM_SHUTDOWN__ADDR ) , 0x00000000);
  do {
    rdata = read((unsigned int *)(DMA_CSR_BASE + SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY__ADDR));
  } while ( rdata != 0xffffffff);
#endif

}

void setup_qm_dma()
{
  // Configure 2WQ (1 for Work Message, 1 for Completions and 2FPQ (1 with DDR buffers, 1 for de-alloc).
  print("\n=============== Configure Queues in QM ============\n");
  qm_csr_init();


  // Set FPQ

  // FPQ for DMA to write the data in OCM.
#ifndef ARM_CC
  fp_qstate_init(FPQID4);
  qm_pb_init(SID_MENET, FPQPBID0, FPQID4);  // slaveid, pbn number, freepoolqid number
  //qm_pb_read(SID_MENET, FPQPBID0);
#else
  fp_qstate_init(FPQID4);



  qm_pb_init(SID_DMA, FPQPBID0, FPQID4);  // slaveid, pbn number, freepoolqid number

  //qm_pb_read(SID_DMA, FPQPBID0);
#endif
  //Enable the qm
#ifndef ARM_CC
  wq_qstate_init(WQID4);
  qm_pb_init(SID_MENET, WQPBID0, WQID4); // slaveid, pbn number, workqueueqid number
  //qm_pb_read(SID_MENET, WQPBID0);
  wq_qstate_init(WQID5);
  qm_pb_init(SID_MENET, WQPBID1, WQID5); // slaveid, pbn number, workqueueqid number
  //qm_pb_read(SID_MENET, WQPBID1);
  wq_qstate_init(WQID6);
  qm_pb_init(SID_MENET, WQPBID2, WQID6); // slaveid, pbn number, workqueueqid number
  //qm_pb_read(SID_MENET, WQPBID2);
  wq_qstate_init(WQID7);
  qm_pb_init(SID_MENET, WQPBID3, WQID7); // slaveid, pbn number, workqueueqid number
  //qm_pb_read(SID_MENET, WQPBID3);
#else

  wq_qstate_init(WQID4);


  qm_pb_init(SID_DMA, WQPBID0, WQID4); // slaveid, pbn number, workqueueqid number
  //qm_pb_read(SID_DMA, WQPBID0);
  wq_qstate_init(WQID5);
  qm_pb_init(SID_DMA, WQPBID1, WQID5); // slaveid, pbn number, workqueueqid number
  //qm_pb_read(SID_DMA, WQPBID1);
  wq_qstate_init(WQID6);
  qm_pb_init(SID_DMA, WQPBID2, WQID6); // slaveid, pbn number, workqueueqid number
  //qm_pb_read(SID_DMA, WQPBID2);
  wq_qstate_init(WQID7);
  qm_pb_init(SID_DMA, WQPBID3, WQID7); // slaveid, pbn number, workqueueqid number
  //qm_pb_read(SID_DMA, WQPBID3);


#endif


  // Completion Queue (DMA --> PROC)
  wq_qstate_init(WQID0);
  qm_pb_init(SID_PROC, WQPBID0, WQID0); // slaveid, pbn number, workqueueqid number
  //qm_pb_read(SID_PROC, WQPBID0);
  fp_qstate_init(FPQID0);
  qm_pb_init(SID_PROC, FPQPBID0, FPQID0);  // slaveid, pbn number, freepoolqid number
  //qm_pb_read(SID_PROC, FPQPBID0);
  qm_enable();
  //dma_setup_FP(FPQID4, 1);  //qid and num_of_pointers max can be 24 only
  //  data_ptr_init(FPQID4, 24);  //qid and num_of_pointers max can be 24 only


  // FPQ to dealloc the messages.

  //data_ptr_init(FPQID0, 24);  //qid and num_of_pointers max can be 24 only


  // Set WQ
  // Work Queue (PROC --> DMA)

  // Configure DMA.

  write((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMIWQDISABLE__ADDR)/*0x97029018*/, 0x000001ff);
  read((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMIWQDISABLE__ADDR)/*0x97029018*/);

  /* // SAB Queue Ids */
  /* write(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMISAB0__ADDR, 0x0812034b); */
  /* read(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMISAB0__ADDR); */
  /* write(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMISAB1__ADDR, 0x01c20a18); */
  /* read(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMISAB1__ADDR); */
  /* write(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMISAB2__ADDR, 0x020b0a86); */
  /* read(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMISAB2__ADDR); */
  /* write(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMISAB3__ADDR, 0x01000b5b); */
  /* read(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMISAB3__ADDR); */
  /* write(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMISAB4__ADDR, 0x03d505f0); */
  /* read(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMISAB4__ADDR); */
  /* write(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMISAB5__ADDR, 0x00000355); */
  /* read(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMISAB5__ADDR); */

  /* //  QML is used so put '1' instead of '0'. */
  /* write(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMIWQASSOC__ADDR, 0x00000100); */
  /* write(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMIWQASSOC__ADDR, 0x000001ff); */
  /* read(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMIWQASSOC__ADDR); */

  write((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMIWQASSOC__ADDR), 0x000001ff);
  read((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMIWQASSOC__ADDR));

  write((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMIFPQASSOC__ADDR), 0x000001ff);
  read((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMIFPQASSOC__ADDR));

#ifndef ARM_CC
  write((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMIQMLITEFPQASSOC__ADDR), 0x000001ff);
  read((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMIQMLITEFPQASSOC__ADDR));

  write((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMIQMLITEWQASSOC__ADDR), 0x000001ff);
  read((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMIQMLITEWQASSOC__ADDR));
#endif
  // QM Hold Enable.
  write((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMIQMHOLD__ADDR), 0x80000007);
  read((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMIQMHOLD__ADDR));

  // Interrupt Mask
  write((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_STSSSQMIINT0MASK__ADDR), 0x00000000);
  read((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_STSSSQMIINT0MASK__ADDR));

  write((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_STSSSQMIINT1MASK__ADDR), 0x00000000);
  read((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_STSSSQMIINT1MASK__ADDR));

  write((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_STSSSQMIINT2MASK__ADDR), 0x00000000);
  read((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_STSSSQMIINT2MASK__ADDR));

  write((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_STSSSQMIINT3MASK__ADDR), 0x00000000);
  read((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_STSSSQMIINT3MASK__ADDR));

  write((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_STSSSQMIINT4MASK__ADDR), 0x00000000);
  read((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_STSSSQMIINT4MASK__ADDR));


  // Temp: disable QMI WQ
  /* write(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMIWQDISABLE__ADDR, 0xffffffff); */
  /* read(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMIWQDISABLE__ADDR); */

  /* print("Read QMI WRK QUEUE\n\r"); */

  /* /\* // read QMI *\/ */
  /* read(DMA_CSR_BASE + SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES0__ADDR); */

  /*************************************/
  // Write a enq message from proc to its own qid

  // Enable QMI WQ
  write((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_CFGSSQMIWQDISABLE__ADDR), 0x00000000);

  dma_init_enq_deq_ptr(); // Normally, we don't need to this since enq_ptr and deq_ptr are global array and initialized by 0 but in FPGA platform, this is not the case

  print("========================================\n");
}
void dma_debug_QMI()
{
  print("Read QMI WRK QUEUE\n\r");
  read  ((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES0__ADDR)/*0x97029050*/);					// read QMI


  // Print FPQ Entries. // For Debug only
  print("=============== FPQEntries0 ============ \n\r");
  read((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_STSSSQMIFPNUMENTRIES0__ADDR)/*0x97029030*/);
  read((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_STSSSQMIFPNUMENTRIES0__ADDR)/*0x97029030*/);
  read((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_STSSSQMIFPNUMENTRIES0__ADDR)/*0x97029030*/);
  read((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_STSSSQMIFPNUMENTRIES0__ADDR)/*0x97029030*/);
  read((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_STSSSQMIFPNUMENTRIES0__ADDR)/*0x97029030*/);
  read((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_STSSSQMIFPNUMENTRIES0__ADDR)/*0x97029030*/);
  print("=============== FPQEntries0 ============ \n\r");

  print("=============== WQEntries0 ============ \n\r");
  read((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES0__ADDR)/*0x97029050*/);
  read((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES0__ADDR)/*0x97029050*/);
  read((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES0__ADDR)/*0x97029050*/);
  read((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES0__ADDR)/*0x97029050*/);
  read((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES0__ADDR)/*0x97029050*/);
  read((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES0__ADDR)/*0x97029050*/);
  read((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES0__ADDR)/*0x97029050*/);
  read((unsigned int *)(DMA_CSR_BASE + SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES0__ADDR)/*0x97029050*/);
  print("=============== WQEntries0 ============ \n\r");


}
#ifdef ARM_CC
unsigned int random()
{

  Xnn = (aa*Xnn + cc) % mm;
  return Xnn;

}
#endif
void _init_dma_msg32(dma_work_msg_32b_ptr ptr)
{
  int i;
  for(i=0; i< 8; i++) ptr->data[i] = 0;
}

void _init_dma_msg64(dma_work_msg_64b_ptr ptr)
{
  int i;
  for(i=0; i< 16; i++) ptr->data[i] = 0;
}

void dma_setup_msg_32b(int fpqnum, int henqnum, int hfpsel, int bufdatalen, int bufaddr, int pb, int hb, dma_work_msg_32b_ptr ptr)
{
  print("\n=====Setup DMA 32B Work Message ======\n");


  ptr->dma_work_msg_32b.field0.BufDataLength = dma_get_BufDataLength(bufdatalen);

  ptr->dma_work_msg_32b.field0.DataAddr = dma_get_bufptrs_start_addr(dma_get_lendata(ptr->dma_work_msg_32b.field0.BufDataLength));

//  ptr->dma_work_msg_32b.field0.DataAddr = 0x1D000000;
  ptr->dma_work_msg_32b.field0.FPQNum = (DMA_QM_ID << 10) | fpqnum;
//  ptr->dma_work_msg_32b.field0.FPQNum =  0x03000000 ;

  ptr->dma_work_msg_32b.field0.UserInfo = 0xbabacafe;
  ptr->dma_work_msg_32b.field0.PB = pb;
  ptr->dma_work_msg_32b.field0.HB = hb;
  ptr->dma_work_msg_32b.field0.ELErr = 0;
  ptr->dma_work_msg_32b.field0.LErr = 0;
  ptr->dma_work_msg_32b.field1.transfer.HFPSel = hfpsel;
  ptr->dma_work_msg_32b.field1.transfer.HEnqNum = (DMA_QM_ID << 10) | henqnum;


  print("======================================\n");
}


void dma_setup_msg_32b_dif(int fpqnum, int henqnum, int hfpsel, int bufdatalen, int bufaddr, int pb, int hb, dma_work_msg_32b_ptr ptr)
{
  unsigned char blk_num,bufsize;
  unsigned int  datalen,Bufdatalength;

  print("\n=====Setup DMA 32B Work Message ======\n");

  do {

    bufsize = (unsigned char)random()%5;

  } while(dma_get_bufsize(bufsize) < dma_get_blksize(ptr->dma_work_msg_32b.field1.dif.BlkSize));


  if(DMA_RAND) blk_num = (unsigned char)random()%(dma_get_bufsize(bufsize) / dma_get_blksize(ptr->dma_work_msg_32b.field1.dif.BlkSize)) + 1;
  else blk_num = bufdatalen / dma_get_blksize(ptr->dma_work_msg_32b.field1.dif.BlkSize);

  if(ptr->dma_work_msg_32b.field1.dif.CTL>>2) {
    datalen = blk_num*dma_get_blksize(ptr->dma_work_msg_32b.field1.dif.BlkSize) + blk_num*8;
  } else {
    datalen = blk_num*dma_get_blksize(ptr->dma_work_msg_32b.field1.dif.BlkSize);
  }

  if(bufsize == 1)      Bufdatalength = 0x6000 | (datalen & 0x03FF);
  else if(bufsize == 2) Bufdatalength = 0x5000 | (datalen & 0x07FF);
  else if(bufsize == 3) Bufdatalength = 0x4000 | (datalen & 0x0FFF);
  else if(bufsize == 4) Bufdatalength = 0x0000 | (datalen & 0x3FFF);

  ptr->dma_work_msg_32b.field0.BufDataLength = Bufdatalength;
  ptr->dma_work_msg_32b.field0.DataAddr = dma_get_bufptrs_start_addr(dma_get_lendata(ptr->dma_work_msg_32b.field0.BufDataLength));
  ptr->dma_work_msg_32b.field0.FPQNum = (DMA_QM_ID << 10) | fpqnum;
  ptr->dma_work_msg_32b.field0.UserInfo = 0xbabacafe;
  ptr->dma_work_msg_32b.field0.PB = pb;
  ptr->dma_work_msg_32b.field0.HB = hb;
  ptr->dma_work_msg_32b.field0.ELErr = 0;
  ptr->dma_work_msg_32b.field0.LErr = 0;
  ptr->dma_work_msg_32b.field1.transfer.HFPSel = hfpsel;
  ptr->dma_work_msg_32b.field1.transfer.HEnqNum = (DMA_QM_ID << 10) | henqnum;
  print("======================================\n");
}

void dma_setup_msg_64b(int fpqnum, int henqnum, int hfpsel, int bufdatalen, int bufaddr, int pb, int hb, dma_work_msg_64b_ptr ptr)
{
  print("\n=====Setup DMA 64B Work Message ======\n");

  ptr->dma_work_msg_64b.field0.BufDataLength = dma_get_BufDataLength(bufdatalen);
  ptr->dma_work_msg_64b.field0.DataAddr = dma_get_bufptrs_start_addr(dma_get_lendata(ptr->dma_work_msg_64b.field0.BufDataLength));

  ptr->dma_work_msg_64b.field2.NxtBufDataLength1 = dma_get_BufDataLength(bufdatalen);
  ptr->dma_work_msg_64b.field2.NxtDataAddr1 = dma_get_bufptrs_start_addr(dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength1));

  ptr->dma_work_msg_64b.field2.NxtBufDataLength2 = dma_get_BufDataLength(bufdatalen);
  ptr->dma_work_msg_64b.field2.NxtDataAddr2 = dma_get_bufptrs_start_addr(dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength2));

  ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength3 = dma_get_BufDataLength(bufdatalen);
  ptr->dma_work_msg_64b.field3.normal.NxtDataAddr3 = dma_get_bufptrs_start_addr(dma_get_lendata(ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength3));

  ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength4 = dma_get_BufDataLength(bufdatalen);
  ptr->dma_work_msg_64b.field3.normal.NxtDataAddr4 = dma_get_bufptrs_start_addr(dma_get_lendata(ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength4));

  ptr->dma_work_msg_64b.field0.FPQNum = (DMA_QM_ID << 10) | fpqnum;
  ptr->dma_work_msg_64b.field0.UserInfo = 0xbabacafe;
  ptr->dma_work_msg_64b.field0.PB = pb;
  ptr->dma_work_msg_64b.field0.HB = hb;
  ptr->dma_work_msg_64b.field0.ELErr = 0;
  ptr->dma_work_msg_64b.field0.LErr = 0;
  ptr->dma_work_msg_64b.field0.NV = 1;
  ptr->dma_work_msg_64b.field1.transfer.HFPSel = hfpsel;
  ptr->dma_work_msg_64b.field1.transfer.HEnqNum = (DMA_QM_ID << 10) | henqnum;
  print("======================================\n");
}


void dma_setup_msg_64b_raid(int fpqnum, int henqnum, int hfpsel, int bufdatalen, int bufaddr, int pb, int hb, dma_work_msg_64b_ptr ptr)
{
  unsigned int BufDataLength;
  print("\n=====Setup DMA 64B Work Message ======\n");

  ptr->dma_work_msg_64b.field0.BufDataLength = dma_get_BufDataLength(bufdatalen);
  ptr->dma_work_msg_64b.field2.NxtBufDataLength1 = ptr->dma_work_msg_64b.field0.BufDataLength;
  ptr->dma_work_msg_64b.field2.NxtBufDataLength2 = ptr->dma_work_msg_64b.field0.BufDataLength;
  ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength3 = ptr->dma_work_msg_64b.field0.BufDataLength;
  ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength4 = ptr->dma_work_msg_64b.field0.BufDataLength;

  BufDataLength = dma_get_lendata(ptr->dma_work_msg_64b.field0.BufDataLength);

//  if(BufDataLength & 0x3F) {
//    BufDataLength = BufDataLength >> 6;
//    BufDataLength++;
//    BufDataLength = BufDataLength << 6;
//  }

  if(BufDataLength & 0x7F) {
    BufDataLength = BufDataLength >> 7;
    BufDataLength++;
    BufDataLength = BufDataLength << 7;
  }



  ptr->dma_work_msg_64b.field0.DataAddr = dma_get_bufptrs_start_addr(BufDataLength);//dma_get_lendata(ptr->dma_work_msg_64b.field0.BufDataLength));
  ptr->dma_work_msg_64b.field2.NxtDataAddr1 = dma_get_bufptrs_start_addr(BufDataLength);//dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength1));
  ptr->dma_work_msg_64b.field2.NxtDataAddr2 = dma_get_bufptrs_start_addr(BufDataLength);//dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength2));
  ptr->dma_work_msg_64b.field3.normal.NxtDataAddr3 = dma_get_bufptrs_start_addr(BufDataLength);//dma_get_lendata(ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength3));


  ptr->dma_work_msg_64b.field3.normal.NxtDataAddr4 = dma_get_bufptrs_start_addr(dma_get_lendata(ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength4));

  ptr->dma_work_msg_64b.field0.FPQNum = (DMA_QM_ID << 10) | fpqnum;
  ptr->dma_work_msg_64b.field0.UserInfo = 0xbabacafe;
  ptr->dma_work_msg_64b.field0.PB = pb;
  ptr->dma_work_msg_64b.field0.HB = hb;
  ptr->dma_work_msg_64b.field0.ELErr = 0;
  ptr->dma_work_msg_64b.field0.LErr = 0;
  ptr->dma_work_msg_64b.field0.NV = 1;
  ptr->dma_work_msg_64b.field1.transfer.HFPSel = hfpsel;
  ptr->dma_work_msg_64b.field1.transfer.HEnqNum = (DMA_QM_ID << 10) | henqnum;
  print("======================================\n");
}

void dma_setup_msg_64b_ll(int fpqnum, int henqnum, int hfpsel, int bufdatalen, int bufaddr, int pb, int hb, dma_work_msg_64b_ptr ptr)
{
  print("\n=====Setup DMA 64B Work Message ======\n");

  ptr->dma_work_msg_64b.field0.BufDataLength = dma_get_BufDataLength(bufdatalen);
  ptr->dma_work_msg_64b.field0.DataAddr = dma_get_bufptrs_start_addr(dma_get_lendata(ptr->dma_work_msg_64b.field0.BufDataLength));

  ptr->dma_work_msg_64b.field2.NxtBufDataLength1 = dma_get_BufDataLength(bufdatalen);
  ptr->dma_work_msg_64b.field2.NxtDataAddr1 = dma_get_bufptrs_start_addr(dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength1));

  ptr->dma_work_msg_64b.field2.NxtBufDataLength2 = dma_get_BufDataLength(bufdatalen);
  ptr->dma_work_msg_64b.field2.NxtDataAddr2 = dma_get_bufptrs_start_addr(dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength2));

  ptr->dma_work_msg_64b.field3.linklist.NxtBufDataLength3 = dma_get_BufDataLength(bufdatalen);
  ptr->dma_work_msg_64b.field3.linklist.NxtDataAddr3 = dma_get_bufptrs_start_addr(dma_get_lendata(ptr->dma_work_msg_64b.field3.linklist.NxtBufDataLength3));

  ptr->dma_work_msg_64b.field0.FPQNum = (DMA_QM_ID << 10) | fpqnum;
  ptr->dma_work_msg_64b.field0.UserInfo = 0xbabacafe;
  ptr->dma_work_msg_64b.field0.PB = pb;
  ptr->dma_work_msg_64b.field0.HB = hb;
  ptr->dma_work_msg_64b.field0.ELErr = 0;
  ptr->dma_work_msg_64b.field0.LErr = 0;
  ptr->dma_work_msg_64b.field0.NV = 1;
  ptr->dma_work_msg_64b.field0.LL = 1;
  ptr->dma_work_msg_64b.field1.transfer.HFPSel = hfpsel;
  ptr->dma_work_msg_64b.field1.transfer.HEnqNum = (DMA_QM_ID << 10) | henqnum;


  print("======================================\n");
}

void dma_setup_msg_64b_dif(int fpqnum, int henqnum, int hfpsel, int bufdatalen, int bufaddr, int pb, int hb, dma_work_msg_64b_ptr ptr)
{
  int Bufdatalength;
  unsigned char bufsize;
  print("\n=====Setup DMA 64B Work Message ======\n");

  if(ptr->dma_work_msg_64b.field1.dif.CTL>>2) { // CHECK

    do {

      bufsize = (unsigned char)random()%5;

    } while(dma_get_bufsize(bufsize) < dma_get_blksize(ptr->dma_work_msg_64b.field1.dif.BlkSize));

    if(bufsize == 1)      Bufdatalength = 0x6000 | (dma_get_blksize(ptr->dma_work_msg_64b.field1.dif.BlkSize & 0x03FF));
    else if(bufsize == 2) Bufdatalength = 0x5000 | (dma_get_blksize(ptr->dma_work_msg_64b.field1.dif.BlkSize & 0x07FF));
    else if(bufsize == 3) Bufdatalength = 0x4000 | (dma_get_blksize(ptr->dma_work_msg_64b.field1.dif.BlkSize & 0x0FFF));
    else if(bufsize == 4) Bufdatalength = 0x0000 | (dma_get_blksize(ptr->dma_work_msg_64b.field1.dif.BlkSize & 0x3FFF));

    ptr->dma_work_msg_64b.field0.BufDataLength = Bufdatalength;
    ptr->dma_work_msg_64b.field0.DataAddr = dma_get_bufptrs_start_addr(dma_get_lendata(ptr->dma_work_msg_64b.field0.BufDataLength));

    ptr->dma_work_msg_64b.field2.NxtBufDataLength1 = 0x5000|0x8;
    ptr->dma_work_msg_64b.field2.NxtDataAddr1 = dma_get_bufptrs_start_addr(dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength1));

    ptr->dma_work_msg_64b.field2.NxtBufDataLength2 = ptr->dma_work_msg_64b.field0.BufDataLength;
    ptr->dma_work_msg_64b.field2.NxtDataAddr2 = dma_get_bufptrs_start_addr(dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength2));

    ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength3 = 0x5000|0x8;
    ptr->dma_work_msg_64b.field3.normal.NxtDataAddr3 = dma_get_bufptrs_start_addr(dma_get_lendata(ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength3));

    ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength4 = 0x7800;
    ptr->dma_work_msg_64b.field3.normal.NxtDataAddr4 = dma_get_bufptrs_start_addr(dma_get_lendata(ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength4));

  } else {

    ptr->dma_work_msg_64b.field0.BufDataLength = dma_get_gather_dif_BufDataLength(bufdatalen, ptr);
    ptr->dma_work_msg_64b.field0.DataAddr = dma_get_bufptrs_start_addr(dma_get_lendata(ptr->dma_work_msg_64b.field0.BufDataLength));

    ptr->dma_work_msg_64b.field2.NxtBufDataLength1 = dma_get_gather_dif_BufDataLength(bufdatalen, ptr);
    ptr->dma_work_msg_64b.field2.NxtDataAddr1 = dma_get_bufptrs_start_addr(dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength1));

    ptr->dma_work_msg_64b.field2.NxtBufDataLength2 = dma_get_gather_dif_BufDataLength(bufdatalen, ptr);
    ptr->dma_work_msg_64b.field2.NxtDataAddr2 = dma_get_bufptrs_start_addr(dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength2));

    ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength3 = dma_get_gather_dif_BufDataLength(bufdatalen, ptr);
    ptr->dma_work_msg_64b.field3.normal.NxtDataAddr3 = dma_get_bufptrs_start_addr(dma_get_lendata(ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength3));

    ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength4 = dma_get_gather_dif_BufDataLength(bufdatalen, ptr);
    ptr->dma_work_msg_64b.field3.normal.NxtDataAddr4 = dma_get_bufptrs_start_addr(dma_get_lendata(ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength4));

  }
  ptr->dma_work_msg_64b.field0.FPQNum = (DMA_QM_ID << 10) | fpqnum;
  ptr->dma_work_msg_64b.field0.UserInfo = 0xbabacafe;
  ptr->dma_work_msg_64b.field0.PB = pb;
  ptr->dma_work_msg_64b.field0.HB = hb;
  ptr->dma_work_msg_64b.field0.ELErr = 0;
  ptr->dma_work_msg_64b.field0.LErr = 0;
  ptr->dma_work_msg_64b.field0.NV = 1;
  ptr->dma_work_msg_64b.field1.transfer.HFPSel = hfpsel;
  ptr->dma_work_msg_64b.field1.transfer.HEnqNum = (DMA_QM_ID << 10) | henqnum;
  print("======================================\n");
}

void dma_set_copy_memdest_msg_32b(dma_work_msg_32b_ptr ptr)
{
  print("\n=====Set Copy Memdest======\n");
  ptr->dma_work_msg_32b.field1.transfer.DR = 1;
  ptr->dma_work_msg_32b.field1.transfer.HR = 0;
  ptr->dma_work_msg_32b.field1.transfer.CTL = 0;
  ptr->dma_work_msg_32b.field1.transfer.FBY = 0;
  ptr->dma_work_msg_32b.field0.C = 0x1;
  ptr->dma_work_msg_32b.field1.transfer.DestAddress = dma_get_bufptrs_start_addr(dma_get_lendata(ptr->dma_work_msg_32b.field0.BufDataLength)); // dst add
  ptr->dma_work_msg_32b.field1.transfer.Rsvd3 =0x0;

  print("===============================\n");
}


void dma_set_copy_memdest_msg_32b_ocm(dma_work_msg_32b_ptr ptr)
{
  print("\n=====Set Copy Memdest======\n");
  ptr->dma_work_msg_32b.field1.transfer.DR = 1;
  ptr->dma_work_msg_32b.field1.transfer.HR = 0;
  ptr->dma_work_msg_32b.field1.transfer.CTL = 0;
  ptr->dma_work_msg_32b.field1.transfer.FBY = 0;
  ptr->dma_work_msg_32b.field0.C = 0x1;
  ptr->dma_work_msg_32b.field1.transfer.DestAddress = dma_get_bufptrs_start_addr_ocm(dma_get_lendata(ptr->dma_work_msg_32b.field0.BufDataLength)); // dst add
//  ptr->dma_work_msg_32b.field1.transfer.DestAddress = 0x1d010000;

  print("===============================\n");
}


void dma_set_copy_bufdest_msg_32b(dma_work_msg_32b_ptr ptr)
{
  print("\n=====Set Copy Bufdest======\n");
  ptr->dma_work_msg_32b.field1.transfer.DR = 0;
  ptr->dma_work_msg_32b.field1.transfer.HR = 0;                  //modified 1------------>0
  ptr->dma_work_msg_32b.field1.transfer.CTL = 1;
  ptr->dma_work_msg_32b.field1.transfer.FBY = 0;
  ptr->dma_work_msg_32b.field1.transfer.DestAddress = 0;	//Buffer
  print("===============================\n");
}

void dma_set_copy_dif_msg_32b(int BlkSize, int RefTag, int AppTag, int CTL, dma_work_msg_32b_ptr ptr, dma_dif_result_ptr ptr_dma_dif_result)
{
  print("\n=====Set Copy Insert DIF ======\n");

  ptr->dma_work_msg_32b.field1.dif.DR  = 0;
  ptr->dma_work_msg_32b.field1.dif.CTL = CTL;
  ptr->dma_work_msg_32b.field1.dif.FBY = 5;
  ptr->dma_work_msg_32b.field1.dif.BlkSize = BlkSize;
  ptr->dma_work_msg_32b.field1.dif.RefTag  = RefTag;
  ptr->dma_work_msg_32b.field1.dif.AppTag  = AppTag;
  ptr_dma_dif_result->dma_dif_result.AppTag = AppTag;
  ptr_dma_dif_result->dma_dif_result.RefTag = RefTag;
  print("===============================\n");
}

void dma_set_copy_bufdest_flyby_crc16_gen_msg_32b(int CTL, int FBY, int ByteCnt, dma_work_msg_32b_ptr ptr)
{
  print("\n=====Set Copy Bufdest Flyby CRC16 Generate ======\n");
  ptr->dma_work_msg_32b.field1.crc_chksum.DR   = 0;
  ptr->dma_work_msg_32b.field1.crc_chksum.CTL  = CTL;//bufdest
  ptr->dma_work_msg_32b.field1.crc_chksum.FBY  = FBY;
  ptr->dma_work_msg_32b.field1.flyby.Seed = 0x0000;
  ptr->dma_work_msg_32b.field1.crc_chksum.ByteCnt = ByteCnt;
//  ptr->dma_work_msg_32b.field1.flyby.HEnqNum  = 0;
//  ptr->dma_work_msg_32b.field1.flyby.HFPSel   = 0;
//  ptr->dma_work_msg_32b.field1.transfer.DestAddress = 0;	// dst add
  print(" CRC seed    : ");putnum(ptr->dma_work_msg_32b.field1.flyby.Seed);print("\n\r");
  print(" CRC ByteCnt : ");putnum(ptr->dma_work_msg_32b.field1.flyby.ByteCnt);print("\n\r");
  print(" FBY         : ");putnum(ptr->dma_work_msg_32b.field1.flyby.FBY);print("\n\r");
  print(" BD          : ");putnum(ptr->dma_work_msg_32b.field1.flyby.BD);print("\n\r");
  print(" CRC ByteCnt : ");putnum(ptr->dma_work_msg_32b.field1.flyby.ByteCnt);print("\n\r");
  print("===============================\n");
}

void dma_set_copy_bufdest_flyby_msg_32b(int CTL, int FBY, int ByteCnt, dma_work_msg_32b_ptr ptr)
{
  print("\n=====Set Copy Bufdest Flyby CRC16 Generate ======\n");
  ptr->dma_work_msg_32b.field1.crc_chksum.DR  = 0;
  ptr->dma_work_msg_32b.field1.crc_chksum.CTL = CTL;//bufdest
  ptr->dma_work_msg_32b.field1.crc_chksum.FBY  = FBY;
  ptr->dma_work_msg_32b.field1.crc_chksum.Seed = 0x0000;

  if(DMA_RAND) {
    if(FBY == 0x4) ptr->dma_work_msg_32b.field1.crc_chksum.ByteCnt = ((unsigned char)random()%(dma_get_lendata(ptr->dma_work_msg_32b.field0.BufDataLength)-2))+3; // CHKSUM
    else if(FBY == 0x1) ptr->dma_work_msg_32b.field1.crc_chksum.ByteCnt = ((unsigned char)random()%(dma_get_lendata(ptr->dma_work_msg_32b.field0.BufDataLength)-2))+1; // CRC16
    else ptr->dma_work_msg_32b.field1.crc_chksum.ByteCnt = ((unsigned char)random()%(dma_get_lendata(ptr->dma_work_msg_32b.field0.BufDataLength)-4))+1;
  }
  else ptr->dma_work_msg_32b.field1.crc_chksum.ByteCnt = ByteCnt;

//  print(" CRC/ChkSum seed    : ");putnum(ptr->dma_work_msg_32b.field1.crc_chksum.Seed);print("\n\r");
  print(" CRC/Chksum ByteCnt : ");putnum(ptr->dma_work_msg_32b.field1.crc_chksum.ByteCnt);print("\n\r");
  print(" FBY         : ");putnum(ptr->dma_work_msg_32b.field1.crc_chksum.FBY);print("\n\r");
  print(" BD          : ");putnum(ptr->dma_work_msg_32b.field1.flyby.BD);print("\n\r");
  print(" CRC ByteCnt : ");putnum(ptr->dma_work_msg_32b.field1.crc_chksum.ByteCnt);print("\n\r");
  print("===============================\n");
}
void dma_set_copy_memdest_striding_msg_32b(int SrcStridingSize, int SrcDistance, int DstStridingSize, int DstDistance, dma_work_msg_32b_ptr ptr)
{
  print("\n=====Set Copy Memedest With Striding ======\n");
  ptr->dma_work_msg_32b.field1.transfer.DR = 1;
  ptr->dma_work_msg_32b.field1.transfer.CTL = 8;
  ptr->dma_work_msg_32b.field1.transfer.FBY = 0;

  ptr->dma_work_msg_32b.field1.transfer.SrcStridingSize = SrcStridingSize;
  ptr->dma_work_msg_32b.field1.transfer.SrcDistance = SrcDistance;
  ptr->dma_work_msg_32b.field1.transfer.DstStridingSize = DstStridingSize;
  ptr->dma_work_msg_32b.field1.transfer.DstDistance = DstDistance;

  ptr->dma_work_msg_32b.field1.transfer.DestAddress = dma_get_bufptrs_start_addr(dma_get_lendata(ptr->dma_work_msg_32b.field0.BufDataLength)); // dst add
  print("===============================\n");
}
void dma_set_gather_memdest_64b(dma_work_msg_64b_ptr ptr)
{
  print("\n=====Set Gather Memdest======\n");
  ptr->dma_work_msg_64b.field1.transfer.DR = 1;
  ptr->dma_work_msg_64b.field1.transfer.CTL = 0;
  ptr->dma_work_msg_64b.field1.transfer.FBY = 0;
  ptr->dma_work_msg_64b.field1.transfer.DestAddress =	dma_get_bufptrs_start_addr(dma_get_lendata(ptr->dma_work_msg_64b.field0.BufDataLength)+
														dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength1)+
														dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength2)+
														dma_get_lendata(ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength3)+
														dma_get_lendata(ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength4));
  print("===============================\n");
}

void dma_set_flyby_raid_64b(unsigned int FBY, unsigned char Multi0, unsigned char Multi1, unsigned char Multi2, unsigned char Multi3, unsigned char Multi4, dma_work_msg_64b_ptr ptr)
{
  print("\n=====Set FLYBY RAID ======\n");
  ptr->dma_work_msg_64b.field1.raid.DR = 0;
  ptr->dma_work_msg_64b.field1.raid.HR = 0;   // modified 1------>0 05Mar13 !!!!!!!!IMPORTANT
  ptr->dma_work_msg_64b.field1.raid.CTL = 1;
  ptr->dma_work_msg_64b.field1.raid.FBY = FBY;

  ptr->dma_work_msg_64b.field1.raid.Multi0 = Multi0;
  ptr->dma_work_msg_64b.field1.raid.Multi1 = Multi1;
  ptr->dma_work_msg_64b.field1.raid.Multi2 = Multi2;
  ptr->dma_work_msg_64b.field1.raid.Multi3 = Multi3;
  ptr->dma_work_msg_64b.field1.raid.Multi4 = Multi4;

  if(FBY == 0x8) { // XOR 2 SOURCES
    ptr->dma_work_msg_64b.field2.NxtBufDataLength2 = 0x7800;
    ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength3 = 0x7800;
    ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength4 = 0x7800;
  } else if(FBY == 0x9) { // XOR 3 SOURCES
    ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength3 = 0x7800;
    ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength4 = 0x7800;
  } else if(FBY == 0xA) { // XOR 4 SOURCES
    ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength4 = 0x7800;
  }

  ptr->dma_work_msg_64b.field1.raid.DestAddress = 0;//BUFPTRS_START_ADDR + dma_qm_get_allocated_fptr_num(2048);	// dst add
  print("===============================\n");
}


void dma_set_gather_bufdest_msg_64b(dma_work_msg_64b_ptr ptr)
{
  print("\n=====Set Gather Bufdest======\n");
  ptr->dma_work_msg_64b.field1.transfer.DR = 0;
  ptr->dma_work_msg_64b.field1.transfer.CTL = 1;
  ptr->dma_work_msg_64b.field1.transfer.FBY = 0;
  ptr->dma_work_msg_64b.field1.transfer.DestAddress =0;	// Buffer
  print("===============================\n");
}

void dma_set_gather_dif_msg_64b(int BlkSize, int RefTag, int AppTag, int CTL, dma_work_msg_64b_ptr ptr, dma_dif_result_ptr ptr_dma_dif_result)
{
  print("\n=====Set Gather Insert DIF======\n");
  ptr->dma_work_msg_64b.field1.dif.DR  = 0;
  ptr->dma_work_msg_64b.field1.dif.CTL = CTL;
  ptr->dma_work_msg_64b.field1.dif.FBY = 5;
  ptr->dma_work_msg_64b.field1.dif.BlkSize = BlkSize;
  ptr->dma_work_msg_64b.field1.dif.RefTag  = RefTag;
  ptr->dma_work_msg_64b.field1.dif.AppTag  = AppTag;
  ptr_dma_dif_result->dma_dif_result.AppTag = AppTag;
  ptr_dma_dif_result->dma_dif_result.RefTag = RefTag;
  print("===============================\n");
}

void dma_set_gather_memdest_striding_msg_64b(int SrcStridingSize, int SrcDistance, int DstStridingSize, int DstDistance, dma_work_msg_64b_ptr ptr)
{
  print("\n=====Set Gather Memedest With Striding ======\n");
  ptr->dma_work_msg_64b.field1.transfer.DR = 1;
  ptr->dma_work_msg_64b.field1.transfer.CTL = 8;
  ptr->dma_work_msg_64b.field1.transfer.FBY = 0;
  ptr->dma_work_msg_64b.field1.transfer.SrcStridingSize = SrcStridingSize;
  ptr->dma_work_msg_64b.field1.transfer.SrcDistance = SrcDistance;
  ptr->dma_work_msg_64b.field1.transfer.DstStridingSize = DstStridingSize;
  ptr->dma_work_msg_64b.field1.transfer.DstDistance = DstDistance;
  ptr->dma_work_msg_64b.field1.transfer.DestAddress = dma_get_bufptrs_start_addr(dma_get_lendata(ptr->dma_work_msg_64b.field0.BufDataLength)+
										 dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength1)+
										 dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength2)+
										 dma_get_lendata(ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength3)+
										 dma_get_lendata(ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength4));
  print("===============================\n");
}
void dma_set_scatter_memdest_msg_striding_32b(int SrcStridingSize, int SrcDistance, int DstStridingSize, int DstDistance, dma_work_msg_32b_ptr ptr, dma_params_ptr dma_params)
{
  unsigned long long PtrDestLL;
  unsigned int DataLength;

  DataLength = dma_get_lendata(ptr->dma_work_msg_32b.field0.BufDataLength);
  print("\n=====Set Scatter Memedest With Striding ======\n");
  ptr->dma_work_msg_32b.field1.transfer.DR = 0;
  ptr->dma_work_msg_32b.field1.transfer.CTL = 8;
  ptr->dma_work_msg_32b.field1.transfer.FBY = 0;
  ptr->dma_work_msg_32b.field1.transfer.SrcStridingSize = SrcStridingSize;
  ptr->dma_work_msg_32b.field1.transfer.SrcDistance = SrcDistance;
  ptr->dma_work_msg_32b.field1.transfer.DstStridingSize = DstStridingSize;
  ptr->dma_work_msg_32b.field1.transfer.DstDistance = DstDistance;
  PtrDestLL = dma_get_bufptrs_start_addr(dma_get_lendata(0x7000)); // 256B
  PtrDestLL = PtrDestLL >> 4;
  PtrDestLL++;
  ptr->dma_work_msg_32b.field1.transfer_dest_ll.PtrDestLL = PtrDestLL;	// dst add
  ptr->dma_work_msg_32b.field1.transfer_dest_ll.LinkSize = 5;
  dma_build_dest_linklist(PtrDestLL<<4,5,DataLength,dma_params);
  print("===============================\n");
}

void dma_set_scatter_memdest_msg_32b(dma_work_msg_32b_ptr ptr, dma_params_ptr dma_params)
{
  unsigned long long PtrDestLL;
  unsigned int DataLength;

  DataLength = dma_get_lendata(ptr->dma_work_msg_32b.field0.BufDataLength);
  print("\n=====Set Scatter Memedest With Striding ======\n");
  ptr->dma_work_msg_32b.field1.transfer.DR = 0;
  ptr->dma_work_msg_32b.field1.transfer.CTL = 0;
  ptr->dma_work_msg_32b.field1.transfer.FBY = 0;
  PtrDestLL = dma_get_bufptrs_start_addr(dma_get_lendata(0x0000)); // 256B
  PtrDestLL = PtrDestLL >> 4;
  PtrDestLL++;
  ptr->dma_work_msg_32b.field1.transfer_dest_ll.PtrDestLL = PtrDestLL;	// dst add
  ptr->dma_work_msg_32b.field1.transfer_dest_ll.LinkSize = 16;
  printf("Datalength =0x%08x\n",DataLength);
  printf("PtrDestLL = 0x%08x\n",PtrDestLL);
  dma_build_dest_linklist(PtrDestLL<<4,16,DataLength,dma_params);
  print("===============================\n");
}

void dma_set_gather_ll_memdest_msg_64b(dma_work_msg_64b_ptr ptr, dma_params_ptr dma_params, unsigned int Linksize, unsigned int bufferlen)
{
  unsigned long long PtrSrcLL;
//  PtrSrcLL = dma_get_bufptrs_start_addr(dma_get_lendata(0x7000)); // 256B
  PtrSrcLL = dma_get_bufptrs_start_addr(dma_get_lendata(0x0000)); // 16K
  print("PtrSrcLL:");putnum(PtrSrcLL);print("\n");
  print("\n=====Set Gather LL Memedest ======\n");
  ptr->dma_work_msg_64b.field1.transfer.DR = 1;
  ptr->dma_work_msg_64b.field1.transfer.CTL = 0;
  ptr->dma_work_msg_64b.field1.transfer.FBY = 0;
  ptr->dma_work_msg_64b.field3.linklist.Ptr2SrcList = PtrSrcLL;	// dst add
//  ptr->dma_work_msg_64b.field3.linklist.LinkSize = 3; // 7 Source
  ptr->dma_work_msg_64b.field3.linklist.LinkSize = Linksize; // 256 Source

  if(PtrSrcLL & 0xF) {
  PtrSrcLL = PtrSrcLL>>4;
  PtrSrcLL++;
  PtrSrcLL = PtrSrcLL<<4;
  print("PtrSrcLL:");putnum(PtrSrcLL);print("\n");
  }
  //ptr->dma_work_msg_64b.field3.linklist.Ptr2SrcList = PtrSrcLL;	// dst add
//  dma_build_src_linklist(PtrSrcLL,3,128, ptr, dma_params);
  dma_build_src_linklist(PtrSrcLL,Linksize,bufferlen, ptr, dma_params);
  ptr->dma_work_msg_64b.field1.transfer.DestAddress = dma_get_bufptrs_start_addr(dma_get_lendata(ptr->dma_work_msg_64b.field0.BufDataLength)+
										 dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength1)+
										 dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength2)+
										 dma_get_lendata(ptr->dma_work_msg_64b.field3.linklist.NxtBufDataLength3)+ptr->dma_work_msg_64b.field1.transfer.TotDataLengthLinkListLSBs);

  printf("Total length Link list: %x\n",ptr->dma_work_msg_64b.field1.transfer.TotDataLengthLinkListLSBs);
  // Get information
  dma_params->src[0] = ptr->dma_work_msg_64b.field0.DataAddr;
  dma_params->len_src[0] = dma_get_lendata(ptr->dma_work_msg_64b.field0.BufDataLength);

  dma_params->src[1] = ptr->dma_work_msg_64b.field2.NxtDataAddr1;
  dma_params->len_src[1] = dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength1);

  dma_params->src[2] = ptr->dma_work_msg_64b.field2.NxtDataAddr2;
  dma_params->len_src[2] = dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength2);

  dma_params->src[3] = ptr->dma_work_msg_64b.field3.linklist.NxtDataAddr3 ;
  dma_params->len_src[3] = dma_get_lendata(ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength3);
  print("===============================\n");
}

void dma_set_gather_ll_bufdest_msg_64b(dma_work_msg_64b_ptr ptr, dma_params_ptr dma_params, unsigned int Linksize, unsigned int bufferlen )
{
  unsigned long long PtrSrcLL;
//  PtrSrcLL = dma_get_bufptrs_start_addr(dma_get_lendata(0x7000)); // 256B
  PtrSrcLL = dma_get_bufptrs_start_addr(dma_get_lendata(0x0000)); // 16K
  print("PtrSrcLL:");putnum(PtrSrcLL);print("\n");
  print("\n=====Set Gather LL Memedest ======\n");
  ptr->dma_work_msg_64b.field1.transfer.DR = 0;
  ptr->dma_work_msg_64b.field1.transfer.CTL = 1;
  ptr->dma_work_msg_64b.field1.transfer.FBY = 0;
  ptr->dma_work_msg_64b.field3.linklist.Ptr2SrcList = PtrSrcLL;	// dst add
//  ptr->dma_work_msg_64b.field3.linklist.LinkSize = 3; // 7 Source
  ptr->dma_work_msg_64b.field3.linklist.LinkSize = Linksize; // 256 Source

  if(PtrSrcLL & 0xF) {
  PtrSrcLL = PtrSrcLL>>4;
  PtrSrcLL++;
  PtrSrcLL = PtrSrcLL<<4;
  print("PtrSrcLL:");putnum(PtrSrcLL);print("\n");
  }
  //ptr->dma_work_msg_64b.field3.linklist.Ptr2SrcList = PtrSrcLL;	// dst add
//  dma_build_src_linklist(PtrSrcLL,3,128, ptr, dma_params);
  dma_build_src_linklist(PtrSrcLL,Linksize,bufferlen, ptr, dma_params);
  ptr->dma_work_msg_64b.field1.transfer.DestAddress =0;
  printf("Total length Link list: %x\n",ptr->dma_work_msg_64b.field1.transfer.TotDataLengthLinkListLSBs);
  // Get information
  dma_params->src[0] = ptr->dma_work_msg_64b.field0.DataAddr;
  dma_params->len_src[0] = dma_get_lendata(ptr->dma_work_msg_64b.field0.BufDataLength);

  dma_params->src[1] = ptr->dma_work_msg_64b.field2.NxtDataAddr1;
  dma_params->len_src[1] = dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength1);

  dma_params->src[2] = ptr->dma_work_msg_64b.field2.NxtDataAddr2;
  dma_params->len_src[2] = dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength2);

  dma_params->src[3] = ptr->dma_work_msg_64b.field3.linklist.NxtDataAddr3 ;
  dma_params->len_src[3] = dma_get_lendata(ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength3);

  print("===============================\n");
}


void dma_set_gather_scatter_memdest_64b(dma_work_msg_64b_ptr ptr, dma_params_ptr dma_params)
{
  unsigned long long PtrDestLL;
  unsigned int DataLength;

  DataLength = (dma_get_lendata(ptr->dma_work_msg_64b.field0.BufDataLength) +
		dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength1) +
		dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength2) +
		dma_get_lendata(ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength3) + dma_get_lendata(ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength4));
  print("\n=====Set Gather Scatter Memdest======\n");
  ptr->dma_work_msg_64b.field1.transfer.DR = 0;
  ptr->dma_work_msg_64b.field1.transfer.CTL = 0;
  ptr->dma_work_msg_64b.field1.transfer.FBY = 0;
  PtrDestLL = dma_get_bufptrs_start_addr(dma_get_lendata(0x7000)); // 256B
  PtrDestLL = PtrDestLL >>4;
  PtrDestLL++;
  ptr->dma_work_msg_64b.field1.transfer_dest_ll.PtrDestLL = PtrDestLL;	// dst add
  ptr->dma_work_msg_64b.field1.transfer_dest_ll.LinkSize = 5;
  dma_build_dest_linklist(PtrDestLL<<4,5,DataLength,dma_params);
  print("===============================\n");
}
void dma_set_gather_scatter_memdest_striding_64b(int SrcStridingSize, int SrcDistance, int DstStridingSize, int DstDistance, dma_work_msg_64b_ptr ptr, dma_params_ptr dma_params)
{
  unsigned long long PtrDestLL;
  unsigned int DataLength;

  DataLength = (dma_get_lendata(ptr->dma_work_msg_64b.field0.BufDataLength) +
		dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength1) +
		dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength2) +
		dma_get_lendata(ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength3) + dma_get_lendata(ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength4));
  print("\n=====Set Gather Scatter Memdest======\n");
  ptr->dma_work_msg_64b.field1.transfer.DR = 0;
  ptr->dma_work_msg_64b.field1.transfer.CTL = 8;
  ptr->dma_work_msg_64b.field1.transfer.FBY = 0;
  ptr->dma_work_msg_64b.field1.transfer.SrcStridingSize = SrcStridingSize;
  ptr->dma_work_msg_64b.field1.transfer.SrcDistance = SrcDistance;
  ptr->dma_work_msg_64b.field1.transfer.DstStridingSize = DstStridingSize;
  ptr->dma_work_msg_64b.field1.transfer.DstDistance = DstDistance;
  PtrDestLL = dma_get_bufptrs_start_addr(dma_get_lendata(0x7000)); // 256B
  PtrDestLL = PtrDestLL >>4;
  PtrDestLL++;
  ptr->dma_work_msg_64b.field1.transfer_dest_ll.PtrDestLL = PtrDestLL;	// dst add
  ptr->dma_work_msg_64b.field1.transfer_dest_ll.LinkSize = 5;
  dma_build_dest_linklist(PtrDestLL<<4,5,DataLength,dma_params);
  print("===============================\n");
}
void dma_enqueue_msg_32b(int qid, dma_work_msg_32b_ptr ptr)
{
  int i;
  unsigned int alt_enq_addr;
  print("\n===== Enqueue DMA 32B work message to QM ======\n");
  for(i=0; i< 8; i++) {
    //print("ENG_PTR:");putnum(enq_ptr[qid]);print(" - QID : ");putnum(qid);print(" - ADDR:");putnum(OCM_BASE_ADDR);print("\n");
//    write((unsigned int *)(((OCM_BASE_ADDR + (0x800 * qid)) + enq_ptr[qid])|DMA_CPU_MEM_ACCESS_MASK), ptr->data[i]);
	  write((unsigned int *)(((OCM_BASE_ADDR + (0x800 * qid)) + enq_ptr[qid])|DMA_CPU_MEM_ACCESS_MASK), ptr->data[i]);

    enq_ptr[qid] += 4;
    if(enq_ptr[qid] == 0x800) enq_ptr[qid] = 0;
  // Alt enqueue command for QM
    dcache_flush_all();
  }
  alt_enq_addr = (DMA_CPU_MEM_ACCESS_MASK | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x2C);
  write((unsigned int *)alt_enq_addr, 0x1);
  print("=============================================\n");
}

void dma_enqueue_msg_64b(int qid, dma_work_msg_64b_ptr ptr)
{
  int i;
  unsigned int alt_enq_addr;
  print("\n===== Enqueue DMA 64B Work message to QM ======\n");
  for(i=0; i< 16; i++) {
    //print("ENG_PTR_:");putnum(enq_ptr[qid]);print(" - QID : ");putnum(qid);print(" - ADDR:");putnum(OCM_BASE_ADDR);print("\n");
    write((unsigned int *)(((OCM_BASE_ADDR + (0x800 * qid)) + enq_ptr[qid])|DMA_CPU_MEM_ACCESS_MASK), ptr->data[i]);

    enq_ptr[qid] += 4;
    if(enq_ptr[qid] == 0x800) enq_ptr[qid] = 0;
    dcache_flush_all();
  // Alt enqueue command for QM
  }
  alt_enq_addr = (DMA_CPU_MEM_ACCESS_MASK | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x2C);
  write((unsigned int *)alt_enq_addr, 0x2);  // Enqueue 3x32B to QM
  print("=============================================\n");
}
void dma_build_dest_linklist(unsigned long long dest_addr, int num_of_dest, int bufdatalen, dma_params_ptr dma_params)
{
  dma_ll_entries ll_entry;
  int num_ll,i,j,ll_index;
  unsigned long long ptr_dst_addr;
  unsigned int DataLength;

  DataLength = bufdatalen/num_of_dest;

  ll_index = 0;
  dma_params->num_dst = num_of_dest;
  ptr_dst_addr = (unsigned long long)(dest_addr) | DMA_CPU_MEM_ACCESS_MASK;
  if (num_of_dest % 2)
    num_ll = num_of_dest/2 +1;
  else
    num_ll = num_of_dest/2;

  	  printf("number of dest =%u\n",num_of_dest);
  	  printf("num_ll =%u\n",num_ll);
  	  printf("bufdatalen =0x%08x\n",bufdatalen);
  	  printf("DataLength =0x%08x\n",DataLength);
  for (i=0; i < num_ll; i++) {

    if ((num_of_dest % 2)  && (i == (num_ll - 1))){
    	printf("case 1: i =%u\n",i);
      ll_entry.ll.NxtBufDataLength1 = 0x0000|((DataLength+(bufdatalen%num_of_dest)) & 0x3FFF);
      ll_entry.ll.NxtDataAddr1 = dma_get_bufptrs_start_addr(dma_get_lendata(ll_entry.ll.NxtBufDataLength1));


    } else {
    	printf("case 2: i = %u\n",i);
      ll_entry.ll.NxtBufDataLength1 = 0x0000| (DataLength & 0x3FFF);
      ll_entry.ll.NxtDataAddr1 = dma_get_bufptrs_start_addr(dma_get_lendata(ll_entry.ll.NxtBufDataLength1));

    }
    dma_params->dst[ll_index] = ll_entry.ll.NxtDataAddr1;
    dma_params->len_dst[ll_index] = dma_get_lendata(ll_entry.ll.NxtBufDataLength1);

    ll_index++;

    if ((num_of_dest % 2)  && (i == (num_ll - 1))){
      // In case the number of linklist is odd, create empty buffer for the last entry
      ll_entry.ll.NxtBufDataLength2 = 0x7800;
      ll_entry.ll.NxtDataAddr2 = 0;
    }
    else {

      ll_entry.ll.NxtBufDataLength2 = 0x0000|(DataLength & 0x3FFF);
      ll_entry.ll.NxtDataAddr2 = dma_get_bufptrs_start_addr(dma_get_lendata(ll_entry.ll.NxtBufDataLength2));

      dma_params->dst[ll_index] = ll_entry.ll.NxtDataAddr2;
      dma_params->len_dst[ll_index] = dma_get_lendata(ll_entry.ll.NxtBufDataLength2);

      ll_index++;

    }

    for (j=0; j< 4; j++) {
      print("Pointer Dest LL ");putnum_64(ptr_dst_addr);print("\n\r");
      write((unsigned long long *)ptr_dst_addr,ll_entry.data[j]);
      ptr_dst_addr += 4;
    }

  }

}

void dma_build_src_linklist(unsigned long long src_addr, int num_of_src, int bufdatalen, dma_work_msg_64b_ptr ptr, dma_params_ptr dma_params)
{
  dma_ll_entries ll_entry;
  int num_ll,i,j,ll_index;
  unsigned long long ptr_src_addr;

  ll_index = 4;
  dma_params->num_src = 4 + num_of_src;
  ptr->dma_work_msg_64b.field1.transfer.TotDataLengthLinkListLSBs = 0;
  ptr_src_addr = (unsigned long long)(src_addr) ;
  if (num_of_src % 2)
    num_ll = num_of_src/2 +1;
  else
    num_ll = num_of_src/2;

  for (i=0; i < num_ll; i++) {

    ll_entry.ll.NxtBufDataLength1 = dma_get_BufDataLength(bufdatalen);
    ll_entry.ll.NxtDataAddr1 = dma_get_bufptrs_start_addr(dma_get_lendata(ll_entry.ll.NxtBufDataLength1));
    dma_params->src[ll_index] = ll_entry.ll.NxtDataAddr1;
    dma_params->len_src[ll_index] = dma_get_lendata(ll_entry.ll.NxtBufDataLength1);

    ptr->dma_work_msg_64b.field1.transfer.TotDataLengthLinkListLSBs += dma_get_lendata(ll_entry.ll.NxtBufDataLength1);

    ll_index++;
    if ((num_of_src % 2)  && (i == (num_ll - 1))){
      // In case the number of linklist is odd, create empty buffer for the last entry
      ll_entry.ll.NxtBufDataLength2 = 0x7800;
      ll_entry.ll.NxtDataAddr2 = 0;
    }
    else {

      ll_entry.ll.NxtBufDataLength2 = dma_get_BufDataLength(bufdatalen);
      ll_entry.ll.NxtDataAddr2 = dma_get_bufptrs_start_addr(dma_get_lendata(ll_entry.ll.NxtBufDataLength2));
      dma_params->src[ll_index] = ll_entry.ll.NxtDataAddr2;
      dma_params->len_src[ll_index] = dma_get_lendata(ll_entry.ll.NxtBufDataLength2);

      ptr->dma_work_msg_64b.field1.transfer.TotDataLengthLinkListLSBs += dma_get_lendata(ll_entry.ll.NxtBufDataLength2);

      ll_index++;
    }

    for (j=0; j< 4; j++) {
      print("Pointer Src LL ");putnum_64(ptr_src_addr);print("\n\r");
      write((unsigned long long *)ptr_src_addr,ll_entry.data[j]);
      ptr_src_addr += 4;
    }

  }
}

void poll_dma_queues_64b(int QID,dma_cmplt_msg_64b_ptr ptr)
{
  int intr_stat;

  // Poll Interrupt.
  intr_stat = qm_poll_deq_intr();

  // Dequeue Completion Message.
  dma_read_cmplt_msg_64b(QID,ptr);

}
void dma_init_enq_deq_ptr() {
  int i;
  for (i=0;i<16;i++) {
    deq_ptr[i] = 0;
    enq_ptr[i] = 0;
  }

  for (i=0;i<16;i++) {
     my_deq_ptr[i] = 0;
   }
}

void dma_read_cmplt_msg(int qid, dma_cmplt_msg_32b_ptr ptr) {
  int              i;//, rdata[8];
  int              alt_deq_addr;

  print("\n===== Read Completion Message ======\n");
  // 32 Byte message read
  for(i=0; i< 8; i++) {
        print("\n Dequeue ptr = "); putnum(deq_ptr[qid]);
    ptr->data[i] = read((unsigned int *)(((OCM_BASE_ADDR + (0x800 * qid)) + deq_ptr[qid])|DMA_CPU_MEM_ACCESS_MASK));

    //    ptr->data[i]=rdata[i];
    deq_ptr[qid] += 4;
    if(deq_ptr[qid] == 0x800) deq_ptr[qid] = 0;

    print("\n DMA Completion Message["); putnum(i); print("] = "); putnum(ptr->data[i]);
    print("\n\r");
  }

  alt_deq_addr = (DMA_CPU_MEM_ACCESS_MASK | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x2C);
  WRITE32(alt_deq_addr, 0xFFFFFFFF);

  print("============================\n");
}
void dma_read_cmplt_msg_64b(int qid, dma_cmplt_msg_64b_ptr ptr) {
  int              i;//, rdata[8];
  int              alt_deq_addr;

  print("\n===== Read 64B Completion Message ======\n");

  for(i=0; i< 8; i++) {
        print("\n Dequeue ptr = "); putnum(deq_ptr[qid]);
    ptr->data[i] = read((unsigned int *)(((OCM_BASE_ADDR + (0x800 * qid)) + deq_ptr[qid])|DMA_CPU_MEM_ACCESS_MASK));
    //    ptr->data[i]=rdata[i];
    deq_ptr[qid] += 4;
    if(deq_ptr[qid] == 0x800) deq_ptr[qid] = 0;
    print("\n DMA First 32B  Completion Message["); putnum(i); print("] = "); putnum(ptr->data[i]);
    print("\n\r");
  }


  if (ptr->dma_cmplt_msg_64b.field0.NV) {
    for(i=8; i< 16; i++) {
          print("\n Dequeue ptr = "); putnum(deq_ptr[qid]);
      ptr->data[i] = read((unsigned int *)(((OCM_BASE_ADDR + (0x800 * qid)) + deq_ptr[qid])|DMA_CPU_MEM_ACCESS_MASK));
      //    ptr->data[i]=rdata[i];
      deq_ptr[qid] += 4;
      print("\n DMA read next 32B Completion Message["); putnum(i); print("] = "); putnum(ptr->data[i]);
      print("\n\r");
    }

    alt_deq_addr = (DMA_CPU_MEM_ACCESS_MASK | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x2C);
    WRITE32(alt_deq_addr, 0xFFFFFFFE);
  }
  else {
    alt_deq_addr = (DMA_CPU_MEM_ACCESS_MASK | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x2C);
    WRITE32(alt_deq_addr, 0xFFFFFFFF);
  }
  print("============================\n");
}

void poll_dma_queues(int QID,dma_cmplt_msg_32b_ptr ptr)
{
  int intr_stat;

  // Poll Interrupt.
  intr_stat = qm_poll_deq_intr();


  // Dequeue Completion Message.
  dma_read_cmplt_msg(QID,ptr);


}

void dma_init_data(dma_work_msg_32b_ptr ptr) {
  unsigned char *ptr_src;
  int length,i;
  print("\n===== Init Data Phase ======\n");

  ptr_src  = (unsigned char *)(ptr->dma_work_msg_32b.field0.DataAddr);
  length = dma_get_lendata(ptr->dma_work_msg_32b.field0.BufDataLength);

  print("DDR Data Start Address:");putnum_64(ptr_src);print("\n\r");
  print("DDR Data Length:");putnum(length);print("\n\r");
  // Write DDR area (mimic'ed in OCM) with Data.
  for (i=0; i < length; i++) {

    if(DMA_RAND) ptr_src[i] = (unsigned char)random();
    else ptr_src[i] = (unsigned char)i;
//    print("Init data at the address = ");putnum(&ptr_src[i]);
//    print(" with data = ");putnum(ptr_src[i]);
//    print("\n\r");
  }
//  printf("Source\n");
//  mem_dump(ptr->dma_work_msg_32b.field0.DataAddr,length/4);

  print("========================================\n");
}

void dma_init_data_chk_dif(dma_work_msg_32b_ptr ptr, dma_dif_result_ptr ptr_dma_dif_result, char ErrSet) {
  unsigned char *ptr_src, dif_ins_enb;
  int length,i,j, nxt_addr,size;
  print("\n===== Init Data Check DIF Phase ======\n");

  j = 0;
  dif_ins_enb = 0;

  size     = dma_get_blksize(ptr->dma_work_msg_32b.field1.dif.BlkSize);
  ptr_src  = (unsigned char *)(ptr->dma_work_msg_32b.field0.DataAddr | DMA_CPU_MEM_ACCESS_MASK);
  length   = dma_get_lendata(ptr->dma_work_msg_32b.field0.BufDataLength); // To be updated
  nxt_addr = size;
  print("DDR Data Start Address:");putnum(ptr_src);print("\n\r");
  print("DDR Data Length:");putnum(length);print("\n\r");
  ptr_dma_dif_result->dma_dif_result.CRC = 0;
  // Write DDR area (mimic'ed in OCM) with Data.
  for (i=0; i < length; i++) {

    if(i == nxt_addr) {
      dif_ins_enb = 1;
    }

    if(dif_ins_enb == 0) {
      if(DMA_RAND) ptr_src[i] = (unsigned char)random();//i;
      else ptr_src[i] = (unsigned char)i;//i;
      ptr_dma_dif_result->dma_dif_result.CRC = get_crc16_seed(&ptr_src[i], 1, ptr_dma_dif_result->dma_dif_result.CRC);
      j = 0;
    } else {
      ptr_src[i] = (ErrSet&(i==size)) ? !(ptr_dma_dif_result->data[j]) : ptr_dma_dif_result->data[j];
      if(j == 7) {
	ptr_dma_dif_result->dma_dif_result.CRC = 0;
	ptr_dma_dif_result->dma_dif_result.RefTag++;
	nxt_addr = nxt_addr + size + 8;
	dif_ins_enb = 0;

	print("nxt_addr");putnum(nxt_addr);print("\n");
      }
      j++;
    }
    //print("Init data at the address = ");putnum(&ptr_src[i]);
    //print(" with data = ");putnum(ptr_src[i]);
    //print("\n\r");
  }
  print("========================================\n");

}
void dma_init_data_chksum(dma_work_msg_32b_ptr ptr, char ErrSet) {
  unsigned char *ptr_src, odd;
  unsigned short int tmp = 0;
  int length,len_cnt;
  unsigned int sum_dat=0;
  print("\n===== Init Data With Check Sum Phase ======\n");

  ptr_src = (unsigned char *)(ptr->dma_work_msg_32b.field0.DataAddr | DMA_CPU_MEM_ACCESS_MASK);
  length  = dma_get_lendata(ptr->dma_work_msg_32b.field0.BufDataLength); // To be updated

  print("DDR Data Start Address:");putnum(ptr_src);print("\n\r");
  print("DDR Data Length:");putnum(length);print("\n\r");
  // Write DDR area (mimic'ed in OCM) with Data.
  for (len_cnt = 2; len_cnt < length; len_cnt++) {

    if(DMA_RAND) ptr_src[len_cnt] = (unsigned char)random();//len_cnt - 2;
    else ptr_src[len_cnt] = (unsigned char)(len_cnt - 2);

    //print("Init data at the address = ");putnum(&ptr_src[len_cnt]);
    //print(" with data = ");putnum(ptr_src[len_cnt]);
    //print("\n\r");

    tmp = tmp << 8;
    tmp = tmp | ptr_src[len_cnt];

    odd = len_cnt & 0x01;
    if(len_cnt < (ptr->dma_work_msg_32b.field1.crc_chksum.ByteCnt)) {
      if(odd == 1) {
	sum_dat = sum_dat + tmp;
	print("SUM0:");putnum(sum_dat);print(" - DATA:");putnum(tmp);print("\n");
      }
      else if(len_cnt == (ptr->dma_work_msg_32b.field1.crc_chksum.ByteCnt-1)) {
	tmp = tmp << 8;
	sum_dat = sum_dat + tmp;
	print("SUM1:");putnum(sum_dat);print(" - DATA:");putnum(tmp);print("\n");
      }
    }
  }

  tmp = sum_dat >> 16;
  tmp+=(sum_dat&0xFFFF);
  tmp = tmp ^ 0xFFFF;
  print("CHECK SUM RESULT : ");putnum(tmp);print("\n");

  ptr_src[0] = tmp >> 0x8;
  ptr_src[1] = tmp & 0xFF;

  if (ErrSet) ptr_src[0] = ptr_src[0] ^ 0xFF;
  print("Init data at the address = ");putnum(&ptr_src[0]);
  print(" with data = ");putnum(ptr_src[0]);
  print("\n\r");

  print("Init data at the address = ");putnum(&ptr_src[1]);
  print(" with data = ");putnum(ptr_src[1]);
  print("\n\r");

  print("========================================\n");
}
void dma_init_data_crc(dma_work_msg_32b_ptr ptr, int ErrSet) {
  unsigned char *ptr_src;
  unsigned int length,i, crc_result;
  print("\n===== Init Data Phase ======\n");

  crc_result  = (ptr->dma_work_msg_32b.field1.crc_chksum.CTL&0x2) ? ptr->dma_work_msg_32b.field1.crc_chksum.Seed : ((ptr->dma_work_msg_32b.field1.crc_chksum.FBY == 0x1) ? 0 : 0xFFFFFFFF);
  ptr_src  = (unsigned char *)(ptr->dma_work_msg_32b.field0.DataAddr | DMA_CPU_MEM_ACCESS_MASK);
  length = dma_get_lendata(ptr->dma_work_msg_32b.field0.BufDataLength); // To be updated
//  print("DDR Data Start Address:");putnum(ptr_src);print("\n\r");
//  print("DDR Data Length:");putnum(length);print("\n\r");

  // Write DDR area (mimic'ed in OCM) with Data.
  for (i=0; i < length; i++) {

    if(i == ptr->dma_work_msg_32b.field1.crc_chksum.ByteCnt) {

      if (ptr->dma_work_msg_32b.field1.crc_chksum.FBY == 0x1)      crc_result = get_crc16_seed(ptr_src, ptr->dma_work_msg_32b.field1.crc_chksum.ByteCnt, crc_result);
      else if (ptr->dma_work_msg_32b.field1.crc_chksum.FBY == 0x2) crc_result = get_iscsi_crc32c_seed(ptr_src, ptr->dma_work_msg_32b.field1.crc_chksum.ByteCnt, crc_result);
      else if (ptr->dma_work_msg_32b.field1.crc_chksum.FBY == 0x3) crc_result = get_eth_crc32e_seed(ptr_src, ptr->dma_work_msg_32b.field1.crc_chksum.ByteCnt, crc_result);
      print("CRC_RESULT:");putnum(crc_result);print("\n");

      ptr_src[i] = crc_result & 0xFF;
      crc_result = crc_result >> 8;
    } else if (i==ptr->dma_work_msg_32b.field1.crc_chksum.ByteCnt+1) {
      ptr_src[i] = crc_result & 0xFF;
      crc_result = crc_result >> 8;
      if(ErrSet) ptr_src[i] = ptr_src[i]^0xFF;
    } else if((i==ptr->dma_work_msg_32b.field1.crc_chksum.ByteCnt+2)&(ptr->dma_work_msg_32b.field1.crc_chksum.FBY!=0x1)) {
      ptr_src[i] = crc_result & 0xFF;
      crc_result = crc_result >> 8;
    } else if((i==ptr->dma_work_msg_32b.field1.crc_chksum.ByteCnt+3)&(ptr->dma_work_msg_32b.field1.crc_chksum.FBY!=0x1)) {
      ptr_src[i] = crc_result & 0xFF;
      crc_result = crc_result >> 8;
    } else {

      if(DMA_RAND) ptr_src[i] = (unsigned char)random();//i;
      else  ptr_src[i] = (unsigned char)i;
    }

    //print("Init data at the address = ");putnum(&ptr_src[i]);
    //print(" with data = ");putnum(ptr_src[i]);
    //print("\n\r");

  }
  printf("Mem_dump source data\n");
//  mem_dump(ptr_src,length/4);
  print("========================================\n");
}
void dma_init_data_64b_msg(dma_work_msg_64b_ptr ptr) {
  unsigned char *ptr_src;
  int length,i;
  print("\n===== Init Data Phase ======\n");

 ptr_src  = (unsigned char *)(ptr->dma_work_msg_64b.field0.DataAddr | DMA_CPU_MEM_ACCESS_MASK);
  length = dma_get_lendata(ptr->dma_work_msg_64b.field0.BufDataLength); // To be updated
  print("DDR Data Start Address:");putnum(ptr_src);print("\n\r");
  print("DDR Data Length:");putnum(length);print("\n\r");
  for (i=0; i < length; i++) {

    if(DMA_RAND) ptr_src[i] = (unsigned char)random();
    else ptr_src[i] = (unsigned char)i;
//    print("Init data at the address = ");putnum(&ptr_src[i]);
//    print(" with data = ");putnum(ptr_src[i]);
//    print("\n\r");
  }

//  printf("Mem_dump source data\n");
//  mem_dump(ptr_src,length/4);

  ptr_src  = (unsigned char *)(ptr->dma_work_msg_64b.field2.NxtDataAddr1 | DMA_CPU_MEM_ACCESS_MASK);
  length = dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength1); // To be updated
  print("DDR Data Start Address:");putnum(ptr_src);print("\n\r");
  print("DDR Data Length:");putnum(length);print("\n\r");
  for (i=0; i < length; i++) {

    if(DMA_RAND) ptr_src[i] = (unsigned char)random();
    else ptr_src[i] = (unsigned char)i;
    //print("Init data at the address = ");putnum(&ptr_src[i]);
    //print(" with data = ");putnum(ptr_src[i]);
    //print("\n\r");
  }

//  printf("Mem_dump source data\n");
//  mem_dump(ptr_src,length/4);

  if ((ptr->dma_work_msg_64b.field2.NxtBufDataLength2 | 0x7FFF) != 0x7800) {
    ptr_src  = (unsigned char *)(ptr->dma_work_msg_64b.field2.NxtDataAddr2 | DMA_CPU_MEM_ACCESS_MASK);
    length = dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength2); // To be updated
    print("DDR Data Start Address:");putnum(ptr_src);print("\n\r");
    print("DDR Data Length:");putnum(length);print("\n\r");
    for (i=0; i < length; i++) {

      if(DMA_RAND) ptr_src[i] = (unsigned char)random();
      else ptr_src[i] = (unsigned char)i;
      //print("Init data at the address = ");putnum(&ptr_src[i]);
      //print(" with data = ");putnum(ptr_src[i]);
      //print("\n\r");
    }
//    printf("Mem_dump source data\n");
//    mem_dump(ptr_src,length/4);

    if ((ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength3 | 0x7FFF) != 0x7800) {
      ptr_src  = (unsigned char *)(ptr->dma_work_msg_64b.field3.normal.NxtDataAddr3 | DMA_CPU_MEM_ACCESS_MASK);
      length = dma_get_lendata(ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength3); // To be updated
      print("DDR Data Start Address:");putnum(ptr_src);print("\n\r");
      print("DDR Data Length:");putnum(length);print("\n\r");
      for (i=0; i < length; i++) {

        if(DMA_RAND) ptr_src[i] = (unsigned char)random();
	else ptr_src[i] = (unsigned char)i;
        //print("Init data at the address = ");putnum(&ptr_src[i]);
        //print(" with data = ");putnum(ptr_src[i]);
        //print("\n\r");
      }

//      printf("Mem_dump source data\n");
//      mem_dump(ptr_src,length/4);

      if ((ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength4 | 0x7FFF) != 0x7800) {
        ptr_src  = (unsigned char *)(ptr->dma_work_msg_64b.field3.normal.NxtDataAddr4 | DMA_CPU_MEM_ACCESS_MASK);
        length = dma_get_lendata(ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength4); // To be updated
        print("DDR Data Start Address:");putnum(ptr_src);print("\n\r");
        print("DDR Data Length:");putnum(length);print("\n\r");
        for (i=0; i < length; i++) {

          if(DMA_RAND) ptr_src[i] = (unsigned char)random();
	  else ptr_src[i] = (unsigned char)i;
          //print("Init data at the address = ");putnum(&ptr_src[i]);
          //print(" with data = ");putnum(ptr_src[i]);
          //print("\n\r");

        }

//        printf("Mem_dump source data\n");
//        mem_dump(ptr_src,length/4);
      }
    }
  }
  print("========================================\n");
}

void dma_init_data_64b_msg_ll(dma_params_ptr ptr) {
  unsigned char *ptr_src;
  int length,i,num_src;
  print("\n===== Init Data Phase ======\n");

  printf("num_src=%u\n",ptr->num_src);
  for (num_src = 0; num_src < ptr->num_src; num_src++) {
    ptr_src  = (unsigned char *)(ptr->src[num_src] | DMA_CPU_MEM_ACCESS_MASK);
    length = ptr->len_src[num_src]; // To be updated
    print("DDR Data Start Address:");putnum_64(ptr_src);print("\n\r");
    print("DDR Data Length:");putnum(length);print("\n\r");
    for (i=0; i < length; i++) {

      if(DMA_RAND) ptr_src[i] = (unsigned char)random();
      else  ptr_src[i] = (unsigned char)i;
      //print("Init data at the address = ");putnum(&ptr_src[i]);
      //print(" with data = ");putnum(ptr_src[i]);
      //print("\n\r");
    }
  }

  print("========================================\n");
}

void dma_init_data_sdp_check_64b_msg(dma_work_msg_64b_ptr ptr, dma_dif_result_ptr ptr_dma_dif_result, char ErrSet) {
  unsigned char *ptr_src;
  int length,i;
  print("\n===== Init Data Gather SDP Check Phase ======\n");

  ptr_src  = (unsigned char *)(ptr->dma_work_msg_64b.field0.DataAddr | DMA_CPU_MEM_ACCESS_MASK);
  length = dma_get_lendata(ptr->dma_work_msg_64b.field0.BufDataLength); // To be updated
  print("DDR Data Start Address:");putnum(ptr_src);print("\n\r");
  print("DDR Data Length:");putnum(length);print("\n\r");
  for (i=0; i < length; i++) {
    if(DMA_RAND) ptr_src[i] = (unsigned char)random();
    else ptr_src[i] = (unsigned char)i;
    ptr_dma_dif_result->dma_dif_result.CRC = get_crc16_seed(&ptr_src[i], 1, ptr_dma_dif_result->dma_dif_result.CRC);
    //print("Init data at the address = ");putnum(&ptr_src[i]);
    //print(" with data = ");putnum(ptr_src[i]);
    //print("\n\r");
  }

  ptr_src  = (unsigned char *)(ptr->dma_work_msg_64b.field2.NxtDataAddr1 | DMA_CPU_MEM_ACCESS_MASK);
  length = dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength1); // To be updated
  print("DDR Data Start Address:");putnum(ptr_src);print("\n\r");
  print("DDR Data Length:");putnum(length);print("\n\r");
  for (i=0; i < length; i++) {
    ptr_src[i] = ptr_dma_dif_result->data[i];
    //print("Init data at the address = ");putnum(&ptr_src[i]);
    //print(" with data = ");putnum(ptr_src[i]);
    //print("\n\r");
    if(i == (length - 1)) {
      ptr_dma_dif_result->dma_dif_result.CRC = 0;
      ptr_dma_dif_result->dma_dif_result.RefTag++;
    }
  }

  if (ptr->dma_work_msg_64b.field2.NxtBufDataLength2 != 0x7800) {
    ptr_src  = (unsigned char *)(ptr->dma_work_msg_64b.field2.NxtDataAddr2 | DMA_CPU_MEM_ACCESS_MASK);
    length = dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength2); // To be updated
    print("DDR Data Start Address:");putnum(ptr_src);print("\n\r");
    print("DDR Data Length:");putnum(length);print("\n\r");
    for (i=0; i < length; i++) {
      if(DMA_RAND) ptr_src[i] = (unsigned char)random();
      else ptr_src[i] = (unsigned char)i;
      ptr_dma_dif_result->dma_dif_result.CRC = get_crc16_seed(&ptr_src[i], 1, ptr_dma_dif_result->dma_dif_result.CRC);
      //print("Init data at the address = ");putnum(&ptr_src[i]);
      //print(" with data = ");putnum(ptr_src[i]);
      //print("\n\r");
    }
    if (ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength3 != 0x7800) {
      ptr_src  = (unsigned char *)(ptr->dma_work_msg_64b.field3.normal.NxtDataAddr3 | DMA_CPU_MEM_ACCESS_MASK);
      length = dma_get_lendata(ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength3); // To be updated
      print("DDR Data Start Address:");putnum(ptr_src);print("\n\r");
      print("DDR Data Length:");putnum(length);print("\n\r");
      for (i=0; i < length; i++) {
        ptr_src[i] = ErrSet ? !(ptr_dma_dif_result->data[i]) : ptr_dma_dif_result->data[i];
        //print("Init data at the address = ");putnum(&ptr_src[i]);
        //print(" with data = ");putnum(ptr_src[i]);
        //print("\n\r");
	if(i == (length - 1)) {
	  ptr_dma_dif_result->dma_dif_result.CRC = 0;
	  ptr_dma_dif_result->dma_dif_result.RefTag++;
	}
      }
      if (ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength4 != 0x7800) {
        ptr_src  = (unsigned char *)(ptr->dma_work_msg_64b.field3.normal.NxtDataAddr4 | DMA_CPU_MEM_ACCESS_MASK);
        length = dma_get_lendata(ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength4); // To be updated
        print("DDR Data Start Address:");putnum(ptr_src);print("\n\r");
        print("DDR Data Length:");putnum(length);print("\n\r");
        for (i=0; i < length; i++) {
	  if(DMA_RAND) ptr_src[i] = (unsigned char)random();
          else ptr_src[i] = (unsigned char)i;
	  ptr_dma_dif_result->dma_dif_result.CRC = get_crc16_seed(&ptr_src[i], 1, ptr_dma_dif_result->dma_dif_result.CRC);
          //print("Init data at the address = ");putnum(&ptr_src[i]);
          //print(" with data = ");putnum(ptr_src[i]);
          //print("\n\r");

        }
      }
    }
  }
  print("========================================\n");
}
void dma_dump_cmplt_msg_32b(dma_cmplt_msg_32b_ptr ptr){
  print("\n===== Decoding 32B  DMA Completion Message ======\n");
  print("UserInfo ="); putnum(ptr->dma_cmplt_msg_32b.field0.UserInfo);print("\n");
  print("DataAddr ="); putnum_64(ptr->dma_cmplt_msg_32b.field0.DataAddr);print("\n");
  print("BufDataLength ="); putnum(dma_get_lendata(ptr->dma_cmplt_msg_32b.field0.BufDataLength));print("\n");
  print("FPQNum ="); putnum(ptr->dma_cmplt_msg_32b.field0.FPQNum);print("\n");
  print("ELErr="); putnum(ptr->dma_cmplt_msg_32b.field0.ELErr & 0x3);print("\n");
  print("LL="); putnum(ptr->dma_cmplt_msg_32b.field0.LL);print("\n");
  print("NV="); putnum(ptr->dma_cmplt_msg_32b.field0.NV);print("\n");
  print("LErr="); putnum(ptr->dma_cmplt_msg_32b.field0.LErr & 0x7);print("\n");
  print("LEI="); putnum(ptr->dma_cmplt_msg_32b.field0.LEI);print("\n");
  print("HEnqNum="); putnum(ptr->dma_cmplt_msg_32b.field1.HEnqNum);print("\n");
  print("HFPSel="); putnum(ptr->dma_cmplt_msg_32b.field1.HFPSel);print("\n");
  print("DR="); putnum(ptr->dma_cmplt_msg_32b.field1.DR & 0x1);print("\n");
  print("HR="); putnum(ptr->dma_cmplt_msg_32b.field1.HR);print("\n");
  print("TotDataLengthLinkListLSBs=");
  putnum(ptr->dma_cmplt_msg_32b.field1.TotDataLengthLinkListLSBs);print("\n");
  print("===================================================\n");

  print("CRCResult="); putnum(ptr->dma_cmplt_bufdest_1buf.CRCResult);print("\n");
  print("CRCResult="); putnum(ptr->dma_cmplt_bufdest_1buf.CRCResult);print("\n");
  print("TotDataLengthLinkListLSBs=");
  putnum(ptr->dma_cmplt_bufdest_1buf.TotDataLengthLinkListLSBs);print("\n");
  print("===================================================\n");
}
void dma_dump_cmplt_msg_64b(dma_cmplt_msg_64b_ptr ptr){
  print("\n===== Decoding 64B  DMA Completion Message ======\n");
  print("UserInfo ="); putnum(ptr->dma_cmplt_msg_64b.field0.UserInfo);print("\n");
  print("DataAddr ="); putnum(ptr->dma_cmplt_msg_64b.field0.DataAddr);print("\n");
  print("BufDataLength ="); putnum(dma_get_lendata(ptr->dma_cmplt_msg_64b.field0.BufDataLength));print("\n");

  print("ELErr ="); putnum(ptr->dma_cmplt_msg_64b.field0.ELErr & 0x3);print("\n");
  print("LErr ="); putnum(ptr->dma_cmplt_msg_64b.field0.LErr & 0x7);print("\n");
  print("HB ="); putnum(ptr->dma_cmplt_msg_64b.field0.HB & 0x1);print("\n");
  print("HL ="); putnum(ptr->dma_cmplt_msg_64b.field0.HL & 0x1);print("\n");
  print("PB ="); putnum(ptr->dma_cmplt_msg_64b.field0.PB & 0x1);print("\n");
  print("HEnqNum ="); putnum(ptr->dma_cmplt_msg_64b.field1.HEnqNum & 0xFFF);print("\n");
  print("HFPSel ="); putnum(ptr->dma_cmplt_msg_64b.field1.HFPSel & 0xF);print("\n");
  print("DR ="); putnum(ptr->dma_cmplt_msg_64b.field1.DR & 0x1);print("\n");
  print("NV ="); putnum(ptr->dma_cmplt_msg_64b.field0.NV & 0x1);print("\n");
  print("LL ="); putnum(ptr->dma_cmplt_msg_64b.field0.LL & 0x1);print("\n");
  print("NxtFPQNumMsbs ="); putnum(ptr->dma_cmplt_msg_64b.field2.NxtFPQNumMsbs & 0xF);print("\n");
  print("NxtFPQNum ="); putnum(ptr->dma_cmplt_msg_64b.field3.NxtFPQNum & 0xF);print("\n");
  print("NxtFPQNumLsbs ="); putnum(ptr->dma_cmplt_msg_64b.field3.NxtFPQNumLsbs & 0xF);print("\n");




  print("TotDataLengthLinkListLSBs ="); putnum(ptr->dma_cmplt_msg_64b.field1.TotDataLengthLinkListLSBs);print("\n");

  print("NxtDataAddr1 ="); putnum(ptr->dma_cmplt_msg_64b.field2.NxtDataAddr1);print("\n");
  print("NxtBufDataLength1 ="); putnum(dma_get_lendata(ptr->dma_cmplt_msg_64b.field2.NxtBufDataLength1));print("\n");

  print("NxtDataAddr2 ="); putnum(ptr->dma_cmplt_msg_64b.field2.NxtDataAddr2);print("\n");
  print("NxtBufDataLength2 ="); putnum(dma_get_lendata(ptr->dma_cmplt_msg_64b.field2.NxtBufDataLength2));print("\n");

  print("NxtDataAddr3 ="); putnum(ptr->dma_cmplt_msg_64b.field3.NxtDataAddr3);print("\n");
  print("NxtBufDataLength3 ="); putnum(dma_get_lendata(ptr->dma_cmplt_msg_64b.field3.NxtBufDataLength3));print("\n");

  print("NxtDataAddr4 ="); putnum(ptr->dma_cmplt_msg_64b.field3.NxtDataAddr4);print("\n");
  print("NxtBufDataLength4 ="); putnum(dma_get_lendata(ptr->dma_cmplt_msg_64b.field3.NxtBufDataLength4));print("\n");

  print("===================================================\n");
}

void dma_dump_work_msg_32b(dma_work_msg_32b_ptr ptr){
  print("\n===== Decoding DMA 32B  Work Message ======\n");
  print("UserInfo ="); putnum(ptr->dma_work_msg_32b.field0.UserInfo);print("\n");
//  print("DataAddr ="); putnum(ptr->dma_work_msg_32b.field0.DataAddr);print("\n");
  printf("DataAddr = %12x\n",ptr->dma_work_msg_32b.field0.DataAddr);
  print("BufDataLength ="); putnum(dma_get_lendata(ptr->dma_work_msg_32b.field0.BufDataLength));print("\n");
  print("FPQNum ="); putnum(ptr->dma_work_msg_32b.field0.FPQNum & 0xFFF);print("\n");
  print("Err =");    putnum(ptr->dma_work_msg_32b.field0.LErr);print("\n");
  print("ElErr =");  putnum(ptr->dma_work_msg_32b.field0.ELErr);print("\n");
  print("DR ="); putnum(ptr->dma_work_msg_32b.field1.transfer.DR);print("\n");
  print("HR ="); putnum(ptr->dma_work_msg_32b.field1.transfer.HR);print("\n");
  print("HB ="); putnum(ptr->dma_work_msg_32b.field0.HB &0x1);print("\n");
  print("HEnqNum ="); putnum(ptr->dma_work_msg_32b.field1.transfer.HEnqNum);print("\n");
  print("HFPSel ="); putnum(ptr->dma_work_msg_32b.field1.transfer.HFPSel);print("\n");
  print("TotDataLengthLinkListLSBs = ");putnum(ptr->dma_work_msg_32b.field1.transfer.TotDataLengthLinkListLSBs);print("\n");
  printf("Dest Address =%12x",ptr->dma_work_msg_32b.field1.transfer.DestAddress);print("\n");
//  printf("Dest Address =%09x\n",ptr->dma_work_msg_32b.field1.transfer.DestAddress);

  if (ptr->dma_work_msg_32b.field1.transfer.FBY== 0  ){
  	 print("\n ========== NO FLYBY==========\n");
     if (ptr-> dma_work_msg_32b.field1.transfer.CTL>>3 & 0x01 ){
  	    print("\n===== STRIDING======\n");
  	    print("SRC striding size =");putnum(ptr-> dma_work_msg_32b.field1.transfer.SrcStridingSize);print("\n");
        print ("SRC Distance =" );putnum(ptr-> dma_work_msg_32b.field1.transfer.SrcDistance);print("\n");
        print("DEST striding size =");putnum(ptr-> dma_work_msg_32b.field1.transfer.DstStridingSize);print("\n");
        print ("DEST Distance =" );putnum(ptr-> dma_work_msg_32b.field1.transfer.DstDistance);print("\n");
    	}
     else {
  	    print("\n===== NO_STRIDING======\n");
     }

	  }
  else {
     print("\n========== FLYBY=============\n");
     print("FBY = ");putnum(ptr->dma_work_msg_32b.field1.flyby.FBY);print("\n");
     print("BD = ");putnum(ptr->dma_work_msg_32b.field1.flyby.BD);print("\n");
	   print("SD = ");putnum(ptr->dma_work_msg_32b.field1.flyby.SD);print("\n");
	   print("GN = ");putnum(ptr->dma_work_msg_32b.field1.flyby.GN);
     print("0/1 :Generate /Check with CRC.Insert/Check with DIF");print("\n");
//     print("Seed = ");putnum(ptr->dma_work_msg_32b.field1.flyby.Seed);print("\n");            //WHY???

     print("Bytecount  = ");putnum(ptr->dma_work_msg_32b.field1.flyby.ByteCnt);
     //print("Mult0 = ");putnum(ptr-> dma_work_msg_32b.field1.raid6.Multi0);
     //print("Mult1 = ");putnum(ptr-> dma_work_msg_32b.field1.raid6.Multi1);
     //print("Mult2 = ");putnum(ptr-> dma_work_msg_32b.field1.raid6.Multi2);
     //print("Mult3 = ");putnum(ptr-> dma_work_msg_32b.field1.raid6.Multi3);
     //print("Mult4 = ");putnum(ptr-> dma_work_msg_32b.field1.raid6.Multi4);
	///SDP add later
   }
  print("\n=================================================\n");
}
void dma_dump_work_msg_64b(dma_work_msg_64b_ptr ptr){
  print("\n===== Decoding DMA 64B Work Message ======\n");
  print("UserInfo ="); putnum(ptr->dma_work_msg_64b.field0.UserInfo);print("\n");
  print("DataAddr ="); putnum(ptr->dma_work_msg_64b.field0.DataAddr);print("\n");

  print("BufDataLength ="); putnum(dma_get_lendata(ptr->dma_work_msg_64b.field0.BufDataLength));print("\n");
  print("DR ="); putnum(ptr->dma_work_msg_64b.field1.transfer.DR);print("\n");
  print("HR ="); putnum(ptr->dma_work_msg_64b.field1.transfer.HR);print("\n");
  print("NV ="); putnum(ptr->dma_work_msg_64b.field0.NV);print("\n");
  print("LL ="); putnum(ptr->dma_work_msg_64b.field0.LL);print("\n");
  print("HEnqNum ="); putnum(ptr->dma_work_msg_64b.field1.transfer.HEnqNum);print("\n");
  print("HFPSel ="); putnum(ptr->dma_work_msg_64b.field1.transfer.HFPSel);print("\n");
  print("TotDataLengthLinkListLSBs = ");putnum(ptr->dma_work_msg_64b.field1.transfer.TotDataLengthLinkListLSBs);print("\n");
  print("Dest Address ="); putnum(ptr->dma_work_msg_64b.field1.transfer.DestAddress);print("\n");
  print("Pointer Dest Linklist =");
  putnum(ptr->dma_work_msg_64b.field1.transfer_dest_ll.PtrDestLL);print("\n");
  print("Link Size =");
  putnum(ptr->dma_work_msg_64b.field1.transfer_dest_ll.LinkSize);print("\n");
  print("NxtDataAddr1 ="); putnum(ptr->dma_work_msg_64b.field2.NxtDataAddr1);print("\n");
  print("NxtBufDataLength1 = "); putnum(dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength1));print("\n");
  print("NxtDataAddr2 = "); putnum(ptr->dma_work_msg_64b.field2.NxtDataAddr2);print("\n");
  print("NxtBufDataLength2 = "); putnum(dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength2));print("\n");
  print("NxtFPQNumMsbs = ");
  putnum(ptr->dma_work_msg_64b.field2.NxtFPQNumMsbs);print("\n");
  print("NxtDataAddr3 ="); putnum(ptr->dma_work_msg_64b.field3.normal.NxtDataAddr3);print("\n");
  print("NxtBufDataLength3 = "); putnum(dma_get_lendata(ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength3));print("\n");
  print("NxtDataAddr4 = "); putnum(ptr->dma_work_msg_64b.field3.normal.NxtDataAddr4);print("\n");
  print("NxtBufDataLength4 = "); putnum(dma_get_lendata(ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength4));print("\n");
  print("NxtFPQNum = ");
  putnum(ptr->dma_work_msg_64b.field3.normal.NxtFPQNum);print("\n");
  print("Source Link Size =");
  putnum(ptr->dma_work_msg_64b.field3.linklist.LinkSize);print("\n");
  if (ptr->dma_work_msg_64b.field1.transfer.FBY== 0  ){
  	 print("\n ========== NO FLYBY==========\n");
     if (ptr-> dma_work_msg_64b.field1.transfer.CTL>>3 & 0x01 ){
  	    print("\n===== STRIDING======\n");
  	    print("SRC striding size =");putnum(ptr-> dma_work_msg_64b.field1.transfer.SrcStridingSize);print("\n");
        print ("SRC Distance =" );putnum(ptr-> dma_work_msg_64b.field1.transfer.SrcDistance);print("\n");
        print("DEST striding size =");putnum(ptr-> dma_work_msg_64b.field1.transfer.DstStridingSize);print("\n");
        print ("DEST Distance =" );putnum(ptr-> dma_work_msg_64b.field1.transfer.DstDistance);print("\n");
    	}
    }
  else {
	print("\n========== FLYBY=============\n");
	print("FBY = ");putnum(ptr->dma_work_msg_64b.field1.flyby.FBY);print("\n");
	print("BD = ");putnum(ptr->dma_work_msg_64b.field1.flyby.BD);print("\n");
	print("SD = ");putnum(ptr->dma_work_msg_64b.field1.flyby.SD);print("\n");
	print("GN = ");putnum(ptr->dma_work_msg_64b.field1.flyby.GN);
//     print("0/1 :Generate /Check with CRC.Insert/Check with DIF");print("\n");
//     print("Seed = ");putnum(ptr->dma_work_msg_64b.field1.flyby.Seed);print("\n");

	print("Bytecount  = ");putnum(ptr->dma_work_msg_64b.field1.flyby.ByteCnt);
	print("Mult0 = ");putnum(ptr-> dma_work_msg_64b.field1.raid.Multi0);
	print("\tMult1 = ");putnum(ptr-> dma_work_msg_64b.field1.raid.Multi1);
	print("\tMult2 = ");putnum(ptr-> dma_work_msg_64b.field1.raid.Multi2);
	print("\tMult3 = ");putnum(ptr-> dma_work_msg_64b.field1.raid.Multi3);
	print("\tMult4 = ");putnum(ptr-> dma_work_msg_64b.field1.raid.Multi4);
	///SDP add later
   }
  print("\n==================================================\n");

}
void dma_get_params_from_32b(dma_work_msg_32b_ptr ptr, dma_params_ptr ptr_params){
  ptr_params->num_src = 1;
  ptr_params->src[0] = ptr->dma_work_msg_32b.field0.DataAddr;
  ptr_params->len_src[0] = dma_get_lendata(ptr->dma_work_msg_32b.field0.BufDataLength);
  ptr_params->SrcStridingSize = ptr->dma_work_msg_32b.field1.transfer.SrcStridingSize;
  ptr_params->SrcDistance = ptr->dma_work_msg_32b.field1.transfer.SrcDistance;
  ptr_params->DstStridingSize = ptr->dma_work_msg_32b.field1.transfer.DstStridingSize;
  ptr_params->DstDistance = ptr->dma_work_msg_32b.field1.transfer.DstDistance;
  ptr_params->BlkSize = ptr->dma_work_msg_32b.field1.dif.BlkSize;
  ptr_params->BD  = (ptr->dma_work_msg_32b.field1.transfer.CTL & 1);
  if (ptr_params->BD) { //bufdest
    print("\n\r BUFDEST operation\n\r");
    ptr_params->FBY     = ptr->dma_work_msg_32b.field1.transfer.FBY;
//    ptr_params->Seed    = ptr->dma_work_msg_32b.field1.crc_chksum.Seed;       ///WHY???? if there is this line, will crash
    ptr_params->ByteCnt = ptr->dma_work_msg_32b.field1.crc_chksum.ByteCnt;
    ptr_params->SD      = ptr->dma_work_msg_32b.field1.flyby.SD;
    ptr_params->GN      = ptr->dma_work_msg_32b.field1.flyby.GN;
    ptr_params->ST      = ptr->dma_work_msg_32b.field1.flyby.ST;

//   print(" CRC seed    : ");putnum(ptr_params->Seed);print("\n\r");			///WHY???? if there is this line, will crash
   //Added 08Mar13
//   print(" field1.crc_chksum.Seed: ");putnum((unsigned int)ptr->dma_work_msg_32b.field1.crc_chksum.Seed);print("\n\r");
   print(" CRC ByteCnt : ");putnum(ptr_params->ByteCnt);print("\n\r");
   print(" Src Addr    : ");putnum(ptr_params->src[0]);print("\n\r");
  }
}

/*Temporarily use this function to avoid crashing*/
void dma_get_params_from_32b_crc_gen_16(dma_work_msg_32b_ptr ptr, dma_params_ptr ptr_params){
  ptr_params->num_src = 1;
  ptr_params->src[0] = ptr->dma_work_msg_32b.field0.DataAddr;
  ptr_params->len_src[0] = dma_get_lendata(ptr->dma_work_msg_32b.field0.BufDataLength);
  ptr_params->SrcStridingSize = ptr->dma_work_msg_32b.field1.transfer.SrcStridingSize;
  ptr_params->SrcDistance = ptr->dma_work_msg_32b.field1.transfer.SrcDistance;
  ptr_params->DstStridingSize = ptr->dma_work_msg_32b.field1.transfer.DstStridingSize;
  ptr_params->DstDistance = ptr->dma_work_msg_32b.field1.transfer.DstDistance;
  ptr_params->BlkSize = ptr->dma_work_msg_32b.field1.dif.BlkSize;
  ptr_params->BD  = (ptr->dma_work_msg_32b.field1.transfer.CTL & 1);
  if (ptr_params->BD) { //bufdest
    print("\n\r BUFDEST operation\n\r");
    ptr_params->FBY     = ptr->dma_work_msg_32b.field1.crc_chksum.FBY;
    ptr_params->Seed    = ptr->dma_work_msg_32b.field1.crc_chksum.Seed;       ///WHY???? if there is this line, will crash
    ptr_params->ByteCnt = ptr->dma_work_msg_32b.field1.crc_chksum.ByteCnt;
    ptr_params->SD      = ptr->dma_work_msg_32b.field1.flyby.SD;
    ptr_params->GN      = ptr->dma_work_msg_32b.field1.flyby.GN;
    ptr_params->ST      = ptr->dma_work_msg_32b.field1.flyby.ST;

   print(" CRC seed    : ");putnum(ptr_params->Seed);print("\n\r");
   //Added 08Mar13
   print(" field1.crc_chksum.Seed: ");putnum((unsigned int)ptr->dma_work_msg_32b.field1.crc_chksum.Seed);print("\n\r");
   print(" CRC ByteCnt : ");putnum(ptr_params->ByteCnt);print("\n\r");
   print(" Src Addr    : ");putnum(ptr_params->src[0]);print("\n\r");
  }
}

void dma_get_params_from_cmplt_32b(dma_cmplt_msg_32b_ptr ptr, dma_params_ptr ptr_params) {
//use this procedure after get params from work message
  print("\n===== Get params from Completion 32b ======\n");
  ptr_params->num_dst = 1;
  ptr_params->dst[0] = ptr->dma_cmplt_msg_32b.field0.DataAddr;
  ptr_params->len_dst[0] = dma_get_lendata(ptr->dma_cmplt_msg_32b.field0.BufDataLength);

  if (ptr_params->BD) {
    ptr_params->ChkResult = ptr->dma_cmplt_bufdest_1buf.ChkResult;
    ptr_params->CRCResult = ptr->dma_cmplt_bufdest_1buf.CRCResult;
    print(" Chk Result : ");putnum(ptr_params->ChkResult);print("\n\r");
    print(" CRC Result : ");putnum(ptr_params->CRCResult);print("\n\r");
  }

  print("\n===== END of Get params from Completion 32b ======\n");
}

void dma_get_params_from_64b(dma_work_msg_64b_ptr ptr, dma_params_ptr ptr_params)
{
  ptr_params->src[0] = ptr->dma_work_msg_64b.field0.DataAddr;
  ptr_params->len_src[0] = dma_get_lendata(ptr->dma_work_msg_64b.field0.BufDataLength);

  ptr_params->src[1] = ptr->dma_work_msg_64b.field2.NxtDataAddr1;
  ptr_params->len_src[1] = dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength1);

  ptr_params->src[2] = ptr->dma_work_msg_64b.field2.NxtDataAddr2;
  ptr_params->len_src[2] = dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength2);

  ptr_params->src[3] = ptr->dma_work_msg_64b.field3.normal.NxtDataAddr3 ;
  ptr_params->len_src[3] = dma_get_lendata(ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength3);

  ptr_params->src[4] = ptr->dma_work_msg_64b.field3.normal.NxtDataAddr4;
  ptr_params->len_src[4] = dma_get_lendata(ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength4);

  ptr_params->SrcStridingSize = ptr->dma_work_msg_64b.field1.transfer.SrcStridingSize;
  ptr_params->SrcDistance = ptr->dma_work_msg_64b.field1.transfer.SrcDistance;
  ptr_params->DstStridingSize = ptr->dma_work_msg_64b.field1.transfer.DstStridingSize;
  ptr_params->DstDistance = ptr->dma_work_msg_64b.field1.transfer.DstDistance;
  ptr_params->BlkSize = ptr->dma_work_msg_64b.field1.dif.BlkSize;

  if(ptr->dma_work_msg_64b.field1.transfer.FBY == 0x8) {
    ptr_params->num_src = 2;
  } else if(ptr->dma_work_msg_64b.field1.transfer.FBY == 0x9) {
    ptr_params->num_src = 3;
  } else if(ptr->dma_work_msg_64b.field1.transfer.FBY == 0xA) {
    ptr_params->num_src = 4;
  } else if(ptr->dma_work_msg_64b.field1.transfer.FBY == 0xB) {
    ptr_params->num_src = 5;
  }
  print("num_src:");putnum(ptr_params->num_src);
  if (ptr->dma_work_msg_64b.field1.transfer.CTL & 1) { //bufdest
    ptr_params->FBY     = ptr->dma_work_msg_64b.field1.transfer.FBY;
//    ptr_params->Seed    = ptr->dma_work_msg_64b.field1.flyby.Seed;			//this line is the reason of crashing of RAID5_XOR???
    ptr_params->ByteCnt = ptr->dma_work_msg_64b.field1.flyby.ByteCnt;
    ptr_params->BD      = ptr->dma_work_msg_64b.field1.flyby.BD;
    ptr_params->SD      = ptr->dma_work_msg_64b.field1.flyby.SD;
    ptr_params->GN      = ptr->dma_work_msg_64b.field1.flyby.GN;
    ptr_params->ST      = ptr->dma_work_msg_64b.field1.flyby.ST;
    if ((ptr->dma_work_msg_64b.field1.transfer.FBY >= 0x08)&(ptr->dma_work_msg_64b.field1.transfer.FBY<=0xB)) {
      ptr_params->Multi0 = ptr->dma_work_msg_64b.field1.raid.Multi0;
      ptr_params->Multi1 = ptr->dma_work_msg_64b.field1.raid.Multi1;
      ptr_params->Multi2 = ptr->dma_work_msg_64b.field1.raid.Multi2;
      ptr_params->Multi3 = ptr->dma_work_msg_64b.field1.raid.Multi3;
      ptr_params->Multi4 = ptr->dma_work_msg_64b.field1.raid.Multi4;
    }
  }
}


void dma_get_params_from_cmplt_64b(dma_cmplt_msg_64b_ptr ptr, dma_params_ptr ptr_params)
{
  ptr_params->dst[0] = ptr->dma_cmplt_msg_64b.field0.DataAddr;
  ptr_params->len_dst[0] = dma_get_lendata(ptr->dma_cmplt_msg_64b.field0.BufDataLength);

  ptr_params->dst[1] = ptr->dma_cmplt_msg_64b.field2.NxtDataAddr1;
  ptr_params->len_dst[1] = dma_get_lendata(ptr->dma_cmplt_msg_64b.field2.NxtBufDataLength1);

  ptr_params->dst[2] = ptr->dma_cmplt_msg_64b.field2.NxtDataAddr2;
  ptr_params->len_dst[2] = dma_get_lendata(ptr->dma_cmplt_msg_64b.field2.NxtBufDataLength2);

  ptr_params->dst[3] = ptr->dma_cmplt_msg_64b.field3.NxtDataAddr3 ;
  ptr_params->len_dst[3] = dma_get_lendata(ptr->dma_cmplt_msg_64b.field3.NxtBufDataLength3);

  ptr_params->dst[4] = ptr->dma_cmplt_msg_64b.field3.NxtDataAddr4;
  ptr_params->len_dst[4] = dma_get_lendata(ptr->dma_cmplt_msg_64b.field3.NxtBufDataLength4);


  print("NxtDataAddr1 ="); putnum(ptr->dma_cmplt_msg_64b.field0.DataAddr);print("\n");
  print("NxtBufDataLength1 ="); putnum(dma_get_lendata(ptr->dma_cmplt_msg_64b.field0.BufDataLength));print("\n");

  print("NxtDataAddr1 ="); putnum(ptr->dma_cmplt_msg_64b.field2.NxtDataAddr1);print("\n");
  print("NxtBufDataLength1 ="); putnum(dma_get_lendata(ptr->dma_cmplt_msg_64b.field2.NxtBufDataLength1));print("\n");

  print("NxtDataAddr2 ="); putnum(ptr->dma_cmplt_msg_64b.field2.NxtDataAddr2);print("\n");
  print("NxtBufDataLength2 ="); putnum(dma_get_lendata(ptr->dma_cmplt_msg_64b.field2.NxtBufDataLength2));print("\n");

  print("NxtDataAddr3 ="); putnum(ptr->dma_cmplt_msg_64b.field3.NxtDataAddr3);print("\n");
  print("NxtBufDataLength3 ="); putnum(dma_get_lendata(ptr->dma_cmplt_msg_64b.field3.NxtBufDataLength3));print("\n");

  print("NxtDataAddr4 ="); putnum(ptr->dma_cmplt_msg_64b.field3.NxtDataAddr4);print("\n");
  print("NxtBufDataLength4 ="); putnum(dma_get_lendata(ptr->dma_cmplt_msg_64b.field3.NxtBufDataLength4));print("\n");


}


void dma_get_linklist_params_from_cmplt_64b(dma_cmplt_msg_64b_ptr ptr, dma_params_ptr ptr_params,int num_dst)
{
	int i,j;
    msg_16b_field_0_t data_ptr[num_dst+1];
	msg_16b_field_0_t *temp_ptr;
	temp_ptr = &data_ptr[0];
  ptr_params->dst[0] = ptr->dma_cmplt_msg_64b.field0.DataAddr;
  ptr_params->len_dst[0] = dma_get_lendata(ptr->dma_cmplt_msg_64b.field0.BufDataLength);

  ptr_params->dst[1] = ptr->dma_cmplt_msg_64b.field2.NxtDataAddr1;
  ptr_params->len_dst[1] = dma_get_lendata(ptr->dma_cmplt_msg_64b.field2.NxtBufDataLength1);

  ptr_params->dst[2] = ptr->dma_cmplt_msg_64b.field2.NxtDataAddr2;
  ptr_params->len_dst[2] = dma_get_lendata(ptr->dma_cmplt_msg_64b.field2.NxtBufDataLength2);

  ptr_params->dst[3] = ptr->dma_cmplt_msg_64b.field3.NxtDataAddr3 ;
  ptr_params->len_dst[3] = dma_get_lendata(ptr->dma_cmplt_msg_64b.field3.NxtBufDataLength3);

  read_queue(FPQID4,temp_ptr,num_dst+1);
  temp_ptr+=5;
  for(j=5;j<=num_dst;j++){
  printf("Address: 0x%08x\n", temp_ptr->DataAddr);
  printf("BufDatalength: 0x%08x\n", temp_ptr->BufDataLength);
  ptr_params->dst[j-1]=temp_ptr->DataAddr;
  ptr_params->len_dst[j-1]=temp_ptr->BufDataLength;
  temp_ptr++;
  }
//
//
//
//  print("NxtDataAddr1 ="); putnum(ptr->dma_cmplt_msg_64b.field0.DataAddr);print("\n");
//  print("NxtBufDataLength1 ="); putnum(dma_get_lendata(ptr->dma_cmplt_msg_64b.field0.BufDataLength));print("\n");
//
//  print("NxtDataAddr1 ="); putnum(ptr->dma_cmplt_msg_64b.field2.NxtDataAddr1);print("\n");
//  print("NxtBufDataLength1 ="); putnum(dma_get_lendata(ptr->dma_cmplt_msg_64b.field2.NxtBufDataLength1));print("\n");
//
//  print("NxtDataAddr2 ="); putnum(ptr->dma_cmplt_msg_64b.field2.NxtDataAddr2);print("\n");
//  print("NxtBufDataLength2 ="); putnum(dma_get_lendata(ptr->dma_cmplt_msg_64b.field2.NxtBufDataLength2));print("\n");
//
//  print("NxtDataAddr3 ="); putnum(ptr->dma_cmplt_msg_64b.field3.NxtDataAddr3);print("\n");
//  print("NxtBufDataLength3 ="); putnum(dma_get_lendata(ptr->dma_cmplt_msg_64b.field3.NxtBufDataLength3));print("\n");
//
//  print("NxtDataAddr4 ="); putnum(ptr->dma_cmplt_msg_64b.field3.NxtDataAddr4);print("\n");
//  print("NxtBufDataLength4 ="); putnum(dma_get_lendata(ptr->dma_cmplt_msg_64b.field3.NxtBufDataLength4));print("\n");
//	dma_build_dest_linklist()

}
unsigned long long dma_get_bufptrs_start_addr(unsigned int BufDataLength)
{
  unsigned long long tmp;
#ifndef PDMA_DDR

  if((BUFPTRS_START_ADDR + DataLength + BufDataLength) & 0x100000) DataLength = DataLength & 0x3F; // RAIDx
#endif /*PDMA_DDR*/

  tmp =  BUFPTRS_START_ADDR + DataLength;

  DataLength+= BufDataLength;


  print("BufDataLength is : ");putnum(BufDataLength);print("- DataLength is :");putnum(DataLength);print("\n");
  return tmp;
}
unsigned int dma_qm_get_allocated_fptr_num (unsigned short int buff_size)
{
  unsigned int tmp;

  tmp =  BUFPTRS_START_ADDR + buff_size * alloted_fptr_num;

  if(tmp & 0x100000) {

    alloted_fptr_num = 0x0;
    tmp = BUFPTRS_START_ADDR + buff_size * alloted_fptr_num;

  }

  alloted_fptr_num++;

  return tmp;
}

void dma_setup_FP(int qid, int num_of_ptr) {
  msg_16b_field_0_t  data_ptr;
  msg_16b_t          intstream;
  int              i, j;
  unsigned int         data_ptr_addr;
  unsigned int         alt_enq_addr;

  print("\n===== DMA SETUP FP Data start ======\n");

  for(i = 0; i < num_of_ptr; i++) {
    // formation of data pointer
	printf("dma_FP_length: 0x%x\n",dma_FP_length);
    data_ptr.BufDataLength =  dma_FP_length; //16K
    //data_ptr.DataAddr = BUFPTRS_START_ADDR + (2048 * alloted_fptr_num);
    data_ptr.DataAddr = dma_get_bufptrs_start_addr(dma_get_lendata(data_ptr.BufDataLength));//dma_qm_get_allocated_fptr_num(2048);
    data_ptr.FPQNum = (DMA_QM_ID << 10) | qid;
    data_ptr.UserInfo = 0xdadacafe;

    intstream.field0 = data_ptr;
    print("DataAddr :  ");putnum_64(data_ptr.DataAddr);  print("\n");
    //print("DataAddr:");putnum(data_ptr.DataAddr);print(" - PTR:");putnum(alloted_fptr_num_FP);print("\n");
    //    data_ptr_addr = ((1<<31) + (q_state[qid].st_addr << 8) + (i * 16));
    data_ptr_addr = ((q_state[qid].st_addr << 8) + enq_ptr[qid]);
    //alloted_fptr_num_FP++;
    for(j=0; j < 4; j++) write((unsigned int *)(data_ptr_addr + j*4), intstream.raw[j]);
    enq_ptr[qid] +=16;
    if(enq_ptr[qid] == 0x800) enq_ptr[qid] = 0;

  }

    /* //Directly send alt_enq_cmd */
    /* alt_enq_addr = (DMA_CPU_MEM_ACCESS_MASK | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x2C); */
    /* write(alt_enq_addr, num_of_ptr); */

  if (num_alt_enq_cmd == 0xFF) {
    //Directly send alt_enq_cmd
    alt_enq_addr = (DMA_CPU_MEM_ACCESS_MASK | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x2C);
    //    write(alt_enq_addr, num_of_ptr);
    write((unsigned int *)alt_enq_addr, num_of_ptr);
  }
  else {
    // Queue up alt_enq_cmd
    alt_enq_qid[num_alt_enq_cmd] = qid;
    alt_enq_num[num_alt_enq_cmd] = num_of_ptr;
    num_alt_enq_cmd++;
  }

  print("\n===== data_ptr_init end ======\n");
}



void dma_setup_FP_ocm(int qid, int num_of_ptr) {
  msg_16b_field_0_t  data_ptr;
  msg_16b_t          intstream;
  int              i, j;
  unsigned int         data_ptr_addr;
  unsigned int         alt_enq_addr;

  print("\n===== DMA SETUP FP Data start ======\n");

  for(i = 0; i < num_of_ptr; i++) {
    // formation of data pointer
	printf("dma_FP_length: 0x%x\n",dma_FP_length);
    data_ptr.BufDataLength =  dma_FP_length; //16K
    //data_ptr.DataAddr = BUFPTRS_START_ADDR + (2048 * alloted_fptr_num);
    data_ptr.DataAddr = dma_get_bufptrs_start_addr_ocm(dma_get_lendata(data_ptr.BufDataLength));//dma_qm_get_allocated_fptr_num(2048);
    data_ptr.FPQNum = (DMA_QM_ID << 10) | qid;
    data_ptr.UserInfo = 0xdadacafe;

    intstream.field0 = data_ptr;
    print("DataAddr :  ");putnum_64(data_ptr.DataAddr);  print("\n");
    //print("DataAddr:");putnum(data_ptr.DataAddr);print(" - PTR:");putnum(alloted_fptr_num_FP);print("\n");
    //    data_ptr_addr = ((1<<31) + (q_state[qid].st_addr << 8) + (i * 16));
    data_ptr_addr = ((q_state[qid].st_addr << 8) + enq_ptr[qid]);
    //alloted_fptr_num_FP++;
    for(j=0; j < 4; j++) write((unsigned int *)(data_ptr_addr + j*4), intstream.raw[j]);
    enq_ptr[qid] +=16;
    if(enq_ptr[qid] == 0x800) enq_ptr[qid] = 0;

  }

    /* //Directly send alt_enq_cmd */
    /* alt_enq_addr = (DMA_CPU_MEM_ACCESS_MASK | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x2C); */
    /* write(alt_enq_addr, num_of_ptr); */

  if (num_alt_enq_cmd == 0xFF) {
    //Directly send alt_enq_cmd
    alt_enq_addr = (DMA_CPU_MEM_ACCESS_MASK | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x2C);
    //    write(alt_enq_addr, num_of_ptr);
    write((unsigned int *)alt_enq_addr, num_of_ptr);
  }
  else {
    // Queue up alt_enq_cmd
    alt_enq_qid[num_alt_enq_cmd] = qid;
    alt_enq_num[num_alt_enq_cmd] = num_of_ptr;
    num_alt_enq_cmd++;
  }

  print("\n===== data_ptr_init end ======\n");
}

unsigned int dma_get_blksize(int Blksize)
{
  unsigned int tmp;
  if(Blksize==0) tmp = 512;
  else if(Blksize==1) tmp = 1024;
  else if(Blksize==2) tmp = 2048;
  else if(Blksize==3) tmp = 4096;
  else if(Blksize==4) tmp = 8192;
  return tmp;
}

unsigned int dma_get_bufsize(int Bufsize)
{
  unsigned int tmp;
  if(Bufsize==0) tmp = 0x100;
  else if(Bufsize==1) tmp = 0x0400;
  else if(Bufsize==2) tmp = 0x0800;
  else if(Bufsize==3) tmp = 0x1000;
  else if(Bufsize==4) tmp = 0x4000;

  return tmp;
}
unsigned int dma_get_BufDataLength(int datalen)
{
  unsigned int BufDataLength;
  unsigned int length;
  unsigned char bufsize;
  if(DMA_RAND)
	  {
	  	  length = (unsigned int)random()%(LENGTH_MAX-LENGTH_MIN+1) + LENGTH_MIN;                        /// DMA_RAND =1
	  	  length = (length&0xFFFFFFFC);  // boundary 4byte
	  }

  else length = (unsigned int)datalen;

do {

    bufsize = (unsigned char)random()%5;

  } while(dma_get_bufsize(bufsize) < length);

//bufsize =4;

  if(bufsize == 0) {

    BufDataLength = 0x7000 | (length & 0x00FF); // 256B: data random from 1 to 256
  }
  else if(bufsize == 1) {

    BufDataLength = 0x6000 | (length & 0x03FF); // 1K : data random from 1 to 1024
  }
  else if(bufsize == 2) {

    BufDataLength = 0x5000 | (length & 0x07FF); // 2K : data random from 1 to 2048
  }
  else if(bufsize == 3) {

    BufDataLength = 0x4000 | (length & 0x0FFF); // 4K : data random from 1 to 4096
  }
  else if(bufsize == 4) {

    BufDataLength = 0x0000 | (length & 0x3FFF);// 16K: data random from 1 to 256
  }

  return BufDataLength;
}

unsigned int dma_get_lendata(int BufDataLength)
{
  unsigned int length;

  if ((BufDataLength & 0x7800) == 0x7800) {

    length = 0;

  } else if((BufDataLength & 0x7000) == 0x7000) { // 256B

    length = BufDataLength & 0x00FF;

    if(length == 0) length = 0x0100;

  } else if((BufDataLength & 0x6000) == 0x6000) { // 1K

    length = BufDataLength & 0x03FF;

    if(length == 0) length = 0x0400;

  } else if((BufDataLength & 0x5000) == 0x5000) { // 2K

    length = BufDataLength & 0x07FF;

    if(length == 0) length = 0x0800;

  } else if((BufDataLength & 0x4000) == 0x4000){ // 4K

    length = BufDataLength & 0x0FFF;

    if(length == 0) length = 0x1000;

  } else if((BufDataLength & 0x4000) == 0x0000){ // 16K

    length = BufDataLength & 0x03FFF;

    if(length == 0) length = 0x04000;
  }

  return length;
}
int dma_get_gather_dif_BufDataLength(int bufdatalen, dma_work_msg_64b_ptr ptr)
{
  unsigned char blk_num,bufsize;
  unsigned int  datalen,Bufdatalength;

  do {

    bufsize = (unsigned char)random()%5;

  } while(dma_get_bufsize(bufsize) < dma_get_blksize(ptr->dma_work_msg_64b.field1.dif.BlkSize));

  if(DMA_RAND) blk_num = (unsigned char)random()%(dma_get_bufsize(bufsize) / dma_get_blksize(ptr->dma_work_msg_64b.field1.dif.BlkSize)) + 1;
  else blk_num = bufdatalen / dma_get_blksize(ptr->dma_work_msg_64b.field1.dif.BlkSize);

  datalen = blk_num*dma_get_blksize(ptr->dma_work_msg_64b.field1.dif.BlkSize);

  if(bufsize == 1)      Bufdatalength = 0x6000 | (datalen & 0x03FF);
  else if(bufsize == 2) Bufdatalength = 0x5000 | (datalen & 0x07FF);
  else if(bufsize == 3) Bufdatalength = 0x4000 | (datalen & 0x0FFF);
  else if(bufsize == 4) Bufdatalength = 0x0000 | (datalen & 0x3FFF);

  return Bufdatalength;
}

/************************ Use this function declaration for OCM - DDR transfer test *************************/

unsigned int dma_get_bufptrs_start_addr_ocm(unsigned int BufDataLength)
{
  unsigned int tmp;

  if((BUFPTRS_START_ADDR_OCM + DataLength_ocm + BufDataLength) & 0x100000) DataLength_ocm = DataLength_ocm & 0x3F; // RAIDx

  tmp =  BUFPTRS_START_ADDR_OCM + DataLength_ocm;

  DataLength_ocm+= BufDataLength;


  print("BufDataLength is : ");putnum(BufDataLength);print("- DataLength is :");putnum(DataLength);print("\n");
  return tmp;
}


void dma_setup_msg_32b_ocm(int fpqnum, int henqnum, int hfpsel, int bufdatalen, int bufaddr, int pb, int hb, dma_work_msg_32b_ptr ptr)
{
  print("\n=====Setup DMA 32B Work Message ======\n");

  ptr->dma_work_msg_32b.field0.BufDataLength = dma_get_BufDataLength(bufdatalen);
  ptr->dma_work_msg_32b.field0.DataAddr = dma_get_bufptrs_start_addr_ocm(dma_get_lendata(ptr->dma_work_msg_32b.field0.BufDataLength));
  ptr->dma_work_msg_32b.field0.FPQNum = (DMA_QM_ID << 10) | fpqnum;
  ptr->dma_work_msg_32b.field0.UserInfo = 0xbabacafe;
  ptr->dma_work_msg_32b.field0.PB = pb;
  ptr->dma_work_msg_32b.field0.HB = hb;
  ptr->dma_work_msg_32b.field0.ELErr = 0;
  ptr->dma_work_msg_32b.field0.LErr = 0;
  ptr->dma_work_msg_32b.field1.transfer.HFPSel = hfpsel;
  ptr->dma_work_msg_32b.field1.transfer.HEnqNum = (DMA_QM_ID << 10) | henqnum;
  print("======================================\n");
}


/************************************************************************************************************/
/********** Use this for PDMA performance ***************************/
void AXI_start_measure(unsigned int bytes_stop)
{
 read(DMA_CSR_BASE+SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR);
 write(DMA_CSR_BASE+SM_GLBL_DIAG_CSR_CFG_BW_MSTR_STOP_CNT__ADDR,bytes_stop); // 16KB
 write(DMA_CSR_BASE+SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR,0x0);   //stop
 write(DMA_CSR_BASE+SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR,0x3FF); //start all measuring
 }
void performance_calculate()
{
	u32 clock_rd, bytes_rd, time_rd, clock_wr, bytes_wr, time_wr;
	u64 read_bw, write_bw;
	printf(" *********************************************** \n\r") ;
	printf(" **            TOTAL READ BANDWIDTH           **  \n\r");
	printf(" ***********************************************  \n\r\n\r") ;

	bytes_rd  =	READ32(DMA_CSR_BASE+SM_GLBL_DIAG_CSR_STS_AXI_MRD_BW_BYTE_CNT__ADDR);
	clock_rd  =	READ32(DMA_CSR_BASE+SM_GLBL_DIAG_CSR_STS_AXI_MRD_BW_CLK_CNT__ADDR);
	time_rd	  =	clock_rd <<2; // AXI clock =250MHz --> time_rd=clock_rd/250MHz = 4*clock_rd*10^-9 (s)= 4*clock (ns)
	read_bw   = (u64)1000000000*bytes_rd/time_rd; //B/s
//	read_bw   = 1000*16384/11564; //B/s

	printf("read_bw: %d\n",read_bw);
	read_bw	  =	read_bw*8/(1024*1024);		//Mb/s
	printf ("Total Bytes READ from AXI: %d\n\r", bytes_rd);
	printf("Total Read clock count: %d\n",clock_rd);
	printf("Total Read time: %d ns\n", time_rd);
	printf("Total Read Data Throughput : %dMb/s=%dMB/s\n\r",read_bw,read_bw/8); // megabits/s , megabytes/s

	printf(" *********************************************** \n\r") ;
	printf(" **            TOTAL WRTIE BANDWIDTH          **  \n\r");
	printf(" ***********************************************  \n\r\n\r") ;

	bytes_wr  =	READ32(DMA_CSR_BASE+SM_GLBL_DIAG_CSR_STS_AXI_MWR_BW_BYTE_CNT__ADDR);
	clock_wr  =	READ32(DMA_CSR_BASE+SM_GLBL_DIAG_CSR_STS_AXI_MWR_BW_CLK_CNT__ADDR);
	time_wr	  =	clock_wr <<2; // AXI clock =250MHz --> time_rd=clock_rd/250MHz = 4*clock_rd*10^-9 (s)= 4*clock (ns)
	write_bw   =  (u64)1000000000*bytes_wr/time_wr;		//B/s
	write_bw  = write_bw*8/(1024*1024);             //MB/s
	printf ("Total Bytes Write from AXI: %d\n\r", bytes_wr);
	printf("Total Write clock count: %d\n",clock_wr);
	printf("Total Write time: %d ns\n", time_wr);
	printf("Total Write Data Throughput : %dMb/s=%dMB/s\n\r",write_bw,write_bw/8); // megabits/s , megabytes/s
}
void dma_enqueue_msg_32b_performance(int qid, dma_work_msg_32b_ptr ptr)
{
  int i;
  unsigned int alt_enq_addr;
  print("\n===== Enqueue DMA 32B work message to QM ======\n");
  for(i=0; i< 8; i++) {
    //print("ENG_PTR:");putnum(enq_ptr[qid]);print(" - QID : ");putnum(qid);print(" - ADDR:");putnum(OCM_BASE_ADDR);print("\n");
    write((unsigned int *)(((OCM_BASE_ADDR + (0x800 * qid)) + enq_ptr[qid])|DMA_CPU_MEM_ACCESS_MASK), ptr->data[i]);
    enq_ptr[qid] += 4;
    if(enq_ptr[qid] == 0x800) enq_ptr[qid] = 0;
  // Alt enqueue command for QM
  }
  alt_enq_addr = (DMA_CPU_MEM_ACCESS_MASK | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x2C);

//  AXI_start_measure();
  write((unsigned int *)alt_enq_addr, 0x1);
  print("=============================================\n");
}

void dma_set_flyby_raid_64b_memdest(unsigned int FBY, unsigned char Multi0, unsigned char Multi1, unsigned char Multi2, unsigned char Multi3, unsigned char Multi4, dma_work_msg_64b_ptr ptr)
{
  print("\n=====Set FLYBY RAID ======\n");
  ptr->dma_work_msg_64b.field1.raid.DR = 1;
  ptr->dma_work_msg_64b.field1.raid.HR = 0;   // modified 1------>0 05Mar13 !!!!!!!!IMPORTANT
  ptr->dma_work_msg_64b.field1.raid.CTL = 1;
  ptr->dma_work_msg_64b.field1.raid.FBY = FBY;

  ptr->dma_work_msg_64b.field1.raid.Multi0 = Multi0;
  ptr->dma_work_msg_64b.field1.raid.Multi1 = Multi1;
  ptr->dma_work_msg_64b.field1.raid.Multi2 = Multi2;
  ptr->dma_work_msg_64b.field1.raid.Multi3 = Multi3;
  ptr->dma_work_msg_64b.field1.raid.Multi4 = Multi4;

  if(FBY == 0x8) { // XOR 2 SOURCES
    ptr->dma_work_msg_64b.field2.NxtBufDataLength2 = 0x7800;
    ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength3 = 0x7800;
    ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength4 = 0x7800;
  } else if(FBY == 0x9) { // XOR 3 SOURCES
    ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength3 = 0x7800;
    ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength4 = 0x7800;
  } else if(FBY == 0xA) { // XOR 4 SOURCES
    ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength4 = 0x7800;
  }

//  ptr->dma_work_msg_64b.field1.raid.DestAddress = 0;//BUFPTRS_START_ADDR + dma_qm_get_allocated_fptr_num(2048);	// dst add
  ptr->dma_work_msg_64b.field1.raid.DestAddress=dma_get_bufptrs_start_addr(dma_get_lendata(ptr->dma_work_msg_64b.field0.BufDataLength));
  print("===============================\n");
}



void dma_set_gather_memdest_striding_ll_msg_64b(int SrcStridingSize, int SrcDistance, int DstStridingSize, int DstDistance, dma_work_msg_64b_ptr ptr,dma_params_ptr dma_params)
{
  unsigned long long PtrSrcLL;
  PtrSrcLL = dma_get_bufptrs_start_addr(dma_get_lendata(0x0000)); // 16kB
  print("\n=====Set Gather Memedest With Striding ======\n");
  ptr->dma_work_msg_64b.field1.transfer.DR = 1;
  ptr->dma_work_msg_64b.field1.transfer.CTL = 8;
  ptr->dma_work_msg_64b.field1.transfer.FBY = 0;
  ptr->dma_work_msg_64b.field1.transfer.SrcStridingSize = SrcStridingSize;
  ptr->dma_work_msg_64b.field1.transfer.SrcDistance = SrcDistance;
  ptr->dma_work_msg_64b.field1.transfer.DstStridingSize = DstStridingSize;
  ptr->dma_work_msg_64b.field1.transfer.DstDistance = DstDistance;

  ptr->dma_work_msg_64b.field3.linklist.Ptr2SrcList = PtrSrcLL;	// dst add
 //  ptr->dma_work_msg_64b.field3.linklist.LinkSize = 3; // 7 Source
   ptr->dma_work_msg_64b.field3.linklist.LinkSize = 4; // 256 Source

   if(PtrSrcLL & 0xF) {
   PtrSrcLL = PtrSrcLL>>4;
   PtrSrcLL++;
   PtrSrcLL = PtrSrcLL<<4;
   print("PtrSrcLL:");putnum(PtrSrcLL);print("\n");
   }
   //ptr->dma_work_msg_64b.field3.linklist.Ptr2SrcList = PtrSrcLL;	// dst add
 //  dma_build_src_linklist(PtrSrcLL,3,128, ptr, dma_params);
   dma_build_src_linklist(PtrSrcLL,4,32, ptr, dma_params);


  ptr->dma_work_msg_64b.field1.transfer.DestAddress = dma_get_bufptrs_start_addr(dma_get_lendata(ptr->dma_work_msg_64b.field0.BufDataLength)+
 										 dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength1)+
 										 dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength2)+
 										 dma_get_lendata(ptr->dma_work_msg_64b.field3.linklist.NxtBufDataLength3)+ptr->dma_work_msg_64b.field1.transfer.TotDataLengthLinkListLSBs);

   printf("Total length Link list: %x\n",ptr->dma_work_msg_64b.field1.transfer.TotDataLengthLinkListLSBs);
   // Get information
   dma_params->src[0] = ptr->dma_work_msg_64b.field0.DataAddr;
   dma_params->len_src[0] = dma_get_lendata(ptr->dma_work_msg_64b.field0.BufDataLength);

   dma_params->src[1] = ptr->dma_work_msg_64b.field2.NxtDataAddr1;
   dma_params->len_src[1] = dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength1);

   dma_params->src[2] = ptr->dma_work_msg_64b.field2.NxtDataAddr2;
   dma_params->len_src[2] = dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength2);

   dma_params->src[3] = ptr->dma_work_msg_64b.field3.linklist.NxtDataAddr3 ;
   dma_params->len_src[3] = dma_get_lendata(ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength3);
  print("===============================\n");
}


void dma_set_gather_scatter_linklist_memdest_64b(dma_work_msg_64b_ptr ptr, dma_params_ptr dma_params)
{
  unsigned long long PtrDestLL;
  unsigned int DataLength;

  unsigned long long PtrSrcLL;
  //  PtrSrcLL = dma_get_bufptrs_start_addr(dma_get_lendata(0x7000)); // 256B
    PtrSrcLL = dma_get_bufptrs_start_addr(dma_get_lendata(0x0000)); // 16K
    print("PtrSrcLL:");putnum_64(PtrSrcLL);print("\n");
    print("\n=====Set Gather LL Memedest ======\n");
    ptr->dma_work_msg_64b.field1.transfer.DR = 0;
    ptr->dma_work_msg_64b.field1.transfer.CTL = 0;
    ptr->dma_work_msg_64b.field1.transfer.FBY = 0;
    ptr->dma_work_msg_64b.field3.linklist.Ptr2SrcList = PtrSrcLL;	// dst add
  //  ptr->dma_work_msg_64b.field3.linklist.LinkSize = 3; // 7 Source
    ptr->dma_work_msg_64b.field3.linklist.LinkSize = 4; // 256 Source

    if(PtrSrcLL & 0xF) {
    PtrSrcLL = PtrSrcLL>>4;
    PtrSrcLL++;
    PtrSrcLL = PtrSrcLL<<4;
    print("PtrSrcLL:");putnum_64(PtrSrcLL);print("\n");
    }
    //ptr->dma_work_msg_64b.field3.linklist.Ptr2SrcList = PtrSrcLL;	// dst add
  //  dma_build_src_linklist(PtrSrcLL,3,128, ptr, dma_params);
    dma_build_src_linklist(PtrSrcLL,4,4, ptr, dma_params);
	DataLength = dma_get_lendata(ptr->dma_work_msg_64b.field0.BufDataLength)+
				 dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength1)+
				 dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength2)+
				 dma_get_lendata(ptr->dma_work_msg_64b.field3.linklist.NxtBufDataLength3)+ptr->dma_work_msg_64b.field1.transfer.TotDataLengthLinkListLSBs;

    printf("Total length Link list: %x\n",ptr->dma_work_msg_64b.field1.transfer.TotDataLengthLinkListLSBs);
    // Get information
    dma_params->src[0] = ptr->dma_work_msg_64b.field0.DataAddr;
    dma_params->len_src[0] = dma_get_lendata(ptr->dma_work_msg_64b.field0.BufDataLength);

    dma_params->src[1] = ptr->dma_work_msg_64b.field2.NxtDataAddr1;
    dma_params->len_src[1] = dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength1);

    dma_params->src[2] = ptr->dma_work_msg_64b.field2.NxtDataAddr2;
    dma_params->len_src[2] = dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength2);

    dma_params->src[3] = ptr->dma_work_msg_64b.field3.linklist.NxtDataAddr3 ;
    dma_params->len_src[3] = dma_get_lendata(ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength3);
    print("===============================\n");

  PtrDestLL = dma_get_bufptrs_start_addr(dma_get_lendata(0x0000)); // 256B
  PtrDestLL = PtrDestLL >>4;
  PtrDestLL++;
  ptr->dma_work_msg_64b.field1.transfer_dest_ll.PtrDestLL = PtrDestLL;	// dst add
  ptr->dma_work_msg_64b.field1.transfer_dest_ll.LinkSize = 8;
  dma_build_dest_linklist(PtrDestLL<<4,8,DataLength,dma_params);
  print("===============================\n");
}


void dma_set_gather_scatter_memdest_striding_linklist_64b(int SrcStridingSize, int SrcDistance, int DstStridingSize, int DstDistance, dma_work_msg_64b_ptr ptr,dma_params_ptr dma_params)
{
  unsigned long long PtrSrcLL;
  unsigned long long PtrDestLL;
  unsigned int DataLength;

  PtrSrcLL = dma_get_bufptrs_start_addr(dma_get_lendata(0x0000)); // 16kB
  print("\n=====Set Gather-Scatter Linklist Memedest With Striding ======\n");
  ptr->dma_work_msg_64b.field1.transfer.DR = 0;
  ptr->dma_work_msg_64b.field1.transfer.CTL = 8;
  ptr->dma_work_msg_64b.field1.transfer.FBY = 0;
  ptr->dma_work_msg_64b.field1.transfer.SrcStridingSize = SrcStridingSize;
  ptr->dma_work_msg_64b.field1.transfer.SrcDistance = SrcDistance;
  ptr->dma_work_msg_64b.field1.transfer.DstStridingSize = DstStridingSize;
  ptr->dma_work_msg_64b.field1.transfer.DstDistance = DstDistance;

  ptr->dma_work_msg_64b.field3.linklist.Ptr2SrcList = PtrSrcLL;	// dst add
    //  ptr->dma_work_msg_64b.field3.linklist.LinkSize = 3; // 7 Source
      ptr->dma_work_msg_64b.field3.linklist.LinkSize = 4; // 256 Source

      if(PtrSrcLL & 0xF) {
      PtrSrcLL = PtrSrcLL>>4;
      PtrSrcLL++;
      PtrSrcLL = PtrSrcLL<<4;
      print("PtrSrcLL:");putnum(PtrSrcLL);print("\n");
      }
      //ptr->dma_work_msg_64b.field3.linklist.Ptr2SrcList = PtrSrcLL;	// dst add
    //  dma_build_src_linklist(PtrSrcLL,3,128, ptr, dma_params);
      dma_build_src_linklist(PtrSrcLL,4,32, ptr, dma_params);
  	DataLength = dma_get_lendata(ptr->dma_work_msg_64b.field0.BufDataLength)+
  				 dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength1)+
  				 dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength2)+
  				 dma_get_lendata(ptr->dma_work_msg_64b.field3.linklist.NxtBufDataLength3)+ptr->dma_work_msg_64b.field1.transfer.TotDataLengthLinkListLSBs;

      printf("Total length Link list: %x\n",ptr->dma_work_msg_64b.field1.transfer.TotDataLengthLinkListLSBs);
      // Get information
      dma_params->src[0] = ptr->dma_work_msg_64b.field0.DataAddr;
      dma_params->len_src[0] = dma_get_lendata(ptr->dma_work_msg_64b.field0.BufDataLength);

      dma_params->src[1] = ptr->dma_work_msg_64b.field2.NxtDataAddr1;
      dma_params->len_src[1] = dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength1);

      dma_params->src[2] = ptr->dma_work_msg_64b.field2.NxtDataAddr2;
      dma_params->len_src[2] = dma_get_lendata(ptr->dma_work_msg_64b.field2.NxtBufDataLength2);

      dma_params->src[3] = ptr->dma_work_msg_64b.field3.linklist.NxtDataAddr3 ;
      dma_params->len_src[3] = dma_get_lendata(ptr->dma_work_msg_64b.field3.normal.NxtBufDataLength3);
      print("===============================\n");

    PtrDestLL = dma_get_bufptrs_start_addr(dma_get_lendata(0x0000)); // 256B
    PtrDestLL = PtrDestLL >>4;
    PtrDestLL++;
    ptr->dma_work_msg_64b.field1.transfer_dest_ll.PtrDestLL = PtrDestLL;	// dst add
    ptr->dma_work_msg_64b.field1.transfer_dest_ll.LinkSize = 8;
    dma_build_dest_linklist(PtrDestLL<<4,8,DataLength,dma_params);
    print("===============================\n");
}



void dma_get_params_from_64b_striding(dma_work_msg_64b_ptr ptr, dma_params_ptr ptr_params)
{

  ptr_params->SrcStridingSize = ptr->dma_work_msg_64b.field1.transfer.SrcStridingSize;
  ptr_params->SrcDistance = ptr->dma_work_msg_64b.field1.transfer.SrcDistance;
  ptr_params->DstStridingSize = ptr->dma_work_msg_64b.field1.transfer.DstStridingSize;
  ptr_params->DstDistance = ptr->dma_work_msg_64b.field1.transfer.DstDistance;
  ptr_params->BlkSize = ptr->dma_work_msg_64b.field1.dif.BlkSize;

}


