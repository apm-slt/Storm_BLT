/*
 * global.c
 *
 *  Created on: Jan 22, 2013
 *      Author: lxpham
 */

#include "../include/vPDMA_defines.h"
#include "../include/global.h"

/* Tinh: commented out below */
//Tinh-SLT:
#define putnum putnum_pdma_copy
#define print print_pdma_copy
#define read read_pdma_copy
#define write write_pdma_copy
#define read_64 read_64_pdma_copy
#define write_64 write_64_pdma_copy
#define reg_dump reg_dump_pdma_copy
#define mem_dump mem_dump_pdma_copy
#define mem_dump_64 mem_dump_64_pdma_copy
#define msg_dump msg_dump_pdma_copy
#define mdump mdump_pdma_copy
//End of Tinh-SLT

/*
void *mem_set(void *s, int c, int n)
{
    unsigned char* p=s;
    while(n--)
        *p++ = (unsigned char)c;
    return s;
}
*/

void putnum(unsigned int num) {
  printf("%08x", num);
  return;
}

void putnum_64(unsigned long num) {
  printf("%09x", num);
  return;
}

void print (const char* str) {
  printf(str);
  return;
}
int read(unsigned int *address){
  unsigned int *addr_int;
  int rdata;
  addr_int = address;
  rdata = *addr_int;
	print("Read32  @ 0x:"); putnum(addr_int); print(" is 0x");  putnum(rdata);  print("\n\r");
	return(rdata);
}

void write(unsigned int *address, int data){
  unsigned int *addr_int;
  addr_int = address;
	*addr_int = data;
	print("Write32 @ 0x:"); putnum(address); print(" is 0x");  putnum(data);  print("\n\r");
}


int read_64(unsigned long *address){
  unsigned long *addr_int;
  unsigned long rdata;
  addr_int = address;
  rdata = *addr_int;
	print("Read64  @ 0x:"); putnum_64(addr_int); print(" is 0x");  putnum_64(rdata);  print("\n\r");
	return(rdata);
}
void write_64(unsigned long *address, unsigned long data){
  unsigned long *addr_int;
  addr_int = address;
	*addr_int = data;
	print("Write64 @ 0x:"); putnum_64(address); print(" is 0x");  putnum_64(data);  print("\n\r");
}


void reg_dump(unsigned int addr, unsigned int wordcount)
{

	int i;
	 unsigned int *address;
	address =(unsigned int*)addr;
	if(!wordcount){
		printf("Invalid size\n");
	}
	for(i=0;i<wordcount;i++){
		if(!(i%4)){
			if(i>0) 	printf("\n");
			printf("%08x:  ",address+i);
		}
		printf("0x%08x    ",*(address+i));
	}
	printf("\n");
}

/*Memdump pass value*/
void mem_dump(unsigned int addr, unsigned int wordcount)
{

	int i;
	 unsigned int *address;
	address =(unsigned int*)addr;
	if(!wordcount){
		printf("Invalid size\n");
	}
	for(i=0;i<wordcount;i++){
		if(!(i%4)){
			if(i>0) 	printf("\n");
			printf("%08x:  ",address+i);
		}
		printf("0x%08x    ",*(address+i));
	}
	printf("\n");
}
/*Memdump pass value*/
void mem_dump_64(u64 addr, unsigned int wordcount)
{

	int i;
	 u64 *address;
	address =(u64*)addr;
	if(!wordcount){
		printf("Invalid size\n");
	}
	for(i=0;i<wordcount;i++){
		if(!(i%4)){
			if(i>0) 	printf("\n");
			printf("%16x:  ",address+i);
		}
		printf("0x%08x    ",*(address+i));
	}
	printf("\n");
}

void msg_dump(u32* addr, u32 size) {
	u32 *ptr,*end_addr;
	u32 word0,word1;
	int error = 0;
	end_addr = (u32*) addr+size;
	ptr = addr;
	while(ptr<end_addr) {
		printf("0x%08x:\t0x%08x_0x%08x:\n",ptr,*ptr++,*ptr++);
	}
}

/*memdump pass poiter*/
void mdump(u32* addr, u32 size) {
	u32* ptr,end_addr;
	int error = 0;
	end_addr = (u32*) addr+size;
	ptr = addr;
	while(ptr<end_addr) {
		printf("0x%08x:\t",ptr);
		printf("0x%08x\t0x%08x\t0x%08x\t0x%08x\n",*ptr++,*ptr++,*ptr++,*ptr++);
	}
}

