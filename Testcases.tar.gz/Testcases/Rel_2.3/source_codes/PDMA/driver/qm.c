/*
 * qm.c
 *
 *  Created on: May 5, 2014
 *      Author: lxpham
 */


#include "../include/qm.h"


//Tinh-SLT:
//function call
#define write write_pdma_copy
#define print print_pdma_copy
#define putnum putnum_pdma_copy
#define read read_pdma_copy
//End of Tinh-SLT


unsigned int enq_ptr[16];
unsigned int deq_ptr[16];
unsigned int alloted_fptr_num = 0;
unsigned int num_alt_enq_cmd = 0;
unsigned int alt_enq_qid[32];
unsigned int alt_enq_num[32];
pq_fp_state_t q_state[16];
//unsigned int m = 4294967295;
//unsigned int a = 1664525;
//unsigned int c = 1013904223;
//unsigned int Xn;

//unsigned int Xn;

unsigned int my_deq_ptr[16];

/*Function Prototype*/
/*********************************************************************************************************************************/

void fp_qstate_init(int qid) {
  pq_fp_state_t fp_state;
  q_state_t     intstream;
  int q_type ;
  int q_size;
  int st_addr;
  int n_msg ;
  int fp_mode;

  print("\n=====fp_qstate_init start ======\n");

  // Formation of Queue state data
  q_type = 2;
  q_size = get_queue_size_code(MAX_QUEUE_SIZE);
  fp_mode = 2;
  st_addr = ((Q_START_ADDR + (MAX_QUEUE_SIZE * qid)) >> 8);
  n_msg = 0;
  fp_state.q_type = q_type;
  fp_state.q_size = q_size;
  fp_state.st_addr = st_addr;
  fp_state.n_msg = n_msg;
  fp_state.fp_mode = fp_mode;

  WRITE32((QM_CSR_BASE_ADDR + CSR_QSTATE_ADDR), qid);
  WRITE32((QM_CSR_BASE_ADDR + CSR_QSTATE_WR_0_ADDR), 0x00000000);
  WRITE32((QM_CSR_BASE_ADDR + CSR_QSTATE_WR_1_ADDR), (n_msg << 1));
  WRITE32((QM_CSR_BASE_ADDR + CSR_QSTATE_WR_2_ADDR), st_addr << 5);
  WRITE32((QM_CSR_BASE_ADDR + CSR_QSTATE_WR_3_ADDR), ((q_size << 23) | (fp_mode << 20) | (st_addr >> 27) ));
  WRITE32((QM_CSR_BASE_ADDR + CSR_QSTATE_WR_4_ADDR), (q_type << 19));

  q_state[qid] = fp_state;

  print("\n=====fp_qstate_init end ======\n");
}

void wq_qstate_init(int qid) {
  pq_fp_state_t wq_state;
  q_state_t     intstream;
  int q_type ;
  int q_size;
  int st_addr;
  int lerr_ok;
  print("\n=====wq_qstate_init start ======\n");

  // Formation of Queue state data
  q_type = 1;
  q_size = get_queue_size_code(MAX_QUEUE_SIZE);
  lerr_ok = 0;
  st_addr = ((Q_START_ADDR + (MAX_QUEUE_SIZE * qid)) >> 8);
  wq_state.q_type = q_type;
  wq_state.q_size = q_size;

  wq_state.st_addr = st_addr;
  wq_state.lerr_ok = lerr_ok;


//  WRITE32((QM_CSR_BASE_ADDR + CSR_QSTATE_ADDR), qid);
//  WRITE32((QM_CSR_BASE_ADDR + CSR_QSTATE_WR_0_ADDR), 0x00000000);
//  WRITE32((QM_CSR_BASE_ADDR + CSR_QSTATE_WR_1_ADDR), 0x00000000);
//  WRITE32((QM_CSR_BASE_ADDR + CSR_QSTATE_WR_2_ADDR), st_addr << 5|0x10);
//  WRITE32((QM_CSR_BASE_ADDR + CSR_QSTATE_WR_3_ADDR), ((q_size << 23) | (lerr_ok << 19 )| (st_addr >> 27) ));
//  WRITE32((QM_CSR_BASE_ADDR + CSR_QSTATE_WR_4_ADDR), (q_type << 19));

  write((QM_CSR_BASE_ADDR + CSR_QSTATE_ADDR), qid);
  write((QM_CSR_BASE_ADDR + CSR_QSTATE_WR_0_ADDR), 0x00000000);
  write((QM_CSR_BASE_ADDR + CSR_QSTATE_WR_1_ADDR), 0x00000000);
  write((QM_CSR_BASE_ADDR + CSR_QSTATE_WR_2_ADDR), (st_addr << 5)|0x10);
//  write((QM_CSR_BASE_ADDR + CSR_QSTATE_WR_2_ADDR),st_addr << 5);
  write((QM_CSR_BASE_ADDR + CSR_QSTATE_WR_3_ADDR), ((q_size << 23) | (lerr_ok << 19 )| (st_addr >> 27) ));
  write((QM_CSR_BASE_ADDR + CSR_QSTATE_WR_4_ADDR), (q_type << 19));




  q_state[qid] = wq_state;




  print("\n===== wq_qstate_init end ======\n");

}

void data_ptr_init(int qid, int num_of_ptr) {
  msg_16b_field_0_t  data_ptr;
  msg_16b_t          intstream;
  int              i, j;
  unsigned long long         data_ptr_addr;
  int                alt_enq_addr;

  print("\n===== data_ptr_init start ======\n");

  for(i = 0; i < num_of_ptr; i++) {
    // formation of data pointer
    data_ptr.BufDataLength = 0x5000;
    data_ptr.DataAddr = BUFPTRS_START_ADDR + (2048 * alloted_fptr_num);
    putnum(data_ptr.DataAddr);print("\n\r");
    data_ptr.FPQNum = (0x3 << 10) | qid;
    data_ptr.UserInfo = 0xdadacafe;
    // for ctm+enet1g
    data_ptr.PB = 1;
    data_ptr.HB = 0;

    intstream.field0 = data_ptr;

    data_ptr_addr = ((q_state[qid].st_addr << 8) + (i * 16));

    alloted_fptr_num++;
    for(j=0; j < 4; j++) WRITE32(data_ptr_addr + j*4, intstream.raw[j]);
    enq_ptr[qid] +=16;
  }

  if (num_alt_enq_cmd == 0xFF) {
    //Directly send alt_enq_cmd
    alt_enq_addr = ( QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x2C);
    WRITE32(alt_enq_addr, num_of_ptr);
  }
  else {
    // Queue up alt_enq_cmd
    alt_enq_qid[num_alt_enq_cmd] = qid;
    alt_enq_num[num_alt_enq_cmd] = num_of_ptr;
    num_alt_enq_cmd++;
  }

  print("\n===== data_ptr_init end ======\n");
}



void enqueue_msg(int qid, int fpqnum, int henqnum, int hfpsel) {
  msg_16b_field_0_t  enq_msg0;
  msg_16b_field_1_t  enq_msg1;
  msg_16b_t          intstream;
  int                i;
  int                alt_enq_addr;

  print("\n===== enqueue_msg start ======\n");
  // Form enqueue message
  enq_msg0.BufDataLength = 0x5000;
  enq_msg0.DataAddr = BUFPTRS_START_ADDR + (2048 * alloted_fptr_num);
  enq_msg0.FPQNum = (0x3 << 10) | fpqnum;
  enq_msg0.UserInfo = 0xbabacafe;
  enq_msg1.HFPSel = (0x3 << 10) | hfpsel;
  enq_msg1.HEnqNum = (0x3 << 10) |  henqnum;

  alloted_fptr_num++;
  // Pack & Write
  intstream.field0 = enq_msg0;
  for(i=0; i< 4; i++) {
    WRITE32(((1<< 31) + ((Q_START_ADDR + (0x800 * qid))) + enq_ptr[qid]), intstream.raw[i]);
    enq_ptr[qid] += 4;
  }
  intstream.field1 = enq_msg1;
  for(i=0; i< 4; i++) {
    WRITE32(((1<< 31) + ((Q_START_ADDR + (0x800 * qid))) + enq_ptr[qid]), intstream.raw[i]);
    enq_ptr[qid] += 4;
  }

  // Alt enqueue command for QM
  alt_enq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x2C);
  WRITE32(alt_enq_addr, 0x1);
  print("\n===== enqueue_msg end ======\n");
}

// For CTM

void enqueue_msg_ctm(int qid, int fpqnum, int henqnum, int hfpsel, int bufdatalen, int bufaddr, int pb, int hb) {
  msg_16b_field_0_t  enq_msg0;
  msg_16b_field_1_t  enq_msg1;
  msg_16b_t          intstream[2];
  int                i;
  int                alt_enq_addr;

  print("===== enqueue_msg start ======\n\r");
  // Form enqueue message
  enq_msg0.BufDataLength = bufdatalen;
  enq_msg0.DataAddr = bufaddr;
  enq_msg0.FPQNum = (0x3 << 10) | fpqnum;
  enq_msg0.UserInfo = 0xbabacafe;
  enq_msg0.PB = pb;
  enq_msg0.HB = hb;
  enq_msg0.HL = 0;
  enq_msg0.LErr = 0;
  enq_msg0.LEI = 0;
  enq_msg0.ELErr = 0;
  enq_msg0.NV = 0;
  enq_msg0.LL = 0;
  enq_msg1.HFPSel = hfpsel;
  enq_msg1.HEnqNum = (0x3 << 10) |  henqnum;
  enq_msg1.HR = 1;

  print ("DDR Data Start Address:");putnum(enq_msg0.DataAddr);print("\n\r");
  // Write DDR area (mimic'ed in OCM) with Data.
/*  for (i=0; i<2048; i=i+4) {
//    print ("i:");putnum(i);print("\n\r");
    write((enq_msg0.DataAddr+i)|(0x80000000), i);
  };*/

  // Pack & Write
  intstream[0].field0 = enq_msg0;
  intstream[1].field1 = enq_msg1;
  write_enqueue_msg(qid, 32, &intstream[0]);
  print("===== enqueue_msg end ======\n\r");
}


/*
void enqueue_msg_copy(int qid, int fpqnum, int henqnum, int hfpsel, int bufdatalen, int bufaddr, int pb, int hb) {
  msg_16b_field_0_t  enq_msg0;
  msg_16b_field_1_t  enq_msg1;
  msg_16b_t          intstream;
  int                i;
  int                alt_enq_addr;

  print("===== COPY enqueue_msg start ======\n\r");
  // Form enqueue message
  enq_msg0.BufDataLength = 0x5100;
  enq_msg0.DataAddr = BUFPTRS_START_ADDR + (2048 * alloted_fptr_num);
  enq_msg0.FPQNum = (0x3 << 10) | fpqnum;
  enq_msg0.UserInfo = 0xbabacafe;
  enq_msg0.PB = pb;
  enq_msg0.HB = hb;

  enq_msg1.HFPSel = hfpsel;
  enq_msg1.HEnqNum = (0x3 << 10) | henqnum;
  enq_msg1.DR = 1;
  enq_msg1.HopInfoLSBs = BUFPTRS_START_ADDR + 1024 + (256 * alloted_fptr_num);	// dst add

  print ("DDR Data Start Address:");putnum(enq_msg0.DataAddr);print("\n\r");
  // Write DDR area (mimic'ed in OCM) with Data.
  for (i=0; i<2048; i=i+4) {
    print ("i:");putnum(i);print("\n\r");
    write((enq_msg0.DataAddr+i)|(0x80000000), i);
  };

  alloted_fptr_num++;
  // Pack & Write
  intstream.field0 = enq_msg0;
  for(i=0; i< 4; i++) {
    write(((1<< 31) + ((OCM_BASE_ADDR + (0x800 * qid))) + enq_ptr[qid]), intstream.raw[i]);
    enq_ptr[qid] += 4;
  }

  intstream.field1 = enq_msg1;
  for(i=0; i< 4; i++) {
    write(((1<< 31) + ((OCM_BASE_ADDR + (0x800 * qid))) + enq_ptr[qid]), intstream.raw[i]);
    enq_ptr[qid] += 4;
  }

  // Alt enqueue command for QM
  alt_enq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x2C);
  write(alt_enq_addr, 0x1);
  print("===== enqueue_msg end ======\n\r");
}
*/

void enqueue_msg_gather(int qid, int fpqnum, int henqnum, int hfpsel, int bufdatalen, int bufaddr, int pb, int hb) {
  msg_16b_field_0_t  enq_msg0;
  msg_16b_field_1_t  enq_msg1;
  msg_16b_field_2_t  enq_msg2;
  msg_16b_field_3_t  enq_msg3;
  msg_16b_t          intstream;
  msg_16b_field_0_t  fp_msg0;
  int                i;
  int                alt_enq_addr;
  int                alt_deq_addr;

  print("===== enqueue_msg start ======\n\r");
  // Form enqueue message
  enq_msg0.BufDataLength = 0x5100;
  enq_msg0.DataAddr = BUFPTRS_START_ADDR + (2048 * alloted_fptr_num);
  enq_msg0.FPQNum = (0x3 << 10) | fpqnum;
  enq_msg0.UserInfo = 0xabcdabcd;
  enq_msg0.PB = pb;
  enq_msg0.HB = hb;
  enq_msg0.NV = 1;

  enq_msg1.HFPSel = hfpsel;
  enq_msg1.HEnqNum = (0x3 << 10) | henqnum;
  enq_msg1.DR = 1;
  enq_msg1.HopInfoLSBs = BUFPTRS_START_ADDR + 2048 + (256 * alloted_fptr_num);	// dst add

  enq_msg2.NxtDataAddr1      = BUFPTRS_START_ADDR + 256 + (2048 * alloted_fptr_num);
  enq_msg2.NxtBufDataLength1 = 0x5100;
  enq_msg2.NxtDataAddr2      = BUFPTRS_START_ADDR + 512 + (2048 * alloted_fptr_num);
  enq_msg2.NxtBufDataLength2 = 0x5100;

  enq_msg3.NxtDataAddr3      = BUFPTRS_START_ADDR + 768 + (2048 * alloted_fptr_num);
  enq_msg3.NxtBufDataLength3 = 0x5100;
  enq_msg3.NxtDataAddr4      = BUFPTRS_START_ADDR + 1024 + (2048 * alloted_fptr_num);
  enq_msg3.NxtBufDataLength4 = 0x5100;


  print ("Data Start Address:");putnum(enq_msg0.DataAddr);print("\n\r");
  // Write DDR area (mimic'ed in OCM) with Data.
  for (i=0; i<2048; i=i+4) {
    print ("i:");putnum(i);print("\n\r");
    write((enq_msg0.DataAddr+i)|(0x80000000), i);
  };

  alloted_fptr_num++;
  // Pack & Write
  intstream.field0 = enq_msg0;
  for(i=0; i< 4; i++) {
    write(((1<< 31) + ((OCM_BASE_ADDR + (0x800 * qid))) + enq_ptr[qid]), intstream.raw[i]);
    enq_ptr[qid] += 4;
  }

  intstream.field1 = enq_msg1;
  for(i=0; i< 4; i++) {
    write(((1<< 31) + ((OCM_BASE_ADDR + (0x800 * qid))) + enq_ptr[qid]), intstream.raw[i]);
    enq_ptr[qid] += 4;
  }

  // Alt enqueue command for QM
  alt_enq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x2C);
  write(alt_enq_addr, 0x1);
  print("===== enqueue_msg end ======\n\r");

  intstream.field2 = enq_msg2;
  for(i=0; i< 4; i++) {
    write(((1<< 31) + ((OCM_BASE_ADDR + (0x800 * qid))) + enq_ptr[qid]), intstream.raw[i]);
    enq_ptr[qid] += 4;
  }

  print("=========== De-Alloc Information ===============\n\r");
  print("FPQNum = ");putnum(qid);print("\n\r");
  print("DataAddr = ");putnum(enq_msg0.DataAddr);print("\n\r");
  print("BufDataLength = ");putnum(enq_msg0.BufDataLength );print("\n\r");

  print("\n\r==========write_dealloc_msg start===========\n\r");
  // Read status of Queue
  alt_enq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x04);
  read(alt_enq_addr);
  fp_msg0.BufDataLength = enq_msg0.BufDataLength ;
  fp_msg0.DataAddr = enq_msg0.DataAddr;
  fp_msg0.FPQNum = (0x3 << 10) | qid;
  fp_msg0.UserInfo = 0xdadacafe;

  // Alt enqueue command for QM
  alt_enq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x2C);
  write(alt_enq_addr, 0x1);
  print("===== enqueue_msg end ======\n\r");
}

void enqueue_msg_scatter(int qid, int fpqnum, int henqnum, int hfpsel, int bufdatalen, int bufaddr, int pb, int hb) {
  msg_16b_field_0_t  enq_msg0;
  msg_16b_field_1_t  enq_msg1;
  msg_16b_t          intstream;
  int                i;
  int                alt_enq_addr;
  int                alt_deq_addr;

  print("===== SCATTER enqueue_msg start ======\n\r");
  // Form enqueue message
  enq_msg0.BufDataLength = 0x5100;
  enq_msg0.DataAddr = BUFPTRS_START_ADDR + (2048 * alloted_fptr_num);
  //enq_msg0.DataAddr = BUFPTRS_START_ADDR ;
  enq_msg0.FPQNum = (0x3 << 10) | fpqnum;
  enq_msg0.UserInfo = 0xbabacafe;
  enq_msg0.PB = pb;
  enq_msg0.HB = hb;

  print("\n\r==========read_alloc_msg start===========\n\r");
  // Read status of Queue
  alt_deq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x04);
  read(alt_deq_addr);

  print ("Prepare Link List");print("\n\r");
  write((enq_msg0.DataAddr + 1024) , (0x5100 << 48 | ((BUFPTRS_START_ADDR + 1024 + 32) + (2048 * alloted_fptr_num))));  // 1st Scatter at Dst Start_add + 32
  write((enq_msg0.DataAddr + 1028) , (0x5100 << 48 | ((BUFPTRS_START_ADDR + 1024 + 288) + (2048 * alloted_fptr_num))));  // 2nd Scatter
  write((enq_msg0.DataAddr + 1032) , (0x5100 << 48 | ((BUFPTRS_START_ADDR + 1024 + 544) + (2048 * alloted_fptr_num))));  // 3rd Scatter
  write((enq_msg0.DataAddr + 1036) , (0x5100 << 48 | ((BUFPTRS_START_ADDR + 1024 + 800) + (2048 * alloted_fptr_num))));  // 4th Scatter


  print ("Data Start Address:");putnum(enq_msg0.DataAddr);print("\n\r");
  // Write DDR area (mimic'ed in OCM) with Data.
  for (i=32; i<2024; i=i+4) {
    print ("i:");putnum(i);print("\n\r");
    write((enq_msg0.DataAddr+i)|(0x80000000), i);
  };

  // Alt decrement cmd for QM
  alt_deq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x2C);
  WRITE32(alt_deq_addr, 0xFFFFFFFF);
  // Read status of Queue
  alt_deq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x04);
  read(alt_deq_addr);
  print("\n\r====== read_alloc_msg end===================\n\r");
}





void enqueue_msg_dma(int qid, int fpqnum, int henqnum, int hfpsel, int bufdatalen, int bufaddr, int pb, int hb) {
  msg_16b_field_0_t  enq_msg0;
  msg_16b_field_1_t  enq_msg1;
  msg_16b_t          intstream;
  int                i;
  int                alt_enq_addr;

  print("===== enqueue_msg start ======\n\r");
  // Form enqueue message
  enq_msg0.BufDataLength = 0x5100;
  enq_msg0.DataAddr = BUFPTRS_START_ADDR + (2048 * alloted_fptr_num);
  enq_msg0.FPQNum = (0x3 << 10) | fpqnum;
  enq_msg0.UserInfo = 0xbabacafe;
  enq_msg0.PB = pb;
  enq_msg0.HB = hb;
  enq_msg1.HFPSel = hfpsel;
  enq_msg1.HEnqNum = (0x3 << 10) |  henqnum;
  enq_msg1.DR = 1;
  enq_msg1.HopInfoLSBs = BUFPTRS_START_ADDR + 1024 + (256 * alloted_fptr_num);	// dst add

  print ("DDR Data Start Address:");putnum(enq_msg0.DataAddr);print("\n\r");
  // Write DDR area (mimic'ed in OCM) with Data.
  for (i=0; i<2048; i=i+4) {
    print ("i:");putnum(i);print("\n\r");
    write((enq_msg0.DataAddr+i)|(0x80000000), i);
  };

  alloted_fptr_num++;
  // Pack & Write
  intstream.field0 = enq_msg0;
  for(i=0; i< 4; i++) {
    write(((1<< 31) + ((OCM_BASE_ADDR + (0x800 * qid))) + enq_ptr[qid]), intstream.raw[i]);
    enq_ptr[qid] += 4;
  }
  intstream.field1 = enq_msg1;

  for(i=0; i< 4; i++) {
    write(((1<< 31) + ((OCM_BASE_ADDR + (0x800 * qid))) + enq_ptr[qid]), intstream.raw[i]);
    enq_ptr[qid] += 4;
  }

  // Alt enqueue command for QM
  alt_enq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x2C);
  write(alt_enq_addr, 0x1);
  print("===== enqueue_msg end ======\n\r");
}





void write_enq_msg(int qid) {
  msg_16b_field_0_t  enq_msg0;
  msg_16b_field_1_t  enq_msg1;
  msg_16b_t        intstream;
  int              i;
  int              alt_enq_addr;

  print("\n===== write_enq_msg start ======\n");
  // Form enqueue message
  enq_msg0.BufDataLength = 0x5000;
  enq_msg0.DataAddr = BUFPTRS_START_ADDR + (2048 * alloted_fptr_num);
  enq_msg0.HB = 1;
  enq_msg0.FPQNum = (0x3 << 10) | FPQID0;
  enq_msg0.UserInfo = 0xbabacafe;
  enq_msg1.HFPSel = (0x3 << 10) | FPQID1;
  enq_msg1.HEnqNum = (0x3 << 10) |  WQID0;

  alloted_fptr_num++;

  // Pack & Write
  intstream.field0 = enq_msg0;
  for(i=0; i< 4; i++) {
    WRITE32(((1<< 31) + ((OCM_BASE_ADDR + (0x800 * qid))) + enq_ptr[qid]), intstream.raw[i]);
    enq_ptr[qid] += 4;
  }
  intstream.field1 = enq_msg1;
  for(i=0; i< 4; i++) {
    WRITE32(((1<< 31) + ((OCM_BASE_ADDR + (0x800 * qid))) + enq_ptr[qid]), intstream.raw[i]);
    enq_ptr[qid] += 4;
  }

  // Alt enqueue command for QM
  alt_enq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x2C);
  WRITE32(alt_enq_addr, 0x1);
  print("\n===== write_enq_msg end ======\n");
}

void write_dealloc_msg(int qid, unsigned long long DataAddr, int BufSize) {
  msg_16b_field_0_t fp_msg0;
  msg_16b_t         intstream;
  int               i;
  int               alt_enq_addr;

  print("=========== De-Alloc Information ===============\n\r");
  print("FPQNum = ");putnum(qid);print("\n\r");
  print("DataAddr = ");putnum(DataAddr);print("\n\r");
  print("BufDataLength = ");putnum(BufSize);print("\n\r");

  print("\n\r==========write_dealloc_msg start===========\n\r");
  // Read status of Queue
  alt_enq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x04);
  read(alt_enq_addr);
  fp_msg0.BufDataLength = BufSize;
  fp_msg0.DataAddr = DataAddr;
  fp_msg0.FPQNum = ((0x3 << 10) | qid) & (0xFFF);
  fp_msg0.FPQNum = (fp_msg0.FPQNum) & 0x00000FFF;
  putnum(fp_msg0.FPQNum);print("\n\r");
  fp_msg0.PB = 0x1;
  fp_msg0.HB = 0x0;
  fp_msg0.UserInfo = 0xdadacafe;

  //Pack & Write
  intstream.field0 = fp_msg0;
  for (i=0; i<4; i++) {
    write(((1<<31) + ((OCM_BASE_ADDR + (0x800 * qid))) + enq_ptr[qid]), intstream.raw[i]);
    enq_ptr[qid] += 4;
  }

  if (enq_ptr[qid] == 0x800)
    enq_ptr[qid] = 0; //Roll back after 2kb limit

  // Alt alloc cmd for QM
  alt_enq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x2C);
  WRITE32(alt_enq_addr, 0x1);
  // Read status of Queue
  alt_enq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x04);
  read(alt_enq_addr);
  print("\n\r====== write_dealloc_msg end===================\n\r");
}

// SMV:

void write_dealloc_msg_ll(msg_16b_field_0_t fp_msg0, int qid) {
  // msg_16b_field_0_t fp_msg0;
  msg_16b_t         intstream;
  int               i;
  int               alt_enq_addr;

  print("=========== LL De-Alloc Information ===============\n\r");
  print("FPQNum = ");putnum(fp_msg0.FPQNum);print("\n\r");
  print("DataAddr = ");putnum(fp_msg0.DataAddr);print("\n\r");
  print("BufDataLength = ");putnum(fp_msg0.BufDataLength);print("\n\r");

  print("\n\r==========write_dealloc_msg_ll start===========\n\r");
  // Read status of Queue
  alt_enq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x04);
  read(alt_enq_addr);

  //Pack & Write
  intstream.field0 = fp_msg0;
  for (i=0; i<4; i++) {
    write(((1<<31) + ((OCM_BASE_ADDR + (0x800 * qid))) + enq_ptr[qid]), intstream.raw[i]);
    enq_ptr[qid] += 4;
  }

  if (enq_ptr[qid] == 0x800)
    enq_ptr[qid] = 0; //Roll back after 2kb limit

  // Alt alloc cmd for QM
  alt_enq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x2C);
  WRITE32(alt_enq_addr, 0x1);
  // Read status of Queue
  alt_enq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x04);
  read(alt_enq_addr);
  print("\n\r====== write_dealloc_msg_ll end===================\n\r");
}
// SMV

void read_alloc_msg(int qid, unsigned long *DataAddr,int* BufSize) {
  static  int  deq_local_ptr[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
  msg_16b_field_0_t fp_msg0;
  msg_16b_t         intstream;
  int               i;
  int               alt_deq_addr;

  print("\n\r==========read_alloc_msg start===========\n\r");
  // Read status of Queue
  alt_deq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x04);
  read(alt_deq_addr);

  //Read
  for (i=0; i<4; i++) {
    intstream.raw[i] = READ32((1<<31) + ((OCM_BASE_ADDR + (0x800 * qid))) + deq_local_ptr[qid]);
    deq_local_ptr[qid] +=4;
  }

  if (deq_local_ptr[qid] == 0x800)
    deq_local_ptr[qid] = 0; //Roll back after 2kb limit

  //Unpack
  *BufSize = intstream.field0.BufDataLength;
  *BufSize &= 0x7FFF;
  *DataAddr = intstream.field0.DataAddr;

  // Alt decrement cmd for QM
  alt_deq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x2C);
  WRITE32(alt_deq_addr, 0xFFFFFFFF);
  // Read status of Queue
  alt_deq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x04);
  read(alt_deq_addr);
  print("\n\r====== read_alloc_msg end===================\n\r");
}

// SMV: Get the address and length for re-constructing the message.
// Decrement message wouldn't be sent to the queue.

void dummy_alloc_msg(int qid, unsigned long *DataAddr,int* BufSize, int msg_no) {
  static  int  deq_local_ptr[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
  msg_16b_field_0_t fp_msg0;
  msg_16b_t         intstream;
  int               i;
  int               alt_deq_addr;
  int msg_num;

  msg_num = msg_no;

  print("\n\r========== dummy_alloc_msg start ===========\n\r");

  //Read
  for (i=0; i<4; i++) {
    print("Queue Number = ");putnum(qid);print("msg_num = ");putnum(msg_num);
    intstream.raw[i] = READ32((1<<31) + ((OCM_BASE_ADDR + (0x800 * qid))) + msg_num);
    msg_num +=4;
  }

  if (msg_num == 0x800)
    msg_num = 0; //Roll back after 2kb limit

  //Unpack
  *BufSize = intstream.field0.BufDataLength;
  *BufSize &= 0x7FFF;
  *DataAddr = intstream.field0.DataAddr;
  print("\n\r====== dummy_alloc_msg end ===================\n\r");
}


void write_enqueue_msg(int qid, int size, msg_16b_t enq_msg[]) {
  msg_16b_field_0_t fp_msg0;
  msg_16b_t         intstream;
  int               i;
  int               alt_enq_addr;

  print("\n\r==========write_enqueue_msg start===========\n\r");
  // Read status of Queue
  alt_enq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x04);
  read(alt_enq_addr);
  for(i=0; i< 4; i++) {
//    WRITE32(((1<< 31) + ((OCM_BASE_ADDR + (0x800 * qid))) + enq_ptr[qid]), enq_msg[0].raw[i]);
    write(((1<< 31) + ((OCM_BASE_ADDR + (0x800 * qid))) + enq_ptr[qid]), enq_msg[0].raw[i]);
    enq_ptr[qid] += 4;
  }

  for(i=0; i< 4; i++) {
//    WRITE32(((1<< 31) + ((OCM_BASE_ADDR + (0x800 * qid))) + enq_ptr[qid]), enq_msg[1].raw[i]);
    write(((1<< 31) + ((OCM_BASE_ADDR + (0x800 * qid))) + enq_ptr[qid]), enq_msg[1].raw[i]);
    enq_ptr[qid] += 4;
  }

  if (enq_ptr[qid] == 0x800)
    enq_ptr[qid] = 0; //Roll back after 2kb limit

  if (size == 32) {
    // Alt enqueue command for QM
    alt_enq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x2C);
    WRITE32(alt_enq_addr, 0x1);
  // Read status of Queue
  alt_enq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x04);
  read(alt_enq_addr);
  print("\n\r==========write_enqueue_msg32 stop===========\n\r");
  }
  else {
    for(i=0; i< 4; i++) {
//      WRITE32(((1<< 31) + ((OCM_BASE_ADDR + (0x800 * qid))) + enq_ptr[qid]), enq_msg[2].raw[i]);
      write(((1<< 31) + ((OCM_BASE_ADDR + (0x800 * qid))) + enq_ptr[qid]), enq_msg[2].raw[i]);
      enq_ptr[qid] += 4;
    }

    for(i=0; i< 4; i++) {
//      WRITE32(((1<< 31) + ((OCM_BASE_ADDR + (0x800 * qid))) + enq_ptr[qid]), enq_msg[3].raw[i]);
      write(((1<< 31) + ((OCM_BASE_ADDR + (0x800 * qid))) + enq_ptr[qid]), enq_msg[3].raw[i]);
      enq_ptr[qid] += 4;
    }

    if (enq_ptr[qid] == 0x800)
      enq_ptr[qid] = 0; //Roll back after 2kb limit

    // Alt enqueue command for QM
    alt_enq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x2C);
    WRITE32(alt_enq_addr, 0x2);
  // Read status of Queue
  alt_enq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x04);
  read(alt_enq_addr);
  print("\n\r==========write_enqueue_msg64 stop===========\n\r");
  }
}

void read_dequeue_msg(int qid, int* size, msg_16b_t* deq_msg) {
  static  int  deq_local_ptr[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
  msg_16b_t         intstream;
  int               i;
  int               alt_deq_addr;

  print("\n\r==========read_dequeue_msg start===========\n\r");
  // Read status of Queue
  alt_deq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x04);
  read(alt_deq_addr);

  //Read
  for (i=0; i<4; i++) {
//    intstream.raw[i] = READ32((1<<31) + ((OCM_BASE_ADDR + (0x800 * qid))) + deq_local_ptr[qid]);
    intstream.raw[i] = read((1<<31) + ((OCM_BASE_ADDR + (0x800 * qid))) + deq_local_ptr[qid]);
    deq_local_ptr[qid] +=4;
  }
  //Unpack
  deq_msg[0].field0 = intstream.field0;

  //Read
  for (i=0; i<4; i++) {
//    intstream.raw[i] = READ32((1<<31) + ((OCM_BASE_ADDR + (0x800 * qid))) + deq_local_ptr[qid]);
    intstream.raw[i] = read((1<<31) + ((OCM_BASE_ADDR + (0x800 * qid))) + deq_local_ptr[qid]);
    deq_local_ptr[qid] +=4;
  }
  //Unpack
  deq_msg[1].field1 = intstream.field1;

  if (deq_local_ptr[qid] == 0x800)
    deq_local_ptr[qid] = 0; //Roll back after 2kb limit

  print("\n\r");
  putnum(deq_msg[0].field0.NV);
  print("\n\r");
  //If NV == 1, read 64bytes
  if (deq_msg[0].field0.NV != 0) {
    //Read
    for (i=0; i<4; i++) {
//      intstream.raw[i] = READ32((1<<31) + ((OCM_BASE_ADDR + (0x800 * qid))) + deq_local_ptr[qid]);
      intstream.raw[i] = read((1<<31) + ((OCM_BASE_ADDR + (0x800 * qid))) + deq_local_ptr[qid]);
      deq_local_ptr[qid] +=4;
    }
    //Unpack
    deq_msg[2].field2 = intstream.field2;

    //Read
    for (i=0; i<4; i++) {
//      intstream.raw[i] = READ32((1<<31) + ((OCM_BASE_ADDR + (0x800 * qid))) + deq_local_ptr[qid]);
      intstream.raw[i] = read((1<<31) + ((OCM_BASE_ADDR + (0x800 * qid))) + deq_local_ptr[qid]);
      deq_local_ptr[qid] +=4;
    }
    //Unpack
    deq_msg[3].field3 = intstream.field3;

    if (deq_local_ptr[qid] == 0x800)
      deq_local_ptr[qid] = 0; //Roll back after 2kb limit

    // Alt decrement cmd for QM
    alt_deq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x2C);
    WRITE32(alt_deq_addr, 0xFFFFFFFE);

    *size = 64;
  }
  else {
    // Alt decrement cmd for QM
    alt_deq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x2C);
    WRITE32(alt_deq_addr, 0xFFFFFFFF);

    *size = 32;
  }
  // Read status of Queue
  alt_deq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x04);
  read(alt_deq_addr);
  print("\n\r====== read_dequeue_msg end===================\n\r");
}

void qm_init_clkrst() {
  print("\n=====qm_init_clkrst start ======\n");
  WRITE32((QM_CLKRST_CSR_BASE_ADDR + QM_CLKEN_ADDR) , 0x00000003);
  WRITE32((QM_CLKRST_CSR_BASE_ADDR + QM_SRST_ADDR) , 0x00000000);

  read(QM_CLKRST_CSR_BASE_ADDR+QM_CLKEN_ADDR);
  read(QM_CLKRST_CSR_BASE_ADDR+QM_SRST_ADDR);
  print("\n=====qm_init_clkrst end ======\n");
}

void read_deq_msg(int qid) {
//  msg_32b_field_t  deq_msg;
//  msg_32b_t        intstream;
  int              i, rdata[8],j;
  int              alt_deq_addr;

//  for (j=0;j<30;j++) {
  print("\n===== read_deq_msg end ======\n");
  // 32 Byte message read
  for(i=0; i< 8; i++) {
//    intstream.raw[i] = READ32((1<<31) + q_state[qid].st_addr + deq_ptr[qid]);
    rdata[i] = READ32((OCM_BASE_ADDR + (0x800 * qid)) + deq_ptr[qid]);
    deq_ptr[qid] += 4;
    print("\n Dequeue Message["); putnum(i); print("] = "); putnum(rdata[i]);
    print("\n\r");
  }

  alt_deq_addr = ( QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x2C);
  WRITE32(alt_deq_addr, 0xFFFFFFFF);

//  write_dealloc_msg((rdata[1] & 0x3FF), rdata[2]);

//  deq_msg = intstream.field;
//  return(deq_msg);

  print("\n===== read_deq_msg end ======\n");
//  }
}

void read_queue(int qid, msg_16b_field_0_t  *deq_msg, unsigned int msg_num ) {


//  msg_32b_t        intstream;
  int              i, rdata[8],j;
  int              alt_deq_addr;
  unsigned long long data_addr_msb;
  for (j=0;j<msg_num;j++) {
  print("\n===== read_deq_msg end ======\n");
  // 32 Byte message read
  for(i=0; i< 4; i++) {
//    intstream.raw[i] = READ32((1<<31) + q_state[qid].st_addr + deq_ptr[qid]);
    rdata[i] = READ32((OCM_BASE_ADDR + (0x800 * qid)) + my_deq_ptr[qid]);
    my_deq_ptr[qid] += 4;
    print("\n Dequeue Message["); putnum(i); print("] = "); putnum(rdata[i]);
    print("\n\r");
    if(i==2) {
			deq_msg->DataAddr=((unsigned long long)rdata[i])&0xFFFFFFFF;
    }
    if(i==3) {
    	deq_msg->BufDataLength=rdata[i]>>16;
		#ifdef PDMA_DDR
    		data_addr_msb= rdata[i]&0xFFFF;
    		deq_msg->DataAddr =	deq_msg->DataAddr + ((data_addr_msb<<32)&0xFF00000000);
		#endif
    }
    printf("my_deq_ptr : 0x%08x\n",my_deq_ptr[qid]);
  }

  alt_deq_addr = ( QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x2C);
  WRITE32(alt_deq_addr, 0xFFFFFFFF);

  print("\n===== read_deq_msg end ======\n");
  deq_msg++;
  }

}

void qm_ecc_init() {
  int rdata;
  unsigned int timeout=0;
  print("\n=====qm_ecc_init start ======\n");

  WRITE32((REGSPEC_GLBL_DIAG_CSR_BASE_ADDR + REGSPEC_CFG_MEM_RAM_SHUTDOWN_ADDR) , 0x00000000);

  do {
    rdata = READ32((REGSPEC_GLBL_DIAG_CSR_BASE_ADDR + REGSPEC_BLOCK_MEM_RDY_ADDR));
    timeout++;
    if(timeout>1000)
    	{
    		printf("Mem block is not ready!!\n");
    		break;
    	}

  } while ( rdata != 0xffffffff);

  print("\n=====qm_ecc_init end ======\n");
}




void qm_misc_init() {

  print("\n=====qm_misc_init start ======\n");

  WRITE32((QM_CSR_BASE_ADDR + CSR_PBM_COAL_ADDR) , 0x88019103);
  WRITE32((QM_CSR_BASE_ADDR + CSR_QM_MBOX_NE_INT_MODE_ADDR) , 0xffffffff);
  WRITE32((QM_CSR_BASE_ADDR + CSR_ACR_FIFO_CTRL_ADDR) , 0xc0e0812a);
  WRITE32((QM_CSR_BASE_ADDR + CSR_DEQ_CTRL_0_ADDR) , 0x00000008);
  WRITE32((QM_CSR_BASE_ADDR + CSR_RECOMB_CTRL_0_ADDR) , 0x00000204);
  WRITE32((QM_CSR_BASE_ADDR + CSR_QM_STATS_CFG_ADDR) , 0x00050005);
  WRITE32((SLAVE_SHIM_CSR_BASE_ADDR + CFG_AMA_MODE_ADDR ) ,0x00000001 );
  WRITE32((QM_CSR_BASE_ADDR + CSR_ERRQ_ADDR) , 0x80008000);

  //SLIMPRO uses pbn0 and pbn1 while cop, abd cpu each use pbn0
  WRITE32((QM_CSR_BASE_ADDR + CSR_QMLITE_PBN_MAP_0_ADDR) , 0x00000000);
  WRITE32((QM_CSR_BASE_ADDR + CSR_QMLITE_PBN_MAP_1_ADDR) , 0x00000021);

  read(QM_CSR_BASE_ADDR+CSR_PBM_COAL_ADDR);
  read(QM_CSR_BASE_ADDR+CSR_QM_MBOX_NE_INT_MODE_ADDR);
  read(QM_CSR_BASE_ADDR+CSR_ACR_FIFO_CTRL_ADDR);
  read(QM_CSR_BASE_ADDR+CSR_DEQ_CTRL_0_ADDR);
  read(QM_CSR_BASE_ADDR+CSR_RECOMB_CTRL_0_ADDR);
  read(QM_CSR_BASE_ADDR+CSR_QM_STATS_CFG_ADDR);
  read(SLAVE_SHIM_CSR_BASE_ADDR+CFG_AMA_MODE_ADDR);
  read(QM_CSR_BASE_ADDR+CSR_ERRQ_ADDR);

  read(QM_CSR_BASE_ADDR+CSR_QMLITE_PBN_MAP_0_ADDR);
  read(QM_CSR_BASE_ADDR+CSR_QMLITE_PBN_MAP_1_ADDR);
  print("\n=====qm_misc_init end ======\n");
}


int qm_poll_deq_intr() {
  int intr_stat;

  print("\n=====qm_poll_deq_intr start ======\n");

  do {
    intr_stat = READ32((QM_CSR_BASE_ADDR + CSR_QM_MBOX_NE_ADDR) );
    print("intr_stat = "); putnum(intr_stat);print("\n\r");
  } while (intr_stat != 0x00000001);
  print("\n\r !!! DEQUEUE INTERRUPT RECEIVED !!! \n\r");
  print("\n\r=====qm_poll_deq_intr end ======\n\r");
  return(intr_stat);
}

void qm_pb_init(qm_sid_assign_t slaveid, qm_pbid_assign_t pbid, qm_qid_assign_t qid) {
  pb_data_field_t pb_data;
  pb_data_t       intstream;
  int       pbmem_start_addr;

  print("\n\r=====qm_pb_init start ======\n\r");

  pb_data.slot = 0;
  pb_data.pb_size = 0;
  if ((slaveid == SID_PROC) && (pbid & 0x20))
    pb_data.pb_en = 0;
  else
    pb_data.pb_en = 1;
  pb_data.tlvq = 0;
  pb_data.qid = qid | (0x3 << 10);
  pb_data.mn = 0;

  intstream.pb_data = pb_data;

  //MEM
//   pbmem_start_addr = QM_CSR_BASE_ADDR + 0x1000;
//   WRITE32((pbmem_start_addr + ((slaveid<<8) | ((pbid & 0x3f) << 2))) , intstream.data);

  //CSR
  WRITE32((QM_CSR_BASE_ADDR + CSR_PBM_ADDR), (1<<31| slaveid<<6 | (pbid & 0x3f)));
  WRITE32((QM_CSR_BASE_ADDR + CSR_PBM_BUF_WR_ADDR), (unsigned int)intstream.data);
  print("\n\r=====qm_pb_init end ======\n\r");

}


void qm_intrmask_init() {

  print("\n\r=====qm_intrmask_init start ======\n\r");

  WRITE32((QM_CSR_BASE_ADDR + QM_INTERRUPTMASK_ADDR) , 0x00000008);
  print("\n\r=====qm_intrmask_init end ======\n\r");

}

void qm_enable() {
  int i,alt_enq_addr;
  unsigned int qid;
  unsigned int num_of_ptr;

  print("\n\r=====qm_enable start ======\n\r");

  WRITE32((QM_CSR_BASE_ADDR + CSR_QM_CONFIG_ADDR) , 0xe0000000);

  // Alt alloc cmd for QM
//  while (num_alt_enq_cmd>0) {
//    num_alt_enq_cmd--;
//    qid        = alt_enq_qid[num_alt_enq_cmd];// = qid;
//    num_of_ptr = alt_enq_num[num_alt_enq_cmd];// = num_of_ptr;
//    alt_enq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x2C);
//    WRITE32(alt_enq_addr, num_of_ptr);
//  }
/*  alt_enq_addr = ((1<<31) | QM_BASE_ADDR | (0x3 << 16) | (qid << 6) | 0x2C);
  write(alt_enq_addr, num_of_ptr);*/
  num_alt_enq_cmd = 0xFF; //Should directly send alt_enq_cmd
  print("\n\r=====qm_enable end ======\n\r");
}

void qm_csr_init() {
  int i;

  print("\n\r=====qm_csr_init start ======\n\r");
  qm_init_clkrst();

  read(0x1f200000);
//  return;
  qm_ecc_init();
  qm_misc_init();
  qm_intrmask_init();

  print("\n\r=====qm_csr_init end ======\n\r");
}



void qm_thrs_init() {

  print("\n\r=====qm_thrs_init start ======\n\r");

  WRITE32((QM_CSR_BASE_ADDR + CSR_THRESHOLD0_SET0_ADDR) , 0x00000006);
  WRITE32((QM_CSR_BASE_ADDR + CSR_THRESHOLD1_SET0_ADDR) , 0x0004000a);
  WRITE32((QM_CSR_BASE_ADDR + CSR_THRESHOLD0_SET1_ADDR) , 0x00040007);
  WRITE32((QM_CSR_BASE_ADDR + CSR_THRESHOLD1_SET1_ADDR) , 0x0004000b);
  WRITE32((QM_CSR_BASE_ADDR + CSR_THRESHOLD0_SET2_ADDR) , 0x0000000d);
  WRITE32((QM_CSR_BASE_ADDR + CSR_THRESHOLD1_SET2_ADDR) , 0x0004002d);
  WRITE32((QM_CSR_BASE_ADDR + CSR_THRESHOLD0_SET3_ADDR) , 0x0004000d);
  WRITE32((QM_CSR_BASE_ADDR + CSR_THRESHOLD1_SET3_ADDR) , 0x0004002d);
  WRITE32((QM_CSR_BASE_ADDR + CSR_THRESHOLD0_SET4_ADDR) , 0x00040083);
  WRITE32((QM_CSR_BASE_ADDR + CSR_THRESHOLD1_SET4_ADDR) , 0x00000183);
  WRITE32((QM_CSR_BASE_ADDR + CSR_THRESHOLD0_SET5_ADDR) , 0x00000081);
  WRITE32((QM_CSR_BASE_ADDR + CSR_THRESHOLD1_SET5_ADDR) , 0x00000181);
  WRITE32((QM_CSR_BASE_ADDR + CSR_THRESHOLD0_SET6_ADDR) , 0x000401fe);
  WRITE32((QM_CSR_BASE_ADDR + CSR_THRESHOLD1_SET6_ADDR) , 0x000405fe);
  WRITE32((QM_CSR_BASE_ADDR + CSR_THRESHOLD0_SET7_ADDR) , 0x00000ffe);
  WRITE32((QM_CSR_BASE_ADDR + CSR_THRESHOLD1_SET7_ADDR) , 0x00042ffe);
  WRITE32((QM_CSR_BASE_ADDR + CSR_HYSTERESIS_ADDR) , 0x1102f56e);

  print("\n\r=====qm_thrs_init end ======\n\r");
}

void sm_qm_test() {

    int intr_stat;

    print("Storm SOC FPGA: \n\r\n\r");

    print("Virtualized-subsystem MUX select for DMA\n\r");
    write (0x9704000c, 0x00000010);

    print("Config PDMA_CLKEN \n\r");
    write (0x9702c008, 0x00000003);			// add changed because dma is mount on Enet slot

    print("Config PDMA_SRST \n\r");
    write (0x9702c000, 0x00000000);

    print("Config PDMA_GCR \n\r");
    write (0x9702c010, 0xf9b99901);

    print("Read IPBRR \n\r");
    read  (0x97020000);

// *********


    qm_csr_init();

    //menet
    fp_qstate_init(FPQID4);
    data_ptr_init(FPQID4, 24);  //qid and num_of_pointers max can be 24 only
    qm_pb_init(SID_MENET, FPQPBID0, FPQID4);  // slaveid, pbn number, freepoolqid number

    wq_qstate_init(WQID4);
    qm_pb_init(SID_MENET, WQPBID0, WQID4); // slaveid, pbn number, workqueueqid number



    //enable the qm
    qm_enable();
    print("Enable QM \n\r");

    print("Waiting ......\n\r");
    print("Waiting ......\n\r");
    print("Waiting ......\n\r");
    print("Waiting ......\n\r");
    print("Waiting ......\n\r");
    print("Waiting ......\n\r");
    print("Waiting ......\n\r");
    print("Waiting ......\n\r");
    print("Waiting ......\n\r");
    print("Waiting ......\n\r");
    print("Waiting ......\n\r");
    print("Waiting ......\n\r");
    print("Waiting ......\n\r");
    print("Waiting ......\n\r");
    print("Waiting ......\n\r");
    print("Waiting ......\n\r");
    print("Waiting ......\n\r");
    print("Waiting ......\n\r");
    print("Waiting ......\n\r");
    print("Waiting ......\n\r");
    print("Waiting ......\n\r");
    read  (0x97029030);

    // Write a enq message from proc to its own qid
    print("Start DMA Message \n\r");
    //write_enq_msg(WQID0);

    //Wait for interrupt by polling csr
    print("Start Wait for Polling \n\r");
    //intr_stat = qm_poll_deq_intr();

    //Read the dequeue message from proc wqid
    //read_deq_msg(WQID0);




    print("*****************************************\n\r");
    print("************** Test Complete ************\n\r");
    print("*****************************************\n\r");
#ifndef ARM_CC
 //   cleanup_platform();
#endif
}
int get_queue_size_code (int actual_queue_size) {
  int queue_size_code;
  switch (actual_queue_size) {
    case 0x200:  // 0.5KB
     queue_size_code = 0;
     break;
    case 0x800:  // 2KB
     queue_size_code = 1;
     break;
    case 0x4000: // 16KB
     queue_size_code = 2;
     break;
    case 0x10000: // 64KB
     queue_size_code = 3;
     break;
    case 0x80000: // 512KB
     queue_size_code = 4;
     break;
    default: //Unsupported setting, forced to 2KB
     queue_size_code = 1;
     break;
  }
  return queue_size_code;
}
