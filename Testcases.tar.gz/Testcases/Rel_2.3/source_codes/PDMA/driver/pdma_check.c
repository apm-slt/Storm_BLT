/*
 * pdma_check.c
 *
 *  Created on: May 5, 2014
 *      Author: lxpham
 */


#include "../include/pdma_check.h"
//Tinh-SLT
//function call
#define print print_pdma_copy
#define putnum putnum_pdma_copy
//End of Tinh-SLT

/*Function Prototype*/
/****************************************************************************************************************/
void dma_check_status(int status) {
  if (status)
    dma_error();
  else
    end_test();
}

void dma_error() {
    print("********************************************************");  print("\n\r");
    print("******************** PDMA Error ************************");  print("\n\r");
    print("********************************************************");  print("\n\r");
#ifdef  ARM_CC
    test_fail();
#endif
  }

int dma_check_gather_scatter(dma_params_t dma_params)
{
  int i,j,k,dst_idx;
  unsigned char *ptr_src,*ptr_dst;
  print("\n===== Check Gather Scatter Memdest operation ======\n");

  k=0;
  dst_idx=0;

	print("NUM_SRC:");putnum(dma_params.num_src);print("\n");
	print("NUM_DST:");putnum(dma_params.num_dst);print("\n");

	for (i=0;i<dma_params.num_src;i++) {
		print("Address src ");putnum(i);print("= ");putnum_64(dma_params.src[i]);print("\n");
		print("Length src ");putnum(i);print("= ");putnum(dma_params.len_src[i]);print("\n");
	}
	for (i=0;i<dma_params.num_dst;i++) {
		print("Address dst ");putnum(i);print("= ");putnum_64(dma_params.dst[i]);print("\n");
		print("Length dst");putnum(i);print("= ");putnum(dma_params.len_dst[i]);print("\n");
	}


  print("NUM_SRC:");putnum(dma_params.num_src);print("\n");
  print("NUM_DST:");putnum(dma_params.num_dst);print("\n");

	  ptr_dst = (unsigned char *)(dma_params.dst[dst_idx] | DMA_CPU_MEM_ACCESS_MASK);

	  print("Address dest = ");putnum_64(ptr_dst);print("\n");
	  print("Length dest =  ");putnum(dma_params.len_dst[dst_idx]);print("\n");

//	  printf("Destination: After transfer\n");
//	  mem_dump(ptr_dst,dma_params.len_dst[dst_idx]/4);

  for (i=0;i<dma_params.num_src;i++) {
    ptr_src = (unsigned char *)(dma_params.src[i] |  DMA_CPU_MEM_ACCESS_MASK);
    print("Address src ");putnum(i);print("= ");putnum_64(ptr_src);print("\n");
    print("Length src ");putnum(i);print("= ");putnum(dma_params.len_src[i]);print("\n");
    for (j=0;j<dma_params.len_src[i];j++) {
      if (k == dma_params.len_dst[dst_idx]) {
        dst_idx++;
        k=0;
        ptr_dst = (unsigned char *)(dma_params.dst[dst_idx] | DMA_CPU_MEM_ACCESS_MASK);
        print("Address dest = ");putnum_64(ptr_dst);print("\n");
        print("Length dest =  ");putnum(dma_params.len_dst[dst_idx]);print("\n");
//        printf("Mem dump for destination\n");
//        mem_dump(ptr_dst,dma_params.len_dst[dst_idx]/4);
      }
      if (ptr_src[j] != ptr_dst[k]) {
        print("ERROR: Gather operation  - Byte mismatch at ");
        putnum(j);
        print(" byte. Expected data = ");
        putnum_64(ptr_src[j]);
        print(" - Actual data = ");
        putnum(ptr_dst[k]);
        print("\n");
        return DMA_CHECK_FAIL;
      } /*else {
        print("Byte Match at ");
        putnum(j);
        print(" byte. Expected data = ");
        putnum(ptr_src[j]);
        print(" - Actual data = ");
        putnum(ptr_dst[k]);
        print("\n");
	}*/
      k++;
    }
  }
  print("\n========================================\n");
  return DMA_CHECK_PASS;
}

int dma_check_gather_scatter_small_size(dma_params_small_size_t dma_params)
{
  int i,j,k,dst_idx;
  unsigned char *ptr_src,*ptr_dst;
  print("\n===== Check Gather Scatter Memdest operation ======\n");

  k=0;
  dst_idx=0;


  print("NUM_SRC:");putnum(dma_params.num_src);print("\n");
  print("NUM_DST:");putnum(dma_params.num_dst);print("\n");

	  ptr_dst = (unsigned char *)(dma_params.dst[dst_idx] | DMA_CPU_MEM_ACCESS_MASK);

	  print("Address dest = ");putnum(ptr_dst);print("\n");
	  print("Length dest =  ");putnum(dma_params.len_dst[dst_idx]);print("\n");

//	  printf("Destination: After transfer\n");
//	  mem_dump(ptr_dst,dma_params.len_dst[dst_idx]/4);

  for (i=0;i<dma_params.num_src;i++) {
    ptr_src = (unsigned char *)(dma_params.src[i] |  DMA_CPU_MEM_ACCESS_MASK);
    print("Address src ");putnum(i);print("= ");putnum(ptr_src);print("\n");
    print("Length src ");putnum(i);print("= ");putnum(dma_params.len_src[i]);print("\n");
    for (j=0;j<dma_params.len_src[i];j++) {
      if (k == dma_params.len_dst[dst_idx]) {
        dst_idx++;
        k=0;
        ptr_dst = (unsigned char *)(dma_params.dst[dst_idx] | DMA_CPU_MEM_ACCESS_MASK);
        print("Address dest = ");putnum(ptr_dst);print("\n");
        print("Length dest =  ");putnum(dma_params.len_dst[dst_idx]);print("\n");
//        printf("Mem dump for destination\n");
//        mem_dump(ptr_dst,dma_params.len_dst[dst_idx]/4);
      }
      if (ptr_src[j] != ptr_dst[k]) {
        print("ERROR: Gather operation  - Byte mismatch at ");
        putnum(j);
        print(" byte. Expected data = ");
        putnum(ptr_src[j]);
        print(" - Actual data = ");
        putnum(ptr_dst[k]);
        print("\n");
        return DMA_CHECK_FAIL;
      } /*else {
        print("Byte Match at ");
        putnum(j);
        print(" byte. Expected data = ");
        putnum(ptr_src[j]);
        print(" - Actual data = ");
        putnum(ptr_dst[k]);
        print("\n");
	}*/
      k++;
    }
  }
  print("\n========================================\n");
  return DMA_CHECK_PASS;
}

/******************************************************************************************
 * ************* This checking function is used for M2B linklist tests ********************
 ******************************************************************************************/
int mycheck (dma_params_t dma_params)
{
	int i,j,k,dst_idx;
	unsigned char *ptr_src,*ptr_dst;
	print("\n===== My check ======\n");

	k=0;
	dst_idx=0;
	print("NUM_SRC:");putnum(dma_params.num_src);print("\n");
	print("NUM_DST:");putnum(dma_params.num_dst);print("\n");

	for (i=0;i<dma_params.num_src;i++) {
	    print("Address src ");putnum(i);print("= ");putnum(dma_params.src[i]);print("\n");
	    print("Length src ");putnum(i);print("= ");putnum(dma_params.len_src[i]);print("\n");
	}
	for (i=0;i<dma_params.num_dst;i++) {
		print("Address dst ");putnum(i);print("= ");putnum(dma_params.dst[i]);print("\n");
		print("Length dst");putnum(i);print("= ");putnum(dma_params.len_dst[i]);print("\n");
		}
	return DMA_CHECK_PASS;

}


int dma_check_crc(dma_params_t dma_params)
{

  unsigned int crc_result;
  unsigned char *ptr_src;

  printf("dma_params.SD = 0x%x\n",dma_params.SD);
  printf("dma_params.Seed = 0x%x\n",dma_params.Seed);
  printf("dma_params.FBY = 0x%x\n",dma_params.FBY);
  crc_result  = dma_params.SD ? dma_params.Seed : ((dma_params.FBY == 0x1) ? 0 : 0xFFFFFFFF);

  if (dma_params.FBY == 0x1) print("\n===== CHECK CRC16 Gen operation ======\n");
  else if (dma_params.FBY == 0x2) print("\n===== CHECK CRC32C Gen operation ======\n");
  else if (dma_params.FBY == 0x3) print("\n===== CHECK Ethernet CRC32 Gen operation ======\n");
  print(" CRC seed    : ");putnum(dma_params.Seed);print("\n\r");
  print(" CRC ByteCnt : ");putnum(dma_params.ByteCnt);print("\n\r");

  ptr_src = (unsigned char *)(dma_params.src[0] |  DMA_CPU_MEM_ACCESS_MASK);
  if (dma_params.FBY == 0x1)      crc_result = get_crc16_seed(ptr_src, dma_params.ByteCnt, crc_result);
  else if (dma_params.FBY == 0x2) crc_result = get_iscsi_crc32c_seed(ptr_src, dma_params.ByteCnt, crc_result);
  else if (dma_params.FBY == 0x3) crc_result = get_eth_crc32e_seed(ptr_src, dma_params.ByteCnt, crc_result);

  print(" CRC RESULT: ");putnum(crc_result);print("\n\r");
  print("\n========================================\n");

  if(dma_params.FBY == 0x1) {

    if(crc_result != (dma_params.CRCResult & 0xFFFF)) {
    print(" Expected CRCR: ");putnum(crc_result);print(" Actual CRC :");putnum(dma_params.CRCResult & 0xFFFF);print("\n");
    return DMA_CHECK_FAIL;
  }

  } else {

    if(crc_result != dma_params.CRCResult) {
    print(" Expected CRCR: ");putnum(crc_result);print(" Actual CRC :");putnum(dma_params.CRCResult);print("\n");
    return DMA_CHECK_FAIL;
  }
  }
  return DMA_CHECK_PASS;
}

int dma_sdp_check(dma_cmplt_msg_32b_ptr cmplt_msg) {
  if((cmplt_msg->dma_cmplt_bufdest_1buf.LErr==3)&(cmplt_msg->dma_cmplt_bufdest_1buf.ELErr==2)) {
    return DMA_CHECK_FAIL;
  } else {
    return DMA_CHECK_PASS;
  }
}

int dma_check_err(dma_cmplt_msg_32b_ptr cmplt_msg) {
  if((cmplt_msg->dma_cmplt_bufdest_1buf.LErr==0)&(cmplt_msg->dma_cmplt_bufdest_1buf.ELErr==0)) {
    return DMA_CHECK_PASS;
  } else {
    return DMA_CHECK_FAIL;
  }
}

int dma_check_raid(int CHID, dma_params_t dma_params) {

  int i,j;
  unsigned char *ptr_src,*ptr_dst;
  unsigned char xor_data;
  unsigned char multi[5];
  unsigned int adg_sel;

  if(CHID == 0) {
    print("\n===== Check RAID5 operation ======\n");
  } else {
    print("\n===== Check RAID6 operation ======\n");
    multi[0] = dma_params.Multi0;
    multi[1] = dma_params.Multi1;
    multi[2] = dma_params.Multi2;
    multi[3] = dma_params.Multi3;
    multi[4] = dma_params.Multi4;

    for(i=0;i<dma_params.num_src;i++)
    printf("Multi[%u]=%x\n",i,multi[i]);
    adg_sel = RAID6_MULT;
    adg_sel = adg_sel >> 24;
    printf("adg_sel=%x\n",adg_sel);

  }


  ptr_dst = (unsigned char *)(dma_params.dst[0] | DMA_CPU_MEM_ACCESS_MASK);
  print("Address dest = ");putnum(ptr_dst);print("\n");
  print("Length dest =  ");putnum(dma_params.len_dst[0]);print("\n");

  printf("Number of source = %u\n",dma_params.num_src);

//  printf("Mem_dump destination data\n");
//  mem_dump(ptr_dst,dma_params.len_dst[0]/4);

  for(i = 0; i < dma_params.len_src[0]; i++) {

    for (j = 0;j < dma_params.num_src; j++) {
      ptr_src = (unsigned char *)(dma_params.src[j] |  DMA_CPU_MEM_ACCESS_MASK);
      if (CHID == 0) {
        xor_data = (j!=0) ? xor_data ^ ptr_src[i] : ptr_src[i];          /*RAID5_XOR*/
      } else {
        xor_data = (j!=0) ? xor_data ^ adg_mul(ptr_src[i],multi[j],(unsigned char)adg_sel) : adg_mul(ptr_src[i],multi[j],(unsigned char)adg_sel);     /*RAID6*/
      }
    }


    if (xor_data != ptr_dst[i]) {
      print("ERROR: RAID operation  - Byte mismatch at ");
      putnum(i);
      print(" byte. Expected data = ");
      putnum(xor_data);
      print(" - Actual data = ");
      putnum(ptr_dst[i]);
      print("\n");
      return DMA_CHECK_FAIL;
    } else {
//      print("Byte Match at ");
//      putnum(i);
//      print(" byte. Expected data = ");
//      putnum(xor_data);
//      print(" - Actual data = ");
//      putnum(ptr_dst[i]);
//      print("\n");
      }
  }

  print("\n========================================\n");
  return DMA_CHECK_PASS;
}

int dma_check_chksum(dma_params_t dma_params) {
  unsigned char *ptr_src, odd;
  unsigned short int tmp=0;      /*initial value must be =0*/
  int length,len_cnt;
  unsigned int sum_dat=0;		/*initial value must be =0*/
  ptr_src = (unsigned char *)(dma_params.src[0] |  DMA_CPU_MEM_ACCESS_MASK);
  printf("ByteCount = 0x%x\n",dma_params.ByteCnt);
  for(len_cnt = 0; len_cnt < dma_params.ByteCnt; len_cnt++) {
    tmp = tmp << 8;
    tmp = tmp | ptr_src[len_cnt];
    odd = len_cnt & 0x01;
    if(odd == 1) {
	sum_dat = sum_dat + tmp;
	print("SUM0:");putnum(sum_dat);print(" - DATA:");putnum(tmp);print("\n");
    } else if(len_cnt == (dma_params.ByteCnt-1)) {
      tmp = tmp << 8;
      sum_dat = sum_dat + tmp;
      print("SUM1:");putnum(sum_dat);print(" - DATA:");putnum(tmp);print("\n");
    }
  }
  tmp = sum_dat >> 16;
  tmp+=(sum_dat&0xFFFF);
  tmp = tmp ^ 0xFFFF;
  print("CHECK SUM RESULT : ");putnum(tmp);print("\n");
  /*lxpham add 21Mar13*/
  printf("tmp = 0x%x\n",tmp);
  printf("dma_params.ChkResult = 0x%x\n",dma_params.ChkResult);
  /*End lxpham add*/
  if (tmp != dma_params.ChkResult) {
    return DMA_CHECK_FAIL;
  }
  print("\n========================================\n");
 return DMA_CHECK_PASS;
}

int dma_check_copy_dif(dma_params_t dma_params, dma_dif_result_ptr ptr_dma_dif_result)
{
  int i,j;
  unsigned int reftag_inc, blk_size, dif_addr;
  unsigned char *ptr_src;
  unsigned int  *ptr_dst;
  dma_dif_result_chk_t dif_result;
  blk_size = dma_get_blksize(dma_params.BlkSize);

  print("\n===== Check Copy Insert DIF operation ======\n");
  ptr_src = (unsigned char *)(dma_params.src[0] | DMA_CPU_MEM_ACCESS_MASK);
  ptr_dst = (unsigned int *)(dma_params.dst[0] | DMA_CPU_MEM_ACCESS_MASK);
  print("Address src = ");putnum(ptr_src);print("\n");
  print("Src Length = ");putnum(dma_params.len_src[0]);print("\n");
  print("Address dest = ");putnum(ptr_dst);print("\n");
  reftag_inc = 1;
  dif_addr   = 0;
  for (i=0;i<dma_params.len_src[0];i++) {
    ptr_dma_dif_result->dma_dif_result.CRC = get_crc16_seed(&ptr_src[i], 1, ptr_dma_dif_result->dma_dif_result.CRC);

    if (i==(reftag_inc*blk_size-1)) {
      for(j=0;j<2;j++) {
	dif_result.data[j] = ptr_dst[j+dif_addr];
	print("ADDR:");putnum(j+dif_addr);print(" DIF :");putnum(ptr_dst[j+dif_addr]);print("\n");
      }

      if(ptr_dma_dif_result->dma_dif_result.CRC!=dif_result.dma_dif_result_chk.CRC) {
	print("ERROR: Copy Insert DIF Operation - Sector Num = ");
	putnum(reftag_inc);print("\n");
	print("Expected CRC = ");putnum(ptr_dma_dif_result->dma_dif_result.CRC);print(" - Actual CRC = ");putnum(dif_result.dma_dif_result_chk.CRC);print("\n");
	return DMA_CHECK_FAIL;
      } else {
	print("DIF match with SECTOR NUM =  ");
	putnum(reftag_inc);print("\n");
	print("Expected CRC = ");putnum(ptr_dma_dif_result->dma_dif_result.CRC);print(" - Actual CRC = ");putnum(dif_result.dma_dif_result_chk.CRC);print("\n");
	}
      if(ptr_dma_dif_result->dma_dif_result.AppTag!=dif_result.dma_dif_result_chk.AppTag) {
	print("ERROR: Copy Insert DIF Operation - Sector Num = ");
	putnum(reftag_inc);print("\n");
	print("Expected App Tagg = ");putnum(ptr_dma_dif_result->dma_dif_result.AppTag);print(" - Actual App Tagg = ");putnum(dif_result.dma_dif_result_chk.AppTag);print("\n");
	return DMA_CHECK_FAIL;
      } else {
	print("DIF match with SECTOR NUM =  ");
	putnum(reftag_inc);print("\n");
	print("Expected App Tagg = ");putnum(ptr_dma_dif_result->dma_dif_result.AppTag);print(" - Actual App Tagg = ");putnum(dif_result.dma_dif_result_chk.AppTag);print("\n");

	}
      if(ptr_dma_dif_result->dma_dif_result.RefTag!=dif_result.dma_dif_result_chk.RefTag) {
	print("ERROR: Copy Insert DIF Operation - Sector Num = ");
	putnum(reftag_inc);print("\n");
	print("Expected Ref Tag = ");putnum(ptr_dma_dif_result->dma_dif_result.RefTag);print(" - Actual Ref Tag = ");putnum(dif_result.dma_dif_result_chk.RefTag);print("\n");
	return DMA_CHECK_FAIL;
      } else {
	print("DIF match with SECTOR NUM =  ");
	putnum(reftag_inc);print("\n");
	print("Expected Ref Tag = ");putnum(ptr_dma_dif_result->dma_dif_result.RefTag);print(" - Actual Ref Tag = ");putnum(dif_result.dma_dif_result_chk.RefTag);print("\n");
	}
      ptr_dma_dif_result->dma_dif_result.RefTag++;
      reftag_inc++;
      dif_addr = dif_addr + j;
      ptr_dma_dif_result->dma_dif_result.CRC = 0;
    }
  }

  print("\n========================================\n");
  return DMA_CHECK_PASS;
}


int dma_check_ins_dif(dma_params_t dma_params, dma_dif_result_ptr ptr_dma_dif_result)
{
  int i,j;
  unsigned int reftag_inc, blk_size, dif_addr, num_src, len_data;
  unsigned char *ptr_src;
  unsigned char *ptr_dst;

  dma_dif_result_t dif_result;
  unsigned long long dst;
  dst = dma_params.dst[0];

  if(dst & 0xF) {
    dst = dst >> 4;
    dst++;
    dst = dst << 4;}
  print("\n===== Check Insert DIF operation ======\n");
  blk_size = dma_get_blksize(dma_params.BlkSize);

  ptr_dst = (unsigned char *)(dst | DMA_CPU_MEM_ACCESS_MASK);

  reftag_inc = 1;
  dif_addr   = 0;
  len_data   = 0;

  for(num_src = 0; num_src < dma_params.num_src; num_src++) {
    ptr_src = (unsigned char *)(dma_params.src[num_src] | DMA_CPU_MEM_ACCESS_MASK);
    print("Address src = ");putnum(ptr_src);print("\n");
    print("Address dst = ");putnum(ptr_dst);print("\n");
    print("Src Length = ");putnum(dma_params.len_src[num_src]);print("\n");
    ptr_dma_dif_result->dma_dif_result.CRC = 0;
    for ( i = 0; i < dma_params.len_src[num_src]; i++) {
      ptr_dma_dif_result->dma_dif_result.CRC = get_crc16_seed(&ptr_src[i], 1, ptr_dma_dif_result->dma_dif_result.CRC);

      if (len_data == (reftag_inc*blk_size-1)) {
	for(j = 0; j < 8; j++) {
	  dif_result.data[j] = ptr_dst[j+dif_addr];
	  print("ADDR:");putnum(j+dif_addr);print(" DIF :");putnum(ptr_dst[j+dif_addr]);print("\n");
	}

	if(ptr_dma_dif_result->dma_dif_result.CRC!=dif_result.dma_dif_result.CRC) {
	  print("ERROR: Copy Insert DIF Operation - Sector Num = ");
	  putnum(reftag_inc);print("\n");
	  print("Expected CRC = ");putnum(ptr_dma_dif_result->dma_dif_result.CRC);print(" - Actual CRC = ");putnum(dif_result.dma_dif_result.CRC);print("\n");
	  return DMA_CHECK_FAIL;
	} else {
	  print("DIF match with SECTOR NUM =  ");
	  putnum(reftag_inc);print("\n");
	  print("Expected CRC = ");putnum(ptr_dma_dif_result->dma_dif_result.CRC);print(" - Actual CRC = ");putnum(dif_result.dma_dif_result.CRC);print("\n");
	}

	if(ptr_dma_dif_result->dma_dif_result.AppTag!=dif_result.dma_dif_result.AppTag) {
	  print("ERROR: Copy Insert DIF Operation - Sector Num = ");
	  putnum(reftag_inc);print("\n");
	  print("Expected App Tagg = ");putnum(ptr_dma_dif_result->dma_dif_result.AppTag);print(" - Actual App Tagg = ");putnum(dif_result.dma_dif_result.AppTag);print("\n");
	  return DMA_CHECK_FAIL;
	} else {
	  print("DIF match with SECTOR NUM =  ");
	  putnum(reftag_inc);print("\n");
	  print("Expected App Tagg = ");putnum(ptr_dma_dif_result->dma_dif_result.AppTag);print(" - Actual App Tagg = ");putnum(dif_result.dma_dif_result.AppTag);print("\n");
	}

	if(ptr_dma_dif_result->dma_dif_result.RefTag!=dif_result.dma_dif_result.RefTag) {
	  print("ERROR: Copy Insert DIF Operation - Sector Num = ");
	  putnum(reftag_inc);print("\n");
	  print("Expected Ref Tag = ");putnum(ptr_dma_dif_result->dma_dif_result.RefTag);print(" - Actual Ref Tag = ");putnum(dif_result.dma_dif_result.RefTag);print("\n");
	  return DMA_CHECK_FAIL;
	} else {
	  print("DIF match with SECTOR NUM =  ");
	  putnum(reftag_inc);print("\n");
	  print("Expected Ref Tag = ");putnum(ptr_dma_dif_result->dma_dif_result.RefTag);print(" - Actual Ref Tag = ");putnum(dif_result.dma_dif_result.RefTag);print("\n");
	}
	ptr_dma_dif_result->dma_dif_result.RefTag++;
	reftag_inc++;
	dif_addr = dif_addr + j;
	ptr_dma_dif_result->dma_dif_result.CRC = 0;
      }
      len_data++;
    }
  }
  print("\n========================================\n");
  return DMA_CHECK_PASS;
}


int dma_check_gather_scatter_striding_mode(dma_params_t dma_params)
{
  unsigned short int src_addr, dst_addr, src_size, dst_size, len_data, len_left, dst_idx, src_idx;
  unsigned char *ptr_src,*ptr_dst;
  print("\n===== Check Gather Scatter Memdest With Striding operation ======\n");

  print("NUM_SRC:");putnum(dma_params.num_src);print("\n");
  print("NUM_DST:");putnum(dma_params.num_dst);print("\n");

  //initial
  len_data = 0;
  dst_idx  = 0;
  dst_addr = 0;
  dst_size = dma_params.DstStridingSize;
  ptr_dst  = (unsigned char *)(dma_params.dst[dst_idx] | DMA_CPU_MEM_ACCESS_MASK);

  print("Address dest = ");putnum(ptr_dst);print("\n");
  print("Length dest  = ");putnum(dma_params.len_dst[dst_idx]);print("\n");

  // Source Total Length
  for (src_idx = 0; src_idx < dma_params.num_src; src_idx++) len_data+= dma_params.len_src[src_idx];

  print("Total Length Of Source Address = ");putnum(len_data);print("\n");

  len_left = len_data % (dma_params.SrcStridingSize+dma_params.SrcDistance);

  if((len_left == 0)|(len_left < dma_params.SrcStridingSize)) {

    len_left = len_data /(dma_params.SrcStridingSize+dma_params.SrcDistance);

    len_left = len_left * dma_params.SrcStridingSize;

  } else {
    len_left = len_data /(dma_params.SrcStridingSize+dma_params.SrcDistance);
    len_left = len_left * dma_params.SrcStridingSize+dma_params.SrcStridingSize;
  }

  for (src_idx = 0; src_idx < dma_params.num_src; src_idx++) {

    ptr_src = (unsigned char *)(dma_params.src[src_idx] |  DMA_CPU_MEM_ACCESS_MASK);
    print("Address src ");putnum(src_idx);print("= ");putnum(ptr_src);print("\n");
    print("Length src  ");putnum(src_idx);print("= ");putnum(dma_params.len_src[src_idx]);print("\n");

    if(src_idx== 0) {
      src_addr = 0;
      src_size = dma_params.SrcStridingSize;

    } else {
      src_addr = src_addr - dma_params.len_src[src_idx-1];
      src_size = src_size - dma_params.len_src[src_idx-1];
    }

    do{

      if(dst_addr >= dma_params.len_dst[dst_idx]) {

	dst_addr = dst_addr - dma_params.len_dst[dst_idx];
	dst_size = dst_size - dma_params.len_dst[dst_idx];

	dst_idx++;

	ptr_dst = (unsigned char *)(dma_params.dst[dst_idx] | DMA_CPU_MEM_ACCESS_MASK);
	print("Address dest = ");putnum(ptr_dst);print("\n");
	print("Length dest ");putnum(dst_idx);print("= ");putnum(dma_params.len_dst[dst_idx]);print("\n");
	}

      if (ptr_src[src_addr] != ptr_dst[dst_addr]) {
        print("ERROR: Gather With Striding operation  - Byte mismatch at ");
        putnum(src_addr);
        print(" byte. Expected data = ");
        putnum(ptr_src[src_addr]);
        print(" - Actual data = ");
        putnum(ptr_dst[dst_addr]);
        print("\n");
        return DMA_CHECK_FAIL;
      } /*else {
        print("Byte Match at ");
        putnum(src_addr);
        print(" byte. Expected data = ");
        putnum(ptr_src[src_addr]);
	print("Dest Addr at : ");
	putnum(dst_addr);
        print(" - Actual data = ");
        putnum(ptr_dst[dst_addr]);
        print("\n");
	}*/

      if (src_addr <  (src_size - 1)) {

	src_addr++;

      } else {
	src_addr = src_addr + dma_params.SrcDistance + 1;
	src_size = src_size + dma_params.SrcDistance + dma_params.SrcStridingSize;
      }

      len_left--;

      if (dst_addr <  (dst_size - 1)) {

	dst_addr++;

      } else {

	if(len_left < dma_params.DstStridingSize) {

	  return DMA_CHECK_PASS;
	}
	dst_addr = dst_addr + dma_params.DstDistance + 1;
	dst_size = dst_size + dma_params.DstStridingSize + dma_params.DstDistance;
      }
    }while((src_idx!=(dma_params.num_src-1)) ? (src_addr < dma_params.len_src[src_idx]) : (len_left != 0));
  }
  print("\n========================================\n");
  return DMA_CHECK_PASS;
}

int dma_gather_scatter_not_same_length_check(dma_cmplt_msg_32b_ptr cmplt_msg) {
  if((cmplt_msg->dma_cmplt_bufdest_1buf.ELErr==0x1)&(cmplt_msg->dma_cmplt_bufdest_1buf.LErr==0x1)) {
    return DMA_CHECK_PASS;
  } else {
    return DMA_CHECK_FAIL;
  }
}

int dma_fpb_timeout_err_check(dma_cmplt_msg_32b_ptr cmplt_msg) {
  if((cmplt_msg->dma_cmplt_bufdest_1buf.ELErr==0x0)&(cmplt_msg->dma_cmplt_bufdest_1buf.LErr==0x5)) {
    return DMA_CHECK_PASS;
  } else {
    return DMA_CHECK_FAIL;
  }
}


int dma_bad_msg_check(dma_cmplt_msg_32b_ptr cmplt_msg) {
  if((cmplt_msg->dma_cmplt_bufdest_1buf.ELErr==0x0)&(cmplt_msg->dma_cmplt_bufdest_1buf.LErr==0x2)) {
    return DMA_CHECK_PASS;
  } else {
    return DMA_CHECK_FAIL;
  }
}

void test_fail()
{
	print("********************************************************");  print("\n\r");
	print("******************** Test FAIL *************************");  print("\n\r");
	print("********************************************************");  print("\n\r");
}
void end_test()
{
	print("********************************************************");  print("\n\r");
	print("******************** Test End **************************");  print("\n\r");
	print("********************************************************");  print("\n\r");

}

