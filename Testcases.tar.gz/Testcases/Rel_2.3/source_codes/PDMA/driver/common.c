/*
 * common.c
 *
 *  Created on: May 5, 2014
 *      Author: lxpham
 */

#include "../include/common.h"


void printPASS(void) {

	printf("\n\n");
	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
	printf ("$$$$ RESULT: TEST PASS $$$$\n");
	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
	printf("\n\n");
}

void printFAIL(void) {

    	printf("\n\n");
	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
	printf ("$$$$ RESULT: TEST FAILED $$$$\n");
	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
	printf("\n\n");
}

