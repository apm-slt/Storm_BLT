#ifndef VSPI_NAND
#define VSPI_NAND

//=================================================================
//Function: spi_read_id_serial_flash_memory
//=================================================================
int spi_read_id_serial_flash_memory (u32 base, u32 num_of_byte, u8 * pData,u32 slave_num)
{
	printf("spi_read_id_serial_flash_memory\n");
	int rc = 0;
    int i;
	u32 csr_base = base;
	u8 code[2];
	u8 cmd_len =2;
	u8 rx_length = 8;

	code[0]= 0x9F;
	code[1]= 0x00;
	xfer_read(csr_base, code, cmd_len, pData, rx_length, slave_num);

	for (i = 0; i <num_of_byte; i++) {
		printf("id code:%x\n",pData[i]);
	}

/*	spi1_release_bus();*/
//	printf("spi_read32(csr_base + SPI_SR):%x\n",spi_read32(csr_base + SPI_SR));

END1:
	//DEBUGMSG_SPI(ZONE_SPI_TRACE, "Leaving %s\n",__FUNCTION__);
	return rc;
}

//=================================================================
//Function: spi_write_data_to_cache
//=================================================================
int spi_write_data_to_cache (u32 base, u32 addr , u8 * pData, u32 tx_length, u32 slave_num)
{
	printf("spi_write_data_to_cache\n");
	int rc = 0;
	u8 addr_hi, addr_lo;
	u8 code[3];
	u8 cmd_len;
/*	rc = spi1_claim_bus();*/


	/* command reset flash*/
	code[0] = 0xFF;
	cmd_len = 1;
	xfer_write(base, code, cmd_len, NULL, 0, slave_num);
	delay_arb(1000);

	addr_hi =(u8)((addr>>8) & 0xff) ;
	addr_lo =(u8)(addr & 0xff) ;

	//write enable
	code[0] = 0x06;
	cmd_len = 1;
	xfer_write(base, code, cmd_len, NULL, 0, slave_num);

	//write data
	printf("addr_hi :%x\n",addr_hi);
	printf("addr_lo :%x\n",addr_lo);
	code[0] = 0x02;
	code[1] = addr_hi;
	code[2] = addr_lo;
	cmd_len = 3;

	xfer_write(base, code, cmd_len, pData, tx_length, slave_num);


END1:
	//DEBUGMSG_SPI(ZONE_SPI_TRACE, "Leaving %s\n",__FUNCTION__);
/*	spi1_release_bus();*/
	return rc;
}

//=================================================================
//Function		: 	spi_execute_program
//More explain	: 	time_out: check whether the function error or not
//					timeout : check error receive FIFO have data or not
//=================================================================
int spi_execute_program(u32 base, u32 addr, u32 slave_num)
{
	printf("spi_execute_program\n");
	int rc = 0;
	u32 i, cnt = 0;
	u8 addr_hi, addr_lo;
	u8 data_dummy,data;
	u8 code[4];
	u8 cmd_len;

/*	rc = spi1_claim_bus();*/

/*
	spi_setup_mode(SPI_TX_ONLY);
	spi_set_rx_data_length (0);

	REG_WRITE32(csr_base + SPI_DR,0xFF); //reset
	while(REG_READ32(csr_base + SPI_TXFLR)){}

*/
	addr_hi =(u8)((addr>>8) & 0xff) ;
	addr_lo =(u8)(addr & 0xff) ;

	/* command write enable flash*/
/*
	code[0] = 0x06;
	cmd_len = 1;
	xfer_write(csr_base, code, cmd_len, NULL, 0);
*/
	code[0] = 0x10;	//execute programe
	code[1] = 0x00;
	code[2] = addr_hi;
	code[3] = addr_lo;
	cmd_len = 4;
	xfer_write(base, code, cmd_len, NULL, 0, slave_num);

	/* command get feature flash*/
	code[0] = 0x0f;
	code[1] = 0xC0;
	cmd_len = 2;
	for (i = 0; i < SPI_FLASH_PAGE_ERASE_TIMEOUT; i++) {
		xfer_read(base, code, cmd_len, data, 1, slave_num);
		if (!(data & MT29F_FEATURE_STATUS_OIP)){
			if ((data&MT29F_FEATURE_STATUS_MASK)!=0){
				printf("SF: %s, Operation failed, status: 0x%02x!\n",__FUNCTION__, (u8)(data&MT29F_FEATURE_STATUS_MASK));
				return 1;
			}
			return 0;
		}

	}
	return rc;
}

//=================================================================
//Function		: 	spi_page_read
//More explain	: 	time_out: check whether the function error or not
//					timeout : check error receive FIFO have data or not
//=================================================================
int spi_page_read(u32 base, u32 addr, u32 slave_num)
{
	printf("spi_page_read\n");
	int rc = 0;
	u32 i, cnt = 0;
	u8 addr_hi, addr_lo;
	u8 data_dummy,data;
	u8 code[4];
	u8 cmd_len;

	addr_hi =(u8)((addr>>8) & 0xff) ;
	addr_lo =(u8)(addr & 0xff) ;
	printf("addr_hi :%x\n",addr_hi);
	printf("addr_lo :%x\n",addr_lo);

	cnt = 0;
	/* command reset flash*/
	code[0] = 0xFF;
	cmd_len = 1;
	xfer_write(base, code, cmd_len, NULL, 0, slave_num);
	delay_arb(1000);

	/* command read page flash*/
	code[0] = 0x13;
	code[1] = 0x00;
	code[2] = addr_hi;
	code[3] = addr_lo;
	cmd_len = 4;
	xfer_write(base, code, cmd_len, NULL, 0, slave_num);


	code[0] = 0x0f;
	code[1] = 0xC0;
	cmd_len = 2;
	for (i = 0; i < SPI_FLASH_PAGE_ERASE_TIMEOUT; i++) {
		xfer_read(base, code, cmd_len, data, 1, slave_num);
		if (!(data & 0x01)){
			break;
		}

	}
	return rc;

}

//=================================================================
//Function: spi_read_data_from_cache
//=================================================================
int spi_read_data_from_cache (u32 base, u32 addr , u8 * pData,u32 rx_length, u32 slave_num){
	printf("spi_read_data_from_cache\n");
	int rc = 0;
	u8 addr_hi, addr_lo;
	u8 code[4];
	u8 *buf;
	u8 cmd_len;
	u16 total_len;

	addr_hi =(u8)((addr>>8) & 0xff) ;
	addr_lo =(u8)(addr & 0xff) ;
	printf("addr_hi :%x\n",addr_hi);
	printf("addr_lo :%x\n",addr_lo);
	code[0] = 0x03;
	code[1] = addr_hi;
	code[2] = addr_lo;
	code[3] = 0;
	cmd_len = 4;

	xfer_read(base, code, cmd_len, pData, rx_length, slave_num);
#if 0
	dwspi_write32((void *)DWSPI_SER(DWSPI_BASE), 0);

/*	rc = spi1_claim_bus();*/
	printf("dwspi_read32((void *)DWSPI_SR(base)) :%x\n",dwspi_read32((void *)DWSPI_SR(csr_base)));

	spi_setup_mode( SPI_EEPROM_READ);
	spi_set_rx_data_length ( PAGE_DATA_SIZE);


/*	spi_write32(csr_base + SPI_SSIENR, 0x1);*/

/*	spi_write32(csr_base + SPI_DR, 0x03);

	spi_write32(csr_base + SPI_DR,addr_hi);

	spi_write32(csr_base + SPI_DR,addr_lo);

	spi_write32(csr_base + SPI_DR, 0x00);*/

	while(REG_READ32(csr_base + SPI_RXFLR)){
		data_dummy = REG_READ32(csr_base + SPI_DR);
	}

	printf("REG_READ32(csr_base + SPI_RXFLR) :%x\n",REG_READ32(csr_base + SPI_RXFLR));
	while (cmd_len)
	{
		trx_level = min((256-REG_READ32(csr_base + SPI_TXFLR)), cmd_len);
		printf("trx_level cmd transfer:%x\n",trx_level);
		if(trx_level)
		{
			for (cnt = 0;cnt<trx_level;cnt++)
			{
				printf("*buf+cnt :%x\n",code[cnt]);
				spi_write32(csr_base + SPI_DR,code[cnt]);
			}
			cmd_len -= trx_level;
			time_out = 1000;
		}
		else {
			time_out--;
			if(time_out == 0)
			{
				printf("missing write data tx_length:%d\n",rx_length);
				break;
			}
		}
	}
	dwspi_write32((void *)DWSPI_SER(DWSPI_BASE), 2);
	while(REG_READ32(csr_base + SPI_RXFLR) == 0);
	while (rx_length){
		trx_level = min(REG_READ32(csr_base + SPI_RXFLR), rx_length);
/*		printf("trx_level :%x  ,REG_READ32(csr_base + SPI_RXFLR) :%x\n",trx_level,REG_READ32(csr_base + SPI_RXFLR));*/
		if(trx_level){
			for (cnt = 0;cnt<trx_level;cnt++){
				*pData++ = REG_READ32(csr_base + SPI_DR);
			}
			rx_length -= trx_level;
			time_out=100;
	}
		else{
			time_out--;
			if(time_out == 0)
				break;
		}
	}
#endif
	spi_write32(base + SPI_SSIENR, 0x0);

/*	spi1_release_bus();*/

END1:
	return rc;
}


//=================================================================
//Function		: 	spi_erase
//More explain	: 	time_out: check whether the function error or not
//					timeout : check error receive FIFO have data or not
//=================================================================
int spi_erase(u32 base, u32 addr, u32 slave_num)
{
	printf("spi_erase\n");
	int rc = 0;
	u32 data_dummy,i,status_reg,time_out,timeout;
	u8 addr_hi,addr_lo;
	u8 code[4];
	u8 cmd_len;
	u8 data=0, ef_sts,oip_sts;

/*	rc = spi1_claim_bus();*/

	/* command reset flash*/
	code[0] = 0xFF;
	cmd_len = 1;
	xfer_write(base, code, cmd_len, NULL, 0, slave_num);
	delay_arb(1000);

	addr_hi =(u8)((addr>>8) & 0xff) ;
	addr_lo =(u8)(addr & 0xff) ;

	/* command unlock flash*/
	code[0] = 0x1f;
	code[1] = 0xA0;
	code[2] = 0x00;
	cmd_len = 3;
	xfer_write(base, code, cmd_len, NULL, 0, slave_num);

	/* command write enable flash*/
	code[0] = 0x06;
	cmd_len = 1;
	xfer_write(base, code, cmd_len, NULL, 0, slave_num);

	/* command erase flash*/
	code[0] = 0xD8;
	code[1] = 0x00;
	code[2] = addr_hi;
	code[3] = addr_lo;
	cmd_len = 4;
	xfer_write(base, code, cmd_len, NULL, 0, slave_num);

	/* command get feature flash*/
	code[0] = 0x0f;
	code[1] = 0xC0;
	cmd_len = 2;
	for (i = 0; i < SPI_FLASH_PAGE_ERASE_TIMEOUT; i++) {
		xfer_read(base, code, cmd_len, data, 1, slave_num);

		ef_sts = (u8)(data & MT29F_FEATURE_STATUS_EFAIL);
		oip_sts = (u8)(data & MT29F_FEATURE_STATUS_OIP);
		if ((ef_sts == 0) && (oip_sts == 0)) {
			break;
		}
	}

	if (i == SPI_FLASH_PAGE_ERASE_TIMEOUT) {
		printf("\n%s, Not ready in %d cycles, status = 0x%x\n",
				__FUNCTION__, SPI_FLASH_PAGE_ERASE_TIMEOUT, (u8)(data & MT29F_FEATURE_STATUS_MASK));
		return 1;
	} else {
		printf("\nSF: MTMicro: Erase success\n");
	}

	return rc;

}
void xfer_read(u32 csr_base, u8 *cmd, u8 cmd_len, u8 *pData, u32 rx_length,u32 slave_num){

	int rc = 0;
	u32 data_dummy,trx_level,cnt;
	u8 time_out;
	u8 *buffer;
	buffer = pData;
	volatile u8 sr;
	int i;

	while(spi_read32(csr_base + SPI_RXFLR)){
		data_dummy = spi_read32(csr_base + SPI_DR);
	}
	spi_disable_slave(csr_base, slave_num);
	spi_setup_mode(csr_base, SPI_EEPROM_READ);
	spi_set_rx_data_length (csr_base, rx_length);


	while (cmd_len)
	{
		trx_level = min((256-spi_read32(csr_base + SPI_TXFLR)), cmd_len);
		if(trx_level)
		{
			for (cnt = 0;cnt<trx_level;cnt++){
/*				printf("*buf+cnt :%x\n",cmd[cnt]);*/
				spi_write32(csr_base + SPI_DR,cmd[cnt]);
			}
			cmd_len -= trx_level;
			time_out = 1000;
		}
		else {
			time_out--;
			if(time_out == 0){
				printf("missing write data cmd_len:%d\n",cmd_len);
				break;
			}
		}
	}
	time_out = 1000;
	cnt = 0;
	spi_enable_slave(csr_base, slave_num);
/*	delay_arb(300);*/
	while(spi_read32(csr_base + SPI_RXFLR) ==0);
#ifndef SPEED_25MHZ
	printf(" read data at 25Mhz\n");
	while (cnt < rx_length){
		sr = spi_read32(base + SPI_RXFLR);
		for (i = 0; i < sr; i++){
			*pData++ = (u16)(spi_read32(base + SPI_DR));
			cnt++;
		}
	}
#else
	u32 dr = csr_base + SPI_DR;
	int rxlr = csr_base + SPI_RXFLR;
/*
	int timeout11;
	for (cnt = 0; cnt<rx_length; cnt ++){
		pData[cnt++] = (u16) (spi_read32(dr));
		sr = spi_read32(csr_base + SPI_RXFLR);
		timeout11 = 10000;
		while(timeout11--);
	}
*/
	while (cnt < rx_length){
		sr = spi_read32(rxlr);
		for (i = 0; i < sr; i++)
			*pData++ = (u32) (spi_read32(dr));
		cnt+= sr;
	}
#endif

	time_out=100;
	do{
	data_dummy  = spi_read32(csr_base + SPI_RXFLR);
//	printf("status_reg:%x\n",status_reg);
	time_out--;
	if(time_out == 0)
		printf("overflow FIFO\n");
		break;
	}while(data_dummy);

}


void xfer_write(u32 base, u8 *cmd, u8 cmd_len, u8 *pData, u32 tx_length, u32 slave_num){

	u16 cnt = 0,i,sr;
	u8 addr_hi, addr_lo;
	u32 status_reg,trx_level ;
	u32 time_out,data_dummy,tmp, tx, rx;
	u8 code[3];

	while(spi_read32(base + SPI_RXFLR)){
		data_dummy = spi_read32(base + SPI_DR);
	}
	spi_disable_slave(base, slave_num);
	spi_setup_mode(base, SPI_TX_ONLY);
	spi_set_rx_data_length (base, 0);

	while (cmd_len)
	{
		trx_level = min((256-spi_read32(base + SPI_TXFLR)), cmd_len);
		if(trx_level)
		{
			for (i = 0;i<trx_level;i++){
				spi_write32(base + SPI_DR,cmd[i]);
			}
			cmd_len -= trx_level;
			time_out = 1000;
		}
		else {
			time_out--;
			if(time_out == 0){
				printf("missing write data tx_length:%d\n",tx_length);
				break;
			}
		}
	}

	cnt = 0;
	int tx_length_tmp = tx_length;
	while(tx_length_tmp){
		sr = spi_read32(base + SPI_SR);
		if (sr & SPI_SR_TFNF_MASK){
			spi_write32(base + SPI_DR, pData[cnt]);
			cnt++;
			tx_length_tmp -- ;
		}
		else{
			break;
		}
	}

#ifndef SPEED_25MHZ
	spi_enable_slave(base, slave_num);
	delay_arb(100);
	while (tx_length) {
		//printf("test 0...\n");
		sr = spi_read32(base + SPI_SR);
		if (sr & SPI_SR_TFNF_MASK) {
//			printf("*(pData[cnt]):%x  cnt :%d\n",pData[cnt],cnt);
			spi_write32(base + SPI_DR, pData[cnt]);
			cnt++;
			tx_length--;

			//sr = dwspi_read32((void *)DWSPI_TXFLR(DWSPI_BASE));
			//printf("%d. count in transmit FIFO = %d\n", cnt, sr);

		}
	}
#else
	spi_enable_slave(base, slave_num);
	delay_arb(100);
/*
	while (cnt < tx_length){
		spi_write32((void *)base + SPI_DR, pData[cnt]);
		delay_arb(30);
		cnt++;
	}
*/
	while (cnt < tx_length){
		sr = spi_read32(base + SPI_TXFLR);
		for (i = 0; i < 256 - sr; i++){
			spi_write32(base + SPI_DR, pData[cnt]);
			cnt++;
		}
	}
#endif

	do{
	status_reg  = spi_read32(base + SPI_TXFLR);
	printf("status_reg:%x\n",status_reg);
	}while(status_reg);

}

int spi_rw_test_nand(u32 base, u32 slave_num)
{
	int rc = 0;
	u16 i;
	u8 data_modifier = 0x00;
	u8 spi_tx_data[PAGE_DATA_SIZE];
	u8 spi_rx_data[PAGE_DATA_SIZE];
	u8 id_code[8];
	u8 *buf_tx,*buf_rx;
	u32 tx_length, rx_length;

	buf_tx = spi_tx_data;
	buf_rx = spi_rx_data;
	tx_length = PAGE_DATA_SIZE;
	rx_length = PAGE_DATA_SIZE;

	for(i=0;i<PAGE_DATA_SIZE;i++){
		*buf_tx++ = data_modifier;
		data_modifier++;
	}
	for(i=0;i<PAGE_DATA_SIZE;i++){
		*buf_rx++ = 0;
	}
	buf_tx = spi_tx_data;
	buf_rx = spi_rx_data;

	printf("test read/write page %d %d bytes\n",SPI_RW_ROW_ADDR,PAGE_DATA_SIZE);

	rc = spi_read_id_serial_flash_memory (base, 0x8, id_code,slave_num);

	rc = spi_erase(base, SPI_RW_ROW_ADDR,slave_num);

	rc = spi_write_data_to_cache(base, SPI_RW_COLUMN_ADDR, buf_tx, tx_length,slave_num);

	rc = spi_execute_program(base, SPI_RW_ROW_ADDR,slave_num);

 	rc = spi_page_read(base, SPI_RW_ROW_ADDR,slave_num);

	rc = spi_read_data_from_cache (base, SPI_RW_COLUMN_ADDR, buf_rx, rx_length,slave_num);


	printf("compare\n");

	//for (i=0;i<PAGE_DATA_SIZE;i++)
	//	printf("spi_rx_data [%d]= %x   spi_tx_data [%d]= %x\n",i,spi_rx_data[i],i,spi_tx_data[i]);

	for (i=0;i<PAGE_DATA_SIZE;i++){
		printf("%d :   spi_tx_data: %x, spi_rx_data: %x\n", i, spi_tx_data[i],spi_rx_data[i]);
		if(spi_rx_data[i] !=  spi_tx_data[i]){
			rc++;
			printf("error at: %d\n",i);
			printf("spi_rx_data: %x, spi_tx_data: %x\n",spi_rx_data[i],spi_tx_data[i]);
			break;
			}
		}
	return rc;
}
#endif
