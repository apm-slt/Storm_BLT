/* Author: automation@apm.com
*  Company: Applied Micro Circuits Corporation (AMCC)
*
* Describe the purpose of your Test here
*   - Include all common functions here
*/

#define OCM_RESULT_ADDR 0x1D009000
#define OCM_FINISH_ADDR 0x1D00A900

#define OCM_READ(add) (*(volatile unsigned *)(add))
#define OCM_WRITE(add, data) *(unsigned *)(add) = (unsigned )(data)

//Tinh-SLT
//function define here
#define str2val str2val_spi
#define printPASS printPASS_spi
#define printFAIL printFAIL_spi

int mdelay(u32 msecs)
{
	return arch_timer_delay(msecs * 1000);
}

int udelay(u32 usecs)
{
	return arch_timer_delay(usecs);
}

unsigned int str2val(char* s)
{
        int i = 0;
        int j = 0;
        int val;
        while(s[i] != '\0')
                i++;
                i++;
                val = 0;
        for( j = 0; j< i; j++)
        {
                switch(s[j])
                {
                        case '0': val = 10* val + 0; break;
                        case '1': val = 10* val + 1; break;
                        case '2': val = 10* val + 2; break;
                        case '3': val = 10* val + 3; break;
                        case '4': val = 10* val + 4; break;
                        case '5': val = 10* val + 5; break;
                        case '6': val = 10* val + 6; break;
                        case '7': val = 10* val + 7; break;
                        case '8': val = 10* val + 8; break;
                        case '9': val = 10* val + 9; break;
                        default: break;
                }
        }

        return val;
}

void printPASS(void) {

	printf("\n\n");
	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
	printf ("$$$$ RESULT: TEST PASS $$$$\n");
	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
	printf("\n\n");

#ifdef OCM 
    OCM_WRITE(OCM_RESULT_ADDR,0x0);                 //Clear Addr first
    printf("Read=0x%08x\n",OCM_READ(OCM_RESULT_ADDR));
    OCM_WRITE(OCM_RESULT_ADDR,0xCAFECAFE);          //Test PASS
    printf("Read=0x%08x\n",OCM_READ(OCM_RESULT_ADDR));

    OCM_WRITE(OCM_FINISH_ADDR,0x3);                 //Test Complete
    printf("Read=0x%08x\n",OCM_READ(OCM_FINISH_ADDR));
#endif
}

void printFAIL(void) {

    	printf("\n\n");
	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
	printf ("$$$$ RESULT: TEST FAILED $$$$\n"); 
	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
	printf("\n\n");

#ifdef OCM
    OCM_WRITE(OCM_RESULT_ADDR,0x0);                 //Clear Addr first
    printf("Read=0x%08x\n",OCM_READ(OCM_RESULT_ADDR));
    OCM_WRITE(OCM_RESULT_ADDR,0xDEADBEEF);          //Test FAIL
    printf("Read=0x%08x\n",OCM_READ(OCM_RESULT_ADDR));
    
    OCM_WRITE(OCM_FINISH_ADDR,0x3);                 //Test Complete
    printf("Read=0x%08x\n",OCM_READ(OCM_FINISH_ADDR));
#endif
}

