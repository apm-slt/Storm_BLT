#ifndef         __COMMON_DEF__
#define         __COMMON_DEF__

/* Tinh: 05/16/14 */
#include "types.h"

//Tinh-SLT:
//function defined here
#define read32 read32_spi
#define write32 write32_spi

int data_modifier;

static unsigned int reverse (unsigned int var)
{
  unsigned int val,val1,val2,val3,val4;

  val1 = (var & 0xFF000000) >> 24 ;
  val2 = (var & 0x00FF0000) >> 8 ;
  val3 = (var & 0x0000FF00) << 8;
  val4 = (var & 0x000000FF) << 24;

  val = val1 + val2 + val3 + val4;
  return (val);
}
static unsigned int reverse16 (unsigned int var)
{
  unsigned int val,val1,val2;

  val1 = (var & 0xFF00) >> 8 ;
  val2 = (var & 0x00FF) << 8;

  val = val1 + val2 ;
  return (val);
}
/*
unsigned int read32(addr){
	unsigned int data;
	data = (*((unsigned int *)((u64_s)addr)));
	XHCI_READ("Read %x from addr :%x\n",data,addr);
	return data;
}
void write32(addr,val){
	XHCI_WRITE("addr :%x  value:%x\n",addr,val);
	*((unsigned int *)((u64_s)addr)) = (unsigned int)val;
}
*/
int  read32(u32_s addr) {
//	printf("read addr :%x\n",addr);
	return *(volatile u32_s*)addr;
}

void write32(u32_s addr, u32_s val){
//	printf("write: addr 0x%x val 0x%08x\n", addr, val);
	*(volatile u32_s*)addr=(volatile u32_s)val;
}

int xhci_readl(u32_s *addr){
	//printf("read addr :%x\n",addr);
	return *(volatile u32_s*)addr;
}
void xhci_writel(int value, int *addr){
	//printf("xhci_writel: addr 0x@%p val 0x%08x\n", addr, value);
	*(volatile u32_s*)addr=(volatile u32_s)value;
}

#define read32_le(addr)                     reverse((*((unsigned int *)((u64_s)addr))))
#define write32_le(addr,val)                *((unsigned int *)((u64_s)addr)) = reverse((unsigned int)val)



#define i2c_read32(a)                         	read32(a)
#define i2c_write32(a,v) 	                    write32(a,v)
#define i2c_read32_le(a)                     	read32_le(a)
#define i2c_write32_le(a,v)             	    write32_le(a,v)

#define spi_read32(a)                     	    read32(a)
#define spi_write32(a,v)	                   	write32(a,v)

/*unsigned int xhci_readl(addr){
	unsigned int data;
	data = (*((unsigned int *)((u64_s)addr)));
	XHCI_READ("Read %x from addr :%x\n",data,addr);
	return data;
}
void xhci_writel(val,addr){
	XHCI_WRITE("addr :%x  value:%x\n",addr,val);
	*((unsigned int *)((u64_s)addr)) = (unsigned int)val;
}*/
#define reg_read32(a)                         	read32(a)
#define reg_write32(a,v) 	                    write32(a,v)


#define	cpu_to_le16
#define	cpu_to_le32
#define	cpu_to_le64

#define	le16_to_cpu
#define	le32_to_cpu
#define	le64_to_cpu

#define le16_to_cpus

#define le32_to_cpus
#define le64_to_cpus

/*
#define	cpu_to_le16(a)							_swab16(a)
#define	cpu_to_le32(a)							_swab32(a)
#define	cpu_to_le64(a)							_swab64(a)

#define	le16_to_cpu(a)							_swab16(a)
#define	le32_to_cpu(a)							_swab32(a)
#define	le64_to_cpu(a)							_swab64(a)

#define le16_to_cpus(x) do { *(x) = _swab16((x));} while (0)

#define le32_to_cpus(x) do { *(x) = _swab32((x));} while (0)
#define le64_to_cpus(x) do { *(x) = _swab64((x));} while (0)
*/

#define malloc(a)								memalloc(a)
/*#define free(a)									memfree(a);*/
#define free


//#define NOFREE

#ifndef ARRAY_SIZE
#define ARRAY_SIZE(x) (sizeof(x) / sizeof((x)[0]))
#endif

/* Define Graphic Mode */
#define GRAPH_ALL_ATTRIBUTE_OFF				0
#define GRAPH_BOLD_ON						1
#define GRAPH_UNDERSCORE					4
#define GRAPH_BLINK_ON						5
#define GRAPH_REVERSE_VIDEO_ON				7
#define GRAPH_CONCEALED_ON					8
#define GRAPH_FOREGROUND_COLOR_BLACK		30
#define GRAPH_FOREGROUND_COLOR_RED			31
#define GRAPH_FOREGROUND_COLOR_GREEN		32
#define GRAPH_FOREGROUND_COLOR_YELLOW		33
#define GRAPH_FOREGROUND_COLOR_BLUE			34
#define GRAPH_FOREGROUND_COLOR_MAGENTA		35
#define GRAPH_FOREGROUND_COLOR_CYAN			36
#define GRAPH_FOREGROUND_COLOR_WHITE		37
#define GRAPH_BACKGROUND_COLOR_BLACK		40
#define GRAPH_BACKGROUND_COLOR_RED			41
#define GRAPH_BACKGROUND_COLOR_GREEN		42
#define GRAPH_BACKGROUND_COLOR_YELLOW		43
#define GRAPH_BACKGROUND_COLOR_BLUE			44
#define GRAPH_BACKGROUND_COLOR_MAGENTA		45
#define GRAPH_BACKGROUND_COLOR_CYAN			46
#define GRAPH_BACKGROUND_COLOR_WHITE		47
#define set_graphic_mode(mode)				printf("\033[%dm",mode)

#define APM_NOTICE(x...) do{set_graphic_mode(GRAPH_FOREGROUND_COLOR_BLUE);\
								printf( x ); \
								set_graphic_mode(GRAPH_ALL_ATTRIBUTE_OFF);\
							}while(0)

#ifndef ARRAY_SIZE
#define ARRAY_SIZE(x) (sizeof(x) / sizeof((x)[0]))
#endif

#endif

