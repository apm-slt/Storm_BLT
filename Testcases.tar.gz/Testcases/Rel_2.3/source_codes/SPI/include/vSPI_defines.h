#ifndef SPI_DEF
#define SPI_DEF

#define min(X, Y)				\
	({ typeof (X) __x = (X), __y = (Y);	\
		(__x < __y) ? __x : __y; })

#define SPI0_IRQNO								106
#define SPI1_IRQNO 								107

#define REG_GROUP_SRST_CLKEN					0
#define REG_GROUP_SRST1_CLKEN1					1
#define MEM_RDY_TIMEOUT_COUNT					10000

/*
 * SPI FIFO Depth
 */
#define	DWSPI_TX_FIFO_DEPTH						8
#define DWSPI_RX_FIFO_DEPTH						8

/*
 * SPI MASK
 */
#define SPI0_F1_MASK							0x000003ff
#define SPI1_F1_MASK							0x000003ff
#define SPI_ISR_TXEIS_MASK						0x01
#define SPI_ISR_RXFIS_MASK						0x10
#define SPI_IMR_TXEIM_MASK						0x01
#define SPI_IMR_RXFIM_MASK						0x10
#define SPI_IMR_VAL								0x0
#define SPI_SSIENR_SSI_EN_MASK					0x1
#define SPI_CTRLR1_MASK							0xFFFF
#define SPI_SR_BUSY_MASK						0x01
#define SPI_SR_TFNF_MASK						0x02
#define SPI_SR_TFE_MASK							0x04
#define SPI_SR_RFNE_MASK						0x08
#define SPI_SR_RFF_MASK							0x10
#define SPI_CTRLR0_TMOD_MASK 					0x0300


/*
 * Threshold value
 */
#define SPI_TXFTLR_VAL							(DWSPI_TX_FIFO_DEPTH-1)
#define SPI_RXFTLR_VAL							0x0

/*
 * SPI mode flags
 */
#define	SPI_CPHA								0x01			/* clock phase */
#define	SPI_CPOL								0x02			/* clock polarity */
#define	SPI_MODE_0								(0|0)			/* (original MicroWire) */
#define	SPI_MODE_1								(0|SPI_CPHA)
#define	SPI_MODE_2								(SPI_CPOL|0)
#define	SPI_MODE_3								(SPI_CPOL|SPI_CPHA)
#define	SPI_CS_HIGH								0x04			/* CS active high */
#define	SPI_LSB_FIRST							0x08			/* per-word bits-on-wire */
#define	SPI_3WIRE								0x10			/* SI/SO signals shared */
#define	SPI_LOOP								0x20			/* loopback mode */


/*
 * Speed
 */
#define SPEED_50MHZ								2
#define SPEED_25MHZ								4
#define SPEED_1MHZ								100
#define SPEED_3MHZ								34
#define SPEED_5MHZ								20
#define SPEED_10MHZ								10


/*
 * Max chip select
 */
#define SPI_MAXCS								4

/*
 * Chip Select
 */
#define CS0										0
#define CS1										1
#define CS2										2


/*
 * SPI TEST
 */
#define	PAGE_DATA_SIZE							2048
#define SPI_RW_ADDR 							0x0000
#define SPI_RW_ROW_ADDR							0x0000
#define SPI_RW_COLUMN_ADDR						0x0000
#define SPI_FLASH_PROG_TIMEOUT					(2 * 1000)
#define SPI_FLASH_PAGE_ERASE_TIMEOUT			(5 * 1000)
#define SPI_FLASH_SECTOR_ERASE_TIMEOUT			(10 * 1000)

	#define MT29F_FEATURE_STATUS_OIP			(1<<0) /* Operation in progress */
	#define MT29F_FEATURE_STATUS_WEL			(1<<1) /* Write enable latch */
	#define MT29F_FEATURE_STATUS_EFAIL			(1<<2) /* Erase fail */
	#define MT29F_FEATURE_STATUS_PFAIL			(1<<3) /* Program fail */
	#define MT29F_FEATURE_STATUS_ECC_S0			(1<<4) /* Program fail */
	#define MT29F_FEATURE_STATUS_ECC_S1			(1<<5) /* Program fail */
	#define MT29F_FEATURE_STATUS_MASK			0x2D
/*
 * EEPROM Command
 */

#define EPROM_CMD_STATUS_WRITE                  0x01 /* EPROM Status Write */
#define EPROM_CMD_PAGE_WRITE                    0x02 /* EPROM Page Write */
#define EPROM_CMD_PAGE_READ                             0x03 /* EPROM Page Read */
#define EPROM_CMD_WRITE_DISABLE                 0x04 /* EPROM Write Disable */
#define EPROM_CMD_STATUS_READ                   0x05 /* EPROM Status Read */
#define EPROM_CMD_WRITE_ENABLE                  0x06 /* EPROM Write Enable */

#define EEPROM_PATERN							0x5A

#define CMD_N25Q256_RDID						0x9F /* Read Volatile Enhanced Configuration Register */
/* N25Q128-specific commands: Legacy protocol */
#define CMD_N25Q256_WRSR		0x01 /* Write Status Register */
#define CMD_N25Q256_PP			0x02 /* Page Program */
#define CMD_N25Q256_READ		0x03 /* Read Data Bytes */
#define CMD_N25Q256_WRDI		0x04 /* Write Disable */
#define CMD_N25Q256_RDSR		0x05 /* Read Status Register */
#define CMD_N25Q256_WREN		0x06 /* Write Enable */
#define CMD_N25Q256_FAST_READ	0x0B /* Read Data Bytes at Higher Speed */
#define CMD_N25Q256_RES			0xAB /* Release from DP, and Read Signature */
#define CMD_N25Q256_DP			0xB9 /* Deep Power-down */
#define CMD_N25Q256_BE			0xC7 /* Bulk Erase */
#define CMD_N25Q256_SE			0xD8 /* Sector Erase */

/* Update new protocol only for N25Q128 */
#define CMD_N25Q256_ROTP		0x4B /* Read OTP (Read of OTP area) */
#define CMD_N25Q256_POTP		0x42 /* Program OTP (Program of OTP area) */
#define CMD_N25Q256_SSE			0x20 /* SubSector Erase */
#define CMD_N25Q256_PER			0x7A /* Program/Erase Resume */
#define CMD_N25Q256_PES			0x75 /* Program/Erase Suspend */
#define CMD_N25Q256_RDLR		0xE8 /* Read Lock Register */
#define CMD_N25Q256_WDLR		0xE5 /* Write Lock Register */
#define CMD_N25Q256_RFSR		0x70 /* Read Flag Status Register */
#define NUMONYX_RFSR_PE			(1 << 7)	/* Prog/Erase Controler status */
#define CMD_N25Q256_CLFSR		0x50 /* Clear Flag Status Register */
#define CMD_N25Q256_RDNVCR		0xB5 /* Read NV Configuration Register */
#define CMD_N25Q256_WRNVCR		0xB1 /* Write NV Configuration Register */
#define CMD_N25Q256_RDVCR		0x85 /* Read Volatile Configuration Register */
#define CMD_N25Q256_WRVCR		0x81 /* Write Volatile Configuration Register */
#define CMD_N25Q256_RDVECR		0x65 /* Read Volatile Enhanced Configuration Register */
#define CMD_N25Q256_WRVECR		0x61 /* Write Volatile Enhanced Configuration Register */

#define WR_ENABLE_ACTION		0
#define RD_STATUS_FLAG_ACTION	1
#define WR_FLAG_ACTION			2
#define NUMONYX_SR_WIP		   (1 << 0)	/* Write-in-Progress */
#define NUMONYX_SR_WEL		   (1 << 1)	/* Write-enable */

#define BYTES_NO 				256
#define PATTERN					1




/* Dual I/O protocol */
#define CMD_N25Q256_MIORDID		0xAF /* Read Identification */
#define CMD_N25Q256_DOFR		0x3B /* Dual Output Fast Read  */
#define CMD_N25Q256_DIOFR		0xBB /* Dual Input/Output Fast Read */
#define CMD_N25Q256_DIFP		0xA2 /* Dual Input Fast Program */
#define CMD_N25Q256_DIEFP		0xD2 /* Dual Input Extended Fast Program */

/* Quad I/O protocol */
//#define CMD_N25Q256_MIORDID		0xAF /* Read Identification */
#define CMD_N25Q256_QOFR		0x6B /* Quad Output Fast Read */
#define CMD_N25Q256_QIOFR		0xEB /* Quad Input/Output Fast Read */
#define CMD_N25Q256_QIFP		0x32 /* Quad Input Fast Program */
#define CMD_N25Q256_QIEFP		0x12 /* Quad Input Extended Fast Program */

/* block protected*/
#define BP0 					(1<<2)
#define BP1 					(1<<3)
#define BP2 					(1<<4)
#define BP3 					(1<<6)



/*
 * Modes for spi master
 */
#define	SPI_TX_RX								0x0000		//;#tx & rx
#define	SPI_TX_ONLY								0x0100		//;#tx only
#define	SPI_RX_ONLY								0x0200		//;#rx only
#define	SPI_EEPROM_READ							0x0300		//;#EEPROM Read

#define SPI_CTRLR0_DFS_MASK						0x000F
#define SPI_CTRLR0_DFS_VAL						0x0007

#define SPI_SCPH_MASK							0x0040
#define SPI_SCPOL_MASK							0x0080

#define SPI_CFS_MASK							0xF000
#define SPI_CFS_8								7





#endif
