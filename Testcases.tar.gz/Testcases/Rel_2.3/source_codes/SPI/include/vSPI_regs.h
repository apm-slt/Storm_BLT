#ifndef SPI_REG
#define SPI_REG
/*#define SPI1_BASE			0x1C026000*/

/*
 * CSR Base
 */

#define AHBC_SRST               0x1F2AC000
#define AHBC_CLKEN              0x1F2AC008

#define SPI_CONFIG				0x1f2a0004

/*
 * SPI Register
 */
#define SPI0_BASE				0x1C025000
#define SPI1_BASE				0x1C026000

#define SPI_CTRLR0    			0x00000000 		//RW
#define SPI_CTRLR1    			0x00000004
#define SPI_SSIENR    			0x00000008
#define SPI_MWCR      			0x0000000C
#define SPI_SER       			0x00000010
#define SPI_BAUDR     			0x00000014
#define SPI_TXFTLR    			0x00000018
#define SPI_RXFTLR    			0x0000001C

#define SPI_TXFLR     			0x00000020		//RO
#define SPI_RXFLR     			0x00000024
#define SPI_SR        			0x00000028

#define SPI_IMR       			0x0000002C		//RW

#define SPI_ISR       			0x00000030		//RO
#define SPI_RISR      			0x00000034
#define SPI_TXOICR    			0x00000038
#define SPI_RXOICR    			0x0000003C
#define SPI_RXUICR    			0x00000040
#define SPI_MSTICR    			0x00000044
#define SPI_ICR       			0x00000048
#define SPI_DMACR     			0x0000004C
#define SPI_DMATDLR   			0x00000050
#define SPI_DMARDLR   			0x00000054
#define SPI_IDR       			0x00000058
#define SPI_VERID     			0x0000005C

#define SPI_DR        			0x00000060		//RW
#define SPI_RX_SPL_DL           0x000000F0
#endif
