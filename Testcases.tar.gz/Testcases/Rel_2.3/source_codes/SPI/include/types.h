#ifndef _LINUX_TYPES_H
#define _LINUX_TYPES_H

typedef unsigned short umode_t;

typedef __signed__ char __s8_s;
typedef unsigned char __u8_s;

typedef __signed__ short __s16_s;
typedef unsigned short __u16_s;

typedef __signed__ int __s32_s;
typedef unsigned int __u32_s;

/*=====================================*/

typedef		__u8_s		uint8_t_s;
typedef		__u16_s		uint16_t_s;
typedef		__u32_s		uint32_t_s;

/*=====================================*/

typedef signed char s8_s;
typedef unsigned char u8_s;

typedef signed short s16_s;
typedef unsigned short u16_s;

typedef signed int s32_s;
typedef unsigned int u32_s;

typedef signed long long s64_s;
typedef unsigned long long u64_s;

/*=====================================*/

typedef		__u8_s		u_int8_t_s;
typedef		__s8_s		int8_t_s;
typedef		__u16_s		u_int16_t_s;
typedef		__s16_s		int16_t_s;
typedef		__u32_s		u_int32_t_s;
typedef		__s32_s		int32_t_s;

/*=====================================*/

typedef		__u8_s		uint8_t_s;
typedef		__u16_s		uint16_t_s;
typedef		__u32_s		uint32_t_s;

typedef u32_s size_t_s;

#endif /* _LINUX_TYPES_H */
