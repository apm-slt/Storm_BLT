int check_int = 0;

void spi_multi_master(void){
	int csr_base;
	u8 i=0,data[8];
	check_int = 1;
	csr_base = SPI1_BASE;
	int clear_int;
	APM_NOTICE("spi_multi_master\n");
	clear_int = spi_read32(csr_base + SPI_MSTICR);
	while(1);

	printf("\n");
}

/*
 * rx fifo full interrupt
 */
void spi1_rxfi_isr (void){
	int csr_base;
	u8 i=0,data[8];
	check_int = 1;
	csr_base = SPI1_BASE;
	APM_NOTICE("spi1 RXFI\n");
	while(spi_read32(csr_base + SPI_RXFLR)){
		data[i] = (u32) (spi_read32(csr_base + SPI_DR));
		printf("ID Code:  ");
		printf("%x   ",data[i]);
		i++;
	}
	printf("\n");
}
void spi0_rxfi_isr (void){
	int csr_base;
	u8 i=0,data[8];
	check_int = 2;
	csr_base = SPI0_BASE;
	APM_NOTICE("spi0 RXFI\n");
	while(spi_read32(csr_base + SPI_RXFLR)){
		data[i] = (u32) (spi_read32(csr_base + SPI_DR));
		printf("ID Code:  ");
		printf("%x   ",data[i]);
		i++;
	}
	printf("\n");
}
/*
 * rx overflow interrupt
 */
void spi1_rxoi_isr (void){
	int csr_base;
	u8 i=0,data[8];
	check_int = 1;
	csr_base = SPI1_BASE;
	int clear_int;
	APM_NOTICE("spi1 RXOI\n");
	clear_int = spi_read32(csr_base + SPI_RXOICR);

	printf("\n");
}
void spi0_rxoi_isr (void){
	int csr_base;
	u8 i=0,data[8];
	check_int = 2;
	csr_base = SPI0_BASE;
	int clear_int;
	APM_NOTICE("spi0 RXOI\n");
	clear_int = spi_read32(csr_base + SPI_RXOICR);
	printf("\n");
}
/*
 * RX Underflow Interrupt
 */
void spi1_rxui_isr (void){
	int csr_base;
	u8 i=0,data[8];
	check_int = 1;
	csr_base = SPI1_BASE;
	int clear_int;
	APM_NOTICE("spi1 RXUI\n");
	clear_int = spi_read32(csr_base + SPI_RXUICR);

	printf("\n");
}
void spi0_rxui_isr (void){
	int csr_base;
	u8 i=0,data[8];
	check_int = 2;
	csr_base = SPI0_BASE;
	int clear_int;
	APM_NOTICE("spi0 RXUI\n");
	clear_int = spi_read32(csr_base + SPI_RXUICR);
	printf("\n");
}
/*
 * TX Overflow Interrupt
 */
void spi1_txoi_isr (void){
	int csr_base;
	u8 i=0,data[8];
	check_int = 1;
	csr_base = SPI1_BASE;
	int clear_int;
	APM_NOTICE("spi1 TXOI\n");
	clear_int = spi_read32(csr_base + SPI_TXOICR);

	printf("\n");
}
void spi0_txoi_isr (void){
	int csr_base;
	u8 i=0,data[8];
	check_int = 2;
	csr_base = SPI0_BASE;
	int clear_int;
	APM_NOTICE("spi0 TXOI\n");
	clear_int = spi_read32(csr_base + SPI_TXOICR);
	printf("\n");
}
/*
 * TX Empty Interrupt
 */
void spi1_txei_isr (void){
	int base = SPI1_BASE;
	check_int = 1;
	spi_write32(base + SPI_IMR, 0);

	APM_NOTICE("spi1 TXEI\n");

	printf("\n");
}
void spi0_txei_isr (void){
	int base = SPI0_BASE;
	check_int = 2;
	spi_write32(base + SPI_IMR, 0);

	APM_NOTICE("spi0 TXEI\n");

	printf("\n");
}

int spi1_RXF_test(int intr_mask, int rxftlr,int rx_length){
	int base;
	int i,time_out= 10000,ret;
	u32 slave_num;
	int cmd[2],cmd_len;
	slave_num = 0;
	base = SPI1_BASE;
	check_int = 0;

	ret = spi_init_h(base);

	u8 id_code[8];
	/* Initialize controller */
	spi_init_core(base,SPEED_1MHZ,slave_num);

	v_spi_claim_bus(base,slave_num);

	spi_reset(base,slave_num);

	spi_write32(base + SPI_IMR, intr_mask);
	spi_write32(base + SPI_RXFTLR, 0x3);

/*  Send command read ID, receive data to the FIFO and check the RXFI*/
	cmd[0]= 0x9F;
	cmd[1]= 0x00;
	cmd_len = 2;

	spi_disable_slave(base, slave_num);
	spi_setup_mode(base, SPI_EEPROM_READ);
	spi_set_rx_data_length (base, rx_length);

	for (i = 0;i<cmd_len;i++){
		spi_write32(base + SPI_DR,cmd[i]);
	}

	spi_enable_slave(base, slave_num);

	while(time_out--){
		mdelay(10);
		if (check_int==1){
			printf("Receive the interrupt\n");
			break;
		}
	}
	if (time_out <= 0){
		printf("No interrupt\n");
		return -1;
	}
	return 0;
}

int spi0_RXF_test(int intr_mask, int rxftlr,int rx_length){
	int base;
	int i,time_out = 1000,ret;
	u32 slave_num;
	int cmd[2],cmd_len;
	slave_num = 0;
	base = SPI0_BASE;
	check_int = 0;

	ret = spi_init_h(base);

	u8 id_code[8];
	/* Initialize controller */
	spi_init_core(base,SPEED_1MHZ,slave_num);

	v_spi_claim_bus(base,slave_num);

	spi_reset(base,slave_num);

	spi_write32(base + SPI_IMR, intr_mask);
	spi_write32(base + SPI_RXFTLR, 0x3);

/*  Send command read ID, receive data to the FIFO and check the RXFI*/
	cmd[0]= 0x9F;
	cmd_len = 1;

	spi_disable_slave(base, slave_num);
	spi_setup_mode(base, SPI_EEPROM_READ);
	spi_set_rx_data_length (base, rx_length);

	for (i = 0;i<cmd_len;i++){
		spi_write32(base + SPI_DR,cmd[i]);
	}

	spi_enable_slave(base, slave_num);

	while(time_out--){
		mdelay(10);
		if (check_int==2){
			printf("Receive the interrupt\n");
			break;
		}
	}
	if (time_out <= 0){
		printf("No interrupt\n");
		return -1;
	}
	return 0;
}



int spi_RXUI_test(int base, int intr_mask){
	int i,time_out = 1000,ret;
	u32 slave_num;
	int count, data;
	slave_num = 0;
	check_int = 0;

	ret = spi_init_h(base);

	u8 id_code[8];
	/* Initialize controller */
	spi_init_core(base,SPEED_1MHZ,slave_num);

	v_spi_claim_bus(base,slave_num);

	spi_write32(base + SPI_IMR, intr_mask);

//read data until empty and after that reading one to generate interrupt
	count = spi_read32(base + SPI_RXFLR);
	for (i = 0;i<count + 1;i++){
		data = (u32) (spi_read32(base + SPI_DR));
	}

	while(time_out--){
		mdelay(10);
		if (check_int==1){
			printf("Receive the interrupt SPI1\n");
			break;
		}
		if (check_int==2){
			printf("Receive the interrupt SPI0\n");
			break;
		}
	}
	if (time_out <= 0){
		printf("No interrupt\n");
		return -1;
	}
	return 0;
}

int spi_TXOI_test(int base, int intr_mask){
	int i,time_out = 1000,ret;
	u32 slave_num;
	int count, data=1;
	slave_num = 0;
	check_int = 0;
	ret = spi_init_h(base);

	u8 id_code[8];
	/* Initialize controller */
	spi_init_core(base,SPEED_1MHZ,slave_num);

	v_spi_claim_bus(base,slave_num);

	spi_disable_slave(base, slave_num);

	spi_write32(base + SPI_IMR, intr_mask);

//write data untill it over flow
	for (i = 0;i<257;i++){
		spi_write32(base + SPI_DR,data);
		mdelay(5);
		if ((check_int==1) ||(check_int==2)) {
			printf("Receive the interrupt SPI\n");
			break;
		}
	}
	if (check_int == 0) {
		printf("Do not Receive the interrupt SPI\n");
		return -1;
	}
	return 0;
}

int spi_TXEI_test(int base, int intr_mask){
	int i,time_out = 1000,ret;
	u32 slave_num;
	int data,tx_len=100;
	slave_num = 0;
	check_int = 0;

	ret = spi_init_h(base);

	/* Initialize controller */
	spi_init_core(base,SPEED_1MHZ,slave_num);

	v_spi_claim_bus(base,slave_num);

	spi_write32(base + SPI_IMR, intr_mask);

/*  Send command read ID, receive data to the FIFO and check the RXFI*/

	spi_disable_slave(base, slave_num);
	spi_setup_mode(base, SPI_TX_ONLY);
	spi_set_rx_data_length (base, 0);

	for (i = 0;i<tx_len;i++){
		spi_write32(base + SPI_DR,data);
	}

	spi_enable_slave(base, slave_num);

	while(time_out--){
		mdelay(10);
		if ((check_int==1)||(check_int==2)){
			printf("Receive the interrupt\n");
			break;
		}
	}
	if (time_out <= 0){
		printf("No interrupt\n");
		return -1;
	}
	return 0;
}
