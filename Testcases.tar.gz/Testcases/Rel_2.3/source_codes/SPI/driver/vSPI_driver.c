/* Tinh: 05/16/14 */
//#include "../include/common_def.h"
//#include "../include/common.h"
void * memset_s(void * s,int c,size_t_s count)
{
    char *xs = (char *) s;
    while (count--)
        *xs++ = c;
    return s;
}
void delay_arb(u32_s count)
{
    if(count < 0) {
        printf("ERR: Invalid value for count:: %08x", count);
        return;
    }
    while(count--);
}

void spi_enable_slave(u32_s base, u32_s slave_num)
{
	u32_s ser;
	if (SPI_MAXCS <= slave_num)
		return;
	ser = spi_read32(base + SPI_SER);
	ser = ser | (0x1 << slave_num);
	spi_write32(base + SPI_SER, ser);
}
void spi_disable_slave(u32_s base, u32_s slave_num)
{
	u32_s ser;
	if (SPI_MAXCS <= slave_num)
		return;
	ser = spi_read32(base + SPI_SER);
	ser = ser & ~(0x1 << slave_num);
	spi_write32(base + SPI_SER, ser);
}

void spi_enable(u32_s base)
{
	u32_s spi_stat;
	spi_stat = spi_read32(base + SPI_SSIENR);
	if (!(spi_stat & SPI_SSIENR_SSI_EN_MASK))
		spi_write32(base + SPI_SSIENR, 0x1);
}

void v_spi_claim_bus(u32_s base, u32_s slave_num)
{
	spi_enable_slave(base, slave_num);
	spi_enable(base);
	return 0;
}
struct am862xx_reset_ctrl {
	int		reg_group;
	unsigned int	clken_mask;
	unsigned int	csr_reset_mask;
	unsigned int	reset_mask;
	unsigned int	mem_rdy_mask;
	unsigned int	*ram_shutdown_addr;
};
int reset_am862xx_block(struct am862xx_reset_ctrl *reset_ctrl)
{
	/* Reset IP */
	int tmp,i;

	/* Release Reset */
	tmp = spi_read32(AHBC_SRST);
	tmp = tmp & (~reset_ctrl->csr_reset_mask);
	spi_write32(AHBC_SRST, tmp);

	/* Enable */
	tmp = spi_read32(AHBC_CLKEN);
	tmp = tmp | reset_ctrl->clken_mask;
	spi_write32(AHBC_CLKEN, tmp);
	return 0;
}
void spi_disable(u32_s base){
	u32_s spi_stat;
	spi_stat = spi_read32(base + SPI_SSIENR);
	if (spi_stat & SPI_SSIENR_SSI_EN_MASK)
		spi_write32(base + SPI_SSIENR, 0x0);
}
void spi_set_mode(u32_s base, u32_s mode)
{
	u32_s ctrlr0;
	u32_s spi_stat;
	spi_stat = spi_read32(base + SPI_SSIENR);
	if (spi_stat & SPI_SSIENR_SSI_EN_MASK)
		spi_write32(base + SPI_SSIENR, 0x0);

	ctrlr0 = spi_read32(base + SPI_CTRLR0);

	ctrlr0 &= ~SPI_CFS_MASK;
	ctrlr0 |= SPI_CFS_8 << 12;

	ctrlr0 &= ~SPI_CTRLR0_TMOD_MASK;
	ctrlr0 |= SPI_EEPROM_READ;

	ctrlr0 &= ~SPI_CTRLR0_DFS_MASK;
	ctrlr0 |= SPI_CTRLR0_DFS_VAL;

	if (mode & SPI_CPHA)
		ctrlr0 |= SPI_SCPH_MASK;
	else
		ctrlr0 &= ~SPI_SCPH_MASK;

	if (mode & SPI_CPOL)
		ctrlr0 |= SPI_SCPOL_MASK;
	else
		ctrlr0 &= ~SPI_SCPOL_MASK;

	spi_write32(base + SPI_CTRLR0, ctrlr0);
	if (spi_stat & SPI_SSIENR_SSI_EN_MASK)
		spi_write32(base + SPI_SSIENR, 1);
}
void spi_init_core(u32_s base, u32_s speed, u32_s slave_num)
{
	/* Disable controller */
	spi_disable(base);

	/* Disable all the interrupts just in case */
	spi_write32(base + SPI_IMR, SPI_IMR_VAL);

	/* Set TX full IRQ threshold */
	spi_write32(base + SPI_TXFTLR, SPI_TXFTLR_VAL);

	/* Set RX empty IRQ threshold */
	spi_write32(base + SPI_RXFTLR, SPI_RXFTLR_VAL);

	/* Set default mode */
	spi_set_mode(base, SPI_MODE_3);

	/* Set Baud */
	spi_write32(base + SPI_BAUDR, speed);

	//RX_SAMPLE_DELAY
	spi_write32((base + 0xf0), 1);

	/* Disable all interrupt */
	spi_write32(base + SPI_IMR, 0x00000000);

	/* Disable chip select for all slaves */
	spi_write32(base + SPI_SER, 0x0);
}

int spi_init_h(u32_s base)
{

	//printf("spi init\n");
	u8_s rc;

	struct am862xx_reset_ctrl reset_ctrl;

	/* Reset the IP */
	memset(&reset_ctrl, 0, sizeof(reset_ctrl));
	switch (base){
		case SPI1_BASE:
			reset_ctrl.clken_mask		= SPI1_F1_MASK;
			reset_ctrl.csr_reset_mask	= SPI1_F1_MASK;
			reset_ctrl.reset_mask		= SPI1_F1_MASK;
			break;
		case SPI0_BASE:
			reset_ctrl.clken_mask		= SPI0_F1_MASK;
			reset_ctrl.csr_reset_mask	= SPI0_F1_MASK;
			reset_ctrl.reset_mask		= SPI0_F1_MASK;
			break;
	}
	rc = reset_am862xx_block(&reset_ctrl);
	/* Control spi_ss_in_n */
	spi_write32(SPI_CONFIG, 0x3);
	if (rc !=0){
		printf("reset_am862xx_block function return error  rc = :%x\n",rc);
		return rc;
	}
	return 0;
}
//=================================================================
//Function		: 	spi_setup_mode
//=================================================================
void spi_setup_mode(u32_s base, int mode)
{
	u32_s temp = 0;
	/*Disable designware spi host*/
	temp = spi_read32(base + SPI_CTRLR0);
	if ((temp & SPI_CTRLR0_TMOD_MASK) != mode)
	{
		/* disable ip */
		spi_write32(base + SPI_SSIENR, 0x0);
		/* Setup transfer mode */
		temp &= ~SPI_CTRLR0_TMOD_MASK;
		temp |= mode;
		spi_write32(base + SPI_CTRLR0,temp);
		spi_write32(base + SPI_SSIENR, 0x1);
	}
}
//=================================================================
//Function		: 	spi_set_rx_data_length
//=================================================================
int spi_set_rx_data_length (u32_s base, unsigned int length)
{
	u32_s temp = 0, len = length;

/*if (len>SPI_RXFIFO_DEPTH) len = SPI_RXFIFO_DEPTH;*/
	if (len>65536) len = 65536;

	temp = spi_read32(base + SPI_CTRLR1) + 1;
	if (temp != len)
	{
		if (len == 0)
		{
			spi_write32(base + SPI_SSIENR, 0);
			spi_write32(base + SPI_CTRLR1,len);
			spi_write32(base + SPI_SSIENR, 1);
		}
		else{
			spi_write32(base + SPI_SSIENR, 0);
			spi_write32(base + SPI_CTRLR1,len - 1);
			spi_write32(base + SPI_SSIENR, 1);
		}

	}
	return 0;
}
void xfer_read(u32_s csr_base, u8_s *cmd, u8_s cmd_len, u8_s *pData, u32_s rx_length,u32_s slave_num){

	int rc = 0;
	u32_s data_dummy,trx_level,cnt;
	u8_s time_out;
	u8_s *buffer;
	buffer = pData;
	volatile u8_s sr;
	int i;
	while(spi_read32(csr_base + SPI_RXFLR)){
		data_dummy = spi_read32(csr_base + SPI_DR);
	}
	spi_disable_slave(csr_base, slave_num);
	spi_setup_mode(csr_base, SPI_EEPROM_READ);
	spi_set_rx_data_length (csr_base, rx_length);


	while (cmd_len)
	{
		trx_level = min((256-spi_read32(csr_base + SPI_TXFLR)), cmd_len);
		if(trx_level)
		{
			for (cnt = 0;cnt<trx_level;cnt++){
				spi_write32(csr_base + SPI_DR,cmd[cnt]);
			}
			cmd_len -= trx_level;
			time_out = 1000;
		}
		else {
			time_out--;
			if(time_out == 0){
				printf("missing write data cmd_len:%d\n",cmd_len);
				break;
			}
		}
	}
	time_out = 1000;
	cnt = 0;
	spi_enable_slave(csr_base, slave_num);
	while(spi_read32(csr_base + SPI_RXFLR) ==0);

	u32_s dr = csr_base + SPI_DR;
	int rxlr = csr_base + SPI_RXFLR;
	while (cnt < rx_length){
		sr = spi_read32(rxlr);
		for (i = 0; i < sr; i++)
			*pData++ = (u32_s) (spi_read32(dr));
		cnt+= sr;
	}

	time_out=100;
	do{
	data_dummy  = spi_read32(csr_base + SPI_RXFLR);
	time_out--;
	if(time_out == 0)
		printf("overflow FIFO\n");
		break;
	}while(data_dummy);

}

void xfer_write(u32_s base, u8_s *cmd, u8_s cmd_len, u8_s *pData, u32_s tx_length, u32_s slave_num){

	u16_s cnt = 0,i,sr;
	u8_s addr_hi, addr_lo;
	u32_s status_reg,trx_level ;
	u32_s time_out,data_dummy,tmp, tx, rx;
	u8_s code[3];

	while(spi_read32(base + SPI_RXFLR)){
		data_dummy = spi_read32(base + SPI_DR);
	}
	spi_disable_slave(base, slave_num);
	spi_setup_mode(base, SPI_TX_ONLY);
	spi_set_rx_data_length (base, 0);

	while (cmd_len)
	{
		trx_level = min((256-spi_read32(base + SPI_TXFLR)), cmd_len);
		if(trx_level)
		{
			for (i = 0;i<trx_level;i++){
				spi_write32(base + SPI_DR,cmd[i]);
			}
			cmd_len -= trx_level;
			time_out = 1000;
		}
		else {
			time_out--;
			if(time_out == 0){
				printf("missing write data tx_length:%d\n",tx_length);
				break;
			}
		}
	}

	cnt = 0;
	int tx_length_tmp = tx_length;
	while(tx_length_tmp){
		sr = spi_read32(base + SPI_SR);
		if (sr & SPI_SR_TFNF_MASK){
			spi_write32(base + SPI_DR, pData[cnt]);
			cnt++;
			tx_length_tmp -- ;
		}
		else{
			break;
		}
	}
	spi_enable_slave(base, slave_num);
	while (cnt < tx_length){
		sr = spi_read32(base + SPI_TXFLR);
		for (i = 0; i < 256 - sr; i++){
			spi_write32(base + SPI_DR, pData[cnt]);
			cnt++;
		}
	}
	mdelay(100);

	do{
	status_reg  = spi_read32(base + SPI_TXFLR);
	}while(status_reg);

}
int spi_check_256bytes_fifo(base, slave_num){

	u16_s cnt = 0,i,sr;
	u8_s pattern = 0xcafe;
	u8_s addr_hi, addr_lo;
	u32_s status_reg,trx_level ;
	u32_s time_out,data_dummy,tmp, tx, rx;

	while(spi_read32(base + SPI_RXFLR)){
		data_dummy = spi_read32(base + SPI_DR);
	}
	spi_disable_slave(base, slave_num);
	spi_setup_mode(base, SPI_TX_ONLY);
	spi_set_rx_data_length (base, 0);

	cnt = 0;
	int tx_length = 512;
	while(tx_length){
		sr = spi_read32(base + SPI_SR);
		if (sr & SPI_SR_TFNF_MASK){
			spi_write32(base + SPI_DR, pattern);
			cnt++;
			tx_length -- ;
		}
		else{
			break;
		}
	}

	time_out=1000;
	do{
		time_out --;
		status_reg  = spi_read32(base + SPI_TXFLR);
		printf("number data in FIFO now : %d\n",status_reg);
		if (time_out == 0){
			printf("Time out expired --> Fail\n");
			return -1;
		}
	}while(status_reg!=256);

	printf("OK\n");
	return 0;
}
int spi0_check_fifodepth(void){
	int base;
	int i;
	base = SPI0_BASE;
	u32_s slave_num;
	slave_num = 0;
	int error;
	error = spi_init_h(base);

	/* Initialize controller */
	spi_init_core(base,SPEED_1MHZ,slave_num);

	v_spi_claim_bus(base,slave_num);

	error = spi_check_256bytes_fifo(base, slave_num) ;
	if (error != 0)
		return error;


	return error;
}

int spi1_check_fifodepth(void){
	int base;
	int i;
	base = SPI1_BASE;
	u32_s slave_num;
	slave_num = 0;
	int error;
	error = spi_init_h(base);

	/* Initialize controller */
	spi_init_core(base,SPEED_1MHZ,slave_num);

	v_spi_claim_bus(base,slave_num);

	error = spi_check_256bytes_fifo(base, slave_num) ;
	if (error != 0)
		return error;

	return error;
}
