int spi_write_eeprom(u32_s base,u32_s slave_num)
{
	int ret;
	u8_s cmd[4];
	u8_s cmd_len;
	u8_s pattern=EEPROM_PATERN;
	u32_s pnum=0;
	u32_s bytes=8;

	u8_s *pbuf;
	int i=0;
	u8_s tbuf[bytes];

	printf("Writing pattern %02x to page number %d\n", pattern, pnum);

    for(i=0; i<bytes; i++){
             tbuf[i] = pattern;
             pattern++;
//             printf("tbuf_in[%d]:%x\n",i,tbuf[i]);
     }
     /* Write Enable for EPROM */

    cmd[0] = EPROM_CMD_WRITE_ENABLE;
    cmd_len = 1;
	xfer_write(base, cmd, cmd_len, NULL, 0, slave_num);

    printf("Write Enabled.....\n");
	cmd[0] = EPROM_CMD_PAGE_WRITE;
	cmd[1] = 0x0;
	cmd[2] = 0x0;
	cmd_len = 3;

	xfer_write(base, cmd, cmd_len, tbuf, 8, slave_num);

	mdelay(100);

    printf("Writing EPROM Done..!\n");

    return 0;
}

int spi_read_eeprom(u32_s base, u32_s slave_num)
{
	int ret;
	u8_s cmd[4];
	u8_s cmd_len;
	u32_s psz = 8;
	u8_s *pbuf;
	int i=0;
	u8_s tbuf[8];
	u8_s tbuf_in[8];
	u32_s pnum=0;
	u32_s bytes=8;
	u8_s pattern =EEPROM_PATERN;
    for(i=0; i<bytes; i++){
    		tbuf[i] = 0;
            tbuf_in[i] = pattern;
            pattern++;
            //printf("tbuf_in[%d]:%x\n",i,tbuf_in[i]);
    }
	if (bytes > 2048)
		bytes = 2048;

	cmd[0] = EPROM_CMD_PAGE_READ;
	cmd[1] = 0x00;
	cmd[2] = 0x00;
	cmd_len = 3;
	xfer_read(base, cmd, cmd_len, tbuf, bytes, slave_num);

    for(i=0; i<bytes; i++){
        printf("data_in[%d]:%x     data_out[%d] = 0x%x\n",i,tbuf_in[i], i, tbuf[i]);
		if(tbuf[i] != tbuf_in[i])
			return -1;
	}

    printf("\n\nReading page %d done ...!\n", pnum);

	return 0;
}

int spi_rw_test_eeprom(u32_s base, u32_s slave_num){
	int rc;
	printf("vdiag_spi test function\n");

	rc = spi_write_eeprom(base, slave_num);
	if(rc != 0)
		return rc;

	rc = spi_read_eeprom(base, slave_num);
	if(rc != 0)
		return rc;

	return 0;

}








