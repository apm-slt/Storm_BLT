/*
 * SPI WRITE ENABLE FLASH
 */
void spi_writeEn_m25q256xxx(u32 base, u32 slave_num){
	int ret;
	u8 cmd[1];
	u8 cmd_len;

    cmd[0] = CMD_N25Q256_WREN;
    cmd_len = 1;
	xfer_write(base, cmd, cmd_len, NULL, 0, slave_num);
	spi_wait_ready(WR_ENABLE_ACTION, base, slave_num);

}
/*
 * Unlock all sector M25Q256xxx
 */
int spi_unlock_m25q256xxx(u32 base,u32 slave_num)
{
	int ret;
	u8 cmd[1];
	u8 cmd_len;
	u8 status;

	cmd[0] = CMD_N25Q256_WRSR;
	cmd[1] = 0;
	cmd_len = 1;
	xfer_write(base, cmd, cmd_len, NULL, 0, slave_num);

	printf("sector unlocked\n");
	 return 0;
}
void spi_reset_m25q256xxx(u32 base, u32 slave_num){
	int ret,i,j;
	u8 cmd[1];
	u8 cmd_len;

    cmd[0] = 0x66;
    cmd_len = 1;
	xfer_write(base, cmd, cmd_len, NULL, 0, slave_num);

for (i=1;i<50000;i++);

    cmd[0] = 0x99;
    cmd_len = 1;
	xfer_write(base, cmd, cmd_len, NULL, 0, slave_num);
	for (i=1;i<50000;i++);

}

/*
 * SPI READ ID M25Q256xxx
 */
void spi_readID_m25q256xxx(u32 base,u32 slave_num)
{
	int ret;
	u8 cmd[1];
	u8 cmd_len;
	int i=0;
	u8 tbuf[4];
	u32 bytes=4;


	cmd[0] = CMD_N25Q256_RDID;
	cmd_len = 1;
	xfer_read(base, cmd, cmd_len, tbuf, bytes, slave_num);

	printf("\nID flash: ");
    for(i=0; i<bytes; i++){
        printf("0x%x  ",tbuf[i]);
	}
    printf("\n");
}

int spi_wait_ready(u32 action, u32 base, u32 slave_num){
	unsigned long timebase =  0x200000;
	int ret;
	u8 cmd[1];
	u8 cmd_len;
	u8 status, polling_logic, status_mask;

	if (action == 0) {/* Write enable */
		polling_logic = 0x0;
		cmd[0] = CMD_N25Q256_RDSR;
		status_mask = 1;
		cmd_len = 1;
	} else if (action == 1){ /* Erase process */
		polling_logic = NUMONYX_RFSR_PE;
		cmd[0] = CMD_N25Q256_RFSR;
		status_mask = NUMONYX_RFSR_PE;
		cmd_len = 1;
	}
	 else if (action == 2){ /* write process */
			polling_logic = 0;
			cmd[0] = CMD_N25Q256_RDSR;
			status_mask = NUMONYX_SR_WIP;
			cmd_len = 1;
	} else {
		polling_logic = 0;
		cmd[0] = CMD_N25Q256_RDSR;
		status_mask = NUMONYX_SR_WIP;
		cmd_len = 1;
	}
	 while (timebase) {
		timebase--;
		xfer_read(base, cmd, cmd_len, &status, 1, slave_num);
		if (timebase == 0) {
			printf("SF: Failed to get device status, status :%x \n",status);
			return -1;
		}
		if ((status & status_mask) == polling_logic)
			break;
	}
//	printf("\nstatus :%x\n",status);

	if ((status & status_mask) == polling_logic){
		return 0;
	}
	/* Timed out */
	return -1;
}

/*
 * 	Each page of memory can be individually programmed. Bits are programmed from one
 *	through zero. The device is subsector, sector, or bulk-erasable, but not page-erasable.
 *	Bits are erased from zero through one. The memory is configured as 33,554,432 bytes (8
 *	bits each); 512 sectors (64KB each); 8192 subsectors (4KB each); and 131,072 pages (256
 *	bytes each); and 64 OTP bytes are located outside the main memory array.
 */
int spi_sector_erase_m25q256xxx(u32 base, u32 slave_num){
	int ret;
	u8 cmd[11];
	u8 cmd_len;

	spi_reset_m25q256xxx(base, slave_num);

	spi_writeEn_m25q256xxx(base, slave_num);

	ret = spi_unlock_m25q256xxx(base, slave_num);
    printf("Erasing.....\n");
	cmd[0] = CMD_N25Q256_SE;
	cmd[1] = 0x0;
	cmd[2] = 0x0;
	cmd[3] = 0x0;
	cmd_len = 4;
	xfer_write(base, cmd, cmd_len, NULL, 0, slave_num);

	ret = spi_wait_ready(RD_STATUS_FLAG_ACTION, base, slave_num);
	if (ret != 0)
		return -1;
	printf("Erase Done ...\n");
    return 0;
}
int spi_write_m25q256xxx(base, slave_num){
	int ret;
	u8 cmd[4];
	u8 cmd_len;

	u8 pattern=PATTERN;
	u8 tmp = pattern;
	u32 bytes_no=BYTES_NO;
	int i=0;
	u8 tbuf[bytes_no];

    for(i=0; i<bytes_no; i++){
    	tbuf[i] = tmp;
    	tmp++;
/*    	printf("tbuf_in[%d]:%d\n",i,tbuf[i]);*/
    }

/*	spi_reset_m25q256xxx(base, slave_num);*/

	spi_writeEn_m25q256xxx(base, slave_num);

	cmd[0] = CMD_N25Q256_PP;
	cmd[1] = 0x0;
	cmd[2] = 0x0;
	cmd[3] = 0x0;
	cmd_len = 4;
	xfer_write(base, cmd, cmd_len, tbuf, bytes_no, slave_num);

	ret = spi_wait_ready(WR_FLAG_ACTION, base, slave_num);
	if (ret != 0)
		return -1;
	printf("Write Done ...\n");
    return 0;

}
int spi_read_m25q256xxx(base, slave_num){
	int ret;
	u8 cmd[4];
	u8 cmd_len;
	int i=0;
	u32 bytes_no=BYTES_NO;
	u8 tbuf[bytes_no];
	u8 tbuf_in[bytes_no];
	u8 pattern =PATTERN;
	u8 tmp = pattern;

    for(i=0; i<bytes_no; i++){
    		tbuf[i] = 0;
            tbuf_in[i] = tmp;
            tmp++;
            //printf("tbuf_in[%d]:%x\n",i,tbuf_in[i]);
    }
	if (bytes_no > 2048)
		bytes_no = 2048;

	cmd[0] = CMD_N25Q256_READ;
	cmd[1] = 0;
	cmd[2] = 0;
	cmd[3] = 0;
	cmd_len = 4;
	xfer_read(base, cmd, cmd_len, tbuf, bytes_no, slave_num);

    printf("\n\nReading page done ...!\n");

	printf("Compare ....\n");
    for(i=0; i<bytes_no; i++){
  //      printf(" data_in[%d]:%d          data_out[%d] = %d\n", i,tbuf_in[i],i,tbuf[i]);
		if(tbuf[i] != tbuf_in[i]){
			printf("Fail: data_in[%d]:%d          data_out[%d] = %d\n", i,tbuf_in[i],i,tbuf[i]);
			return -1;
		}
	}

	return 0;
}

int spi_rw_test_m25q256xxx(u32 base, u32 slave_num){
	int rc;
	printf("test function\n");

	spi_readID_m25q256xxx(base, slave_num);

	rc = spi_sector_erase_m25q256xxx(base, slave_num);
	if (rc !=0)
		return rc;

	rc = spi_write_m25q256xxx(base, slave_num);
	if (rc !=0)
		return rc;

	rc = spi_read_m25q256xxx(base, slave_num);
	if (rc !=0)
		return rc;

	return 0;

}
