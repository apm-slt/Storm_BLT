/*
 * Copyright (C) 2013 AppliedMicro Confidential Information
 * All Rights Reserved.
 *
 * THIS WORK CONTAINS PROPRIETARY INFORMATION WHICH IS THE PROPERTY OF
 * AppliedMicro AND IS SUBJECT TO THE TERMS OF NON-DISCLOSURE AGREEMENT
 * BETWEEN AppliedMicro AND THE COMPANY USING THIS FILE.
 *
 * WARNING !!!
 * This is an auto-generated C header file for register definitions
 * PLEASE DON'T MANUALLY MODIFY IN THIS FILE AS CHANGES WILL BE LOST
 *
 *  sata_driver.h
 *
 *  Created on : May 20, 2013
 *  Last Update: Jul 23, 2013
 *  Author     : kqngo@apm.com
 */

#ifndef SATA_DRIVER_H__
#define SATA_DRIVER_H__

#include "sata.h"
#include "sata_phy.h"
#include "pcie2_phy.h"

#define ALL_IRQS		0xFDC000FF

void sm_host_read32(u64 addr, unsigned int* data);
void sm_host_write32(u64 addr, unsigned int data);
u32 sm_sata_write32(u32 addr, u32 data);
void sm_sata_pmp_write32(u32 port, u32 pmp, u32 reg_num, u32 val);
int sm_sata_pmp_read32(u32 port, u32 pmp, u32 reg_num);
u32 sm_sata_read32(u32 addr);
void sm_sata_write64(u64 addr, u32 data);
u32 sm_sata_read64(u64 addr);

// delay func
void sm_sata_usdelay(unsigned us);
void sm_sata_msdelay(unsigned ms);
void sm_sata_delay(unsigned s);

// KC commands
void kc_sds_wr(u32 csr_base, u32 offset, u32 data);
u32 kc_sds_rd(u32 csr_base, u32 offset);

int sm_sata_sds_rst(int port);
int sm_sata_sds_ena(int port);

void sm_sata_mdio_debug_en(void);

void sm_sata_sds_irst_cfg(int port);
void sm_sata_core_sds_orst_cfg(int port, int gen);

int sm_sata_pll_chk(int port);
void sm_sata_rxa_rst(int port);

void sm_sata_mdio_debug_en(void);
void sm_sata_rxa_rst(int port);
void sm_sata_rxd_rst(int port);

void sm_sata_debug_dump_sds_regs(int port);

int COMPARE_val(u32 addr, u32 def_val);
int SETBITS_high(u32 addr, u32 bits);
int SETBITS_low(u32 addr, u32 bits);

// status func
void sm_sata_pxis(int port);
void sm_sata_pxssts(int port);
void sm_sata_pxserr(int port);
void sm_sata_port_status(int port);

// irq
void sm_sata_global_irq(int port, int enable_bit);
void sm_sata_port_irq(int port, int enable_bits);
void sm_sata_irq(u32 sata_ahci_base);
void sm_sata_irq1(void);
void sm_sata_irq2(void);
void sm_sata_irq3(void);
void sm_sata_reg_irq(int port);

// bring-up
int sm_sata_enet_muxing(int port);
int sm_sata_clk_rst_ena(int port);
int sm_sata_core_ena(int port);
int sm_sata_mem_ena(int port);
void sm_sata_ceva_cfg(int port);
void sm_sata_spd_cfg(int port);
void sm_sata_customer_pin_mode_cfg(int port);
void sm_sata_sds_csr_cfg(int port);
int sm_sata_get_csr_base(int port);
int sm_sata_get_ahci_base(int port);
int sm_sata_init(int port);
void sm_sata_ahci_host_init(int port);
int sm_sata_ahci_device_init(int port);
int sm_sata_ahci_port_init(int port);
int sm_sata_linkup(int port);

int sm_sata_dty_chk(int port);
int sm_sata_dty_fix(int port);
void sm_sata_dty_clr(int port);
int sm_sata_ahci_hba_reset(int port);
int sm_sata_PxSERR_clr(int port);

// DDR Memory
void memory_reset(u64 base, u32 number_sectors);
void memory_create_data(u64 base, u32 number_sectors);
int memory_compare(int report, u64 fr, u64 to, u32 number_sectors);
void memory_display(u64 base, int length);

// features
int  sm_sata_readid(int port, int pmp);
void sm_sata_pio_read(int port, int pmp, int start_sector, int sector_count);
void sm_sata_pio_write(int port, int start_sector, int sector_count);
int  sm_sata_pio_test(int port, int pmp);
void sm_sata_dma_read(int port);
void sm_sata_dma_write(int port);
int  sm_sata_dma_test(int port, int pmp);
void sm_sata_fpdma_read(int port, int start_sector, int sector_count);
void sm_sata_fpdma_write(int port, int start_sector, int sector_count);
int  sm_sata_fpdma_test(int port, int pmp);
void sm_sata_xdata_stress(int port, int pmp, int direction, int wr_cmd, int rd_cmd, int start_sector, int sector_count, int loop);
void sm_sata_pio_stress(int port);
void sm_sata_dma_stress(int port);
void sm_sata_fpdma_stress(int port);
void view_pwr_mode(int port);
int  sm_sata_pwr_test(int port, int pmp);
void sm_sata_ccc_test(int port, int pmp);
void sm_sata_ncq_test(int port, int pmp);
void sm_sata_bw_monitor(int port, int sector_count, int mode);
#endif /* SATA_DRIVER_H__ */
