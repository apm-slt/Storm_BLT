/* Author: your_name@apm.com 
*  Company: Applied Micro Circuits Corporation (AMCC)
* 
* Describe the purpose of your Test here
*/

#ifndef _SATA_H_
#define _SATA_H_

#include <types.h>			//vbios
#include <armv8.h>
#include <delay.h>
#include <stdio.h>
#include <string.h>
#include <common.h>
#include <delay.h>
#include <ddr_driver.h>
#define PLATFORM_VBIOS

/*************************************************************/
#if 0	// OCM
#define CMD_LST_BASE			0x1D080000
#define CMD_TABLE_BASE			0x1D082000
#define CMD_FIS_BASE			0x1D090000

#define SATA_DATA_BASE			0x1D092000
#define SATA_DATA_READ_BASE		0x1D092000
#define SATA_DATA_WRITE_BASE	0x1D0C2000

#else	// DDR
#define DDR_CACHEABLE			1

#if 0	// old vBios
extern struct vbios_mem_space *gp_ddr_mem_space;  // this is for latest vBios(DDR_CACHE enabled)
#define DDR_BASE				gp_ddr_mem_space->region[0].str_addr + 0x10000000	// this is for latest vBios(DDR_CACHE enabled)
#else	// vBios2_B0
#define DDR_BASE				get_ddr_cpu_test_base()
#endif

#define CMD_LST_BASE			DDR_BASE + 0x00000000
#define CMD_TABLE_BASE			DDR_BASE + 0x10000000
#define CMD_FIS_BASE			DDR_BASE + 0x20000000

#define SATA_DATA_BASE			DDR_BASE + 0x30000000
#define SATA_DATA_READ_BASE		DDR_BASE + 0x30000000
#define SATA_DATA_WRITE_BASE	DDR_BASE + 0x40000000
#endif	// end OCM DDR

#define PIO 	0x0
#define DMA 	0x1
#define FPDMA 	0x2

#define FIS_H2D					0x27
#define FIS_D2H					0x34

#define DIRECT_WRITE			0x1
#define DIRECT_READ				0x0
#define FEATURE_DEFAUTL			0x0

#define SATA_IDENTIFY_DEV       0xEC
#define SATA_SET_FEATURE		0xEF
#define SATA_HOST_INIT_BIST     0x58

#define ATA_CMD_PIO_RD			0x20	/* Read Sectors (with retries)	*/
#define ATA_CMD_READN			0x21	/* Read Sectors ( no  retries)	*/
#define ATA_CMD_PIO_RD_EXT		0x24
#define ATA_CMD_DMA_RD_EXT		0x25
#define ATA_CMD_RD_NATI_MAX_EXT 0x27
#define ATA_CMD_PIO_WR			0x30	/* Write Sectors (with retries)*/
#define ATA_CMD_WRITEN			0x31	/* Write Sectors  ( no  retries)*/
#define ATA_CMD_PIO_WR_EXT		0x34
#define ATA_CMD_DMA_WR_EXT		0x35
#define ATA_CMD_VRFY			0x40	/* Read Verify  (with retries)	*/
#define ATA_CMD_VRFYN			0x41	/* Read verify  ( no  retries)	*/
#define SATA_IoCoH_TEST			0x44
#define PCS_REG_RD_DEFAULT		0x45
#define ATA_CMD_FPDMA_RD		0x60
#define	ATA_CMD_FPDMA_WR		0x61
#define ATA_CMD_SEEK			0x70	/* Seek				*/
#define ATA_CMD_DIAG			0x90	/* Execute Device Diagnostic	*/
#define ATA_CMD_INIT			0x91	/* Initialize Device Parameters	*/
#define ATA_CMD_IDENT_PKG		0xA1	/* Identify Package Device */
#define ATA_CMD_RD_MULT			0xC4	/* Read Multiple		*/
#define ATA_CMD_WR_MULT			0xC5	/* Write Multiple		*/
#define ATA_CMD_SETMULT			0xC6	/* Set Multiple Mode		*/
#define ATA_CMD_DMA_RD			0xC8	/* Read DMA (with retries)	*/
#define ATA_CMD_DMAN_READ		0xC9	/* Read DMS ( no  retries)	*/
#define ATA_CMD_DMA_WR			0xCA	/* Write DMA (with retries)	*/
#define ATA_CMD_DMAN_WRITE		0xCB	/* Write DMA ( no  retires)	*/
#define ATA_CMD_BUFFER_RD       0xE4    /* Read Buffer */
#define ATA_CMD_BUFFER_WR       0xE8    /* Write Buffer */
#define ATA_CMD_IDENT			0xEC	/* Identify Device		*/
#define ATA_CMD_SETF			0xEF	/* Set Features			*/
#define ATA_CMD_PWR_CHK			0xE5	/* Check Power Mode		*/


#define SM_SATA_AHCI_BASE__ADDR              0x0001A000000	//TBD
#define SM_SATA_01_AHCI_BASE__ADDR           SM_SATA_AHCI_BASE__ADDR | 0x00000000
#define SM_SATA_23_AHCI_BASE__ADDR           SM_SATA_AHCI_BASE__ADDR | 0x00400000
#define SM_SATA_45_AHCI_BASE__ADDR           SM_SATA_AHCI_BASE__ADDR | 0x00800000

#define SM_SATA_CSR_BASE__ADDR               0x0001f200000	//TBD
#define SM_SATA_01_CSR_BASE__ADDR            SM_SATA_CSR_BASE__ADDR | 0x00010000
#define SM_SATA_23_CSR_BASE__ADDR            SM_SATA_CSR_BASE__ADDR | 0x00020000
#define SM_SATA_45_CSR_BASE__ADDR            SM_SATA_CSR_BASE__ADDR | 0x00030000

/* HBA MEMORY REGs - GENERIC HOST CONTROL */
#define CAP__ADDR                                 0x00000000
#define GHC__ADDR                                 0x00000004
#define IS__ADDR                                  0x00000008
#define PI__ADDR                                  0x0000000C
#define VS__ADDR                                  0x00000010
#define CCC_CTL__ADDR                             0x00000014
#define CCC_PORTS__ADDR                           0x00000018
#define EM_LOC__ADDR                              0x0000001C
#define EM_CTL__ADDR                              0x00000020
#define CAP2__ADDR                                0x00000024
#define BOHC__ADDR                                0x00000028

#define BIST_ERR__ADDR                            0x00000070
#define P0SERCTL__ADDR                            0x000000A0
#define PORTCFG__ADDR                             0x000000A4
#define PORTPHY1CFG__ADDR                         0x000000A8
#define PORTPHY2CFG__ADDR                         0x000000Ac
#define PORTPHY3CFG__ADDR                         0x000000B0
#define PORTPHY4CFG__ADDR                         0x000000B4
#define PORTPHY5CFG__ADDR                         0x000000B8
#define PORTAXICFG__ADDR                          0x000000Bc
#define PORTAXICACHECTL__ADDR                     0x000000C0
#define PORTAXIPROTCTL__ADDR                      0x000000C4
#define PORTRANSCFG__ADDR                         0x000000C8
#define PORTRANSSTAT__ADDR                        0x000000CC
#define PORTLNKCFG0__ADDR                         0x000000D0
#define PORTLNKCFG1__ADDR                         0x000000D4
#define PORTLNKCFG2__ADDR                         0x000000D8
#define PORTLNKSTAT0__ADDR                        0x000000Dc
#define PORTLNKSTAT1__ADDR                        0x000000E0
#define PORTCMDCFG__ADDR                          0x000000E4
#define CLB0__ADDR                                0x00000100
#define CLBU0__ADDR                               0x00000104
#define FB0__ADDR                                 0x00000108
#define FBU0__ADDR                                0x0000010C
#define IS0__ADDR                                 0x00000110
#define IE0__ADDR                                 0x00000114
#define CMD0__ADDR                                0x00000118
#define TFD0__ADDR                                0x00000120
#define SIG0__ADDR                                0x00000124
#define SSTS0__ADDR                               0x00000128
#define SCTL0__ADDR                               0x0000012C
#define SERR0__ADDR                               0x00000130
#define SACT0__ADDR                               0x00000134
#define CI0__ADDR                                 0x00000138
#define SNTF0__ADDR                               0x0000013C
#define FBS0__ADDR                                0x00000140
#define CLB1__ADDR                                0x00000180
#define CLBU1__ADDR                               0x00000184
#define FB1__ADDR                                 0x00000188
#define FBU1__ADDR                                0x0000018C
#define IS1__ADDR                                 0x00000190
#define IE1__ADDR                                 0x00000194
#define CMD1__ADDR                                0x00000198
#define TFD1__ADDR                                0x000001A0
#define SIG1__ADDR                                0x000001A4
#define SSTS1__ADDR                               0x000001A8
#define SCTL1__ADDR                               0x000001AC
#define SERR1__ADDR                               0x000001B0
#define SACT1__ADDR                               0x000001B4
#define CI1__ADDR                                 0x000001B8
#define SNTF1__ADDR                               0x000001BC
#define FBS1__ADDR                                0x000001C0

#define SLVRDERRATTRIBUTES__ADDR                  0x00000000
#define SLVWRERRATTRIBUTES__ADDR                  0x00000004
#define MSTRDERRATTRIBUTES__ADDR                  0x00000008
#define MSTWRERRATTRIBUTES__ADDR                  0x0000000C
#define SwInt__ADDR                               0x00000010
#define BUSCTLREG__ADDR                           0x00000014
#define IOFMSTRWAUX__ADDR                         0x00000018
#define LinkMonitorPort__ADDR                     0x0000001C
#define RxRamCtrl__ADDR                           0x00000020
#define TxRamCtrl__ADDR                           0x00000024
#define INTStatus__ADDR                           0x00000028
#define INTSTATUSMASK__ADDR                       0x0000002C
#define ERRINTSTATUS__ADDR                        0x00000030
#define ERRINTSTATUSMASK__ADDR                    0x00000034
#define SATA_ID__ADDR                             0x00000038
#define SATA_RAM_TEST__ADDR                       0x0000003C

/* KOOLCHIP SERDES CSR */
#define SATA_ENET_SDS_PCS_CTL0__ADDR              0x0000A000
#define SATA_ENET_SDS_PCS_CTL0__MASK               0x3FFFE000
#define SATA_ENET_SDS_PCS_CTL0__VALUE               0x036B6000
#define SATA_ENET_SDS_PCS_CTL1__ADDR              0x0000A004
#define SATA_ENET_SDS_PCS_CTL1__MASK               0x1FFFFFFF
#define SATA_ENET_SDS_PCS_CTL1__VALUE               0x00000000
#define SATA_ENET_SDS_PCS_CTL2__ADDR              0x0000A008
#define SATA_ENET_SDS_CTL0__ADDR                  0x0000A00C
#define SATA_ENET_SDS_CTL0__MASK                  0x00003FFF
#define SATA_ENET_SDS_CTL0__VALUE                 0x00004021
#define SATA_ENET_SDS_PCS_CTL2__MASK              0x00003FFF
#define SATA_ENET_SDS_PCS_CTL2__VALUE             0x00003C00
#define SATA_ENET_SDS_CTL1__ADDR                  0x0000A010
#define SATA_ENET_SDS_CMU_STATUS0__ADDR           0x0000A014
#define SATA_ENET_SDS0_RXTX_STATUS__ADDR          0x0000A018
#define SATA_ENET_SDS1_RXTX_STATUS__ADDR          0x0000A020
#define SATA_ENET_SDS_RST_CTL__ADDR               0x0000A024
#define SATA_ENET_SDS_CMU_CTL0__ADDR              0x0000A028
#define SATA_ENET_SDS_CMU_CTL1__ADDR              0x0000A02C
#define SATA_ENET_SDS_RX_CTL__ADDR                0x0000A030
#define SATA_ENET_SDS_TX_CTL__ADDR                0x0000A034
#define SATA_ENET_SDS_DEBUG_REG__ADDR             0x0000A038
#define SATA_ENET_SDS_IND_CMD_REG__ADDR           0x0000A03C
#define SATA_ENET_SDS_IND_CMD_REG__MASK            0x003FFFFF
#define SATA_ENET_SDS_IND_RDATA_REG__ADDR         0x0000A040
#define SATA_ENET_SDS_IND_RDATA_REG__MASK          0x0				// RO
#define SATA_ENET_SDS_IND_WDATA_REG__ADDR         0x0000A044
#define SATA_ENET_SDS_IND_WDATA_REG__MASK          0x003FFFFF
#define SATA_ENET_CLK_MACRO_REG__ADDR             0x0000A04C
#define SATA_ENET_CLK_MACRO_REG__MASK              0x007FFFFF

#define SATA_ENET_CONFIG_REG__ADDR                0x00007000
#define SATACLKENREG__ADDR                        0x0000C000
#define SATASRESETREG__ADDR                       0x0000C004
#define CFG_DIAG_SEL__ADDR                        0x0000D000
#define CFG_READ_BW_LAT_ADDR_MASK__ADDR           0x0000D004
#define CFG_READ_BW_LAT_ADDR_PAT__ADDR            0x0000D008
#define CFG_WRITE_BW_LAT_ADDR_MASK__ADDR          0x0000D00C
#define CFG_WRITE_BW_LAT_ADDR_PAT__ADDR           0x0000D010
#define CFG_DIAG_START_STOP__ADDR                 0x0000D014
#define CFG_BW_MSTR_STOP_CNT__ADDR                0x0000D018
#define CFG_BW_SLV_STOP_CNT__ADDR                 0x0000D01C
#define STS_READ_LATENCY_OUTPUT__ADDR             0x0000D020
#define STS_AXI_MRD_BW_CLK_CNT__ADDR              0x0000D024
#define STS_AXI_MRD_BW_BYTE_CNT__ADDR             0x0000D028
#define STS_AXI_MWR_BW_CLK_CNT__ADDR              0x0000D02C
#define STS_AXI_MWR_BW_BYTE_CNT__ADDR             0x0000D030
#define STS_AXI_SRD_BW_CLK_CNT__ADDR              0x0000D034
#define STS_AXI_SRD_BW_BYTE_CNT__ADDR             0x0000D038
#define STS_AXI_SWR_BW_CLK_CNT__ADDR              0x0000D03C
#define STS_AXI_SWR_BW_BYTE_CNT__ADDR             0x0000D040
#define CFG_DBG_TRIG_CTRL__ADDR                   0x0000D044
#define CFG_DBG_PAT_REG_0__ADDR                   0x0000D048
#define CFG_DBG_PAT_MASK_REG_0__ADDR              0x0000D04C
#define CFG_DBG_PAT_REG_1__ADDR                   0x0000D050
#define CFG_DBG_PAT_MASK_REG_1__ADDR              0x0000D054
#define DBG_TRIG_OUT__ADDR                        0x0000D058
#define DBG_TRIG_INT__ADDR                        0x0000D05C
#define DBG_TRIG_INTMask__ADDR                    0x0000D060
#define INTR_STS__ADDR                            0x0000D064
#define CFG_MEM_ECC_BYPASS__ADDR                  0x0000D068
#define CFG_MEM_PWRDN_DIS__ADDR                   0x0000D06C
#define CFG_MEM_RAM_SHUTDOWN__ADDR                0x0000D070
#define BLOCK_MEM_RDY__ADDR                       0x0000D074
#define STS_READ_LATENCY_TOT_READ_REQS__ADDR      0x0000D08C
#define CFG_LT_MSTR_STOP_CNT__ADDR                0x0000D090
#define CFG_BW_SRD_TRIG_CAP__ADDR                 0x0000D0A0
#define CFG_BW_SWR_TRIG_CAP__ADDR                 0x0000D0A4
#define CFG_BW_MRD_TRIG_CAP__ADDR                 0x0000D0A8
#define CFG_BW_MWR_TRIG_CAP__ADDR                 0x0000D0AC
#define CFG_LT_MRD_TRIG_CAP__ADDR                 0x0000D0B0
#define DBG_BLOCK_AXI__ADDR                       0x0000D0B4
#define DBG_BLOCK_NON_AXI__ADDR                   0x0000D0B8
#define DBG_AXI_SHIM_OUT__ADDR                    0x0000D0BC
#define GLBL_ERR_STS__ADDR                        0x0000D800
#define GLBL_SEC_ERRL__ADDR                       0x0000D810
#define GLBL_SEC_ERRLMask__ADDR                   0x0000D814
#define GLBL_SEC_ERRH__ADDR                       0x0000D818
#define GLBL_SEC_ERRHMask__ADDR                   0x0000D81C
#define GLBL_MSEC_ERRL__ADDR                      0x0000D820
#define GLBL_MSEC_ERRLMask__ADDR                  0x0000D824
#define GLBL_MSEC_ERRH__ADDR                      0x0000D828
#define GLBL_MSEC_ERRHMask__ADDR                  0x0000D82C
#define GLBL_DED_ERRL__ADDR                       0x0000D830
#define GLBL_DED_ERRLMask__ADDR                   0x0000D834
#define GLBL_DED_ERRH__ADDR                       0x0000D838
#define GLBL_DED_ERRHMask__ADDR                   0x0000D83C
#define GLBL_MDED_ERRL__ADDR                      0x0000D840
#define GLBL_MDED_ERRLMask__ADDR                  0x0000D844
#define GLBL_MDED_ERRH__ADDR                      0x0000D848
#define GLBL_MDED_ERRHMask__ADDR                  0x0000D84C
#define GLBL_MERR_ADDR__ADDR                      0x0000D850
#define GLBL_MERR_REQINFO__ADDR                   0x0000D854
#define GLBL_TRANS_ERR__ADDR                      0x0000D860
#define GLBL_TRANS_ERRMask__ADDR                  0x0000D864
#define GLBL_WDERR_ADDR__ADDR                     0x0000D870
#define GLBL_WDERR_REQINFO__ADDR                  0x0000D874
#define GLBL_DEVERR_ADDR                          0x0000D878
#define GLBL_DEVERR_REQINFO__ADDR                 0x0000D87C
#define GLBL_SEC_ERRL_ALS__ADDR                   0x0000D880
#define GLBL_SEC_ERRH_ALS__ADDR                   0x0000D884
#define GLBL_DED_ERRL_ALS__ADDR                   0x0000D888
#define GLBL_DED_ERRH_ALS__ADDR                   0x0000D88C
#define GLBL_TRANS_ERR_ALS__ADDR                  0x0000D890
#define CFG_MST_IOB_SEL__ADDR                     0x0000F004
#define CFG_VC0_PREFETCH__ADDR                    0x0000F008
#define CFG_VC1_PREFETCH__ADDR                    0x0000F00C
#define CFG_VC2_PREFETCH__ADDR                    0x0000F010
#define VC0_TOKEN_USED__ADDR                      0x0000F014
#define VC1_TOKEN_USED__ADDR                      0x0000F018
#define VC2_TOKEN_USED__ADDR                      0x0000F01C
#define VC0_TOKEN_REQ__ADDR                       0x0000F020
#define VC1_TOKEN_REQ__ADDR                       0x0000F024
#define VC2_TOKEN_REQ__ADDR                       0x0000F028
#define CFG_SLV_RESP_TMO_CNTR__ADDR               0x0000E004
#define CFG_SLV_READY_TMO_CNTR__ADDR              0x0000E008
#define INT_SLV_TMO__ADDR                         0x0000E00C
#define INT_SLV_TMOMASK__ADDR                     0x0000E010
#define CFG_AMA_MODE__ADDR                        0x0000E014
#define CFG_SLV_CSR_TMO_CNTR__ADDR                0x0000E018
#define CFG_MASK_DEV_ERR_RESP__ADDR               0x0000E01C

/* PMP RRGISTERS */
#define PMP_GSCR0			0	// Product Identifier
#define PMP_GSCR1			1	// Revision Information
#define PMP_GSCR2			2	// Port Information
#define PMP_GSCR64			64	// Port Multiplier Revision 1.X Features Support
#define PMP_GSCR96			96	// Port Multiplier Revision 1.X Features Enable

#define PMP_PSCR0			0	// SStatus Reg
#define PMP_PSCR1			1	// SError Reg
#define PMP_PSCR2			2	// SControl Reg
#define PMP_PSCR3			3	// SActive Reg
#define PMP_PSCR4			4	// SNotification Reg

#if 0
#define FIELD_PMP_SPD_LSB		4
#define FIELD_PMP_SPD_MSB		7
#define FIELD_PMP_SPD_WIDTH		4
#define FIELD_PMP_SPD_MASK		0x000000F0
#define FIELD_PMP_SPD_SHIFT_MASK		0x4
#define FIELD_PMP_SPD_RD(src)	((FIELD_PMP_SPD_MASK & (unsigned int)(src)) >> FIELD_PMP_SPD_SHIFT_MASK)
#define FIELD_PMP_SPD_WR(dst)	(FIELD_PMP_SPD_MASK & ((unsigned int)(dst) << FIELD_PMP_SPD_SHIFT_MASK))
#define FIELD_PMP_SPD_SET(dst, src)	(((dst) & ~FIELD_PMP_SPD_MASK) | (((unsigned int)(src) << FIELD_PMP_SPD_SHIFT_MASK) & FIELD_PMP_SPD_MASK))

#define FIELD_PMP_DET_LSB		0
#define FIELD_PMP_DET_MSB		3
#define FIELD_PMP_DET_WIDTH		4
#define FIELD_PMP_DET_MASK		0x0000000f
#define FIELD_PMP_DET_SHIFT_MASK		0x0
#define FIELD_PMP_DET_RD(src)	((FIELD_PMP_DET_MASK & (unsigned int)(src)))
#define FIELD_PMP_DET_WR(dst)	(FIELD_PMP_DET_MASK & ((unsigned int)(dst) << FIELD_PMP_DET_SHIFT_MASK))
#define FIELD_PMP_DET_SET(dst, src)	(((dst) & ~FIELD_PMP_DET_MASK) | (((unsigned int)(src) << FIELD_PMP_DET_SHIFT_MASK) & FIELD_PMP_DET_MASK))
#endif

#endif
