/*
 * Copyright (C) 2013 AppliedMicro Confidential Information
 * All Rights Reserved.
 *
 * THIS WORK CONTAINS PROPRIETARY INFORMATION WHICH IS THE PROPERTY OF
 * AppliedMicro AND IS SUBJECT TO THE TERMS OF NON-DISCLOSURE AGREEMENT
 * BETWEEN AppliedMicro AND THE COMPANY USING THIS FILE.
 *
 * WARNING !!!
 * This is an auto-generated C header file for register definitions
 * PLEASE DON'T MANUALLY MODIFY IN THIS FILE AS CHANGES WILL BE LOST
 *
 *  sata_phy.h
 *
 *  Created on : Feb  2, 2013
 *  Last Update: Jul 23, 2013
 *  Author     : kqngo@apm.com
 */

#ifndef _SATA_PHY_H__
#define _SATA_PHY_H__

/* Koolchip SERDES Config */
#define CHANNEL_MAX					2
#define CHx_RXTX_REG_MAX			163
#define CH0_RXTX_REG_OFFSET			0x00000400
#define CH1_RXTX_REG_OFFSET			0x00000600
#define CMUx_REG_MAX				40
#define CMU0_REG_OFFSET				0x0
#define CMU1_REG_OFFSET				0x00020000

#define CMU_REG0		0
#define CMU_REG1		1
#define CMU_REG2		2
#define CMU_REG3		3
#define CMU_REG4		4
#define CMU_REG5		5
#define CMU_REG6		6
#define CMU_REG7		7
#define CMU_REG8		8
#define CMU_REG9		9
#define CMU_REG10		10
#define CMU_REG11		11
#define CMU_REG12		12
#define CMU_REG13		13
#define CMU_REG14		14
#define CMU_REG15		15
#define CMU_REG16		16
#define CMU_REG17		17
#define CMU_REG18		18
#define CMU_REG19		19
#define CMU_REG20		20
#define CMU_REG21		21
#define CMU_REG22		22
#define CMU_REG23		23
#define CMU_REG24		24
#define CMU_REG25		25
#define CMU_REG26		26
#define CMU_REG27		27
#define CMU_REG28		28
#define CMU_REG29		29
#define CMU_REG30		30
#define CMU_REG31		31
#define CMU_REG32		32
#define CMU_REG33		33
#define CMU_REG34		34
#define CMU_REG35		35
#define CMU_REG36		36
#define CMU_REG37		37
#define CMU_REG38		38
#define CMU_REG39		39

#define RXTX_REG0			0
#define RXTX_REG1			1
#define RXTX_REG2			2
#define RXTX_REG3			3
#define RXTX_REG4			4
#define RXTX_REG5			5
#define RXTX_REG6			6
#define RXTX_REG7			7
#define RXTX_REG8			8
#define RXTX_REG9			9
#define RXTX_REG10			10
#define RXTX_REG11			11
#define RXTX_REG12			12
#define RXTX_REG13			13
#define RXTX_REG14			14
#define RXTX_REG15			15
#define RXTX_REG16			16
#define RXTX_REG17			17
#define RXTX_REG18			18
#define RXTX_REG19			19
#define RXTX_REG20			20
#define RXTX_REG21			21
#define RXTX_REG22			22
#define RXTX_REG23			23
#define RXTX_REG24			24
#define RXTX_REG25			25
#define RXTX_REG26			26
#define RXTX_REG27			27
#define RXTX_REG28			28
#define RXTX_REG29			29
#define RXTX_REG30			30
#define RXTX_REG31			31
#define RXTX_REG32			32
#define RXTX_REG33			33
#define RXTX_REG34			34
#define RXTX_REG35			35
#define RXTX_REG36			36
#define RXTX_REG37			37
#define RXTX_REG38			38
#define RXTX_REG39			39
#define RXTX_REG40			40
#define RXTX_REG41			41
#define RXTX_REG42			42
#define RXTX_REG43			43
#define RXTX_REG44			44
#define RXTX_REG45			45
#define RXTX_REG46			46
#define RXTX_REG47			47
#define RXTX_REG48			48
#define RXTX_REG49			49
#define RXTX_REG50			50
#define RXTX_REG51			51
#define RXTX_REG52			52
#define RXTX_REG53			53
#define RXTX_REG54			54
#define RXTX_REG55			55
#define RXTX_REG56			56
#define RXTX_REG57			57
#define RXTX_REG58			58
#define RXTX_REG59			59
#define RXTX_REG60			60
#define RXTX_REG61			61
#define RXTX_REG62			62
#define RXTX_REG63			63
#define RXTX_REG64			64
#define RXTX_REG65			65
#define RXTX_REG66			66
#define RXTX_REG67			67
#define RXTX_REG68			68
#define RXTX_REG69			69
#define RXTX_REG70			70
#define RXTX_REG71			71
#define RXTX_REG72			72
#define RXTX_REG73			73
#define RXTX_REG74			74
#define RXTX_REG75			75
#define RXTX_REG76			76
#define RXTX_REG77			77
#define RXTX_REG78			78
#define RXTX_REG79			79
#define RXTX_REG80			80
#define RXTX_REG81			81
#define RXTX_REG82			82
#define RXTX_REG83			83
#define RXTX_REG84			84
#define RXTX_REG85			85
#define RXTX_REG86			86
#define RXTX_REG87			87
#define RXTX_REG88			88
#define RXTX_REG89			89
#define RXTX_REG90			90
#define RXTX_REG91			91
#define RXTX_REG92			92
#define RXTX_REG93			93
#define RXTX_REG94			94
#define RXTX_REG95			95
#define RXTX_REG96			96
#define RXTX_REG97			97
#define RXTX_REG98			98
#define RXTX_REG99			99
#define RXTX_REG100			100
#define RXTX_REG101			101
#define RXTX_REG102			102
#define RXTX_REG103			103
#define RXTX_REG104			104
#define RXTX_REG105			105
#define RXTX_REG106			106
#define RXTX_REG107			107
#define RXTX_REG108			108
#define RXTX_REG109			109
#define RXTX_REG110			110
#define RXTX_REG111			111
#define RXTX_REG112			112
#define RXTX_REG113			113
#define RXTX_REG114			114
#define RXTX_REG115			115
#define RXTX_REG116			116
#define RXTX_REG117			117
#define RXTX_REG118			118
#define RXTX_REG119			119
#define RXTX_REG120			120
#define RXTX_REG121			121
#define RXTX_REG122			122
#define RXTX_REG123			123
#define RXTX_REG124			124
#define RXTX_REG125			125
#define RXTX_REG126			126
#define RXTX_REG127			127
#define RXTX_REG128			128
#define RXTX_REG129			129
#define RXTX_REG130			130
#define RXTX_REG131			131
#define RXTX_REG132			132
#define RXTX_REG133			133
#define RXTX_REG134			134
#define RXTX_REG135			135
#define RXTX_REG136			136
#define RXTX_REG137			137
#define RXTX_REG138			138
#define RXTX_REG139			139
#define RXTX_REG140			140
#define RXTX_REG141			141
#define RXTX_REG142			142
#define RXTX_REG143			143
#define RXTX_REG144			144
#define RXTX_REG145			145
#define RXTX_REG146			146
#define RXTX_REG147			147
#define RXTX_REG148			148
#define RXTX_REG149			149
#define RXTX_REG150			150
#define RXTX_REG151			151
#define RXTX_REG152			152
#define RXTX_REG153			153
#define RXTX_REG154			154
#define RXTX_REG155			155
#define RXTX_REG156			156
#define RXTX_REG157			157
#define RXTX_REG158			158
#define RXTX_REG159			159
#define RXTX_REG160			160
#define RXTX_REG161			161
#define RXTX_REG162			162

/* CMU Config - Start */
#define CMU_REG12_STATE_DELAY9__MASK					~(0xF << 4)
#define CMU_REG12_STATE_DELAY9__VALUE					0x1 << 4

#define CMU_REG13_STATE_DELAY1__MASK					~(0xF << 12)
#define CMU_REG13_STATE_DELAY2__MASK					~(0xF << 8)
#define CMU_REG13_STATE_DELAY3__MASK					~(0xF << 4)
#define CMU_REG13_STATE_DELAY4__MASK					~(0xF)
#ifdef STORM_A3
#define CMU_REG13_STATE_DELAY1__VALUE					0x0 << 12
#else
#define CMU_REG13_STATE_DELAY1__VALUE					0xF << 12
#endif
#define CMU_REG13_STATE_DELAY2__VALUE					0x2 << 8
#define CMU_REG13_STATE_DELAY3__VALUE					0x2 << 4
#define CMU_REG13_STATE_DELAY4__VALUE					0x2

#define CMU_REG14_STATE_DELAY5__MASK					~(0xF << 12)
#define CMU_REG14_STATE_DELAY6__MASK					~(0xF << 8)
#define CMU_REG14_STATE_DELAY7__MASK					~(0xF << 4)
#define CMU_REG14_STATE_DELAY8__MASK					~(0xF)
#define CMU_REG14_STATE_DELAY5__VALUE					0x2 << 12
#define CMU_REG14_STATE_DELAY6__VALUE					0x2 << 8
#define CMU_REG14_STATE_DELAY7__VALUE					0x2 << 4
#define CMU_REG14_STATE_DELAY8__VALUE					0x5

/* Select Reference Clock */
#define CMU_REG0_PLL_REF_SEL__MASK						~(0x1 << 13)
#define CMU_REG0_PLL_REF_SEL__SET						0x1 << 13
#define CMU_REG1_REFCLK_CMOS_SEL__MASK					~(0x1)
#define CMU_REG1_REFCLK_CMOS_SEL__SET					0x1

#define CMU_REG0_CAL_COUNT_RESOL__MASK					~(0x7 << 5)
#ifdef STORM_A3
#define CMU_REG0_CAL_COUNT_RESOL__VALUE					0x7 << 5
#else
#define CMU_REG0_CAL_COUNT_RESOL__VALUE					0x4 << 5
#endif

#define CMU_REG1_PLL_CP__MASK							~(0xF << 10)
#define CMU_REG1_PLL_CP_SEL__MASK						~(0x1F << 5)
#define CMU_REG1_PLL_MANUALCAL__MASK					~(0x1 << 3)
#define CMU_REG1_PLL_CP__VALUE							0x1 << 10
#ifdef STORM_A3
#define CMU_REG1_PLL_CP_SEL__VALUE						0x3 << 5
#define CMU_REG1_PLL_MANUALCAL__VALUE					0x1 << 3
#else
#define CMU_REG1_PLL_CP_SEL__VALUE						0x5 << 5
#define CMU_REG1_PLL_MANUALCAL__VALUE					0x0 << 3
#endif

#define CMU_REG5_PLL_RESETB__MASK						~(0x1)
#define CMU_REG5_PLL_RESETB__SET						0x1

#define CMU_REG2_PLL_REFDIV__MASK						~(3 << 14)
#define CMU_REG2_PLL_FBDIV__MASK						~(0x1FF << 5)
#define CMU_REG2_PLL_LFRES__MASK						~(0xF << 1)
#define CMU_REG2_PLL_REFDIV__50MHz						0x1 << 14
#define CMU_REG2_PLL_FBDIV__50MHz						0x77 << 5
#define CMU_REG2_PLL_REFDIV__100MHz						0x0 << 14
#define CMU_REG2_PLL_FBDIV__100MHz						0x3B << 5
#ifdef STORM_A3
#define CMU_REG2_PLL_LFRES__VALUE						0x3 << 1
#else
#define CMU_REG2_PLL_LFRES__VALUE						0xA << 1
#endif

#define CMU_REG3_VCO_MANMOMSEL__MASK					~(0x3F << 10)
#define CMU_REG3_VCO_MOMSEL_INIT__MASK					~(0x3F << 4)
#define CMU_REG3_VCOVARSEL__MASK						~(0xF)
#define CMU_REG3_VCO_MANMOMSEL__VALUE					0x15 << 10
#ifdef STORM_A3
#define CMU_REG3_VCO_MOMSEL_INIT__VALUE					0x1A << 4
#else
#define CMU_REG3_VCO_MOMSEL_INIT__VALUE					0x15 << 4
#endif
#define CMU_REG3_VCOVARSEL__VALUE						0xF

#define CMU_REG26_FORCE_PLL_LOCK__MASK					~(0x1)
#define CMU_REG26_FORCE_PLL_LOCK__VALUE					0x0

#define CMU_REG5_PLL_LFSMCAP__MASK						~(0x3 << 14)
#define CMU_REG5_PLL_LFCAP__MASK						~(0x3 << 12)
#define CMU_REG5_PLL_LOCK_RESOLUTION__MASK				~(0x7 << 1)
#define CMU_REG5_PLL_LFSMCAP__VALUE						3 << 14
#define CMU_REG5_PLL_LFCAP__VALUE						3 << 12
#ifdef STORM_A3
#define CMU_REG5_PLL_LOCK_RESOLUTION__VALUE				0x7 << 7
#else
#define CMU_REG5_PLL_LOCK_RESOLUTION__VALUE				0x4 << 7
#endif

#define CMU_REG6_PLL_VREGTRIM__MASK						~(0x3 << 9)
#define CMU_REG6_MAN_PVT_CAL__MASK						~(0x1 << 2)
#ifdef STORM_A3
#define CMU_REG6_PLL_VREGTRIM__VALUE					0x2 << 9
#else
#define CMU_REG6_PLL_VREGTRIM__VALUE					0x0 << 9
#endif
#define CMU_REG6_MAN_PVT_CAL__SET						0x1 << 2

#define CMU_REG9_TX_WORD_MODE_CH1__MASK					~(0x7 << 7)
#define CMU_REG9_TX_WORD_MODE_CH0__MASK					~(0x7 << 4)
#define CMU_REG9_PLL_POST_DIVBY2__MASK					~(0x1 << 3)
#define CMU_REG9_VBG_BYPASSB__MASK						~(0x1 << 2)
#define CMU_REG9_IGEN_BYPASS__MASK						~(0x1 << 1)
#define CMU_REG9_TX_WORD_MODE_CH1__VALUE				0x3 << 7
#define CMU_REG9_TX_WORD_MODE_CH0__VALUE				0x3 << 4
#define CMU_REG9_PLL_POST_DIVBY2__SET					0x1 << 3
#define CMU_REG9_VBG_BYPASSB__SET						0x1 << 2
#define CMU_REG9_IGEN_BYPASS__SET						0x1 << 1

#define CMU_REG10_VREG_REFSEL__MASK						~(0x1)
#define CMU_REG10_VREG_REFSEL__SET						0x1

#define CMU_REG16_BYPASS_PLL_LOCK__MASK					~(0x1 << 6)
#define CMU_REG16_CALIBRATION_DONE_OVERRIDE__MASK		~(0x1 << 5)
#define CMU_REG16_VCOCAL_WAIT_BTW_CODE__MASK			~(0x7 << 2)
#define CMU_REG16_BYPASS_PLL_LOCK__SET					0x1 << 6
#define CMU_REG16_CALIBRATION_DONE_OVERRIDE__SET		0x1 << 5
#ifdef STORM_A3
#define CMU_REG16_VCOCAL_WAIT_BTW_CODE__VALUE			0x7 << 2
#else
#define CMU_REG16_VCOCAL_WAIT_BTW_CODE__VALUE			0x4 << 2
#endif

#define CMU_REG30_PCIE_MODE__MASK						~(0x1 << 3)
#define CMU_REG30_LOCK_COUNT__MASK						~(0x3 << 1)
#define CMU_REG30_PCIE_MODE__SET						0x1 << 3
#define CMU_REG30_LOCK_COUNT__VALUE						0x3 << 1

#define CMU_REG31_LOS_OVERRIDE_CH0__MASK				~(0x1 << 3)
#define CMU_REG31_LOS_OVERRIDE_CH1__MASK				~(0x1 << 2)
#define CMU_REG31_LOS_OVERRIDE_CH2__MASK				~(0x1 << 1)
#define CMU_REG31_LOS_OVERRIDE_CH3__MASK				~(0x1)
#define CMU_REG31_LOS_OVERRIDE_CH0__SET					0x1 << 3
#define CMU_REG31_LOS_OVERRIDE_CH1__SET					0x1 << 2
#define CMU_REG31_LOS_OVERRIDE_CH2__SET					0x1 << 1
#define CMU_REG31_LOS_OVERRIDE_CH3__SET					0x1

#define CMU_REG32_IREF_ADJ__MASK						~(0x3 << 7)
#define CMU_REG32_PVT_CAL_WAIT_SEL__MASK				~(0x3 << 1)
#ifdef STORM_A3
#define CMU_REG32_IREF_ADJ__VALUE						0x1 << 7
#else
#define CMU_REG32_IREF_ADJ__VALUE						0x3 << 7
#endif
#define CMU_REG32_PVT_CAL_WAIT_SEL__VALUE				0x3 << 1

#define CMU_REG34_VCO_CAL_VTH_HI_MIN__MASK				~(0xF << 12)
#define CMU_REG34_VCO_CAL_VTH_HI_MAX__MASK				~(0xF << 8)
#define CMU_REG34_VCO_CAL_VTH_LO_MIN__MASK				~(0xF << 4)
#define CMU_REG34_VCO_CAL_VTH_LO_MAX__MASK				~(0xF)
#define CMU_REG34_VCO_CAL_VTH_HI_MIN__VALUE				0x8 << 12
#ifdef STORM_A3
#define CMU_REG34_VCO_CAL_VTH_HI_MAX__VALUE				0xD << 8		// SSD fix 0xA
#define CMU_REG34_VCO_CAL_VTH_LO_MIN__VALUE				0x2 << 4		// SSD fix 0x5
#else
#define CMU_REG34_VCO_CAL_VTH_HI_MAX__VALUE				0xC << 8
#define CMU_REG34_VCO_CAL_VTH_LO_MIN__VALUE				0x3 << 4
#endif
#define CMU_REG34_VCO_CAL_VTH_LO_MAX__VALUE				0x7

#define CMU_REG37_CTLE_CAL_DONE_OVR__MASK				~(0xF << 12)
#define CMU_REG37_LATCH_CAL_DONE_OVR__MASK				~(0xF << 8)
#define CMU_REG37_SUMMER_OFF_CAL_DONE_OVR__MASK			~(0xF << 4)
#define CMU_REG37_FT_SEARCH_DONE_OVR__MASK				~(0xF)
#define CMU_REG37_CTLE_CAL_DONE_OVR__VALUE				0xF << 12
#define CMU_REG37_LATCH_CAL_DONE_OVR__VALUE				0x0 << 8
#define CMU_REG37_SUMMER_OFF_CAL_DONE_OVR__VALUE		0x0 << 4
#define CMU_REG37_FT_SEARCH_DONE_OVR__VALUE				0xF
/* CMU Config - End */

/* SSC Enabling - Start */
#define CMU_REG35_PLL_SSC_MOD__MASK						~(0x7F << 9)
#ifdef STORM_A3
#define CMU_REG35_PLL_SSC_MOD__VALUE					0x31 << 9		// 49
#else
#define CMU_REG35_PLL_SSC_MOD__VALUE					0x5F << 9
#endif

#define CMU_REG36_PLL_SSC_VSTEP__MASK					~(0x3FF << 6)
#define CMU_REG36_PLL_SSC_DSMSEL__MASK					~(0x1 << 5)
#define CMU_REG36_PLL_SSC_EN__MASK						~(0x1 << 4)
#ifdef STORM_A3
#define CMU_REG36_PLL_SSC_VSTEP__VALUE					0xC9 << 6		// 201
#else
#define CMU_REG36_PLL_SSC_VSTEP__VALUE					0x21 << 6		// 33
#endif
#define CMU_REG36_PLL_SSC_DSMSEL__SET					0x1 << 5
#define CMU_REG36_PLL_SSC_EN__SET						0x1 << 4

#define CMU_REG32_FORCE_VCOCAL_START__MASK				~(0x1 << 14)
#define CMU_REG32_FORCE_VCOCAL_START__SET				0x1 << 14
/* SSC Enabling - End */

/* RXTX Config - Start */
#define RXTX_REG147_STMC_OVERRIDE__MASK					0x0
#define RXTX_REG147_STMC_OVERRIDE__VALUE				0x6

#define RXTX_REG0_CTLE_EQ_HR__MASK						~(0x1F << 11)
#define RXTX_REG0_CTLE_EQ_QR__MASK						~(0x1F << 6)
#define RXTX_REG0_CTLE_EQ_FR__MASK						~(0x1F << 1)
#define RXTX_REG0_CTLE_EQ_HR__VALUE						0x10 << 11
#define RXTX_REG0_CTLE_EQ_QR__VALUE						0x10 << 6
#define RXTX_REG0_CTLE_EQ_FR__VALUE						0x10 << 1

#define RXTX_REG1_RXACVCM__MASK							~(0xF << 12)
#define RXTX_REG1_CTLE_EQ__MASK							~(0x1F << 7)
#define RXTX_REG1_RXACVCM__VALUE						0x7 << 12
#ifdef STORM_A3
#define RXTX_REG1_CTLE_EQ__VALUE						0x2 << 7			// SSD fix 0x1E
#else
#define RXTX_REG1_CTLE_EQ__VALUE						0xA << 7
#endif

#define RXTX_REG2_VTT_ENA__MASK							~(0x1 << 8)
#define RXTX_REG2_VTT_SEL__MASK							~(0x3 << 6)
#define RXTX_REG2_TX_FIFO_ENA__MASK						~(0x1 << 5)
#define RXTX_REG2_VTT_ENA__SET							0x1 << 8
#define RXTX_REG2_VTT_SEL__VALUE						0x1 << 6
#define RXTX_REG2_TX_FIFO_ENA__SET						0x1 << 5

#define RXTX_REG4_TX_WORD_MODE__MASK					~(0x7 << 11)
#define RXTX_REG4_TX_WORD_MODE__VALUE					0x3 << 11

#define RXTX_REG5_TX_CN1__MASK							~(0x1F << 11)
#define RXTX_REG5_TX_CP1__MASK							~(0x3F << 5)
#define RXTX_REG5_TX_CN2__MASK							~(0x1F)
#define RXTX_REG5_TX_CN1__VALUE							0x0 << 11			// SSD fix 0x2
#ifdef STORM_A3
#define RXTX_REG5_TX_CP1__VALUE							0x5 << 5			// SSD fix 0xA
#define RXTX_REG5_TX_CN2__VALUE							0x0
#else
#define RXTX_REG5_TX_CP1__VALUE							0xF << 5
#define RXTX_REG5_TX_CN2__VALUE							0x4					// SSD fix 0x0
#endif

#define RXTX_REG6_TXAMP_CNTL__MASK						~(0xF << 7)
#define RXTX_REG6_TXAMP_ENA__MASK						~(0x1 << 6)
#define RXTX_REG6_TX_IDLE__MASK							~(0x1 << 3)
#define RXTX_REG6_RX_BIST_RESYNC__MASK					~(0x1 << 1)
#define RXTX_REG6_RX_BIST_ERRCNT_RD__MASK				~(0x1)
#ifdef STORM_A3
#define RXTX_REG6_TXAMP_CNTL__VALUE						0xA << 7			// SSD fix 0x8
#else
#define RXTX_REG6_TXAMP_CNTL__VALUE						0xF << 7
#endif
#define RXTX_REG6_TXAMP_ENA__SET						0x1 << 6
#define RXTX_REG6_TX_IDLE__SET							0x1 << 3
#define RXTX_REG6_RX_BIST_RESYNC__SET					0x1 << 1
#define RXTX_REG6_RX_BIST_ERRCNT_RD__SET				0x1

#define RXTX_REG7_RX_WORD_MODE__MASK					~(0x7 << 11)
#define RXTX_REG7_BIST_ENA_RX__MASK						~(0x1 << 6)
#define RXTX_REG7_RX_WORD_MODE__VALUE					0x3 << 11
#define RXTX_REG7_BIST_ENA_RX__SET						0x1 << 6

#define RXTX_REG8_CDR_LOOP_ENA__MASK					~(0x1 << 14)
#define RXTX_REG8_CDR_BYPASS_RXLOS__MASK				~(0x1 << 11)
#define RXTX_REG8_SSC_ENABLE__MASK						~(0x1 << 9)
#define RXTX_REG8_SD_DISABLE__MASK						~(0x1 << 8)
#define RXTX_REG8_SD_VREF__MASK							~(0xF << 4)
#define RXTX_REG8_CDR_LOOP_ENA__SET						0x1 << 14
#define RXTX_REG8_CDR_BYPASS_RXLOS__SET					0x1 << 11
#define RXTX_REG8_SSC_ENABLE__SET						0x1 << 9
#define RXTX_REG8_SD_DISABLE__SET						0x1 << 8
#define RXTX_REG8_SD_VREF__VALUE						0x4 << 4

#define RXTX_REG11_PHASE_ADJUST_LIMIT__MASK				~(0x1F << 11)
#define RXTX_REG11_PHASE_ADJUST_LIMIT__VALUE			0x0 << 11

#define RXTX_REG12_LATCH_OFF_ENA__MASK					~(0x1 << 13)
#define RXTX_REG12_SUMOS_ENABLE__MASK					~(0x1 << 2)
#define RXTX_REG12_RX_DET_TERM_ENABLE__MASK				~(0x1 << 1)
#define RXTX_REG12_LATCH_OFF_ENA__SET					0x1 << 13
#define RXTX_REG12_SUMOS_ENABLE__SET					0x1 << 2
#define RXTX_REG12_RX_DET_TERM_ENABLE__SET				0x1 << 1

#define RXTX_REG26_PERIOD_ERROR_LATCH__MASK				~(0x7 << 11)
#define RXTX_REG26_BLWC_ENA__MASK						~(0x1 << 3)
#define RXTX_REG26_PERIOD_ERROR_LATCH__VALUE				0x0 << 11
#define RXTX_REG26_BLWC_ENA__SET						0x1 << 3

#define RXTX_REG28_DFE_TAP_ENA__MASK					~0xFFFF
#define RXTX_REG28_DFE_TAP_ENA__VALUE					0x0						// SSD fix 0x7

#define RXTX_REG31_DFE_PRESET_VALUE_H0__MASK			~(0x7F << 9)
#define RXTX_REG31_DFE_PRESET_VALUE_H1__MASK			~(0x7F << 1)
#define RXTX_REG31_DFE_PRESET_VALUE_H0__VALUE			0x0						// SSD fix 0x3F
#define RXTX_REG31_DFE_PRESET_VALUE_H1__VALUE			0x0


/* RXTX Config - End */


#if SSD_FIX
// CMU_REG0
#define CAL_COUNT_RESOL					0x7
// CMU_REG1
#define PLL_CP							0x1
#define PLL_CP_SEL						0x3
#define PLL_MANUALCAL					0x0
// CMU_REG2
#define PLL_LFRES						0xa
// CMU_REG3
#define VCO_MANMOMSEL					0x15
#define VCO_MOMSEL_INIT					0x1A
// CMU_REG5
#define PLL_LFSMCAP			 			0x3
#define PLL_LFCAP						0x3
#define PLL_LOCK_RESOLUTION				0x7
// CMU_REG6
#define PLL_VREGTRIM					0x2
#define MAN_PVT_CAL				 		0x0
// CMU_REG9
#define TX_WORD_MODE_CH1				0x3
#define TX_WORD_MODE_CH0				0x3
#define PLL_POST_DIVBY2					0x1
#define VBG_BYPASSB						0x0
#define IGEN_BYPASS						(val , 0x0
// CMU_REG10
#define VREG_REFSEL						0x1
// CMU_REG16
#define CALIBRATION_DONE_OVERRIDE		0x1
#define BYPASS_PLL_LOCK					0x1
#define VCOCAL_WAIT_BTW_CODE			0x7
// CMU_REG26
#define FORCE_PLL_LOCK					0x0
// CMU_REG30
#define PCIE_MODE						0x0
#define LOCK_COUNT						0x3
// CMU_REG32
#define IREF_ADJ						0x1
#define PVT_CAL_WAIT_SEL				0x3
// CMU_REG34
#define VCO_CAL_VTH_HI_MIN				0x8
#define VCO_CAL_VTH_HI_MAX				0xA
#define VCO_CAL_VTH_LO_MIN				0x5
#define VCO_CAL_VTH_LO_MAX				0x7
// CMU_REG37
#define PLL_SSC_VSTEP					0x3C0
#define PLL_SSC_DSMSEL					0x1
#define PLL_SSC_EN						0x1
#define FORCE_RATE_CHANGE_RX_CH2		0x1
#define FORCE_RATE_CHANGE_TX_CH2		0x1
#define FORCE_RATE_CHANGE_RX_CH3		0x1
#define FORCE_RATE_CHANGE_TX_CH3		0x1

//RXTX_REG0
#define CTLE_EQ_HR				0x10
#define CTLE_EQ_QR				0x10
#define CTLE_EQ_FR				0x10
//RXTX_REG1
#define RXACVCM					0x7
#define CTLE_EQ					0xA		// need check
#define RXVREG1					0x2
#define RXIREF_ADJ				0x2
//RXTX_REG2
#define VTT_ENA					0x1
#define VTT_SEL					0x1
#define TX_FIFO_ENA				0x1
//RXTX_REG4
#define TX_WORD_MODE			0x3
//RXTX_REG5
#define TX_CN1					0x2
#define TX_CP1					0xa
#define TX_CN2					0x0
#define TX_CN2					0x0
//RXTX_REG6
#define TXAMP_CNTL				0x8
#define TXAMP_ENA				0x1
#define TX_IDLE					0x0
#define RX_BIST_RESYNC			0x0
#define RX_BIST_ERRCNT_RD		0x0
//RXTX_REG7
#define BIST_ENA_RX				0x0
#define RX_WORD_MODE			0x3
//RXTX_REG8
#define SSC_ENABLE				0x1
#define SD_DISABLE				0x0
#define SD_VREF					0x4
//RXTX_REG11
#define PHASE_ADJUST_LIMIT		0x0
//RXTX_REG12
#define SUMOS_ENABLE			0x0
#define RX_DET_TERM_ENABLE		0x0
//RXTX_REG26
#define PERIOD_ERROR_LATCH		0x0
#define BLWC_ENA				0x1
//RXTX_REG61
#define EYE_COUNT_WIDTH_SEL		0x0
#define ISCAN_INBERT			0x1
#define LOADFREQ_SHIFT			0x0
//RXTX_REG62
#define PERIOD_H1_QLATCH		0x0
//RXTX_REG89
#define MU_TH7					0xE
#define MU_TH8					0xE
#define MU_TH9					0xE
//RXTX_REG96
#define MU_FREQ1				0x10
#define MU_FREQ2				0x10
#define MU_FREQ3				0x10
//RXTX_REG99
#define MU_PHASE1				0x7
#define MU_PHASE2				0x7
#define MU_PHASE3				0x7
//RXTX_REG102
#define FREQLOOP_LIMIT			0x0
//RXTX_REG125
#define PQ_REG					0xA
#define SIGN_PQ					0x0
#define PHZ_MANUAL				0x1
//RXTX_REG127
#define LATCH_MAN_CAL_ENA		0x0
//RXTX_REG128
#define LATCH_CAL_WAIT_SEL		0x3
//RXTX_REG145
#define RXDFE_CONFIG			0x3
#define RXES_ENA				0x0
#define TX_IDLE_SATA			0x0
#endif

#endif
