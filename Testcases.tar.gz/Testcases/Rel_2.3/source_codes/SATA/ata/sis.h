
struct ata_port_info;

/* pata_sis.c */
extern const struct ata_port_info sis_info133_for_sata;
