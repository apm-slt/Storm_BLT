/*
 * AppliedMicro X-Gene SATA PHY driver
 *
 * Copyright (c) 2013, Applied Micro Circuits Corporation
 * Author: Loc Ho <lho@apm.com>
 *         Tuan Phan <tphan@apm.com>
 *         Suman Tripathi <stripathi@apm.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#ifndef __SATA_XGENE_H__
#define __SATA_XGENE_H__

#include "ahci.h"	/* for ahci_host_priv */

/* Default tuning parameters */
#define XGENE_SERDES_VAL_NOT_SET	~0x0
#define CTLE_EQ 			0x9
#define PQ_REG  			0x8
#define CTLE_EQ_A2 			0x2
#define PQ_REG_A2  			0xa
#define CTLE_EQ_A3 			0x3
#define SPD_SEL 			0x5
#define SPD_SEL_A3 			0x7

/* Max # of disk per a controller */
#define MAX_AHCI_CHN_PERCTR	 	2
#define MAX_AHCI_CTR	 	3

/*
 * Configure Reference clock (clock type):
 *  External differential 0
 *  Internal differential 1
 *  Internal single ended 2
 */
#define SATA_CLK_EXT_DIFF		0
#define SATA_CLK_INT_DIFF		1
#define SATA_CLK_INT_SING		2

#define SPD_SEL_GEN2			0x3
#define SPD_SEL_GEN1			0x1

/* Common Macro both for serdes and controller */

#define SATA_CLK_OFFSET			0x0000C000
#define SATASRESETREG_ADDR		0x00000004
#define  SATA_MEM_RESET_MASK		0x00000020
#define D0_RD(src)  (((src)& 0x00100000)>>20)
#define B0_RD(src)   (((src)&0x00080000)>>19)
#define SSTS0_ADDR    0x00000128

struct xgene_ahci_context {
	struct ahci_host_priv  hpriv;
	struct device *dev;
	u8 cid;			/* Controller ID */
	int irq;		/* IRQ */
	void *csr_base;		/* CSR base address of IP - serdes */
	void *mmio_base;	/* AHCI I/O base address */
	void *pcie_base;	/* Shared Serdes CSR in PCIe 4/5 domain */
	void *ahbc_io_base;	/* Used for IOB flushing */
	u64 csr_phys;		/* Physical address of CSR base address */
	u64 mmio_phys;		/* Physical address of MMIO base address */

	/* Override Serdes parameters */
	u32 disk_ssd[MAX_AHCI_CHN_PERCTR];
	u32 ctrl_eq_A1; 	/* Serdes Reg 1 RX/TX ctrl_eq value for A1 */
	u32 ctrl_eq[MAX_AHCI_CHN_PERCTR][3];	/* Serdes Reg 1 RX/TX ctrl_eq value */
	u32 ctrl_eq_ssd[MAX_AHCI_CHN_PERCTR][3];/* Serdes Reg 1 RX/TX ctrl_eq value for SSD */
	u32 dfe[MAX_AHCI_CHN_PERCTR][3];/* DFE */
	u32 pq_A1; 		/* Serdes Reg 125 pq value for A1 */
	u32 pq[MAX_AHCI_CHN_PERCTR][3];	/* Serdes Reg 125 pq value */
	u32 pq_sign;		/* Serdes Reg 125 pq sign */
	u32 loopback_buf_en_A1; /* Serdes Reg 4 Tx loopback buffer enable for A1 */
	u32 loopback_buf_en;    /* Serdes Reg 4 Tx loopback buffer enable */
	u32 loopback_ena_ctle_A1; /* Serdes Reg 7 loopback enable ctrl value for A1 */
	u32 loopback_ena_ctle;  /* Serdes Reg 7 loopback enable ctrl value */
	u32 spd_sel_cdr_A1;	/* Serdes Reg 61 spd sel cdr value for A1*/
	u32 spd_sel_cdr[3];	/* Serdes Reg 61 spd sel cdr value */
	u32 use_gen_avg;	/* Use generate average value */

	u32 coherent;		/* Coherent IO */
};

void xgene_ahci_enable_phy(struct xgene_ahci_context *ctx, int channel, int enable);
int xgene_ahci_clean_disparity(void *port_mmio , struct xgene_ahci_context *ctx , int channel);
void xgene_ahci_port_ctr_rxreset(void *port_mmio,struct xgene_ahci_context *ctx, int channel);
void xgene_ahci_in32(void *addr, u32 *val);
void xgene_ahci_out32(void *addr, u32 val);
void xgene_ahci_out32_flush(void *addr, u32 val);
void xgene_ahci_delayus(unsigned long us);
void xgene_ahci_delayms(unsigned long ms);
int xgene_ahci_is_A1(void);
int xgene_ahci_is_A2(void);
int xgene_ahci_is_A3(void);

int xgene_ahci_serdes_init(struct xgene_ahci_context *ctx,
	int gen_sel, int clk_type, int rxwclk_inv);
void xgene_ahci_serdes_gen_avg_val(struct xgene_ahci_context *ctx, int channel);
void xgene_ahci_serdes_force_lat_summer_cal(struct xgene_ahci_context *ctx,
	int channel);
void xgene_ahci_serdes_reset_rxa_rxd(struct xgene_ahci_context *ctx,
	int channel);
void xgene_ahci_serdes_force_gen(struct xgene_ahci_context *ctx, int channel,
	int gen);
void xgene_ahci_serdes_set_pq(struct xgene_ahci_context *ctx, int chan,
	int data);
int xgene_ahci_reprogram_ctle(struct xgene_ahci_context *ctx, int chan,
	int gen);

int xgene_ahci_port_start(struct ata_port *ap);
int xgene_ahci_port_resume(struct ata_port *ap);
#if defined(CONFIG_ARCH_MSLIM)
void xgene_ahci_fill_cmd_slot(struct ahci_port_priv *pp,
	unsigned int tag, u32 opts);
u64 xgene_ahci_to_axi(dma_addr_t addr);
void xgene_ahci_dflush(void *addr, int size);
int xgene_ahci_exec_polled_cmd(struct ata_port *ap, int pmp,
	struct ata_taskfile *tf, int is_cmd, u16 flags,
	unsigned long timeout_msec);
#else
#define xgene_ahci_fill_cmd_slot	ahci_fill_cmd_slot
#define xgene_ahci_exec_polled_cmd	ahci_exec_polled_cmd
#define xgene_ahci_to_axi(x)		(x)
#define xgene_ahci_dflush(x, ...)
#endif

#endif /* __SATA_XGENE_H__ */
