/*
 * AppliedMicro X-Gene SoC SATA Driver
 *
 * Copyright (c) 2013, Applied Micro Circuits Corporation
 * Author: Loc Ho <lho@apm.com>
 *         Tuan Phan <tphan@apm.com>
 *         Suman Tripathi <stripathi@apm.com>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 * MA 02111-1307 USA
 *
 * This file include routines that are only needed by MSLIM.
 */

#ifdef CONFIG_ARCH_MSLIM
#include <linux/module.h>
#include <linux/platform_device.h>
#include <linux/io.h>
#include <asm/hardware/mslim-iof-map.h>
#include <asm/cacheflush.h>
#include "sata_xgene.h"

u64 xgene_ahci_to_axi(dma_addr_t addr)
{
	/* Due to the fact that the DDR address seen by the MSLIM is different
	 * from what is needed by the SATA core, we need a translation from
	 * MSLIM CPU DDR address into AXI address that the SATA core can
	 * access.
	 */
	return mslim_pa_to_iof_axi(addr);
}

void xgene_ahci_dflush(void *addr, int size)
{
	/* Due to the fact that the MSLIM L1/L2 cache is not coherent with
         * the IO, we need to flush before given the data to the SATA core.
	 */
	__cpuc_flush_dcache_area(addr, size);
}

void xgene_ahci_fill_cmd_slot(struct ahci_port_priv *pp,
        unsigned int tag, u32 opts)
{
        dma_addr_t cmd_tbl_dma = pp->cmd_tbl_dma + tag * AHCI_CMD_TBL_SZ;
        u64 cmd_tbl_dma_addr = xgene_ahci_to_axi(cmd_tbl_dma);

        pp->cmd_slot[tag].opts = cpu_to_le32(opts);
        pp->cmd_slot[tag].status = 0;
        pp->cmd_slot[tag].tbl_addr = cpu_to_le32(cmd_tbl_dma_addr &
						 0xffffffff);
        pp->cmd_slot[tag].tbl_addr_hi = cpu_to_le32((cmd_tbl_dma_addr >> 16)
						    >> 16);
        xgene_ahci_dflush((void *) &pp->cmd_slot[tag],
			  sizeof(pp->cmd_slot[tag]));
}

int xgene_ahci_exec_polled_cmd(struct ata_port *ap, int pmp,
	struct ata_taskfile *tf, int is_cmd, u16 flags,
	unsigned long timeout_msec)
{
	const u32 cmd_fis_len = 5; /* five dwords */
	struct ahci_port_priv *pp = ap->private_data;
	void __iomem *port_mmio = ahci_port_base(ap);
	u8 *fis = pp->cmd_tbl;
	u32 tmp;

	/* prep the command */
	ata_tf_to_fis(tf, pmp, is_cmd, fis);

	/* Must call X-Gene version in case it needs to flush the cache for
           MSLIM as well as AXI address translation */
	xgene_ahci_fill_cmd_slot(pp, 0, cmd_fis_len | flags | (pmp << 12));

	/* issue & wait */
	writel(1, port_mmio + PORT_CMD_ISSUE);

	if (timeout_msec) {
		tmp = ata_wait_register(ap, port_mmio + PORT_CMD_ISSUE,
					0x1, 0x1, 1, timeout_msec);
		if (tmp & 0x1) {
			ahci_kick_engine(ap);
			return -EBUSY;
		}
	} else {
		readl(port_mmio + PORT_CMD_ISSUE);	/* flush */
	}
	return 0;
}

/*
 * Due to the fact that the DDR address seen by the MSLIM is different
 * from what is needed by the SATA core, we need a translation from
 * CPU address into AXI address that the SATA core can access.
 */
static void xgene_ahci_start_fis_rx(struct ata_port *ap)
{
	void __iomem *port_mmio = ahci_port_base(ap);
	struct ahci_host_priv *hpriv = ap->host->private_data;
	struct ahci_port_priv *pp = ap->private_data;
	u32 tmp;
	u64 cmd_slot_dma_addr = xgene_ahci_to_axi(pp->cmd_slot_dma);
	u64 rx_fis_dma_addr = xgene_ahci_to_axi(pp->rx_fis_dma);

	if (hpriv->cap & HOST_CAP_64)
		writel((cmd_slot_dma_addr >> 16) >> 16,
		       port_mmio + PORT_LST_ADDR_HI);
	writel(cmd_slot_dma_addr& 0xffffffff, port_mmio + PORT_LST_ADDR);

	if (hpriv->cap & HOST_CAP_64)
		writel((rx_fis_dma_addr >> 16) >> 16,
		       port_mmio + PORT_FIS_ADDR_HI);
	writel(rx_fis_dma_addr & 0xffffffff, port_mmio + PORT_FIS_ADDR);
	/* enable FIS reception */
	tmp = readl(port_mmio + PORT_CMD);
	tmp |= PORT_CMD_FIS_RX;
	writel(tmp, port_mmio + PORT_CMD);

	/* flush */
	readl(port_mmio + PORT_CMD);
}

static void xgene_ahci_start_port(struct ata_port *ap)
{
	struct ahci_host_priv *hpriv = ap->host->private_data;
	struct ahci_port_priv *pp = ap->private_data;
	struct ata_link *link;
	struct ahci_em_priv *emp;
	ssize_t rc;
	int i;

	/* enable FIS reception */
	xgene_ahci_start_fis_rx(ap);

	/* enable DMA */
	if (!(hpriv->flags & AHCI_HFLAG_DELAY_ENGINE))
		ahci_start_engine(ap);

	/* turn on LEDs */
	if (ap->flags & ATA_FLAG_EM) {
		ata_for_each_link(link, ap, EDGE) {
			emp = &pp->em_priv[link->pmp];

			/* EM Transmit bit maybe busy during init */
			for (i = 0; i < EM_MAX_RETRY; i++) {
				rc = ahci_transmit_led_message(ap,
							       emp->led_state,
							       4);
				if (rc == -EBUSY)
					ata_msleep(ap, 1);
				else
					break;
			}
		}
	}

	if (ap->flags & ATA_FLAG_SW_ACTIVITY)
		ata_for_each_link(link, ap, EDGE)
			ahci_init_sw_activity(link);
}

int xgene_ahci_port_resume(struct ata_port *ap)
{
	ahci_power_up(ap);
	xgene_ahci_start_port(ap);

	if (sata_pmp_attached(ap))
		ahci_pmp_attach(ap);
	else
		ahci_pmp_detach(ap);

	return 0;
}

int xgene_ahci_port_start(struct ata_port *ap)
{
	struct ahci_host_priv *hpriv = ap->host->private_data;
	struct device *dev = ap->host->dev;
	struct ahci_port_priv *pp;
	void *mem;
	dma_addr_t mem_dma;
	size_t dma_sz, rx_fis_sz;

	pp = devm_kzalloc(dev, sizeof(*pp), GFP_KERNEL);
	if (!pp)
		return -ENOMEM;

	/* check FBS capability */
	if ((hpriv->cap & HOST_CAP_FBS) && sata_pmp_supported(ap)) {
		void __iomem *port_mmio = ahci_port_base(ap);
		u32 cmd = readl(port_mmio + PORT_CMD);
		if (cmd & PORT_CMD_FBSCP)
			pp->fbs_supported = true;
		else if (hpriv->flags & AHCI_HFLAG_YES_FBS) {
			dev_info(dev, "port %d can do FBS, forcing FBSCP\n",
				 ap->port_no);
			pp->fbs_supported = true;
		} else
			dev_warn(dev, "port %d is not capable of FBS\n",
				 ap->port_no);
	}

	if (pp->fbs_supported) {
		dma_sz = AHCI_PORT_PRIV_FBS_DMA_SZ;
		rx_fis_sz = AHCI_RX_FIS_SZ * 16;
	} else {
		dma_sz = AHCI_PORT_PRIV_DMA_SZ;
		rx_fis_sz = AHCI_RX_FIS_SZ;
	}

	mem = dmam_alloc_coherent(dev, dma_sz, &mem_dma, GFP_KERNEL);
	if (!mem)
		return -ENOMEM;
	memset(mem, 0, dma_sz);

	/*
	 * First item in chunk of DMA memory: 32-slot command table,
	 * 32 bytes each in size
	 */
	pp->cmd_slot = mem;
	pp->cmd_slot_dma = mem_dma;
	mem += AHCI_CMD_SLOT_SZ;
	mem_dma += AHCI_CMD_SLOT_SZ;

	/*
	 * Second item: Received-FIS area
	 */
	pp->rx_fis = mem;
	pp->rx_fis_dma = mem_dma;
	mem += rx_fis_sz;
	mem_dma += rx_fis_sz;

	/*
	 * Third item: data area for storing a single command
	 * and its scatter-gather table
	 */
	pp->cmd_tbl = mem;
	pp->cmd_tbl_dma = mem_dma;
	/*
	 * Save off initial list of interrupts to be enabled.
	 * This could be changed later
	 */
	pp->intr_mask = DEF_PORT_IRQ;

	ap->private_data = pp;

	/* engage engines, captain */
	return xgene_ahci_port_resume(ap);
}
#endif /* CONFIG_ARCH_MSLIM */
