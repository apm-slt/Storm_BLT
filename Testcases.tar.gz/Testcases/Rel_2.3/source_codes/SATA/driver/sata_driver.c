/*
 * Copyright (C) 2013 AppliedMicro Confidential Information
 * All Rights Reserved.
 *
 * THIS WORK CONTAINS PROPRIETARY INFORMATION WHICH IS THE PROPERTY OF
 * AppliedMicro AND IS SUBJECT TO THE TERMS OF NON-DISCLOSURE AGREEMENT
 * BETWEEN AppliedMicro AND THE COMPANY USING THIS FILE.
 *
 * WARNING !!!
 * This is an auto-generated C header file for register definitions
 * PLEASE DON'T MANUALLY MODIFY IN THIS FILE AS CHANGES WILL BE LOST
 *
 *  sata_driver.c
 *
 *  Created on : Feb 02, 2013
 *  Last Update: Jul 12, 2014
 *  Author     : kqngo@apm.com
 *
 *  Serdes config 07/12/14: storm_a3/SM_SATA/SATA_6PORTS_B0/
 *  Serdes config 07/28/14: storm_b0/SM_SATA/SATA_6PORTS_B0/
 */

#ifndef _SATA_DRIVER_C__
#define _SATA_DRIVER_C__

#include "../include/sata_driver.h"

#define MDIO_EN
//#define TUNING
#define B0_1

#if DDR_CACHEABLE
extern dcache_flush_all();
#endif

int fix_gen_avg_val	= 1;			// 071014

int SDS_DUMP		= 0;
int SSC_EN			= 0;
int SSC1_EN			= 0;
int PLL_SSC_MOD		= 0x62;			// 0x62 / 49
int PLL_SSC_VSTEP	= 0x1E;			// 0x1E / 1500ppm = 121, 2500ppm = 201, 3000ppm = 242
int CLK_REF			= 0;			// 0: External - 1: Internal
int CLK_TYPE		= 0;			// 0: CML      - 1: CMOS
//int CLK_FREQ		= 1;			// 0: 100MHz   - 1: 50MHz   - 2: 25MHz
int PLL_GEN			= 3;			// 1: Gen1 / 2: Gen2 / 3: Gen3
int LINK_GEN		= 0;			// 0: Auto / 1: Gen1 / 2: Gen2 / 3: Gen3
int PVT_MAN			= 0;			// 0: Auto / 1: Manual
int WATERMARK		= 0;

int FBS			= 0;	//FIS-based switching
u64 STA_SECTOR  = 10;
int NUM_SECTOR  = 4000;	// in sectors
int PRD_SIZE 	= 64;	// in KBs

#ifdef A2							// 071014
int CLK_FREQ			= 1;
int CMU_REG13__VALUE			= 0xF222;
int CMU_REG26_FORCE_PLL_LOCK	= 0x0;
int CMU_REG10_VREG_REFSEL		= 0x0;
int CMU_REG32_IREF_ADJ			= 0x3;
int CMU_REG3_VCO_MANMOMSEL  	= 0x15;
int CMU_REG3_VCO_MOMSEL_INIT	= 0x15;
int RXTX_REG8_SD_VREF			= 0x4;
int CTLE_EQ						= 0xA;
int TX_CN1						= 0x0;
int TX_CP1						= 0x0;
int TX_CN2						= 0x0;
int CTLE_EQ_QR					= 0x10;
int CTLE_EQ_HR					= 0x10;
int CTLE_EQ_FR					= 0x10;

int PQ_REG						= 0x9;
int RXTX_REG1_RXVREG1			= 0x2;
int RXTX_REG1_RXVREG1P2			= 0x2;
int RXTX_REG1_RXIREF_ADJ		= 0x2;
int RXTX_REG5_TX_CP1			= 0xF;
int RXTX_REG5_TX_CN1			= 0x0;
int RXTX_REG5_TX_CN2			= 0x4;
int RXTX_REG6_TX_CN2_INV		= 0x0;	//0x1;
int RXTX_REG6_TXAMP_CNTL		= 0xF;
int RXTX_REG6_TXAMP_ENA			= 0x1;	//0x0;
int DFE							= 0x0;
#endif	/* A2 */

#ifdef A3							// 071014
int CLK_FREQ			= 1;
int CMU_REG13__VALUE			= 0x0222;
int CMU_REG26_FORCE_PLL_LOCK	= 0x0;
int CMU_REG10_VREG_REFSEL		= 0x1;
int CMU_REG32_IREF_ADJ			= 0x1;
int CMU_REG3_VCO_MANMOMSEL  	= 0x15;
int CMU_REG3_VCO_MOMSEL_INIT	= 0x1A;
int RXTX_REG8_SD_VREF			= 0x4;
int CTLE_EQ						= 0x3;
int TX_CN1						= 0x0;
int TX_CP1						= 0x0;
int TX_CN2						= 0x0;
int CTLE_EQ_QR					= 0x10;
int CTLE_EQ_HR					= 0x10;
int CTLE_EQ_FR					= 0x10;

int PQ_REG						= 0xA;
int RXTX_REG1_RXVREG1			= 0x2;
int RXTX_REG1_RXVREG1P2			= 0x2;
int RXTX_REG1_RXIREF_ADJ		= 0x2;
int RXTX_REG5_TX_CP1			= 0xA;
int RXTX_REG5_TX_CN1			= 0x0;
int RXTX_REG5_TX_CN2			= 0x4;
int RXTX_REG6_TX_CN2_INV		= 0x0;	//0x1;
int RXTX_REG6_TXAMP_CNTL		= 0x8;
int RXTX_REG6_TXAMP_ENA			= 0x1;	//0x0;
int DFE							= 0x0;
#endif	/* A2 */

#ifdef B0							// 071014
int CLK_FREQ			= 1;
int CMU_REG13__VALUE			= 0x0222;
int CMU_REG26_FORCE_PLL_LOCK	= 0x0;
int CMU_REG10_VREG_REFSEL		= 0x1;
int CMU_REG32_IREF_ADJ			= 0x1;
int CMU_REG3_VCO_MANMOMSEL  	= 0x18;
int CMU_REG3_VCO_MOMSEL_INIT	= 0x1A;
int RXTX_REG8_SD_VREF			= 0x4;
int CTLE_EQ						= 0x3;
int TX_CN1						= 0x0;
int TX_CP1						= 0x0;
int TX_CN2						= 0x0;
int CTLE_EQ_QR					= 0x10;
int CTLE_EQ_HR					= 0x10;
int CTLE_EQ_FR					= 0x10;

int PQ_REG						= 0x8;
int RXTX_REG1_RXVREG1			= 0x2;
int RXTX_REG1_RXVREG1P2			= 0x2;
int RXTX_REG1_RXIREF_ADJ		= 0x2;
int RXTX_REG5_TX_CP1			= 0xA;	//0x5;	//0x7;
int RXTX_REG5_TX_CN1			= 0x0;
int RXTX_REG5_TX_CN2			= 0x0;	//0x4;
int RXTX_REG6_TX_CN2_INV		= 0x0;	//0x1;
int RXTX_REG6_TXAMP_CNTL		= 0x5;
int RXTX_REG6_TXAMP_ENA			= 0x1;	//0x0;
int DFE							= 0x0;
#endif	/* B0 */

#ifdef B0_1							// 072814
int CLK_FREQ			= 1;
int CMU_REG13__VALUE			= 0x0222;
int CMU_REG26_FORCE_PLL_LOCK	= 0x0;
int CMU_REG10_VREG_REFSEL		= 0x1;
int CMU_REG32_IREF_ADJ			= 0x1;
int CMU_REG3_VCO_MANMOMSEL  	= 0x18;
int CMU_REG3_VCO_MOMSEL_INIT	= 0x1A;
int RXTX_REG8_SD_VREF			= 0x4;
int CTLE_EQ						= 0x3;
int TX_CN1						= 0x0;
int TX_CP1						= 0x0;
int TX_CN2						= 0x0;
int CTLE_EQ_QR					= 0x10;
int CTLE_EQ_HR					= 0x10;
int CTLE_EQ_FR					= 0x10;

int PQ_REG						= 0x8;
int RXTX_REG1_RXVREG1			= 0x2;
int RXTX_REG1_RXVREG1P2			= 0x2;
int RXTX_REG1_RXIREF_ADJ		= 0x2;
int RXTX_REG5_TX_CP1			= 0xA;	//0x5;	//0x7;
int RXTX_REG5_TX_CN1			= 0x0;
int RXTX_REG5_TX_CN2			= 0x0;	//0x4;
int RXTX_REG6_TX_CN2_INV		= 0x0;	//0x1;
int RXTX_REG6_TXAMP_CNTL		= 0x5;
int RXTX_REG6_TXAMP_ENA			= 0x1;	//0x0;
int DFE							= 0x0;
#endif	/* B0_1 */

#ifdef B0_2							// 081114
int CLK_FREQ			= 2;
int CMU_REG13__VALUE			= 0x5222;
int CMU_REG26_FORCE_PLL_LOCK	= 0x1;
int CMU_REG10_VREG_REFSEL		= 0x1;
int CMU_REG32_IREF_ADJ			= 0x1;
int CMU_REG3_VCO_MANMOMSEL  	= 0x18;
int CMU_REG3_VCO_MOMSEL_INIT	= 0x1A;
int RXTX_REG8_SD_VREF			= 0x6;
int CTLE_EQ						= 0x3;
int TX_CN1						= 0x0;
int TX_CP1						= 0x0;
int TX_CN2						= 0x0;
int CTLE_EQ_QR					= 0x10;
int CTLE_EQ_HR					= 0x10;
int CTLE_EQ_FR					= 0x10;

int PQ_REG						= 0x8;
int RXTX_REG1_RXVREG1			= 0x2;
int RXTX_REG1_RXVREG1P2			= 0x2;
int RXTX_REG1_RXIREF_ADJ		= 0x2;
int RXTX_REG5_TX_CP1			= 0xA;	//0x5;	//0x7;
int RXTX_REG5_TX_CN1			= 0x0;
int RXTX_REG5_TX_CN2			= 0x0;	//0x4;
int RXTX_REG6_TX_CN2_INV		= 0x0;	//0x1;
int RXTX_REG6_TXAMP_CNTL		= 0x5;
int RXTX_REG6_TXAMP_ENA			= 0x1;	//0x0;
int DFE							= 0x0;
#endif	/* B0_2 */

#ifdef TUNING
#ifdef B0
int CTLE_EQ_0	= 0x3;
int CTLE_EQ_1	= 0x3;
int CTLE_EQ_2	= 0x3;
int CTLE_EQ_3	= 0x3;
int CTLE_EQ_4	= 0x3;
int CTLE_EQ_5	= 0x3;
#else
int CTLE_EQ_0	= 0x19;
int CTLE_EQ_1	= 0x19;
int CTLE_EQ_2	= 0x19;
int CTLE_EQ_3	= 0x19;
int CTLE_EQ_4	= 0x19;
int CTLE_EQ_5	= 0x19;
#endif /* B0 */
#endif	/* TUNNING */

typedef enum{
	LBP	 = 0,
	LFTP = 1,
	MFTP = 2,
	HFTP = 3,
	PRBS = 4,
	BIST = 5,
}pattern_mode;

typedef enum{
	PRBS7  = 0,
	PRBS9  = 1,
	PRBS11 = 2,
	PRBS23 = 3,
	PRBS31 = 4,
}prbs_mode;

int test_id;				//  1: Read ID
							//  2: PIO tests
							//  3: DMA tests
							//  4: FPDMA tests
							//  5: CCC
							//  6: NCQ
                            //  9: IRQ
							// 10: Hotplug
							// 11: ASR
							// 12: AN
int device_id;
int vendor_id;
int irq_cnt, irq_ccc_cnt;

typedef struct CMD_HEADER{
	// DWORD 0
	u8	cfl:5;		// Command FIS length in DWORDS, 2 ~ 16
	u8	a:1;		// ATAPI
	u8	w:1;		// Data direction 1: Mem to Dev, 0: Dev to Mem
	u8	p:1;		// Prefetchable

	u8	r:1;		// Reset
	u8	b:1;		// BIST
	u8	c:1;		// Clear busy upon R_OK
	u8	rsv0:1;		// Reserved
	u8	pmp:4;		// Port multiplier port

	u16	prdtl;		// Physical region descriptor table length in entries

	// DWORD 1
	u32	prdbc;		// Physical region descriptor byte count transferred

	// DWORD 2, 3
	u32	ctba;		// Command table descriptor base address
	u32	ctbau;		// Command table descriptor base address upper 32 bits
}cmd_header;

typedef struct CMD_FIS{
	// DWORD 0
	u8	fis_type;	// FIS_TYPE_REG_H2D

	u8	pmp:4;		// Port multiplier
	u8	rsv0:3;		// Reserved
	u8	c:1;		// 1: Command, 0: Control

	u8	cmd;		// Command register
	u8	featurel;	// Feature register, 7:0

	// DWORD 1
	u8	lba0;		// LBA low register, 7:0
	u8	lba1;		// LBA mid register, 15:8
	u8	lba2;		// LBA high register, 23:16
	u8	device;		// Device register

	// DWORD 2
	u8	lba3;		// LBA register, 31:24
	u8	lba4;		// LBA register, 39:32
	u8	lba5;		// LBA register, 47:40
	u8	featureh;	// Feature register, 15:8

	// DWORD 3
	u8	countl;		// Count register, 7:0
	u8	counth;		// Count register, 15:8
	u8	icc;		// Isochronous command completion
	u8	control;	// Control register

	// DWORD 4
	u32	rsv1;	// Reserved
}cmd_fis;

typedef struct PRD_TABLE{
	// DWORD 0
	u32	dba;		// Data base address

	// DWORD 1
	u32	dbau;		// Data base address upper 32 bits

	// DWORD 2
	u32	rsv0;		// Reserved

	// DWORD 3
	u32	dbc:22;		// Byte count, 4M max
	u32	rsv1:9;		// Reserved
	u32	i:1;		// Interrupt on completion
}prd_table;

void sm_host_read32(u64 addr, unsigned int* data){
	*data = *((volatile unsigned int *) addr);
}

void sm_host_write32(u64 addr, unsigned int data){
	*((volatile unsigned int *) addr) = data;
}

u32 sm_sata_write32(u32 addr, u32 data){
	u32 rd_data;
	int verbose = g_verbose_level;

	sm_host_write32(addr, data);
	if(g_verbose_level > 6) {
		sm_host_read32(addr, &rd_data);
		if(data != rd_data){
			printf("\n SATA_WRITE [0x%08x] : [0x%08x] = [0x%08x] --> WARNING", addr, data, rd_data);
			return 1;
		}
		else
			printf("\n SATA_WRITE [0x%08x] : [0x%08x] = [0x%08x]", addr, data, rd_data);
	}
	return 0;
}

u32 sm_sata_read32(u32 addr){
	u32 rd_data;

	sm_host_read32(addr, &rd_data);
	if(g_verbose_level > 6)	lprintf(8, "\n SATA_READ  [0x%08x] : [0x%08x]", addr, rd_data);
	return rd_data;
}

void sm_sata_write64(u64 addr, u32 data){
	u32 rd_data;

	sm_host_write32(addr, data);
	if(g_verbose_level > 8) {
		sm_host_read32(addr, &rd_data);
		if(data != rd_data)
			printf("\n SATA_WRITE [0x%09x] : [0x%08x] = [0x%08x] --> WARNING", addr, data, rd_data);
		else
			printf("\n SATA_WRITE [0x%09x] : [0x%08x] = [0x%08x]", addr, data, rd_data);
	}
}

u32 sm_sata_read64(u64 addr){
	u32 rd_data;

	sm_host_read32(addr, &rd_data);
	if(g_verbose_level > 8)	printf("\n SATA_READ  [0x%09x] : [0x%08x]", addr, rd_data);
	return rd_data;
}

void sm_sata_usdelay(unsigned us){
	USDELAY(us);
}
void sm_sata_msdelay(unsigned ms){
	MSDELAY(ms);
}
void sm_sata_delay(unsigned s){
	int i;
	for(i=0; i<s; ++i) MSDELAY(1000);
}

void kc_sds_wr(u32 csr_base, u32 addr, u32 wr_data){
	u32 cap_value, rb_data;
	int offset, reg_num, timeout;
	u32 data, ind_addr_cmd;
    u32 SDS_IND_CMD_REG, SDS_IND_RDATA_REG, SDS_IND_WDATA_REG;

    data = csr_base & 0xFFFF0000;
    switch(data){
    case 0x1F210000:	// SATA01
    case 0x1F220000:	// SATA23
    case 0x1F230000:	// SATA45
    	SDS_IND_CMD_REG   = SATA_ENET_SDS_IND_CMD_REG__ADDR;
    	SDS_IND_RDATA_REG = SATA_ENET_SDS_IND_RDATA_REG__ADDR;
    	SDS_IND_WDATA_REG = SATA_ENET_SDS_IND_WDATA_REG__ADDR;
    	break;
    case 0x1F2D0000:	// PCIE2
    	SDS_IND_CMD_REG   = PCIE_SDS_IND_CMD_REG__ADDR;
    	SDS_IND_RDATA_REG = PCIE_SDS_IND_RDATA_REG__ADDR;
    	SDS_IND_WDATA_REG = PCIE_SDS_IND_WDATA_REG__ADDR;
    	break;
    default:
    	break;
    }

	offset = addr & 0xFFFF;
 	ind_addr_cmd = addr << 4;	// cfg_ind_addr
 	ind_addr_cmd |= 1 << 2;		// cfg_ind_cmd_done
 	ind_addr_cmd |= 1 << 0;		// cfg_ind_wr_cmd
 	sm_host_write32(csr_base + SDS_IND_WDATA_REG, wr_data);
 	sm_host_write32(csr_base + SDS_IND_CMD_REG, ind_addr_cmd);

 	if(SDS_DUMP || (g_verbose_level > 6)) {
		if(offset >= 0x0600){
			reg_num = (offset - 0x0600) / 2;
			printf("\n Write ch1_rxtx_reg%03d [0x%05X]", reg_num, addr);
		}
		else if(offset >= 0x0400){
			reg_num = (offset - 0x0400) / 2;
			printf("\n Write ch0_rxtx_reg%03d [0x%05X]", reg_num, addr);
		}
		else{
			reg_num = offset / 2;
			printf("\n Write cmu_reg%02d [0x%05X]", reg_num, addr);
		}
		timeout = 100;
		do{
			sm_sata_usdelay(10);
			sm_host_read32(csr_base + SDS_IND_CMD_REG, &cap_value);
		}while(((cap_value & (1 << 2)) == 0) && --timeout);
		if(timeout){
			ind_addr_cmd = addr << 4;	// cfg_ind_addr
			ind_addr_cmd |= 1 << 2;		// cfg_ind_cmd_done
			ind_addr_cmd |= 1 << 1;		// cfg_ind_rd_cmd
			sm_host_write32(csr_base + SDS_IND_CMD_REG, ind_addr_cmd); // Read register
			timeout = 100;
			do{
				sm_sata_usdelay(10);
				sm_host_read32(csr_base + SDS_IND_CMD_REG, &cap_value);
			}while((cap_value & (1 << 2) == 0) && (--timeout));
			if(timeout <= 0)
				printf(" [ERROR]: KC WR FAILED - Read back timeout\n");
			else{
				sm_host_read32(csr_base + SDS_IND_RDATA_REG, &rb_data);
				if(rb_data != wr_data)
					printf(" [WARNING]: KC WR FAILED Wr data = [0x%04X] != RdBk data = [0x%04X]", wr_data, rb_data);
				else{
					printf(" [0x%04X]", rb_data);
				}
			}
		}
		else
			lprintf(7, " [ERROR]: KC WR FAILED - Timeout\n");
 	}
}

u32 kc_sds_rd(u32 csr_base, u32 addr){
    u32 cap_value, offset, reg_num, timeout;
    u32 data, ind_addr_cmd;
    u32 SDS_IND_CMD_REG, SDS_IND_RDATA_REG;

    data = csr_base & 0xFFFF0000;
    switch(data){
    case 0x1f210000:	// SATA01
    case 0x1f220000:	// SATA23
    case 0x1f230000:	// SATA45
    	SDS_IND_CMD_REG   = SATA_ENET_SDS_IND_CMD_REG__ADDR;
    	SDS_IND_RDATA_REG = SATA_ENET_SDS_IND_RDATA_REG__ADDR;
    	break;
    case 0x1f2D0000:	// PCIE2
    	SDS_IND_CMD_REG   = PCIE_SDS_IND_CMD_REG__ADDR;
    	SDS_IND_RDATA_REG = PCIE_SDS_IND_RDATA_REG__ADDR;
    	break;
    default:
    	break;
    }

    offset = addr & 0xFFFF;
    ind_addr_cmd = addr << 4;	// cfg_ind_addr
    ind_addr_cmd |= 1 << 2;		// cfg_ind_cmd_done
    ind_addr_cmd |= 1 << 1;		// cfg_ind_rd_cmd
    sm_host_write32(csr_base + SDS_IND_CMD_REG, ind_addr_cmd); // Read register
    timeout = 100;
    do{
    	sm_sata_usdelay(10);
    	sm_host_read32(csr_base + SDS_IND_CMD_REG, &cap_value);
    }while((cap_value & (1 << 2) == 0) && (--timeout));
    if(timeout) sm_host_read32(csr_base + SDS_IND_RDATA_REG, &data);

 	if(SDS_DUMP || (g_verbose_level > 6)) {
		if(offset >= 0x0600){
			reg_num = (offset - 0x0600) / 2;
			printf("\n Read  ch1_rxtx_reg%03d [0x%05X]", reg_num, addr);
		}
		else if(offset >= 0x0400){
			reg_num = (offset - 0x0400) / 2;
			printf("\n Read  ch0_rxtx_reg%03d [0x%05X]", reg_num, addr);
		}
		else{
			reg_num = offset / 2;
			printf("\n Read  cmu_reg%02d [0x%05X]", reg_num, addr);
		}

		if(timeout)
			printf(" [0x%04X]", data);
		else
			printf(" [ERROR]: KC RD FAILED - Timeout");
 	}
    return data;
}

int sm_sata_sds_rst(int port){
	u32 sata_csr_base = sm_sata_get_csr_base(port);
	u32 addr, data;

	lprintf(6, "\n##### sm_sata_sds_rst #####");
	lprintf(6, "\n KOOLCHIP SERDES RESET .......");
	lprintf(7, "\n SATA_ENET_SDS_RST_CTL [15:0]");
	addr = sata_csr_base + SATA_ENET_SDS_RST_CTL__ADDR;
	sm_sata_write32(addr, 0);
	sm_sata_usdelay(10);			// Allow IP to get reflected
	sm_sata_write32(addr, 0x20);	// Serdes main reset
	sm_sata_write32(addr, 0xDE);	// Release all reset, but main reset
	sm_sata_msdelay(1);
	sm_host_read32(addr, &data);
	if(data != 0xDE)
		return -1;
	else
		lprintf(5, "\n\t SERDES in reset");
	return 0;
}

int sm_sata_sds_ena(int port){
	int reg_offset;
	u32 sata_csr_base = sm_sata_get_csr_base(port);
	u32 addr, data;

	lprintf(6, "\n##### sm_sata_sds_ena #####");
	lprintf(6, "\n KOOLCHIP SERDES ENABLE .......");
	lprintf(7, "\n SATA_ENET_SDS_RST_CTL [15:0]");
	addr = sata_csr_base + SATA_ENET_SDS_RST_CTL__ADDR;
    sm_sata_write32(addr, 0x000000DF);
    sm_sata_msdelay(1);
	sm_host_read32(addr, &data);
	if(data != 0xDF)
		return -1;
	else
		lprintf(5, "\n\t SERDES out of reset");
	return 0;
}

void sm_sata_mdio_debug_en(void){
	u32 data = 0x001E1E1E;

	lprintf(6, "\n##### sm_sata_mdio_debug_en #####");
    sm_sata_write32(0x17001398, data);		// connect to MDIO
    lprintf(4, "\n MPA_MDIO_IOCTL [15:0] = 0x%08x", sm_sata_read32(0x17001398));
}

void sm_sata_rxwclk_inv(int port){
	int i;
	u32 reg_base = CH0_RXTX_REG_OFFSET;
	u32 reg_offset, data32;
	u32 sata_csr_base = sm_sata_get_csr_base(port);

	lprintf(6, "\n##### sm_sata_rxwclk_inv #####");
	for(i=0; i<2; ++i){
		reg_offset = reg_base + i*0x0200 + RXTX_REG13*2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 |= 1 << 13;
		kc_sds_wr(sata_csr_base, reg_offset, data32);
	}
}

void sm_sata_ctle_rd(int port){
	int i, j;
    int reg_base, reg_offset;
    u32 data32;
    u32 sata_csr_base = sm_sata_get_csr_base(port);

    reg_base = (port%2) ? CH1_RXTX_REG_OFFSET : CH0_RXTX_REG_OFFSET;

	/*
	 * XRTX_REG147 NEEDED TO BE EXECUTED BEFORE WRITING TO RXTX_REG1
	 * rxtx_reg1[15:12]  rxacvcm
	 * rxtx_reg1[11:7]   CTLE_EQ
	 *      CTLE A2     = <0x2 0x2 0x2 0x2 0x2 0x2>;
	 *      CTLE A3     = <0x1e 0x1e 0x19 0x1e 0x1e 0x19>;
	 *      CTLE SSD A3 = <0x2 0x2 0x19 0x2 0x2 0x19>;
	 */
	reg_offset = reg_base + RXTX_REG1 * 2;
	data32 = kc_sds_rd(sata_csr_base, reg_offset);
	data32 &= (0x1F << 7);
	data32 >>= 7;
	printf("\n CTLE EQ_%d = 0x%02X\n", port, data32);
}
void sm_sata_ctle_wr(int port, int value){
	int i, j;
    int reg_base, reg_offset;
    u32 data32;
    u32 sata_csr_base = sm_sata_get_csr_base(port);

    reg_base = (port%2) ? CH1_RXTX_REG_OFFSET : CH0_RXTX_REG_OFFSET;

	/*
	 * XRTX_REG147 NEEDED TO BE EXECUTED BEFORE WRITING TO RXTX_REG1
	 * rxtx_reg1[15:12]  rxacvcm
	 * rxtx_reg1[11:7]   CTLE_EQ
	 *      CTLE A2     = <0x2 0x2 0x2 0x2 0x2 0x2>;
	 *      CTLE A3     = <0x1e 0x1e 0x19 0x1e 0x1e 0x19>;
	 *      CTLE SSD A3 = <0x2 0x2 0x19 0x2 0x2 0x19>;
	 */
	reg_offset = reg_base + RXTX_REG1 * 2;
	data32 = kc_sds_rd(sata_csr_base, reg_offset);
	data32 &= ~(0x1F << 7);
	data32 |= value << 7;
	kc_sds_wr(sata_csr_base, reg_offset, data32);
}
void sm_sata_pq_rd(int port){
	int i, j;
    int reg_base, reg_offset;
    u32 data32;
    u32 sata_csr_base = sm_sata_get_csr_base(port);

    reg_base = (port%2) ? CH1_RXTX_REG_OFFSET : CH0_RXTX_REG_OFFSET;

	/*
	 * rxtx_reg125[15:9] pq_reg
	 */
	reg_offset = reg_base + RXTX_REG125 * 2;
	data32 = kc_sds_rd(sata_csr_base, reg_offset);
	data32 &= (0x7F << 9);
	data32 >>= 9;
	printf("\n PQ_REG_%d = 0x%02X\n", port, data32);
}
void sm_sata_pq_wr(int port, int value){
	int i, j;
    int reg_base, reg_offset;
    u32 data32;
    u32 sata_csr_base = sm_sata_get_csr_base(port);

    reg_base = (port%2) ? CH1_RXTX_REG_OFFSET : CH0_RXTX_REG_OFFSET;

	/*
	 * rxtx_reg125[15:9] pq_reg
	 */
	reg_offset = reg_base + RXTX_REG125 * 2;
	data32 = kc_sds_rd(sata_csr_base, reg_offset);
	data32 &= ~(0x7F << 9);
	data32 |= value << 9;
	kc_sds_wr(sata_csr_base, reg_offset, data32);
}

/*
 * Config Koolchip SERDES
 * based on the KC spreadsheet
 */
void sm_sata_sds_irst_cfg(int port){
	int i, j;
    int reg_base, reg_offset;
    u32 data32, data0, data1;
    u32 sata_csr_base = sm_sata_get_csr_base(port);

    lprintf(6, "\n##### sm_sata_sds_irst_cfg #####");
	/*
	 * CMU_reg12[7:4]  State_delay9
	 */
	reg_offset = CMU_REG12 * 2;
	data32 = kc_sds_rd(sata_csr_base, reg_offset);
	data32 &= ~(0xF << 4);
	data32 |= 0x1 << 4;
	kc_sds_wr(sata_csr_base, reg_offset, data32);

	/*
	 * CMU_REG13[15:12]  State_delay1
	 * CMU_REG13[11:8]   State_delay2
	 * CMU_REG13[7:4]    State_delay3
	 * CMU_REG13[3:0]    State_delay4
	 */
	reg_offset = CMU_REG13 * 2;
	data32 = CMU_REG13__VALUE;
	kc_sds_wr(sata_csr_base, reg_offset, data32);

	/*
	 * CMU_REG14[15:12]  State_delay5
	 * CMU_REG14[11:8]   State_delay6
	 * CMU_REG14[7:4]    State_delay7
	 * CMU_REG14[3:0]    State_delay8
	 */
	reg_offset = CMU_REG14 * 2;
	data32 = 0x2225;
	kc_sds_wr(sata_csr_base, reg_offset, data32);

	lprintf(6, "\n Selecting Reference Clock for SATA Controller %d ... ", port/2);
	/*
	 * CMU_REG0[13] pll_ref_sel
	 * CMU_REG1[0]  refclk_cmos_sel
	 *
	 * External Clock CML for SATA 0-5
	 * Internal Clock CML for SATA 0-3
	 * Internal Clock CMOS for SATA 0-5
	 */
	data0 = kc_sds_rd(sata_csr_base, CMU_REG0 * 2);
	data1 = kc_sds_rd(sata_csr_base, CMU_REG1 * 2);
	if(CLK_REF){			// Internal Clock
		if(CLK_TYPE){			// CMOS
			data0 &= ~(0x1 << 13);
			data1 |= 0x1;
			lprintf(3, "\n\t Reference Clock: Internal CMOS selected");
		}
		else{					// CML
			data0 |= 0x1 << 13;
			data1 &= ~(0x1);
			lprintf(3, "\n\t Reference Clock: Internal CML selected");
		}
	}
	else{					// External Clock - CML
		data0 &= ~(0x1 << 13);
		data1 &= ~(0x1);
		lprintf(3, "\n\t Reference Clock: External CML selected");
	}
	kc_sds_wr(sata_csr_base, CMU_REG0 * 2, data0);
	kc_sds_wr(sata_csr_base, CMU_REG1 * 2, data1);

//	sm_sata_rxwclk_inv(port);

	lprintf(6, "\n Writing to CMU ...");
    /*
     * CMU_reg0[7:5]  cal_count_resol
     */
    reg_offset = CMU_REG0 * 2;
    data32 = kc_sds_rd(sata_csr_base, reg_offset);
	data32 &= ~(0x7 << 5);
#ifdef A2
	data32 |= 0x4 << 5;
#else
	data32 |= 0x7 << 5;
#endif
    kc_sds_wr(sata_csr_base, reg_offset, data32);

	/*
	 * CMU_reg1[13:10]  pll_cp
	 * CMU_reg1[9:5]    pll_cp_sel
	 * CMU_reg1[3]      pll_manualcal
	 */
    reg_offset = CMU_REG1 * 2;
    data32 = kc_sds_rd(sata_csr_base, reg_offset);
	data32 &= ~(0xF << 10);
	data32 &= ~(0x1F << 5);
	data32 |= 0x1 << 10;
#ifdef A2
	data32 |= 0x5 << 5;
#else
	data32 |= 0x3 << 5;
#endif
    kc_sds_wr(sata_csr_base, reg_offset, data32);

#ifndef A2
    /* This code to fix vco calibration failure */
	reg_offset = CMU_REG5 * 2;
	data32 = kc_sds_rd(sata_csr_base, reg_offset);
	data32 &= ~(0x1);	// CMU_reg5[0]: pll_resetb
	kc_sds_wr(sata_csr_base, reg_offset, data32);

	reg_offset = CMU_REG1 * 2;
	data32 = kc_sds_rd(sata_csr_base, reg_offset);
	data32 |= 0x1 << 3;	//CMU_reg1[3]: pll_manualcal
	kc_sds_wr(sata_csr_base, reg_offset, data32);
#endif

	/*
	 * CMU_REG2[15:14]  pll_refdiv
	 * CMU_REG2[13:5]   pll_fbdiv
	 * CMU_REG2[4:1]    pll_lfres
	 */
    reg_offset = CMU_REG2 * 2;
    data32 = kc_sds_rd(sata_csr_base, reg_offset);
	data32 &= ~(3 << 14);
	data32 &= ~(0x1FF << 5);
	data32 &= ~(0xF << 1);
	if(CLK_FREQ == 2) {			// 25MHz
		data32 |= 0x2 << 14;
		data32 |= 0xEF << 5;
	}else if(CLK_FREQ == 1) {	// 50MHz
		data32 |= 0x1 << 14;
		data32 |= 0x77 << 5;
	}else {						// 100MHz
		data32 |= 0x0 << 14;
		data32 |= 0x3B << 5;
	}
#ifdef A2
	data32 |= 0xA << 1;
#else
	data32 |= 0x3 << 1;
#endif
    kc_sds_wr(sata_csr_base, reg_offset, data32);

	/*
	 * CMU_REG3[15:10]  vco_manmomsel
	 * CMU_REG3[9:4]    vco_momsel_init
	 * CMU_REG3[3:0]    vcovarsel
	 */
    reg_offset = CMU_REG3 * 2;
    data32 = kc_sds_rd(sata_csr_base, reg_offset);
	data32 &= ~(0x3F << 10);
	data32 &= ~(0x3F << 4);
	data32 &= ~(0xF);
	data32 |= CMU_REG3_VCO_MANMOMSEL << 10;
	data32 |= CMU_REG3_VCO_MOMSEL_INIT << 4;
	data32 |= 0xF;
    kc_sds_wr(sata_csr_base, reg_offset, data32);
	
	/*
	 * CMU_REG26[0:0] = 0  force_pll_lock
	 */
	reg_offset = CMU_REG26 * 2;
	data32 = kc_sds_rd(sata_csr_base, reg_offset);
	data32 &= ~(0x1);
	data32 |= CMU_REG26_FORCE_PLL_LOCK;
	kc_sds_wr(sata_csr_base, reg_offset, data32);

#ifndef A2
#ifndef A3
	/*
	 * CMU_REG27[15:13] ref_volt_sel_ch0
	 * CMU_REG27[12:10] ref_volt_sel_ch1
	 */
	reg_offset = CMU_REG27 * 2;
	data32 = kc_sds_rd(sata_csr_base, reg_offset);
	data32 &= ~(0x7 << 13);
	data32 &= ~(0x7 << 10);
	data32 |= 1 << 13;
	data32 |= 1 << 10;
	kc_sds_wr(sata_csr_base, reg_offset, data32);

	/*
	 * CMU_REG31[3:3] los_override_ch0
	 * CMU_REG31[2:2] los_override_ch1
	 */
	reg_offset = CMU_REG31 * 2;
	data32 = kc_sds_rd(sata_csr_base, reg_offset);
	data32 |= 1 << 3;
	data32 |= 1 << 2;
	kc_sds_wr(sata_csr_base, reg_offset, data32);
#endif
#endif

	/*
	 * CMU_REG5[15:14] = 00   pll_lfsmcap
	 * CMU_REG5[13:12] = 00   pll_lfcap
	 * CMU_REG5[3:1]   = 000  pll_lock_resolution
	 */
    reg_offset = CMU_REG5 * 2;
    data32 = kc_sds_rd(sata_csr_base, reg_offset);
	data32 &= ~(0x3 << 14);
	data32 &= ~(0x3 << 12);
	data32 &= ~(0x7 << 1);
	data32 |= 0x3 << 14;
	data32 |= 0x3 << 12;
	data32 |= 0x7 << 1;
    kc_sds_wr(sata_csr_base, reg_offset, data32);

	/*
	 * CMU_REG6[10:9]  pll_vregtrim
	 * CMU_REG6[2]     man_pvt_cal
	 */
    reg_offset = CMU_REG6 * 2;
    data32 = kc_sds_rd(sata_csr_base, reg_offset);
	data32 &= ~(0x3 << 9);
	data32 &= ~(0x1 << 2);
#ifdef A2
	data32 |= 0x0 << 9;
	data32 |= 0x1 << 2;
#else
	data32 |= 0x2 << 9;
	data32 |= 0x0 << 2;
#endif
    kc_sds_wr(sata_csr_base, reg_offset, data32);

	/*
	 * CMU_REG9[9:7]  tx_word_mode_ch1
	 * CMU_REG9[6:4]  tx_word_mode_ch0
	 * CMU_REG9[3]    pll_post_divby2
	 * CMU_REG9[2]    vbg_bypassb
	 * CMU_REG9[1]    igen_bypass
	 */
    reg_offset = CMU_REG9 * 2;
    data32 = kc_sds_rd(sata_csr_base, reg_offset);
//	data32 &= ~(0x7 << 7);		// can't access
//	data32 &= ~(0x7 << 4);		// can't access
//	data32 |= 0x3 << 7;
//	data32 |= 0x3 << 4;
	data32 |= 0x1 << 3;
#ifndef A2
	data32 &= ~(0x1 << 2);
#endif
    kc_sds_wr(sata_csr_base, reg_offset, data32);

	/*
	 * CMU_REG10[0]    vreg_refsel
	 */
	reg_offset = CMU_REG10 * 2;
	data32 = kc_sds_rd(sata_csr_base, reg_offset);
	data32 &= ~(0x1);
	data32 |= CMU_REG10_VREG_REFSEL;
	kc_sds_wr(sata_csr_base, reg_offset, data32);

	/*
	 * CMU_REG16[6]    bypass_pll_lock
	 * CMU_REG16[5]    calibration_done_override
	 * CMU_REG16[4:2]  vcocal_wait_btw_code
	 */
    reg_offset = CMU_REG16 * 2;
    data32 = kc_sds_rd(sata_csr_base, reg_offset);
    data32 &= ~(0x7 << 2);
	data32 |= 0x1 << 6;
	data32 |= 0x1 << 5;
#ifdef A2
	data32 |= 0x4 << 2;
#else
	data32 |= 0x7 << 2;
#endif
	kc_sds_wr(sata_csr_base, reg_offset, data32);

	/*
	 * CMU_REG30[3]    pcie_mode
	 * CMU_REG30[2:1]  lock_count[1:0]
	 */
    reg_offset = CMU_REG30 * 2;
    data32 = kc_sds_rd(sata_csr_base, reg_offset);
	data32 &= ~(0x1 << 3);
	data32 &= ~(0x3 << 1);
	data32 |= 0x3 << 1;
    kc_sds_wr(sata_csr_base, reg_offset, data32);

	/*
	 * CMU_REG31[3:0]  los_override_ch0..ch3
	 */
    reg_offset = CMU_REG31 * 2;
	data32 = 0xF;
    kc_sds_wr(sata_csr_base, reg_offset, data32);

	/*
	 * CMU_REG32[8:7]  iref_adj[1:0]
	 * CMU_REG32[2:1]  pvt_cal_wait_sel[1:0]
	 */
    reg_offset = CMU_REG32 * 2;
    data32 = kc_sds_rd(sata_csr_base, reg_offset);
    data32 &= ~(0x3 << 7);
    data32 &= ~(0x3 << 1);
    data32 |= CMU_REG32_IREF_ADJ << 7;
	data32 |= 0x3 << 1;
	kc_sds_wr(sata_csr_base, reg_offset, data32);

	/*
	 * CMU_REG34[15:12] = 0010	vco_cal_vth_hi_min[3:0]
	 * CMU_REG34[11:8]  = 1010  vco_cal_vth_hi_max[3:0]
	 * CMU_REG34[7:4]   = 0010  vco_cal_vth_lo_min[3:0]
	 * CMU_REG34[3:0]   = 1010  vco_cal_vth_lo_max[3:0]
	 */
    reg_offset = CMU_REG34 * 2;
#ifdef A2
    data32 = 0x8C37;
#else
    data32 = 0x8967;
#endif
#ifdef A3
    data32 = 0x8C37;
#endif
    kc_sds_wr(sata_csr_base, reg_offset, data32);

	/*
	 * CMU_REG37[15:12] = 1111  CTLE_cal_done_ovr[3:0]
	 * CMU_REG37[11:8]  = 1111  Latch_cal_done_ovr[3:0]
	 * CMU_REG37[7:4]   = 1111  Summer_off_cal_done_ovr[3:0]
	 * CMU_REG37[3:0]   = 1111  FT_search_done_ovr[3:0]
	 */
    reg_offset = CMU_REG37 * 2;
	data32 = 0xF00F;
    kc_sds_wr(sata_csr_base, reg_offset, data32);

	// for SpreadSpectrum Clock enable (SSC)
	if(SSC_EN){
		lprintf(4, "\n\t Spread Spectrum Clock Enabled");
		data32 = kc_sds_rd(sata_csr_base, CMU_REG35*2);
		data32 &= ~(0x7F << 9);
		data32 |= PLL_SSC_MOD << 9;
		kc_sds_wr(sata_csr_base, CMU_REG35*2, data32);

		data32 = kc_sds_rd(sata_csr_base, CMU_REG36*2);
		data32 &= ~(0x3FF << 6);
		data32 |= PLL_SSC_VSTEP << 6;
		data32 |= 0x1 << 5;
		data32 |= 0x1 << 4;
		kc_sds_wr(sata_csr_base, CMU_REG36*2, data32);

		data32 = kc_sds_rd(sata_csr_base, CMU_REG5*2);
		data32 &= ~(0x1);		// [0] - pll_resetb: PLL reset to reset VCOCAL, PVT cal and PLL
		kc_sds_wr(sata_csr_base, CMU_REG5*2, data32);
		sm_sata_msdelay(1);		// Allow Serdes to get reflected
		data32 = kc_sds_rd(sata_csr_base, CMU_REG5*2);
		data32 |= 0x1;			// disable PLL reset
		kc_sds_wr(sata_csr_base, CMU_REG5*2, data32);

		// toggle
		data32 = kc_sds_rd(sata_csr_base, CMU_REG32*2);
		data32 |= 0x1 << 14;	// [14] - force_vcocal_start: force VCO calibration re-start
		kc_sds_wr(sata_csr_base, CMU_REG32*2, data32);
		data32 &= ~(0x1 << 14);
		kc_sds_wr(sata_csr_base, CMU_REG32*2, data32);
	}

    lprintf(6, "\n Writing to RXTX ...");
	for(j=0; j<2; ++j){		// channel 0 - 1
		reg_base = (j == 0) ? CH0_RXTX_REG_OFFSET : CH1_RXTX_REG_OFFSET;

		/*
		 * rxtx_reg147[15:0] = 1    STMC_OVERRIDE[15:0]
		 *
		 * rxtx_reg147[15:0] = 0x6 Anil@KC changed 31/1/2013
		 */
		/* NEEDED TO BE BEFORE WRITING TO RXTX_REG1 */
		reg_offset = reg_base + RXTX_REG147 * 2;
		data32 = 0x6;
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		/*
		 * rxtx_reg0[15:11]  CTLE_EQ_HR
		 * rxtx_reg0[10:6]   CTLE_EQ_QR
		 * rxtx_reg0[5:1]    CTLE_EQ_FR
		 */
		reg_offset = reg_base + RXTX_REG0 * 2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(0x1F << 11);
		data32 &= ~(0x1F << 6);
		data32 &= ~(0x1F << 1);
		data32 |= CTLE_EQ_HR << 11;
		data32 |= CTLE_EQ_QR << 6;
		data32 |= CTLE_EQ_FR << 1;
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		/*
		 * XRTX_REG147 NEEDED TO BE EXECUTED BEFORE WRITING TO RXTX_REG1
		 * rxtx_reg1[15:12]	rxacvcm
		 * rxtx_reg1[11:7]	CTLE_EQ
		 * rxtx_reg1[6:5]	rxvreg1
		 * rxtx_reg1[2:1]	rxiref_adj
		 */
		reg_offset = reg_base + RXTX_REG1 * 2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(0xF << 12);
		data32 |= 0x7 << 12;
		data32 &= ~(0x1F << 7);
#ifdef TUNING
		i = port - (port%2) + j;
		switch(i){
		case 0:
			data32 |= CTLE_EQ_0 << 7;
			break;
		case 1:
			data32 |= CTLE_EQ_1 << 7;
			break;
		case 2:
			data32 |= CTLE_EQ_2 << 7;
			break;
		case 3:
			data32 |= CTLE_EQ_3 << 7;
			break;
		case 4:
			data32 |= CTLE_EQ_4 << 7;
			break;
		case 5:
			data32 |= CTLE_EQ_5 << 7;
			break;
		default:
			break;
		}
#else
		data32 |= CTLE_EQ << 7;
#endif
#ifndef A2
#ifndef A3
		data32 &= ~(0x3 << 5);
		data32 |= RXTX_REG1_RXVREG1 << 5;
		data32 &= ~(0x3 << 3);
		data32 |= RXTX_REG1_RXVREG1P2 << 3;
		data32 &= ~(0x3 << 1);
		data32 |= RXTX_REG1_RXIREF_ADJ << 1;
#endif
#endif
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		/*
		 * rxtx_reg2[8]    vtt_ena
		 * rxtx_reg2[7:6]  vtt_sel
		 * rxtx_reg2[5]    tx_fifo_ena
		 */
		reg_offset = reg_base + RXTX_REG2 * 2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(0x3 << 6);
		data32 |= 0x1 << 8;
		data32 |= 0x1 << 6;
		data32 |= 0x1 << 5;
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		/*
		 * rxtx_reg4[15:14] = 2 for GEN 1 (Quarter rate)
		 * 					= 1 for GEN 2 (Half rate)
		 * 					= 0 for GEN 3 (Full rate)
		 * rxtx_reg4[13:11] = 3 TX Word modes
		 * rxtx_reg4[10:8]  = 4 TX_PRBS_sel (default)
		 * rxtx_reg4[6]  	= 0 tx_loopback_buf_en
		 */
//		reg_offset = reg_base + RXTX_REG4 * 2;
//		data32 = kc_sds_rd(sata_csr_base, reg_offset);
//		data32 &= ~(0x7 << 11);		// can't access, customer pin mode bit [0] = 1
//		data32 |= 0x3 << 11;
//		kc_sds_wr(sata_csr_base, reg_offset, data32);

		/*
		 * rxtx_reg5[15:11]  tx_cn1
		 * rxtx_reg5[10:5]   tx_cp1
		 * rxtx_reg5[4:0]    tx_cn2
		 */
		reg_offset = reg_base + RXTX_REG5 * 2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(0x1F << 11); 	// Mask [15:11] = 0 0000
		data32 &= ~(0x3F << 5); 	// Mask [10:5] = 00 0000
		data32 &= ~(0x1F << 0); 	// Mask [4:0] = 0 0000
		data32 |= RXTX_REG5_TX_CN1 << 11;
		data32 |= RXTX_REG5_TX_CP1 << 5;
		data32 |= RXTX_REG5_TX_CN2 << 0;
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		/*
		 * rxtx_reg6[14]    tx_cn2_inv
		 * rxtx_reg6[10:7]  txamp_cntl
		 * rxtx_reg6[6]     txamp_ena
		 * rxtx_reg6[3]     tx_idle
		 * rxtx_reg6[1]     rx_bist_resync
		 * rxtx_reg6[0]     rx_bist_errcnt_rd
		 */
		reg_offset = reg_base + RXTX_REG6 * 2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(0x1 << 14);
		data32 &= ~(0xF << 7);
		data32 &= ~(0x1 << 6);
//		data32 &= ~(0x1 << 3);	// can't access, customer pin mode bit [5] = 1
		data32 &= ~(0x1 << 1);
		data32 &= ~(0x1);
		data32 |= RXTX_REG6_TX_CN2_INV << 14;
		data32 |= RXTX_REG6_TXAMP_CNTL << 7;
		data32 |= RXTX_REG6_TXAMP_ENA << 6;
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		/*
		 * rxtx_reg7[13:11]  RX_word_mode[2:0] (can't write)
		 *
		 * RX Rate divider select
		 * rxtx_reg7[10:9] 	= 2 for GEN 1 (Quarter rate)
		 * 					= 1 for GEN 2 (Half rate)
		 * 					= 0 for GEN 3 (Full rate)
		 *
		 * rxtx_reg7[8]  resetb_rxd
		 * rxtx_reg7[7]  resetb_rxa
		 * rxtx_reg7[6]  bist_ena_rx
		 *
		 * RX Word modes select (20bit)
		 * rxtx_reg7[5:3]  	= 4 RX_PRBS_sel[2:0]
		 */
		reg_offset = reg_base + RXTX_REG7 * 2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
//		data32 &= ~(0x7 << 11);		// can't access, customer pin mode bit [0] = 1
//		data32 |= 0x3 << 11;
		data32 &= ~(0x1 << 6);
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		/*
		 * rxtx_reg8[14]   CDR_Loop_ena
		 * rxtx_reg8[11]   CDR_bypass_rxlos
		 * rxtx_reg8[9]    SSC_enable: Used for SSC 5000PPM support
		 * rxtx_reg8[8]    sd_disable: Los logic enable => set to 0 sata working => Tao changed 31/1/2013
		 * rxtx_reg8[7:4]  sd_vref
		 */
		reg_offset = reg_base + RXTX_REG8 * 2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(0x1 << 11);
		data32 &= ~(0x1 << 8);
		data32 &= ~(0xF << 4);
		data32 |= 0x1 << 14;
		data32 |= 0x1 << 9;
		//data32 |= RXTX_REG8_SD_VREF << 4;
		data32 |= 0x6<< 4;//mle@apm.com Updated RXTX_REG8_SD_VREF =0x4-->0x6 from SERDES SOC
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		/*
		 * rxtx_reg11[15:11]  phase_adjust_limit
		 */
		reg_offset = reg_base + RXTX_REG11 * 2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(0x1F << 11);
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		/*
		 * rxtx_reg12[13] = 1  Latch_off_ena
		 * rxtx_reg12[11] = 0  rx_inv
		 * rxtx_reg12[2]  = 0  sumos_enable
		 * rxtx_reg12[1]  = 0  rx_det_term_enable
		 */
		reg_offset = reg_base + RXTX_REG12 * 2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 |= 0x1 << 13;
		data32 &= ~(0x1 << 2);
		data32 &= ~(0x1 << 1);
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		/*
		 * rxtx_reg26[13:11]  period_error_latch
		 * rxtx_reg26[3]      blwc_ena
		 */
		reg_offset = reg_base + RXTX_REG26 * 2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(0x7 << 11);
		data32 |= 0x1 << 3;
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		/*
		 * rxtx_reg28[15:0]  DFE_tap_ena
		 */
		reg_offset = reg_base + RXTX_REG28 * 2;
		data32 = 0x0;
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		/*
		 * rxtx_reg31[15:9]  DFE_Preset_value_h0
		 * rxtx_reg31[7:1]   DFE_Preset_value_h1
		 */
		reg_offset = reg_base + RXTX_REG31 * 2;
		data32 = 0x0;
		kc_sds_wr(sata_csr_base, reg_offset, data32);

#ifdef A2
		/* rxtx_reg39-55 */
		for(i=0; i<17; ++i){
			reg_offset = reg_base + RXTX_REG39*2 + i*2;
			data32 = 0;
			kc_sds_wr(sata_csr_base, reg_offset, data32);
		}
#endif

		/*
		 * Speed Select for Different data32 Standards.
		 * rxtx_reg61[13:10]  SPD_sel_cdr
		 * rxtx_reg61[7:6]    eye_count_width_sel
		 * rxtx_reg61[4]      iscan_inbert
		 * rxtx_reg61[3]      LoadFreq_shift
		 */
		reg_offset = reg_base + RXTX_REG61 * 2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
#ifdef A2
		data32 &= ~(0xF << 10);		// Mask [7:6]   = 0000
#else
		data32 &= ~(3 << 6);		// Mask [7:6]   = 0000
		data32 |= 1 << 4;
		data32 &= ~(1 << 3); 		// Mask [3] = 0
#endif
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		/*
		 * Speed Select for Different Data Standards.
		 * rxtx_reg62[13:11] = 0 period_h1_qlatch
		 */
		reg_offset = reg_base + RXTX_REG62 * 2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(0x7 << 11);
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		/*
		 * rxtx_reg81-89[15:11] = 0xE
		 * rxtx_reg81-89[10:6] 	= 0xE
		 * rxtx_reg81-89[5:1] 	= 0xE
		 */
		for(i=0; i<9; i++) {
			reg_offset = reg_base + RXTX_REG81*2 + i*2;
			data32 = kc_sds_rd(sata_csr_base, reg_offset);
			data32 &= ~(0x1F << 11); 	// Mask [15:11] = 0 0000
			data32 &= ~(0x1F << 6); 	// Mask [10:6]  = 0 0000
			data32 &= ~(0x1F << 1); 	// Mask [5:1]   = 0 0000
			data32 |= 0xE << 11;
			data32 |= 0xE << 6;
			data32 |= 0xE << 1;
			kc_sds_wr(sata_csr_base, reg_offset, data32);
		}

		/*
		 * rxtx_reg96-98[15:11] = 0x10
		 * rxtx_reg96-98[10:6]	= 0x10
		 * rxtx_reg96-98[5:1] 	= 0x10
		 */
		for(i=0; i<3; i++) {
			reg_offset = reg_base + RXTX_REG96*2 + i*2;
			data32 = kc_sds_rd(sata_csr_base, reg_offset);
			data32 &= ~(0x1F << 11); 	// Mask [15:11] = 0 0000
			data32 &= ~(0x1F << 6); 	// Mask [10:6]  = 0 0000
			data32 &= ~(0x1F << 1); 	// Mask [5:1]   = 0 0000
			data32 |= 0x10 << 11;
			data32 |= 0x10 << 6;
			data32 |= 0x10 << 1;
			kc_sds_wr(sata_csr_base, reg_offset, data32);
		}

		/*
		 * rxtx_reg99-101[15:11] = 0x7
		 * rxtx_reg99-101[10:6]	 = 0x7
		 * rxtx_reg99-101[5:1] 	 = 0x7
		 */
		for (i = 0; i < 3; i++) {
			reg_offset = reg_base + RXTX_REG99*2 + i*2;
			data32 = kc_sds_rd(sata_csr_base, reg_offset);
			data32 &= ~(0x1F << 11); 	// Mask [15:11] = 0 0000
			data32 &= ~(0x1F << 6); 	// Mask [10:6]  = 0 0000
			data32 &= ~(0x1F << 1); 	// Mask [5:1]   = 0 0000
			data32 |= 7 << 11;
			data32 |= 7 << 6;
			data32 |= 7 << 1;
			kc_sds_wr(sata_csr_base, reg_offset, data32);
		}

		/*
		 * rxtx_reg102[6:5]  freqloop_limit
		 */
		reg_offset = reg_base + RXTX_REG102*2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(0x3 << 5); 	// Mask [6:5] = 00
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		/*
		 * rxtx_reg114[14:5]
		 */
		reg_offset = reg_base + RXTX_REG114*2;
		data32 = 0xFFE0;
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		/*
		 * rxtx_reg125[15:9] pq_reg
		 * rxtx_reg125[8]    sign_pq
		 *
		 * Manual phase program mode
		 * rxtx_reg125[1] = 1  phz_manual
		 */
		reg_offset = reg_base + RXTX_REG125*2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(0x7F << 9);
		if(PLL_GEN == 1)
			data32 |= 0x3 << 9;
		else if(PLL_GEN == 2)
			data32 |= 0x5 << 9;
		else	// auto or gen3
			data32 |= PQ_REG << 9;
		data32 &= ~(1 << 8);
		data32 |= 1 << 1;
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		/*
		 * rxtx_reg127[3] = 0 latch_man_cal_ena
		 */
		reg_offset = reg_base + RXTX_REG127*2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(1 << 3); 	/* Mask [3] = 0 */
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		/*
		 * rxtx_reg128[3:2]  latch_cal_wait_sel[1:0]
		 */
		reg_offset = reg_base + RXTX_REG128*2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 |= 3 << 2;
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		/*
		 * rxtx_reg145[15:14] 	= 3   rxdfe_config[1:0]
		 * rxtx_reg145[2]		= 1   rxes_ena
		 * rxtx_reg145[1]		= 1	  rxvwes_latena
		 * rxtx_reg145[0] 		= 0   tx_idle_sata
		 */
		reg_offset = reg_base + RXTX_REG145*2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 |= 3 << 14;
#ifdef A3
		data32 &= ~(1 << 2);
		data32 &= ~(1 << 1);
#else
		data32 |= 1 << 2;
		data32 |= 1 << 1;
#endif		
		data32 &= ~(1 << 0);		/* Mask [0] 	= 0 */
		kc_sds_wr(sata_csr_base, reg_offset, data32);

#ifdef A3
		/*
		 * rxtx_reg148-151[15:0] = 0xFFFF
		 */
		for (i = 0; i < 4; i++){
			reg_offset = reg_base + RXTX_REG148*2 + i*2;
			data32 = 0xFFFF;
			kc_sds_wr(sata_csr_base, reg_offset, data32);
		}
#endif
	}
}

void sm_sata_ssd_force_calib(int port){
	int i;
    int reg_base = CH0_RXTX_REG_OFFSET + (port%2)*0x0200;
	u32 sata_csr_base = sm_sata_get_csr_base(port);
	u32 data32, reg_offset;

	// Summer Calib
	// toggle
	reg_offset = reg_base + RXTX_REG127*2;
	data32 = kc_sds_rd(sata_csr_base, reg_offset);
	// [1] force_sum_cal_start: Manual start the calibration
	data32 |= 1 << 1;
	kc_sds_wr(sata_csr_base, reg_offset, data32);
	sm_sata_msdelay(1);
	data32 = kc_sds_rd(sata_csr_base, reg_offset);
	data32 &= ~(1 << 1);
	kc_sds_wr(sata_csr_base, reg_offset, data32);
	sm_sata_msdelay(10);

	// Latch calib
	// toggle
	reg_offset = reg_base + RXTX_REG127*2;
	data32 = kc_sds_rd(sata_csr_base, reg_offset);
	// [2] force_lat_cal_start: Manual start the calibration
	data32 |= 1 << 2;
	kc_sds_wr(sata_csr_base, reg_offset, data32);
	sm_sata_msdelay(1);
	data32 = kc_sds_rd(sata_csr_base, reg_offset);
	data32 &= ~(1 << 2);
	kc_sds_wr(sata_csr_base, reg_offset, data32);

//	reg_offset = reg_base + RXTX_REG28*2;
//	//data32 = kc_sds_rd(sata_csr_base, reg_offset);
//	data32 = 0x7;
//	kc_sds_wr(sata_csr_base, reg_offset, data32);
//
//	reg_offset = reg_base + RXTX_REG31*2;
//	//data32 = kc_sds_rd(sata_csr_base, reg_offset);
//	data32 = 0x7E00;
//	kc_sds_wr(sata_csr_base, reg_offset, data32);

	reg_offset = reg_base + RXTX_REG4*2;
	data32 = kc_sds_rd(sata_csr_base, reg_offset);
	// [6] tx_loopback_buf_en: Tx forward loopback enable, enables the loopabck buffer
	data32 &= ~(1 << 6);	// disable TX loopback
	kc_sds_wr(sata_csr_base, reg_offset, data32);

	reg_offset = reg_base + RXTX_REG7*2;
	data32 = kc_sds_rd(sata_csr_base, reg_offset);
	/* [14] tx_cn2_inv: Invert CN2 Co-efficient value
	 * 	0 - Default and positive
	 * 	1 - Reduced the amplitude of the signal by i_tx_cn2[4:0] value.
	 */
	data32 &= ~(1 << 14);	// Default and positive
	kc_sds_wr(sata_csr_base, reg_offset, data32);

#ifdef B0
	reg_offset = reg_base + RXTX_REG38*2;
//	data32 = kc_sds_rd(sata_csr_base, reg_offset);
	data32 = 0;
	kc_sds_wr(sata_csr_base, reg_offset, data32);
#else
	for(i=0; i<18; i++){
		reg_offset = reg_base + (RXTX_REG38+i)*2;
		if(i == 1)
			data32 = 0xFF00;
		else if(i == 9)
			data32 = 0xFFFC;
		else if((i > 1) && (i < 9))
			data32 = 0xFFFF;
		else
			data32 = 0x0;
		kc_sds_wr(sata_csr_base, reg_offset, data32);
	}
#endif
}

void sm_sata_gen_avg(int port){
	int i, j;
	int timeout;
	int max_loop = 10;
	u32 loop;
	u32 do_lat = 0;
	u32 xo_lat = 0;
	u32 eo_lat = 0;
	u32 so_lat = 0;
	u32 de_lat = 0;
	u32 xe_lat = 0;
	u32 ee_lat = 0;
	u32 se_lat = 0;
	u32 sum_cal = 0;
	u32 reg_base = CH0_RXTX_REG_OFFSET + (port%2)*0x0200;
	u32 sata_csr_base = sm_sata_get_csr_base(port);
	u32 data32, read1, read2, read3, read4, read5, reg_offset;

	if(fix_gen_avg_val) {
		reg_offset = reg_base + RXTX_REG12*2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		// [1] rx_det_term_enable: Enable RX Hi-Z termination
		data32 |= RXTX_REG12_RX_DET_TERM_ENABLE__SET;
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		reg_offset = reg_base + RXTX_REG28*2;
		//data32 = kc_sds_rd(sata_csr_base, reg_offset);
		// [15:0] DFE_tap_ena: Enable for Each DFE loops and Back channel loops
		data32 = 0;		// Turn off DFE
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		reg_offset = reg_base + RXTX_REG31*2;
		//data32 = kc_sds_rd(sata_csr_base, reg_offset);
		// [15:9] DFE_Preset_value_h0: DFE loop preset value
		//  [7:1] DFE_Preset_value_h1: DFE loop preset value, preset valeu is mid value
		data32 = 0;		// DFE Presets to zero
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		/* SUMMER CALIB */
		loop = max_loop;
		while(loop) {
			// toggle Summer calib
			reg_offset = reg_base + RXTX_REG127*2;
			data32 = kc_sds_rd(sata_csr_base, reg_offset);
			data32 |= 0x1 << 1;
			kc_sds_wr(sata_csr_base, reg_offset, data32);
			sm_sata_usdelay(500);
			data32 &= ~(0x1 << 1);
			kc_sds_wr(sata_csr_base, reg_offset, data32);
			sm_sata_usdelay(500);

			timeout = 100;
			do {
				reg_offset = reg_base + RXTX_REG158*2;
				data32 = kc_sds_rd(sata_csr_base, reg_offset);
				sm_sata_usdelay(100);
			}while((--timeout) && ((data32 & 0x8000) == 0) || (data32 & 0x4000));
			if(timeout){
				lprintf(4, "\n Summer Calib is Passed");
				reg_offset = reg_base + RXTX_REG121*2;
				data32 = kc_sds_rd(sata_csr_base, reg_offset);
				sum_cal += (data32 & 0x3E) >> 1;
				--loop;
			}else
				lprintf(4, "\n [ERROR]: Summer Calib is NOT Passed");
			sm_sata_rxd_rst(port);
		}
		// Summer Calib Manual Program with the average value above
		reg_offset = reg_base + RXTX_REG14*2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(0x3F);
		data32 |= (sum_cal/max_loop);
		kc_sds_wr(sata_csr_base, reg_offset, data32);
		// Start Summer Calib Manual
		reg_offset = reg_base + RXTX_REG14*2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 |= 1 << 6;
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		/* LATCH CALIB */
		loop = max_loop;
		while(loop) {
			// toggle Latch calib
			reg_offset = reg_base + RXTX_REG127*2;
			data32 = kc_sds_rd(sata_csr_base, reg_offset);
			data32 |= 0x1 << 2;
			kc_sds_wr(sata_csr_base, reg_offset, data32);
			sm_sata_usdelay(500);
			data32 &= ~(0x1 << 2);
			kc_sds_wr(sata_csr_base, reg_offset, data32);
			sm_sata_usdelay(500);

			timeout = 1000;
			do {
				reg_offset = reg_base + RXTX_REG158*2;
				data32 = kc_sds_rd(sata_csr_base, reg_offset);
				sm_sata_usdelay(500);
			}while((--timeout) && ((data32 & 0x0800) == 0));
			if(timeout){
				lprintf(4, "\n Latch Calib is Passed");
			}else
				lprintf(4, "\n [ERROR]: Latch Calib is NOT Passed");

			reg_offset = reg_base + RXTX_REG21*2;
			read1 = kc_sds_rd(sata_csr_base, reg_offset);
			/*
			 * [15:10] DO_latch_calout: Data Latch code read out - Odd
			 *   [9:4] XO_latch_calout: Crossing Latch code read out - Odd
			 *   [3:0] Latch_cal_fail_odd: Latch Calibration Odd latch status bit
			 */
			reg_offset = reg_base + RXTX_REG22*2;
			read2 = kc_sds_rd(sata_csr_base, reg_offset);
			/*
			 * [15:10] DO_latch_calout: Data Latch code read out - Odd
			 *   [9:4] XO_latch_calout: Crossing Latch code read out - Odd
			 *   [3:0] Latch_cal_fail_even: Latch Calibration Even latch status bit
			 */
			reg_offset = reg_base + RXTX_REG23*2;
			read3 = kc_sds_rd(sata_csr_base, reg_offset);
			/*
			 * [15:10] DE_latch_calout: Data Latch code read out - Even
			 *   [9:4] XE_latch_calout: Crossing Latch code read out - Even
			 */
			reg_offset = reg_base + RXTX_REG24*2;
			read4 = kc_sds_rd(sata_csr_base, reg_offset);
			/*
			 * [15:10] DE_latch_calout: Data Latch code read out - Even
			 *   [9:4] XE_latch_calout: Crossing Latch code read out - Even
			 */

			lprintf(7, "\n RXTX_REG21 = 0x%04X  RXTX_REG22 = 0x%04X", read1, read2);
			lprintf(7, "  RXTX_REG23 = 0x%04X  RXTX_REG24 = 0x%04X  RXTX_REG121 = 0x%04X", read3, read4, data32);
			if(((read1 & 0xF) < 2) && ((read2 & 0xF) < 2)) {
				do_lat += ((read1 & 0xFC00) >> 10);
				xo_lat += ((read1 & 0x03F0) >> 4);
				eo_lat += ((read2 & 0xFC00) >> 10);
				so_lat += ((read2 & 0x03F0) >> 4);
				de_lat += (read3 & 0xFC00) >> 10;
				xe_lat += (read3 & 0x03F0) >> 4;
				ee_lat += (read4 & 0xFC00) >> 10;
				se_lat += (read4 & 0x03F0) >> 4;

				--loop;

				lprintf(7, "\n\t do_lat = 0x%04X  xo_lat = 0x%04X", (read1 & 0xFC00) >> 10, (read1 & 0x03F0) >> 4);
				lprintf(7, "  eo_lat = 0x%04X  so_lat = 0x%04X", (read2 & 0xFC00) >> 10, (read2 & 0x03F0) >> 4);
				lprintf(7, "\n\t de_lat = 0x%04X  xe_lat = 0x%04X", (read3 & 0xFC00) >> 10, (read3 & 0x03F0) >> 4);
				lprintf(7, "  ee_lat = 0x%04X  se_lat = 0x%04X", (read4 & 0xFC00) >> 10, (read4 & 0x03F0) >> 4);
				lprintf(7, "\n\t sum_cal = 0x%04X", (data32 & 0x3E) >> 1);
			}else {
				lprintf(7, "RXTX_REG23 = 0x%04X  RXTX_REG24 = 0x%04X  RXTX_REG121 = 0x%04X  FAILED", read1, read2, data32);
			}
			sm_sata_rxd_rst(port);
		}
		lprintf(7, "\n\t do_lat total = 0x%08X    ", do_lat);
		do_lat = do_lat / max_loop;
		lprintf(7, " do_lat average = 0x%08X ", do_lat);
		lprintf(7, "\n\t xo_lat total = 0x%08X    ", xo_lat);
		xo_lat = xo_lat / max_loop;
		lprintf(7, " xo_lat average = 0x%08X ", xo_lat);
		lprintf(7, "\n\t eo_lat total = 0x%08X    ", eo_lat);
		eo_lat = eo_lat / max_loop;
		lprintf(7, " eo_lat average = 0x%08X ", eo_lat);
		lprintf(7, "\n\t so_lat total = 0x%08X    ", so_lat);
		so_lat = so_lat / max_loop;
		lprintf(7, " so_lat average = 0x%08X ", so_lat);
		lprintf(7, "\n\t de_lat total = 0x%08X    ", de_lat);
		de_lat = de_lat / max_loop;
		lprintf(7, " de_lat average = 0x%08X ", de_lat);
		lprintf(7, "\n\t xe_lat total = 0x%08X    ", xe_lat);
		xe_lat = xe_lat / max_loop;
		lprintf(7, " xe_lat average = 0x%08X ", xe_lat);
		lprintf(7, "\n\t ee_lat total = 0x%08X    ", ee_lat);
		ee_lat = ee_lat / max_loop;
		lprintf(7, " ee_lat average = 0x%08X ", ee_lat);
		lprintf(7, "\n\t se_lat total = 0x%08X    ", se_lat);
		se_lat = se_lat / max_loop;
		lprintf(7, " se_lat average = 0x%08X ", se_lat);

		reg_offset = reg_base + RXTX_REG127*2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(0xFFF0);
		data32 |= do_lat << 10;
		data32 |= xo_lat << 4;
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		reg_offset = reg_base + RXTX_REG128*2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(0xFFF0);
		data32 |= eo_lat << 10;
		data32 |= so_lat << 4;
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		reg_offset = reg_base + RXTX_REG129*2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(0xFFF0);
		data32 |= de_lat << 10;
		data32 |= xe_lat << 4;
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		reg_offset = reg_base + RXTX_REG130*2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(0xFFF0);
		data32 |= ee_lat << 10;
		data32 |= se_lat << 4;
		kc_sds_wr(sata_csr_base, reg_offset, data32);
		sm_sata_msdelay(10);

		// Start Latch Calib Manual
		reg_offset = reg_base + RXTX_REG127*2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 |= 0x1 << 3;
		kc_sds_wr(sata_csr_base, reg_offset, data32);
		sm_sata_msdelay(10);

		// Disable RX Hi-Z termination
		reg_offset = reg_base + RXTX_REG12*2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(0x1 << 1);
		kc_sds_wr(sata_csr_base, reg_offset, data32);
#ifdef A3	// 072814
		reg_offset = reg_base + RXTX_REG28*2;
		data32 = 0x0007;
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		reg_offset = reg_base + RXTX_REG31*2;
		data32 = 0x7E00;
		kc_sds_wr(sata_csr_base, reg_offset, data32);
#endif
	}else {
		reg_offset = reg_base + RXTX_REG12*2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		// [1] rx_det_term_enable: Enable RX Hi-Z termination
		data32 |= RXTX_REG12_RX_DET_TERM_ENABLE__SET;
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		reg_offset = reg_base + RXTX_REG28*2;
		//data32 = kc_sds_rd(sata_csr_base, reg_offset);
		// [15:0] DFE_tap_ena: Enable for Each DFE loops and Back channel loops
		data32 = 0;		// Turn off DFE
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		reg_offset = reg_base + RXTX_REG31*2;
		//data32 = kc_sds_rd(sata_csr_base, reg_offset);
		// [15:9] DFE_Preset_value_h0: DFE loop preset value
		//  [7:1] DFE_Preset_value_h1: DFE loop preset value, preset valeu is mid value
		data32 = 0;		// DFE Presets to zero
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		loop = max_loop;
		while(loop){
			sm_sata_ssd_force_calib(port);
			sm_sata_msdelay(1);

			reg_offset = reg_base + RXTX_REG21*2;
			read1 = kc_sds_rd(sata_csr_base, reg_offset);
			/*
			 * [15:10] DO_latch_calout: Data Latch code read out - Odd
			 *   [9:4] XO_latch_calout: Crossing Latch code read out - Odd
			 *   [3:0] Latch_cal_fail_odd: Latch Calibration Odd latch status bit
			 */
			reg_offset = reg_base + RXTX_REG22*2;
			read2 = kc_sds_rd(sata_csr_base, reg_offset);
			/*
			 * [15:10] DO_latch_calout: Data Latch code read out - Odd
			 *   [9:4] XO_latch_calout: Crossing Latch code read out - Odd
			 *   [3:0] Latch_cal_fail_even: Latch Calibration Even latch status bit
			 */
			reg_offset = reg_base + RXTX_REG23*2;
			read3 = kc_sds_rd(sata_csr_base, reg_offset);
			/*
			 * [15:10] DE_latch_calout: Data Latch code read out - Even
			 *   [9:4] XE_latch_calout: Crossing Latch code read out - Even
			 */
			reg_offset = reg_base + RXTX_REG24*2;
			read4 = kc_sds_rd(sata_csr_base, reg_offset);
			/*
			 * [15:10] DE_latch_calout: Data Latch code read out - Even
			 *   [9:4] XE_latch_calout: Crossing Latch code read out - Even
			 */
			reg_offset = reg_base + RXTX_REG121*2;
			data32 = kc_sds_rd(sata_csr_base, reg_offset);
			sum_cal += (data32 & 0x3E) >> 1;

			lprintf(7, "\n RXTX_REG21 = 0x%04X  RXTX_REG22 = 0x%04X", read1, read2);
			lprintf(7, "  RXTX_REG23 = 0x%04X  RXTX_REG24 = 0x%04X  RXTX_REG121 = 0x%04X", read3, read4, data32);
			if(((read1 & 0xF) < 2) && ((read2 & 0xF) < 2)){
				do_lat += ((read1 & 0xFC00) >> 10);
				xo_lat += ((read1 & 0x03F0) >> 4);
				eo_lat += ((read2 & 0xFC00) >> 10);
				so_lat += ((read2 & 0x03F0) >> 4);
				de_lat += (read3 & 0xFC00) >> 10;
				xe_lat += (read3 & 0x03F0) >> 4;
				ee_lat += (read4 & 0xFC00) >> 10;
				se_lat += (read4 & 0x03F0) >> 4;

				--loop;

				lprintf(7, "\n\t do_lat = 0x%04X  xo_lat = 0x%04X", (read1 & 0xFC00) >> 10, (read1 & 0x03F0) >> 4);
				lprintf(7, "  eo_lat = 0x%04X  so_lat = 0x%04X", (read2 & 0xFC00) >> 10, (read2 & 0x03F0) >> 4);
				lprintf(7, "\n\t de_lat = 0x%04X  xe_lat = 0x%04X", (read3 & 0xFC00) >> 10, (read3 & 0x03F0) >> 4);
				lprintf(7, "  ee_lat = 0x%04X  se_lat = 0x%04X", (read4 & 0xFC00) >> 10, (read4 & 0x03F0) >> 4);
				lprintf(7, "\n\t sum_cal = 0x%04X", (data32 & 0x3E) >> 1);
			}
			else{
				lprintf(7, "RXTX_REG23 = 0x%04X  RXTX_REG24 = 0x%04X  RXTX_REG121 = 0x%04X  FAILED", read1, read2, data32);
			}
			sm_sata_rxd_rst(port);
		}
		loop = max_loop;
		lprintf(7, "\n\t do_lat total = 0x%08X    ", do_lat);
		do_lat = do_lat / loop;
		lprintf(7, " do_lat average = 0x%08X ", do_lat);
		lprintf(7, "\n\t xo_lat total = 0x%08X    ", xo_lat);
		xo_lat = xo_lat / loop;
		lprintf(7, " xo_lat average = 0x%08X ", xo_lat);
		lprintf(7, "\n\t eo_lat total = 0x%08X    ", eo_lat);
		eo_lat = eo_lat / loop;
		lprintf(7, " eo_lat average = 0x%08X ", eo_lat);
		lprintf(7, "\n\t so_lat total = 0x%08X    ", so_lat);
		so_lat = so_lat / loop;
		lprintf(7, " so_lat average = 0x%08X ", so_lat);
		lprintf(7, "\n\t de_lat total = 0x%08X    ", de_lat);
		de_lat = de_lat / loop;
		lprintf(7, " de_lat average = 0x%08X ", de_lat);
		lprintf(7, "\n\t xe_lat total = 0x%08X    ", xe_lat);
		xe_lat = xe_lat / loop;
		lprintf(7, " xe_lat average = 0x%08X ", xe_lat);
		lprintf(7, "\n\t ee_lat total = 0x%08X    ", ee_lat);
		ee_lat = ee_lat / loop;
		lprintf(7, " ee_lat average = 0x%08X ", ee_lat);
		lprintf(7, "\n\t se_lat total = 0x%08X    ", se_lat);
		se_lat = se_lat / loop;
		lprintf(7, " se_lat average = 0x%08X ", se_lat);
		lprintf(7, "\n\t sum_cal total = 0x%08X    ", sum_cal);
		sum_cal = sum_cal / loop;
		lprintf(7, " sum_cal average = 0x%08X ", sum_cal);

		reg_offset = reg_base + RXTX_REG127*2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(0xFFF0);
		data32 |= do_lat << 10;
		data32 |= xo_lat << 4;
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		reg_offset = reg_base + RXTX_REG128*2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(0xFFF0);
		data32 |= eo_lat << 10;
		data32 |= so_lat << 4;
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		reg_offset = reg_base + RXTX_REG129*2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(0xFFF0);
		data32 |= de_lat << 10;
		data32 |= xe_lat << 4;
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		reg_offset = reg_base + RXTX_REG130*2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(0xFFF0);
		data32 |= ee_lat << 10;
		data32 |= se_lat << 4;
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		// Summer Calib Manual Program
		reg_offset = reg_base + RXTX_REG14*2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(0x3F);
		data32 |= sum_cal;
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		// Start Summer Calib Manual
		reg_offset = reg_base + RXTX_REG14*2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 |= 1 << 6;
		kc_sds_wr(sata_csr_base, reg_offset, data32);
		sm_sata_msdelay(10);

		// Start Latch Calib Manual
		reg_offset = reg_base + RXTX_REG127*2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 |= 1 << 3;
		kc_sds_wr(sata_csr_base, reg_offset, data32);
		sm_sata_msdelay(10);

		// Disable RX Hi-Z termination
		reg_offset = reg_base + RXTX_REG12*2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(1 << 1);
		kc_sds_wr(sata_csr_base, reg_offset, data32);

	//	reg_offset = reg_base + RXTX_REG28*2;
	//	data32 = 0x7;
	//	kc_sds_wr(sata_csr_base, reg_offset, data32);
	//
	//	reg_offset = reg_base + RXTX_REG31*2;
	//	data32 = 0x7E00;
	//	kc_sds_wr(sata_csr_base, reg_offset, data32);
	//
	//	sm_sata_rxd_rst(port);
	}
}

void sm_sata_sds_pdown_force_vco(int port){
	u32 data32, reg_offset, clkref_offset;
	u32 sata_csr_base = sm_sata_get_csr_base(port);

	lprintf(6, "\n##### sm_sata_sds_pdown_force_vco #####");

	if(CLK_TYPE){
		clkref_offset = SM_PCIE_KC_CLKMACRO;
		lprintf(4, "\n\t SATA-PCIE2 VCO Power Down Force");
	}else{
		clkref_offset = 0;
		lprintf(4, "\n\t SATA VCO Power Down Force");
	}

	reg_offset = clkref_offset + CMU_REG16*2;
	data32 = kc_sds_rd(sata_csr_base, reg_offset);
	data32 &= ~(7 << 2);
#ifdef B0		// 072814
	data32 |= 7 << 2;	// [4:2] vcocal_wait_btw_code: wait between freq band/momsel code changes during VCO calibrations
#else
	data32 |= 5 << 2;
#endif
	kc_sds_wr(sata_csr_base, reg_offset, data32);

	// toggle: CMU Power Recycle
	reg_offset = clkref_offset + CMU_REG0*2;
	data32 = kc_sds_rd(sata_csr_base, reg_offset);
	data32 |= 1 << 14;
	kc_sds_wr(sata_csr_base, reg_offset, data32);
	sm_sata_msdelay(1);
	data32 = kc_sds_rd(sata_csr_base, reg_offset);
	data32 &= ~(1<<14);
	kc_sds_wr(sata_csr_base, reg_offset, data32);
	sm_sata_msdelay(1);

	// toggle: Force VCO Calibration re-start
	reg_offset = clkref_offset + CMU_REG32*2;
	data32 = kc_sds_rd(sata_csr_base, reg_offset);
	data32 |= 1 << 14;
	kc_sds_wr(sata_csr_base, reg_offset, data32);
	sm_sata_msdelay(1);
	data32 &= ~(1 << 14);
	kc_sds_wr(sata_csr_base, reg_offset, data32);
	sm_sata_msdelay(1);
}

int sm_sata_sds_calib(int port){
	int rc = 0;
	int data32, timeout;
    int reg_base, reg_offset, clkref_offset;
    u32 sata_csr_base = sm_sata_get_csr_base(port);

    lprintf(6, "\n##### sm_sata_sds_calib #####");

	if(CLK_TYPE){
		clkref_offset = SM_PCIE_KC_CLKMACRO;
		lprintf(4, "\n\t SATA-PCIE2 VCO Power Down Force");
	}else{
		clkref_offset = 0;
		lprintf(4, "\n\t SATA VCO Power Down Force");
	}

    sm_sata_write32(sata_csr_base + SATA_ENET_SDS_RST_CTL__ADDR, 0x000000DF);
    sm_sata_usdelay(800);

#ifdef A2	// Manual PVT
		// TERM CALIBRATION CH0
		reg_offset = clkref_offset + CMU_REG17 * 2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(0x7F << 8);
		data32 |= 0x12 << 8;	// Poly requested 102213
		data32 &= ~(7 << 5);	// RO bits, Channel 0
		kc_sds_wr(sata_csr_base, reg_offset, data32);
		// toggle
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 |= 1 << 15;		// Enable term calibration manual mode
		kc_sds_wr(sata_csr_base, reg_offset, data32);
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(1 << 15);	// Disable term calibration manual mode
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		// DOWN CALIBRATION CH0
		reg_offset = clkref_offset + CMU_REG17 * 2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(0x7F << 8);
		data32 |= 0x29 << 8;
		data32 &= ~(7 << 5);	// RO bits, Channel 0
		kc_sds_wr(sata_csr_base, reg_offset, data32);
		// toggle
		reg_offset = clkref_offset + CMU_REG16 * 2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 |= 1;	// Enable pull dn calibration manual mode
		kc_sds_wr(sata_csr_base, reg_offset, data32);
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~1;	// Disable pull dn calibration manual mode
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		// UP CALIBRATION CH0
		reg_offset = clkref_offset + CMU_REG17 * 2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(0x7F << 8);
		data32 |= 0x28 << 8;
		data32 &= ~(7 << 5);	// RO bits, Channel 0
		kc_sds_wr(sata_csr_base, reg_offset, data32);
		// toggle
		reg_offset = clkref_offset + CMU_REG16 * 2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 |= 1 << 1;		// Enable pull up calibration manual mode
		kc_sds_wr(sata_csr_base, reg_offset, data32);
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(1 << 1);	// Disable pull up calibration manual mode
		kc_sds_wr(sata_csr_base, reg_offset, data32);
#else		// Auto PVT
		reg_offset = clkref_offset + CMU_REG5 * 2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 |= 0x1;		// 1: PLL reset to reset VCO Calib, PVT calib, and PLL
		kc_sds_wr(sata_csr_base, reg_offset, data32);
		sm_sata_usdelay(800);

		reg_offset = clkref_offset + CMU_REG1 * 2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(0x1 << 3);	// 0: Disable Manual VCO Calib
		kc_sds_wr(sata_csr_base, reg_offset, data32);
		sm_sata_usdelay(800);

		reg_offset = clkref_offset + CMU_REG32 * 2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 |= 0x1 << 14;	// 1: Force VCO calib restart
		kc_sds_wr(sata_csr_base, reg_offset, data32);
		sm_sata_usdelay(800);
		data32 &= ~(0x1 << 14);
		kc_sds_wr(sata_csr_base, reg_offset, data32);
#endif

	// VCO calib & result
	lprintf(7, "\n CMU_REG7 [14], [11:10]");
	/*
	 * [14] pll_calib_done
	 * VCO calibration complete status bit
	 * [11:10] pll_lock
	 * PLL Lock status bit
	 */
	timeout = 100;
	do{
		reg_offset = clkref_offset + CMU_REG7 * 2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		if((data32 & 0x0C00) == 0x0400) {
		    sm_sata_write32(sata_csr_base + SATA_ENET_SDS_RST_CTL__ADDR, 0x000000DE);
		    sm_sata_write32(sata_csr_base + SATA_ENET_SDS_RST_CTL__ADDR, 0x000000DF);
		    sm_sata_usdelay(800);
			reg_offset = clkref_offset + CMU_REG32 * 2;
			data32 = kc_sds_rd(sata_csr_base, reg_offset);
			data32 |= 0x1 << 14;
			kc_sds_wr(sata_csr_base, reg_offset, data32);
			data32 &= ~(0x1 << 14);
			kc_sds_wr(sata_csr_base, reg_offset, data32);
			sm_sata_usdelay(800);
			reg_offset = clkref_offset + CMU_REG7 * 2;
			data32 = kc_sds_rd(sata_csr_base, reg_offset);
		}
		sm_sata_usdelay(100);
	}while((((data32 & 0x4000) == 0) || ((data32 & 0x0C00) > 0)) && --timeout);

	reg_offset = clkref_offset + CMU_REG7 * 2;
	data32 = kc_sds_rd(sata_csr_base, reg_offset);
	if(data32 & 0x4000)
		lprintf(5, "\n\t SATA Controller %d - VCO calibration completed", port/2);
	else
		lprintf(5, "\n\t [ERROR]: SATA Controller %d - VCO calibration NOT completed", port/2);

	if((data32 & 0x0C00) == 0){
		lprintf(5, "\n\t SATA Controller %d - VCO calibration PASSED", port/2);
	}else{
		lprintf(5, "\n\t [ERROR]: SATA Controller %d - VCO calibration FAILED", port/2);
		return -1;
	}
	return 0;
}

void sm_sata_sds_dump(int port)	{
	int i, reg_base, reg_offset;
	int sds_dump_status = SDS_DUMP;
	int cmu_maxreg = 40;
	int rxtx_maxreg = 163;
    u32 sata_csr_base = sm_sata_get_csr_base(port);

    SDS_DUMP = 1;
	// CMU Regs
	for(i=0; i<cmu_maxreg; i++) {
		reg_offset = (CMU_REG0 + i) * 2;
		kc_sds_rd(sata_csr_base, reg_offset);
	}

	// RXTX Regs
	reg_base = ((port%2) == 0) ? CH0_RXTX_REG_OFFSET : CH1_RXTX_REG_OFFSET;
	for(i=0; i<rxtx_maxreg; i++) {
		reg_offset = reg_base + (RXTX_REG0 + i) * 2;
		kc_sds_rd(sata_csr_base, reg_offset);
	}
	SDS_DUMP = sds_dump_status;
}
void sm_sata_force_calib(int port) {
	int i, j;
	int timeout = 10;
    int reg_base = CH0_RXTX_REG_OFFSET;
    int reg_offset;
    u32 data32, sata_csr_base = sm_sata_get_csr_base(port);

    lprintf(6, "\n##### sm_sata_force_calib #####");

	for(j=0; j<2; ++j){
		reg_offset = reg_base + j*0x0200 + RXTX_REG127*2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		// Summer Calib
		/* [1] force_sum_cal_start
		 * Manual start the calibration
		 */
		data32 |= 1 << 1;
		kc_sds_wr(sata_csr_base, reg_offset, data32);
		sm_sata_msdelay(10);
		data32 &= ~(1 << 1);
		kc_sds_wr(sata_csr_base, reg_offset, data32);
		sm_sata_msdelay(10);

		// Latch calib
		/* [2] force_lat_cal_start
		 * Manual start the calibration
		 */
		data32 |= 1 << 2;
		kc_sds_wr(sata_csr_base, reg_offset, data32);
		sm_sata_msdelay(10);
		data32 &= ~(1 << 2);
		kc_sds_wr(sata_csr_base, reg_offset, data32);
		sm_sata_msdelay(10);

		reg_offset = reg_base + j*0x0200 + RXTX_REG121*2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		lprintf(5, "\n\t RXTX REG121: 0x%08x", data32 >> 1);
	}
	for(j=0; j<2; ++j){
		// Anil request
		reg_offset = reg_base + j*0x0200 + RXTX_REG28*2;
		kc_sds_wr(sata_csr_base, reg_offset, 0x7);
		reg_offset = reg_base + j*0x0200 + RXTX_REG31*2;
		kc_sds_wr(sata_csr_base, reg_offset, 0x7E00);
	}
	for(j=0; j<2; ++j){
		// Removing Loopback
		reg_offset = reg_base + j*0x0200 + RXTX_REG4*2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(1 << 6);
		kc_sds_wr(sata_csr_base, reg_offset, data32);
		reg_offset = reg_base + j*0x0200 + RXTX_REG7*2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(1 << 14);
		kc_sds_wr(sata_csr_base, reg_offset, data32);

		reg_offset = reg_base + j*0x0200 + RXTX_REG38*2;
		kc_sds_wr(sata_csr_base, reg_offset, 0x00);
		reg_offset = reg_base + j*0x0200 + RXTX_REG39*2;
		kc_sds_wr(sata_csr_base, reg_offset, 0xFF00);
		for(i=0; i<7; ++i){		// REG40 - REG46
			reg_offset = reg_base + j*0x0200 + (RXTX_REG40+i)*2;
			kc_sds_wr(sata_csr_base, reg_offset, 0xFFFF);
		}
		reg_offset = reg_base + j*0x0200 + RXTX_REG47*2;
		kc_sds_wr(sata_csr_base, reg_offset, 0xFFFC);
		for(i=0; i<8; ++i){		// REG48 - REG55
			reg_offset = reg_base + j*0x0200 + (RXTX_REG48+i)*2;
			kc_sds_wr(sata_csr_base, reg_offset, 0x0);
		}
	}
}

/*
 * Config Koolchip SERDES
 * based on the KC spreadsheet
 */

void sm_sata_core_sds_rxs_rst(int port){
	int i;
    int reg_base, reg_offset;
    u32 data32, sata_csr_base = sm_sata_get_csr_base(port);

    lprintf(6, "\n##### sm_sata_core_sds_rxs_rst - START #####");
	for(i=0; i<2; ++i){
		reg_base = (i == 0) ? CH0_RXTX_REG_OFFSET : CH1_RXTX_REG_OFFSET;
		/* Receiver (RX) Reset
		 * [8] resetb_rxd
		 * Digital RX reset
		 *
		 * [7] resetb_rxa
		 * Analog RX reset
		 */
		reg_offset = reg_base + RXTX_REG7 * 2;
		data32 = kc_sds_rd(sata_csr_base, reg_offset);
		data32 &= ~(1 << 8);	// Digital RX in reset
		kc_sds_wr(sata_csr_base, reg_offset, data32);
		data32 &= ~(1 << 7);	// Analog RX in reset
		kc_sds_wr(sata_csr_base, reg_offset, data32);
		sm_sata_msdelay(10);	// 050213 changed fr 0x8000
		data32 |= (1 << 7);		// Analog RX out of reset
		kc_sds_wr(sata_csr_base, reg_offset, data32);
		sm_sata_msdelay(10);	// 050213 changed fr 0x8000
		data32 |= (1 << 8);		// Digital RX out of reset
		kc_sds_wr(sata_csr_base, reg_offset, data32);
		sm_sata_msdelay(10);	// 050213 changed fr 0x8000
	}
    lprintf(6, "\n##### sm_sata_core_sds_rxs_rst - END #####\n");
}

int sm_sata_pll_chk(int port){
	int i, rc = 0;
    int reg_offset;
    u32 data32, sata_csr_base = sm_sata_get_csr_base(port);

    lprintf(6, "\n##### sm_sata_pll_chk - START #####");

	// Re-check status of PLL Locking
	lprintf(7, "\n\n SATA_ENET_SDS_CMU_STATUS0 [0]");
	data32 = sm_sata_read32(sata_csr_base + SATA_ENET_SDS_CMU_STATUS0__ADDR);
	if((data32 & 0x1) > 0)
		lprintf(4, "\n\t PLL Ready");
	else{
		lprintf(3, "\n\t [ERROR]: PLL NOT Ready");
    	++rc;
    }

	// Check status of RXTX
	lprintf(7, "\n\n SATA_ENET_SDS0_RXTX_STATUS [20], [0]");
	data32 = sm_sata_read32(sata_csr_base + SATA_ENET_SDS0_RXTX_STATUS__ADDR);
	/* [20] cfg_tx_o_tx_ready
	 * SERDES Tx Per Lane TX ready to receive data
	 * 0 : TX is not ready.
	 * 1 : TX is ready
	 * Sync to csr clk, source is based on refclk
	 */
	if((data32 & (1 << 20)) > 0)
		lprintf(4, "\n\t SERDES TX of Channel 0 is Ready");
	else{
		lprintf(3, "\n\t [ERROR]: SERDES TX of Channel 0 is NOT Ready");
		++rc;
	}

	/* [0] cfg_rx_o_rx_ready
	 * SERDES Tx Per Lane TX ready to receive data
	 * 0 : RX is not ready.
	 * 1 : RX is ready
	 * Sync to csr clk, source is based on refclk
	 */
	if((data32 & (1 << 0)) > 0)
		lprintf(4, "\n\t SERDES RX of Channel 0 is Ready");
	else{
		lprintf(3, "\n\t [ERROR]: SERDES RX of Channel 0 is NOT Ready");
		++rc;
	}

	lprintf(7, "\n\n SATA_ENET_SDS1_RXTX_STATUS [20], [0]");
	data32 = sm_sata_read32(sata_csr_base + SATA_ENET_SDS1_RXTX_STATUS__ADDR);
	/* [20] cfg_tx_o_tx_ready
	 * SERDES Tx Per Lane TX ready to receive data
	 * 0 : TX is not ready.
	 * 1 : TX is ready
	 * Sync to csr clk, source is based on refclk
	 */
	if((data32 & (1 << 20)) > 0)
		lprintf(4, "\n\t SERDES TX of Channel 1 is Ready");
	else{
		lprintf(3, "\n\t [ERROR]: SERDES TX of Channel 1 is NOT ready");
		++rc;
	}

	/* [0] cfg_rx_o_rx_ready
	 * SERDES Tx Per Lane TX ready to receive data
	 * 0 : RX is not ready.
	 * 1 : RX is ready
	 * Sync to csr clk, source is based on refclk
	 */
	if((data32 & (1 << 0)) > 0)
		lprintf(4, "\n\t SERDES RX of Channel 1 is Ready");
	else{
		lprintf(3, "\n\t [ERROR]: SERDES RX of Channel 1 is NOT Ready");
		++rc;
	}

	lprintf(6, "\n##### sm_sata_pll_chk - END %d #####\n", rc);
    return rc;
}

/***************************************************************************/
void sm_sata_rxa_rst(int port){
    int reg_base = CH0_RXTX_REG_OFFSET + (port%2)*0x0200;
 	u32 sata_csr_base = sm_sata_get_csr_base(port);
	u32 data32, reg_offset;

    lprintf(6, "\n##### sm_sata_rxa_rst #####");

	reg_offset = reg_base + RXTX_REG7*2;
	data32 = kc_sds_rd(sata_csr_base, reg_offset);
	// [7] resetb_rxa: Analog RX reset
	data32 &= ~(1 << 7);
	kc_sds_wr(sata_csr_base, reg_offset, data32);
	sm_sata_msdelay(10);

	data32 |= (1 << 7);
	kc_sds_wr(sata_csr_base, reg_offset, data32);
	sm_sata_msdelay(10);
}

void sm_sata_rxd_rst(int port){
    int reg_base = CH0_RXTX_REG_OFFSET + (port%2)*0x0200;
 	u32 sata_csr_base = sm_sata_get_csr_base(port);
	u32 data32, reg_offset;

    lprintf(6, "\n##### sm_sata_rxd_rst #####");

	reg_offset = reg_base + RXTX_REG7*2;
	data32 = kc_sds_rd(sata_csr_base, reg_offset);
	// [8] resetb_rxd: Digital RX reset
	data32 &= ~(1 << 8);
	kc_sds_wr(sata_csr_base, reg_offset, data32);
	sm_sata_usdelay(200);
	data32 |= (1 << 8);
	kc_sds_wr(sata_csr_base, reg_offset, data32);
	sm_sata_usdelay(200);
}

/****************************** STATUS REGS ******************************/
void sm_sata_pxis_decode(int val){
	if(val & (1 <<  0)) printf("\n\t\t [0] Device to Host Register FIS Interrupt (DHRS)");
	if(val & (1 <<  1)) printf("\n\t\t [1] PIO Setup FIS Interrupt (PSS)");
	if(val & (1 <<  2)) printf("\n\t\t [2] DMA Setup FIS Interrupt (DSS)");
	if(val & (1 <<  3)) printf("\n\t\t [3] Set Device Bits Interrupt (SDBS)");
	if(val & (1 <<  4)) printf("\n\t\t [4] Unknown FIS Interrupt (UFS)");
	if(val & (1 <<  5)) printf("\n\t\t [5] Descriptor Processed (DPS)");
	if(val & (1 <<  6)) printf("\n\t\t [6] Port Connect Change Status (PCS)");
	if(val & (1 <<  7)) printf("\n\t\t [7] Device Mechanical Presence Status (DMPS)");
	if(val & (1 << 22)) printf("\n\t\t [22] PHY Ready Change Status (PRCS)");
	if(val & (1 << 23)) printf("\n\t\t [23] Incorrect Port Multiplier Status (IPMS)");
	if(val & (1 << 24)) printf("\n\t\t [24] Overflow Status (OFS)");
	if(val & (1 << 26)) printf("\n\t\t [26] Interface Non-fatal Error Status (INFS)");
	if(val & (1 << 27)) printf("\n\t\t [27] Interface Fatal Error Status (IFS)");
	if(val & (1 << 28)) printf("\n\t\t [28] Host Bus Data Error Status (HBDS)");
	if(val & (1 << 29)) printf("\n\t\t [29] Host Bus Fatal Error Status (HBFS)");
	if(val & (1 << 30)) printf("\n\t\t [30] Task File Error Status (TFES)");
	if(val & (1 << 31)) printf("\n\t\t [31] Cold Port Detect Status (CPDS)");
}
void sm_sata_pxis(int port){
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);
	u32 data;

	data = sm_sata_read32(sata_ahci_port_base + IS0__ADDR);
	printf("\n\n\t SATA Port%d Interrupt Status (P%dIS) = 0x%08x", port, port, data);
	sm_sata_pxis_decode(data);
}
void sm_sata_pxssts_decode(int val){
	int bit_num;
	printf("\n\t Interface Power Management (IPM) [11:8]");
	bit_num = (val >> 8) & 0xF;
	switch(bit_num){
	case 1:
		printf("\n\t\t 1: Interface in Active state");
		break;
	case 2:
		printf("\n\t\t 2: Interface in Partial power management state");
		break;
	case 6:
		printf("\n\t\t 6: Interface in Slumber power management state");
		break;
	default:
		printf("\n\t\t Device not present or communication not established");
		break;
	}
	printf("\n\t Current  Interface  Speed (SPD) [7:4]");
	bit_num = (val >> 4) & 0xF;
	switch(bit_num){
	case 1:
		printf("\n\t\t 1: Generation 1 communication rate negotiated");
		break;
	case 2:
		printf("\n\t\t 2: Generation 2 communication rate negotiated");
		break;
	case 3:
		printf("\n\t\t 3: Generation 3 communication rate negotiated");
		break;
	default:
		printf("\n\t\t Device not present or communication not established");
		break;
	}
	printf("\n\t Device Detection (DET) [3:0]");
	bit_num = val & 0xF;
	switch(bit_num){
	case 1:
		printf("\n\t\t 1: Device presence detected but Phy communication not established");
		break;
	case 3:
		printf("\n\t\t 3: Device presence detected and Phy communication established");
		break;
	case 4:
		printf("\n\t\t 4: Phy in offline mode as a result of the interface being disabled or running in a BIST loopback mode");
		break;
	default:
		printf("\n\t\t No device detected and Phy communication not established");
		break;
	}
}
void sm_sata_pxssts(int port){
	int bit_num;
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);
	u32 data;

	data = sm_sata_read32(sata_ahci_port_base + SSTS0__ADDR);
	printf("\n\tSATA Port%d Serial ATA Status (P%dSSTS) = 0x%08x", port, port, data);
	sm_sata_pxssts_decode(data);
}

void sm_sata_pxserr_decode(int val){
	if(val & (1 <<  0)) printf("\n\t\t [0] Recovered Data Integrity Error (I)");
	if(val & (1 <<  1)) printf("\n\t\t [1] Recovered Communications Error (M)");
	if(val & (1 <<  8)) printf("\n\t\t [8] Transient Data Integrity Error (T)");
	if(val & (1 <<  9)) printf("\n\t\t [9] Persistent Communication or Data Integrity Error (C)");
	if(val & (1 << 10)) printf("\n\t\t [10] Protocol Error (P)");
	if(val & (1 << 11)) printf("\n\t\t [11] Internal Error (E)");
	if(val & (1 << 16)) printf("\n\t\t [16] PhyRdy Change (N)");
	if(val & (1 << 17)) printf("\n\t\t [17] Phy Internal Error (I)");
	if(val & (1 << 18)) printf("\n\t\t [18] Comm Wake (W)");
	if(val & (1 << 19)) printf("\n\t\t [19] 10B to 8B Decode Error (B)");
	if(val & (1 << 20)) printf("\n\t\t [20] Disparity Error (D)");
	if(val & (1 << 21)) printf("\n\t\t [21] CRC Error (C)");
	if(val & (1 << 22)) printf("\n\t\t [22] Handshake Error (H)");
	if(val & (1 << 23)) printf("\n\t\t [23] Link Sequence Error (S)");
	if(val & (1 << 24)) printf("\n\t\t [24] Transport state transition error (T)");
	if(val & (1 << 25)) printf("\n\t\t [25] Unknown FIS Type (F)");
	if(val & (1 << 26)) printf("\n\t\t [26] Exchanged (X)");
}
void sm_sata_pxserr(int port){
	int bit_num;
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);
	u32 data;

	data = sm_sata_read32(sata_ahci_port_base + SERR0__ADDR);
	printf("\n\t SATA Port%d Serial ATA Error (P%dSERR) = 0x%08x", port, port, data);
	sm_sata_pxserr_decode(data);
}

void sm_sata_port_status(int port){
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);
	printf("\n\n SATA Port %d Status:", port);
	sm_sata_pxssts(port);
	sm_sata_pxis(port);
	sm_sata_pxserr(port);
}

/****************************** IRQ ******************************/
void sm_sata_global_irq(int port, int enable){
	u32 sata_ahci_base = sm_sata_get_ahci_base(port);
	u32 addr = sata_ahci_base + GHC__ADDR;
	u32 data;
	sm_host_read32(addr, &data);
	if(enable)
		data |= 2;
	else
		data &= ~2;
	sm_host_write32(addr,  data);
}

void sm_sata_port_irq(int port, int enable_bits){
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);
	u32 addr = sata_ahci_port_base + IE0__ADDR;
	// PxIE - Port Interrupt Enable
	/* 0xFDC000FF
	 * [0] [0] Device to Host Register FIS Interrupt Enable (DHRE)
	 * [1] PIO Setup FIS Interrupt Enable (PSE)
	 * [2] DMA Setup FIS Interrupt Enable (DSE)
	 * [3] Set Device Bits Interrupt Enable (SDBE)
	 * [4] Unknown  FIS  Interrupt Enable (UFE)
	 * [5] Descriptor Processed Enable (DPE)
	 * [6] Port Connect Change Status Enable (PCE)
	 * [7] Device Mechanical Presence Status Enable (DMPE)
	 * [22] PHY Ready Change Status Enable (PRCE)
	 * [23] Incorrect Port Multiplier Status Enable (IPME)
	 * [24] Overflow Status Enable (OFE)
	 * [26] Interface Non-fatal Error Status Enable (INFE)
	 * [27] Interface Fatal Error Status Enable (IFE)
	 * [28] Host Bus Data Error Status Enable (HBDE)
 	 * [29] Host Bus Fatal Error Status Enable (HBFE)
	 * [30] Task File Error Status Enable (TFEE)
	 * [31] Cold Port Detect Status Enable (CPDE)
	 */
	sm_host_write32(addr, enable_bits);
}

void sm_sata_irq_ccc_en(int port, int TV, int CC){
	u32 data;
	u32 sata_ahci_base = sm_sata_get_ahci_base(port);
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);
	u32 addr;

	lprintf(6, "sm_sata_irq_ccc_en - START");
	/* Enable Command Completion Coalescing Control Process: */
    // Disable DHRE, PSE, SDBE, DPE
	lprintf(7, "\n P%dIE", port);
	addr = sata_ahci_port_base + IE0__ADDR;
	data = sm_sata_read32(addr);
	data &= ~((1 << 0) | (1 << 1) | (1 << 3) | (1 << 5));
	sm_sata_write32(addr, data);
	// Disable CCC
	lprintf(7, "\n\n CCC_CTL");
	addr = sata_ahci_base + CCC_CTL__ADDR;
    data = sm_sata_read32(addr);
    data &= ~1;
	sm_sata_write32(addr, data);
	// Set ports for CCC
	lprintf(7, "\n\n CCC_PORTS");
    addr = sata_ahci_base + CCC_PORTS__ADDR;
	data = sm_sata_read32(addr);
	data |= 1 << (port % 2);
	sm_sata_write32(addr, data);
	// Set timeout and number of completed commands
	lprintf(7, "\n\n CCC_CTL");
	addr = sata_ahci_base + CCC_CTL__ADDR;
    data = sm_sata_read32(addr);
    data &= ~(0xFFFF << 16);
    data |= TV << 16;		// Timeout Value in milisecond
    data &= ~(0xFF << 8);
    data |= CC << 8;		// Number of completed commands
	sm_sata_write32(addr, data);
	// Enable CCC
	lprintf(7, "\n\n CCC_CTL");
    data |= 1;				// Enable CCC
	sm_sata_write32(addr, data);
	data = sm_sata_read32(addr);
	if(data & 1){
		lprintf(3, "\n Command Completion Coalescing (CCC) Enabled. \n");
		lprintf(3, "\t Timeout Value (TV)        = %d miliseconds \n", (data >> 16) & 0xFFFF);
		lprintf(3, "\t Command Complietions (CC) = %d commands \n", (data >> 8) & 0xFF);
		lprintf(3, "\t Interrupt (INT)           = 0x%x \n", (data >> 3) & 0x1F);
	}
	lprintf(6, "sm_sata_irq_ccc_en - END");
}

void sm_sata_irq_ccc_dis(int port){
	u32 data;
	u32 sata_ahci_base = sm_sata_get_ahci_base(port);

	// Disable CCC
	lprintf(7, "\n\n CCC_CTL [0]");
    data = sm_sata_read32(sata_ahci_base + CCC_CTL__ADDR);
    data &= ~1;
	sm_sata_write32(sata_ahci_base + CCC_CTL__ADDR, data);
	lprintf(3, "\n\n Command Completion Coalescing (CCC) Disable. \n");
}

void sm_sata_irq(u32 sata_ahci_base){
	int i, port;
	u32 temp1, temp2, temp3;
	u32 data, empty_slot, ccc_ctl_reg;
	u32 sata_ahci_port_base;
	u32 addr;
	u32 start_sector = 5;
	u32 sector_count = 20000;
	u64 fr = SATA_DATA_WRITE_BASE;

	port = ((sata_ahci_base & 0x00F00000) >> 20) / 2;
	// Get AHCI Base for the interrupted port
	sata_ahci_port_base = sata_ahci_base;
	addr = sata_ahci_base + IS__ADDR;
	data = sm_sata_read32(addr);
	if(data & 4){
		++irq_ccc_cnt;
		lprintf(6, "\n\t CCC interrupt occurred");
		addr = sata_ahci_base + CCC_PORTS__ADDR;
		data = sm_sata_read32(addr);
	}
	else
		++irq_cnt;
	if(data == 2){
		sata_ahci_port_base += 0x80;
		++port;
	}
	lprintf(4, "\n =====> SATA Port%d INTERRUPT OCCURRED <===== ", port);
	switch(test_id){
	case 1:		// ReadID
	case 2:		// PIO
	case 3:		// DMA
	case 4:		// FPDMA
	case 5:		// CCC
		addr = sata_ahci_port_base + IS0__ADDR;
		sm_sata_write32(addr, sm_sata_read32(addr));
		addr = sata_ahci_base + IS__ADDR;
		sm_sata_write32(addr, sm_sata_read32(addr));
		break;
	case 6:		// NCQ
		addr = sata_ahci_port_base + IS0__ADDR;
		data = sm_sata_read32(addr);
		lprintf(4, "\n\t PxIS   = 0x%08x", data);
		sm_sata_write32(addr, data);
		addr = sata_ahci_base + IS__ADDR;
		sm_sata_write32(addr, sm_sata_read32(addr));
		lprintf(4, "\n\t PxCI   = 0x%08x", sm_sata_read32(sata_ahci_port_base + CI0__ADDR));
		lprintf(4, "\n\t PxSACT = 0x%08x", sm_sata_read32(sata_ahci_port_base + SACT0__ADDR));
		break;
	case 7:		// IRQ
		addr  = sata_ahci_port_base + IS0__ADDR;
		temp1 = sm_sata_read32(addr);
		addr  = sata_ahci_port_base + IE0__ADDR;
		temp2 = sm_sata_read32(addr);
		data  = temp1 & temp2;
		break;
	case 8:
		addr = sata_ahci_port_base + IS0__ADDR;
		temp1 = sm_sata_read32(addr);
		sm_sata_write32(addr, temp1);
		addr = sata_ahci_base + IS__ADDR;
		temp2 = sm_sata_read32(addr);
		sm_sata_write32(addr, temp2);
		addr = sata_ahci_base + SERR0__ADDR;
		temp3 = sm_sata_read32(addr);
		sm_sata_write32(addr, temp3);
		lprintf(4, "\n\t PxIS   before = 0x%08x   after = 0x%08x", temp1, sm_sata_read32(sata_ahci_port_base + IS0__ADDR));
//		lprintf(4, "\n\t IS     before = 0x%08x   after = 0x%08x", temp2, sm_sata_read32(sata_ahci_base + IS__ADDR));
		lprintf(4, "\n\t PxSERR before = 0x%08x   after = 0x%08x", temp3, sm_sata_read32(sata_ahci_port_base + SERR0__ADDR));
		lprintf(4, "\n\t PxCI   = 0x%08x", sm_sata_read32(sata_ahci_port_base + CI0__ADDR));
		lprintf(4, "\n\t PxSACT = 0x%08x", sm_sata_read32(sata_ahci_port_base + SACT0__ADDR));
		break;
	case 9:		// IRQ
		printf("\n =====> SATA Port%d INTERRUPT OCCURRED <===== ", port);
		addr = sata_ahci_port_base + IS0__ADDR;
		sm_host_read32(addr, &data);
		printf("\n P%dIS = 0x%08X", port, data);
		data &= sm_sata_read32(sata_ahci_port_base + IE0__ADDR);
		switch(data){
		case (1 << 0):
			printf("\n\t [0] Device to Host Register FIS Interrupt(DHRS)");
			break;
		case (1 << 1):
			printf("\n\t [1] PIO Setup FIS Interrupt (PSS)");
			break;
		case (1 << 2):
			printf("\n\t [2] DMA Setup FIS Interrupt (DSS)");
			break;
		case (1 << 3):
			printf("\n\t [3] Set Device Bits FIS Interrupt (SDBS)");
			break;
		case (1 << 4):
			printf("\n\t [4] Unknown FIS Interrupt (UFS)");
			break;
		case (1 << 5):
			printf("\n\t [5] Descriptor Processed (DPS)");
			break;
		case (1 << 6):
			printf("\n\t [6] Port Connect Change Status (PCS)");
			break;
		case (1 << 7):
			printf("\n\t [7] Device Mechanical Presence Status (DMPS)");
			break;
		case (1 << 22):
			printf("\n\t [22] PHY Ready Change Status (PRCS)");
			printf("\n\t P%dSERR = 0x%08X", port, sm_sata_read32(sata_ahci_port_base + SERR0__ADDR));
			break;
		case (1 << 23):
			printf("\n\t [23] Incorrect Port Multiplier Status (IPMS)");
			break;
		case (1 << 24):
			printf("\n\t [24] Overflow Status (OFS)");
			break;
		case (1 << 26):
			printf("\n\t [26] Interface Non-fatal Error Status (INFS)");
			break;
		case (1 << 27):
			printf("\n\t [27] Interface Fatal Error Status (IFS)");
			break;
		case (1 << 28):
			printf("\n\t [28] Host Bus Data Error Status (HBDS)");
			break;
		case (1 << 29):
			printf("\n\t [29] Host Bus Fatal Error Status (HBFS)");
			break;
		case (1 << 30):
			printf("\n\t [30] Task File Error Status (TFES)");
			break;
		case (1 << 31):
			printf("\n\t [31] Cold Port Detect Status (CPDS)");
			break;
		default:
			printf("\n\t Unknown interrupt");
			break;
		}
		sm_host_read32(addr, &data);
		sm_host_write32(addr, data);
		addr = sata_ahci_port_base + SERR0__ADDR;
		sm_host_read32(addr, &data);
		sm_host_write32(addr, data);
		addr = sata_ahci_base + IS__ADDR;
		sm_host_read32(addr, &data);
		sm_host_write32(addr, data);
		break;
		case 10:	// HOTPLUG
			printf("\n =====> SATA Port%d INTERRUPT OCCURRED <===== ", port);
			sm_host_read32(sata_ahci_port_base + SSTS0__ADDR, &data);
			printf("\n P%dSSTS = 0x%08X", port, data);
			sm_host_read32(sata_ahci_port_base + SERR0__ADDR, &data);
			printf("\n P%dSERR = 0x%08X", port, data);
			sm_host_read32(sata_ahci_port_base + IS0__ADDR, &data);
			printf("\n P%dIS   = 0x%08X", port, data);
			if(data & (1 << 22)){
				sm_host_read32(sata_ahci_port_base + SSTS0__ADDR, &data);
				if(data & (0xF << 8)){
					if(data & (0xF << 4))
						printf("\n\t Device PLUGGED IN and re-linked at GEN%d\n", (data & 0xF0) >> 4);
					else
						printf("\n\t Device PLUGGED IN and re-linked FAILED\n");
				}
				else
					printf("\n\t Device UNPLUGGED \n");
			}
			sm_host_write32(sata_ahci_port_base + SERR0__ADDR, 0xFFFFFFFF);
			sm_host_write32(sata_ahci_port_base + IS0__ADDR, ALL_IRQS);
			addr = sata_ahci_base + IS__ADDR;
			sm_host_read32(addr, &data);
			sm_host_write32(addr, data);
			break;
		case 11:	// ASR
			printf("\n =====> SATA Port%d INTERRUPT OCCURRED <===== ", port);
			sm_host_read32(sata_ahci_port_base + IS0__ADDR, &data);
			//printf("\n P%dIS   = 0x%08X", port, data);
			if(data == ((1 << 6) | (1 << 22))){
				printf("\n\t Device PLUGGED IN");
				sm_sata_port_status(port);
				printf("\n\n");
				sm_host_write32(sata_ahci_port_base + SERR0__ADDR, 1 << 16);
			}
			if(data == (1 << 22)){
				printf("\n\t Device UNPLUGGED");
				sm_sata_port_status(port);
				printf("\n\n");
				sm_host_write32(sata_ahci_port_base + SERR0__ADDR, 1 << 16);
			}
			sm_host_write32(sata_ahci_port_base + SERR0__ADDR, 0xFFFFFFFF);
			sm_host_write32(sata_ahci_port_base + IS0__ADDR, ALL_IRQS);
			addr = sata_ahci_base + IS__ADDR;
			sm_host_read32(addr, &data);
			sm_host_write32(addr, data);
			break;
		case 12:	// AN
			printf("\n =====> SATA Port%d INTERRUPT OCCURRED <===== ", port);
			sm_host_read32(sata_ahci_port_base + SNTF0__ADDR, &data);
			printf("\n A hotplug occured on PMP%d_%d", port, data & 0xFFFF);
			break;
	default:
#if 0
		// CCC_PORTS
		addr = sata_ahci_base + CCC_CTL__ADDR;
		data = sm_sata_read32(addr);
		printf("\n\t CCC_CTL = 0x%08x", data);
		addr = sata_ahci_base + CCC_PORTS__ADDR;
		data = sm_sata_read32(addr);
		printf("\n\t CCC_PORTS = 0x%08x", data);
		addr = sata_ahci_base + CCC_PORTS__ADDR;
		data = sm_sata_read32(addr);
	//	if((data & 1) > 0) printf("\n\t CCC Interrupt on Port 0");
	//	if((data & 2) > 0) printf("\n\t CCC Interrupt on Port 1");
#endif
		// PxIS
		addr = sata_ahci_port_base + IS0__ADDR;
		do{
			sm_host_read32(addr, & data);
		//	printf("\n\t PxIS = 0x%08x", data);
			if(data & (1 << 0)) lprintf(6, "\n\t [0] Device to Host Register FIS Interrupt(DHRS) -> Clear");
			if(data & (1 << 1)) lprintf(6, "\n\t [1] PIO Setup FIS Interrupt (PSS) -> Clear");
			if(data & (1 << 2)) lprintf(6, "\n\t [2] DMA Setup FIS Interrupt (DSS) -> Clear");
			if(data & (1 << 3)) lprintf(6, "\n\t [3] Set Device Bits FIS Interrupt (SDBS)");
			if(data & (1 << 4)) lprintf(6, "\n\t [4] Unknown FIS Interrupt (UFS)");
			if(data & (1 << 5)) lprintf(6, "\n\t [5] Descriptor Processed (DPS) -> Clear");
			if(data & (1 << 6)){
				lprintf(6, "\n\t [6] Port Connect Change Status (PCS) -> Clear");
				sm_sata_write32(sata_ahci_port_base + SERR0__ADDR, 1 << 26);
			}
			if(data & (1 << 7)) lprintf(6, "\n\t [7] Device Mechanical Presence Status (DMPS)");
			if(data & (1 << 22)){
				lprintf(6, "\n\t [22] PHY Ready Change Status (PRCS)");
				sm_sata_write32(sata_ahci_port_base + SERR0__ADDR, 1 << 16);
			}
			if(data & (1 << 23)) lprintf(6, "\n\t [23] Incorrect Port Multiplier Status (IPMS)");
			if(data & (1 << 24)) lprintf(6, "\n\t [24] Overflow Status (OFS)");
			if(data & (1 << 26)){
				lprintf(6, "\n\t [26] Interface Non-fatal Error Status (INFS)");
				sm_sata_pxserr(port);
			}
			if(data & (1 << 27)){
				lprintf(6, "\n\t [27] Interface Fatal Error Status (IFS)");
				sm_sata_pxserr(port);
			}
			if(data & (1 << 28)) lprintf(6, "\n\t [28] Host Bus Data Error Status (HBDS)");
			if(data & (1 << 29)) lprintf(6, "\n\t [29] Host Bus Fatal Error Status (HBFS)");
			if(data & (1 << 30)){
				lprintf(6, "\n\t [30] Task File Error Status (TFES)");
				sm_sata_pxserr(port);
			}
			if(data & (1 << 31)) lprintf(6, "\n\t [31] Cold Port Detect Status (CPDS)");

			sm_sata_write32(addr, data);

		}while(sm_sata_read32(addr));
		addr = sata_ahci_base + IS__ADDR;
		sm_sata_write32(addr, sm_sata_read32(addr));
		lprintf(6, "\n\t IS     = 0x%08x", sm_sata_read32(addr));
#if 0
		addr = sata_ahci_port_base + IS0__ADDR;
		sm_sata_write32(addr, data);
		data = sm_sata_read32(addr);
		data &= ~((1 << 25) | (0xFFFF << 8));
		if(data == 0){
			addr = sata_ahci_base + IS__ADDR;
			sm_sata_write32(addr, sm_sata_read32(addr));
			lprintf(6, "\n\t IS     = 0x%08x", sm_sata_read32(addr));
		}
#endif
		data = sm_sata_read32(sata_ahci_port_base + CI0__ADDR);
		lprintf(6, "\n\t PxCI   = 0x%08x", data);
		data = sm_sata_read32(sata_ahci_port_base + SACT0__ADDR);
		lprintf(6, "\n\t PxSACT = 0x%08x", data);
		break;
	}
}

void sm_sata_irq1(void){
	sm_sata_irq(SM_SATA_01_AHCI_BASE__ADDR);
}

void sm_sata_irq2(void){
	sm_sata_irq(SM_SATA_23_AHCI_BASE__ADDR);
}

void sm_sata_irq3(void){
	sm_sata_irq(SM_SATA_45_AHCI_BASE__ADDR);
}

void sm_sata_reg_irq(int port){
	u32 data;

	lprintf(6, "\n##### sm_sata_reg_irq - START #####");
    // Run irq handler function one time only
	lprintf(7, "\n GICD_ICFGR10");
	data = sm_sata_read32(0x78010c28);
	sm_sata_write32(0x78010c28, ~0);

	lprintf(6, "\n\t Registering IRQ for SATA Port%d", port);
	if((port == 0) || (port == 1)){
		register_irq_handler(166, sm_sata_irq1);
	}
	else if((port == 2) || (port == 3)){
		register_irq_handler(167, sm_sata_irq2);
	}
	else if((port == 4) || (port == 5)){
		register_irq_handler(168, sm_sata_irq3);
	}
	else
		lprintf(5, "\n\n [ERROR]: WRONG SATA PORT NUMBER \n\n");

	lprintf(6, "\n##### sm_sata_reg_irq - END ####");
}

int sm_sata_enet_muxing(int port){
	u32 addr32, data32;
	u32 sata_csr_base = sm_sata_get_csr_base(port);

	lprintf(6, "\n##### sm_sata_enet_muxing #####");
	if(port < 4){		// only for SATA Port 0 to 3
		lprintf(6, "\n SATA Controller%d CSR BASE = 0x%08x", port/2, sata_csr_base);
		lprintf(6, "\n Selecting SATA/ENET Clock for SATA Controller%d ...", port/2);
		lprintf(7, "\n SATA_ENET_CONFIG_REG [0]");
		addr32 = sata_csr_base + SATA_ENET_CONFIG_REG__ADDR;
		data32 = sm_sata_read32(addr32);
		data32 &= ~(0x1);
		sm_sata_write32(addr32, data32);
		data32 = sm_sata_read32(addr32);
		if(data32 & 0x1){
			lprintf(3, "\n\t [ERROR]: SATA Controller %d - SATA/ENET muxing = ENET", port/2);
			return -1;
		} else
			lprintf(4, "\n\t SATA Controller %d - SATA/ENET muxing = SATA", port/2);
	}
	return 0;
}

int sm_sata_clk_rst(int port){
	int rc = 0;
    int data, addr;
    u32 sata_csr_base = sm_sata_get_csr_base(port);

    lprintf(6, "\n##### sm_sata_clk_rst #####");
	if(sata_csr_base != 0){
		/* Set environment to Pre-PowerUp State */
		lprintf(6, "\n SATA Controller%d - Disable then Enable all reset ", port/2);
		addr = sata_csr_base + SATASRESETREG__ADDR;
		sm_sata_write32(addr, 0);			// disable
		rc += sm_sata_write32(addr, 0x3F);	// enable

		lprintf(6, "\n SATA Controller%d - Disable and Enable all clocks", port/2);
		addr = sata_csr_base + SATACLKENREG__ADDR;
		sm_sata_write32(addr, 0);			// disable
		rc += sm_sata_write32(addr, 0x39);	// enable

		lprintf(6, "\n Pull CSR, SDS_CSR, and AHB are out of Reset.");
		lprintf(7, "\n SATASRESETREG [5:0]");			// ~(01 1101) = 0x22
		addr = sata_csr_base + SATASRESETREG__ADDR;
		data = sm_sata_read32(addr);
		data &= ~(1 << 2);	// sata_sds_reset: includes SDS_CSR related logic when the mux has selected SATA
		data &= ~(1 << 0);	// sata_csr_reset: SATA CSR Sort Reset
		rc += sm_sata_write32(addr, data);
		if(rc)
			lprintf(4, "\n\t [ERROR]: SATA Controller %d Clock Reset ... FAILED", port/2);
		else
			lprintf(4, "\n\t SATA Controller %d - Clock Reset ... DONE", port/2);
	}
    return rc;
}

int sm_sata_core_ena(int port){
	u32 sata_csr_base = sm_sata_get_csr_base(port);
    u32 addr32, data32;

    lprintf(6, "\n##### sm_sata_core_ena - START #####");
	addr32 = sata_csr_base + SATACLKENREG__ADDR;
	sm_sata_write32(addr32, 0x3F);
	sm_sata_msdelay(1);
	addr32 = sata_csr_base + SATASRESETREG__ADDR;
	data32 = sm_sata_read32(addr32);
	data32 &= ~((1 << 4) | (1 << 1));
	sm_sata_write32(addr32, data32);
	sm_sata_msdelay(1);
	sm_host_read32(addr32, &data32);
	data32 &= ~(1 << 3);
	sm_sata_write32(addr32, data32);
	sm_sata_msdelay(1);
	lprintf(6, "\n##### sm_sata_core_ena - END #####\n");
    return 0;
}

int sm_sata_mem_ena(int port){
	int rc = 0;
    int data32, timeout;
    u32 sata_csr_base = sm_sata_get_csr_base(port);
    u32 addr;

    lprintf(6, "\n##### sm_sata_mem_ena - START #####");

	lprintf(6, "\n Pull SATA MEM out of Reset");
    addr = sata_csr_base + SATASRESETREG__ADDR;
    data32 = sm_sata_read32(addr);
    data32 &= ~(0x1 << 5);
    sm_sata_write32(addr, data32);

	lprintf(6, "\n\n Shutdown Memory Ram ...");
	lprintf(7, "\n CFG_MEM_RAM_SHUTDOWN");
    addr = sata_csr_base + CFG_MEM_RAM_SHUTDOWN__ADDR;
    sm_sata_write32(addr, 0);
    data32 = sm_sata_read32(addr);

	lprintf(6, "\n\n Check Block Memory Ready ...");
	lprintf(7, "\n BLOCK_MEM_RDY");
    addr = sata_csr_base + BLOCK_MEM_RDY__ADDR;
    timeout = 1000;
    do{
    	sm_sata_msdelay(1);
    	data32 = sm_sata_read32(addr);
    }while((data32 != 0xFFFFFFFF) && (--timeout));
    data32 = sm_sata_read32(addr);
    if(timeout == 0)
    	++rc;
	lprintf(6, "\n##### sm_sata_mem_ena - END #####\n");
    return rc;
}

void sm_sata_portcfg_sel(int port){
    u32 data;
	u32 sata_ahci_base = sm_sata_get_ahci_base(port);
    u32 addr;

    // select port of port
	lprintf(6, "\n Selecting Channel for SATA%d ...", port);
	lprintf(7, "\n PORTCFG [5:0]");
	addr = sata_ahci_base + PORTCFG__ADDR;
	data = sm_sata_read32(addr);
	/* [5:0] PORTADDR
	 * Port Address
	 * Port00Addr = 6'h02 Address port 0 configuration / status register set
	 * Port01Addr = 6'h03 Address port 1 configuration / status register set
	 */
	data &= ~0x3f;		// PORTADDR[5:0] = 11 1111 = 3F
	data |= ((port % 2) == 0) ? 2 : 3;
	sm_sata_write32(addr, data);
	data = sm_sata_read32(addr);
	if((data & 0x3F) == 0x2){
		lprintf(6, "\n\t Channel 0 is selected");
	}
	else if((data & 0x3F) == 0x3){
		lprintf(6, "\n\t Channel 1 is selected");
	}
	else{
		lprintf(5, "\n\t [ERROR]: No channel is selected");
	}
}

void sm_sata_ceva_cfg(int port){
    u32 data;
	u32 sata_ahci_base = sm_sata_get_ahci_base(port);
    u32 addr;
    u32 PORTPHY1CFG__VALUE = 0x0001fffe;
    u32 PORTPHY2CFG__VALUE = 0x5018461c;
    u32 PORTPHY3CFG__VALUE = 0x1c081907;
    u32 PORTPHY4CFG__VALUE = 0x1c080815;
    u32 PORTAXICFG__VALUE;

    lprintf(6, "\n##### sm_sata_port_cfg - START #####");

    // select port of port
	lprintf(6, "\n Selecting Channel for SATA%d ...", port);
	lprintf(7, "\n PORTCFG [5:0]");
	addr = sata_ahci_base + PORTCFG__ADDR;
	data = sm_sata_read32(addr);
	/* [5:0] PORTADDR
	 * Port Address
	 * Port00Addr = 6'h02 Address port 0 configuration / status register set
	 * Port01Addr = 6'h03 Address port 1 configuration / status register set
	 */
	data &= ~0x3f;		// PORTADDR[5:0] = 11 1111 = 3F
	data |= ((port % 2) == 0) ? 2 : 3;
	sm_sata_write32(addr, data);
	data = sm_sata_read32(addr);
	if((data & 0x3F) == 0x2){
		lprintf(6, "\n\t Channel 0 is selected");
	}
	else if((data & 0x3F) == 0x3){
		lprintf(6, "\n\t Channel 1 is selected");
	}
	else{
		lprintf(5, "\n\t [ERROR]: No channel is selected");
	}

	// disable Fixed Rate & disable Filter
	addr = sata_ahci_base + PORTPHY1CFG__ADDR;
	lprintf(7, "\n\n PORTPHY1CFG");
	sm_sata_write32(addr, PORTPHY1CFG__VALUE);	// set time period for ALIGN during speed negotiation
	addr = sata_ahci_base + PORTPHY2CFG__ADDR;
	lprintf(7, "\n\n PORTPHY2CFG");
	sm_sata_write32(addr, PORTPHY2CFG__VALUE);
	addr = sata_ahci_base + PORTPHY3CFG__ADDR;
	lprintf(7, "\n\n PORTPHY3CFG");
	sm_sata_write32(addr, PORTPHY3CFG__VALUE);
	addr = sata_ahci_base + PORTPHY4CFG__ADDR;
	lprintf(7, "\n\n PORTPHY4CFG");
	sm_sata_write32(addr, PORTPHY4CFG__VALUE);
	addr = sata_ahci_base + PORTPHY5CFG__ADDR; 
	lprintf(7, "\n\n PORTPHY5CFG");
	data = sm_sata_read32(addr);
	data &= ~(0xFFF << 20);		// RTCHG[31:20] = 1111 1111 1111 = 0xFFF
	//data |= 0x300 << 20;
	data |= 0x700 << 20; //kqngo@apm update for down gen 3-->2 bug  
	sm_sata_write32(addr, data);
	addr = sata_ahci_base + PORTAXICFG__ADDR;
	lprintf(7, "\n\n PORTAXICFG");
	data = sm_sata_read32(addr);
	data |= 1 << 24;
	data |= 0xE << 20;	// [23:20] Outstanding Transfer Limit
	sm_sata_write32(addr, data);
	if(WATERMARK){
		addr = sata_ahci_base + PORTRANSCFG__ADDR;
		data = 0x30;
		sm_sata_write32(addr, data);
	}

	lprintf(6, "\n##### sm_sata_ceva_config - END #####\n");
}

void sm_sata_spd_cfg(int port){
    u32 data;
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);
    u32 addr;

    lprintf(6, "\n##### sm_sata_spd_cfg #####");

	lprintf(6, "\n P%dSCTL [7:4] - Speed Allowed: ...", port);
	addr = sata_ahci_port_base + SCTL0__ADDR;
	data = sm_sata_read32(addr);
	data &= 0xF << 4;
	switch(LINK_GEN){
	case 1:
		data |= 1 << 4;
		lprintf(5, "\n\t Limit speed negotiation to GEN 1 ONLY");
		break;
	case 2:
		data |= 2 << 4;
		lprintf(5, "\n\t Limit speed negotiation to a rate not greater than GEN 2");
		break;
	case 3:
		data |= 3 << 4;
		lprintf(5, "\n\t Limit speed negotiation to a rate not greater than GEN 3");
		break;
	default:
		data |= 0 << 4;
		lprintf(5, "\n\t No speed negotiation restrictions");
		break;
	}
	sm_sata_write32(addr, data);
}

void sm_sata_customer_pin_mode_cfg(int port){
    u32 data32;
    u32 sata_csr_base = sm_sata_get_csr_base(port);

    lprintf(6, "\n##### sm_sata_customer_pin_mode_cfg #####");

    /*
	 * We have two ways to program SERDES:
	 *	- Indirect Way when cfg_i_customer_pin_mode = 0
	 * 	  by indirect register set:
	 * 		SATA_SDS_IND_CMD
	 * 		SATA_SDS_IND_RDATA
	 * 		SATA_SDS_IND_WDATA
	 * 	- Direct Way when cfg_i_customer_pin_mode = 1
	 * 	  by CSR registers
	 */
	lprintf(6, "\n Modifying Customer Pin Mode ...");
	sm_host_read32(sata_csr_base + SATA_ENET_SDS_CTL0__ADDR, &data32);
    data32 &= ~0x7FFF;
    data32 |= 0x4421;
    sm_sata_write32(sata_csr_base + SATA_ENET_SDS_CTL0__ADDR, data32);
    lprintf(5, "\n\t Customer Pin Mode = 0x%04X", data32);
}

void sm_sata_sds_csr_cfg(int port){
	int timeout;
	u32 cpm;	// Customer Pin Mode
	u32 data;
	u32 sata_csr_base = sm_sata_get_csr_base(port);
	u32 addr;

	lprintf(6, "\n##### sm_sata_sds_csr_cfg #####");

	addr = sata_csr_base + SATA_ENET_SDS_CTL0__ADDR;
	cpm = sm_sata_read32(addr);
	cpm &= 0x7FFF;		// cfg_i_customer_pin_mode
	/*
	 * SERDES RX Reference voltage threshold value 	[27:24] 	0011	(77.5mv)
	 *
	 * Configure Rx/Tx Data rate
	 *
	 * When bit cfg_i_customer_pin_mode[0] is set
	 */
	lprintf(7, "\n SATA_ENET_SDS_PCS_CTL0 [20:19], [15:14]");
	addr = sata_csr_base + SATA_ENET_SDS_PCS_CTL0__ADDR;
	data = sm_sata_read32(addr);
	if(cpm & (1 << 4)){		// pin 4 is set
		/* [24:27] cfg_i_rx_sd_threshold
		 * SERDES RX Reference voltage threshold value for LOS detection
		 * 1111: TBD
		 * 0010: 65mv
		 * 0000: 40mv
		 */
		data &= ~(0xF << 24);
		data |= 3 << 24;
	}
	if(cpm & (1 << 5)){		// pin 5 is set
		/* [28:28] cfg_i_tx_idle
		 * SERDES Set TX into electrical Idle.
		 * 0 : normal operation
		 * 1 : Electrical Idle mode SERDES Per lane word mode
		 * When bit 5 of cfg_i_customer_pin_mode is set, this register will be used to drive input of SERDES
		 */
		data &= ~(1 << 5);
	}
	if(cpm & (1 << 0)){		// pin 0 is set
		/* [23:21] cfg_i_rx_wordmode
		 * [18:16] cfg_i_tx_wordmode
		 * SERDES Per lane word mode
		 * 000: 08 bit mode
		 * 001: 10 bit mode
		 * 010: 16 bit mode
		 * 011: 20 bit mode
		 * 100: 32 bit mode
		 * 101: 40 bit mode
		 * 110: 64 bit mode
		 * 111: 66 bit mode
		 * When bit 0 of cfg_i_customer_pin_mode is set, this register will be used to drive input of SERDES
		 */
		data &= ~((7 << 16) | (7 << 21));
		data |= ((3 << 16) | (3 << 21));
	}
	sm_sata_write32(addr, data);
}

int sm_sata_get_csr_base(int port){
    if((port == 0) | (port == 1)){
    	return SM_SATA_01_CSR_BASE__ADDR;
    }
    else if((port == 2) | (port == 3)){
    	return SM_SATA_23_CSR_BASE__ADDR;
    }
    else if((port == 4) | (port == 5)){
    	return SM_SATA_45_CSR_BASE__ADDR;
    }
    else
    	return 0;
}

int sm_sata_get_ahci_base(int port){
    if((port == 0) | (port == 1)){
    	return SM_SATA_01_AHCI_BASE__ADDR;
    }
    else if((port == 2) | (port == 3)){
    	return SM_SATA_23_AHCI_BASE__ADDR;
    }
    else if((port == 4) | (port == 5)){
    	return SM_SATA_45_AHCI_BASE__ADDR;
    }
    else
    	return 0;
}

int sm_sata_get_ahci_port_base(int port){
    if(port == 0)
    	return SM_SATA_01_AHCI_BASE__ADDR;
    else if(port == 1)
    	return SM_SATA_01_AHCI_BASE__ADDR + 0x80;
    else if(port == 2)
    	return SM_SATA_23_AHCI_BASE__ADDR;
    else if(port == 3)
    	return SM_SATA_23_AHCI_BASE__ADDR + 0x80;
    else if(port == 4)
    	return SM_SATA_45_AHCI_BASE__ADDR;
    else if(port == 5)
    	return SM_SATA_45_AHCI_BASE__ADDR + 0x80;
    else
    	return 0;
}

int sm_pcie2_sds_calib(void){
    int csr_base = PCIE2_CSR_BASE;
    int timeout;
    u32 addr, data32;

    if(PVT_MAN){
		// TERM CALIBRATION CH0
		addr = SM_PCIE_KC_CLKMACRO + CMU_REG17*2;
		data32 = kc_sds_rd(csr_base, addr);
		data32 &= ~(0x7F << 8);	// pvt_code_r2a
		//data32 |= 0xD << 8;
		data32 |= 0x12 << 8;	// Poly requested 102213
		data32 &= ~(0x7 << 5);	// RESERVED - RO bits, Channel 0
		kc_sds_wr(csr_base, addr, data32);

		data32 = kc_sds_rd(csr_base, addr);
		data32 |= 1 << 15;		// Enable term calibration manual mode
		kc_sds_wr(csr_base, addr, data32);
		data32 = kc_sds_rd(csr_base, addr);
		data32 &= ~(1 << 15);	// Disable term calibration manual mode
		kc_sds_wr(csr_base, addr, data32);

		// DOWN CALIBRATION CH0
		addr = SM_PCIE_KC_CLKMACRO + CMU_REG17*2;
		data32 = kc_sds_rd(csr_base, addr);
		data32 &= ~(0x7F << 8);
		data32 |= 0x29 << 8;	// A3 change
		data32 &= ~(7 << 5);	// RESERVED - RO bits, Channel 0
		kc_sds_wr(csr_base, addr, data32);

		addr = SM_PCIE_KC_CLKMACRO + CMU_REG16*2;
		data32 = kc_sds_rd(csr_base, addr);
		data32 |= 1;	// Enable pull down calibration manual mode
		kc_sds_wr(csr_base, addr, data32);
		data32 = kc_sds_rd(csr_base, addr);
		data32 &= ~1;	// Disable pull down calibration manual mode
		kc_sds_wr(csr_base, addr, data32);

		// UP CALIBRATION CH0
		addr = SM_PCIE_KC_CLKMACRO + CMU_REG17*2;
		data32 = kc_sds_rd(csr_base, addr);
		data32 &= ~(0x7F << 8);
		data32 |= 0x28 << 8;
		data32 &= ~(7 << 5);	// RESERVED - RO bits, Channel 0
		kc_sds_wr(csr_base, addr, data32);

		addr = SM_PCIE_KC_CLKMACRO + CMU_REG16*2;
		data32 = kc_sds_rd(csr_base, addr);
		data32 |= 1 << 1;	// Enable pull up calibration manual mode
		kc_sds_wr(csr_base, addr, data32);
		data32 = kc_sds_rd(csr_base, addr);
		data32 &= ~(1 << 1);	// Disable pull up calibration manual mode
		kc_sds_wr(csr_base, addr, data32);
    }

	// Check for PLL calibration
	timeout = 100;
	do{
		sm_sata_msdelay(10);
		data32 = kc_sds_rd(csr_base, SM_PCIE_KC_CLKMACRO + CMU_REG7*2);
	}while(((data32 & 0x4000) == 0) && --timeout);	// [14] pll_calib_done: VCO calibration complete status bit
	if(timeout){
		lprintf(5, "\n\t PCIE2 - VCO calibration completed");
	}
	else{
		lprintf(5, "\n\t [ERROR]: PCIE2 - VCO calibration NOT completed");
	}

	data32 = kc_sds_rd(csr_base, SM_PCIE_KC_CLKMACRO + CMU_REG7*2);
	if(data32 & 0x0C00){	// [11:10] vco_cal_fail: VCO calibration state machine status bits
		lprintf(5, "\n\t [ERROR]: PCIE2 - VCO calibration FAILED");
#if 0	// 092413: no need
		// Put PCIE2 Clock Macro in reset
		lprintf(5, "\n\t Put PCIE2 Clock Macro in reset");
		addr = csr_base + PCIE_CLK_MACRO_REG__ADDR;
		sm_host_read32(addr, &data32);
		data32 &= ~(0x1F << 7);		// i_customerOV
		data32 &= ~1;				// i_reset_b
		sm_host_write32(addr, data32);
		sm_sata_msdelay(100);
#endif
		return -1;
	}
	else
		lprintf(5, "\n\t PCIE2 - VCO calibration PASSED");

	return 0;
}

void sm_sata_sds_pdown_force_vco1(int port){
	u32 addr, data32, reg_offset, clkref_offset;
	u32 csr_base;

	csr_base = sm_sata_get_csr_base(port);
	if(CLK_TYPE){
		clkref_offset = SM_PCIE_KC_CLKMACRO;
		if((port/2) == 2){
			csr_base = PCIE2_CSR_BASE;
			lprintf(4, "\n\t PCIE2 VCO Power Down Force");
		}
		else
			lprintf(4, "\n\t SATA-PCIE2 VCO Power Down Force");
	}else{
		clkref_offset = 0;
		lprintf(4, "\n\t SATA VCO Power Down Force");
	}

	reg_offset = clkref_offset + CMU_REG0*2;
	data32 = kc_sds_rd(csr_base, reg_offset);
	data32 |= 1 << 14;		// pdown
	kc_sds_wr(csr_base, reg_offset, data32);
	sm_sata_msdelay(10);

#if 0	// 092413 no need
	// Adding Pll reset
	reg_offset = clkref_offset + CMU_REG5*2;
	data32 = kc_sds_rd(csr_base, reg_offset);
	data32 &= ~1;			// pll_resetb
	kc_sds_wr(csr_base, reg_offset, data32);
	sm_sata_msdelay(100);
	data32 |= 1;
	kc_sds_wr(csr_base, reg_offset, data32);
#endif

	reg_offset = clkref_offset + CMU_REG0*2;
	data32 = kc_sds_rd(csr_base, reg_offset);
	data32 &= ~(1 << 14);	// [14] pdown: CMU power down
	kc_sds_wr(csr_base, reg_offset, data32);
	sm_sata_msdelay(10);

	reg_offset = clkref_offset + CMU_REG32*2;
	data32 = kc_sds_rd(csr_base, reg_offset);
	data32 |= 1 << 14;			// force_vcocal_start
	kc_sds_wr(csr_base, reg_offset, data32);
	sm_sata_msdelay(10);
	data32 &= ~(1 << 14);
	kc_sds_wr(csr_base, reg_offset, data32);
}

void sm_pcie2_sds_pdown_force_vco(void){
	u32 addr, data32;
	u32 pcie2_csr_base = PCIE2_CSR_BASE;

	lprintf(6, "\n##### sm_pcie2_sds_pdown_force_vco #####");

	addr = SM_PCIE_KC_CLKMACRO + CMU_REG0*2;
	data32 = kc_sds_rd(pcie2_csr_base, addr);
	data32 |= 1 << 14;		// pdown
	kc_sds_wr(pcie2_csr_base, addr, data32);
	sm_sata_msdelay(10);

#if 0
	// Adding Pll reset
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG5*2;
	data32 = kc_sds_rd(pcie2_csr_base, addr);
	data32 &= ~1;			// pll_resetb
	kc_sds_wr(pcie2_csr_base, addr, data32);
	sm_sata_msdelay(100);
	data32 |= 1;
	kc_sds_wr(pcie2_csr_base, addr, data32);
#endif

	addr = SM_PCIE_KC_CLKMACRO + CMU_REG0*2;
	data32 = kc_sds_rd(pcie2_csr_base, addr);
	data32 &= ~(1 << 14);
	kc_sds_wr(pcie2_csr_base, addr, data32);
	sm_sata_msdelay(10);

	addr = SM_PCIE_KC_CLKMACRO + CMU_REG32*2;
	data32 = kc_sds_rd(pcie2_csr_base, addr);
	data32 |= 1 << 14;			// force_vcocal_start
	kc_sds_wr(pcie2_csr_base, addr, data32);
	sm_sata_msdelay(10);
	data32 &= ~(1 << 14);
	kc_sds_wr(pcie2_csr_base, addr, data32);
}

void sm_pcie2_clock_init(void){
    int csr_base = PCIE2_CSR_BASE;
	u32 addr, data32;

	lprintf(6, "\n##### sm_pcie2_clock_init #####");

	// Enable PCIE2 Clock
	lprintf(6, "\n\t PCIE2 Clock Enabling ... ");
	addr = csr_base + PCIE_CLKEN__ADDR;
	/*
	 * [31:4] RESERVED
	 * [3] apb_core_clken: Clock Enable for APB Clk to the PCIe Core
	 * [2] axi_core_clken: Clock Enable for AXI Clk to the PCIe Core
	 * [1] core_clken    : Clock Enable for Core Clk (i.e. PCIE Clk) to the PCIe Core
	 * [0] csr_clken     : Clock Enable for CSR clk to the PCIe Core as well as SERDES logic
	 */
	sm_host_read32(addr, &data32);
	data32 |= 0xF;
	sm_host_write32(addr, data32);
	lprintf(6, "\n\t PCIE2_CLKEN [0x%08X] = 0x%08X", addr, sm_sata_read32(addr));
	sm_sata_msdelay(100);

	// Pull PCIE2 Clock out of Reset
	lprintf(6, "\n\t PCIE2 Clock Going out of Reset ... ");
	addr = csr_base + PCIE_SRST__ADDR;
	/*
	 * [31:9] RESERVED
	 * [8] phy_sds_reset : Phy Soft reset. When active, the serdes and pcs will be reset
	 * [7:4] RESERVED
	 * [3] apb_core_reset: APB register Soft reset. When active, the apb interface of the PCIe core (used for accessing
	 *                     registers specific to PCIE core) will be reset
	 * [2] axi_core_reset: AXI Core Soft reset. When active, the axi master and slave interface of the PCIe core will be reset
	 * [1] core_reset    : Core Soft reset. When active, the PCIE interface of the PCIe core will be reset
	 * [0] csr_reset     : CSR Soft reset. When active, the APM CSR logic as well as SERDES CSR logic will be reset
	 */
	sm_host_read32(addr, &data32);
	data32 &= ~0x10F;
	sm_host_write32(addr, data32);
	lprintf(6, "\n\t PCIE2_SRST  [0x%08X] = 0x%08X", addr, sm_sata_read32(addr));
	sm_sata_msdelay(100);
}

int sm_sata_cmos_clock_init1(int port){
    int csr_base, CLK_MACRO_REG__ADDR;
	int timeout;
	u32 addr, data32;

	lprintf(6, "\n##### sm_sata_cmos_clock_init #####");

	if((port/2) == 2){	// Port45
		csr_base = PCIE2_CSR_BASE;
		CLK_MACRO_REG__ADDR = PCIE_CLK_MACRO_REG__ADDR;
		sm_pcie2_clock_init();
	}
	else{				// Port0123
		csr_base = sm_sata_get_csr_base(port);
		CLK_MACRO_REG__ADDR = SATA_ENET_CLK_MACRO_REG__ADDR;
	}

	/* Configure PCIE Clock Macro */
	// Put the PCIE Clock Macro in reset
	addr = csr_base + CLK_MACRO_REG__ADDR;
	sm_host_read32(addr, &data32);
	data32 &= ~(0x1FF << 12);	// [20:12] i_pll_fbdiv
	data32 &= ~(0x1F << 7);		//  [11:7] i_customerOV
	data32 &= ~1;				//     [0] i_reset_b
	data32 |= 0x27 << 12;
	sm_host_write32(addr, data32);
	sm_host_read32(addr, &data32);
	lprintf(5, "\n\t CLK_MACRO_REG [0x%08X] = [0x%08X]", addr, data32);

	// VCO control voltage threshold setting for calibration
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG34*2;
	//data32 = kc_sds_rd(csr_base, addr);
	data32 = 0x8 << 12;	// vco_cal_vth_hi_min
	data32 |= 0xD << 8;	// vco_cal_vth_hi_max
	data32 |= 0x2 << 4;	// vco_cal_vth_lo_min
	data32 |= 0x7;		// vco_cal_vth_lo_max
	kc_sds_wr(csr_base, addr, data32);

	//CMU_REG0
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG0*2;
	data32 = kc_sds_rd(csr_base, addr);
	data32 &= ~(7 << 5);	// cal_count_resol
	data32 |= 4 << 5;		// Counter tap selection for VCO calibration counter
	kc_sds_wr(csr_base, addr, data32);

	//CMU_REG1
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG1*2;
	data32 = kc_sds_rd(csr_base, addr);
	data32 &= ~(0xF << 10);		// pll_cp
	data32 |= 1 << 10;			// Charge pump current control bits
	data32 &= ~(0x1F << 5);		// pll_cp_sel
	data32 |= 5 << 5;			// Sub Charge pump selection
	data32 &= ~(1 << 3);		// pll_manualcal
	kc_sds_wr(csr_base, addr, data32);

	//CMU_REG2
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG2*2;
	data32 = kc_sds_rd(csr_base, addr);
	data32 &= ~(0x1FF << 5);	// pll_fbdiv
	data32 |= 0x27 << 5;		// PLL feedback divider selection
	data32 &= ~(0xF << 1);		// pll_lfres
	data32 |= 0xA << 1;			// Loop filter resistor control
	kc_sds_wr(csr_base, addr, data32);

	//CMU_REG3
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG3*2;
	data32 = kc_sds_rd(csr_base, addr);
	data32 &= ~(0x3F << 4);	// vco_momsel_init
	data32 |= 0x10 << 4;	// PLL feedback divider selection
	data32 &= ~0xF;			// vcovarsel
	data32 |= 3;			// PLL feedback divider selection
	kc_sds_wr(csr_base, addr, data32);

	//CMU_REG26   Added on 3/23/2013
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG26*2;
	data32 = kc_sds_rd(csr_base, addr);
	data32 &= ~1;		// force_pll_lock
	kc_sds_wr(csr_base, addr, data32);

	//CMU_REG5
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG5*2;
	data32 = kc_sds_rd(csr_base, addr);
	data32 |= 3 << 14;		// pll_lfsmcap
	data32 |= 3 << 12;		// pll_lfcap
	data32 |= 7 << 1;		// pll_lock_resolution
	kc_sds_wr(csr_base, addr, data32);

	//CMU_reg6
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG6*2;
	data32 = kc_sds_rd(csr_base, addr);
	data32 &= ~(3 << 9);	// pll_vregtrim
	if(PVT_MAN)
		data32 |= 1 << 2;		// man_pvt_cal
	else
		data32 &= ~(1 << 2);	// auto PVT Calib
	kc_sds_wr(csr_base, addr, data32);

	//CMU_reg16
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG16*2;
	data32 = kc_sds_rd(csr_base, addr);
	data32 |= 1 << 6;		// Calibration_done_override
	data32 |= 1 << 5;		// Bypass_pll_lock
	data32 &= ~(0x7 << 2);	// vcocal_wait_btw_code
	data32 |= 4 << 2;		// wait between freq band/momsel code changes during VCO calibrations
	kc_sds_wr(csr_base, addr, data32);

	//CMU_reg30
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG30*2;
	data32 = kc_sds_rd(csr_base, addr);
	data32 &= ~(1 << 3);	// pcie_mode
	data32 |= 3 << 1;		// lock_count
	kc_sds_wr(csr_base, addr, data32);
	//
	//CMU_reg31
	kc_sds_wr(csr_base, SM_PCIE_KC_CLKMACRO + CMU_REG31*2, 0xF);

	//CMU_reg32
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG32*2;
	data32 = kc_sds_rd(csr_base, addr);
	data32 |= 3 << 7;		// [8:7] iref_adj
	data32 |= 3 << 1;		// [2:1] pvt_cal_wait_sel
	kc_sds_wr(csr_base, addr, data32);

	//CMU_reg34
	//kc_sds_wr(csr_base, SM_PCIE_KC_CLKMACRO + CMU_REG34*2, 0x2A2A);
	kc_sds_wr(csr_base, SM_PCIE_KC_CLKMACRO + CMU_REG34*2, 0x8D27);

	//CMU_reg37
	kc_sds_wr(csr_base,  SM_PCIE_KC_CLKMACRO + CMU_REG37*2, 0xF00F);

	// Pull Clock Macro out of reset
	addr = csr_base + CLK_MACRO_REG__ADDR;
	lprintf(5, "\n\t Pull Clock Macro out of reset ... ");
	data32 = sm_sata_read32(addr);
	data32 &= ~(0x1F << 7);	// [11:7] i_customerOV
	data32 |= 1;			//    [0] i_reset_b
	sm_host_write32(addr, data32);
	sm_sata_msdelay(250);	// MUST
	sm_host_read32(addr, &data32);
	lprintf(5, "\n\t CLK_MACRO_REG [0x%08X] = [0x%08X]", addr, data32);

	timeout = 5;
	do{
		if(timeout != 5) sm_sata_sds_pdown_force_vco1(port);
	}while((sm_pcie2_sds_calib()) && --timeout);
	if(timeout){
		sm_host_read32(addr, &data32);
		lprintf(5, "\n\t CLK_MACRO_REG [0x%08X] = [0x%08X]", addr, data32);
		if(data32 & (1 << 30))
			lprintf(4, "\n\t Clock Macro LOCKED");
		else{
			lprintf(4, "\n\t [ERROR]: Clock Macro UNLOCKED");
			return -1;
		}

		if(data32 & (1 << 31))
			lprintf(4, "\n\t Clock Macro READY");
		else{
			lprintf(4, "\n\t [ERROR]: Clock Macro NOT READY");
			return -1;
		}
	}
	else
		return -1;
	return 0;
}

int sm_pcie2_cmos_clock_init(void){
    int csr_base = PCIE2_CSR_BASE;
	int timeout;
	u32 addr, data32;

	lprintf(6, "\n##### sm_pcie2_cmos_clock_init #####");

	sm_pcie2_clock_init();

	// Configure PCIE2 Clock Macro
	addr = csr_base + PCIE_CLK_MACRO_REG__ADDR;
	lprintf(5, "\n\t PCIE2 Clock Macro Going in Reset ... ");
	sm_host_read32(addr, &data32);
	data32 &= ~(0x1FF << 12);	// [20:12] i_pll_fbdiv
	data32 &= ~(0x1F << 7);		//  [11:7] i_customerOV
	data32 &= ~1;				//     [0] i_reset_b
	data32 |= 0x27 << 12;
	sm_host_write32(addr, data32);
	sm_host_read32(addr, &data32);
	lprintf(5, "\n\t\t PCIE2_CLK_MACRO_REG [0x%08x] = [0x%08X]", addr, data32);

	// VCO control voltage threshold setting for calibration
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG34*2;
	//data32 = kc_sds_rd(csr_base, addr);
	data32 = 0x8 << 12;	// vco_cal_vth_hi_min
	data32 |= 0xD << 8;	// vco_cal_vth_hi_max
	data32 |= 0x2 << 4;	// vco_cal_vth_lo_min
	data32 |= 0x7;		// vco_cal_vth_lo_max
	kc_sds_wr(csr_base, addr, data32);

	//CMU_REG0
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG0*2;
	data32 = kc_sds_rd(csr_base, addr);
	data32 &= ~(7 << 5);	// cal_count_resol
	data32 |= 4 << 5;		// Counter tap selection for VCO calibration counter
	kc_sds_wr(csr_base, addr, data32);

	//CMU_REG1
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG1*2;
	data32 = kc_sds_rd(csr_base, addr);
	data32 &= ~(0xF << 10);		// pll_cp
	data32 |= 1 << 10;			// Charge pump current control bits
	data32 &= ~(0x1F << 5);		// pll_cp_sel
	data32 |= 5 << 5;			// Sub Charge pump selection
	data32 &= ~(1 << 3);		// pll_manualcal
	kc_sds_wr(csr_base, addr, data32);

	//CMU_REG2
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG2*2;
	data32 = kc_sds_rd(csr_base, addr);
	data32 &= ~(0x1FF << 5);	// pll_fbdiv
	data32 |= 0x27 << 5;		// PLL feedback divider selection
	data32 &= ~(0xF << 1);		// pll_lfres
	data32 |= 0xA << 1;			// Loop filter resistor control
	kc_sds_wr(csr_base, addr, data32);

	//CMU_REG3
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG3*2;
	data32 = kc_sds_rd(csr_base, addr);
	data32 &= ~(0x3F << 4);	// vco_momsel_init
	data32 |= 0x10 << 4;	// PLL feedback divider selection
	data32 &= ~0xF;			// vcovarsel
	data32 |= 3;			// PLL feedback divider selection
	kc_sds_wr(csr_base, addr, data32);

	//CMU_REG26   Added on 3/23/2013
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG26*2;
	data32 = kc_sds_rd(csr_base, addr);
	data32 &= ~1;		// force_pll_lock
	kc_sds_wr(csr_base, addr, data32);

	//CMU_REG5
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG5*2;
	data32 = kc_sds_rd(csr_base, addr);
	data32 |= 3 << 14;		// pll_lfsmcap
	data32 |= 3 << 12;		// pll_lfcap
	data32 |= 7 << 1;		// pll_lock_resolution
	kc_sds_wr(csr_base, addr, data32);

	//CMU_reg6
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG6*2;
	data32 = kc_sds_rd(csr_base, addr);
	data32 &= ~(3 << 9);	// pll_vregtrim
	if(PVT_MAN)
		data32 |= 1 << 2;		// man_pvt_cal
	else
		data32 &= ~(1 << 2);	// auto PVT Calib
	kc_sds_wr(csr_base, addr, data32);

	//CMU_reg16
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG16*2;
	data32 = kc_sds_rd(csr_base, addr);
	data32 |= 1 << 6;		// Calibration_done_override
	data32 |= 1 << 5;		// Bypass_pll_lock
	data32 &= ~(0x7 << 2);	// vcocal_wait_btw_code
	data32 |= 4 << 2;		// wait between freq band/momsel code changes during VCO calibrations
	kc_sds_wr(csr_base, addr, data32);

	//CMU_reg30
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG30*2;
	data32 = kc_sds_rd(csr_base, addr);
	data32 &= ~(1 << 3);	// pcie_mode
	data32 |= 3 << 1;		// lock_count
	kc_sds_wr(csr_base, addr, data32);
	//
	//CMU_reg31
	kc_sds_wr(csr_base, SM_PCIE_KC_CLKMACRO + CMU_REG31*2, 0xF);

	//CMU_reg32
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG32*2;
	data32 = kc_sds_rd(csr_base, addr);
	data32 |= 3 << 7;		// [8:7] iref_adj
	data32 |= 3 << 1;		// [2:1] pvt_cal_wait_sel
	kc_sds_wr(csr_base, addr, data32);

	//CMU_reg34
	//kc_sds_wr(csr_base, SM_PCIE_KC_CLKMACRO + CMU_REG34*2, 0x2A2A);
	kc_sds_wr(csr_base, SM_PCIE_KC_CLKMACRO + CMU_REG34*2, 0x8D27);

	//CMU_reg37
	kc_sds_wr(csr_base,  SM_PCIE_KC_CLKMACRO + CMU_REG37*2, 0xF00F);

	// Pull PCIE2 Clock Macro out of reset
	addr = csr_base + PCIE_CLK_MACRO_REG__ADDR;
	lprintf(5, "\n\t PCIE2 Clock Macro Going out of Reset ... ");
	data32 = sm_sata_read32(addr);
	data32 &= ~(0x1F << 7);	// [11:7] i_customerOV
	data32 |= 1;			//    [0] i_reset_b
	sm_sata_write32(addr, data32);
	sm_sata_msdelay(250);		// MUST
	lprintf(5, "\n\t\t PCIE2_CLK_MACRO_REG [0x%08x] = [0x%08X]", addr, data32);

	timeout = 5;
	addr = csr_base + PCIE_CLK_MACRO_REG__ADDR;
	do{
		if(timeout != 5) sm_pcie2_sds_pdown_force_vco();
	}while((sm_pcie2_sds_calib()) && --timeout);
	if(timeout){
		sm_host_read32(addr, &data32);
		if(data32 & (1 << 30))
			lprintf(4, "\n\t PCIE2 Clock Macro LOCKED");
		else{
			lprintf(4, "\n\t [ERROR]: PCIE2 Clock Macro UNLOCKED");
			return -1;
		}

		if(data32 & (1 << 31))
			lprintf(4, "\n\t PCIE2 Clock Macro READY");
		else{
			lprintf(4, "\n\t [ERROR]: PCIE2 Clock Macro NOT READY");
			return -1;
		}
	}
	else
		return -1;
	return 0;
}

int sm_sata_cmos_clock_init(int port){
	int timeout;
	u32 addr, data32;
	u32 sata_csr_base = sm_sata_get_csr_base(port);

	lprintf(6, "\n##### sm_sata_cmos_clock_init #####");
	/* Configure PCIE Clock Macro */
	// Put the PCIE Clock Macro in reset
	addr = sata_csr_base + SATA_ENET_CLK_MACRO_REG__ADDR;
	sm_host_read32(addr, &data32);
	data32 &= ~(0x1FF << 12);	// i_pll_fbdiv
	data32 &= ~(0x1F << 7);		// i_customerOV
	data32 &= ~1;				// i_reset_b
	data32 |= 0x27 << 12;
	sm_host_write32(addr, data32);
	sm_host_read32(addr, &data32);
	lprintf(6, "\n SATA_ENET_CLK_MACRO_REG [0x%08x] = [0x%08X]", addr, data32);

	// VCO control voltage threshold setting for calibration
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG34 * 2;
	//data32 = kc_sds_rd(sata_csr_base, addr);
	data32 = 0x8 << 12;	// vco_cal_vth_hi_min
	data32 |= 0xD << 8;	// vco_cal_vth_hi_max
	data32 |= 0x2 << 4;	// vco_cal_vth_lo_min
	data32 |= 0x7;		// vco_cal_vth_lo_max
	kc_sds_wr(sata_csr_base, addr, data32);

	//CMU_REG0
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG0 * 2;
	data32 = kc_sds_rd(sata_csr_base, addr);
	data32 &= ~(7 << 5);	// cal_count_resol
	data32 |= 4 << 5;		// Counter tap selection for VCO calibration counter
	kc_sds_wr(sata_csr_base, addr, data32);

	//CMU_REG1
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG1 * 2;
	data32 = kc_sds_rd(sata_csr_base, addr);
	data32 &= ~(0xF << 10);		// pll_cp
	data32 |= 1 << 10;			// Charge pump current control bits
	data32 &= ~(0x1F << 5);		// pll_cp_sel
	data32 |= 5 << 5;			// Sub Charge pump selection
	data32 &= ~(1 << 3);		// pll_manualcal
	kc_sds_wr(sata_csr_base, addr, data32);

	//CMU_REG2
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG2 * 2;
	data32 = kc_sds_rd(sata_csr_base, addr);
	data32 &= ~(0x1FF << 5);	// pll_fbdiv
	data32 |= 0x27 << 5;		// PLL feedback divider selection
	data32 &= ~(0xF << 1);		// pll_lfres
	data32 |= 0xA << 1;			// Loop filter resistor control
	kc_sds_wr(sata_csr_base, addr, data32);

	//CMU_REG3
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG3 * 2;
	data32 = kc_sds_rd(sata_csr_base, addr);
	data32 &= ~(0x3F << 4);	// vco_momsel_init
	data32 |= 0x10 << 4;	// PLL feedback divider selection
	data32 &= ~0xF;			// vcovarsel
	data32 |= 3;			// PLL feedback divider selection
	kc_sds_wr(sata_csr_base, addr, data32);

	//CMU_REG26   Added on 3/23/2013
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG26 * 2;
	data32 = kc_sds_rd(sata_csr_base, addr);
	data32 &= ~1;		// force_pll_lock
	kc_sds_wr(sata_csr_base, addr, data32);

	//CMU_REG5
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG5 * 2;
	data32 = kc_sds_rd(sata_csr_base, addr);
	data32 |= 3 << 14;		// pll_lfsmcap
	data32 |= 3 << 12;		// pll_lfcap
	data32 |= 7 << 1;		// pll_lock_resolution
	kc_sds_wr(sata_csr_base, addr, data32);

	//CMU_reg6
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG6 * 2;
	data32 = kc_sds_rd(sata_csr_base, addr);
	data32 &= ~(3 << 9);	// pll_vregtrim
	if(PVT_MAN)
		data32 |= 1 << 2;		// man_pvt_cal
	else
		data32 &= ~(1 << 2);	// auto PVT Calib
	kc_sds_wr(sata_csr_base, addr, data32);

	//CMU_reg16
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG16 * 2;
	data32 = kc_sds_rd(sata_csr_base, addr);
	data32 |= 1 << 6;		// Calibration_done_override
	data32 |= 1 << 5;		// Bypass_pll_lock
	data32 &= ~(0x7 << 2);	// vcocal_wait_btw_code
	data32 |= 4 << 2;		// wait between freq band/momsel code changes during VCO calibrations
	kc_sds_wr(sata_csr_base, addr, data32);

	//CMU_reg30
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG30 * 2;
	data32 = kc_sds_rd(sata_csr_base, addr);
	data32 &= ~(1 << 3);	// pcie_mode
	data32 |= 3 << 1;		// lock_count
	kc_sds_wr(sata_csr_base, addr, data32);
	//
	//CMU_reg31
	kc_sds_wr(sata_csr_base, SM_PCIE_KC_CLKMACRO + CMU_REG31 * 2, 0xF);

	//CMU_reg32
	addr = SM_PCIE_KC_CLKMACRO + CMU_REG32 * 2;
	data32 = kc_sds_rd(sata_csr_base, addr);
	data32 |= 3 << 7;		// iref_adj
	data32 |= 3 << 1;		// pvt_cal_wait_sel
	kc_sds_wr(sata_csr_base, addr, data32);

	//CMU_reg34
	//kc_sds_wr(sata_csr_base, SM_PCIE_KC_CLKMACRO + CMU_REG34 * 2, 0x2A2A);
	kc_sds_wr(sata_csr_base, SM_PCIE_KC_CLKMACRO + CMU_REG34 * 2, 0x8D27);

	//CMU_reg37
	kc_sds_wr(sata_csr_base, SM_PCIE_KC_CLKMACRO + CMU_REG37 * 2, 0xF00F);

	// Pull SATA Clock Macro out of reset
	addr = sata_csr_base + SATA_ENET_CLK_MACRO_REG__ADDR;
	data32 = sm_sata_read32(addr);
	data32 &= ~(0x3F << 7);	// i_customerOV
	data32 |= 1;			// i_reset_b
	sm_sata_write32(addr, data32);
	sm_sata_msdelay(250);
	timeout = 5;
	while(sm_sata_sds_calib(port) && --timeout) sm_sata_sds_pdown_force_vco(port);
	if(timeout){
		data32 = sm_sata_read32(addr);
		if(data32 & (1 << 30))
			lprintf(5, "\n\t SATA Port%d - Clock Macro LOCKED", port);
		else
			lprintf(5, "\n\t [ERROR]: SATA Port%d - Clock Macro UNLOCKED", port);

		if(data32 & (1 << 31))
			lprintf(5, "\n\t SATA Port%d - Clock Macro READY", port);
		else{
			lprintf(5, "\n\t [ERROR]: SATA Port%d - Clock Macro NOT READY", port);
			return -1;
		}
	}
	else
		return -1;
	return 0;
}

int sm_sata_clk_init(int port){
	int rc = 0;

	lprintf(6, "\n##### sm_sata_clk_init #####");

	if(CLK_REF){	// Internal
		if(CLK_TYPE){	// CMOS
			lprintf(4, "\n\t SATA Controller %d - Reference Clock: Internal - CMOS", port/2);
			if((port/2) == 2){	// Port45
				rc += sm_pcie2_cmos_clock_init();
				rc += sm_sata_clk_rst(port);
			}
			else{				// Port 0-3
				rc += sm_sata_clk_rst(port);
				rc += sm_sata_cmos_clock_init(port);
			}
		}
	}
	else{	// External CML
		lprintf(4, "\n\t SATA Controller %d - Reference Clock: External - CML", port/2);
		rc += sm_sata_clk_rst(port);
	}
	return rc;
}

void sm_sata_cdr_spd(int port){
	// cfg_i_SPD_sel_cdr_ovr
	u32 sata_csr_base = sm_sata_get_csr_base(port);
	u32 addr = sata_csr_base + SATA_ENET_SDS_CTL1__ADDR;
	u32 data = sm_sata_read32(addr);
	data &= ~(0xF);
	if(PLL_GEN == 1)		// forcing Gen 1
		data |= 1;
	else if(PLL_GEN == 2)	// forcing Gen 2
		data |= 3;
	else					// forcing Gen 3
		data |= 7;
	sm_sata_write32(addr, data);
}

int sm_sata_init(int port){
	int rc = 0;
	int timeout;

	lprintf(6, "\n##### sm_sata_init - START #####");

	/* SATA/ENET Muxing for SATA 0..3 */
	rc = sm_sata_enet_muxing(port);
	/* Clock Initiation */
	if(rc == 0) rc = sm_sata_clk_init(port);
	if(rc == 0){
		sm_sata_sds_rst(port);		// Put SERDES in reset
#ifdef MDIO_EN
		sm_sata_mdio_debug_en();					// enable the MDIO device
#endif
		sm_sata_cdr_spd(port);
		sm_sata_customer_pin_mode_cfg(port);			// choose Controller/Serdes doing the control
		sm_sata_sds_irst_cfg(port);		// config SERDES registers while SERDES is in reset
		sm_sata_sds_csr_cfg(port);		// config SERDES through CSR
		sm_sata_sds_ena(port);			// Pull SERDES out of reset
		timeout = 5;
		while(sm_sata_sds_calib(port) && --timeout) {		// VCO Calibration
			if(timeout == 4) sm_sata_sds_pdown_force_vco(port);
		}
		if(timeout){
			rc = sm_sata_core_ena(port);				// Pull SATA Core out of reset
			sm_sata_gen_avg(((port/2) * 2) + 0);
			sm_sata_gen_avg(((port/2) * 2) + 1);

			rc = sm_sata_mem_ena(port);			// reset Block Memory
			if(rc == 0)
				lprintf(4, "\n\t Block Memory is READY");
			else
				lprintf(4, "\n\t [ERROR]: Block Memory is NOT READY");
		}
		rc = sm_sata_pll_chk(port);
		if(rc == 0)
			lprintf(3, "\n\t SATA Controller %d - PLL Initiation PASSED", port/2);
		else
			lprintf(3, "\n\t [ERROR]: SATA Controller %d - PLL Initiation FAILED", port/2);
	}
	else
		lprintf(3, "\n\t [ERROR]: Putting SERDES in Reset FAILED");

    lprintf(6, "\n##### sm_sata_init - END #####\n");
	return rc;
}

void sm_sata_ahci_host_init(int port){
	int i, irq_id;
    u32 data;
	u32 sata_csr_base = sm_sata_get_csr_base(port);
	u32 sata_ahci_base = sm_sata_get_ahci_base(port);
    u32 addr;

    lprintf(6, "\n##### sm_sata_ahci_host_init - START #####");

	if((sata_csr_base != 0) && (sata_ahci_base !=0)){
        // Read CAP reg
        addr = sata_ahci_base + CAP__ADDR;
        data = sm_sata_read32(addr);
		lprintf(6, "\n SATA AHCI Host - Feature List");
		lprintf(7, "\n CAP [31:0] -> 0x%08x", data);

        sm_sata_global_irq(port, 1);

        // Show which ports are ready for software
        addr = sata_ahci_base + PI__ADDR;
		lprintf(6, "\n\n List of available ports for software");
		lprintf(7, "\n PI [1:0]");
        /* Port  Implemented  (PI):
         * This  register  is  bit  significant.    If  a  bit  is  set  to  �1�,  the
         * corresponding port is available for software to use.  If a bit is cleared to �0�, the port is
         * not  available  for  software  to  use.    The  maximum  number  of  bits  set  to  �1�  shall  not
         * exceed CAP.NP + 1, although the number of bits set in this register may be fewer than
         * CAP.NP + 1.  At least one bit shall be set to �1�.
         */
        data = sm_sata_read32(addr);

        // Disable MASK
        addr = sata_csr_base + INTSTATUSMASK__ADDR;
		lprintf(6, "\n\n Disable MASK");
		lprintf(7, "\n INTSTATUSMASK");
        sm_sata_write32(addr, 0);
        addr = sata_csr_base + ERRINTSTATUSMASK__ADDR;
        lprintf(7, "\n ERRINTSTATUSMASK");
        sm_sata_write32(addr, 0);
        addr = sata_csr_base + INT_SLV_TMOMASK__ADDR;
        lprintf(7, "\n INT_SLV_TMOMASK");
        sm_sata_write32(addr, 0);

        // Enable AXI Interrupt
        addr = sata_csr_base + SLVRDERRATTRIBUTES__ADDR;
		lprintf(6, "\n\n Enable AXI Interrupts");
		lprintf(7, "\n SLVRDERRATTRIBUTES");
		sm_sata_write32(addr, 0xFFFFFFFF);
        addr = sata_csr_base + SLVWRERRATTRIBUTES__ADDR;
        lprintf(7, "\n SLVWRERRATTRIBUTES");
        sm_sata_write32(addr, 0xFFFFFFFF);
        addr = sata_csr_base + MSTRDERRATTRIBUTES__ADDR;
        lprintf(7, "\n MSTRDERRATTRIBUTES");
        sm_sata_write32(addr, 0xFFFFFFFF);
        addr = sata_csr_base + MSTWRERRATTRIBUTES__ADDR;
        lprintf(7, "\n MSTWRERRATTRIBUTES");
        sm_sata_write32(addr, 0xFFFFFFFF);

        // Enable Coherency
        addr = sata_csr_base + BUSCTLREG__ADDR;
        data = sm_sata_read32(addr);
        data &= ~(0x1 << 1);
        data &= ~(0x1);
		sm_sata_write32(addr, data);

        addr = sata_csr_base + IOFMSTRWAUX__ADDR;
        data = sm_sata_read32(addr);
        data |= 0x1 << 9;	/* Enable read coherency */
        data |= 0x1 << 3;	/* Enable write coherency */
		sm_sata_write32(addr, data);
    }
    lprintf(6, "\n##### sm_sata_ahci_host_init - END #####\n");
}

int sm_sata_ahci_device_init(int port){
	int i, timeout;
    u32 data;
	u32 sata_ahci_base = sm_sata_get_ahci_base(port);
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);
    u32 addr;

	lprintf(6, "\n##### sm_sata_ahci_device_init - START #####");

	addr = sata_ahci_port_base + CMD0__ADDR;
	data = sm_sata_read32(addr);
	data &= ~1;		/* Mask [0] - make sure the Start bit of command list is unset*/
	sm_sata_write32(addr, data);
	sm_sata_msdelay(5);

	// Clear Error status
	addr = sata_ahci_port_base + SERR0__ADDR;
	data = sm_sata_read32(addr);
	sm_sata_write32(addr, data);

	// COMRESET: Hard Reset
	lprintf(6, "\n The interface is being reset and Communications are reinitialized ...");
	lprintf(7, "\n P%dSCTL [3:0]", port);
	addr = sata_ahci_port_base + SCTL0__ADDR;
	data = sm_sata_read32(addr);
	data &= ~(0xF << 4);	/* Mask [7:4] = 0 -> No speed negotiation restrictions */
	data &= ~(0xF);			/* Mask [3:0] = 0 */
	data |= 1;				// perform interface initiation - hard reset
	sm_sata_write32(addr, data);
	sm_sata_msdelay(5);		// at least 1 miliseconds
	data &= ~(0xF);			/* Mask [3:0] = 0 */
	sm_sata_write32(addr, data);
	sm_sata_msdelay(5);

	// COMINIT
	lprintf(6, "\n\n SATA%d - waiting for COMINIT ...", port);
	lprintf(7, "\n P%dSERR [26]", port);
	addr = sata_ahci_port_base + SERR0__ADDR;
	timeout = 500;
	do{
		sm_sata_msdelay(1);
		data = sm_sata_read32(addr);		// wait until COMINIT is detected
	}while(((data & (1 << 26)) == 0) && (--timeout));
	if(timeout)
		lprintf(5, "\n\t COMINIT is detected.");
	else{
		lprintf(5, "\n\t [ERROR]: COMINIT is NOT detected.");
		return -1;
	}

	// COMWAKE
	lprintf(6, "\n\n SATA%d - waiting for COMWAKE ...", port);
	lprintf(7, "\n P%dSERR0 [18]", port);
	addr = sata_ahci_port_base + SERR0__ADDR;
	timeout = 500;
	do{
		sm_sata_msdelay(1);
		data = sm_sata_read32(addr);
	}while(((data & (1 << 18)) == 0) && (--timeout));		// wait until COMWAKE is detected
	lprintf(7, "\n SATA_READ [0x%08x] = [0x%08x]", addr, data);
	if(timeout) {
		lprintf(5, "\n\t COMWAKE is detected.");
		sm_sata_write32(addr, data);
	}else {
		lprintf(5, "\n\t [ERROR]: COMWAKE is NOT detected.");
		return -1;
	}
    return 0;
}

int sm_sata_ahci_hba_reset(int port){
	int timeout, error = 0;
	u32 data;
	u32 sata_ahci_base = sm_sata_get_ahci_base(port);
    u32 addr;

	printf("\n##### sm_sata_ahci_hba_reset - START #####");

    printf ("\n Resetting SATA AHCI HBA ...");
    addr = sata_ahci_base + GHC__ADDR;
    printf ("\n GHC [0]");
    /* [0] HBA Reset (HR)
     * When set by SW, this bit causes an internal reset of the HBA.  All state  machines that
     * relate to data transfers and queuing shall return to an idle condition, and all ports shall
     * be re-initialized via COMRESET (if staggered spin-up is not  supported).
     * If staggered spin-up is supported, then it is the responsibility of software to spin-up each port
     * after the reset has completed.
     * When the HBA has performed the reset action, it shall reset this bit to �0�. A software
     * write of �0� shall have no effect. For a description on which bits are reset when this bit is
     * set, see section  10.4.3.
     */
    data = sm_sata_read32(addr);
    data |= 1;
    sm_sata_write32(addr, data);
    timeout = 0x1000;
    do{
//    	data = sm_sata_read32(addr);
    	data = sm_sata_read32(addr);
    }while(((data & 0x1) != 0) && (--timeout > 0));
    if(timeout > 0)
    	printf("\n\t Resetting SATA AHCI HBA is completed.");
    else{
    	printf("\n\t ===> Resetting SATA AHCI HBA is NOT completed.");
    	++error;
    }

    printf("\n##### sm_sata_ahci_hba_reset - END #####\n");

    return error;
}

int sm_sata_ahci_port_init(int port){
	int i;
	int port_offset;
    u32 data, timeout;
    u32 addr;
    u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);
    u32 sata_ahci_base = sm_sata_get_ahci_base(port);

	lprintf(6, "\n##### sm_sata_ahci_port_init - START #####");

	// PHY status
	lprintf(5, "\n\n Checking for PHY Status of SATA%d...", port);
	lprintf(7, "\n P%dSSTS0 [1:0] = 0x3", port);
	addr = sata_ahci_port_base + SSTS0__ADDR;
	timeout = 100;
	do{
		data = sm_sata_read32(addr);
		sm_sata_msdelay(10);
	}while(((data & 0x3) != 0x3) && (--timeout));
	lprintf(7, "\n SATA_READ [0x%08x] = [0x%08x]", addr, data);
	if(timeout)
		lprintf(5, "\n\t PHY is ready");
	else{
		lprintf(5, "\n\t [ERROR]: PHY is NOT ready");
		return -1;
	}

	// Clear all errors
	sm_sata_PxSERR_clr(port);

	// Task File Data
	addr = sata_ahci_port_base + TFD0__ADDR;
	lprintf(5, "\n\n Check for Task File Data of SATA%d ...", port);
	lprintf(7, "\n TFD0 [6:0]");
	timeout = 500;
	while(((sm_sata_read32(addr) & 0x7F) == 0x7F) && (--timeout)){
//		sm_sata_ahci_device_init(port);
		sm_sata_msdelay(10);
	}
	if(timeout){
		addr = sata_ahci_port_base + CLB0__ADDR;
		lprintf(5, "\n\n Set Command List Base Address ...");
//		lprintf(7, "\n P%dCLB [31:10]", port);
		sm_sata_write32(addr, (u64)CMD_LST_BASE);

		addr = sata_ahci_port_base + CLBU0__ADDR;
		lprintf(5, "\n\n Set Command List Base Upper Address ...");
//		lprintf(7, "\n P%dCLBU [31:10]", port);
		sm_sata_write32(addr, ((u64)CMD_LST_BASE >> 32));

		addr = sata_ahci_port_base + FB0__ADDR;
		lprintf(5, "\n\n Set Command FIS Base Address ...");
//		lprintf(7, "\n P%dFB [31:10]", port);
		sm_sata_write32(addr, (u64)CMD_FIS_BASE);

		addr = sata_ahci_port_base + FBU0__ADDR;
		lprintf(5, "\n\n Set Command FIS Base Upper Address ...");
//		lprintf(7, "\n P%dFBU [31:10]", port);
		sm_sata_write32(addr, ((u64)CMD_FIS_BASE >> 32));

		addr = sata_ahci_port_base + CMD0__ADDR;
		lprintf(5, "\n\n FIS Receive Enable ...");
//		lprintf(7, "\n CMD0 [4]");
		data = sm_sata_read32(addr);
		data |= 1 << 4;
		sm_sata_write32(addr, data);

		sm_sata_port_irq(port, ALL_IRQS);

		addr = sata_ahci_port_base + SSTS0__ADDR;
		data = sm_sata_read32(addr);
		if((data & 0xF0F) == 0x103)
			lprintf(3, "\n\t SATA Port%d - Linked up at GEN%d", port, ((data >> 4) & 0xF));
		else
			return -1;
		
		// Port x Signature
		//lprintf(7, "\n P%dSIG [31:0]", port);
		addr = sata_ahci_port_base + SIG0__ADDR;
		data = sm_sata_read32(addr);
		lprintf(4, "\n Port Signature - P%dSIG [0x%08x]: 0x%X", port, addr, data);
	}
	else
		return -1;
    return 0;
}


int sm_sata_linkup(int port){
	int timeout = 5;

	lprintf(6, "\n##### sm_sata_linkup - START #####");

	sm_sata_ceva_cfg(port);
	sm_sata_spd_cfg(port);
	sm_sata_ahci_host_init(port);
	sm_sata_reg_irq(port);	// enable GIC Interrupts
	while(sm_sata_ahci_device_init(port) && --timeout);
	if(timeout)
		lprintf(3, "\n\t SATA Port%d - OOB Signal was GOOD", port);
	else{
		lprintf(3, "\n\t [ERROR]: SATA Port%d - OOB Signal was NOT GOOD", port);
		return -1;
	}
	if(sm_sata_ahci_port_init(port)) {
		lprintf(3, "\n\t [ERROR]: SATA Port%d - Link up was FAILED", port);
		return -1;
	}else
		lprintf(3, "\n\t SATA Port%d - Link up was GOOD", port);
	return 0;
}

/**********************************UTILITY************************************************/
int sm_sata_dty_chk(int port){
	u32 data;
	u32 addr, sata_ahci_port_base = sm_sata_get_ahci_port_base(port);

	lprintf(6, "\n##### sm_sata_dty_chk - START #####");
	lprintf(3, "\n Disparity check for Port%d", port);

	addr = sata_ahci_port_base + SERR0__ADDR;
	data = sm_sata_read32(addr);
	if((data & (1 << 20)) > 0){
		lprintf(3, "\n\t [ERROR]: Disparity Error");
		lprintf(3, "\n\t P%dSERR = 0x%08x", port, data);
		return -1;
	}
	else
		lprintf(3, "\n \t NOTE: No Disparity Error");
	
	lprintf(6, "\n##### sm_sata_dty_chk - END #####\n");
	return 0;
}

int sm_sata_dty_fix(int port){
	int i, timeout, error = 0;

	lprintf(6, "\n##### sm_sata_dty_fix - START #####");
	lprintf(3, "\n Disparity fix for Port%d", port);

	timeout = 10;
	do{
		lprintf(3, "\n FIX%d", 11-timeout);
		sm_sata_rxa_rst(port);
		sm_sata_dty_clr(port);
		sm_sata_msdelay(300);
		error = sm_sata_dty_chk(port);
	}while((error) && (--timeout));
	if(timeout > 0)
		lprintf(3, "\n\t Disparity is GOOD after %d RX Analog Reset(s)", 11-timeout);
	else
		lprintf(3, "\n\t [ERROR]: Disparity Flag CAN'T be cleared");

	lprintf(6, "\n##### sm_sata_dty_fix - END #####\n");

	return error;
}

int sm_sata_PxSERR_clr(int port){
	u32 data;
	u32 addr, sata_ahci_port_base = sm_sata_get_ahci_port_base(port);

	addr = sata_ahci_port_base + SERR0__ADDR;
	sm_host_read32(addr, &data);
	sm_host_write32(addr, data);
	sm_sata_msdelay(1);
	sm_host_read32(addr, &data);
	return (data == 0) ? 0 : -1;
}

void sm_sata_dty_clr(int port){
	int i, error = 0;
	u32 data;
	u32 addr, sata_ahci_port_base = sm_sata_get_ahci_port_base(port);

	lprintf(6, "\n##### sm_sata_dty_clr - START #####");

	addr = sata_ahci_port_base + SERR0__ADDR;
	data = sm_sata_read32(addr);
	lprintf(6, "\n\t P%dSERR before clearing = 0x%08x", port, data);
	data = 1 << 20;
	sm_sata_write32(addr, data);
	i = 0x1000;
	do{
		data = sm_sata_read32(addr);
	}while(((data & (1 << 20)) > 0) && (--i));
	lprintf(6, "\n\t P%dSERR after clearing  = 0x%08x", port, data);
	if(i > 0){
		lprintf(6, "\n\t P%dSERR[20] has been cleared", port);
	}
	lprintf(6, "\n##### sm_sata_dty_clr - END #####\n");
}

int sm_sata_get_busy_slots(int port){
	int busy_slots;
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);
	busy_slots = sm_sata_read32(sata_ahci_port_base + CI0__ADDR) | sm_sata_read32(sata_ahci_port_base + SACT0__ADDR);
	return busy_slots;
}

int sm_sata_get_free_slot(int port){
	int i, the_slot;
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);
	the_slot = sm_sata_read32(sata_ahci_port_base + CI0__ADDR) | sm_sata_read32(sata_ahci_port_base + SACT0__ADDR);
	for(i=0; i<32; ++i){
		if((the_slot & (1 << i)) == 0)
			return i;
	}
	lprintf(4, "\n [WARNING]: Can't find an empty command slot.");
	return i;
}

// sm_sata_ctrl_init(data32, 0xF, 1, 0, 1, 0, 1, 0, 0, 0, 0xA0, 0x0C);
void sm_sata_ctrl_init(u32 CMD_slot, u8 PMP, u8 C, u8 B, u8 R, u8 P, u8 W, u8 A, u32 FTR, u8 DEV_reg, u8 CTL_reg){
	/*
	 * CMD_slot : slot number 0..31
	 * PMP      : Port Multiplier Port
	 * C        : Clear  Busy  upon  R_OK
	 * B        : BIST
	 * R        : Reset
	 * P        : Prefetchable
	 * W        : Direction (Read or Write)
	 * A        : ATAPI
	 * W        : 0 for READ & 1 for WRITE
	 * FTR      : Feature
	 * DEV_reg  : Device register
	 * CTL_reg  : Control register
	 */
	u32 FIS_TYPE = 0x27;		// Host to Device (0x27)

	u32 cmd_lst_header[4];		// 4 DWORDs
	u32 cmd_lst_header_offset = 0x20;

	u32 cmd_fis[5];				// 5 DWORDs
	u32 cfl = 5;				// Command FIS Length

	u32 prd_entry[4];			// 4 DWORDs
	u32 prdtl = 0;				// PRDT Length
	u32 prd_region = 0x80;
	u32 cmd_offset = 0x100;
	u32 prd_offset = 0x10;

	u32 i, j;
	u64 addr;

	lprintf(6, "\n\n sm_sata_ctrl_init - START");

	/* create Command Header */
	lprintf(6, "\n  Create Command Header ...");
	for(i = 0; i<4; i++) cmd_lst_header[i] = 0x0;
	cmd_lst_header[0] = 0;			// PRDTL
	cmd_lst_header[0] |= PMP << 12;
	cmd_lst_header[0] |= C << 10;	// Clear  Busy  upon  R_OK
	cmd_lst_header[0] |= B << 9;	// BIST
	cmd_lst_header[0] |= R << 8;	// Reset
	cmd_lst_header[0] |= P << 7;	// Prefetchable
	cmd_lst_header[0] |= W << 6;	// Direction (Read or Write)
	cmd_lst_header[0] |= A << 5;	// ATAPI
	cmd_lst_header[0] |= cfl;
	cmd_lst_header[1] = 0;			// PRDBC
	addr = CMD_TABLE_BASE + CMD_slot*cmd_offset;
	cmd_lst_header[2] = addr;		// Command Table Descriptor Base Address
	cmd_lst_header[3] = addr >> 32;	// Command Table Descriptor Base Address (upper 32-bit)
	for (i=0; i<4; ++i){
		addr = CMD_LST_BASE + CMD_slot*cmd_lst_header_offset + i*4;
		sm_sata_write64(addr, cmd_lst_header[i]);
	}

	/* create FIS commands */
	lprintf(6, "\n\n  Create FIS Commands ...");
	for(i=0; i<5; i++) cmd_fis[i] = 0x0;
	cmd_fis[0] = FIS_TYPE;
	cmd_fis[0] |= PMP << 8;		// Port Multiplier Ports
	cmd_fis[0] |= FTR << 24;	// Feature low
	cmd_fis[1] = DEV_reg << 24;
	cmd_fis[2] = (FTR >> 8) << 24;		// Feature high
	cmd_fis[3] = 1 << 16;		// Isochronous command completion
	cmd_fis[3] |= CTL_reg << 24;
	cmd_fis[4] = 0;
	for(i=0; i<5; ++i){
		addr = CMD_TABLE_BASE + CMD_slot*cmd_offset + i*4;
		sm_sata_write64(addr, cmd_fis[i]);
	}
	lprintf(6, "\n sm_sata_ctrl_init - END");
}

void sm_sata_cmd_setup(u8 cmd_slot, u8 pmp, u8 cmd, u64 data1, u64 data2, u32 data3, u32 data4, u8 data5, u8 data6){
	u64 addr;
	u64 sec_sta = STA_SECTOR;
	u32 sec_cnt = NUM_SECTOR;
	u32 cmd_header_offset = 0x20;
	u32 cmd_offset = 0x1000000;
	u32 prd_region = 0x80;
	u32 prd_offset = 0x10;
	cmd_header *header = (cmd_header *) ((void *)(CMD_LST_BASE + cmd_slot*cmd_header_offset));
	cmd_fis    *fis    = (cmd_fis *) ((void *)(CMD_TABLE_BASE + cmd_slot*cmd_offset));
	int i, val;

	memset((void *)(CMD_LST_BASE + cmd_slot*cmd_header_offset), 0x00, sizeof(cmd_header));
	memset((void *)(CMD_TABLE_BASE + cmd_slot*cmd_offset), 0x00, sizeof(cmd_fis));

	// Command header
	if(FBS) header->p = 0;
	header->cfl = 5;
	header->pmp = pmp;
#if 0
	if(data3) header->prdtl = ((data3 - 1) >> prd_shifter) + 1;		// sector counts
#else
	if(sec_cnt){
		header->prdtl = sec_cnt / (PRD_SIZE*2);		// PRD length
		if(sec_cnt % (PRD_SIZE*2))
			header->prdtl += 1;
	}
#endif
	lprintf(4, "\n PRD length = %d \n", header->prdtl);
	addr = CMD_TABLE_BASE + cmd_slot*cmd_offset;
	header->ctba = addr;
	header->ctbau = addr >> 32;

	// FIS command
	fis->fis_type = FIS_H2D;
	if(cmd)	fis->c = 1;
	fis->pmp = pmp;
	fis->cmd = cmd;
	fis->device = 0x40;			// LBA48
	fis->lba0 = sec_sta;			// 48-bit start sector
	fis->lba1 = sec_sta >> 8;
	fis->lba2 = sec_sta >> 16;
	fis->lba3 = sec_sta >> 24;
	fis->lba4 = sec_sta >> 32;
	fis->lba5 = sec_sta >> 40;

	if((cmd == ATA_CMD_DMA_WR) || (cmd == ATA_CMD_DMA_WR_EXT) ||
	   (cmd == ATA_CMD_PIO_WR) || (cmd == ATA_CMD_PIO_WR_EXT) ||
	   (cmd == ATA_CMD_FPDMA_WR))
		header->w = 1;
	else
		header->w = 0;

	if((cmd == ATA_CMD_FPDMA_RD) || (cmd == ATA_CMD_FPDMA_WR)){
		fis->featurel = sec_cnt;		// sector count
		fis->featureh = sec_cnt >> 8;
		fis->countl   = cmd_slot << 3;	// TAG
	}
	else{
		fis->countl = sec_cnt;			// sector count
		fis->counth = sec_cnt >> 8;
	}

	if((cmd == ATA_CMD_BUFFER_RD) || (cmd == ATA_CMD_BUFFER_WR)){
		header->r = 1;
		header->pmp = 0xF;	// PM card address
		fis->pmp = 0xF;		// PM card address
		fis->featurel = data5;		// GSCR[data5] or PSCR[data5]
		fis->device = pmp;			// Port Multiplier number
		//fis->control = 0x08;
		if(cmd == ATA_CMD_BUFFER_WR){
			fis->countl = data2;		// the 64-bit value to write to the register.
			fis->lba0 = data2 >> 8;
			fis->lba1 = data2 >> 16;
			fis->lba2 = data2 >> 24;
			fis->counth = data2 >> 32;
			fis->lba3 = data2 >> 40;
			fis->lba4 = data2 >> 48;
			fis->lba5 = data2 >> 56;
		}
	}

	// PRDT
	if(header->prdtl > 0){
		for(i=0; i<(header->prdtl); ++i){
			addr = CMD_TABLE_BASE + cmd_slot*cmd_offset + prd_region + prd_offset*i;
			prd_table *prdt = (prd_table *) ((void *)(addr));
			memset((void *)(addr), 0x00, sizeof(prd_table));

			//addr = data1 + (i*(1 << prd_shifter)*512);
#if 0
			addr = data1 + (i*(1 << PRD_SHIFTER)*512);
			prdt->dba = addr;
			prdt->dbau = addr >> 32;
#else
			addr = data1 + (i*PRD_SIZE*1024);
			prdt->dba = addr;
			prdt->dbau = addr >> 32;
#endif
			prdt->i = 1;
			if(i == (header->prdtl - 1))
				//prdt->dbc = (data3 * 512) - 1;
				prdt->dbc = (sec_cnt * 512) - 1;
			else{
				//prdt->dbc = (((1 << prd_shifter)*512) - 1);
				//data3 -= (1 << prd_shifter);
				prdt->dbc = PRD_SIZE*1024 - 1;
				sec_cnt -= PRD_SIZE*2;
			}
		}
	}
#if DDR_CACHEABLE
	//printf("\n\n DDR Flushing ... \n");
	dcache_flush_all();
#endif

#if 0	//debug
	printf("\n");
	for(i=0; i<5; ++i){
		addr = CMD_LST_BASE + cmd_slot*cmd_header_offset + i*4;
		sm_host_read32(addr, &val);
		printf("\n HEAD[%d] [0x%08X] = 0x%08X", i, addr, val);
	}
	printf("\n");
	for(i=0; i<5; ++i){
		addr = CMD_TABLE_BASE + cmd_slot*cmd_offset + i*4;
		sm_host_read32(addr, &val);
		printf("\n FIS[%d] [0x%08X]  = 0x%08X", i, addr, val);
	}
	int j;
	for(i=0; i<(header->prdtl); ++i){
		printf("\n");
		for(j=0; j<4; ++j){
			addr = CMD_TABLE_BASE + cmd_slot*cmd_offset + prd_region + prd_offset*i + j*4;
			sm_host_read32(addr, &val);
			printf("\n PRD[%d] [0x%08X] = 0x%08X", j, addr, val);
		}
	}
#endif
}

void sm_sata_cmds_init(u32 pm_port, u32 cmd, u32 cmd_slot, u32 dev_reg, u32 ctl_reg, u32 W, u32 prd_size_shifter, u64 location, u32 startl, u32 starth, u32 sec_cnt){
	/*
	 * cmd      : ATA Command
	 * cmd_slot : slot number 0..31
	 * W        : 0 for READ & 1 for WRITE
	 * location : where to put data for reading & get data for writing
	 * startl   : start sector (lower 48 bits)
	 * starth   : start sector (upper 48 bits)
	 * sec_cnt  : sector count
	 */
	u32 FIS_TYPE = 0x27;		// Host to Device (0x27)
	u32 cmd_lst_header[4];		// 4 DWORDs
	u32 cmd_lst_header_offset = 0x20;

	u32 cmd_fis[5];				// 5 DWORDs
	u32 CFL = 5;				// Command FIS Length

	u32 prd_entry[4];			// 4 DWORDs
	u32 PRDTL = 0;				// PRDT Length
	u32 prd_region = 0x80;
	u32 cmd_offset = 0x100;
	u32 prd_offset = 0x10;

	u32 i, j;
	u64 addr;

	lprintf(6, "\n\n sm_sata_cmds_init - START");

	lprintf(5, "\n\t Setting up ATA Command 0x%02x", cmd);
	if((cmd != ATA_CMD_PWR_CHK) && (cmd != ATA_CMD_IDENT)){
		lprintf(5, "\t Start sector: %d", startl);
		lprintf(5, "\t Sector count: %d", sec_cnt);
	}

	/* create Command Header */
	lprintf(6, "\n  Create Command Header ...");
	if(sec_cnt)
		PRDTL = ((sec_cnt-1) >> prd_size_shifter) + 1;
	cmd_lst_header[0] = PRDTL << 16;
	cmd_lst_header[0] |= pm_port << 12;
	cmd_lst_header[0] |= W << 6;	// Direction (Read or Write)
	cmd_lst_header[0] |= CFL;
	cmd_lst_header[1] = 0;
	addr = CMD_TABLE_BASE + cmd_slot*cmd_offset;
	cmd_lst_header[2] = addr;
	cmd_lst_header[3] = addr >> 32;
	for (i=0; i<4; ++i){
		addr = CMD_LST_BASE + cmd_slot*cmd_lst_header_offset + i*4;
		sm_sata_write64(addr, cmd_lst_header[i]);
	}

	/* create FIS commands */
	lprintf(6, "\n\n  Create FIS Commands ...");
	cmd_fis[0] = FIS_TYPE;
	cmd_fis[1] = 0;
	cmd_fis[2] = 0;
	cmd_fis[3] = 0;
	cmd_fis[4] = 0;
	cmd_fis[0] |= pm_port << 8;
	cmd_fis[0] |= cmd << 16;
	cmd_fis[0] |= 1 << 15;		// 0: Control, 1: Command
	cmd_fis[1] |= startl & 0x00FFFFFF;	// Start sector
	cmd_fis[1] |= dev_reg << 24;		// Device register, 0x40 = LBA48
	cmd_fis[2] |= starth & 0x00FFFFFF;	// Start sector
	if((cmd == ATA_CMD_FPDMA_RD) || (cmd == ATA_CMD_FPDMA_WR)){
		cmd_fis[0] |= sec_cnt << 24;
		cmd_fis[2] |= (sec_cnt >> 8) << 24;
		cmd_fis[3] |= cmd_slot << 3;
	}
	else{
		cmd_fis[3] = sec_cnt;			// Count (15:0)
	}
	//if(pm_port) cmd_fis[0] |= pm_port << 8;
	for(i=0; i<5; ++i){
		addr = CMD_TABLE_BASE + cmd_slot*cmd_offset + i*4;
		sm_sata_write64(addr, cmd_fis[i]);
	}

	if(PRDTL > 0){
		lprintf(6, "\n\n  Create PRD Entries ...");
		for(i=0; i<(PRDTL-1); ++i){
			//addr = location + (i*(1 << 12)*512);
			addr = location + (i*(1 << prd_size_shifter)*512);
			prd_entry[0] = addr; 					// Database address
			prd_entry[1] = addr >> 32;				// Database address Upper 32-bits
			prd_entry[2] = 0;						// Reserved
			prd_entry[3] = (1 << 31) | (((1 << prd_size_shifter)*512) - 1);		// [31] Interrupt on Completion
																				// [30:22] Reserved
																				// [21:0] Data Byte Count
			sec_cnt -= (1 << prd_size_shifter);
			for(j=0; j<4; ++j){
				addr = CMD_TABLE_BASE + cmd_slot*cmd_offset + prd_region + prd_offset*i + j*4;
				sm_sata_write64(addr, prd_entry[j]);
			}
		}
		addr = location + (i*(1 << prd_size_shifter)*512);
		prd_entry[0] = addr;
		prd_entry[1] = addr >> 32;
		prd_entry[2] = 0;
		prd_entry[3] = (1 << 31) | ((sec_cnt * 512) - 1);
		for(j=0; j<4; ++j){
			addr = CMD_TABLE_BASE + cmd_slot*cmd_offset + prd_region + prd_offset*i + j*4;
			sm_sata_write64(addr, prd_entry[j]);
		}
	}
	lprintf(6, "\n sm_sata_cmds_init - END");
}

void sm_sata_cmds_exe(int port, int pwr_mode, int ci_cmd, int sact_cmd){
	int i, timeout;
	u32 data;
	u32 sata_ahci_base = sm_sata_get_ahci_base(port);
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);

	lprintf(6, "\n\n sm_sata_cmds_exe - START");
#if 0
	if(test_id != 8){
		lprintf(6, "\n SATA%d AHCI BASE : 0x%08x", port, sata_ahci_base);
		lprintf(6, "\n SATA%d AHCI PORT BASE : 0x%08x \n", port, sata_ahci_port_base);

		lprintf(6, "\n\n P%dSERR - Clear Error Status", port);
		sm_sata_write32(sata_ahci_port_base + SERR0__ADDR, 0xFFFFFFFF);
		lprintf(6, "\n\n P%dIS - Clear Port Interrupt Status", port);
		sm_sata_write32(sata_ahci_port_base + IS0__ADDR, 0xFFFFFFFF);
		lprintf(6, "\n\n IS - Clear Interrupt Status", port);
		sm_sata_write32(sata_ahci_base + IS__ADDR, 0xFFFFFFFF);
	}
#endif

	lprintf(6, "\n\n POWER MODE = 0x%08x \n", pwr_mode);
	lprintf(7, "\n\n P%dCMD [0] - Start Command List", port);
	data = sm_sata_read32(sata_ahci_port_base + CMD0__ADDR);
	data &= ~((3 << 26) | (1 << 23));
	data |= pwr_mode;
	data |= 1;
	sm_sata_write32(sata_ahci_port_base + CMD0__ADDR, data);

	if(sact_cmd != 0){
		lprintf(6, "\n Queued Commands issuing ...");
		lprintf(7, "\n P%dSACT [31:0]", port);
		sm_sata_write32(sata_ahci_port_base + SACT0__ADDR, sact_cmd);
	}
	if(ci_cmd != 0){
		lprintf(6, "\n\n Commands issuing ...");
		lprintf(7, "\n P%dCI [31:0]", port);
//		printf("\n PxTFD = 0x%08x (before)", sm_sata_read32(sata_ahci_port_base + TFD0__ADDR));
//		i = 100;
		sm_sata_write32(sata_ahci_port_base + CI0__ADDR, ci_cmd);
//		while(--i) printf("\n PxTFD = 0x%08x (after)", sm_sata_read32(sata_ahci_port_base + TFD0__ADDR));
	}

	lprintf(6, "\n COMPLETE PROCESSING COMMAND BLOCK ... ");

	lprintf(6, "\n sm_sata_cmds_exe - END");
}

int sm_sata_bist_init(int port, u32 pattern_id, u32 data1, u32 data2){
	u32 FIS_TYPE = 0x58;		// BIST activate FIS - bidirectional
	u32 cmd_lst_header[4];		// 4 DWORDs

	u32 cmd_fis[3];				// 3 DWORDs
	u32 CFL = 3;				// Command FIS Length

	u32 i, data, timeout = 10;
	u32 sata_ahci_base      = sm_sata_get_ahci_base(port);
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);
	u32 addr32;
	u64 addr64;

	lprintf(6, "\nsm_sata_bist_init");
	lprintf(3, "\n BIST Initialization for Port%d", port);

	/* create Command Header */
	lprintf(6, "\n  Create Command Header ...");
	cmd_lst_header[0] = 1 << 9;	// BIST
	cmd_lst_header[0] |= CFL;
	cmd_lst_header[1] = 0;
	addr64 = CMD_TABLE_BASE;
	cmd_lst_header[2] = addr64;
	cmd_lst_header[3] = addr64 >> 32;
	for (i=0; i<4; ++i){
		addr64 = CMD_LST_BASE + i*4;
		sm_sata_write64(addr64, cmd_lst_header[i]);
	}

	/* create FIS commands */
	lprintf(6, "\n\n  Create FIS Commands ...");
	cmd_fis[0] = 0;
	cmd_fis[0] |= pattern_id << 16;
	cmd_fis[0] |= 0 << 15;		// 0: Control, 1: Command
	cmd_fis[0] |= FIS_TYPE;
	cmd_fis[1] = data1;
	cmd_fis[2] = data2;
	for(i=0; i<CFL; ++i){
		addr64 = CMD_TABLE_BASE + i*4;
		sm_sata_write64(addr64, cmd_fis[i]);
	}

	addr32 = sata_ahci_port_base + CI0__ADDR;
	sm_sata_write32(addr32, 1);		// cmd slot 0

	sm_sata_msdelay(100);
	addr32 = sata_ahci_port_base + SSTS0__ADDR;
	sm_host_read32(addr32, &data);
	if((data & 0xF) != 4){
		printf("\n [ERROR]: BIST initialization FAILED");
		return -1;
	}

	sm_sata_portcfg_sel(port);	// select Port of Controller
	data = sm_sata_read32(sata_ahci_base + PORTLNKSTAT0__ADDR);
	if((data == 34) || (data == 35)){
		printf("\n BIST Test is Running, LinkState = %d", data);
	}
	else{
		printf("\n BIST Test is NOT Running, LinkState = %d", data);
		return -1;
	}
	return 0;
#if 0
	u64 addr;
	u32 cmd_header_offset = 0x20;
	u32 cmd_offset = 0x100;
	u32 prd_region = 0x80;
	u32 prd_offset = 0x10;
	u32 prd_shifter = 12;
	cmd_header *header = (cmd_header *) ((void *)(CMD_LST_BASE + cmd_slot*cmd_header_offset));
	cmd_fis *fis = (cmd_fis *) ((void *)(CMD_TABLE_BASE + cmd_slot*cmd_offset));
	int i, val;

	memset((void *)(CMD_LST_BASE + cmd_slot*cmd_header_offset), 0x00, sizeof(cmd_header));
	memset((void *)(CMD_TABLE_BASE + cmd_slot*cmd_offset), 0x00, sizeof(cmd_fis));

	// Command header
	header->cfl = 5;
	header->pmp = pmp;
	if(data5) prd_shifter = data5;
	if(data3) header->prdtl = ((data3 - 1) >> prd_shifter) + 1;		// sector counts
	addr = CMD_TABLE_BASE + cmd_slot*cmd_offset;
	header->ctba = addr;
	header->ctbau = addr >> 32;

	// FIS command
	fis->fis_type = FIS_H2D;
	if(cmd)	fis->c = 1;
	fis->pmp = pmp;
	fis->cmd = cmd;
	fis->device = 0x40;			// LBA48
	fis->lba0 = data2;			// 48-bit start sector
	fis->lba1 = data2 >> 8;
	fis->lba2 = data2 >> 16;
	fis->lba3 = data2 >> 24;
	fis->lba4 = data2 >> 32;
	fis->lba5 = data2 >> 40;

	//if(test_id = 91) fis->device = 0;	// for interrupt tests

	if((cmd == ATA_CMD_DMA_WR) || (cmd == ATA_CMD_DMA_WR_EXT) ||
	   (cmd == ATA_CMD_PIO_WR) || (cmd == ATA_CMD_PIO_WR_EXT) ||
	   (cmd == ATA_CMD_FPDMA_WR))
		header->w = 1;
	else
		header->w = 0;

	if((cmd == ATA_CMD_FPDMA_RD) || (cmd == ATA_CMD_FPDMA_WR)){
		fis->featurel = data3;		// sector count
		fis->featureh = data3 >> 8;
		fis->countl   = cmd_slot << 3;
	}
	else{
		fis->countl = data3;		// sector count
		fis->counth = data3 >> 8;
	}

	if((cmd == ATA_CMD_BUFFER_RD) || (cmd == ATA_CMD_BUFFER_WR)){
		header->r = 1;
		header->pmp = 0xF;	// PM card address
		fis->pmp = 0xF;		// PM card address
		fis->featurel = data5;		// GSCR[data5] or PSCR[data5]
		fis->device = pmp;			// Port Multiplier number
		//fis->control = 0x08;
		if(cmd == ATA_CMD_BUFFER_WR){
			fis->countl = data2;		// the 64-bit value to write to the register.
			fis->lba0 = data2 >> 8;
			fis->lba1 = data2 >> 16;
			fis->lba2 = data2 >> 24;
			fis->counth = data2 >> 32;
			fis->lba3 = data2 >> 40;
			fis->lba4 = data2 >> 48;
			fis->lba5 = data2 >> 56;
		}
	}

	// PRDT
	if(header->prdtl > 0){
		for(i=0; i<(header->prdtl); ++i){
			addr = CMD_TABLE_BASE + cmd_slot*cmd_offset + prd_region + prd_offset*i;
			prd_table *prdt = (prd_table *) ((void *)(addr));
			memset((void *)(addr), 0x00, sizeof(prd_table));

			addr = data1 + (i*(1 << prd_shifter)*512);
			prdt->dba = addr;
			prdt->dbau = addr >> 32;
			prdt->i = 1;
			if(i == (header->prdtl - 1))
				prdt->dbc = (data3 * 512) - 1;
			else{
				prdt->dbc = (((1 << prd_shifter)*512) - 1);
				data3 -= (1 << prd_shifter);
			}
		}
	}
#endif
}

int sm_sata_bist_chk(int port) {
	int i;
	u32 data, fail;
	u32 addr;
	u32 sata_ahci_base      = sm_sata_get_ahci_base(port);
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);

	lprintf(6, "\nsm_sata_bist_chk");
	sm_sata_portcfg_sel(port);

	// PhyControl BIST Clear Error
	addr = sata_ahci_base + PORTPHY1CFG__ADDR;
	sm_host_read32(addr, &data);
	data |= 1 << 25;
	sm_sata_write32(addr, data);
	sm_sata_msdelay(100);
	data &= ~(1 << 25);
	sm_sata_write32(addr, data);

	// Wait 2 seconds to see if the BIST has errors
	sm_sata_msdelay(2000);
	sm_host_read32(sata_ahci_base + BIST_ERR__ADDR, &data);
	if(data & 1) return -1;

	fail = 0;
	for(i=0; i<5; ++i){
		printf("\n BIST Test Check #%d", i+1);
		sm_sata_msdelay(2000);
		sm_host_read32(sata_ahci_base + BIST_ERR__ADDR, &data);
		printf("\n\t BIST ERR Register = 0x%08X", data);
		fail += (data & 1) ? 1 : 0;
		//sm_host_read32(sata_ahci_port_base + SERR0__ADDR, &data);
		//printf("\n\t P%dSERR Register = 0x%08X", port, data);
		//fail += (data) ? 1 : 0;
		if(fail) return -1;
		//sm_host_write32(sata_ahci_port_base + SERR0__ADDR, data);
	}
	return 0;
}

void memory_reset(u64 base, u32 number_sectors){
	u32 number_dword;
	u32 i;

	lprintf(4, "\n Init memory from   0x%09x to 0x%09x ...", base, base + number_sectors*512 - 1);

	number_dword = (number_sectors*512)/4;

	for(i=0; i<number_dword; i++)
	{
		sm_sata_write64(base + i*4, 0x5555AAAA);
		if((i % 0x64000) == 0)
			lprintf(4, ".");
	}
#if DDR_CACHEABLE
	dcache_flush_all();
#endif
}

void memory_create_data(u64 base, u32 number_sectors){
	u32 number_dword;
	u32 data;
	u32 i;

	lprintf(4, "\n Generate data from 0x%09x to 0x%09x ...", base, base + number_sectors*512 - 1);

	number_dword = (number_sectors*512)/4;

	for(i=0x0; i<number_dword; i++)
	{
		if(i < (number_dword / 4))
			data = 0xCCCC0000;
		else if(i < (number_dword / 2))
			data = 0x55550000;
		else if(i < ((number_dword * 3) / 4))
			data = 0xAAAA0000;
		else	// (i < number_dword)
			data = 0xEEEE0000;

		if((i % 0x64000) == 0)
			lprintf(4, ".");

		sm_sata_write64(base + i*4, data + i);
	}
#if DDR_CACHEABLE
	dcache_flush_all();
#endif
}

int memory_compare(int report, u64 fr, u64 to, u32 number_sectors){
	u32 number_dword;
	u32 data1, data2;
	u32 i, error = 0;

	lprintf(4, "\n Memory comparing ...");
	number_dword = (number_sectors*512)/4;
#if DDR_CACHEABLE
	dcache_flush_all();
#endif
	for(i=0x0; i<number_dword; i++)
	{
		data1 = sm_sata_read64(fr + i*4);
		data2 = sm_sata_read64(to + i*4);
		if(report){
			lprintf(8, "\n Offset[0x%09x]: 0x%08x 0x%08x", i*4, data1, data2);
		}
		if(data1 != data2){
			++error;
			if(report) lprintf(8, "  ---> Don't match.");
		}

		if((i % 0x64000) == 0) lprintf(4, ".");
	}

	lprintf(4, "\n\n Source addr       = 0x%09x to 0x%09x", fr, fr+(number_sectors*512)-1);
	lprintf(4, "\n Destination addr  = 0x%09x to 0x%09x", to, to+(number_sectors*512)-1);
	lprintf(4, "\n Number of sectors = %d", number_sectors);

	if(error > 0)
		lprintf(4, "\t\t\t DON'T MATCHED %d\%", (error * 100)/i);
	else
		lprintf(4, "\t\t\t MATCHED 100%");
	lprintf(4, "\n");
	return error;
}

void memory_display(u64 base, int length){
	u32 rd_data, i;

	lprintf(5, "\n\n ===> MEMORY DISLAY32 <===");
	lprintf(5, "\n Address     Value\n");
	for(i = 0; i< length; i++)
	{
		//rd_data = byte_swap_RD_MEM32(base + i*4);
		rd_data = sm_sata_read64(base + i*4);
		lprintf(5, " 0x%09x 0x%08x \n", (base + i*4),rd_data);
	}
}

void sm_sata_pmp_cmd_chk(int port, int pmp){
/* FIS-Based Switching enabled if PM_Port */
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);
	u32 addr, data32;

	// Make sure PxCMD0.ST = 0
	addr = sata_ahci_port_base + CMD0__ADDR;
	data32 = sm_sata_read32(addr);
	data32 &= (~1);
	sm_sata_write32(addr, data32);
	FBS = (pmp) ? 1 : 0;
	if(FBS){
		if(pmp){
			// Enable FIS-Based Switching
			addr = sata_ahci_port_base + FBS0__ADDR;
			data32 = sm_sata_read32(addr);
			lprintf(5, "\n\t Enabling FIS-based Switching ...");
			lprintf(5, "\n\t Registering PMP%d_%d ...", port, pmp);
			lprintf(6, "\n\t Before enabling FBS, FBS0 reg val: 0x%X", data32);
//			data32 &= ~(0xF << 8);
//			data32 |= pmp << 8;		// Register the PM card
			data32 |= 1;			// Enable FIS-Based Switching
			sm_sata_write32(addr, data32);
			lprintf(6, "\n\t After enabling FBS, FBS0 reg val: 0x%X", data32);
		}
		else{
			addr = sata_ahci_port_base + FBS0__ADDR;
			data32 = sm_sata_read32(addr);
			data32 &= ~(0xF << 8);
			data32 &= ~1;			// Disable FIS-Based Switching
			sm_sata_write32(addr, data32);
		}
	}
}

int sm_sata_readid(int port, int pmp){
	/*
	 * STA_SECTOR = 0
	 * NUM_SECTOR = 1
	 * PRD_SHIFTER = 1
	 */
	char id[20];
	int i, data, timeout = 100;
	u64 location = SATA_DATA_READ_BASE;
	lprintf(6, "\n location = 0x%08X", location);
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);
	u32 data32;
	test_id = 1;

	memory_reset(location, 1);
	sm_sata_pmp_cmd_chk(port, pmp);
	sm_sata_cmd_setup(0, pmp, ATA_CMD_IDENT, location, 0, 1, 0, 0, 0);
	sm_sata_cmds_exe(port, 0, 1, 0);
	while((sm_sata_get_busy_slots(port) != 0) && --timeout){
		sm_sata_msdelay(10);
	}
	if((sm_sata_read64(location) >> 16) == 0x3FFF){
		lprintf(3, "\n Serial      :");
		for(i=0; i<5; ++i){		// Word: 10-19
			data = sm_sata_read64(location + 20 + i*4);
			lprintf(3, "%c", data >> 8);
			lprintf(3, "%c", data >> 0);
			lprintf(3, "%c", data >> 24);
			lprintf(3, "%c", data >> 16);
		}
		lprintf(3, "\n Firmware Rev: ");
		for(i=0; i<3; ++i){
			data = sm_sata_read64(location + 44 + i*4);		// Word: 23-26
			if(i > 0){
				lprintf(3, "%c", data >> 8);
				lprintf(3, "%c", data >> 0);
			}
			if(i < 2){
				lprintf(3, "%c", data >> 24);
				lprintf(3, "%c", data >> 16);
			}
		}
		lprintf(3, "\n Model Number: ");
		for(i=0; i<11; ++i){
			data = sm_sata_read64(location + 52 + i*4);		// Word: 27-46
			if(i > 0){
				lprintf(3, "%c", data >> 8);
				lprintf(3, "%c", data >> 0);
			}
			if(i < 10){
				lprintf(3, "%c", data >> 24);
				lprintf(3, "%c", data >> 16);
			}
		}

		data = sm_sata_read64(location + 152);		// Word: 76-77
		lprintf(3, "\n Serial ATA capabilities - Word #77-76 = 0x%08x", data);
		if(data & (1 << 15)) lprintf(3, "\n\t Supports READ LOG DMA EXT as equivalent to READ LOG EXT");
		if(data & (1 << 14)) lprintf(3, "\n\t Supports Device Automatic Partial to Slumber transitions");
		if(data & (1 << 13)) lprintf(3, "\n\t Supports Host Automatic Partial to Slumber transitions");
		if(data & (1 << 12)) lprintf(3, "\n\t Supports Native Command Queuing priority information");
		if(data & (1 << 11)) lprintf(3, "\n\t Supports Unload while NCQ commands outstanding");
		if(data & (1 << 10)) lprintf(3, "\n\t Supports Phy event counters");
		if(data & (1 << 9)) lprintf(3, "\n\t Supports Receipt of host-initiated interface power management requests");
		if(data & (1 << 8)) lprintf(3, "\n\t Supports Native Command Queuing");
		if(data & (1 << 3)) lprintf(3, "\n\t Supports Serial ATA Gen3 signaling speed (6.0 Gbps)");
		if(data & (1 << 2)) lprintf(3, "\n\t Supports Serial ATA Gen2 signaling speed (3.0 Gbps)");
		if(data & (1 << 1)) lprintf(3, "\n\t Supports Serial ATA Gen1 signaling speed (1.5 Gbps)");

		data = sm_sata_read64(location + 156);		// Word: 78-79
		lprintf(3, "\n Serial ATA features supported - Word #79-78 - 0x%08x", data);
		lprintf(3, "\n\t Device Automatic Partial to Slumber transitions: ");
		if(data & (1 << 7)){
			lprintf(3, "Supported");
			if(data & (1 << (7+16)))
				lprintf(3, " - Enabled");
			else
				lprintf(3, " - Disabled");
		}
		else
			lprintf(3, "NOT Supported");

		lprintf(3, "\n\t Software settings preservation: ");
		if(data & (1 << 6)){
			lprintf(3, "Supported");
			if(data & (1 << (6+16)))
				lprintf(3, " - Enabled");
			else
				lprintf(3, " - Disabled");
		}
		else
			lprintf(3, "NOT Supported");

		lprintf(3, "\n\t Asynchronous Notification: ");
		if(data & (1 << 5)){
			lprintf(3, "Supported");
			if(data & (1 << (5+16)))
				lprintf(3, " - Enabled");
			else
				lprintf(3, " - Disabled");
		}
		else
			lprintf(3, "NOT Supported");

		lprintf(3, "\n\t Guaranteed In-Order Data Delivery: ");
		if(data & (1 << 4)){
			lprintf(3, "Supported");
			if(data & (1 << (4+16)))
				lprintf(3, " - Enabled");
			else
				lprintf(3, " - Disabled");
		}
		else
			lprintf(3, "NOT Supported");

		lprintf(3, "\n\t Device initiating interface power management: ");
		if(data & (1 << 3)){
			lprintf(3, "Supported");
			if(data & (1 << (3+16)))
				lprintf(3, " - Enabled");
			else
				lprintf(3, " - Disabled");
		}
		else
			lprintf(3, "NOT Supported");

		lprintf(3, "\n\t DMA Setup FIS Auto-Activate optimization: ");
		if(data & (1 << 2)){
			lprintf(3, "Supported");
			if(data & (1 << (2+16)))
				lprintf(3, " - Enabled");
			else
				lprintf(3, " - Disabled");
		}
		else
			lprintf(3, "NOT Supported");

		lprintf(3, "\n\t Non-zero buffer offset in DMA Setup FIS: ");
		if(data & (1 << 1)){
			lprintf(3, "Supported");
			if(data & (1 << (1+16)))
				lprintf(3, " - Enabled");
			else
				lprintf(3, " - Disabled");
		}
		else
			lprintf(3, "NOT Supported");
	}
	else{
		lprintf(3, "\n SATA READ ID FAILED");
		return -1;
	}
	printf("\n");
	return 0;
}

int sm_sata_fis_h2d(int port)
{
	int rc = 0;
	int timeout = 100;
	u64 location = SATA_DATA_READ_BASE;
#if 0
	sm_sata_cmds_init(0, ATA_CMD_IDENT, 0, 0x40, 0, 0, 3, location, 1, 0, 1);
	sm_sata_cmds_exe(port, 0, 1, 0);
	while((sm_sata_get_busy_slots(port) != 0) && --timeout){
		sm_sata_msdelay(10);
	}

	timeout = 100;
#endif
	sm_sata_cmd_setup(0, 0, ATA_CMD_RD_NATI_MAX_EXT, location, 1, 1, 0, 3, 0);
	sm_sata_cmds_exe(port, 0, 1, 0);
	while((sm_sata_get_busy_slots(port) != 0) && --timeout){
		sm_sata_msdelay(10);
	}

	if(timeout ==0){
		printf("Slot is not coming out of busy\n");
		return -1;
	}
	else
		return rc;
}

void sm_sata_pio_read(int port, int pmp, int start_sector, int sector_count){
	u64 location = SATA_DATA_READ_BASE;
	u32 cmd;
	int timeout = 10;

	test_id = 2;
	memory_reset(location, 1);
	memory_display(location, 5);
	sm_sata_cmd_setup(0, pmp, cmd, location, start_sector, sector_count, 0, 0, 0);
	sm_sata_cmds_exe(port, 0, 1, 0);
	while((sm_sata_get_busy_slots(port) != 0) && --timeout){
		sm_sata_msdelay(200);
	}
	memory_display(location, 5);
	test_id = 0;
}

void sm_sata_pio_write(int port, int start_sector, int sector_count){
	u64 location = SATA_DATA_WRITE_BASE;
	u32 cmd;
	int timeout = 10;

	test_id = 2;
	memory_create_data(location, sector_count);
	memory_display(location, 5);
	cmd = (sector_count < 256) ? ATA_CMD_PIO_WR : ATA_CMD_PIO_WR_EXT;
	memory_create_data(location, sector_count);
	sm_sata_cmd_setup(1, 0, cmd, location, start_sector, sector_count, 0, 0, 0);
	sm_sata_cmds_exe(port, 0, 2, 0);
	while((sm_sata_get_busy_slots(port) != 0) && --timeout){
		sm_sata_msdelay(200);
	}
	test_id = 0;
}

int sm_sata_pio_test(int port, int pmp){
	u64 fr = SATA_DATA_WRITE_BASE;
	u64 to = SATA_DATA_READ_BASE;
	u32 start_sector = 5;
	u32 sector_count = 2000;
	u32 rd_cmd, wr_cmd;
	int rc = 0;
	int timeout = 20;

	test_id = 2;
	lprintf(6, "\n\n sm_sata_pio_test - START");

	if(NUM_SECTOR < 256){
		rd_cmd = ATA_CMD_PIO_RD;
		wr_cmd = ATA_CMD_PIO_WR;
	}
	else{
		rd_cmd = ATA_CMD_PIO_RD_EXT;
		wr_cmd = ATA_CMD_PIO_WR_EXT;
	}
	lprintf(4, "\n Setting up ATA commands for PIO Write(0x%02X) / Read(0x%02X)", wr_cmd, rd_cmd);
	lprintf(4, "\n\t Start sector: %d", STA_SECTOR);
	lprintf(4, "\n\t Sector count: %d", NUM_SECTOR);
	memory_reset(to, NUM_SECTOR);
	memory_create_data(fr, NUM_SECTOR);
	sm_sata_port_irq(port, 1 << 5);		// Descriptor  Processed  Interrupt  Enable  (DPE)
	sm_sata_pmp_cmd_chk(port, pmp);
	sm_sata_cmd_setup(0, pmp, wr_cmd, fr, start_sector, sector_count, 0, 0, 0);
	sm_sata_cmd_setup(1, pmp, rd_cmd, to, start_sector, sector_count, 0, 0, 0);
	sm_sata_cmds_exe(port, 0, 3, 0);
	while((sm_sata_get_busy_slots(port) != 0) && --timeout){
		sm_sata_msdelay(200);
	}
	if(timeout == 0) {
		lprintf(3, "\n CMD failed to complete");
		lprintf(3, "\n\t DMA READ/WRITE TEST FAILED \n");
		rc = -1;
	}else {
		rc = memory_compare(0, fr, to, NUM_SECTOR);
		if(rc != 0) {
			lprintf(3, "\n\t PIO READ/WRITE TEST FAILED \n");
			sm_sata_port_status(port);
		}else
			lprintf(3, "\n\t PIO READ/WRITE TEST PASSED \n");
	}

	test_id = 0;
	return rc;
}

void sm_sata_dma_read(int port){
	u64 location = SATA_DATA_READ_BASE;
	u32 cmd;
	int timeout = 10;

	test_id = 3;
//	memory_reset(location, 1);
//	memory_display(location, 5);
	cmd = (NUM_SECTOR < 256) ? ATA_CMD_DMA_RD : ATA_CMD_DMA_RD_EXT;
	sm_sata_cmd_setup(0, 0, cmd, location, STA_SECTOR, NUM_SECTOR, 0, 0, 0);
	sm_sata_cmds_exe(port, 0, 1, 0);
#if 1
	while(sm_sata_get_busy_slots(port) != 0){
		sm_sata_msdelay(200);
	}
#else
	while((sm_sata_get_busy_slots(port) != 0) && --timeout){
		sm_sata_msdelay(200);
	}
#endif
//	memory_display(location, 5);
}

void sm_sata_dma_write(int port){
	u64 location = SATA_DATA_WRITE_BASE;
	u32 cmd;
	int timeout = 10;

	test_id = 3;
	memory_display(location, 5);
	cmd = (STA_SECTOR < 256) ? ATA_CMD_DMA_WR : ATA_CMD_DMA_WR_EXT;
//	memory_create_data(location, NUM_SECTOR);
	sm_sata_cmd_setup(1, 0, cmd, location, STA_SECTOR, NUM_SECTOR, 0, 0, 0);
	sm_sata_cmds_exe(port, 0, 2, 0);
#if 1
	while(sm_sata_get_busy_slots(port) != 0){
		sm_sata_msdelay(200);
	}
#else
	while((sm_sata_get_busy_slots(port) != 0) && --timeout){
		sm_sata_msdelay(200);
	}
#endif
}

int sm_sata_dma_test(int port, int pmp){
	u64 fr = SATA_DATA_WRITE_BASE;
	u64 to = SATA_DATA_READ_BASE;
	u32 start_sector = 10;
	u32 sector_count = 100;
	u32 rd_cmd, wr_cmd, empty_slot;
	int rc = 0;
	int timeout = 20;

	test_id = 3;
	lprintf(6, "\n\n sm_sata_dma_test - START");
	if(NUM_SECTOR < 256){
		rd_cmd = ATA_CMD_DMA_RD;
		wr_cmd = ATA_CMD_DMA_WR;
	}
	else{
		rd_cmd = ATA_CMD_DMA_RD_EXT;
		wr_cmd = ATA_CMD_DMA_WR_EXT;
	}
	lprintf(4, "\n Setting up ATA commands for DMA Write(0x%02X) / Read(0x%02X)", wr_cmd, rd_cmd);
	lprintf(4, "\n\t Start sector: %d", STA_SECTOR);
	lprintf(4, "\n\t Sector count: %d", NUM_SECTOR);
	memory_reset(to, NUM_SECTOR);
	memory_create_data(fr, NUM_SECTOR);
	sm_sata_port_irq(port, 1 << 5);		// Descriptor  Processed  Interrupt  Enable  (DPE)

	sm_sata_pmp_cmd_chk(port, pmp);

#if 0
	printf("\n writing");
	empty_slot = sm_sata_get_free_slot(port);
	sm_sata_cmd_setup(empty_slot, pmp, wr_cmd, fr, start_sector, sector_count, 0, 0, 0);
	sm_sata_cmds_exe(port, 0, 1 << empty_slot, 0);
	timeout = 10;
	while((sm_sata_get_busy_slots(port) != 0) && --timeout){
		sm_sata_msdelay(200);
	}
	if(timeout == 0) printf("\n WriteCMD failed to complete");

	printf("\n reading");
	empty_slot = sm_sata_get_free_slot(port);
	sm_sata_cmd_setup(empty_slot, pmp, rd_cmd, to, start_sector, sector_count, 0, 0, 0);
	sm_sata_cmds_exe(port, 0, 1 << empty_slot, 0);
	timeout = 10;
	while((sm_sata_get_busy_slots(port) != 0) && --timeout){
		sm_sata_msdelay(200);
	}
	if(timeout == 0) printf("\n Read CMD failed to complete");

#else
	sm_sata_cmd_setup(0, pmp, wr_cmd, fr, start_sector, sector_count, 0, 0, 0);
	sm_sata_cmd_setup(1, pmp, rd_cmd, to, start_sector, sector_count, 0, 0, 0);
	sm_sata_cmds_exe(port, 0, 3, 0);
	while((sm_sata_get_busy_slots(port) != 0) && --timeout){
		sm_sata_msdelay(200);
	}
#endif
	if(timeout == 0){
		lprintf(3, "\n CMD failed to complete");
		lprintf(3, "\n\t DMA READ/WRITE TEST FAILED \n");
		rc = -1;
	}
	else{
		rc = memory_compare(0, fr, to, NUM_SECTOR);
		if(rc != 0){
			lprintf(3, "\n\t DMA READ/WRITE TEST FAILED \n");
			sm_sata_port_status(port);
		}
		else
			lprintf(3, "\n\t DMA READ/WRITE TEST PASSED \n");
	}

	test_id = 0;
	return rc;
}

void sm_sata_fpdma_read(int port, int start_sector, int sector_count){
	u64 location = SATA_DATA_READ_BASE;
	int timeout = 10;

	test_id = 4;
	memory_reset(location, 1);
	memory_display(location, 5);
	sm_sata_cmd_setup(0, 0, ATA_CMD_FPDMA_RD, location, start_sector, sector_count, 0, 0, 0);
	sm_sata_cmds_exe(port, 0, 1, 1);
	while((sm_sata_get_busy_slots(port) != 0) && --timeout){
		sm_sata_msdelay(200);
	}
	memory_display(location, 5);
}

void sm_sata_fpdma_write(int port, int start_sector, int sector_count){
	u64 location = SATA_DATA_WRITE_BASE;
	int timeout = 10;

	test_id = 4;
	memory_create_data(location, sector_count);
	memory_display(location, 5);
	sm_sata_cmd_setup(0, 0, ATA_CMD_FPDMA_WR, location, start_sector, sector_count, 0, 0, 0);
	sm_sata_cmds_exe(port, 0, 1, 1);
	while((sm_sata_get_busy_slots(port) != 0) && --timeout){
		sm_sata_msdelay(200);
	}
}

int sm_sata_fpdma_test(int port, int pmp){
	u64 fr = SATA_DATA_WRITE_BASE;
	u64 to = SATA_DATA_READ_BASE;
	u32 rd_cmd, wr_cmd;
	int start_sector = 0x800;
	int sector_count = 200;
	int timeout = 20;
	int rc = 0;

	test_id = 4;
	rd_cmd = ATA_CMD_FPDMA_RD;
	wr_cmd = ATA_CMD_FPDMA_WR;

	lprintf(4, "\n Setting up ATA commands for FPDMA Write(0x%02X) / Read(0x%02X)", wr_cmd, rd_cmd);
	lprintf(4, "\n\t Start sector: %d", STA_SECTOR);
	lprintf(4, "\n\t Sector count: %d", NUM_SECTOR);
	memory_reset(to, NUM_SECTOR);
	memory_create_data(fr, NUM_SECTOR);
	sm_sata_port_irq(port, 1 << 5);		// Descriptor  Processed  Interrupt  Enable  (DPE)
	sm_sata_pmp_cmd_chk(port, pmp);
	sm_sata_cmd_setup(0, pmp, wr_cmd, fr, start_sector, sector_count, 0, 0, 0);
	sm_sata_cmd_setup(1, pmp, rd_cmd, to, start_sector, sector_count, 0, 0, 0);
	sm_sata_cmds_exe(port, 0, 3, 3);
	while((sm_sata_get_busy_slots(port) != 0) && --timeout){
		sm_sata_msdelay(200);
	}
	rc = memory_compare(0, fr, to, NUM_SECTOR);
	if(rc != 0)
		lprintf(3, "\n\t FPDMA READ/WRITE TEST FAILED \n");
	else
		lprintf(3, "\n\t FPDMA READ/WRITE TEST PASSED \n");

	test_id = 0;
	return rc;
}

void sm_sata_xdata_stress(int port, int pmp, int direction, int wr_cmd, int rd_cmd, int start_sector, int sector_count, int loop){
	/*
	 * direction: 0-Read, 1-Write, 2-Read/Write
	 */
	int k;
	int timeout;
	int empty_slot, RdWr, cmd_cnt = 0;
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);
	u64 fr = SATA_DATA_WRITE_BASE;
	u64 to = SATA_DATA_READ_BASE;

	test_id = 8;
	irq_cnt = 0;
	k = (loop == 0) ? 1 : 0;
	//sm_sata_irq(port);

	sm_sata_port_irq(port, 1 << 2);		// DMA Setup FIS Interrupt Enable
	memory_create_data(fr, sector_count);
	RdWr = 1;

	do{
		empty_slot = sm_sata_get_free_slot(port);
		if(empty_slot < 32){
			printf(".");
//			printf("\nP%dCI [0x%08x] = 0x%08X", port, sata_ahci_port_base + CI0__ADDR, sm_sata_read32(sata_ahci_port_base + CI0__ADDR));
			timeout = 10;
			switch(direction){
			case 0:
				RdWr = 0;
				break;
			case 1:
				RdWr = 1;
				break;
			default:	// for stress test
				break;
			}
			if(RdWr){
				sm_sata_cmd_setup(empty_slot, pmp, wr_cmd, fr, start_sector, sector_count, 0, 0, 0);
				RdWr = 0;
				start_sector += (direction == 1) ? sector_count : 0;
			}else{
				sm_sata_cmd_setup(empty_slot, pmp, rd_cmd, to, start_sector, sector_count, 0, 0, 0);
				RdWr = 1;
				start_sector += sector_count;
			}
			if((rd_cmd == ATA_CMD_FPDMA_WR) || (wr_cmd == ATA_CMD_FPDMA_WR))
				sm_sata_cmds_exe(port, 0, 1 << empty_slot, 1 << empty_slot);
			else
				sm_sata_cmds_exe(port, 0, 1 << empty_slot, 0);
			cmd_cnt++;
		}else{
			--timeout;
			sm_sata_msdelay(200);	// wait for empty command slots
		}
	}while(((--loop) || k) && timeout);

	lprintf(3, "\n Number of commands sent = %d", cmd_cnt);
	sm_sata_msdelay(5000);		// wait for all commands executed
	lprintf(3, "\n P%dSACT                  = 0x%08x", port, sm_sata_read32(sm_sata_get_ahci_port_base(port) + SACT0__ADDR));
	lprintf(3, "\n P%dCI                    = 0x%08x", port, sm_sata_read32(sm_sata_get_ahci_port_base(port) + CI0__ADDR));

	test_id = 0;
}

void view_pwr_mode(int port){
	u32 data;
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);

	data = sm_sata_read32(sata_ahci_port_base + SSTS0__ADDR);
	switch(data & 0x00000F00){
		case 0x100:
			printf("\n\tInterface in ACTIVE state\n");
			break;
		case 0x200:
			printf("\n\tInterface in PARTIAL power management state\n");
			break;
		case 0x600:
			printf("\n\tInterface in SLUMBER power management state\n");
			break;
		default:
			printf("\n\tP%dSSTS = 0x%08x", port, data);
			printf("\n\t[ERROR]: Device not present or communication not established \n");
			break;
	}
}

int sm_sata_go_partial(int port, int pmp){
	int timeout;
	u32 loc = SATA_DATA_READ_BASE;
	u32 PARTIAL = 1 << 26;
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);
	u32 data32;

	// go to PARTIAL
	sm_sata_cmd_setup(0, pmp, ATA_CMD_PWR_CHK, 0, 0, 0, 0, 0, 0);
	sm_sata_cmds_exe(port, PARTIAL, 1, 0);
	timeout = 10;
	while(sm_sata_get_busy_slots(port) && --timeout){
		sm_sata_msdelay(200);
	}
	lprintf(3, "\n Going to PARTIAL Power State ..................... ");
	data32 = sm_sata_read32(sata_ahci_port_base + SSTS0__ADDR);
	if((data32 & 0x0F00) != 0x200){
		lprintf(3, "FAILED");
		return -1;
	}
	else
		lprintf(3, "PASSED");
	return 0;
}
int sm_sata_go_slumber(int port, int pmp){
	int timeout;
	u32 loc = SATA_DATA_READ_BASE;
	u32 SLUMBER = 3 << 26;
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);
	u32 data32;

	// go to SLUMBER
	sm_sata_cmd_setup(0, pmp, ATA_CMD_PWR_CHK, 0, 0, 0, 0, 0, 0);
	sm_sata_cmds_exe(port, SLUMBER, 1, 0);
	timeout = 10;
	while(sm_sata_get_busy_slots(port) && --timeout){
		sm_sata_msdelay(200);
	}
	lprintf(3, "\n Going to SLUMBER Power State ..................... ");
	data32 = sm_sata_read32(sata_ahci_port_base + SSTS0__ADDR);
	if((data32 & 0x0F00) != 0x600){
		lprintf(3, "FAILED");
		return -1;
	}
	else
		lprintf(3, "PASSED");
	return 0;
}
int sm_sata_go_parslumauto(int port, int pmp){
	int timeout;
	u32 loc = SATA_DATA_READ_BASE;
	u32 ParSluAuto = 9 << 23;
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);
	u32 data32;

	// go PARTIAL to SLUMBER Auto
	sm_sata_cmd_setup(0, pmp, ATA_CMD_PWR_CHK, 0, 0, 0, 0, 0, 0);
	sm_sata_cmds_exe(port, ParSluAuto, 1, 0);
	timeout = 10;
	while(sm_sata_get_busy_slots(port) && --timeout){
		sm_sata_msdelay(200);
	}
	lprintf(3, "\n Going PARTIAL to SLUMBER AUTO Power State ........ ");
	data32 = sm_sata_read32(sata_ahci_port_base + SSTS0__ADDR);
	if((data32 & 0x0F00) != 0x600){
		lprintf(3, "FAILED");
		return -1;
	}
	else
		lprintf(3, "PASSED");
	return 0;
}
int sm_sata_go_active(int port, int pmp){
	int timeout;
	u32 loc = SATA_DATA_READ_BASE;
	u32 ACTIVE = 1 << 28;
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);
	u32 data32;

	// go to PARTIAL
	sm_sata_cmd_setup(0, pmp, ATA_CMD_PWR_CHK, 0, 0, 0, 0, 0, 0);
	sm_sata_cmds_exe(port, ACTIVE, 1, 0);
	timeout = 10;
	while(sm_sata_get_busy_slots(port) && --timeout){
		sm_sata_msdelay(200);
	}
	lprintf(3, "\n Going to ACTIVE Power State ...................... ");
	data32 = sm_sata_read32(sata_ahci_port_base + SSTS0__ADDR);
	if((data32 & 0x0F00) != 0x100){
		lprintf(3, "FAILED");
		return -1;
	}
	else
		lprintf(3, "PASSED");
	return 0;
}

int sm_sata_pwr_test(int port, int pmp){
	int timeout, rc = 0;
	u32 loc = SATA_DATA_READ_BASE;
	u32 ACTIVE = 1 << 28;
	u32 PARTIAL = 1 << 26;
	u32 SLUMBER = 3 << 26;
	u32 ParSluAuto = 9 << 23;
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);
	u32 data;

	test_id = 0;
	sm_sata_port_irq(port, 1 << 22);	// PhyRdy Change Interrupt Enable (PRCE)

	printf("\n Current Power State:");
	view_pwr_mode(port);

	rc += sm_sata_go_partial(port, pmp);
	view_pwr_mode(port);

	rc += sm_sata_go_slumber(port, pmp);
	view_pwr_mode(port);

	rc += sm_sata_go_active(port, pmp);
	view_pwr_mode(port);

	rc += sm_sata_go_partial(port, pmp);
	view_pwr_mode(port);

	rc += sm_sata_go_parslumauto(port, pmp);
	view_pwr_mode(port);

	rc += sm_sata_go_active(port, pmp);
	view_pwr_mode(port);

	rc += sm_sata_go_slumber(port, pmp);
	view_pwr_mode(port);

	rc += sm_sata_go_partial(port, pmp);
	view_pwr_mode(port);

	rc += sm_sata_go_active(port, pmp);
	view_pwr_mode(port);
	return rc;
}

void sm_sata_ccc_test(int port, int pmp){
	int rc = 0;
	int i, num_cmd = 16;
	int ci_cmd = 0;
	int startl = 100;
	int sec_cnt = 10000;
	int rd_cmd, wr_cmd, timeout;
	int verbose = g_verbose_level;
	u64 fr = SATA_DATA_WRITE_BASE;
	u64 to = SATA_DATA_READ_BASE;

	test_id = 5;
	irq_cnt = 0;
	irq_ccc_cnt = 0;

	rd_cmd = ATA_CMD_DMA_RD_EXT;
	wr_cmd = ATA_CMD_DMA_WR_EXT;

	g_verbose_level = 4;
	memory_create_data(fr, sec_cnt*num_cmd);
	memory_reset(to, sec_cnt*num_cmd);
	sm_sata_port_irq(port, ALL_IRQS);
	g_verbose_level = verbose;
	printf("\n\n Command Completion Coalescing Disable.");
	printf("\n All IRQs in P%dIE are enabled.", port);
	for(i=0; i<num_cmd; ++i){
		sm_sata_cmds_init(0, wr_cmd, i, 0x40, 0, 1, 12, fr + (i*sec_cnt*512), startl + i*sec_cnt, 0, sec_cnt);
		sm_sata_cmds_init(0, rd_cmd, i+num_cmd, 0x40, 0, 0, 12, to + (i*sec_cnt*512), startl + i*sec_cnt, 0, sec_cnt);
		ci_cmd |= (1 << i) | (1 << (i+num_cmd));
	}
	sm_sata_cmds_exe(port, 0, ci_cmd, 0);
	timeout = 10;
	while(sm_sata_get_busy_slots(port) && --timeout){
		sm_sata_msdelay(500);
	}
	printf("\n\n Number of regular IRQ: %d", irq_cnt);
	printf("\n Number of CCC IRQ    : %d", irq_ccc_cnt);
	g_verbose_level = 4;
	rc = memory_compare(0, fr, to, sec_cnt*num_cmd);
	printf("\n\n");
	g_verbose_level = verbose;

	if(rc == 0){
		// enable CCC
		irq_cnt = 0;
		irq_ccc_cnt = 0;
		g_verbose_level = 4;
		memory_reset(to, sec_cnt*num_cmd);
		sm_sata_irq_ccc_en(port, 3000, 2);
		g_verbose_level = verbose;
		for(i=0; i<num_cmd; ++i){
			sm_sata_cmds_init(0, wr_cmd, i, 0x40, 0, 1, 12, fr + (i*sec_cnt*512), startl + i*sec_cnt, 0, sec_cnt);
			sm_sata_cmds_init(0, rd_cmd, i+num_cmd, 0x40, 0, 0, 12, to + (i*sec_cnt*512), startl + i*sec_cnt, 0, sec_cnt);
			ci_cmd |= (1 << i) | (1 << (i+num_cmd));
		}
		sm_sata_cmds_exe(port, 0, ci_cmd, 0);
		timeout = 10;
		while(sm_sata_get_busy_slots(port) && --timeout){
			sm_sata_msdelay(500);
		}
		printf("\n Number of regular IRQ: %d", irq_cnt);
		printf("\n Number of CCC IRQ    : %d", irq_ccc_cnt);
		g_verbose_level = 4;
		rc = memory_compare(0, fr, to, sec_cnt*num_cmd);
		printf("\n\n");
		g_verbose_level = verbose;
	}

	if(rc == 0){
		irq_cnt = 0;
		irq_ccc_cnt = 0;
		g_verbose_level = 4;
		memory_reset(to, sec_cnt*num_cmd);
		sm_sata_irq_ccc_en(port, 3000, 32);
		g_verbose_level = verbose;
		for(i=0; i<num_cmd; ++i){
			sm_sata_cmds_init(0, wr_cmd, i, 0x40, 0, 1, 12, fr + (i*sec_cnt*512), startl + i*sec_cnt, 0, sec_cnt);
			sm_sata_cmds_init(0, rd_cmd, i+num_cmd, 0x40, 0, 0, 12, to + (i*sec_cnt*512), startl + i*sec_cnt, 0, sec_cnt);
			ci_cmd |= (1 << i) | (1 << (i+num_cmd));
		}
		sm_sata_cmds_exe(port, 0, ci_cmd, 0);
		timeout = 10;
		while(sm_sata_get_busy_slots(port) && --timeout){
			sm_sata_msdelay(500);
		}
		printf("\n Number of regular IRQ: %d", irq_cnt);
		printf("\n Number of CCC IRQ    : %d", irq_ccc_cnt);
		g_verbose_level = 4;
		rc = memory_compare(0, fr, to, sec_cnt*num_cmd);
		printf("\n\n");
		g_verbose_level = verbose;
	}

	if(rc == 0){
		irq_cnt = 0;
		irq_ccc_cnt = 0;
		g_verbose_level = 4;
		memory_reset(to, sec_cnt*num_cmd);
		sm_sata_irq_ccc_en(port, 10, 32);
		g_verbose_level = verbose;
		for(i=0; i<num_cmd; ++i){
			sm_sata_cmds_init(0, wr_cmd, i, 0x40, 0, 1, 12, fr + (i*sec_cnt*512), startl + i*sec_cnt, 0, sec_cnt);
			sm_sata_cmds_init(0, rd_cmd, i+num_cmd, 0x40, 0, 0, 12, to + (i*sec_cnt*512), startl + i*sec_cnt, 0, sec_cnt);
			ci_cmd |= (1 << i) | (1 << (i+num_cmd));
		}
		sm_sata_cmds_exe(port, 0, ci_cmd, 0);
		timeout = 10;
		while(sm_sata_get_busy_slots(port) && --timeout){
			sm_sata_msdelay(500);
		}
		printf("\n Number of regular IRQ: %d", irq_cnt);
		printf("\n Number of CCC IRQ    : %d", irq_ccc_cnt);
		g_verbose_level = 4;
		rc = memory_compare(0, fr, to, sec_cnt*num_cmd);
		printf("\n\n");
		g_verbose_level = verbose;
	}
	test_id = 0;
}

void sm_sata_ncq_test(int port, int pmp){
	int rc = 0;
	int i, num_cmd = 16;
	int sact_cmd = 0;
	int startl = 100;
	int sec_cnt = 10000;
	int rd_cmd, wr_cmd, timeout = 10;
	int verbose = g_verbose_level;
	u64 fr = SATA_DATA_WRITE_BASE;
	u64 to = SATA_DATA_READ_BASE;

	test_id = 6;

	rd_cmd = ATA_CMD_FPDMA_RD;
	wr_cmd = ATA_CMD_FPDMA_WR;
	g_verbose_level = 4;
	memory_create_data(fr, sec_cnt*num_cmd);
	memory_reset(to, sec_cnt*num_cmd);
	sm_sata_port_irq(port, 1 << 2);		// DMA Setup FIS Interrupt Enable

	for(i=0; i<num_cmd; ++i){
		sm_sata_cmds_init(0, wr_cmd, i, 0x40, 0, 1, 12, fr + (i*sec_cnt*512), startl + i*sec_cnt, 0, sec_cnt);
		sm_sata_cmds_init(0, rd_cmd, i+num_cmd, 0x40, 0, 0, 12, to + (i*sec_cnt*512), startl + i*sec_cnt, 0, sec_cnt);
		sact_cmd |= (1 << i) | (1 << (i+num_cmd));
	}
	sm_sata_cmds_exe(port, 0, sact_cmd, sact_cmd);
	while(sm_sata_get_busy_slots(port) && --timeout){
		sm_sata_msdelay(500);
	}
	rc = memory_compare(0, fr, to, sec_cnt*num_cmd);
	g_verbose_level = verbose;
	if(rc != 0)
		lprintf(3, "\n\t NCQ TEST FAILED \n");
	else
		lprintf(3, "\n\t NCQ TEST PASSED \n");

	test_id = 0;
}

int sm_sata_irq_test(int port, int pmp, int irq_id){
	int timeout;
	u32 addr, data;
	u32 sata_ahci_base = sm_sata_get_ahci_base(port);
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);
	u64 fr = SATA_DATA_WRITE_BASE;
	u64 to = SATA_DATA_READ_BASE;
	u32 ACTIVE  = 1 << 28;
	u32 PARTIAL = 1 << 26;
	u32 SLUMBER = 3 << 26;

	test_id = 9;
	irq_cnt = 0;
	addr = sata_ahci_port_base + IS0__ADDR;
	sm_sata_write32(addr, ALL_IRQS);	// clear Port IRQ Status
	data = sm_sata_read32(addr);
	if(data){
		printf("\n [ERROR] Unable to clear Port IRQ Status, P%dIS = 0x%08X", port, data);
		return -1;
	}
	addr = sata_ahci_base + IS__ADDR;
	sm_sata_write32(addr, 0xFFFFFFFF);	// clear Controller IRQ Status
	data = sm_sata_read32(addr);
	if(data){
		printf("\n [ERROR] Unable to clear Controller IRQ Status, IS = 0x%08X", data);
		return -1;
	}
	sm_sata_write32(sata_ahci_port_base + IE0__ADDR, 1 << irq_id);
	//sm_host_write32(sata_ahci_port_base + IE0__ADDR, ALL_IRQS);
	//sm_sata_port_irq(port, 1 << irq_id);
	switch(irq_id){
	case 0:
	case 22:
		printf("\n going to Partial State Mode ...");
		//sm_sata_cmds_init(pmp, ATA_CMD_PWR_CHK, 0, 0x40, 0, 0, 12, loc, 1, 0, 1);
		sm_sata_cmds_init(pmp, ATA_CMD_PWR_CHK, 0, 0x40, 0, 0, 12, to, 1, 0, 1);
		//sm_sata_cmd_setup(0, pmp, ATA_CMD_PWR_CHK, to, 0, 0, 0, 0, 0);
		sm_sata_cmds_exe(port, PARTIAL, 1, 0);
		break;
	case 1:
		printf("\n doing an ID Read ...");
		sm_sata_cmd_setup(0, pmp, ATA_CMD_IDENT, to, 0, 1, 0, 0, 0);
		sm_sata_cmds_exe(port, 0, 1, 1);
		break;
	case 2:
	case 3:
	case 5:
		printf("\n doing a FPDMA Read ...");
		//sm_sata_cmd_setup(0, pmp, ATA_CMD_FPDMA_WR, fr, 1, 1000, 0, 0, 0);
		sm_sata_cmd_setup(0, pmp, ATA_CMD_FPDMA_RD, to, 1, 10, 0, 0, 0);
		sm_sata_cmds_exe(port, 0, 1, 1);
		break;
	case 6:
		printf("\n Please unplug the device ...");
//		printf("\n going to Partial State Mode ...");
		//sm_sata_cmds_init(pmp, ATA_CMD_PWR_CHK, 0, 0x40, 0, 0, 12, loc, 1, 0, 1);
		//sm_sata_cmds_init(pmp, ATA_CMD_PWR_CHK, 0, 0x40, 0, 0, 12, to, 1, 0, 1);
//		sm_sata_cmd_setup(0, pmp, ATA_CMD_PWR_CHK, to, 0, 0, 0, 0, 0);
//		sm_sata_cmds_exe(port, PARTIAL, 1, 0);
		break;
	default:
		break;
	}
	timeout = 100;
	while(sm_sata_get_busy_slots(port) && --timeout){
		sm_sata_msdelay(10);
	}
	test_id = 0;
	return (irq_cnt) ? 0 : -1;
}

int sm_sata_hotplug_test(int port, int pmp){
	u32 addr, data;
	u32 sata_ahci_base = sm_sata_get_ahci_base(port);
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);

	test_id = 10;
	irq_cnt = 0;
	addr = sata_ahci_port_base + IS0__ADDR;
	sm_host_write32(addr, ALL_IRQS);	// clear Port IRQ Status
	sm_host_read32(addr, &data);
	if(data){
		printf("\n [ERROR] Unable to clear Port IRQ Status, P%dIS = 0x%08X", port, data);
		return -1;
	}
	addr = sata_ahci_base + IS__ADDR;
	sm_host_write32(addr, 0xFFFFFFFF);	// clear Controller IRQ Status
	sm_host_read32(addr, &data);
	if(data){
		printf("\n [ERROR] Unable to clear Controller IRQ Status, IS = 0x%08X", data);
		return -1;
	}
	sm_host_write32(sata_ahci_port_base + IE0__ADDR, ALL_IRQS);		// enable all irqs
	printf("\n Please perform hotplug activities within the next 20 seconds.\n");
	sm_sata_msdelay(20000);
	return (irq_cnt) ? 0 : 1;
}

int sm_sata_asr_test(int port, int pmp){
	u32 addr, data;
	u32 sata_ahci_base = sm_sata_get_ahci_base(port);
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);

	test_id = 11;
	irq_cnt = 0;
	addr = sata_ahci_port_base + IS0__ADDR;
	sm_host_write32(addr, ALL_IRQS);	// clear Port IRQ Status
	sm_host_read32(addr, &data);
	if(data){
		printf("\n [ERROR] Unable to clear Port IRQ Status, P%dIS = 0x%08X", port, data);
		return -1;
	}
	addr = sata_ahci_base + IS__ADDR;
	sm_host_write32(addr, 0xFFFFFFFF);	// clear Controller IRQ Status
	sm_host_read32(addr, &data);
	if(data){
		printf("\n [ERROR] Unable to clear Controller IRQ Status, IS = 0x%08X", data);
		return -1;
	}
	sm_host_write32(sata_ahci_port_base + IE0__ADDR, ALL_IRQS);
	//sm_sata_port_irq(port, 1 << irq_id);
	printf("\n Please unplug and re-plug in the device on SATA Port%d within the next 20 seconds.\n", port);
	sm_sata_msdelay(20000);
	//printf("\n irq_cnt = %d", irq_cnt);
	if(irq_cnt == 0){
		printf("\n [WARNING]: No hotplug has been detected");
		return -1;
	}
	else if((irq_cnt % 2) == 0){
		data = sm_sata_readid(port, pmp);
		if(data)
			return -1;
		else{
			sm_sata_port_status(port);
			return 0;
		}
	}
	else{
		printf("\n [WARNING]: No device is connected to SATA Port%d", port);
		return -1;
	}
}

/***************************************************************
Function  : sm_sata_bw_monitor
parameters:
	Port - It can be from 0 to 5
	Sector_count - It can be a whole number with > 0
	mode - It can be PIO(0), DMA (1), FPDMA(2))
return val: None
***************************************************************/
void sm_sata_bw_monitor(int port, int sector_count1, int mode){
	int i, timeout, cmd_slot;
	u32 sata_csr_base = sm_sata_get_csr_base(port);
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);
	u32 rd_cmd, wr_cmd;
	u32 stop_count;
	u32 rd_time, wr_time, data, bw;
	u64 fr = SATA_DATA_WRITE_BASE;
	u64 to = SATA_DATA_READ_BASE;
	u32 sector_count = NUM_SECTOR;

	if(sector_count < 256){
		switch (mode)
		{
		case PIO:
			rd_cmd = ATA_CMD_PIO_RD;
			wr_cmd = ATA_CMD_PIO_WR;
			break;
		case DMA:
			rd_cmd = ATA_CMD_DMA_RD;
			wr_cmd = ATA_CMD_DMA_WR;
			break;
		case FPDMA:
			rd_cmd = ATA_CMD_FPDMA_RD;
			wr_cmd = ATA_CMD_FPDMA_WR;
			break;
		}
	}
	else{
		switch (mode)
		{
		case PIO:
			rd_cmd = ATA_CMD_PIO_RD_EXT;
			wr_cmd = ATA_CMD_PIO_WR_EXT;
			break;
		case DMA:
			rd_cmd = ATA_CMD_DMA_RD_EXT;
			wr_cmd = ATA_CMD_DMA_WR_EXT;
			break;
		case FPDMA:
			rd_cmd = ATA_CMD_FPDMA_RD;
			wr_cmd = ATA_CMD_FPDMA_WR;
			break;
		}
	}

	lprintf(4, "\n\n CFG_DIAG_SEL               = 0x%08x", sm_sata_read32(sata_csr_base + CFG_DIAG_SEL__ADDR));
	lprintf(4, "\n\n CFG_READ_BW_LAT_ADDR_MASK  = 0x%08x", sm_sata_read32(sata_csr_base + CFG_READ_BW_LAT_ADDR_MASK__ADDR));
	lprintf(4, "\n\n CFG_READ_BW_LAT_ADDR_PAT   = 0x%08x", sm_sata_read32(sata_csr_base + CFG_READ_BW_LAT_ADDR_PAT__ADDR));
	lprintf(4, "\n\n CFG_WRITE_BW_LAT_ADDR_MASK = 0x%08x", sm_sata_read32(sata_csr_base + CFG_WRITE_BW_LAT_ADDR_MASK__ADDR));
	lprintf(4, "\n\n CFG_WRITE_BW_LAT_ADDR_PAT  = 0x%08x", sm_sata_read32(sata_csr_base + CFG_WRITE_BW_LAT_ADDR_PAT__ADDR));
	lprintf(4, "\n\n CFG_DIAG_START_STOP        = 0x%08x", sm_sata_read32(sata_csr_base + CFG_DIAG_START_STOP__ADDR));
	lprintf(4, "\n\n CFG_BW_MSTR_STOP_CNT       = 0x%08x", sm_sata_read32(sata_csr_base + CFG_BW_MSTR_STOP_CNT__ADDR));
	lprintf(4, "\n\n CFG_BW_SLV_STOP_CNT        = 0x%08x", sm_sata_read32(sata_csr_base + CFG_BW_SLV_STOP_CNT__ADDR));
	lprintf(4, "\n\n STS_AXI_MRD_BW_CLK_CNT     = 0x%08x", sm_sata_read32(sata_csr_base + STS_AXI_MRD_BW_CLK_CNT__ADDR));
	lprintf(4, "\n\n STS_AXI_MRD_BW_BYTE_CNT    = 0x%08x", sm_sata_read32(sata_csr_base + STS_AXI_MRD_BW_BYTE_CNT__ADDR));
	lprintf(4, "\n\n STS_AXI_MWR_BW_CLK_CNT     = 0x%08x", sm_sata_read32(sata_csr_base + STS_AXI_MWR_BW_CLK_CNT__ADDR));
	lprintf(4, "\n\n STS_AXI_MWR_BW_BYTE_CNT    = 0x%08x", sm_sata_read32(sata_csr_base + STS_AXI_MWR_BW_BYTE_CNT__ADDR));
	stop_count = ((sector_count/2) | ((sector_count/2)<<16));
#if 0
	// Read speed
	if(1){
		cmd_slot = sm_sata_get_free_slot(port);
		data = ~(((sector_count*512) - 1) >> 10);
		//printf("\n\n CFG_WRITE_BW_LAT_ADDR_MASK = 0x%08x", data);
#if 0
		sm_sata_write32(sata_csr_base + CFG_READ_BW_LAT_ADDR_MASK__ADDR, data);
		sm_sata_write32(sata_csr_base + CFG_WRITE_BW_LAT_ADDR_MASK__ADDR, 0);
		data &= (fr >> 10);
		//printf("\n CFG_WRITE_BW_LAT_ADDR_PAT  = 0x%08x", data);
		sm_sata_write32(sata_csr_base + CFG_READ_BW_LAT_ADDR_PAT__ADDR, data);
		sm_sata_write32(sata_csr_base + CFG_WRITE_BW_LAT_ADDR_PAT__ADDR, -1);
		//printf("\n CFG_BW_MSTR_STOP_CNT__ADDR  = 0x%08x", stop_count);
		sm_sata_write32(sata_csr_base + CFG_BW_MSTR_STOP_CNT__ADDR, stop_count);
		sm_sata_write32(sata_csr_base + CFG_DIAG_START_STOP__ADDR, 0x1);
#else
		sm_sata_write32(sata_csr_base + CFG_READ_BW_LAT_ADDR_MASK__ADDR, data);
		sm_sata_write32(sata_csr_base + CFG_WRITE_BW_LAT_ADDR_MASK__ADDR, 0);
		data &= (fr >> 10);
		//printf("\n CFG_WRITE_BW_LAT_ADDR_PAT  = 0x%08x", data);
		sm_sata_write32(sata_csr_base + CFG_READ_BW_LAT_ADDR_PAT__ADDR, data);
		sm_sata_write32(sata_csr_base + CFG_WRITE_BW_LAT_ADDR_PAT__ADDR, -1);
		//printf("\n CFG_BW_MSTR_STOP_CNT__ADDR  = 0x%08x", stop_count);
		sm_sata_write32(sata_csr_base + CFG_BW_MSTR_STOP_CNT__ADDR, stop_count);
		sm_sata_write32(sata_csr_base + CFG_DIAG_START_STOP__ADDR, 0x1);
#endif
		//sm_sata_cmds_init(0, rd_cmd, cmd_slot, 0x40, 0, 0, 3, to, 150, 0, sector_count);
		sm_sata_cmd_setup(cmd_slot, 0, rd_cmd, fr, 1, sector_count, 0, 0, 0);
		lprintf(4, "\n\n CFG_DIAG_SEL               = 0x%08x", sm_sata_read32(sata_csr_base + CFG_DIAG_SEL__ADDR));
		lprintf(4, "\n\n CFG_READ_BW_LAT_ADDR_MASK  = 0x%08x", sm_sata_read32(sata_csr_base + CFG_READ_BW_LAT_ADDR_MASK__ADDR));
		lprintf(4, "\n\n CFG_READ_BW_LAT_ADDR_PAT   = 0x%08x", sm_sata_read32(sata_csr_base + CFG_READ_BW_LAT_ADDR_PAT__ADDR));
		lprintf(4, "\n\n CFG_WRITE_BW_LAT_ADDR_MASK = 0x%08x", sm_sata_read32(sata_csr_base + CFG_WRITE_BW_LAT_ADDR_MASK__ADDR));
		lprintf(4, "\n\n CFG_WRITE_BW_LAT_ADDR_PAT  = 0x%08x", sm_sata_read32(sata_csr_base + CFG_WRITE_BW_LAT_ADDR_PAT__ADDR));
		lprintf(4, "\n\n CFG_DIAG_START_STOP        = 0x%08x", sm_sata_read32(sata_csr_base + CFG_DIAG_START_STOP__ADDR));
		lprintf(4, "\n\n CFG_BW_MSTR_STOP_CNT       = 0x%08x", sm_sata_read32(sata_csr_base + CFG_BW_MSTR_STOP_CNT__ADDR));
		lprintf(4, "\n\n CFG_BW_SLV_STOP_CNT        = 0x%08x", sm_sata_read32(sata_csr_base + CFG_BW_SLV_STOP_CNT__ADDR));
		lprintf(4, "\n\n STS_AXI_MRD_BW_CLK_CNT     = 0x%08x", sm_sata_read32(sata_csr_base + STS_AXI_MRD_BW_CLK_CNT__ADDR));
		lprintf(4, "\n\n STS_AXI_MRD_BW_BYTE_CNT    = 0x%08x", sm_sata_read32(sata_csr_base + STS_AXI_MRD_BW_BYTE_CNT__ADDR));
		lprintf(4, "\n\n STS_AXI_MWR_BW_CLK_CNT     = 0x%08x", sm_sata_read32(sata_csr_base + STS_AXI_MWR_BW_CLK_CNT__ADDR));
		lprintf(4, "\n\n STS_AXI_MWR_BW_BYTE_CNT    = 0x%08x", sm_sata_read32(sata_csr_base + STS_AXI_MWR_BW_BYTE_CNT__ADDR));
		if(mode == FPDMA)
			sm_sata_cmds_exe(port, 0, 1 << cmd_slot, 1 << cmd_slot);
		else
			sm_sata_cmds_exe(port, 0, 1 << cmd_slot, 0);
		timeout = 1000;
		while((sm_sata_get_busy_slots(port) != 0) && --timeout){
			sm_sata_msdelay(5);
		}
		lprintf(4, "\n\n CFG_DIAG_SEL               = 0x%08x", sm_sata_read32(sata_csr_base + CFG_DIAG_SEL__ADDR));
		lprintf(4, "\n\n CFG_READ_BW_LAT_ADDR_MASK  = 0x%08x", sm_sata_read32(sata_csr_base + CFG_READ_BW_LAT_ADDR_MASK__ADDR));
		lprintf(4, "\n\n CFG_READ_BW_LAT_ADDR_PAT   = 0x%08x", sm_sata_read32(sata_csr_base + CFG_READ_BW_LAT_ADDR_PAT__ADDR));
		lprintf(4, "\n\n CFG_WRITE_BW_LAT_ADDR_MASK = 0x%08x", sm_sata_read32(sata_csr_base + CFG_WRITE_BW_LAT_ADDR_MASK__ADDR));
		lprintf(4, "\n\n CFG_WRITE_BW_LAT_ADDR_PAT  = 0x%08x", sm_sata_read32(sata_csr_base + CFG_WRITE_BW_LAT_ADDR_PAT__ADDR));
		lprintf(4, "\n\n CFG_DIAG_START_STOP        = 0x%08x", sm_sata_read32(sata_csr_base + CFG_DIAG_START_STOP__ADDR));
		lprintf(4, "\n\n CFG_BW_MSTR_STOP_CNT       = 0x%08x", sm_sata_read32(sata_csr_base + CFG_BW_MSTR_STOP_CNT__ADDR));
		lprintf(4, "\n\n CFG_BW_SLV_STOP_CNT        = 0x%08x", sm_sata_read32(sata_csr_base + CFG_BW_SLV_STOP_CNT__ADDR));
		lprintf(4, "\n\n STS_AXI_MRD_BW_CLK_CNT     = 0x%08x", sm_sata_read32(sata_csr_base + STS_AXI_MRD_BW_CLK_CNT__ADDR));
		lprintf(4, "\n\n STS_AXI_MRD_BW_BYTE_CNT    = 0x%08x", sm_sata_read32(sata_csr_base + STS_AXI_MRD_BW_BYTE_CNT__ADDR));
		lprintf(4, "\n\n STS_AXI_MWR_BW_CLK_CNT     = 0x%08x", sm_sata_read32(sata_csr_base + STS_AXI_MWR_BW_CLK_CNT__ADDR));
		lprintf(4, "\n\n STS_AXI_MWR_BW_BYTE_CNT    = 0x%08x", sm_sata_read32(sata_csr_base + STS_AXI_MWR_BW_BYTE_CNT__ADDR));
		data = sm_sata_read32(sata_csr_base + STS_AXI_MWR_BW_CLK_CNT__ADDR);
		rd_time = data * 4;

		printf("\n Read time   (ns)   = %d", rd_time);
		//bw = (sector_count/2)*(1000000000/1024)/rd_time;
		bw = ((1000000000/1024/2)*sector_count)/rd_time;
		printf("\n Read Perf.  (MB/s) = %d\n", bw);
	}

	if(1){
		cmd_slot = sm_sata_get_free_slot(port);
		data = ~(((sector_count*512) - 1) >> 10);
		//printf("\n\n CFG_WRITE_BW_LAT_ADDR_MASK = 0x%08x", data);
		sm_sata_write32(sata_csr_base + CFG_READ_BW_LAT_ADDR_MASK__ADDR, 0);
		sm_sata_write32(sata_csr_base + CFG_WRITE_BW_LAT_ADDR_MASK__ADDR, data);
		data &= (fr >> 10);
		//printf("\n CFG_WRITE_BW_LAT_ADDR_PAT  = 0x%08x", data);
		sm_sata_write32(sata_csr_base + CFG_READ_BW_LAT_ADDR_PAT__ADDR, -1);
		sm_sata_write32(sata_csr_base + CFG_WRITE_BW_LAT_ADDR_PAT__ADDR, data);
		//printf("\n CFG_BW_MSTR_STOP_CNT__ADDR  = 0x%08x", stop_count);
		sm_sata_write32(sata_csr_base + CFG_BW_MSTR_STOP_CNT__ADDR, stop_count);
		sm_sata_write32(sata_csr_base + CFG_DIAG_START_STOP__ADDR, 0x4);
		//sm_sata_cmds_init(0, wr_cmd, cmd_slot, 0x40, 0, 1, 3, fr, 150, 0, sector_count);
		sm_sata_cmd_setup(cmd_slot, 0, wr_cmd, fr, 1, sector_count, 0, 0, 0);
		lprintf(4, "\n\n CFG_DIAG_SEL               = 0x%08x", sm_sata_read32(sata_csr_base + CFG_DIAG_SEL__ADDR));
		lprintf(4, "\n\n CFG_READ_BW_LAT_ADDR_MASK  = 0x%08x", sm_sata_read32(sata_csr_base + CFG_READ_BW_LAT_ADDR_MASK__ADDR));
		lprintf(4, "\n\n CFG_READ_BW_LAT_ADDR_PAT   = 0x%08x", sm_sata_read32(sata_csr_base + CFG_READ_BW_LAT_ADDR_PAT__ADDR));
		lprintf(4, "\n\n CFG_WRITE_BW_LAT_ADDR_MASK = 0x%08x", sm_sata_read32(sata_csr_base + CFG_WRITE_BW_LAT_ADDR_MASK__ADDR));
		lprintf(4, "\n\n CFG_WRITE_BW_LAT_ADDR_PAT  = 0x%08x", sm_sata_read32(sata_csr_base + CFG_WRITE_BW_LAT_ADDR_PAT__ADDR));
		lprintf(4, "\n\n CFG_DIAG_START_STOP        = 0x%08x", sm_sata_read32(sata_csr_base + CFG_DIAG_START_STOP__ADDR));
		lprintf(4, "\n\n CFG_BW_MSTR_STOP_CNT       = 0x%08x", sm_sata_read32(sata_csr_base + CFG_BW_MSTR_STOP_CNT__ADDR));
		lprintf(4, "\n\n CFG_BW_SLV_STOP_CNT        = 0x%08x", sm_sata_read32(sata_csr_base + CFG_BW_SLV_STOP_CNT__ADDR));
		lprintf(4, "\n\n STS_AXI_MRD_BW_CLK_CNT     = 0x%08x", sm_sata_read32(sata_csr_base + STS_AXI_MRD_BW_CLK_CNT__ADDR));
		lprintf(4, "\n\n STS_AXI_MRD_BW_BYTE_CNT    = 0x%08x", sm_sata_read32(sata_csr_base + STS_AXI_MRD_BW_BYTE_CNT__ADDR));
		lprintf(4, "\n\n STS_AXI_MWR_BW_CLK_CNT     = 0x%08x", sm_sata_read32(sata_csr_base + STS_AXI_MWR_BW_CLK_CNT__ADDR));
		lprintf(4, "\n\n STS_AXI_MWR_BW_BYTE_CNT    = 0x%08x", sm_sata_read32(sata_csr_base + STS_AXI_MWR_BW_BYTE_CNT__ADDR));
		if(mode == FPDMA)
			sm_sata_cmds_exe(port, 0, 1 << cmd_slot, 1 << cmd_slot);
		else
			sm_sata_cmds_exe(port, 0, 1 << cmd_slot, 0);
		timeout = 100;
		while((sm_sata_get_busy_slots(port) != 0) && --timeout){
			sm_sata_msdelay(50);
		}
		lprintf(4, "\n\n CFG_DIAG_SEL               = 0x%08x", sm_sata_read32(sata_csr_base + CFG_DIAG_SEL__ADDR));
		lprintf(4, "\n\n CFG_READ_BW_LAT_ADDR_MASK  = 0x%08x", sm_sata_read32(sata_csr_base + CFG_READ_BW_LAT_ADDR_MASK__ADDR));
		lprintf(4, "\n\n CFG_READ_BW_LAT_ADDR_PAT   = 0x%08x", sm_sata_read32(sata_csr_base + CFG_READ_BW_LAT_ADDR_PAT__ADDR));
		lprintf(4, "\n\n CFG_WRITE_BW_LAT_ADDR_MASK = 0x%08x", sm_sata_read32(sata_csr_base + CFG_WRITE_BW_LAT_ADDR_MASK__ADDR));
		lprintf(4, "\n\n CFG_WRITE_BW_LAT_ADDR_PAT  = 0x%08x", sm_sata_read32(sata_csr_base + CFG_WRITE_BW_LAT_ADDR_PAT__ADDR));
		lprintf(4, "\n\n CFG_DIAG_START_STOP        = 0x%08x", sm_sata_read32(sata_csr_base + CFG_DIAG_START_STOP__ADDR));
		lprintf(4, "\n\n CFG_BW_MSTR_STOP_CNT       = 0x%08x", sm_sata_read32(sata_csr_base + CFG_BW_MSTR_STOP_CNT__ADDR));
		lprintf(4, "\n\n CFG_BW_SLV_STOP_CNT        = 0x%08x", sm_sata_read32(sata_csr_base + CFG_BW_SLV_STOP_CNT__ADDR));
		lprintf(4, "\n\n STS_AXI_MRD_BW_CLK_CNT     = 0x%08x", sm_sata_read32(sata_csr_base + STS_AXI_MRD_BW_CLK_CNT__ADDR));
		lprintf(4, "\n\n STS_AXI_MRD_BW_BYTE_CNT    = 0x%08x", sm_sata_read32(sata_csr_base + STS_AXI_MRD_BW_BYTE_CNT__ADDR));
		lprintf(4, "\n\n STS_AXI_MWR_BW_CLK_CNT     = 0x%08x", sm_sata_read32(sata_csr_base + STS_AXI_MWR_BW_CLK_CNT__ADDR));
		lprintf(4, "\n\n STS_AXI_MWR_BW_BYTE_CNT    = 0x%08x", sm_sata_read32(sata_csr_base + STS_AXI_MWR_BW_BYTE_CNT__ADDR));
		data = sm_sata_read32(sata_csr_base + STS_AXI_MRD_BW_CLK_CNT__ADDR);
		wr_time = data * 4;
		printf("\n Write time  (ns)   = %d", wr_time);
		//bw = (sector_count/2)*(1000000000/1024)/wr_time;
		bw = ((1000000000/1024/2)*sector_count)/wr_time;
		printf("\n Write Perf. (MB/s) = %d\n", bw);
	}

#else
	for(i=0; i<2; ++i)
	{
		cmd_slot = sm_sata_get_free_slot(port);
		data = ~(((sector_count*512) - 1) >> 10);
		//printf("\n\n CFG_WRITE_BW_LAT_ADDR_MASK = 0x%08x", data);
		sm_sata_write32(sata_csr_base + CFG_READ_BW_LAT_ADDR_MASK__ADDR, data);
		sm_sata_write32(sata_csr_base + CFG_WRITE_BW_LAT_ADDR_MASK__ADDR, 0);
		data &= (to >> 10);
		//printf("\n CFG_WRITE_BW_LAT_ADDR_PAT  = 0x%08x", data);
		sm_sata_write32(sata_csr_base + CFG_READ_BW_LAT_ADDR_PAT__ADDR, data);
		sm_sata_write32(sata_csr_base + CFG_WRITE_BW_LAT_ADDR_PAT__ADDR, -1);
		//printf("\n CFG_BW_MSTR_STOP_CNT__ADDR  = 0x%08x", stop_count);
		sm_sata_write32(sata_csr_base + CFG_BW_MSTR_STOP_CNT__ADDR, stop_count);
		sm_sata_write32(sata_csr_base + CFG_DIAG_START_STOP__ADDR, 0x1);
		//sm_sata_cmds_init(0, rd_cmd, cmd_slot, 0x40, 0, 0, 3, to, 150, 0, sector_count);
		sm_sata_cmd_setup(cmd_slot, 0, rd_cmd, fr, 1, sector_count, 0, 0, 0);
		if(mode == FPDMA)
			sm_sata_cmds_exe(port, 0, 1 << cmd_slot, 1 << cmd_slot);
		else
			sm_sata_cmds_exe(port, 0, 1 << cmd_slot, 0);
		timeout = 30;
		while((sm_sata_get_busy_slots(port) != 0) && --timeout){
			sm_sata_msdelay(50);
		}
		/*
		timeout = 5;
		while((sm_sata_read32(sata_ahci_port_base + CI0__ADDR) != 0) && --timeout){
			sm_sata_msdelay(1000);
		}
		*/
		data = sm_sata_read32(sata_csr_base + STS_AXI_MWR_BW_CLK_CNT__ADDR);
		rd_time = data * 4;
		sm_sata_msdelay(200);

		cmd_slot = sm_sata_get_free_slot(port);
		data = ~(((sector_count*512) - 1) >> 10);
		//printf("\n\n CFG_WRITE_BW_LAT_ADDR_MASK = 0x%08x", data);
		sm_sata_write32(sata_csr_base + CFG_READ_BW_LAT_ADDR_MASK__ADDR, 0);
		sm_sata_write32(sata_csr_base + CFG_WRITE_BW_LAT_ADDR_MASK__ADDR, data);
		data &= (fr >> 10);
		//printf("\n CFG_WRITE_BW_LAT_ADDR_PAT  = 0x%08x", data);
		sm_sata_write32(sata_csr_base + CFG_READ_BW_LAT_ADDR_PAT__ADDR, -1);
		sm_sata_write32(sata_csr_base + CFG_WRITE_BW_LAT_ADDR_PAT__ADDR, data);
		//printf("\n CFG_BW_MSTR_STOP_CNT__ADDR  = 0x%08x", stop_count);
		sm_sata_write32(sata_csr_base + CFG_BW_MSTR_STOP_CNT__ADDR, stop_count);
		sm_sata_write32(sata_csr_base + CFG_DIAG_START_STOP__ADDR, 0x4);
		//sm_sata_cmds_init(0, wr_cmd, cmd_slot, 0x40, 0, 1, 3, fr, 150, 0, sector_count);
		sm_sata_cmd_setup(cmd_slot, 0, wr_cmd, fr, 1, sector_count, 0, 0, 0);
		if(mode == FPDMA)
			sm_sata_cmds_exe(port, 0, 1 << cmd_slot, 1 << cmd_slot);
		else
			sm_sata_cmds_exe(port, 0, 1 << cmd_slot, 0);
		timeout = 30;
		while((sm_sata_get_busy_slots(port) != 0) && --timeout){
			sm_sata_msdelay(50);
		}
		data = sm_sata_read32(sata_csr_base + STS_AXI_MRD_BW_CLK_CNT__ADDR);
		wr_time = data * 4;
		sm_sata_msdelay(200);
	}
	//printf("\nResuts for Port%d Sectors:%d, Mode:%d \n", port, sector_count, mode);

	//printf("\n Write time  (ns)   = %d", wr_time);
	bw = ((sector_count/2)*(1000000000/wr_time))/1024;
	//bw = ((1000000000/1024/2)*sector_count)/wr_time;
	printf("\n Write Perf. (MB/s) = %d", bw);

	//printf("\n Read time   (ns)   = %d", rd_time);
	bw = ((sector_count/2)*(1000000000/rd_time))/1024;
	//bw = ((1000000000/1024/2)*sector_count)/rd_time;
	printf("\n Read Perf.  (MB/s) = %d\n", bw);
#endif
}

void sm_sata_asyn_note(int port){
	int an_en = 0;	// 1: Controller supports AsynNote
					// 2: AsynNote enabled on Device
	int test_id = 12;
	u32 sata_ahci_base = sm_sata_get_ahci_base(port);
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);
	u32 i, addr, data, timeout;
	u64 location = SATA_DATA_READ_BASE;

	// check to see if the SATA Controller supports SNotification Register (SSNTF)
	sm_host_read32(sata_ahci_base + CAP__ADDR, &data);
	if(data & (1 << 29)){	// Supports SNotification Register (SSNTF)
		/* Enable Asynchronous Notification on PM */
		if(PM_discovery(port)){		// check to see if device is a PM card
			lprintf(3, "\n Asynchronous Notification: ");
			data = sm_sata_pmp_read32(port, 0xF, PMP_GSCR64);
			if(data & (1 << 3)){
				lprintf(3, "Supported");
				data = sm_sata_pmp_read32(port, 0xF, PMP_GSCR96);
				if(data & (1 << 3)){
					lprintf(3, " - Enabled");
					an_en = 1;
				}
				else{
					lprintf(3, " - Enabling ... ");
					sm_sata_pmp_write32(port, 0xF, PMP_GSCR96, data | (1 << 3));
					sm_sata_msdelay(10);
					data = sm_sata_pmp_read32(port, 0xF, PMP_GSCR96);
					if(data & (1 << 3)){
						lprintf(3, "ENABLED \n");
						an_en = 1;
					}
					else
						lprintf(3, "FAILED \n");
				}
			}
			else
				lprintf(5, "NOT Supported on this device \n");
		}
		else{
			sm_sata_cmd_setup(0, 0, ATA_CMD_IDENT, location, 0, 1, 0, 0, 0);
			sm_sata_cmds_exe(port, 0, 1, 0);
			timeout = 10;
			while((sm_sata_get_busy_slots(port) != 0) && --timeout){
				sm_sata_msdelay(100);
			}
			if((sm_sata_read64(location) >> 16) == 0x3FFF){
				lprintf(3, "\n Asynchronous Notification: ");
				data = sm_sata_read64(location + 156);
				if(data & (1 << 5)){
					lprintf(3, "Supported");
					if(data & (1 << (5+16))){
						lprintf(3, " - Enabled");
						an_en = 1;
					}
					else{
						lprintf(3, " - Enabling ... ");
						// Enable AN on Device
						sm_sata_cmds_init(0, ATA_CMD_SETF, 0, 0x40, 0, 0, 3, 0, 0, 0, 5);
						sm_sata_cmds_init(0, ATA_CMD_IDENT, 1, 0x40, 0, 0, 3, location, 1, 0, 1);
						sm_sata_cmds_exe(port, 0, 3, 0);
						timeout = 10;
						while((sm_sata_get_busy_slots(port) != 0) && --timeout){
							sm_sata_msdelay(100);
						}
						data = sm_sata_read64(location + 156);
						if(data & (1 << (5+16))){
							lprintf(3, "PASSED");
							an_en = 1;
						}
						else
							lprintf(3, "FAILED \n");
					}
				}
				else
					lprintf(3, "NOT Supported on this device \n");
			}
			else
				lprintf(3, "[ERROR]: Command ReadID FAILED \n");
		}
	}
	else
		printf("\n [ERROR]: SATA Controller does not support Asynchronous Notification feature \n");
	if(an_en){
		// Disable all port irq
		sm_sata_write32(sata_ahci_port_base + IE0__ADDR, 0);
		// Enable Set  Device  Bits  FIS  Interrupt  Enable  (SDBE)
		sm_sata_write32(sata_ahci_port_base + IE0__ADDR, 1 << 3);
		printf("\n Enabling Set Device Bits FIS Interrupt ... ENABLED \n");
		data = sm_sata_read32(sata_ahci_base + CAP__ADDR);

		// Check PxSNTF Reg
		printf("\n P%dSNTF = 0x%08x \n", port, sm_sata_read32(sata_ahci_port_base + SNTF0__ADDR));
		printf("\n Unplug the HDD and plug it back in");
	}
}

int sm_sata_ata_feature_en(int port, int f_val){
	/*
	 * f_val: Feature Value
	 * 01h  Non-zero buffer offset in DMA Setup FIS
	 * 02h  DMA Setup FIS Auto-Activate optimization
	 * 03h  Device-initiated interface power state transitions
	 * 04h  Guaranteed In-Order Data Delivery
	 * 05h  Asynchronous Notification
	 * 06h  Software Settings Preservation
	 * 07h  Device Automatic Partial to Slumber transitions
	 */
	int rc = 0;
	u32 i, addr, data, timeout;
	u64 location = SATA_DATA_READ_BASE;

	switch(f_val){
	case 1:
		lprintf(3, "\n Non-zero buffer offset in DMA Setup FIS: ");
		break;
	case 2:
		lprintf(3, "\n DMA Setup FIS Auto-Activate optimization: ");
		break;
	case 3:
		lprintf(3, "\n Device-initiated interface power state transitions: ");
		break;
	case 4:
		lprintf(3, "\n Guaranteed In-Order Data Delivery: ");
		break;
	case 5:
		lprintf(3, "\n Asynchronous Notification: ");
		break;
	case 6:
		lprintf(3, "\n Software Settings Preservation: ");
		break;
	case 7:
		lprintf(3, "\n Device Automatic Partial to Slumber transitions: ");
		break;
	default:
		lprintf(3, "\n Software Settings Preservation: ");
		break;
	}

	sm_sata_cmds_init(0, ATA_CMD_IDENT, 0, 0x40, 0, 0, 3, location, 1, 0, 1);
	sm_sata_cmds_exe(port, 0, 1, 0);
	timeout = 10;
	while((sm_sata_get_busy_slots(port) != 0) && --timeout){
		sm_sata_msdelay(100);
	}
	if((sm_sata_read64(location) >> 16) == 0x3FFF){
		data = sm_sata_read64(location + 156);
		if(data & (1 << f_val)){
			lprintf(3, "Supported");
			if(data & (1 << (f_val+16)))
				lprintf(3, " - Enabled");
			else{
				lprintf(3, " - Enabling ... ");
				sm_sata_cmds_init(0, ATA_CMD_SETF, 0, 0x40, 0, 0, 3, 0, 0, 0, f_val);
				sm_sata_cmds_init(0, ATA_CMD_IDENT, 1, 0x40, 0, 0, 3, location, 1, 0, 1);
				sm_sata_cmds_exe(port, 0, 3, 0);
				timeout = 10;
				while((sm_sata_get_busy_slots(port) != 0) && --timeout){
					sm_sata_msdelay(100);
				}
				data = sm_sata_read64(location + 156);
				if(data & (1 << (f_val+16)))
					lprintf(3, "PASSED\n");
				else{
					lprintf(3, "FAILED\n");
					rc = -1;
				}
			}
		}
		else{
			lprintf(3, "NOT Supported on this HDD\n");
			rc = -1;
		}
	}
	return rc;
}

int sm_sata_bist_test1(int port, pattern_mode patt_mode, prbs_mode prbs){
	u32 sata_ahci_base = sm_sata_get_ahci_base(port);
	u32 addr32, data32;

	sm_sata_portcfg_sel(port);

	addr32 = sata_ahci_base + PORTPHY1CFG__ADDR;
	sm_host_read32(addr32, &data32);
    lprintf(7, "\n SATA Port%d - PORTPHY1CFG = 0x%08X", port, data32);
    data32 |= 1 << 26;			// BISTPATTNA: PhyControl BIST Pattern no Aligns
    data32 |= 1 << 25;			// BISTCLRERR: PhyControl BIST Clear Error
    data32 |= 1 << 24;			// BISTPATTEN: PhyControl BIST Pattern Enable
    data32 &= ~(0x7 << 21);		// Mask BISTPATTSEL [23:21]
    data32 |= patt_mode << 21;
    data32 |= 1 << 20;			// FRCPHYRDY
    sm_sata_write32(addr32, data32);
    lprintf(5, "\n Delaying 10 seconds ... ");
    sm_sata_delay(10);		// delay 10 seconds

    sm_host_read32(addr32, &data32);
    lprintf(7, "\n SATA Port%d - PORTPHY1CFG = 0x%08X", port, data32);
    data32 &= ~(1 << 25);		// Complete BIST Clear Error
    sm_sata_write32(addr32, data32);
    lprintf(5, "\n Delaying 1 ms ... ");
    sm_sata_msdelay(1);

    switch(patt_mode){
	case BIST:	// 5 -> 7
		return sm_sata_bist_L_test(port);
		break;
    case PRBS:
    	return sm_sata_bist_PRBS_test(port, prbs);
        break;
    case HFTP:
    	return sm_sata_bist_T_HFTP_test(port);
		break;
    case MFTP:
    	return sm_sata_bist_T_MFTP_test(port);
    	break;
    case LFTP:
    	return sm_sata_bist_T_LFTP_test(port);
    	break;
    default:	// LBP
    	return sm_sata_bist_T_LBP_test(port);
    	break;
    }
}

int sm_sata_bist_L_test(int port){
	int patt_mode = 1 << 4;
	if(sm_sata_bist_init(port, patt_mode, 0, 0) == 0){
		if(sm_sata_bist_chk(port)){
			printf("\n SATA Port%d BIST Test FAILED \n", port);
			return -1;
		}
		else
			printf("\n SATA Port%d BIST Test PASSED \n", port);
	}
	else
		return -1;
	return 0;
}

int sm_sata_bist_T_HFTP_test(int port){
	int patt_mode = 1 << 7;
	u32 patt1 = 0x4a4a4a4a;
	u32 patt2 = 0x4a4a4a4a;
	if(sm_sata_bist_init(port, patt_mode, patt1, patt2) == 0){
		if(sm_sata_bist_chk(port)){
			printf("\n SATA Port%d BIST T HFPT Test FAILED \n", port);
			return -1;
		}
		else
			printf("\n SATA Port%d BIST T HFPT Test PASSED \n", port);
	}
	else
		return -1;
	return 0;
}

int sm_sata_bist_T_MFTP_test(int port){
	int patt_mode = 1 << 7;
	u32 patt1 = 0x78787878;
	u32 patt2 = 0x78787878;
	if(sm_sata_bist_init(port, patt_mode, patt1, patt2) == 0){
		if(sm_sata_bist_chk(port)){
			printf("\n SATA Port%d BIST T HFPT Test FAILED \n", port);
			return -1;
		}
		else
			printf("\n SATA Port%d BIST T HFPT Test PASSED \n", port);
	}
	else
		return -1;
	return 0;
}

int sm_sata_bist_T_LFTP_test(int port){
	int patt_mode = 1 << 7;
	u32 patt1 = 0x7E7E7E7E;
	u32 patt2 = 0x7E7E7E7E;
	if(sm_sata_bist_init(port, patt_mode, patt1, patt2) == 0){
		if(sm_sata_bist_chk(port)){
			printf("\n SATA Port%d BIST T HFPT Test FAILED \n", port);
			return -1;
		}
		else
			printf("\n SATA Port%d BIST T HFPT Test PASSED \n", port);
	}
	else
		return -1;
	return 0;
}

int sm_sata_bist_T_LBP_test(int port){
	int patt_mode = 1 << 7;
	u32 patt1 = 0x4a4a4a4a;
	u32 patt2 = 0x4a4a4a4a;
	if(sm_sata_bist_init(port, patt_mode, patt1, patt2) == 0){
		if(sm_sata_bist_chk(port)){
			printf("\n SATA Port%d BIST T HFPT Test FAILED \n", port);
			return -1;
		}
		else
			printf("\n SATA Port%d BIST T HFPT Test PASSED \n", port);
	}
	else
		return -1;
	return 0;
}

int sm_sata_bist_PRBS_test(int port, prbs_mode prbs){
	u32 sata_csr_base = sm_sata_get_csr_base(port);
	u32 reg_base, reg_offset;
	u32 addr32, data32;

	reg_base = ((port % 2) == 0) ? CH0_RXTX_REG_OFFSET : CH1_RXTX_REG_OFFSET;

	lprintf(4, "\n BIST PRBS Test");
	lprintf(4, "\n Set Customer Pin Mode [5] = 0");
	addr32 = sata_csr_base + SATA_ENET_SDS_CTL0__ADDR;
	sm_host_read32(addr32, &data32);
	data32 &= ~(1 << 5);
	//data32 = data32 & 0xffffffdf;	//0x0;
	sm_host_write32(addr32, data32);

	reg_offset = reg_base + RXTX_REG2*2;
	data32 = 0xF << 12;		// Pull TX out of reset
	data32 |= 1 << 11;		// Bist_en_tx
	data32 |= 1 << 5;		// tx_fifo_ena
	data32 |= 1 << 1;		// iddtn: active low
	kc_sds_wr(sata_csr_base, reg_offset, data32);

	reg_offset = reg_base + RXTX_REG11*2;
	data32 = 0x0000C800;	// phase_adjust_limit [15:11]
	kc_sds_wr(sata_csr_base, reg_offset, data32);

	reg_offset = reg_base + RXTX_REG4*2;
	data32 = 0x00001840;	// TX_PRBS_sel [10:8] = 0
	data32 |= prbs << 8;
	kc_sds_wr(sata_csr_base, reg_offset, data32);

	reg_offset = reg_base + RXTX_REG7*2;
	data32 = 0x000059C7;	// RX_PRBS_sel [5:3] = 0
	data32 |= prbs << 3;
	kc_sds_wr(sata_csr_base, reg_offset, data32);

	reg_offset = reg_base + RXTX_REG6*2;
	data32 = 1 << 2;		// txsync_resetb
	data32 |= 1 << 1;		// rx_bist_resync: re-sync the RX bert logic, without reset
	kc_sds_wr(sata_csr_base, reg_offset, data32);
	data32 &= ~(1 << 1);
	kc_sds_wr(sata_csr_base, reg_offset, data32);

	reg_offset = reg_base + RXTX_REG61*2;
	data32 = 1 << 8;		// eye_acc_resetb
	kc_sds_wr(sata_csr_base, reg_offset, data32);
	data32 |= 1 << 5;		// bert_resetb: reset bert logic
	kc_sds_wr(sata_csr_base, reg_offset, data32);

	printf("\n Delaying 9 seconds ...");
	sm_sata_delay(9);

	reg_offset = reg_base + RXTX_REG118*2;
	data32 = kc_sds_rd(sata_csr_base, reg_offset);
	if(data32 & 0x18) lprintf(4, "\n RX Bist sample count is Done");

	reg_offset = reg_base + RXTX_REG158*2;
	data32 = kc_sds_rd(sata_csr_base, reg_offset);
	if(data32 & 0x8000)
		lprintf(4, "\n Summer Calib is Completed");
	else
		lprintf(4, "\n [ERROR]: Summer Calib is NOT Completed");
	if(data32 & 0x2000)
		lprintf(4, "\n CTLE Calib is Completed");
	else
		lprintf(4, "\n [ERROR]: CTLE Calib is NOT Completed");
	if(data32 & 0x0800)
		lprintf(4, "\n LAT Calib is Completed");
	else
		lprintf(4, "\n [ERROR]: LAT Calib is NOT Completed");
	if(data32 & 0x0080){
		lprintf(4, "\n BIST PRBS Test is PASSED");
		return 0;
	}
	if(data32 & 0x0040){
		lprintf(4, "\n [ERROR]: BIST PRBS Test is FAILED");
		return -1;
	}
}

void sm_sata_fix_clr(int port){
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);
	u32 addr, data;

	addr = sata_ahci_port_base + CI0__ADDR;
	data = sm_sata_read32(addr);
	lprintf(3, "\n P%dCI = 0x%08x", port, data);
	if(data > 0){
		lprintf(3, "\n Clearing Command List Running Issue ... ");
		addr = sata_ahci_port_base + CMD0__ADDR;
		data = sm_sata_read32(addr);
		data &= ~1;
		sm_sata_write32(addr, data);
		data = sm_sata_read32(addr);
		data |= 1;
		sm_sata_write32(addr, data);
		lprintf(3, "\n P%dCMD = 0x%08x", port, sm_sata_read32(addr));
		lprintf(3, "\n P%dCI  = 0x%08x", port, sm_sata_read32(sata_ahci_port_base + CI0__ADDR));
	}
	else printf("\n NOTE: No commands in queue to clear");
}

void sm_sata_ssc_measure(int port){
	int i, rc = 0;
	char outstr [256];
	u32 addr32, data32, wdata32;
	u32 sata_ahci_base = sm_sata_get_ahci_base(port);

	rc = sm_sata_init(port);
	sm_sata_ceva_cfg(port);
	sm_sata_spd_cfg(port);
	sm_sata_portcfg_sel(port);

	addr32 = sata_ahci_base + PORTPHY1CFG__ADDR;
	data32 = sm_sata_read32(addr32);
	lprintf(5, "\n\n Setting up BIST");
	lprintf(5, "\n\t PORTPHY1CFG__ADDR[0x%08X] = 0x%08X", addr32, data32);
	data32 |= 1 << 20;		// FRCPHYRDY
	data32 &= ~(7 << 21);
	data32 |= 3 << 21;		// BISTPATTSEL = HFTP Pattern
	data32 |= 1 << 24;		// BISTPATTEN
	data32 |= 1 << 25;		// BISTCLRERR
	data32 |= 1 << 26;		// BISTPATTNA
	sm_sata_write32(addr32, data32);

	// 10 seconds delay
	lprintf(5, "\n ... 10 seconds delay");
	sm_sata_delay(10);

	sm_host_read32(addr32, &data32);
	lprintf(5, "\n\t PORTPHY1CFG__ADDR[0x%08X] = 0x%08X", addr32, data32);
	lprintf(5, "\n Clearing BIST Error [25]");
	data32 &= ~(1 << 25);	// Clear BIST Error
	sm_sata_write32(addr32, data32);

	// 1 milisecond delay
	lprintf(5, "\n ... 1 seconds delay");
	sm_sata_msdelay(1);

	data32 = sm_sata_read32(addr32);
	lprintf(5, "\n\t PORTPHY1CFG__ADDR[0x%08X] = 0x%08X", addr32, data32);

	sm_host_read32(sata_ahci_base + 0x170, &data32);
	lprintf(5, "\n PortVS0ADDR_Register = 0x%08x\n", data32);
	if(data32 & 0x1){
		lprintf(5, "\n AHSATA Port Init After BIST ....\n");
	}

	// 1 milisecond delay
	lprintf(5, "\n ... 1 miliseconds delay");
	sm_sata_msdelay(1);

	data32 = sm_sata_read32(addr32);
	lprintf(5, "\n\t PORTPHY1CFG__ADDR[0x%08X] = 0x%08X", addr32, data32);
	// 1 milisecond delay
	lprintf(5, "\n ... 1 miliseconds delay");
	sm_sata_msdelay(1);
	data32 = sm_sata_read32(addr32);
	lprintf(5, "\n\t PORTPHY1CFG__ADDR[0x%08X] = 0x%08X", addr32, data32);

	sm_host_read32(sata_ahci_base + TFD0__ADDR, &data32);
	sm_sata_msdelay(10);
	sm_host_read32(sata_ahci_base + TFD0__ADDR, &data32);
	sm_sata_msdelay(1);
}

void sm_sata_linkup_reset(int loop, int fail_stop){
	int rc = 0;
	int i = 0;
	int pll_error_count = 0;
	int linkup_error_count = 0;
	int verbose = g_verbose_level;
	int port, num_try, infinite;
	int linkup01, linkup23, linkup45;

	infinite = (loop == 0) ? 1 : 0;
#if 0
	while((++i <= loop) || infinite){
		sm_sata_delay(2);
		/* PLL locking */
		printf("\n PLL locking ...");
		g_verbose_level = 2;
		num_try = 5;
		do{
			linkup01 = (sm_sata_init(0) == 0) ? 1 : 0;
		}while((linkup01 == 0) && --num_try);
		if(linkup01)
			printf("\n\tSATA Controller 0 - PLL Initiation PASSED after %d try\n", 6 - num_try);
		else
			printf("\n\tSATA Controller 0 - PLL Initiation FAILED\n");
		num_try = 5;
		do{
			linkup23 = (sm_sata_init(2) == 0) ? 1 : 0;
		}while((linkup23 == 0) && --num_try);
		if(linkup23)
			printf("\n\tSATA Controller 0 - PLL Initiation PASSED after %d try\n", 6 - num_try);
		else
			printf("\n\tSATA Controller 1 - PLL Initiation FAILED\n");
		num_try = 5;
		do{
			linkup45 = (sm_sata_init(4) == 0) ? 1 : 0;
		}while((linkup45 == 0) && --num_try);
		if(linkup45)
			printf("\n\tSATA Controller 0 - PLL Initiation PASSED after %d try\n", 6 - num_try);
		else
			printf("\n\tSATA Controller 2 - PLL Initiation FAILED\n");
		g_verbose_level = verbose;
		/* Link up */
		printf("\n Linking up ...");
		if(linkup01){
			linkup_error_count += (sm_sata_linkup(0) == 0) ? 0 : 1;
			printf("\n");
			linkup_error_count += (sm_sata_linkup(1) == 0) ? 0 : 1;
			printf("\n");
		}else
			++pll_error_count;
		if(linkup23){
			linkup_error_count += (sm_sata_linkup(2) == 0) ? 0 : 1;
			printf("\n");
			linkup_error_count += (sm_sata_linkup(3) == 0) ? 0 : 1;
			printf("\n");
		}else
			++pll_error_count;
		if(linkup45){
			linkup_error_count += (sm_sata_linkup(4) == 0) ? 0 : 1;
			printf("\n");
			linkup_error_count += (sm_sata_linkup(5) == 0) ? 0 : 1;
		}else
			++pll_error_count;
		printf("\n########## COMPLETED RUN #%d: PLL locking failed = %d - Linking up failed = %d\n", i, pll_error_count, linkup_error_count);
		if(fail_stop & (linkup_error_count > 0)) break;
	}
#else
	/* PLL locking */
	sm_sata_delay(1);
	printf("\n PLL locking ...");
	g_verbose_level = 2;
	num_try = 5;
	do{
		linkup01 = (sm_sata_init(0) == 0) ? 1 : 0;
	}while((linkup01 == 0) && --num_try);
	if(linkup01)
		printf("\n\tSATA Controller 0 - PLL Initiation PASSED after %d try\n", 6 - num_try);
	else
		printf("\n\tSATA Controller 0 - PLL Initiation FAILED\n");
	num_try = 5;
	do{
		linkup23 = (sm_sata_init(2) == 0) ? 1 : 0;
	}while((linkup23 == 0) && --num_try);
	if(linkup23)
		printf("\n\tSATA Controller 0 - PLL Initiation PASSED after %d try\n", 6 - num_try);
	else
		printf("\n\tSATA Controller 1 - PLL Initiation FAILED\n");
	num_try = 5;
	do{
		linkup45 = (sm_sata_init(4) == 0) ? 1 : 0;
	}while((linkup45 == 0) && --num_try);
	if(linkup45)
		printf("\n\tSATA Controller 0 - PLL Initiation PASSED after %d try\n", 6 - num_try);
	else
		printf("\n\tSATA Controller 2 - PLL Initiation FAILED\n");
	g_verbose_level = verbose;

	while((++i <= loop) || infinite){
		/* Link up */
		sm_sata_delay(1);
		printf("\n\n Linking up ...");
		if(i == 1){
			if(linkup01){
				linkup_error_count += (sm_sata_linkup(0) == 0) ? 0 : 1;
				printf("\n");
				linkup_error_count += (sm_sata_linkup(1) == 0) ? 0 : 1;
				printf("\n");
			}else
				++pll_error_count;
			if(linkup23){
				linkup_error_count += (sm_sata_linkup(2) == 0) ? 0 : 1;
				printf("\n");
				linkup_error_count += (sm_sata_linkup(3) == 0) ? 0 : 1;
				printf("\n");
			}else
				++pll_error_count;
			if(linkup45){
				linkup_error_count += (sm_sata_linkup(4) == 0) ? 0 : 1;
				printf("\n");
				linkup_error_count += (sm_sata_linkup(5) == 0) ? 0 : 1;
			}else
				++pll_error_count;
		}else{
			if(linkup01){
				for(port=0; port<2; ++port){
					if(sm_sata_ahci_device_init(port) == 0){
						lprintf(3, "\n\t SATA Port%d - OOB Signal is GOOD", port);
						if(sm_sata_ahci_port_init(port) == 0)
							lprintf(3, "\n\t SATA Port%d - Link up is GOOD\n", port);
						else{
							lprintf(3, "\n\t [ERROR]: SATA Port%d - Link up is FAILED\n", port);
							++linkup_error_count;
						}
					}else{
						lprintf(3, "\n\t [ERROR]: SATA Port%d - OOB Signal is FAILED\n", port);
						++linkup_error_count;
					}
				}
			}
			if(linkup23){
				for(port=2; port<4; ++port){
					if(sm_sata_ahci_device_init(port) == 0){
						lprintf(3, "\n\t SATA Port%d - OOB Signal was GOOD", port);
						if(sm_sata_ahci_port_init(port) == 0)
							lprintf(3, "\n\t SATA Port%d - Link up was GOOD\n", port);
						else{
							lprintf(3, "\n\t [ERROR]: SATA Port%d - Link up was FAILED\n", port);
							++linkup_error_count;
						}
					}else{
						lprintf(3, "\n\t [ERROR]: SATA Port%d - OOB Signal was FAILED\n", port);
						++linkup_error_count;
					}
				}
			}
			if(linkup45){
				for(port=4; port<6; ++port){
					if(sm_sata_ahci_device_init(port) == 0){
						lprintf(3, "\n\t SATA Port%d - OOB Signal was GOOD", port);
						if(sm_sata_ahci_port_init(port) == 0)
							lprintf(3, "\n\t SATA Port%d - Link up was GOOD\n", port);
						else{
							lprintf(3, "\n\t [ERROR]: SATA Port%d - Link up was FAILED\n", port);
							++linkup_error_count;
						}
					}else{
						lprintf(3, "\n\t [ERROR]: SATA Port%d - OOB Signal was FAILED\n", port);
						++linkup_error_count;
					}
				}
			}
		}
		printf("\n########## COMPLETED RUN #%d: Linking up failed = %d\n", i, linkup_error_count);
		if(fail_stop & (linkup_error_count > 0)) break;
	}
#endif
}


/************************* For Automation ************************/
#if 1	// for Automation
int sm_sata_enet_muxing_test(int ctrl){
/*
 * This test will test the functional of the SATA/ENET mux
 * When ENET is selected: not sure what are the post requirements
 * When SATA is selected:
 * 		Memory, Power Clock, Power Management Clock, and AHB are all in reset mode
 */
	int rc = 0;
	int data32;
	int sata_csr_base = sm_sata_get_csr_base(ctrl*2);
	int addr = sata_csr_base + SATA_ENET_CONFIG_REG__ADDR;

	printf("\n\n SATA Controller %d - SATA/SGMII Muxing", ctrl);
	if(ctrl < 2){ // not controller 2 (port 4 - 5)
		printf("\n Selecting SGMII over SATA ... ");
		sm_host_write32(addr, 0x1);
		sm_host_read32(addr, &data32);
		if(data32 & 0x1)
			printf("PASSED: SGMII is muxed");
		else{
			printf("FAILED: SGMII can't be muxed");
			++rc;
		}
		printf("\n\t SATA_ENET_CONFIG_REG [0x%08X] bit [0] = [0x%08X]", addr, data32);
		printf("\n\t SATACLKENREG         [0x%08X]         = [0x%08X]", addr, sm_sata_read32(sata_csr_base + SATACLKENREG__ADDR));
		printf("\n\t SATASRESETREG        [0x%08X]         = [0x%08X]", addr, sm_sata_read32(sata_csr_base + SATASRESETREG__ADDR));

		printf("\n Selecting SATA over SGMII ... ");
		sm_host_write32(addr, 0x0);
		sm_host_read32(addr, &data32);
		if((data32 & 0x1) == 0){
			printf("PASSED: SATA is muxed");
			printf("\n\t SATA_ENET_CONFIG_REG [0x%08X] bit [0] = [0x%08X]", addr, data32);
			printf("\n\t SATACLKENREG         [0x%08X]         = [0x%08X]", addr, sm_sata_read32(sata_csr_base + SATACLKENREG__ADDR));
			sm_host_read32(sata_csr_base + SATASRESETREG__ADDR, &data32);
			printf("\n\t SATASRESETREG        [0x%08X]         = [0x%08X]", addr, data32);
			if((data32 & 0x20) == 0){
				printf("\n\t [FAILED]: Memory is not reseted when the mux has selected SATA");
				++rc;
			}
			if((data32 & 0x10) == 0){
				printf("\n\t [FAILED]: Power Management Clock is not reseted when the mux has selected SATA");
				++rc;
			}
			if((data32 & 0x08) == 0){
				printf("\n\t [FAILED]: Power Clock is not reseted when the mux has selected SATA");
				++rc;
			}
			if((data32 & 0x04) == 0){
				printf("\n\t [FAILED]: AHB is not reseted when the mux has selected SATA");
				++rc;
			}
		}
		else{
			printf("FAILED: SATA can't be muxed");
			++rc;
		}
	}else
		printf(" Not available\n");
	return rc;
}
int sm_sata_bit_test(int addr32, int bit){
	int rc = 0;
	u32 data32;
	sm_host_read32(addr32, &data32);
	data32 &= ~bit;
	sm_host_write32(addr32, data32);
	if(sm_sata_read32(addr32) & bit) ++rc;
	data32 |= bit;
	sm_host_write32(addr32, data32);
	if((sm_sata_read32(addr32) & bit) == 0) ++rc;
	data32 &= ~bit;
	sm_host_write32(addr32, data32);
	if(sm_sata_read32(addr32) & bit) ++rc;
	return rc;
}
int sm_sata_satasresetreg_bit_test(int ctrl, int testing_bits){
	int rc = 0;
	int i;
	u32 sata_csr_base = sm_sata_get_csr_base(ctrl*2);
	u32 addr32 = sata_csr_base + SATASRESETREG__ADDR;
	u32 data32;

	printf("\n\n SATA Controller %d - Bits Testing of SATASRESETREG [0x%08X] ...", ctrl, addr32);
	if(sm_sata_enet_muxing(ctrl*2) == 0){
		for(i=0; i<32; i++){
			if(testing_bits & (1 << i)){
				switch(i){
				case 5:
					printf("\n\t Memory Reset bit ................... ");
					break;
				case 4:
					printf("\n\t Power Management Clock Reset bit ... ");
					break;
				case 3:
					printf("\n\t Power Clock Reset bit .............. ");
					break;
				case 2:
					printf("\n\t AHB (SDS_CSR) Reset bit ............ ");
					break;
				case 1:
					printf("\n\t SATA Core Reset bit ................ ");
					break;
				case 0:
					printf("\n\t CSR Reset bit ...................... ");
					break;
				}
				if(sm_sata_bit_test(addr32, 1 << i)){
					printf("FAILED");
					++rc;
				}
				else
					printf("PASSED");
			}
		}
	}
	return rc;
}
void satasresetreg(int argc, char *argv[]){
	int i, ctrl;
	if(argc != 1){
		printf("\n Syntax: satasresetreg [CONTROLLER]");
		printf("\n\t where [CONTROLLER] = 0, 1, 2, or 3 for all SATA controllers.\n");
	}else{
		if(atoi(argv[0]) == 3){
			for(i=0; i<atoi(argv[0]); ++i) sm_sata_satasresetreg_bit_test(i, 0x3F);
		}else{
			ctrl = atoi(argv[0]);
			sm_sata_satasresetreg_bit_test(ctrl, 0x3F);
		}
	}
}

int sm_sata_sataclkenreg_bit_test(int ctrl, int testing_bits){
	int rc = 0;
	int i;
	u32 sata_csr_base = sm_sata_get_csr_base(ctrl*2);
	u32 addr32 = sata_csr_base + SATACLKENREG__ADDR;

	printf("\n\n SATA Controller %d - Bits Testing of SATACLKENREG [0x%08X] ...", ctrl, addr32);
	if(sm_sata_enet_muxing(ctrl*2) == 0){
		for(i=0; i<32; i++){
			if(testing_bits & (1 << i)){
				switch(i){
				case 5:
					printf("\n\t SATA AHB (SDS_CSR) Clock Enable bit ... ");
					break;
				case 4:
					printf("\n\t SATA CORE AXI Clock Enable bit ........ ");
					break;
				case 3:
					printf("\n\t Power Management Clock Enable bit ..... ");
					break;
				case 2:
					printf("\n\t SATA1 CORE Clock Enable bit ........... ");
					break;
				case 1:
					printf("\n\t SATA0 CORE Clock Enable bit ........... ");
					break;
				case 0:
					printf("\n\t SATA CSR Clock Enable bit ............. ");
					break;
				}
				if(sm_sata_bit_test(addr32, 1 << i)){
					printf("FAILED");
					++rc;
				}
				else
					printf("PASSED");
			}
		}
	}
	return rc;
}
void sataclkenreg(int argc, char *argv[]){
	int i, ctrl;
	if(argc != 1){
		printf("\n Syntax: sataclkenreg [CONTROLLER]");
		printf("\n\t where [CONTROLLER] = 0, 1, 2, or 3 for all SATA controllers.\n");
	}else{
		if(atoi(argv[0]) == 3){
			for(i=0; i<atoi(argv[0]); ++i) sm_sata_sataclkenreg_bit_test(i, 0x3F);
		}else{
			ctrl = atoi(argv[0]);
			sm_sata_sataclkenreg_bit_test(ctrl, 0x3F);
		}
	}
}

int sm_sata_kc_sds_rst(int ctrl){
	int rc = 0;
	int verbose = g_verbose_level;
	int sata_csr_base = sm_sata_get_csr_base(ctrl*2);
	int addr = sata_csr_base + SATASRESETREG__ADDR;

	printf("\n\n SATA Controller %d - KOOLCHIP SERDES Reset testing ...", ctrl);
	g_verbose_level = 4;
	if(sm_sata_enet_muxing(ctrl*2) == 0){
		g_verbose_level = 3;
		if(sm_sata_clk_rst(ctrl*2) == 0){
			printf("\n\t Pulling CSR and AHB (SDS_CSR) out of reset ... DONE");
			g_verbose_level = 5;
			rc = sm_sata_sds_rst(ctrl*2);
			g_verbose_level = verbose;
		}
		else
			printf("\n\t Pulling CSR and AHB (SDS_CSR) out of reset ... FAILED\n");
	}
	else
		printf("\n\t Selecting SATA over SGMII ... FAILED\n");
	return rc;
}
int sm_sata_kc_sds_ena(int ctrl){
	int rc = 0;
	int verbose = g_verbose_level;
	int sata_csr_base = sm_sata_get_csr_base(ctrl*2);
	int addr = sata_csr_base + SATASRESETREG__ADDR;

	printf("\n\n SATA Controller %d - KOOLCHIP SERDES Enable testing ...", ctrl);
	g_verbose_level = 4;
	if(sm_sata_enet_muxing(ctrl*2) == 0){
		g_verbose_level = 3;
		if(sm_sata_clk_rst(ctrl*2) == 0){
			printf("\n\t Pulling CSR and AHB (SDS_CSR) out of reset ... DONE");
			g_verbose_level = 5;
			rc = sm_sata_sds_ena(ctrl*2);
			g_verbose_level = verbose;
		}
		else
			printf("\n\t Pulling CSR and AHB (SDS_CSR) out of reset ... FAILED");
	}
	else
		printf("\n\t Selecting SATA over SGMII ... FAILED");
	return rc;
}

int sm_sata_pll_lock(ctrl){
	int rc = 0;
	int verbose = g_verbose_level;

	printf("\n\n SATA Controller %d - PLL locking ...", ctrl);
	g_verbose_level = 5;
	rc = sm_sata_init(ctrl*2);
	g_verbose_level = verbose;
	return rc;
}

int sm_sata_link_up(port){
	int rc = 0;
	int verbose = g_verbose_level;

	printf("\n\n SATA Controller %d - Linking up ...", port);
	rc = sm_sata_init(port);
	g_verbose_level = 5;
	rc = sm_sata_linkup(port);
	g_verbose_level = verbose;
	return rc;
}

int sm_sata_read_id(port){
	int rc = 0;
    rc = sm_sata_init(port);
    if(rc == 0)
    	rc = sm_sata_linkup(port);
    printf("\n");
    if(rc == 0)
    	rc = sm_sata_readid(port, 0);
	return rc;
}

int sm_sata_pio(port){
	int rc = 0;
	int verbose = g_verbose_level;
    rc = sm_sata_init(port);
    if(rc == 0)
    	rc = sm_sata_linkup(port);
    printf("\n");
	g_verbose_level = 4;
    if(rc == 0)
    	rc = sm_sata_pio_test(port, 0);
	g_verbose_level = verbose;
	return rc;
}

int sm_sata_dma(port){
	int rc = 0;
	int verbose = g_verbose_level;
    rc = sm_sata_init(port);
    if(rc == 0)
    	rc = sm_sata_linkup(port);
    printf("\n");
	g_verbose_level = 4;
    if(rc == 0)
    	rc = sm_sata_dma_test(port, 0);
	g_verbose_level = verbose;
	return rc;
}

int sm_sata_fpdma(port){
	int rc = 0;
	int verbose = g_verbose_level;
    rc = sm_sata_init(port);
    if(rc == 0)
    	rc = sm_sata_linkup(port);
    printf("\n");
	g_verbose_level = 4;
    if(rc == 0)
    	rc = sm_sata_fpdma_test(port, 0);
	g_verbose_level = verbose;
	return rc;
}

int sm_sata_power(port){
	int rc = 0;
	int verbose = g_verbose_level;
    rc = sm_sata_init(port);
    if(rc == 0)
    	rc = sm_sata_linkup(port);
    printf("\n");
	g_verbose_level = 4;
    if(rc == 0)
    	rc = sm_sata_pwr_test(port, 0);
	g_verbose_level = verbose;
	return rc;
}

int sm_sata_ncq(port){
	int rc = 0;
	int verbose = g_verbose_level;
    rc = sm_sata_init(port);
    if(rc == 0)
    	rc = sm_sata_linkup(port);
    printf("\n");
	g_verbose_level = 4;
    if(rc == 0)
    	sm_sata_ncq_test(port, 0);
	g_verbose_level = verbose;
	return rc;
}

int sm_sata_irq_dhr(port){
	int rc = 0;
    rc = sm_sata_init(port);
    if(rc == 0)
    	rc = sm_sata_linkup(port);
    printf("\n");
    if(rc == 0)
    	rc = sm_sata_irq_test(port, 0, 0);
	return rc;
}

int sm_sata_irq_ps(port){
	int rc = 0;
    rc = sm_sata_init(port);
    if(rc == 0)
    	rc = sm_sata_linkup(port);
    printf("\n");
    if(rc == 0)
    	rc = sm_sata_irq_test(port, 0, 1);
	return rc;
}

int sm_sata_irq_ds(port){
	int rc = 0;
    rc = sm_sata_init(port);
    if(rc == 0)
    	rc = sm_sata_linkup(port);
    printf("\n");
    if(rc == 0)
    	rc = sm_sata_irq_test(port, 0, 2);
	return rc;
}

int sm_sata_irq_sdb(port){
	int rc = 0;
    rc = sm_sata_init(port);
    if(rc == 0)
    	rc = sm_sata_linkup(port);
    printf("\n");
    if(rc == 0)
    	rc = sm_sata_irq_test(port, 0, 3);
	return rc;
}

int sm_sata_irq_dp(port){
	int rc = 0;
    rc = sm_sata_init(port);
    if(rc == 0)
    	rc = sm_sata_linkup(port);
    printf("\n");
    if(rc == 0)
    	rc = sm_sata_irq_test(port, 0, 5);
	return rc;
}

int sm_sata_irq_pc(port){
	int rc = 0;
    rc = sm_sata_init(port);
    if(rc == 0)
    	rc = sm_sata_linkup(port);
    printf("\n");
    if(rc == 0)
    	rc = sm_sata_irq_test(port, 0, 6);
	return rc;
}

int sm_sata_irq_prc(port){
	int rc = 0;
    rc = sm_sata_init(port);
    if(rc == 0)
    	rc = sm_sata_linkup(port);
    printf("\n");
    if(rc == 0)
    	rc = sm_sata_irq_test(port, 0, 22);
	return rc;
}

int sm_sata_ccc(port){
	int rc = 0;
    rc = sm_sata_init(port);
    if(rc == 0)
    	rc = sm_sata_linkup(port);
    printf("\n");
    if(rc == 0)
    	sm_sata_ccc_test(port, 0);
	return rc;
}

int sm_sata_hotplug(port){
	int rc = 0;
    rc = sm_sata_init(port);
    if(rc == 0)
    	rc = sm_sata_linkup(port);
    printf("\n");
    if(rc == 0)
    	rc = sm_sata_hotplug_test(port, 0);
	return rc;
}

int sm_sata_asr(port){
	int rc = 0;
    rc = sm_sata_init(port);
    if(rc == 0)
    	rc = sm_sata_linkup(port);
    printf("\n");
    if(rc == 0)
    	rc = sm_sata_asr_test(port, 0);
	return rc;
}

#endif	// for Automation
/************************* For Automation Ends ************************/

/***************************** Port Multiplier ********************************/
#if 1
int sm_sata_pmp_read32(u32 port, u32 pmp, u32 reg_num){
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);
	u32 cmd_slot = sm_sata_get_free_slot(port);
	u32 data, timeout;

	sm_sata_cmd_setup(cmd_slot, pmp, ATA_CMD_BUFFER_RD, 0, 0, 0, 0, reg_num, 0);
	sm_sata_write32(sata_ahci_port_base + CI0__ADDR, 1 << cmd_slot);
	timeout = 100;
	while((sm_sata_get_busy_slots(port) != 0) && --timeout){
		sm_sata_msdelay(1);
	}
	if(timeout){
		data = sm_sata_read32(sata_ahci_port_base + SIG0__ADDR );
		lprintf(8, "\n [PMP%d_%d READ32]: ", port, pmp);
		if(pmp == 0xF)
			lprintf(8, "GSCR");
		else
			lprintf(8, "PSCR");
		lprintf(8, "[%d] = 0x%08X \n", reg_num, data);
		return data;
	}
	else{
		lprintf(7, "\n [ERROR]: PMP%d_%d READ32 FAILED \n", port, pmp);
		return -1;
	}
}

void sm_sata_pmp_write32(u32 port, u32 pmp, u32 reg_num, u32 val){
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);
	u32 cmd_slot = sm_sata_get_free_slot(port);
	u32 timeout;

	sm_sata_cmd_setup(cmd_slot, pmp, ATA_CMD_BUFFER_WR, 0, val, 0, 0, reg_num, 0);
	sm_sata_write32(sata_ahci_port_base + CI0__ADDR, 1 << cmd_slot);
	timeout = 100;
	while((sm_sata_get_busy_slots(port) != 0) && --timeout){
		sm_sata_msdelay(1);
	}
	if(timeout){
		lprintf(8, "\n [PMP%d_%d WRITE32]: ", port, pmp);
		if(pmp == 0xF)
			lprintf(8, "GSCR");
		else
			lprintf(8, "PSCR");
		lprintf(8, "[%d] = 0x%08X \n", reg_num, val);
	}
	else
		lprintf(7, "\n [ERROR]: PMP%d_%d WRITE32 FAILED \n", port, pmp);
}

void pmp_rd(int argc, char *argv[]){
	int data;
	int port, pmp, reg_num;
	if(argc != 3){
		printf("Syntax: go pmp_rd [PORTS] [PMP] [REG]");
		printf("\n\t where [PORTS] = 0 .. 5");
		printf("\n\t where [PMP]   = PM port");
		printf("\n\t where [REG]   = Reg number \n");
	}
	else{
		port = atoi(argv[0]);
		pmp  = atoi(argv[1]);
		reg_num = atoi(argv[2]);
		printf("\n PMP%d_%d READ32 = 0x%08X \n", port, pmp, sm_sata_pmp_read32(port, pmp, reg_num));
	}
}

void pmp_wr(int argc, char *argv[]){
	int data;
	int port, pmp, reg_num, val;
	if(argc != 4){
		printf("Syntax: go pmp_wr [PORTS] [PMP] [REG] [VAL]");
		printf("\n\t where [PORTS] = 0 .. 5");
		printf("\n\t where [PMP]   = PM port");
		printf("\n\t where [REG]   = Reg number");
		printf("\n\t where [VAL]   = Writing value \n");
	}
	else{
		port = atoi(argv[0]);
		pmp  = atoi(argv[1]);
		reg_num = atoi(argv[2]);
		sm_sata_pmp_write32(port, pmp, reg_num, val);
	}
}

int PM_discovery(int port){
	u32 addr, data32, timeout;
	u32 free_slot;
	u32 sata_ahci_base = sm_sata_get_ahci_base(port);
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);

	// disable FIS-based switching
	addr = sata_ahci_port_base + FBS0__ADDR;
	data32 = sm_sata_read32(addr);
	data32 &= ~1;
	sm_sata_write32(addr, data32);

	lprintf(5, "\n P%dSIG = 0x%X", port, sm_sata_read32(sata_ahci_port_base + SIG0__ADDR));
	printf("\n Discovering PMP in SATA Port %d ...", port);

	// send ATA reset
	free_slot = sm_sata_get_free_slot(port);
	//sm_sata_ctrl_init(free_slot, 0xF, 1, 0, 1, 0, 1, 0, 0, 0xA0, 0x0C);
	sm_sata_ctrl_init(free_slot, 0xF, 1, 0, 1, 0, 1, 0, 0, 0xA0, 0x04);
	sm_sata_write32(sata_ahci_port_base + CI0__ADDR, 1 << free_slot);
	timeout = 10;
	while((sm_sata_get_busy_slots(port) != 0) && --timeout){
		sm_sata_msdelay(100);
	}
	// pull out of reset
	//sm_sata_ctrl_init(free_slot, 0xF, 1, 0, 1, 0, 1, 0, 0, 0xA0, 0x08);
	sm_sata_ctrl_init(free_slot, 0xF, 1, 0, 1, 0, 1, 0, 0, 0xA0, 0x0);
	sm_sata_write32(sata_ahci_port_base + CI0__ADDR, 1 << free_slot);
	timeout = 10;
	while((sm_sata_get_busy_slots(port) != 0) && --timeout){
		sm_sata_msdelay(100);
	}

	data32 = sm_sata_read32(sata_ahci_port_base + SIG0__ADDR);
	lprintf(5, "\n P%dSIG = 0x%X", port, data32);
	data32 = data32 >> 24;
	if((data32 == 0x69) || (data32 == 0x96)){
		printf("\n ... found a Port Multiplier by SIG \n");
		addr = sata_ahci_port_base + CMD0__ADDR;
		data32 = sm_sata_read32(addr);
		if((data32 & (1 << 17)) == 0){
			lprintf(5, "\n P%dCMD register value: 0x%08X", port, data32);
			if(data32 & 1){
				data32 &= ~1;			// make sure PxCMD.ST = 0
				sm_sata_write32(addr, data32);
			}
			data32 |= (1 << 17);	// to indicate that PMP is connected to the Host
			sm_sata_write32(addr, data32);
			data32 |= 1;			// set PxCMD.ST = 1
			sm_sata_write32(addr, data32);
		}

/*		sm_sata_write32(addr, 0x00);
		sm_sata_msdelay(1);
		sm_sata_write32(addr, 0x11);
*/
		lprintf(5, "\n P%dCMD register value: 0x%08X", port, sm_sata_read32(addr));

		data32 = sm_sata_pmp_read32(port, 0xF, PMP_GSCR2);		// Read GSCR[2] - Port Information
		lprintf(5, "\n GSCR[2] - Port Information: 0x%08X", data32);
		data32 &= 0xF;
		return (data32);	// fix me: The control port could be counted. So, minus the control port.
							// return the number of available ports on the PM card
	}
	else
		return 0;
}

void read_gscr(int port){
	int data32;
	printf("\n General Status and Control of PM in SATA Port%d\n", port);

	data32 = sm_sata_pmp_read32(port, 0xF, PMP_GSCR0);		// Read GSCR[0] - Product Identifier
	printf(" GSCR[0] - Product Identifier: 0x%08X \n", data32);
	device_id = (data32 >> 16) & 0xFFFF;
	vendor_id = data32 & 0xFFFF;
	printf("\t Device ID: 0x%X \n", device_id);
	printf("\t Vendor ID: 0x%X \n", vendor_id);

	data32 = sm_sata_pmp_read32(port, 0xF, PMP_GSCR1);		// Read GSCR[1] - Revision Information
	printf(" GSCR[1] - Revision Information: 0x%08X \n", data32);
	printf("\t Revision level: 0x%X \n", (data32 >> 8 ) & 0xFF);
	data32 &= 0xE;
	if(data32 & 8)	printf("\t Supports Port Multiplier specification 1.2 \n");
	if(data32 & 4)	printf("\t Supports Port Multiplier specification 1.1 \n");
	if(data32 & 2)	printf("\t Supports Port Multiplier specification 1.0 \n");

	data32 = sm_sata_pmp_read32(port, 0xF, PMP_GSCR2);		// Read GSCR[2] - Port Information
	printf(" GSCR[2] - Port Information: 0x%08X \n", data32);
	data32 &= 0xF;
	printf("\t Number of exposed device fan-out ports: %d \n", data32);

	data32 = sm_sata_pmp_read32(port, 0xF, PMP_GSCR64);		// Read GSCR[64] - PM Revision 1.X Features Support
	printf(" GSCR[64] - Port Information: 0x%08X \n", data32);
	data32 &= 0x1F;
	if(data32 & 16)	printf("\t Supports Phy event counters \n");
	if(data32 & 8)	printf("\t Supports Asynchronous notification \n");
	if(data32 & 4)	printf("\t Supports dynamic SSC transmit enable \n");
	if(data32 & 2)	printf("\t Supports issuing PMREQP to host \n");
	if(data32 & 1)	printf("\t Supports BIST \n");

	data32 = sm_sata_pmp_read32(port, 0xF, PMP_GSCR96);		// Read GSCR[96] - Port Multiplier Revision 1.X Features Enable
	printf(" GSCR[64] - Port Information: 0x%08X \n", data32);
	data32 &= 0xF;
	if(data32 & 8)	printf("\t Asynchronous notification enabled\n");
	if(data32 & 4)	printf("\t Dynamic SSC transmit enabled \n");
	if(data32 & 2)	printf("\t Issuing PMREQP to host enabled \n");
	if(data32 & 1)	printf("\t BIST Supports enabled \n");
}

int Device_enum(int port){
	int i;
	u32 data32, timeout;
	u32 pmp_total, pmp_on = 0;
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);

	printf ("\n Performing Port Multiplier Interface Communication");
	data32 = sm_sata_pmp_read32(port, 0xF, PMP_GSCR2);				// Read GSCR[2] - Port Information
	lprintf(5, "\n GSCR[2] - Port Information: 0x%08X", data32);
	data32 &= 0xF;
	pmp_total = data32;		// number of ports on PM card
	for (i =0; i < pmp_total; i++){
		data32 = sm_sata_pmp_read32(port, i, PMP_PSCR2);			// Read PSCR[2] - SControl register
		lprintf(5, "\n PSCR[2] - SControl register: 0x%08X", data32);
		data32 &= ~0xF;
		data32 |= 1;		// Send out COMRESET
		sm_sata_pmp_write32(port, i, PMP_PSCR2, data32);			// Write PSCR[2] - SControll register
		sm_sata_usdelay(100);
//		data32 = sm_sata_pmp_read32(port, i, PMP_PSCR2);			// Read PSCR[2] - SControl register
//		lprintf(5, "\n PSCR[2] - SControl register: 0x%08X", data32);
		data32 &= ~0xF;		// Stop sending out COMRESET
		sm_sata_pmp_write32(port, i, PMP_PSCR2, data32);			// Write PSCR[2] - SControll register
		timeout = 10;
		while(((sm_sata_pmp_read32(port, i, PMP_PSCR0) & 0xF) != 3) && --timeout){
			sm_sata_usdelay(100);
		}
		if(timeout){
			data32 = sm_sata_pmp_read32(port, i, PMP_PSCR0);		// Read PSCR[0] - SStatus register
			printf("\n\t PMP%d_%d LINK IS UP AT GEN%d", port, i, (data32>>4)&0xF);
			pmp_on |= 1 << i;
			data32 = sm_sata_pmp_read32(port, i, PMP_PSCR1);		// Read PSCR[1] SERR
			if(data32 != 0x0){
				lprintf(5, "\n\t\t PMP_PSCR1 - SError = 0x%08X", data32);
				data32 &= 1 << 26;	// Clear X bit on device port
				lprintf(5, "\n\t\t data = 0x%08X", data32);
				sm_sata_pmp_write32(port, i, PMP_PSCR1, data32);
				data32 = sm_sata_pmp_read32(port, i, PMP_PSCR1);	// Read PSCR[1] SERR
				lprintf(5, "\n\t\t PMP_PSCR1 - SError = 0x%08X", data32);
			}
		}
		else{
			printf("\n\t PMP%d_%d - no device", port, i);
		}
	}
	return pmp_on;
}

void pmp_scan(int argc, char *argv[]){
	int rc = 0;
	int port, i;
	if(argc == 0 || argc > 6){
		printf("\n Syntax: go pmp_scan [PORTS]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
	}
	else{
		for(i=0; i<argc; ++i){
			port = atoi(argv[i]);
			printf("\n Scanning PMP for SATA Port%d \n", port);

			if(sm_sata_init(port) == 0){
				if(sm_sata_linkup(port) == 0){
					if(sm_sata_readid(port, 0) == 0){
						if(PM_discovery(port)){
							read_gscr(port);
							Device_enum(port);
						}
					}
				}
			}
		}
	}
}

int sm_sata_pmp_fbs(int port, int pmp1, int pmp2){
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);
	u64 fr = SATA_DATA_WRITE_BASE;
	u64 to1 = SATA_DATA_READ_BASE;
	u64 to2 = SATA_DATA_READ_BASE + 0x20000000;
	u32 sector_count = NUM_SECTOR;
	u32 rd_cmd, wr_cmd, empty_slot;
	u32 addr32, data32;
	int rc = 0;
	int timeout = 20;

	addr32 = sata_ahci_port_base + FBS0__ADDR;
	data32 = sm_sata_read32(addr32);
	data32 |= 1;			// Enable FIS-Based Switching
	sm_sata_write32(addr32, data32);

	NUM_SECTOR = 100000;
	PRD_SIZE = 256;
	printf("\n Command      : ATA_CMD_FPDMA_WR");
	printf("\n Data transfer: %dKB", NUM_SECTOR/2);
	printf("\n PRD_Size     : %dKB", PRD_SIZE);
	printf("\n PRD_Length   : %d\n", (NUM_SECTOR/PRD_SIZE/2) + 1);
	sm_sata_cmd_setup(8, pmp1, ATA_CMD_FPDMA_WR, fr, 0, 0, 0, 0, 0);
	data32 &= ~(0xF << 8);
	data32 |= pmp1 << 8;		// Register the PM card
	sm_sata_write32(addr32, data32);
	sm_sata_write32(sata_ahci_port_base + SACT0__ADDR, 1 << 8);
	sm_sata_write32(sata_ahci_port_base + CI0__ADDR, 1 << 8);

	NUM_SECTOR = 10000;
	PRD_SIZE = 128;
	printf("\n Command      : ATA_CMD_DMA_RD_EXT");
	printf("\n Data transfer: %dKB", NUM_SECTOR/2);
	printf("\n PRD_Size     : %dKB", PRD_SIZE);
	printf("\n PRD_Length   : %d\n", (NUM_SECTOR/PRD_SIZE/2) + 1);
	sm_sata_cmd_setup(5, pmp2, ATA_CMD_DMA_RD_EXT, to1, 0, 0, 0, 0, 0);
	data32 &= ~(0xF << 8);
	data32 |= pmp2 << 8;		// Register the PM card
	sm_sata_write32(addr32, data32);
	sm_sata_write32(sata_ahci_port_base + CI0__ADDR, 1 << 5);

	NUM_SECTOR = 100000;
	PRD_SIZE = 1024;
	printf("\n Command      : ATA_CMD_FPDMA_RD");
	printf("\n Data transfer: %dKB", NUM_SECTOR/2);
	printf("\n PRD_Size     : %dKB", PRD_SIZE);
	printf("\n PRD_Length   : %d\n", (NUM_SECTOR/PRD_SIZE/2) + 1);
	sm_sata_cmd_setup(0, pmp1, ATA_CMD_FPDMA_RD, to2, 0, 0, 0, 0, 0);
	data32 &= ~(0xF << 8);
	data32 |= pmp1 << 8;		// Register the PM card
	sm_sata_write32(addr32, data32);
	sm_sata_write32(sata_ahci_port_base + SACT0__ADDR, 1 << 0);
	sm_sata_write32(sata_ahci_port_base + CI0__ADDR, 1 << 0);

	NUM_SECTOR = 50000;
	PRD_SIZE = 512;
	printf("\n Command      : ATA_CMD_DMA_WR_EXT");
	printf("\n Data transfer: %dKB", NUM_SECTOR/2);
	printf("\n PRD_Size     : %dKB", PRD_SIZE);
	printf("\n PRD_Length   : %d\n", (NUM_SECTOR/PRD_SIZE/2) + 1);
	sm_sata_cmd_setup(2, pmp2, ATA_CMD_DMA_WR_EXT, fr, 0, 0, 0, 0, 0);
	data32 &= ~(0xF << 8);
	data32 |= pmp2 << 8;		// Register the PM card
	sm_sata_write32(addr32, data32);
	sm_sata_write32(sata_ahci_port_base + CI0__ADDR, 1 << 2);

	NUM_SECTOR = sector_count;
	do{
		sm_host_read32(sata_ahci_port_base + CI0__ADDR, &timeout);
		printf("\n 0x%08X", timeout);
	}while(timeout);
}
void pmp_fbs_test(int argc, char *argv[]){
	int port, pmp1, pmp2;
	if(argc != 3){
		printf("\n Syntax: pmp_fbs_test [PORT] [PMP1] [PMP2]");
		printf("\n\t where [PORT] = SATA port 0 .. 5\n");
		printf("\n\t where [PMP1] = PM port 0 .. 4\n");
		printf("\n\t where [PMP2] = PM port 0 .. 4\n");
	}else{
		port = atoi(argv[0]);
		pmp1 = atoi(argv[1]);
		pmp2 = atoi(argv[2]);
		sm_sata_pmp_fbs(port, pmp1, pmp2);
	}
}
void pmp_fbs_bug42338(int port, int pmp, int dbc1, int dbc2, int dbc3 ){
	u64 addr;
	u32 i, data;
	u32 cmd_slot = 0;
	u32 cmd_offset = 0x1000000;
	u32 cmd_header_offset = 0x20;
	u32 prd_region = 0x80;
	u32 prd_offset = 0x10;
	u64 sec_sta = STA_SECTOR;
	u32 sec_cnt = NUM_SECTOR;
	u64 fr = SATA_DATA_WRITE_BASE;
	u64 to = SATA_DATA_READ_BASE;
	u32 timeout = 10;
	u32 rc = 0;

	u32 sata_ahci_base = sm_sata_get_ahci_base(port);
	u32 sata_ahci_port_base = sm_sata_get_ahci_port_base(port);

	//STA_SECTOR = 0x10;
	//NUM_SECTOR = 20;
	memory_reset(to, NUM_SECTOR);
	memory_create_data(fr, NUM_SECTOR);

	// Checking for Hardware Context bit
	printf("\n Hardware Context: ");
	addr = sata_ahci_base + PORTAXICFG__ADDR;
	sm_host_read32(addr, &data);
	if(data & (1 << 24))
		printf("ENABLE");
	else
		printf("DISABLE");

	// Enable FIS-based Switching & Register the PM port
	if(FBS){
		printf("\n Enable FIS-based Switching & Register the PMP%d_%d", port, pmp);
		addr = sata_ahci_port_base + FBS0__ADDR;
		data = sm_sata_read32(addr);
		data |= 1;			// Enable FIS-Based Switching
		data &= ~(0xF << 8);
		data |= pmp << 8;	// Register the PM card
		sm_sata_write32(addr, data);
	}

	// write data to drive for scoreboard
	printf("\n\n DMA WRITE %dKB to PMP%d_%d ...", NUM_SECTOR/2, port, pmp);
	sm_sata_cmd_setup(1, pmp, ATA_CMD_DMA_WR_EXT, fr, 0, 0, 0, 0, 0);
	sm_sata_write32(sata_ahci_port_base + CI0__ADDR, 1 << 1);
	do{
		sm_host_read32(sata_ahci_port_base + CI0__ADDR, &data);
		printf(".");
	}while(data);


	// setting up DMA READ command
	printf("\n\n Setting up DMA READ command ...");
	cmd_header *header = (cmd_header *) ((void *)(CMD_LST_BASE + cmd_slot*cmd_header_offset));
	cmd_fis    *fis    = (cmd_fis *) ((void *)(CMD_TABLE_BASE + cmd_slot*cmd_offset));

	memset((void *)(CMD_LST_BASE + cmd_slot*cmd_header_offset), 0x00, sizeof(cmd_header));
	memset((void *)(CMD_TABLE_BASE + cmd_slot*cmd_offset), 0x00, sizeof(cmd_fis));

	// Command header
	header->cfl = 5;
	header->a = 0;
	header->w = 0;
	if(FBS) header->p = 0;

	header->r = 0;
	header->b = 0;
	header->c = 0;
	header->pmp = pmp;

	header->prdtl = 3;

	addr = CMD_TABLE_BASE + cmd_slot*cmd_offset;
	header->ctba = addr;
	header->ctbau = addr >> 32;
	printf("\n\t Command Header DW0 = 0x%08X", sm_sata_read32(CMD_LST_BASE));
	printf("\n\t Command Header DW1 = 0x%08X", sm_sata_read32(CMD_LST_BASE + 4));
	printf("\n\t Command Header DW2 = 0x%08X", sm_sata_read32(CMD_LST_BASE + 8));
	printf("\n\t Command Header DW3 = 0x%08X", sm_sata_read32(CMD_LST_BASE + 12));

	// FIS command
	fis->fis_type = FIS_H2D;
	fis->c = 1;
	fis->pmp = pmp;
	fis->cmd = ATA_CMD_DMA_RD_EXT;
	fis->device = 0x40;			// LBA48
	fis->lba0 = sec_sta;		// 48-bit start sector
	fis->lba1 = sec_sta >> 8;
	fis->lba2 = sec_sta >> 16;
	fis->lba3 = sec_sta >> 24;
	fis->lba4 = sec_sta >> 32;
	fis->lba5 = sec_sta >> 40;
	fis->countl = sec_cnt;			// sector count
	fis->counth = sec_cnt >> 8;
	printf("\n\t FIS Command DW0 = 0x%08X", sm_sata_read32(CMD_TABLE_BASE));
	printf("\n\t FIS Command DW1 = 0x%08X", sm_sata_read32(CMD_TABLE_BASE + 4));
	printf("\n\t FIS Command DW2 = 0x%08X", sm_sata_read32(CMD_TABLE_BASE + 8));
	printf("\n\t FIS Command DW3 = 0x%08X", sm_sata_read32(CMD_TABLE_BASE + 12));

	// PRDT
	if(header->prdtl > 0){
		for(i=0; i<(header->prdtl); ++i){
			addr = CMD_TABLE_BASE + cmd_slot*cmd_offset + prd_region + prd_offset*i;
			prd_table *prdt = (prd_table *) ((void *)(addr));
			memset((void *)(addr), 0x00, sizeof(prd_table));
			//1st PRD
			if(i == 0){
				prdt->dba  = to;
				prdt->dbau = to >> 32;

				prdt->i = 1;
				prdt->dbc = dbc1*1024 - 1;
				printf("\n\t PRD[0] DW0 = 0x%08X", sm_sata_read32(addr));
				printf("\n\t PRD[0] DW1 = 0x%08X", sm_sata_read32(addr + 4));
				printf("\n\t PRD[0] DW2 = 0x%08X", sm_sata_read32(addr + 8));
				printf("\n\t PRD[0] DW3 = 0x%08X", sm_sata_read32(addr + 12));
			}else if(i == 1){
				prdt->dba  = (to + 5*1024*1024);
				prdt->dbau = (to + 5*1024*1024) >> 32;

				prdt->i = 1;
				prdt->dbc = dbc2*1024 - 1;
				printf("\n\t PRD[1] DW0 = 0x%08X", sm_sata_read32(addr));
				printf("\n\t PRD[1] DW1 = 0x%08X", sm_sata_read32(addr + 4));
				printf("\n\t PRD[1] DW2 = 0x%08X", sm_sata_read32(addr + 8));
				printf("\n\t PRD[1] DW3 = 0x%08X", sm_sata_read32(addr + 12));
			}else{
				prdt->dba  = (to + 10*1024*1024);
				prdt->dbau = (to + 10*1024*1024) >> 32;

				prdt->i = 1;
				prdt->dbc = dbc3*1024 - 1;
				printf("\n\t PRD[2] DW0 = 0x%08X", sm_sata_read32(addr));
				printf("\n\t PRD[2] DW1 = 0x%08X", sm_sata_read32(addr + 4));
				printf("\n\t PRD[2] DW2 = 0x%08X", sm_sata_read32(addr + 8));
				printf("\n\t PRD[2] DW3 = 0x%08X", sm_sata_read32(addr + 12));
			}
		}
	}
#if DDR_CACHEABLE
	//printf("\n\n DDR Flushing ... \n");
	dcache_flush_all();
#endif

	sm_sata_write32(sata_ahci_port_base + CI0__ADDR, 1 << cmd_slot);
	do{
		sm_host_read32(sata_ahci_port_base + CI0__ADDR, &data);
		printf("\n 0x%08X", data);
		sm_sata_msdelay(200);
	}while(data && --timeout);
	if(timeout){
		rc = memory_compare(0, fr, to, dbc1*2);
		rc += memory_compare(0, fr + dbc1*2*512, to + 5*1024*1024, dbc2*2);
		rc += memory_compare(0, fr + (dbc1+dbc2)*2*512, to + 10*1024*1024, dbc3*2);
		if(rc)
			printf("\n FAILED");
		else
			printf("\n PASSED");
	}
	else
		printf("\n FAILED");
}
void pmp_fbs_bug42338_test(int argc, char *argv[]){
	int port, pmp, dbc1, dbc2, dbc3;
	if(argc != 5){
		printf("\n Syntax: pmp_fbs_bug42338_test [PORT] [PMP]");
		printf("\n\t where [PORT] = SATA port 0 .. 5\n");
		printf("\n\t where [PMP]  = PM port 0 .. 4\n");
		printf("\n\t where [DBC1] = Data Byte Count\n");
		printf("\n\t where [DBC2] = Data Byte Count\n");
		printf("\n\t where [DBC3] = Data Byte Count\n");
	}else{
		port = atoi(argv[0]);
		pmp  = atoi(argv[1]);
		dbc1 = atoi(argv[2]);
		dbc2 = atoi(argv[3]);
		dbc3 = atoi(argv[4]);
		pmp_fbs_bug42338(port, pmp, dbc1, dbc2, dbc3);
	}
}
/* FIS-based Switching */
#endif
/***************************** Port Multiplier Ends ***************************/
#if 0 /* rx_margin */
void sm_sata_rx_margin(int port, int depth) {
	int ctle_def, ctle_min, ctle_max;
	int pq_def, pq_min, pq_max;
	int pll_pass, linkup_pass, pio_pass, dma_pass, fpdma_pass;
	int verbose = g_verbose_level;
//	g_verbose_level = 2;

	pll_pass = 0;
	linkup_pass = 0;
	pio_pass = 0;
	dma_pass = 0;
	fpdma_pass = 0;
	if(sm_sata_init(port) == 0) {
		pll_pass = 1;
		if(sm_sata_linkup(port) == 0) {
			STA_SECTOR = 10000;
			NUM_SECTOR = 10000;
			if(sm_sata_fpdma_test(port, 0) == 0)
				fpdma_pass = 1;
			else
				fpdma_pass = 0;
			STA_SECTOR = 5000;
			NUM_SECTOR = 5000;
			if(sm_sata_dma_test(port, 0) == 0)
				dma_pass = 1;
			else
				dma_pass = 0;
			linkup_pass = 1;
			STA_SECTOR = 100;
			NUM_SECTOR = 100;
			if(sm_sata_pio_test(port, 0) == 0)
				pio_pass = 1;
			else
				pio_pass = 0;
		}else {
			linkup_pass = 0;
		}
	}else {
		pll_pass = 0;
	}

	sm_sata_msdelay(1000);

	printf("\n CTLE_EQ = 0x%02X (DEF) \t PQ = 0x%02X ", CTLE_EQ, PQ_REG);
	if(pll_pass)
		printf("\t PLL = PASS ");
	else
		printf("\t PLL = FAIL* ");
	if(linkup_pass)
		printf("\t LinkUp = PASS  ");
	else
		printf("\t LinkUp = FAIL* ");
	if(pio_pass)
		printf("\t PIO = PASS  ");
	else
		printf("\t PIO = FAIL* ");
	if(dma_pass)
		printf("\t DMA = PASS ");
	else
		printf("\t DMA = FAIL* ");
	if(fpdma_pass)
		printf("\t FPDMA = PASS ");
	else
		printf("\t FPDMA = FAIL* ");

	ctle_def = CTLE_EQ;
	ctle_min = ctle_def - depth;
	ctle_max = ctle_def + depth;
	pq_def = PQ_REG;
	pq_min = pq_def - depth;
	pq_max = pq_def + depth;
	for(CTLE_EQ = ctle_min; CTLE_EQ <= ctle_max; ++CTLE_EQ) {
		if((CTLE_EQ >= 0) && (CTLE_EQ < 0x20)) {
			for(PQ_REG = pq_min; PQ_REG <= pq_max; ++PQ_REG) {
				if((PQ_REG >= 0) && (PQ_REG < 0x80)) {
					//if(((CTLE_EQ == ctle_def) && (PQ_REG == pq_def)) ||	(((CTLE_EQ != ctle_def)) && (PQ_REG != pq_def))) {
					if((abs(ctle_def - CTLE_EQ) == abs(pq_def - PQ_REG)) && (CTLE_EQ != ctle_def)) {
						pio_pass = 0;
						dma_pass = 0;
						fpdma_pass = 0;

						sm_sata_ctle_wr(port, CTLE_EQ);
						sm_sata_pq_wr(port, PQ_REG);

						STA_SECTOR = 10000;
						NUM_SECTOR = 10000;
						if(sm_sata_fpdma_test(port, 0) == 0)
							fpdma_pass = 1;
						else {
							fpdma_pass = 0;
							sm_sata_fix_clr(port);
						}
						STA_SECTOR = 5000;
						NUM_SECTOR = 5000;
						if(sm_sata_dma_test(port, 0) == 0)
							dma_pass = 1;
						else {
							dma_pass = 0;
							sm_sata_fix_clr(port);
						}
						STA_SECTOR = 100;
						NUM_SECTOR = 100;
						if(sm_sata_pio_test(port, 0) == 0)
							pio_pass = 1;
						else {
							pio_pass = 0;
							sm_sata_fix_clr(port);
						}

						printf("\n CTLE_EQ = 0x%02X       \t PQ = 0x%02X ", CTLE_EQ, PQ_REG);
						if(pio_pass)
							printf("\t PIO = PASS  ");
						else
							printf("\t PIO = FAIL* ");
						if(dma_pass)
							printf("\t DMA = PASS ");
						else
							printf("\t DMA = FAIL* ");
						if(fpdma_pass)
							printf("\t FPDMA = PASS ");
						else
							printf("\t FPDMA = FAIL* ");
					}
				}
			}
		}
	}
	CTLE_EQ = ctle_def;
	PQ_REG = pq_def;
	g_verbose_level = verbose;
}
#else
void sm_sata_rx_margin(int port, int depth) {
	int i, j, loop, rc;
	int ctle_def, ctle_min, ctle_max;
	int pq_def, pq_min, pq_max;
	int pll_pass, linkup_pass, pio_pass, dma_pass, fpdma_pass;
	int verbose = g_verbose_level;
	g_verbose_level = 2;

	ctle_def = CTLE_EQ;
	ctle_min = ctle_def - depth;
	ctle_max = ctle_def + depth;
	pq_def = PQ_REG;
	pq_min = pq_def - depth;
	pq_max = pq_def + depth;
	for(CTLE_EQ = ctle_min; CTLE_EQ <= ctle_max; ++CTLE_EQ) {
		if((CTLE_EQ >= 0) && (CTLE_EQ < 0x20)) {
			for(PQ_REG = pq_min; PQ_REG <= pq_max; ++PQ_REG) {
				if((PQ_REG >= 0) && (PQ_REG < 0x80)) {
					//if(((CTLE_EQ == ctle_def) && (PQ_REG == pq_def)) ||	(((CTLE_EQ != ctle_def)) && (PQ_REG != pq_def))) {
					if(((CTLE_EQ == ctle_def) && (PQ_REG == pq_def)) ||	(abs(ctle_def - CTLE_EQ) == abs(pq_def - PQ_REG))) {
						pll_pass = 0;
						linkup_pass = 0;
						pio_pass = 0;
						dma_pass = 0;
						fpdma_pass = 0;
						if(sm_sata_init(port) == 0) {
							pll_pass = 1;
							if(sm_sata_linkup(port) == 0) {
								linkup_pass = 1;
								STA_SECTOR = 100;
								NUM_SECTOR = 100;
								if(sm_sata_pio_test(port, 0) == 0)
									pio_pass = 1;
								else
									pio_pass = 0;
								STA_SECTOR = 10000;
								NUM_SECTOR = 10000;
								if(sm_sata_dma_test(port, 0) == 0)
									dma_pass = 1;
								else
									dma_pass = 0;
								STA_SECTOR = 30000;
								NUM_SECTOR = 30000;
								if(sm_sata_fpdma_test(port, 0) == 0)
									fpdma_pass = 1;
								else
									fpdma_pass = 0;
							}else {
								linkup_pass = 0;
							}
						}else {
							pll_pass = 0;
						}

						if(CTLE_EQ == ctle_def)
							printf("\n CTLE_EQ = 0x%02X (DEF) \t PQ = 0x%02X ", CTLE_EQ, PQ_REG);
						else
							printf("\n CTLE_EQ = 0x%02X       \t PQ = 0x%02X ", CTLE_EQ, PQ_REG);
						if(pll_pass)
							printf("\t PLL = PASS ");
						else
							printf("\t PLL = FAIL* ");
						if(linkup_pass)
							printf("\t LinkUp = PASS  ");
						else
							printf("\t LinkUp = FAIL* ");
						if(pio_pass)
							printf("\t PIO = PASS  ");
						else
							printf("\t PIO = FAIL* ");
						if(dma_pass)
							printf("\t DMA = PASS ");
						else
							printf("\t DMA = FAIL* ");
						if(fpdma_pass)
							printf("\t FPDMA = PASS ");
						else
							printf("\t FPDMA = FAIL* ");
					}
				}
			}
		}
	}
	CTLE_EQ = ctle_def;
	PQ_REG = pq_def;
	g_verbose_level = verbose;
}
#endif /* rx_margin */
void sm_sata_tuning(int port, int emph){
//void sm_sata_tuning(int port, int rate){
	/* rate = 1: QR, 2: HR, 3: FR */
	/* emph = 1: pre emph1, 2: pre emph2, 3: post emph */
	int CTLE_EQ_MAX = 0x20;
	int i;
	int verbose = g_verbose_level;

	g_verbose_level = 2;
	for(i=0; i<CTLE_EQ_MAX; ++i){
		switch(emph){
		case 1:
			TX_CN1 = i;
			printf("\n TX_CN1 = 0x%02X ",i);
			break;
		case 2:
			TX_CN2 = i;
			printf("\n TX_CN2 = 0x%02X ",i);
			break;
		case 3:
			TX_CP1 = i;
			printf("\n TX_CP1 = 0x%02X ",i);
			break;
		default:
			break;
		}
/*
		switch(rate){
		case 1:
			CTLE_EQ_QR = i;
			printf("\n CTLE_QR = 0x%02X ",i);
			break;
		case 2:
			CTLE_EQ_HR = i;
			printf("\n CTLE_HR = 0x%02X ",i);
			break;
		case 3:
			CTLE_EQ_FR = i;
			printf("\n CTLE_FR = 0x%02X ",i);
			break;
		default:
			break;
		}
		switch(port){
		case 0:
			CTLE_EQ_0 = i;
			break;
		case 1:
			CTLE_EQ_1 = i;
			break;
		case 2:
			CTLE_EQ_2 = i;
			break;
		case 3:
			CTLE_EQ_3 = i;
			break;
		case 4:
			CTLE_EQ_4 = i;
			break;
		case 5:
			CTLE_EQ_5 = i;
			break;
		default:
			break;
		}
//		printf("\n CTLE_EQ = 0x%02X ",i);
 */
		if(sm_sata_init(port) == 0){
			printf(" PLL Lock: PASS ");
			if(sm_sata_linkup(port) == 0)
				printf(" Linkup: PASS ");
			else
				printf(" Linkup: FAIL ");
		}else
			printf(" PLL Lock: FAIL ");
	}
	g_verbose_level = verbose;
}
void tuning(int argc, char *argv[]){
	int port, rate, dbc1, dbc2, dbc3;
	if(argc != 2){
		printf("\n Syntax: tuning [PORT]");
		printf("\n\t where [PORT] = SATA port 0 .. 5\n");
/*		printf("\n\t where [PMP]  = PM port 0 .. 4\n");
		printf("\n\t where [DBC1] = Data Byte Count\n");
		printf("\n\t where [DBC2] = Data Byte Count\n");
		printf("\n\t where [DBC3] = Data Byte Count\n");
*/	}else{
		port = atoi(argv[0]);
		rate = atoi(argv[1]);
		/*		dbc1 = atoi(argv[2]);
		dbc2 = atoi(argv[3]);
		dbc3 = atoi(argv[4]);
*/		sm_sata_tuning(port, rate);
	}
}
#endif
