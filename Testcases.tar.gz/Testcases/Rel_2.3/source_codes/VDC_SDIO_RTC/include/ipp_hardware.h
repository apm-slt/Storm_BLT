/*=============================================================================
**
** Copyright (C) 2009 AppliedMicro Confidential Information
**
** All Rights Reserved.
**
** THIS WORK CONTAINS PROPRIETARY INFORMATION WHICH IS THE PROPERTY OF
** AppliedMicro AND IS SUBJECT TO THE TERMS OF NON-DISCLOSURE AGREEMENT
** BETWEEN AppliedMicro AND THE COMPANY USING THIS FILE.
**
** File: ipp_hardware.h
** Version: 1.0
** Authors: Tushar Tyagi (ttyagi@amcc.com),
**          Anup Patel (apatel@amcc.com)
**          Prodyut Hazarika (phazarika@amcc.com)
** Description: common header file for hardware related functions & Macros
*/
#ifndef _IPP_HARDWARE_H__
#define _IPP_HARDWARE_H__
#include "../include/common.h"
#include "../include/boot_defines.h"
#include "../include/apm_ipp_csr.h"
#include "../include/ipp.h"
#include "types.h"
#include "../include/ipp_libc.h"
/* Maximum ROM/IRAM Sizes */
#define IPP_ROM_MAXSIZE			0x1800
#define IPP_IRAM_START			0x2000
#define IPP_IRAM_MAXSIZE		0x6000

#define ARM_STACK_OFFSET		0
#define ARM_STARTADDR_OFFSET		4

/** AHB Address Space */
#define MPA_AHB_BASE_VA			0x50001000
#define MPA_RTC_BASE_VA			0x50010000 
#define MPA_IIC_BASE_VA			0x50011000 
#define MPA_PKA_BASE_VA			0x50020000
#define MPA_TRNG_BASE_VA		0x50028000
#define MPA_CRD_BASE_VA			0x50040000

/** ARM PPB Private Peripheral Bus Address space */
#define PPB_BASE_VA			0xe0000000
#define REG_PPB_NVIC_ISER0		0xe100
#define REG_PPB_SYSCTL_VTOR		0xed08
#define REG_PPB_SYSTICK_CTRL		0xe010
#define REG_PPB_SYSTICK_RELOAD		0xe014
#define REG_PPB_SYSTICK_CURRENT		0xe018

/** Each Mapper can map 0.5GB space    */

/** Use Mapper 0 to map SCU, MPA space */ 
/* map 0x6000_0000 -> 0xD_C000_0000    */
/* `0b0_1101_110 = 0x6e */
/* Maps AXI Range 0xD_C000_0000 to 0xD_DFFF_FFFF */
#define MAPPER0				0x0000006e
#define MAPPER0_BASE_VA			0x60000000

/* Mapper 1 is currently unused    */
/* We will use it to map DDR space */
/* 0x8000_0000 -> 0xD_8xxx_xxxx */
/* `0b0_1101_100 = 0x6c */
#define MAPPER1				0x0000006c
#define MAPPER1_BASE_VA			0x80000000

/** Use Mapper 2 to map External AHB space */ 
/** map AHB 0xa000_0000 -> AXI 0xf_a000_0000 */
/* `0b0_1111_101 = 0x7d */
/* Maps AXI Range 0xF_A000_0000 to 0xF_BFFF_FFFF */
#define MAPPER2				0x0000007d
#define MAPPER2_BASE_VA			0xa0000000

/* Use Mapper 3 for OCM */
/** map AHB 0xc000_0000 -> AXI 0xe_e000_0000 */ 
/* `0b0_1110_111 = 0x77 */
/* Maps AXI Range 0xE_E000_0000 to 0xE_FFFF_FFFF */
#define MAPPER3				0x00000077
#define MAPPER3_BASE_VA			0xc0000000

/** MPA/ETH/PPCAHB address space using Mapper0 */
#define MPA_PPCAHB_BASE_VA		(MAPPER0_BASE_VA + 0x1D860000)
#define MPA_ETH_BASE_VA 		(MAPPER0_BASE_VA + 0x1D8a0000)
#define MPA_SCU_BASE_VA 		(MAPPER0_BASE_VA + 0x1D8b0000)
#define MPA_REG_BASE_VA			(MAPPER0_BASE_VA + 0x1D8b0800)

/** APB/SDIO/SPI mapped using Mapper 2 */
#define MPA_SPI0_BASE_VA		(MAPPER2_BASE_VA + 0x00005000) 
#define MPA_SPI1_BASE_VA		(MAPPER2_BASE_VA + 0x00006000) 
/*#define MPA_SDIO_BASE_VA		(MAPPER2_BASE_VA + 0x00040000) */
#define MPA_USB_OTG_BASE_VA		(MAPPER2_BASE_VA + 0x00100000) 
/*  FIXME: SDIO AND PPC AHB base addr  */


#define SCU_BASE_VA VA_CSR_MPA	

//#define MPA_PPC_AHB_BASE_VA 	0xdda80000 // sdio
#define MPA_PPC_AHB_BASE_VA 	VA_CSR_AHB_BRIDGE 

//#define MPA_SDIO_BASE_VA		0xe0060000 // gemini
#define MPA_SDIO_BASE_VA		VA_SDIO    // for SDIO-0 
#define MPA_SDIO_BASE_VA_1		(VA_SDIO + 0x100)   // for SDIO-1



/** OCM mapped using Mapper 3 */
#define OCM_BASE_VA			(MAPPER3_BASE_VA + 0x1FFF8000) 
#define OCM_SIZE			0x8000     /* 32K OCM      */
#define READ_OCM(offset)		sd_bswap32(READ32((char*)(OCM_BASE_VA+offset)))
#define WRITE_OCM(offset, data)		WRITE32((char*)(OCM_BASE_VA+offset), sd_bswap32(data))

/** Endianess macros */
#define CPU_TO_LE32(data32)		sd_bswap32(data32)
#define LE32_TO_CPU(data32)		sd_bswap32(data32)
#define CPU_TO_LE16(data16)		sd_bswap16(data16)
#define LE16_TO_CPU(data16)		sd_bswap16(data16)
#define CPU_TO_BE32(data32)		data32
#define BE32_TO_CPU(data32)		data32
#define CPU_TO_BE16(data16)		data16
#define BE16_TO_CPU(data16)		data16

/** READ WRITE macros */


#if 1 //mmd

// datnguyen
//static inline void WRITE32(unsigned int *_reg_addr, unsigned int _data32)
//{
//    *((volatile unsigned int *)_reg_addr) = _data32;
//    printf("WR32 -> addr:0x%08x data32:0x%08x\n",_reg_addr,_data32);
//}
//static inline unsigned int READ32(unsigned int *_addr)
//{
//    unsigned int ret=0;
//    ret = *((volatile unsigned int *)_addr);
//    printf("RD32 -> addr:0x%08x data32:0x%08x\n",_addr,ret);
//    return ret;
//}
#endif

#define READ_PRIV(offset)		READ32((char*)(PPB_BASE_VA+offset))
#define WRITE_PRIV(offset, data)	WRITE32((char*)(PPB_BASE_VA+offset), data)
#define READ_MPA(offset)		sd_bswap32(READ32((char*)(MPA_REG_BASE_VA+offset)))
#define WRITE_MPA(offset, data)		WRITE32((char*)(MPA_REG_BASE_VA+offset), sd_bswap32(data))
#define READ_SCU(offset)		sd_bswap32(READ32((char*)(MPA_SCU_BASE_VA+offset)))
#define WRITE_SCU(offset, data)		WRITE32((char*)(MPA_SCU_BASE_VA+offset), sd_bswap32(data))
#define READ_AHB(offset)		READ32((char*)(MPA_AHB_BASE_VA+offset))
#define WRITE_AHB(offset, data)		WRITE32((char*)(MPA_AHB_BASE_VA+offset), data)
#define READ_CRD(offset)		READ32((char*)(MPA_CRD_BASE_VA+offset))
#define WRITE_CRD(offset, data)		WRITE32((char*)(MPA_CRD_BASE_VA+offset), data)
#define READ_IIC(offset)		READ32((char*)(MPA_IIC_BASE_VA+offset))
#define WRITE_IIC(offset, data)		WRITE32((char*)(MPA_IIC_BASE_VA+offset), data)
#define READ_RTC(offset)		READ32((char*)(MPA_RTC_BASE_VA+offset))
#define WRITE_RTC(offset, data)		WRITE32((char*)(MPA_RTC_BASE_VA+offset), data)
#define READ_PKA(offset)		READ32((char*)(MPA_PKA_BASE_VA+offset))
#define WRITE_PKA(offset, data)		WRITE32((char*)(MPA_PKA_BASE_VA+offset), data)
#define READ_TRNG(offset)		READ32((char*)(MPA_TRNG_BASE_VA+offset))
#define WRITE_TRNG(offset, data)	WRITE32((char*)(MPA_TRNG_BASE_VA+offset), data)

/* Swap Needed for AXI space */
/*#define READ_PPCAHB(offset)		sd_bswap32(READ32((char*)(MPA_PPCAHB_BASE_VA+offset)))
#define WRITE_PPCAHB(offset, data)	WRITE32((char*)(MPA_PPCAHB_BASE_VA+offset), sd_bswap32(data))*/
#define READ_ETH(offset)		sd_bswap32(READ32((char*)(MPA_ETH_BASE_VA+offset)))
#define WRITE_ETH(offset, data)		WRITE32((char*)(MPA_ETH_BASE_VA+offset), sd_bswap32(data))
#define READ_SPI0(offset)		sd_bswap32(READ32((char*)(MPA_SPI0_BASE_VA+offset)))
#define WRITE_SPI0(offset, data)	WRITE32((char*)(MPA_SPI0_BASE_VA+offset), sd_bswap32(data))
#define READ_SPI1(offset)		sd_bswap32(READ32((char*)(MPA_SPI1_BASE_VA+offset)))
#define WRITE_SPI1(offset, data)	WRITE32((char*)(MPA_SPI1_BASE_VA+offset), sd_bswap32(data))
/*#define READ_SDIO(offset)		sd_bswap32(READ32((char*)(MPA_SDIO_BASE_VA+offset)))
#define WRITE_SDIO(offset, data)	WRITE32((char*)(MPA_SDIO_BASE_VA+offset), sd_bswap32(data))*/
#define READ_USBOTG(offset)		sd_bswap32(READ32((char*)(MPA_USB_OTG_BASE_VA+offset)))
#define WRITE_USBOTG(offset, data)	WRITE32((char*)(MPA_USB_OTG_BASE_VA+offset), sd_bswap32(data))
/*  FIXME: update SDIO PPC read macro  */

#if 1 //mmd
// datnguyen
//#define READ_SDIO(offset)		sd_bswap32(READ32((char*)(MPA_SDIO_BASE_VA+offset)))
//#define WRITE_SDIO(offset, data)	WRITE32((char*)(MPA_SDIO_BASE_VA+offset), sd_bswap32(data))
//
//#define READ_SDIO_1(offset)		sd_bswap32(READ32((char*)(MPA_SDIO_BASE_VA_1+offset)))
//#define WRITE_SDIO_1(offset, data)	WRITE32((char*)(MPA_SDIO_BASE_VA_1+offset), sd_bswap32(data))
#endif //mmd


#if 0 //mmd
static inline void WRITE_SDIO(u8 sdio_no, unsigned int *_reg_addr, unsigned int _data32) 
{
    if(sdio_no == 1)
        WRITE32((char*)(MPA_SDIO_BASE_VA+offset), sd_bswap32(data))
    else(sdio_no == 2)
        WRITE32((char*)(MPA_SDIO_BASE_VA_1+offset), sd_bswap32(data))
}
static inline unsigned int READ_SDIO(u8 sdio_no, unsigned int *_addr) 
{
    if(sdio_no == 1)
        sd_bswap32(READ32((char*)(MPA_SDIO_BASE_VA+offset)))
    else if (sdio_no == 2)    
        sd_bswap32(READ32((char*)(MPA_SDIO_BASE_VA_1+offset)))
}
#endif

#if 0 //mmd
#define WRITE_SDIO(u8 sdio_no, unsigned int *_reg_addr, unsigned int _data32) \
    {   \
    if(sdio_no == 1) \
        WRITE32((char*)(MPA_SDIO_BASE_VA+offset), sd_bswap32(data)) \
    else(sdio_no == 2) \
        WRITE32((char*)(MPA_SDIO_BASE_VA_1+offset), sd_bswap32(data)) \
    } \


#define READ_SDIO(u8 sdio_no, unsigned int *_addr) \
{ \
    if(sdio_no == 1) \
        sd_bswap32(READ32((char*)(MPA_SDIO_BASE_VA+offset))) \
    else if (sdio_no == 2)    \
        sd_bswap32(READ32((char*)(MPA_SDIO_BASE_VA_1+offset))) \
}
#endif


#if 0 //mmd old 
#define READ_SDIO(offset)		READ32((char*)(MPA_SDIO_BASE_VA+offset))
#define WRITE_SDIO(offset, data)	WRITE32((char*)(MPA_SDIO_BASE_VA+offset), data)
#endif //mmd

#define READ_PPCAHB(offset)		READ32((char*)(MPA_PPC_AHB_BASE_VA+offset))
#define WRITE_PPCAHB(offset, data)	WRITE32((char*)(MPA_PPC_AHB_BASE_VA+offset), data)

//mmd
//#define READ_PPCSCU(offset)		READ32((char*)(SCU_BASE_VA+offset))
//#define WRITE_PPCSCU(offset, data)	WRITE32((char*)(SCU_BASE_VA+offset), data)
#define READ_PPCSCU(offset)		READ32((char*)(0x17000000 + offset))
#define WRITE_PPCSCU(offset, data)	WRITE32((char*)(0x17000000 + offset), data)
//mmd

#define TPM_ENABLED			0x1

#define SCU_ENABLEALL_NOSEC_MASK	(NDFC_F1_MASK | APB_PERI_F1_MASK | MPIC_MASK | \
					SATA0_F1_MASK | SATA1_F1_MASK | USB0_F1_MASK | USB1_F1_MASK | USB2_F1_MASK | \
					PCIE1_F1_MASK | PCIE2_F1_MASK | PCIE3_F1_MASK | ENET0_F1_MASK | ENET1_F1_MASK | \
					SPI_F1_MASK | SDIO_F1_MASK | MEMC_AXI_MASK | MEMC_PLB_MASK | OCM_F1_MASK | \
					PKTDMA_F1_MASK | QMTM_F1_MASK | QMLITE_F1_MASK | LCD_F1_MASK | PLB_F1_MASK | TRACE_F1_MASK)

#define SCU_CSR_ENABLEALL_NOSEC_MASK	(TDM_MASK | AHBC_F1_MASK | MPIC_F2_MASK | SATA0_F3_MASK | SATA1_F3_MASK | \
					PCIE1_F3_MASK | PCIE2_F3_MASK | PCIE1_F3_MASK | ENET0_F3_MASK | ENET1_F2_MASK | \
					MEMC_F2_MASK | OCM_F3_MASK | PKTDMA_F2_MASK | QMTM_F3_MASK | QMLITE_F2_MASK | \
					LCD_F2_MASK | TRACE_F2_MASK)

/* FIXME: OCM address where PPC image will be loaded*/
#define IPP_PPCBOOT_OCM_ADDR		0xc0000000
/* FIXME: OCM memory size where PPC image will be loaded */
#define IPP_PPCBOOT_OCM_SIZE		0x8000

/* iPP DRAM Start Address			*/
#define IPP_DRAM_START_ADDR		0x3fff0000

/* iPP Stack Start Address - Grows downward      */
#define IPP_STACK_TOP_ADDR		0x3fff1000

/* iPP Data RAM Globals Start Address - grows up */

/* Base Address Reserved for QML Resources */
/* 4K reserved for QML                     */
#define IPP_QML_RESOURCE_OFFSET		0x1000
#define IPP_QML_RESOURCE_BASE_ADDR      (IPP_DRAM_START_ADDR + IPP_QML_RESOURCE_OFFSET)

/* IPP Runtime memory map */
/**

	|--------| -> IRAM_START
	|        |
	|        |
	|        |
	|        |
	|        |
	|  IRAM  |
	|        |
	|        |
	|        |
	|        |
	|        |
	|--------| -> 1024*24 (Start of Global)
	| Global |
	|   |    |
	|   v    |
	|        |
	|        | -> 1024*4
	|   ^    |
	|   |    |   |------> Stack Starts at 0x3fff1000
	| Stack  |   |------> Stack grows from here downwards.
	|--------| --+
	| QML    |   |------> Message buffers sit here onwards.
	| data   | ---------> Here onwards space is free for PPC and QML etc.
	|        |
	| PPC    | -> 1024*4
	| msg    |
	| data   |
	|--------| -> Total 1024*32 (0x9fff)

	Note: in secured mode, iPP DRAM access via AXI is blocked
**/

/* Prototype of runtime function */
typedef void(*ipp_runtime_func_t)(void);

/* Possible PPC boot devices */
enum ipp_ppcboot_devices {
	IPP_PPCBOOTDEV_NAND=0,
	IPP_PPCBOOTDEV_NOR=1,
	IPP_PPCBOOTDEV_ROM_NAND=2,
	IPP_PPCBOOTDEV_ROM_NOR=3,
	IPP_PPCBOOTDEV_NAND_ECC=4,
	IPP_PPCBOOTDEV_VFAT=5,
	IPP_PPCBOOTDEV_USB=IPP_PPCBOOTDEV_VFAT,		/* For iPP it means I2C, this onwards */
	IPP_PPCBOOTDEV_SDIO=IPP_PPCBOOTDEV_VFAT+1,
	IPP_PPCBOOTDEV_SPI=IPP_PPCBOOTDEV_VFAT+2
};

/* Possible ARM boot devices */
enum ipp_armboot_devices {
	IPP_ARMBOOTDEV_ROM=0,
	IPP_ARMBOOTDEV_IIC=1
};

/* Function Declarations */
/* Offset must be 32-bit aligned */
u32 read_iram_word(u32 offset);

/* Offset must be 32-bit aligned */
u32 copy_to_iram(u32 offset, u32 *data, u32 wcount);

/* offset: 32 bit / 4 byte aligned offset into the eFuse array */
u32 read_efuse_32(u32 offset);

/* Release reset to PowerPC */
u32 start_ppc(void);

u32 hw_init(void);
u32 load_iram_from_i2c(u32 dest,u32 offset,u32 len);
u32 ppcboot_device_id(void);
u32 armboot_device_id(void);
u32 get_iram_size(void);

#endif /* _IPP_HARDWARE_H__ */

