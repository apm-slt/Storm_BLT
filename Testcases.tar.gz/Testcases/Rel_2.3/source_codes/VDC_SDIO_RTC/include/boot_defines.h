#ifndef BOOT_DEFINES_H
#define BOOT_DEFINES_H

/*
//////////////////////////////////////////////////////////////////////////////////
# This is a define file used for the Boot Code 
# It mainly has the Virtual Address and Physical Address Mapping Defines
# Page Size     SIZE 
#   1 KB    =   0
#   4 KB    =   1
#   16 KB   =   2
#   64 KB   =   3
#   256 KB  =   4
#   1 MB    =   5
#   16 MB   =   7
#   256 MB  =   9
#   1 GB    =   10
//////////////////////////////////////////////////////////////////////////////////
*/
// Size defines
#define SZ_1KB    0x0
#define SZ_4KB    0x1
#define SZ_16KB   0x2
#define SZ_64KB   0x3
#define SZ_256KB  0x4
#define SZ_1MB    0x5
#define SZ_16MB   0x7
#define SZ_256MB  0x9
#define SZ_1GB    0xA



// Segment - 0
#define VA_DDR       0x00000000
#define PA_DDR       0x00000000
#define ERPN_DDR     0x0
#define DDR_SIZE     SZ_1GB

#define VA_DDR_REG   0x80000000
#define PA_DDR_REG   0xFFFFD000
#define ERPN_DDR_REG 0x3
#define DDR_REG_SIZE SZ_16KB

#define VA_MAILBOX   VA_DDR_REG

// Segment - 1 (Actual Size is 512 KB)
#define VA_FAM      0x80D00000
#define PA_FAM      0x00000000
#define ERPN_FAM    0x4
#define FAM_SIZE    SZ_256KB

// Segment - 3
// PCIE Fabric
#define VA_SATA    0x8E000000
#define PA_SATA    0x00000000
#define ERPN_SATA  0x5
#define SATA_SIZE  SZ_16KB

#define VA_PCIE1   0x90000000
#define PA_PCIE1   0x00000000
#define ERPN_PCIE1 0x6
#define PCIE1_SIZE SZ_256MB

#define VA_PCIE2   0xA0000000
#define PA_PCIE2   0x00000000
#define ERPN_PCIE2 0x7
#define PCIE2_SIZE SZ_256MB

#define VA_PCIE3   0xB0000000
#define PA_PCIE3   0x00000000
#define ERPN_PCIE3 0xA
#define PCIE3_SIZE SZ_256MB

// Deep Sleep Fabric - 37 Bits

#define VA_QMLite    0x81000000
#define PA_QMLite    0x00000000
#define ERPN_QMLite  0xD
// Actual Size is 4 MB
#define QMLite_SIZE  SZ_1MB


#define VA_MPA       0x81400000
#define PA_MPA       0x00400000
#define ERPN_MPA     0xD
#define MPA_SIZE     SZ_256KB

#define VA_MPA_DRAM  (VA_MPA | 0x00000000)
#define VA_MPA_RTC   (VA_MPA | 0x00010000)
#define VA_MPA_PKA   (VA_MPA | 0x00020000)
#define VA_MPA_TRNG  (VA_MPA | 0x00028000)
#define VA_MPA_QMI   (VA_MPA | 0x00030000)


#define VA_MPA_ETH   0x81500000
#define PA_MPA_ETH   0x00440000
#define ERPN_MPA_ETH  0xD
#define MPA_ETH_SIZE     SZ_4KB

#define VA_MPA_CLASS 0x81600000
#define PA_MPA_CLASS 0x00441000
#define ERPN_MPA_CLASS  0xD
#define MPA_CLASS_SIZE     SZ_4KB


// CSR Virtual Address

#define VA_CSR      0x1f2a0000 // datnguyen 0x84000000 -> 0x84000000 for storm
#define PA_CSR      0xDD800000
#define ERPN_CSR    0xD

// Actual Size is 1 MB
#define CSR_SIZE    SZ_1MB

#define VA_CSR_QMTM     (VA_CSR) 
#define VA_CSR_SDU      (VA_CSR | 0x00010000) 
#define VA_CSR_DMA      (VA_CSR | 0x00020000)
#define VA_CSR_SEC      (VA_CSR | 0x00030000)
#define VA_CSR_OCMM     (VA_CSR | 0x00050000)
#define VA_CSR_AHB_BRIDGE (VA_CSR | 0x00000000) // 0x1f2a0000
#define VA_CSR_SATA     (VA_CSR | 0x00070000)
#define VA_CSR_PCIE1    (VA_CSR | 0x00080000)
#define VA_CSR_PCIE2    (VA_CSR | 0x00090000)
#define VA_CSR_ETH      (VA_CSR | 0x000A0000)
#define VA_CSR_MPA      (VA_CSR | 0x000B0000)
#define VA_CSR_SCU      (VA_CSR | 0x000C0000)
#define VA_CSR_QMLite   (VA_CSR | 0x000D0000)
#define VA_CSR_CLASS    (VA_CSR | 0x000E0000)
#define RESERVE_1       (VA_CSR | 0x000F0000)

#define VA_CSR_SATA0    	VA_CSR_SATA
#define VA_CSR_SATA1    	VA_CSR_PCIE1
#define	SERDES_OFFSET	0x4000
// Primary Fabric  Virtual Address
#define VA_QMTM         0x88000000
#define PA_QMTM         0xDF000000
#define ERPN_QMTM       0xD
// Actual Size is 4 MB (Use 4 Entries of 1 MB)
#define QMTM_SIZE       SZ_1MB


#define VA_MPIC         0x88900000
#define PA_MPIC         0xDF400000
#define ERPN_MPIC       0xD
#define MPIC_SIZE       SZ_256KB

#define VA_LCDC         0x88940000
#define PA_LCDC         0xDF440000
#define ERPN_LCDC       0xD
#define LCDC_SIZE       SZ_256KB

#define VA_DMA          0x88980000
#define PA_DMA          0xDF600000
#define ERPN_DMA        0xD
#define DMA_SIZE        SZ_4KB

#define VA_SEC          0x88981000
#define PA_SEC          0xDF601000
#define ERPN_SEC        0xD
#define SEC_SIZE        SZ_4KB

#define VA_QMI          0x88982000
#define PA_QMI          0xDF602000
#define ERPN_QMI        0xD
#define QMI_SIZE        SZ_4KB

//// APB Bridge 
#define VA_APB_BRIDGE   0x89000000
#define PA_APB_BRIDGE   0xA0000000
#define ERPN_APB_BRIDGE 0xF
#define APB_BRIDGE_SIZE SZ_1MB


#define VA_UART0        VA_APB_BRIDGE
#define VA_UART1        (VA_APB_BRIDGE | 0x00001000)
#define VA_IIC0         (VA_APB_BRIDGE | 0x00002000)
#define VA_IIC1         (VA_APB_BRIDGE | 0x00003000)
#define VA_GPIO         (VA_APB_BRIDGE | 0x00004000)
#define VA_SPI0         (VA_APB_BRIDGE | 0x00005000)
#define VA_SPI1         (VA_APB_BRIDGE | 0x00006000)

#define VA_USB_BASE      0x8A010000
#define PA_USB_BASE      0xA0010000
#define ERPN_USB_BASE    0xF
#define USB_BASE_SIZE    SZ_4KB
#define VA_USBH0_OHCI   (VA_USB_BASE | 0x00000000)
#define VA_USBH0_EHCI   (VA_USB_BASE | 0x00000400)
#define VA_USBH1_OHCI   (VA_USB_BASE | 0x00000800)
#define VA_USBH1_EHCI   (VA_USB_BASE | 0x00000c00)

#define VA_AHB_ARBITER  0x8B000000
#define PA_AHB_ARBITER  0xA0030000
#define ERPN_AHB_ARBITER 0xF
#define AHB_ARBITER_SIZE  SZ_64KB

#define VA_SDIO  0x1C000000  //datnguyen 0x8B010000 -> 0x1C000000
#define PA_SDIO  0xA0040000
#define ERPN_SDIO 0xF
#define SDIO_SIZE  SZ_1KB

#define VA_USB_OTG  0x8C000000
#define PA_USB_OTG  0xA0100000
#define ERPN_USB_OTG 0xF
#define USB_OTG_SIZE  SZ_256KB

#define VA_FLASH_CTRL  0x8D000000
#define PA_FLASH_CTRL  0xA0140000
#define ERPN_FLASH_CTRL 0xF
#define FLASH_CTRL_SIZE  SZ_4KB

//PPC and MPA boot Nor-Nand
#define VA_NOR_NAND     0xC0000000
#define PA_NOR_NAND     0xE0000000
#define ERPN_NOR_NAND   0xF
#define NOR_NAND_SIZE   SZ_256MB

// OCMM (PPC Boot) - 32 KB Actual 
#define VA_OCMM         0xFFFF8000
#define PA_OCMM         0xFFFF8000
#define ERPN_OCMM       0xE
#define OCMM_SIZE       SZ_16KB

#endif




