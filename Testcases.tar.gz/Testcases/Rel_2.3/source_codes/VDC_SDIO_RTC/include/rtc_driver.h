/*
 * Copyright (C) 2013 AppliedMicro Confidential Information
 * All Rights Reserved.
 *
 * THIS WORK CONTAINS PROPRIETARY INFORMATION WHICH IS THE PROPERTY OF
 * AppliedMicro AND IS SUBJECT TO THE TERMS OF NON-DISCLOSURE AGREEMENT
 * BETWEEN AppliedMicro AND THE COMPANY USING THIS FILE.
 *
 * WARNING !!!
 * This is an auto-generated C header file for register definitions
 * PLEASE DON'T MANUALLY MODIFY IN THIS FILE AS CHANGES WILL BE LOST
 *
 * rtc_driver.h
 *
 *  Created on: Mar 07, 2013
 *      Author: kqngo@apm.com
 */

#ifndef RTC_DRIVER_H_
#define RTC_DRIVER_H_

#include <common.h>
#include "rtc_reg.h"

#define FEBRUARY		2
#define	STARTOFTIME		1970
#define SECDAY			86400L
#define SECYR			(SECDAY * 365)
#define	leapyear(year)		((year) % 4 == 0)
#define	days_in_year(a)		(leapyear(a) ? 366 : 365)
#define	days_in_month(a)	(month_days[(a) - 1])

static int month_days[12] = {
	31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31
};

u32 sm_rtc_read32(unsigned addr);
u32 sm_rtc_read32(unsigned addr);
void sm_rtc_write32(unsigned addr, unsigned data);

int sm_rtc_load_cnt(u32 data);
int sm_rtc_wrap_ena(void);
int sm_rtc_wrap_dis(void);
int sm_rtc_cnt_ena(void);
int sm_rtc_cnt_dis(void);
int sm_rtc_interrupt_ena(void);
int sm_rtc_interrupt_dis(void);
int sm_rtc_interrupt_mask_ena(void);
int sm_rtc_interrupt_mask_dis(void);
void sm_rtc_read_eoi(void);

int sm_rtc_default_value(void);
int sm_rtc_wrap_test(int sec);
int sm_rtc_accuracy_test(int sec);
int sm_rtc_interrupt_test(int sec);

#endif /* RTC_DRIVER_H_ */
