/*=============================================================================
**
** Copyright (C) 2009 AppliedMicro Confidential Information
**
** All Rights Reserved.
**
** THIS WORK CONTAINS PROPRIETARY INFORMATION WHICH IS THE PROPERTY OF
** AppliedMicro AND IS SUBJECT TO THE TERMS OF NON-DISCLOSURE AGREEMENT
** BETWEEN AppliedMicro AND THE COMPANY USING THIS FILE.
**
** File: ipp_vfatdev_sdio.h
** Version: 1.0
** Authors: Anup Patel (apatel@amcc.com)
** Description: SDIO driver header file for VFAT
*/
#ifndef _IPP_VFATDEV_SDIO_H__
#define _IPP_VFATDEV_SDIO_H__

#include "../include/ipp.h"
#include "../include/storm_common.h"
#include "types.h"
#include "../include/ipp_hardware.h"
#include "../include/ipp_libc.h"
#include "../include/vSDIO_regs.h"

#define SDIO_BLOCK_SIZE		512

//#define SDIO_OCM_PHYS_ADDR_RD	0x02000000
#define SDIO_OCM_PHYS_ADDR_RD	0x1d0c0000 //datnguyen0x2E000000
//#define SDIO_OCM_PHYS_ADDR_WR	0x02001000
#define SDIO_OCM_PHYS_ADDR_WR	0x1d0c1000 // datnguyen0x2E010000

/*
#define SDIO_OCM_VIRT_ADDR	0x01000000
#define SDIO_OCM_PHYS_ADDR	0x01000000
#define SDIO_OCM_VIRT_ADDR_WR	0x01001000
#define SDIO_OCM_PHYS_ADDR_WR	0x01001000
*/

u32 read_vfatdev_emmc_adma_2_multi_block_test_suspend_resume(u8 sdio_no,u32 lba,u16 blkNo);
u32 write_vfatdev_emmc_adma_2_multi_block_test_suspend_resume(u8 sdio_no,u32 lba,u16 blkNo);
int sdio_pio(u8 sdio_no,unsigned int capacity);
u32 sdio_hw_pio(u8 sdio_no, unsigned int capacity);
int sdio_detect(unsigned char sdio_no);
u32 test_write_pio (unsigned char sdio_no, unsigned int lba );
u32 test_read_pio (unsigned char sdio_no, unsigned int lba );
u32 test_write_sdma (unsigned char sdio_no ,unsigned int lba );
void start_test (void);
u32 read_vfatdev_sdio(unsigned char *dest,unsigned int lba,unsigned int blkoff,unsigned int len);
u32 init_vfatdev_sdio(unsigned int *block_size);
void SDIO_soft_reset (void);
#endif
