/*=============================================================================
**
** Copyright (C) 2009 AppliedMicro Confidential Information
**
** All Rights Reserved.
**
** THIS WORK CONTAINS PROPRIETARY INFORMATION WHICH IS THE PROPERTY OF
** AppliedMicro AND IS SUBJECT TO THE TERMS OF NON-DISCLOSURE AGREEMENT
** BETWEEN AppliedMicro AND THE COMPANY USING THIS FILE.
**
** File: ipp_libc.h
** Version: 1.0
** Authors: Anup Patel (apatel@amcc.com)
** Description: C library header file
*/
#ifndef _IPP_LIBC_H__
#define _IPP_LIBC_H__
#include "types.h"
// #include "mb_common.h" // modify for uboot
#include "../include/ipp.h"

/** Useful macros */
#define less( _a, _b ) ( (_a < _b) ? 1:0 )

u16 sd_bswap16(u16 h);
u32 sd_bswap32(u32 h);
void *ipp_memcpy(void *dest, void *src, size_t count);
void *ipp_memset(void *dest, int c, size_t count);
int ipp_memcmp(const void * s1, const void *s2, size_t count);

/* Delay in microseconds */
void ipp_udelay(int usecs);

/* For uboot environment */
//int  getc(void);
//int  tstc(void);
//void putc(const char);
//void puts(const char*);
//void printf(const char* fmt, ...);
//void free(void*);
//void udelay(unsigned long);

#endif
