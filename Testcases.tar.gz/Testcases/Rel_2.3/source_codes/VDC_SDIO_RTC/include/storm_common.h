/* Author: automation@apm.com
*  Company: Applied Micro Circuits Corporation (AMCC)
*
* Describe the purpose of your Test here
*   - Include all common functions here
*/
////
//#define READ8(a) (*(volatile unsigned char *)(a))
//#define READ32(a) (*(volatile unsigned *)(a))
//#define WRITE8(a, d)  *(unsigned char *)(a) = (unsigned char)(d)
//#define WRITE32(a, d) *(unsigned *)(a) = (unsigned )(d)

//#define READ8(a) (*(volatile unsigned char *)(a)) // modify for uboot
//#define READ32(a) (*(volatile unsigned *)(a)) // modify for uboot
//#define WRITE8(a, d)  *(unsigned char *)(a) = (unsigned char)(d) // modify for uboot
//#define WRITE32(a, d) *(unsigned *)(a) = (unsigned )(d) // modify for uboot
