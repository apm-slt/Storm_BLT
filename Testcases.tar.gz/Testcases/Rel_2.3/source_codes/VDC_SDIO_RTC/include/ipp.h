/*=============================================================================
**
** Copyright (C) 2009 AppliedMicro Confidential Information
**
** All Rights Reserved.
**
** THIS WORK CONTAINS PROPRIETARY INFORMATION WHICH IS THE PROPERTY OF
** AppliedMicro AND IS SUBJECT TO THE TERMS OF NON-DISCLOSURE AGREEMENT
** BETWEEN AppliedMicro AND THE COMPANY USING THIS FILE.
**
** File: ipp.h
** Version: 1.0
** Authors: Anup Patel (apatel@amcc.com)
** Description: common header file for typedefs and macros
*/
#ifndef _IPP_H__
#define _IPP_H__

#if 0
/** Handy data types */
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned long long u64;
#endif
// datnguyen
//typedef char s8;
//typedef short s16;
//typedef int s32;
#ifndef _SIZE_T
#define _SIZE_T
typedef unsigned int			size_t;
#endif

/* iPP error codes */
typedef enum {
	/* Common */
	IPP_OK=0,
	IPP_ERR_FAIL,
	IPP_ERR_INVALID,
	IPP_ERR_NOTAVAIL,
	IPP_ERR_NOSPACE,
	IPP_ERR_BUSY,
	IPP_ERR_BOOT_INVALIMG,
	IPP_ERR_NOHW,
	IPP_ERR_SDHW
	
} ipp_error_codes;

/** Boolean macros */
#define TRUE 1
#define FALSE 0

#endif
