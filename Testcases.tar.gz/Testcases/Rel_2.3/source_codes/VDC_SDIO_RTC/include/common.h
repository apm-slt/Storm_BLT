/* Author: automation@apm.com
*  Company: Applied Micro Circuits Corporation (AMCC)
*
* Describe the purpose of your Test here
*   - Include all common functions here
*/
#ifndef __SHOW_RESULT__
#define __SHOW_RESULT__

#define READ8(a) (*(volatile unsigned char *)(a))
#define READ32(a) (*(volatile unsigned *)(a))
#define WRITE8(a, d)  *(unsigned char *)(a) = (unsigned char)(d)
#define WRITE32(a, d) *(unsigned *)(a) = (unsigned )(d)

void printPASSSDIO(void);
void printFAILSDIO(void);

#ifdef DEBUG
#define debug_sdio(format, arg...)	printf("" format , ## arg)
#else
#define debug_sdio(format, arg...)	do {} while(0)
#endif

#endif
