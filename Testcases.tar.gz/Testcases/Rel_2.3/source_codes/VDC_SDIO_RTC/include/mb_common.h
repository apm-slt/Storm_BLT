#ifndef __MB_COMMON_H__
#define __MB_COMMON_H__

#ifndef __ASM_TYPES_H_
#define __ASM_TYPES_H_
// datnguyen
//typedef unsigned char		u8;
//typedef unsigned short		u16;
//typedef unsigned long 		u32;
//typedef unsigned long long	u64;

typedef volatile unsigned char		vu8;
typedef volatile unsigned short		vu16;
typedef volatile unsigned long 		vu32;
typedef volatile unsigned long long	vu64;
#endif

#define SYNCHRONIZE_IO __asm__ volatile ("eieio")
#define mb_in_be32(InputPtr) (*(vu32 *)(InputPtr)); SYNCHRONIZE_IO;
#define mb_out_be32(OutputPtr, Value) \
    { (*(vu32 *)(OutputPtr) = Value); SYNCHRONIZE_IO; }

#define mb_ddr_p2v(addr) ((u32)addr)

//kxtran
#define SYNC __asm__ volatile ("sync")
#define ISYNC __asm__ volatile ("isync")

//kxtran
#define CPU_CLK_HZ	800000000ULL
#define CPU_CLK_KHZ	800000ULL
#define CPU_CLK_MHZ	800ULL

//kxtran
//time base unit
#define MFTB()		({unsigned int rval; \
						asm volatile("mftb %0" : "=r" (rval)); rval;})
#define MFTBU()	({unsigned int rval; \
						asm volatile("mftbu %0" : "=r" (rval)); rval;})
typedef struct time_base_st{
	unsigned int tbu;
	unsigned int tbl;
}TIME_BASE_T;
typedef union time64_union{
	unsigned long long tmp64;
	TIME_BASE_T time;
}TIME64_T;

typedef enum
{
	MB_OK,
	MB_INVALID_PARAM,
	MB_NO_RSC,
	MB_TIMEOUT,
	MB_FATAL,
	MB_FAIL

} mb_ret_t;

typedef enum
{
	MB_RD,
	MB_WR,
	MB_OP_MAX,

} mb_op_t;

extern unsigned int gVerboseLevel;

/* Debugging Flags */

#define LPRINTF_ENABLE 

#define VL_EMERG           0 /**< Logging Level Pass/Fail */
#define VL_ALERT           1 /**< External Device Config     */
#define VL_CRIT            2 /**< Logging Level IP Config print  */
#define VL_ERR             3 /**< Logging Level Error     */
#define VL_WARNING         4 /**< Logging Level Data Transfer   */
#define VL_NOTICE          5 /**< Logging Level Notice    */
#define VL_INFO            6 /**< Logging Level info    */
#define VL_DEBUG           7 /**< Logging Level Debugging */
#define VL_EXTRADEBUG      8 /**< Logging Level Extra Verbose Debugging */

#if !defined(LPRINTF_ENABLE)
#	define lprintf(vl, msg, ...) 
#else
#       define lprintf(vl, msg, ...)	\
		do { \
            if ((vl) <= gVerboseLevel)	\
				printf(msg, ##__VA_ARGS__); \
		} while(0)
#endif

#define MB_ERR_PRINT(fmt, ...)  lprintf(VL_ERR, fmt, ##__VA_ARGS__);

#define MB_CHK_RET(ret) \
	{if (ret != MB_OK) {{MB_ERR_PRINT("%s, %s, line=%d, Function Call Failed: ret=%d.\n", \
						__FILE__, __FUNCTION__, __LINE__, ret);}; return ret;}}

#define MB_CHK_PTR(p) \
	{if (!p) {{MB_ERR_PRINT("%s, %s, line=%d, Null Ptr Passed.\n", \
				__FILE__, __FUNCTION__, __LINE__);}; return MB_FAIL;}}

#define MB_CHK_VAL(a, b) \
	{if (a!=b) {{MB_ERR_PRINT("%s, %s, line=%d, Value check failed: a=0x%x, b=0x%x.\n", \
				__FILE__, __FUNCTION__, __LINE__, a, b);}; return MB_FAIL;}}

u32 ReverseE(u32 Data);
void ddr_init_flush_dcache_range(u32 address, u32 size) __attribute__ ((section(".ddr_init"))); 
void vbios_ufc_250MHz_timing(void);
unsigned int ddr_init_flush_dcache_range1(unsigned long start, unsigned long stop) __attribute__ ((section(".ddr_init")));
unsigned int DDRINIT_RANKTLB_NC(unsigned int rankno, unsigned long vadr, unsigned long phyadr) __attribute__ ((section(".ddr_init")));
unsigned int DDRINIT_RANKTLB_C(unsigned int rankno, unsigned long vadr, unsigned long phyadr) __attribute__ ((section(".ddr_init")));
#endif /* __MB_COMMON_H__ */

