#ifndef _MAMBA_SCU_H__
#define _MAMBA_SCU_H__
#include "../include/boot_defines.h"
#include "../include/apm_ipp_csr.h"

#define REG_SCU_PINSTRAP	(VA_CSR_MPA+SCU_PINSTRAP_ADDR)
#define REG_SCU_SOCPLL0 	(VA_CSR_MPA+SCU_SOCPLL0_ADDR)
#define REG_SCU_SOCPLL1 	(VA_CSR_MPA+SCU_SOCPLL1_ADDR)
#define REG_SCU_SOCPLL2 	(VA_CSR_MPA+SCU_SOCPLL2_ADDR)
#define REG_SCU_SOCPLL3 	(VA_CSR_MPA+SCU_SOCPLL3_ADDR)
#define REG_SCU_SOCPLL4 	(VA_CSR_MPA+SCU_SOCPLL4_ADDR)
#define REG_SCU_SOCPLLADJ0 	(VA_CSR_MPA+SCU_SOCPLLADJ0_ADDR)
#define REG_SCU_SOCPLLADJ1 	(VA_CSR_MPA+SCU_SOCPLLADJ1_ADDR)
#define REG_SCU_SOCPLLADJ2 	(VA_CSR_MPA+SCU_SOCPLLADJ2_ADDR)
#define REG_SCU_SOCPLLADJ3 	(VA_CSR_MPA+SCU_SOCPLLADJ3_ADDR)
#define REG_SCU_SOCPLLADJ4 	(VA_CSR_MPA+SCU_SOCPLLADJ4_ADDR)
#define REG_SCU_SOCDIV	 	(VA_CSR_MPA+SCU_SOCDIV_ADDR)
#define REG_SCU_SOCDIV1 	(VA_CSR_MPA+SCU_SOCDIV1_ADDR)
#define REG_SCU_SOCDIV2 	(VA_CSR_MPA+SCU_SOCDIV2_ADDR)
#define REG_SCU_SOCDIV3 	(VA_CSR_MPA+SCU_SOCDIV3_ADDR)
#define REG_SCU_SOCDIV4 	(VA_CSR_MPA+SCU_SOCDIV4_ADDR)
#define BSC_DIS_MASK    0x80000000
#define ROM_TYPE_MASK   0x0000000F
#define ROM_WIDTH_MASK  0x08000000 
#define IO_CLKCFG_MASK  0x03000000
#define CPU_CLKCFG_MASK 0x00700000
#define MPA_IRAM_SIZE_MASK  0x00030000
#define MPA_IROM_1WS_MASK   0x00008000
#define TEST_TPM_ENABLE_MASK  0x00004000

#define VA_MB_GLOBAL_DIAG 0x84060000
#define CFG_MEM_ECC_BYPASS (VA_MB_GLOBAL_DIAG | 0x7068)
#define CFG_MEM_PWRDN_DIS  (VA_MB_GLOBAL_DIAG | 0x706C)
#define CFG_MEM_RAM_SHUTDOWN  (VA_MB_GLOBAL_DIAG | 0x7070)
#define BLOCK_MEM_RDY  (VA_MB_GLOBAL_DIAG | 0x7074)

#ifndef __ASSEMBLY__

/* Reset Control Structure for AM862xx IP block                    */
/* reg_group: indicate whether to use SCU_SRST or SCU_SRST1 reg    */
/* clken_mask: Mask to enable clock in SCU_CLKEN/CLKEN1 reg: 0 skip*/
/* csr_reset_mask: Mask for SCU_CSR_SRST/SRST1 reg: 0 means NO CSR */
/* reset_mask: Mask for SCU_SRST/SRST1 reg: 0 skip                 */
/* mem_rdy_mask: Mask for SCU_MRDY reg: 0 means not MEM_RDY bit    */
/* ram_shutdown_addr: Module's RAM shutdown addr: NULL to skip     */
#define REG_GROUP_SRST_CLKEN		0
#define REG_GROUP_SRST1_CLKEN1		1	
#define MEM_RDY_TIMEOUT_COUNT		10000
struct am862xx_reset_ctrl {
	int		reg_group;
	unsigned int	clken_mask;
	unsigned int	csr_reset_mask;
	unsigned int	reset_mask;
	unsigned int	mem_rdy_mask;
	unsigned int	*ram_shutdown_addr;
};

/* Reset APM 862xx block - User mask pass proper values in reset_ctrl */
/* Example: to reset Ethernet Port1 and Port 2, the values should be */
/* reg_group = REG_GROUP_SRST_CLKEN; */
/* clken_mask = ENET1_F1_MASK | ENET0_F1_MASK; in SCU_CLKEN reg: apm_ipp_csr.h */
/* csr_reset_mask = ENET0_F3_MASK | ENET1_F2_MASK; in SCU_CSR_SRST reg         */
/* reset_mask = ENET0_MASK | ENET1_MASK; in SCU_SRST reg: apm_ipp_csr.h        */
/* mem_rdy_mask = ENET0_F2_MASK; in SCU_MRDY reg: apm_ipp_csr.h                */
/* ram_shutdown_addr = Virt addr of ENET_CFG_MEM_RAM_SHUTDOWN reg:mb_enet_csr.h*/
int reset_am862xx_block(struct am862xx_reset_ctrl *reset_ctrl);
int reset_am862xx_enet(void);

/* Shutdown APM 862xx block - User mask pass proper values in reset_ctrl */
void disable_am862xx_block(struct am862xx_reset_ctrl *reset_ctrl);

struct am862xx_pll_ctrl {
	unsigned short	clkf_val;
	unsigned short	clkod_val;
	unsigned short	clkr_val;
	unsigned short	bwadj_val;
};

/* To reconfigure PLL, user must shutdown PLL and pass new values */
/* If PLL already configured, enable_xxx_pll returns safely       */
/* Safe to call enable_xxx_pll multiple times                     */

/* Enable APM 862xx DDR PLL - User must pass proper PLL values in eth_pll */
int enable_ddr_pll(struct am862xx_pll_ctrl *ddr_pll);
/* Enable APM 862xx Ethernet PLL - User must pass proper PLL values in eth_pll */
int enable_eth_pll(struct am862xx_pll_ctrl *eth_pll);
/* Enable APM 862xx LCD PLL - User must pass proper PLL values in eth_pll */
int enable_lcd_pll(struct am862xx_pll_ctrl *lcd_pll);

/* Shutdown DDR PLL */
void disable_ddr_pll(void);
/* Shutdown Ethernet PLL */
void disable_eth_pll(void);
/* Shutdown LCD PLL */
void disable_lcd_pll(void);
void mb_mem_init_ecc(void);




#endif /* __ASSEMBLY__ */

#endif /* _MAMBA_SCU_H__ */
