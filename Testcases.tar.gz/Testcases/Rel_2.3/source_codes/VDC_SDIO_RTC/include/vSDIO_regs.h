
#ifndef __vSDIO_REG_H__
#define __vSDIO_REG_H__
	#define	CFG_DIAG_SEL 					0xd000
	#define	CFG_READ_BW_LAT_ADDR_MASK 		0xd004
	#define	CFG_READ_BW_LAT_ADDR_PAT 		0xd008
	#define	CFG_WRITE_BW_LAT_ADDR_MASK 		0xd00c
	#define	CFG_WRITE_BW_LAT_ADDR_PAT 		0xd010
	#define	CFG_DIAG_START_STOP 			0xd014
	#define	CFG_BW_MSTR_STOP_CNT 			0xd018
	#define	CFG_BW_SLV_STOP_CNT 			0xd01c
	#define	CFG_DBG_TRIG_CTRL 				0xd044
	#define	CFG_DBG_PAT_REG_0 				0xd048
	#define	CFG_DBG_PAT_MASK_REG_0 			0xd04c
	#define	CFG_DBG_PAT_REG_1 				0xd050
	#define	CFG_DBG_PAT_MASK_REG_1 			0xd054
	#define	CFG_MEM_ECC_BYPASS 				0xd068
	#define	CFG_MEM_PWRDN_DIS 				0xd06c
	#define	CFG_MEM_RAM_SHUTDOWN 			0xd070
	#define	CFG_LT_MSTR_STOP_CNT 			0xd090

	#define	DBG_TRIG_INT 					0xd05c

	#define	DBG_TRIG_INTMask				0xd060

	#define	STS_READ_LATENCY_OUTPUT 		0xd020
	#define	STS_AXI_MRD_BW_CLK_CNT 			0xd024
	#define	STS_AXI_MRD_BW_BYTE_CNT 		0xd028
	#define	STS_AXI_MWR_BW_CLK_CNT 			0xd02c
	#define	STS_AXI_MWR_BW_BYTE_CNT 		0xd030
	#define	STS_AXI_SRD_BW_CLK_CNT 			0xd034
	#define	STS_AXI_SRD_BW_BYTE_CNT 		0xd038
	#define	STS_AXI_SWR_BW_CLK_CNT 			0xd03c
	#define	STS_AXI_SWR_BW_BYTE_CNT 		0xd040

#endif /*__vSDIO_REG_H__*/
