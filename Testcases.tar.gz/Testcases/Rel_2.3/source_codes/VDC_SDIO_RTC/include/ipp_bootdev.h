/*=============================================================================
**
** Copyright (C) 2009 AppliedMicro Confidential Information
**
** All Rights Reserved.
**
** THIS WORK CONTAINS PROPRIETARY INFORMATION WHICH IS THE PROPERTY OF
** AppliedMicro AND IS SUBJECT TO THE TERMS OF NON-DISCLOSURE AGREEMENT
** BETWEEN AppliedMicro AND THE COMPANY USING THIS FILE.
**
** File: ipp_bootdev.h
** Version: 1.0
** Authors: Anup Patel (apatel@amcc.com)
** Description: header file for boot device interface
*/
#ifndef _IPP_BOOTDEV_H__
#define _IPP_BOOTDEV_H__

#include "../include/ipp.h"

typedef struct ipp_bootdev ipp_bootdev_t;

typedef u32(*ipp_init_device_t)(ipp_bootdev_t *bdev);
typedef u32(*ipp_read_device_t)(ipp_bootdev_t *bdev,u8 *dest,u32 offset,u32 len);

struct ipp_bootdev {
	u32 device_id;
	u32 runtime_offset;
	u32 hotswap_offset;
	u32 ppcimg_offset;
	ipp_init_device_t init_device;
	ipp_read_device_t read_device;
};

#define IPP_BOOTDEV_NULL(bdev) (bdev)->device_id = 0; \
			       (bdev)->runtime_offset = 0; \
			       (bdev)->hotswap_offset = 0; \
			       (bdev)->ppcimg_offset = 0; \
			       (bdev)->init_device = NULL; \
			       (bdev)->read_device = NULL;

ipp_bootdev_t * armboot_device(u32 device_id,ipp_bootdev_t *bdev);
ipp_bootdev_t * ppcboot_device(u32 device_id,ipp_bootdev_t *bdev);

#endif

