/*
 * Copyright (C) 2013 AppliedMicro Confidential Information
 * All Rights Reserved.
 *
 * THIS WORK CONTAINS PROPRIETARY INFORMATION WHICH IS THE PROPERTY OF
 * AppliedMicro AND IS SUBJECT TO THE TERMS OF NON-DISCLOSURE AGREEMENT
 * BETWEEN AppliedMicro AND THE COMPANY USING THIS FILE.
 *
 * WARNING !!!
 * This is an auto-generated C header file for register definitions
 * PLEASE DON'T MANUALLY MODIFY IN THIS FILE AS CHANGES WILL BE LOST
 *
 * rtc_reg.h
 *
 *  Created on: Mar 07, 2013
 *      Author: kqngo@apm.com
 */

#ifndef RTC_REG_H_
#define RTC_REG_H_

/*	Global Base Address	*/
//#define RTC_BASE__ADDR		0x50010000	// SM_RTC_I_BASE_ADDR for Storm Slim
//#define SCU_BASE__ADDR		0x50000000
#define RTC_BASE__ADDR	        0x10510000	// SM_RTC_SYS_BASE_ADDR for Storm cpu
#define SCU_BASE__ADDR		    0x17000000
//#define SM_RTC_SYS_BASE_ADDR	0xE0210000	// for Black Mamba

/* Registers for RTC Clock RESET & ENABLE */
#define SCU_CLKEN__ADDR			0x00000010
#define SCU_SRST__ADDR			0x0000000C

/* Addresses of RTC Configuration Registers */
#define RTC_CMR__ADDR			0x00000004
#define RTC_CMR_DEFAULT			0x00000000
#define RTC_CLR__ADDR			0x00000008
#define RTC_CLR_DEFAULT			0x00000000
#define RTC_CCR__ADDR			0x0000000C
#define RTC_CCR_DEFAULT			0x00000000

/* Addresses of RTC Status (Read Only) Registers */
#define RTC_CCVR__ADDR			0x00000000
#define RTC_CCVR_DEFAULT		0x00000000		// change every second
#define RTC_STAT__ADDR			0x00000010
#define RTC_STAT_DEFAULT		0x00000000
#define RTC_RSTAT__ADDR			0x00000014
#define RTC_RSTAT_DEFAULT		0x00000000
#define RTC_EOI__ADDR			0x00000018
#define RTC_EOI_DEFAULT			0x00000000
#define RTC_COMP_VER__ADDR		0x0000001C
#define RTC_COMP_VER_DEFAULT	0x3230322A

#endif /* RTC_REG_H_ */
