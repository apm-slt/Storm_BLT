/*=============================================================================
**
** Copyright (C) 2009 AppliedMicro Confidential Information
**
** All Rights Reserved.
**
** THIS WORK CONTAINS PROPRIETARY INFORMATION WHICH IS THE PROPERTY OF
** AppliedMicro AND IS SUBJECT TO THE TERMS OF NON-DISCLOSURE AGREEMENT
** BETWEEN AppliedMicro AND THE COMPANY USING THIS FILE.
**
** File: ipp_vfatdev.h
** Version: 1.0
** Authors: Anup Patel (apatel@amcc.com)
** Description: header file for VFAT device driver (hypothetical device)
*/
#ifndef _IPP_VFATDEV_H_
#define _IPP_VFATDEV_H_
#include "../include/ipp_libc.h"
#include "../include/ipp_bootdev.h"
#include "../include/ipp_hardware.h"
/* Macros for configuring VFAT code */

//mmd
//#define IPP_VFAT_OLD16
//mmd

#define IPP_VFAT_SAVESPACE 
#define IPP_VFAT_PPCIMG_FILENAME "PPCIMG"
#define IPP_VFAT_DEVDATA_OFFSET 0
#ifdef IPP_VFAT_OLD12
#ifndef IPP_VFAT_OLD
#define IPP_VFAT_OLD
#endif
#endif
#ifdef IPP_VFAT_OLD16
#ifndef IPP_VFAT_OLD
#define IPP_VFAT_OLD
#endif
#endif

/* Important offsets */
#define IPP_VFAT_PARTITION_TABLE_OFFSET		0x1BE
#define IPP_VFAT_PARTITION_ENTRY_SIZE		16
#define IPP_VFAT_BOOTSECTOR_OFFSET		0x000

/* Enumeration of possible values for Media Type field in boot sector */
enum ipp_vfat_media_types {
	IPP_VFAT_DOUBLE_SIDED_1_44_MB=0xF0,
	IPP_VFAT_FIXED_DISK=0xF8,
	IPP_VFAT_DOUBLE_SIDED_720_KB=0xF9,
	IPP_VFAT_SINGLE_SIDED_320_KB=0xFA,
	IPP_VFAT_DOUBLE_SIDED_640_KB=0xFB,
	IPP_VFAT_SINGLE_SIDED_180_KB=0xFC,
	IPP_VFAT_DOUBLE_SIDED_360_KB=0xFD,
	IPP_VFAT_SINGLE_SIDED_160_KB=0xFE,
	IPP_VFAT_DOUBLE_SIDED_320_KB=0xFF
};

/* Enumeration of FAT types supported in VFAT */
enum ipp_vfat_types {
	IPP_VFAT_FAT12=12,
	IPP_VFAT_FAT16=16,
	IPP_VFAT_FAT32=32
};

/* Enumeration of types of cluster in FAT12 table */
enum ipp_vfat_fat12_cluster_types {
	IPP_VFAT_FREE_CLUSTER12=0x000,
	IPP_VFAT_RESERVED1_CLUSTER12=0x001,
	IPP_VFAT_RESERVED2_CLUSTER12=0xFF0,
	IPP_VFAT_BAD_CLUSTER12=0xFF7,
	IPP_VFAT_LAST_CLUSTER12=0xFF8
};

/* Enumeration of types of cluster in FAT16 table */
enum ipp_vfat_fat16_cluster_types {
	IPP_VFAT_FREE_CLUSTER16=0x0000,
	IPP_VFAT_RESERVED1_CLUSTER16=0x0001,
	IPP_VFAT_RESERVED2_CLUSTER16=0xFFF0,
	IPP_VFAT_BAD_CLUSTER16=0xFFF7,
	IPP_VFAT_LAST_CLUSTER16=0xFFF8
};

/* Enumeration of types of cluster in FAT32 table */
enum ipp_vfat_fat32_cluster_types {
	IPP_VFAT_FREE_CLUSTER32=0x00000000,
	IPP_VFAT_RESERVED1_CLUSTER32=0x00000001,
	IPP_VFAT_RESERVED2_CLUSTER32=0x0FFFFFF0,
	IPP_VFAT_BAD_CLUSTER32=0x0FFFFFF7,
	IPP_VFAT_LAST_CLUSTER32=0x0FFFFFF8
};

/* Enumeration of partition status */
enum ipp_vfat_partition_status {
	IPP_VFAT_PARTITON_NONBOOTABLE=0x00,
	IPP_VFAT_PARTITION_BOOTABLE=0x80
};

/* Enumeration of partition status */
enum ipp_vfat_partition_types {
	IPP_VFAT_PARTITION_EMPTY=0x00,
	IPP_VFAT_PARTITION_FAT12=0x01,
	IPP_VFAT_PARTITION_XENIX_ROOT=0x02,
	IPP_VFAT_PARTITION_XENIX_USR=0x03,
	IPP_VFAT_PARTITION_FAT16_32M=0x04,
	IPP_VFAT_PARTITION_EXTENDED=0x05,
	IPP_VFAT_PARTITION_FAT16=0x06,
	IPP_VFAT_PARTITION_NTFS=0x07,
	IPP_VFAT_PARTITION_AIX=0x08,
	IPP_VFAT_PARTITION_AIX_BOOTABLE=0x09,
	IPP_VFAT_PARTITION_OS2_BOOT_MANAGER=0x0A,
	IPP_VFAT_PARTITION_FAT32=0x0B,
	IPP_VFAT_PARTITION_FAT32_LBA=0x0C,
	IPP_VFAT_PARTITION_FAT16_LBA=0x0E,
	IPP_VFAT_PARTITION_FAT16_EXTENDED=0x0F,
	IPP_VFAT_PARTITION_OPUS=0x10,
	IPP_VFAT_PARTITION_FAT12_HIDDEN=0x11,
	IPP_VFAT_PARTITION_COMPAQ_DIAG=0x12,
	IPP_VFAT_PARTITION_FAT16_HIDDEN=0x14,
	IPP_VFAT_PARTITION_LINUX_SWAP=0x82,
	IPP_VFAT_PARTITION_LINUX_NATIVE=0x83,
	IPP_VFAT_PARTITION_RAW=0xDA,
	IPP_VFAT_PARTITION_BOOTIT=0xDF,
	IPP_VFAT_PARTITION_VMFS=0xFB,
	IPP_VFAT_PARTITION_VMKCORE=0xFC
};

/* Enumeration of directory entry attributes */
enum ipp_vfat_dirent_attributes {
	IPP_VFAT_DIRENT_READONLY=0x01,
	IPP_VFAT_DIRENT_HIDDEN=0x02,
	IPP_VFAT_DIRENT_SYSTEM=0x04,
	IPP_VFAT_DIRENT_VOLLABLE=0x08,
	IPP_VFAT_DIRENT_SUBDIR=0x10,
	IPP_VFAT_DIRENT_ARCHIVE=0x20,
	IPP_VFAT_DIRENT_DEVICE=0x40,
	IPP_VFAT_DIRENT_UNUSED=0x80
};

/* Extended boot sector information for FAT12/FAT16 */
typedef struct {
	u8 drive_number;
	u8 reserved;
	u8 extended_signature;
	u32 serial_number;
	u8 volume_label[11];
	u8 fs_type[8];
#ifndef IPP_VFAT_SAVESPACE
	u8 boot_code[448];
	u16 boot_sector_signature;
#endif
} __attribute__((packed)) ipp_vfat_ext_bsector16_t;

/* Extended boot sector information for FAT32 */
typedef struct {
	u32 sectors_per_fat;
	u16 fat_flags;
	u16 version;
	u32 root_directory_cluster;
	u16 fs_info_sector;
	u16 boot_sector_copy;
	u8 reserved1[12];
	u8 drive_number;
	u8 reserved2;
	u8 extended_signature;
	u32 serial_number;
	u8 volume_label[11];
	u8 fs_type[8];
#ifndef IPP_VFAT_SAVESPACE
	u8 boot_code[420];
	u16 boot_sector_signature;
#endif
} __attribute__((packed)) ipp_vfat_ext_bsector32_t;

/* Boot sector information for FAT12/FAT16/FAT32 */
typedef struct {
	u8 jump[3];
	u8 oem_name[8];
	u16 bytes_per_sector;
	u8 sectors_per_cluster;
	u16 reserved_sector_count;
	u8 number_of_fat;
	u16 max_directory_entry;
	u16 total_sectors_16;
	u8 media_type;
	u16 sectors_per_fat;
	u16 sectors_per_track;
	u16 number_of_heads;
	u32 hidden_sector_count;
	u32 total_sectors_32;
#ifdef IPP_VFAT_OLD
	ipp_vfat_ext_bsector16_t ext;
#else
	ipp_vfat_ext_bsector32_t ext;
#endif
} __attribute__((packed)) ipp_vfat_bsector_t;

/* Partition table entry */
typedef struct {
	u8 status;
	u8 chs_first[3];
	u8 type;
	u8 chs_last[3];
	u32 lba_start;
	u32 sector_count;
} __attribute__ ((packed)) ipp_vfat_partition_t;

/* Directory entry information for FAT12/FAT16/FAT32 */
typedef struct {
	u8 dos_file_name[8];
	u8 dos_extension[3];
	u8 file_attributes;
	u8 reserved;
	u8 create_time_millisecs;
	u32 create_time_seconds:5;
	u32 create_time_minutes:6;
	u32 create_time_hours:5;
	u32 create_date_day:5;
	u32 create_date_month:4;
	u32 create_date_year:7;
	u32 laccess_date_day:5;
	u32 laccess_date_month:4;
	u32 laccess_date_year:7;
#ifdef IPP_VFAT_OLD
	u16 ea_index;
#else
	u16 first_cluster_hi;
#endif
	u32 lmodify_time_seconds:5;
	u32 lmodify_time_minutes:6;
	u32 lmodify_time_hours:5;
	u32 lmodify_date_day:5;
	u32 lmodify_date_month:4;
	u32 lmodify_date_year:7;
#ifdef IPP_VFAT_OLD
	u16 first_cluster;
#else
	u16 first_cluster_lo;
#endif
	u32 file_size;
} __attribute__((packed)) ipp_vfat_dirent_t;

typedef u32(*ipp_init_vfatdev_t)(u32 *block_size);
typedef u32(*ipp_read_vfatdev_t)(u8 *dest,u32 lba,u32 blkoff,u32 len);

/* IPP specific VFAT information required for reading PPC image */
typedef struct {
	ipp_read_vfatdev_t read_vfat_device;
	u32 start_block;
	u32 fat_type;
	u32 bytes_per_block;
	u32 blocks_per_cluster;
	u32 sector_to_block_ratio;
	u32 first_fat_block;
	u32 blocks_per_fat;
	u32 blocks_to_jump;
	u32 first_ppcimage_cluster;
} __attribute__((packed)) ipp_vfat_info_t;

#define IPP_BOOTDEV_VFAT(bdev) (bdev)->device_id = IPP_PPCBOOTDEV_VFAT; \
			       (bdev)->runtime_offset = 0; \
			       (bdev)->hotswap_offset = 0; \
			       (bdev)->ppcimg_offset = 0; \
			       (bdev)->init_device = init_vfatdev; \
			       (bdev)->read_device = read_vfatdev;

u32 read_vfatdev(ipp_bootdev_t *bdev,u8 *dest,u32 offset,u32 len);
u32 init_vfatdev(ipp_bootdev_t *bdev);

#endif

