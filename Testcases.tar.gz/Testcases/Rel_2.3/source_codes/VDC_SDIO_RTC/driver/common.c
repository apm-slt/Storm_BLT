/* Author: automation@apm.com
*  Company: Applied Micro Circuits Corporation (AMCC)
*
* Describe the purpose of your Test here
*   - Include all common functions here
*/
#include "../include/common.h"
void printPASSSDIO(void) {
	printf("\n\n");
	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
	printf ("$$$$ RESULT: TEST PASS $$$$\n");
	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
	printf("\n\n");
}

void printFAILSDIO(void) {
	printf("\n\n");
	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
	printf ("$$$$ RESULT: TEST FAILED $$$$\n"); 
	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
	printf("\n\n");
}

