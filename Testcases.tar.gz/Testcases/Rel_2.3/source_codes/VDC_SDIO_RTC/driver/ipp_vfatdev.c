/*=============================================================================
**
** Copyright (C) 2009 AppliedMicro Confidential Information
**
** All Rights Reserved.
**
** THIS WORK CONTAINS PROPRIETARY INFORMATION WHICH IS THE PROPERTY OF
** AppliedMicro AND IS SUBJECT TO THE TERMS OF NON-DISCLOSURE AGREEMENT
** BETWEEN AppliedMicro AND THE COMPANY USING THIS FILE.
**
** File: ipp_vfatdev.c
** Version: 1.0
** Authors: Anup Patel (apatel@amcc.com)
** Description: source file for VFAT device driver (hypothetical device)
*/

#include "../include/ipp_libc.h"
#include "../include/ipp_hardware.h"
//#include "sdio/sdio_enum/ipp_vfatdev_usb.h"
#include "../include/ipp_vfatdev_sdio.h"
#include "../include/ipp_vfatdev.h"

ipp_vfat_info_t vinfo;

u32 next_cluster(u32 current_cluster)
{
	u32 fat_block,fat_offset,fat_entry;
	u8 fat_entry_b[4];

	/* Read FAT table entry for current cluster */
#ifdef IPP_VFAT_OLD12
	fat_offset = (current_cluster%2==0) ? current_cluster * 12 / 8 : (current_cluster - 1) * 12 / 8 + 1;
	fat_block = vinfo.start_block + vinfo.first_fat_block + fat_offset / vinfo.bytes_per_block;
	fat_offset = fat_offset % vinfo.bytes_per_block;
	vinfo.read_vfat_device((u8*)fat_entry_b,fat_block,fat_offset,2);
	fat_entry = ((u32)fat_entry_b[1] << 8) | (u32)fat_entry_b[0]; 
	if(current_cluster%2==0) { 
		fat_entry &= 0xFFF;
	} else { 
		fat_entry >>= 4;
	}
#else
#ifdef IPP_VFAT_OLD16
	fat_offset = current_cluster * 2;
	fat_block = vinfo.start_block + vinfo.first_fat_block + fat_offset / vinfo.bytes_per_block;
	fat_offset = fat_offset % vinfo.bytes_per_block;
	vinfo.read_vfat_device((u8*)&fat_entry_b,fat_block,fat_offset,2);
	fat_entry = ((u32)fat_entry_b[1] << 8) | (u32)fat_entry_b[0]; 
#else
	fat_offset = current_cluster * 4;
	fat_block = vinfo.start_block + vinfo.first_fat_block + fat_offset / vinfo.bytes_per_block;
	fat_offset = fat_offset % vinfo.bytes_per_block;
	vinfo.read_vfat_device((u8*)&fat_entry_b,fat_block,fat_offset,4);
	fat_entry = ((u32)fat_entry_b[3] << 24) |((u32)fat_entry_b[2] << 16) | ((u32)fat_entry_b[1] << 8) | (u32)fat_entry_b[0]; 
#endif
#endif

	/* Return FAT table entry */
	return fat_entry;
}

u32 read_vfatdev(ipp_bootdev_t *bdev,u8 *dest,u32 offset,u32 len)
{
	u32 ite,count,bytes_left,bytes_per_cluster,bytes_to_read;
	u32 file_offset,file_block,file_cluster;
	
    printf("read_vfatdev -> in\n");
	/* Forward read request to physical device if we are not reading PPC image */
	if(offset<bdev->ppcimg_offset) {
		return 0;
	}

	/* Precompute information required in reading file from VFAT */
	bytes_left = len;
	bytes_per_cluster = vinfo.bytes_per_block * vinfo.blocks_per_cluster;
	file_offset = offset - bdev->ppcimg_offset;
	file_cluster = vinfo.first_ppcimage_cluster;

	/* Traverse FAT table to reach first file cluster to read */
	count = file_offset / bytes_per_cluster;
	for(ite=0;ite<count;ite++) {
		/* Retrive next cluster number */
		file_cluster = next_cluster(file_cluster);
		/* If we have no more cluster for this file then return error */
#ifdef IPP_VFAT_OLD12
		if(file_cluster<=IPP_VFAT_RESERVED1_CLUSTER12 || IPP_VFAT_RESERVED2_CLUSTER12<=file_cluster) {
#else
#ifdef IPP_VFAT_OLD16
		if(file_cluster<=IPP_VFAT_RESERVED1_CLUSTER16 || IPP_VFAT_RESERVED2_CLUSTER16<=file_cluster) {
#else
		if(file_cluster<=IPP_VFAT_RESERVED1_CLUSTER32 || IPP_VFAT_RESERVED2_CLUSTER32<=file_cluster) {
#endif
#endif
			for(ite=0;ite<bytes_left;ite++) dest[ite] = 0;
			return 0;
		}
	}

	/* Start reading from first file cluster determined by previous step */
	while(bytes_left>0) {
		/* Compute count of blocks to read from current file cluster */
		count = bytes_left / bytes_per_cluster;
		count = (count==0) ? bytes_left / vinfo.bytes_per_block : vinfo.blocks_per_cluster;
		count = (count==0) ? 1 : count;
		/* Compute file block number */
		file_block = vinfo.start_block + vinfo.blocks_to_jump + (file_cluster - 2) * vinfo.blocks_per_cluster;
		/* Read blocks from current cluster */
		for(ite=0;ite<count;ite++) {
			/* Determine bytes to read from sector <ite> of current file cluster */			
			bytes_to_read = (bytes_left<vinfo.bytes_per_block) ? bytes_left : vinfo.bytes_per_block;
			/* Read sector <ite> in current file cluster */
			vinfo.read_vfat_device(dest,file_block + ite,file_offset % vinfo.bytes_per_block,bytes_to_read);
			/* Update <dest> and <bytes_left> based on bytes read */
			file_offset += bytes_to_read;
			dest += bytes_to_read;
			bytes_left -= bytes_to_read;
		}
		/* If there is no more bytes left to read then break out of loop */
		if(bytes_left<=0) break;
		/* Retrive next file cluster */
		file_cluster = next_cluster(file_cluster);
		/* If we have no more cluster for this file then return error */
#ifdef IPP_VFAT_OLD12
		if(file_cluster<=IPP_VFAT_RESERVED1_CLUSTER12 || IPP_VFAT_RESERVED2_CLUSTER12<=file_cluster) {
#else
#ifdef IPP_VFAT_OLD16
		if(file_cluster<=IPP_VFAT_RESERVED1_CLUSTER16 || IPP_VFAT_RESERVED2_CLUSTER16<=file_cluster) {
#else
		if(file_cluster<=IPP_VFAT_RESERVED1_CLUSTER32 || IPP_VFAT_RESERVED2_CLUSTER32<=file_cluster) {
#endif
#endif
			for(ite=0;ite<bytes_left;ite++) dest[ite] = 0;
			return len - bytes_left;
		}
	}

    printf("read_vfatdev <- out\n");
	/* Return bytes read */
	return len;
}

u32 init_vfatdev(ipp_bootdev_t *bdev)
{
	u32 ite1,ite2,current,root_dir_sc,root_block_count;
	ipp_vfat_partition_t partition;
	ipp_vfat_bsector_t bsect;
	ipp_vfat_dirent_t dirent;
	ipp_init_vfatdev_t init_vfat_device;

    printf("init_vfatdev -> in\n");

	/* Retrive physical device information required to access VFAT */
	if(bdev->device_id==IPP_PPCBOOTDEV_USB) {
//mmd		init_vfat_device = init_vfatdev_usb;
//mmd		vinfo.read_vfat_device = read_vfatdev_usb;
	} else if(bdev->device_id==IPP_PPCBOOTDEV_SDIO) {
		init_vfat_device = init_vfatdev_sdio;
		vinfo.read_vfat_device = read_vfatdev_sdio;
	} else {
		return IPP_ERR_FAIL;
	}

	/* Initialize physical device */
	if(init_vfat_device(&current)!=IPP_OK) {
        printf("Error in Init device\n");
        return IPP_ERR_FAIL;
    }

	/* Copy the block size returned by physical device */
	vinfo.bytes_per_block = current;
    printf("vinfo.bytes_per_block:0x%x\n",vinfo.bytes_per_block);

	/* Determine the starting block of filesystem */
	vinfo.start_block = 0;
	for(ite1=0;ite1<4;ite1++) {
		current = IPP_VFAT_PARTITION_TABLE_OFFSET + ite1*IPP_VFAT_PARTITION_ENTRY_SIZE;
        printf("current: 0x%x\n",current);

        printf("\nREAD Starting Block From Device\n");
		vinfo.read_vfat_device((u8*)&partition, current/vinfo.bytes_per_block, current%vinfo.bytes_per_block, sizeof(ipp_vfat_partition_t));
#ifdef IPP_VFAT_OLD12
		if(partition.type==IPP_VFAT_PARTITION_FAT12) {
#else
#ifdef IPP_VFAT_OLD16
		if(partition.type==IPP_VFAT_PARTITION_FAT16) {
#else
		if(partition.type==IPP_VFAT_PARTITION_FAT32) {
#endif
#endif
			vinfo.start_block = LE32_TO_CPU(partition.lba_start);
//mmd			vinfo.start_block = partition.lba_start;
			break;
		}
	}

    printf("\nREAD Boot Sector From Device\n");
	/* Read device to retrive boot sector information */
    
//    printf("bsect:0x%08x vinfo.start_block:0x%08x IPP_VFAT_BOOTSECTOR_OFFSET:0x%08x sizeof(ipp_vfat_bsector_t):0x%x\n",bsect,vinfo.start_block,(unsigned int)IPP_VFAT_BOOTSECTOR_OFFSET,sizeof(ipp_vfat_bsector_t));

	vinfo.read_vfat_device((u8*)&bsect,vinfo.start_block,IPP_VFAT_BOOTSECTOR_OFFSET,sizeof(ipp_vfat_bsector_t));
    
    //printf("bsect:0x%08x vinfo.start_block:0x%08x IPP_VFAT_BOOTSECTOR_OFFSET:0x%08x sizeof(ipp_vfat_bsector_t):0x%x\n",bsect,vinfo.start_block,(unsigned int)IPP_VFAT_BOOTSECTOR_OFFSET,sizeof(ipp_vfat_bsector_t));

	/* Compute type of FAT from boot sector */
	vinfo.fat_type = 10 * (bsect.ext.fs_type[3] - '0') + (bsect.ext.fs_type[4] - '0');
    printf("vinfo.fat_type:0x%x IPP_VFAT_FAT32:0x%x\n",vinfo.fat_type,(unsigned int)IPP_VFAT_FAT32); 


#ifdef IPP_VFAT_OLD12
	if(vinfo.fat_type!=IPP_VFAT_FAT12) {
#else
#ifdef IPP_VFAT_OLD16
	if(vinfo.fat_type!=IPP_VFAT_FAT16) {
#else
	if(vinfo.fat_type!=IPP_VFAT_FAT32) {
#endif
#endif
        printf("Error vinfo.fat_type:0x%x IPP_VFAT_FAT32:0x%x\n",vinfo.fat_type,(unsigned int)IPP_VFAT_FAT32); // yes
		return IPP_ERR_FAIL;
	}

	/* Compute sector to block ratio */
	vinfo.sector_to_block_ratio = LE16_TO_CPU(bsect.bytes_per_sector) / vinfo.bytes_per_block;
//mmd	vinfo.sector_to_block_ratio = bsect.bytes_per_sector / vinfo.bytes_per_block;

    printf("vinfo.sector_to_block_ratio:0x%x\n",vinfo.sector_to_block_ratio); 

	/* Compute sectors per cluster from boot sector */
	vinfo.blocks_per_cluster = bsect.sectors_per_cluster * vinfo.sector_to_block_ratio;
    printf("vinfo.blocks_per_cluster:0x%x\n",vinfo.blocks_per_cluster); 

	/* Compute first FAT table sector from boot sector */
	vinfo.first_fat_block = LE16_TO_CPU(bsect.reserved_sector_count) * vinfo.sector_to_block_ratio;
//mmd	vinfo.first_fat_block = bsect.reserved_sector_count * vinfo.sector_to_block_ratio;

    printf("vinfo.first_fat_block:0x%x\n",vinfo.first_fat_block); 

	/* Compute sectors per FAT table from boot sector */
#ifdef IPP_VFAT_OLD
	vinfo.blocks_per_fat = LE16_TO_CPU(bsect.sectors_per_fat) * vinfo.sector_to_block_ratio;
//mmd	vinfo.blocks_per_fat = bsect.sectors_per_fat * vinfo.sector_to_block_ratio;
#else
	vinfo.blocks_per_fat = LE32_TO_CPU(bsect.ext.sectors_per_fat) * vinfo.sector_to_block_ratio;
//mmd	vinfo.blocks_per_fat = bsect.ext.sectors_per_fat * vinfo.sector_to_block_ratio;
#endif
    printf("vinfo.blocks_per_fat:0x%x\n",vinfo.blocks_per_fat); 

	/* Compute sectors to jump for accessing VFAT data region */
#ifdef IPP_VFAT_OLD
	root_dir_sc = LE16_TO_CPU(bsect.reserved_sector_count) + bsect.number_of_fat * LE16_TO_CPU(bsect.sectors_per_fat);
//mmd	root_dir_sc = bsect.reserved_sector_count + bsect.number_of_fat * bsect.sectors_per_fat;

	root_block_count = (LE16_TO_CPU(bsect.max_directory_entry) * sizeof(ipp_vfat_dirent_t)) / vinfo.bytes_per_block;
//mmd	root_block_count = (bsect.max_directory_entry * sizeof(ipp_vfat_dirent_t)) / vinfo.bytes_per_block;

	vinfo.blocks_to_jump = root_dir_sc * vinfo.sector_to_block_ratio + root_block_count;
#else
	root_dir_sc = LE32_TO_CPU(bsect.ext.root_directory_cluster);
//mmd	root_dir_sc = bsect.ext.root_directory_cluster;

	root_block_count = vinfo.blocks_per_cluster;

	vinfo.blocks_to_jump = (LE16_TO_CPU(bsect.reserved_sector_count) + bsect.number_of_fat * LE32_TO_CPU(bsect.ext.sectors_per_fat)) * vinfo.sector_to_block_ratio;
//mmd	vinfo.blocks_to_jump = (bsect.reserved_sector_count) + bsect.number_of_fat * bsect.ext.sectors_per_fat * vinfo.sector_to_block_ratio;

#endif
    printf("\nvinfo.start_block:0x%x\n",vinfo.start_block); 
    printf("root_dir_sc:0x%x\n",root_dir_sc); 
    printf("root_block_count:0x%x\n",root_block_count); 
    printf("vinfo.blocks_to_jump:0x%x\n",vinfo.blocks_to_jump); 

	/* Find the first cluster number of PPC image in ROOT directory */
#ifdef IPP_VFAT_OLD
	vinfo.first_ppcimage_cluster = 0;
	/* Iterate for each sector of root directory */
	for(ite1=0;ite1<root_block_count;ite1++) {
		/* Precompute the start block of the current root directory sector in physical device */
		current = vinfo.start_block + root_dir_sc * vinfo.sector_to_block_ratio + ite1;
		/* Iterate for each directory entry in the current sector of root directory */
		for(ite2=0;ite2<(vinfo.bytes_per_block/sizeof(ipp_vfat_dirent_t));ite2++) {
			/* Read current directory entry */
			vinfo.read_vfat_device((u8*)&dirent,current,ite2*sizeof(ipp_vfat_dirent_t),sizeof(ipp_vfat_dirent_t));
			/* Skip to next entry if current directory entry is not a file */
			if(dirent.file_attributes & (IPP_VFAT_DIRENT_VOLLABLE | IPP_VFAT_DIRENT_SUBDIR)) continue;
			if(dirent.dos_file_name[0]!=0x0 && dirent.dos_file_name[0]!=0xE5) {
				/* Compare the DOS name of the directory entry with image name we are looking for */
				if(ipp_memcmp(dirent.dos_file_name,IPP_VFAT_PPCIMG_FILENAME,6)==0) {
					vinfo.first_ppcimage_cluster = dirent.first_cluster;
					break;
				}
			}
		}
		/* Break the loop if we have found the first cluster of image file */
		if(vinfo.first_ppcimage_cluster>0) break;
	}
#else
	vinfo.first_ppcimage_cluster = 0;
	while(1) {
		/* Iterate for each sector of current root directory cluster */
		for(ite1=0;ite1<root_block_count;ite1++) {
			/* Precompute the start block of the current root directory sector in physical device */
			current = vinfo.start_block + vinfo.blocks_to_jump + (root_dir_sc-2) * vinfo.blocks_per_cluster + ite1;
            
            printf("current:0x%x\n",current);
            printf("root_block_count:0x%x\n",root_block_count);

			/* Iterate for each directory entry in the current sector of root directory */
			for(ite2=0;ite2<(vinfo.bytes_per_block/sizeof(ipp_vfat_dirent_t));ite2++) {
                printf("vinfo.bytes_per_block:0x%x\n",vinfo.bytes_per_block);
                printf("sizeof(ipp_vfat_dirent_t):0x%x\n",sizeof(ipp_vfat_dirent_t));
                printf("ite2:%d\n",ite2); //yes
				/* Read current directory entry */
				vinfo.read_vfat_device((u8*)&dirent,current,ite2*sizeof(ipp_vfat_dirent_t),sizeof(ipp_vfat_dirent_t));
				/* Skip to next entry if current directory entry is not a file */
				if(dirent.file_attributes & (IPP_VFAT_DIRENT_VOLLABLE | IPP_VFAT_DIRENT_SUBDIR)) {
                    printf("1\n"); 
                    continue;
                }
                printf("dirent.dos_file_name[0]:0x%08x\n",dirent.dos_file_name[0]);
				if(dirent.dos_file_name[0]!=0x0 && dirent.dos_file_name[0]!=0xE5) {
					/* Compare the DOS name of the directory entry with image name we are looking for */
                    dirent.dos_file_name[7] = '\0';
                    printf("dirent.dos_file_name:%s IPP_VFAT_PPCIMG_FILENAME:%s\n",dirent.dos_file_name,IPP_VFAT_PPCIMG_FILENAME);
					if(ipp_memcmp(dirent.dos_file_name,IPP_VFAT_PPCIMG_FILENAME,6)==0) {
                        printf("3\n"); //no
                        printf("vinfo.first_ppcimage_cluster: 0x%x\n",vinfo.first_ppcimage_cluster);
						vinfo.first_ppcimage_cluster = ((u32)LE16_TO_CPU(dirent.first_cluster_hi) << 16) | ((u32)LE16_TO_CPU(dirent.first_cluster_lo));
//mmd						vinfo.first_ppcimage_cluster = ((u32)(dirent.first_cluster_hi)) << 16 | ((u32)(dirent.first_cluster_lo));
						break;
					}
				}
			}
			/* Break the loop if we have found the first cluster of image file */
			if(vinfo.first_ppcimage_cluster>0) break;
		}
		/* Break the loop if we have found the first cluster of image file */
		if(vinfo.first_ppcimage_cluster>0) break;
		/* Retrive next root directory cluster */
		root_dir_sc = next_cluster(root_dir_sc);
		/* If we have no more root directory cluster then return error */
		if(root_dir_sc<=IPP_VFAT_RESERVED1_CLUSTER32 || IPP_VFAT_RESERVED2_CLUSTER32<=root_dir_sc) {
            printf("\nError root_dir_sc:%d\n",root_dir_sc); // yes
            printf("IPP_VFAT_RESERVED1_CLUSTER32:0x%08x\n",(unsigned int)IPP_VFAT_RESERVED1_CLUSTER32); // yes
            printf("IPP_VFAT_RESERVED2_CLUSTER32:0x%08x\n",(unsigned int)IPP_VFAT_RESERVED2_CLUSTER32); // yes
//mmd			return IPP_ERR_FAIL; //yes
            break;
		}
	}
#endif
	/* Return erro if we did not find first cluster of image file */
	if(vinfo.first_ppcimage_cluster==0) {
        printf("\nError vinfo.first_ppcimage_cluster:%d\n",vinfo.first_ppcimage_cluster); // yes
//		vinfo.first_ppcimage_cluster = 0x197500; 
//mmd        return IPP_ERR_FAIL; //yes

    }

    printf("init_vfatdev <- out\n");
	/* Return success */
	return IPP_OK;
}

