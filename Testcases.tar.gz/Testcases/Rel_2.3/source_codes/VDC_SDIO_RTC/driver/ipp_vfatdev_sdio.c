/*=============================================================================
**
** Copyright (C) 2009 AppliedMicro Confidential Information
**
** All Rights Reserved.
**
** THIS WORK CONTAINS PROPRIETARY INFORMATION WHICH IS THE PROPERTY OF
** AppliedMicro AND IS SUBJECT TO THE TERMS OF NON-DISCLOSURE AGREEMENT
** BETWEEN AppliedMicro AND THE COMPANY USING THIS FILE.
**
** File: ipp_vfatdev_sdio.c
** Version: 1.0
** Authors: Loc Ho (lho@amcc.com)
** Description: SDIO driver source file for VFAT
*/
//#include "stdio.h"
//#include <string.h>
#include <stdio.h>

#include "../include/apm_ahbc_csr.h"
#include "../include/ipp_hardware.h"
#include "../include/ipp_vfatdev_sdio.h"
#include "../include/ipp_libc.h"

//#include "mb_common.h" // modify for uboot
#include "../include/mamba_scu.h"
#include "../include/apm_ipp_csr.h"
//=========== for IIC ===========//

//  #include "mamba_i2c.h"
//#include "i2c_tests.h"
//#define IO_EXPANDER_1 0x26
//#define IO_EXPANDER_2 0x25


#define IO_EXPANDER_1 0x4C
#define IO_EXPANDER_2 0x4A

//===============================//
#define DELAY_1 100000  //50000 //1000000

static unsigned char  high_capacity;
//
static unsigned int respond_0_1 ;
static unsigned int respond_0_1_cmd3 ;
static unsigned int respond_2_3 ;
static unsigned int respond_4_5 ;
static unsigned int respond_6_7 ;
//
static unsigned int data_test [512] ;
static unsigned int data_read_test [100] ;
//static unsigned int data_write_test [512] ;
//
////= for ADMA === //
//unsigned int data_for_table_adma_0[8*100]; // 100 transation
//static unsigned int data_for_table_adma_1[8*100]; // 100 transation
//static unsigned int data_for_table_adma_2[8*100]; // 100 transation
//static unsigned int data_for_table_adma_3[8*100]; // 100 transation
//static unsigned int data_for_table_adma_4[8*100]; // 100 transation
//
//static unsigned int addr_for_data_adma_0[512*100]; // 100 blocks
//static unsigned int addr_for_data_adma_1[512*100]; // 100 blocks
//static unsigned int addr_for_data_adma_2[512*100]; // 100 blocks
//static unsigned int addr_for_data_adma_3[512*100]; // 100 blocks
//static unsigned int addr_for_data_adma_4[512*100]; // 100 blocks

/*
int  getc(void);
int  tstc(void);
void putc(const char);
void puts(const char*);
void printf(const char* fmt, ...);
void *malloc(size_t);
void free(void*);
void udelay(unsigned long);
*/
//void start_test (void);
int sdio_init(unsigned char sdio_no);
//void config_io_expander_for_sdhc ( void);
unsigned int sdio_hw_init(unsigned char sdio_no);
unsigned int read_vfatdev_sdio_block(u8 sdio_no,unsigned int lba);
unsigned int write_vfatdev_sdio_block(u8 sdio_no,unsigned int lba);
unsigned int read_vfatdev_sdio_adma_mono_block(u8 sdio_no,unsigned int lba);
unsigned int write_vfatdev_sdio_adma_mono_block(u8 sdio_no,unsigned int lba);
unsigned int read_vfatdev_sdio_block_muliple(u8 sdio_no, unsigned int lba, u16 blkNo);
unsigned int read_vfatdev_sdio_sdma_multi_block(u8 sdio_no,unsigned int lba ,u16 blkNo);
unsigned int write_vfatdev_sdio_sdma_multi_block(u8 sdio_no,unsigned int lba ,u16 blkNo);
unsigned int write_vfatdev_sdio_block_multiple(u8 sdio_no, unsigned int lba, u16 blkNo);
unsigned int write_vfatdev_sdio_adma_multi_block(u8 sdio_no,unsigned int lba);
unsigned int write_vfatdev_sdio_adma_2_multi_block(u8 sdio_no,unsigned int lba,u16 blkNo);
unsigned int write_vfatdev_sdio_adma_2_multi_block_test_suspend_resume(u8 sdio_no,unsigned int lba,u16 blkNo);
unsigned int read_vfatdev_sdio_adma_2_multi_block(u8 sdio_no,unsigned int lba,u16 blkNo);
unsigned int read_vfatdev_sdio_adma_2_multi_block_test_suspend_resume(u8 sdio_no,unsigned int lba,u16 blkNo);
unsigned int sdio_send_suspend_resume_command (unsigned char sdio_no);
void reset_cmd_data_line (unsigned char sdio_no);
void SDIO_soft_reset (void)
{
	int read_data;
	int write_data;
	arch_timer_msdelay(100);
	WRITE32( 0x1f2ac008, 0x000003fd);		/* Disable SDIO CLOCK */
    arch_timer_msdelay(100);
	WRITE32( 0x1f2ac008, 0x000003ff );		/* Enable SDIO CLOCK */
	read_data = READ32(0x1f2ac000);
	arch_timer_msdelay(100);
	write_data = (read_data & 0xfffffffd) | 0x2;
	WRITE32( 0x1f2ac000, write_data );		/* reset */
	arch_timer_msdelay(100);
	write_data = (read_data & 0xfffffffd) ;
	arch_timer_msdelay(100);
	WRITE32( 0x1f2ac000, write_data );		/* disable reset */
    arch_timer_msdelay(100);

}
void delay_arb_sdio(u32 count)
{

    if(count < 0) {
        printf("ERR: Invalid value for count:: %08x", count);
        return;
    }
    while(count--);
}

void WRITE_SDIO(unsigned char sdio_no, unsigned int offset, unsigned int data)
{
    unsigned int addr=0;
    if(sdio_no == 1) {
        addr = MPA_SDIO_BASE_VA + offset;
    }
    else if(sdio_no == 2)  {
        addr = MPA_SDIO_BASE_VA_1 + offset;
    }
//    data = sd_bswap32(data);
    *((volatile unsigned int *)addr) = data;
//	WRITE32(addr, data);
}

void WRITE_SDIO_8(unsigned char sdio_no, unsigned int offset, unsigned char data)
{
    unsigned int addr=0;
    if(sdio_no == 1) {
        addr = MPA_SDIO_BASE_VA + offset;
    }
    else if(sdio_no == 2)  {
        addr = MPA_SDIO_BASE_VA_1 + offset;
    }
//    data = sd_bswap32(data);
    *((volatile unsigned char *)addr) = data;
//	WRITE32(addr, data);
}

void WRITE_SDIO_16(unsigned char sdio_no, unsigned int offset, unsigned short data)
{
    unsigned int addr=0;
    if(sdio_no == 1) {
        addr = MPA_SDIO_BASE_VA + offset;
    }
    else if(sdio_no == 2)  {
        addr = MPA_SDIO_BASE_VA_1 + offset;
    }
//    data = sd_bswap32(data);
    *((volatile unsigned short *)addr) = data;
//	WRITE32(addr, data);
}

unsigned int READ_SDIO(unsigned int sdio_no, unsigned int offset)
{
    unsigned int addr=0,data=0;
    if(sdio_no == 1) {
        addr = MPA_SDIO_BASE_VA + offset;
    }
    else if(sdio_no == 2)  {
        addr = MPA_SDIO_BASE_VA_1 + offset;
    }
    data = *((volatile unsigned int *)addr);
//    data = READ32((void *) addr); //  add
//    data = sd_bswap32(data);
    return data;
}

unsigned char READ_SDIO_8(unsigned int sdio_no, unsigned int offset)
{
    unsigned int addr=0;
    unsigned char data=0;
    if(sdio_no == 1) {
        addr = MPA_SDIO_BASE_VA + offset;
    }
    else if(sdio_no == 2)  {
        addr = MPA_SDIO_BASE_VA_1 + offset;
    }
    data = *((volatile unsigned char *)addr);
//    data = READ32((void *) addr); //  add
//    data = sd_bswap32(data);
    return data;
}

unsigned short READ_SDIO_16(unsigned int sdio_no, unsigned int offset)
{
    unsigned int addr=0;
    unsigned short data=0;
    if(sdio_no == 1) {
        addr = MPA_SDIO_BASE_VA + offset;
    }
    else if(sdio_no == 2)  {
        addr = MPA_SDIO_BASE_VA_1 + offset;
    }
    data = *((volatile unsigned short *)addr);
//    data = READ32((void *) addr); //  add
//    data = sd_bswap32(data);
    return data;
}
int sdio_out32(u32 addr, u32 val)
{
	//  out_be32((void *) addr, val);
	WRITE32(addr, val); //  add
	delay_arb_sdio(100);
	return 0;
}

int sdio_in32(u32 addr, u32 *val)
{
	delay_arb_sdio(100);
// 	*val = in_be32((void *) addr);
	*val = READ32((void *) addr); //  add
	return 0;
}


void sdio_read_write_reg(u8 sdio_no) {

    u32 istat;

    //  lprintf(7, "Default Reg Read\n");
	istat = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
    //  lprintf(7, "Read addr:0x%08x rdVal:0x%08x\n",(unsigned int *)PRESENT_STATE_ADDR, istat);
    istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
    //  lprintf(7, "Read addr:0x%08x rdVal:0x%08x\n",(unsigned int *)INTERRUPT_STATUS_ADDR, istat);

	istat = READ_SDIO(sdio_no,CAPABILITIES_0_ADDR);
    //  lprintf(7, "Read addr:0x%08x rdVal:0x%08x\n",(unsigned int *)CAPABILITIES_0_ADDR, istat);
    istat = READ_SDIO(sdio_no,CAPABILITIES_1_ADDR);
    //  lprintf(7, "Read addr:0x%08x rdVal:0x%08x\n",(unsigned int *)CAPABILITIES_1_ADDR, istat);

    //  lprintf(7, "Reg Write/Read for 0x0 and 0x4 addr\n");
	istat = READ_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR);
    //  lprintf(7, "Read addr:0x%08x rdVal:0x%08x\n",(unsigned int *)SDMA_SYSTEM_ADDRESS_ADDR, istat);
    WRITE_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR, SDIO_OCM_PHYS_ADDR_RD);
	istat = READ_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR);
    //  lprintf(7, "Read addr:0x%08x rdVal:0x%08x\n",(unsigned int *)SDMA_SYSTEM_ADDRESS_ADDR, istat);

	istat = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
    //  lprintf(7, "Read addr:0x%08x rdVal:0x%08x\n",(unsigned int *)BLOCK_DEF_ADDR, istat);
	WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, 0x00010008);
	istat = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
    //  lprintf(7, "Read addr:0x%08x rdVal:0x%08x\n",(unsigned int *)BLOCK_DEF_ADDR, istat);
}

u32 sdio_card_present(u8 sdio_no)
{
	u32 rc=0;

    //  lprintf(7, "sdio_card_present -> in\n");

    rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
    //  lprintf(7, "addr: 0x%08x rtVal:0x%08x\n",(unsigned int *)PRESENT_STATE_ADDR, rc);

    rc = rc & 0x00010000;

    //  lprintf(7, "sdio_card_present <- out\n");

    return rc;
}

static u32 sdio_wait_cmd_complete(u8 sdio_no)
{
	u32 val,timeout=0;

//    printf("sdio_wait_cmd_complete -> in\n");

    /* Wait for the command complete or error bit set */
    arch_timer_msdelay(1);
    timeout=100;
	do {

        val = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
        printf("INTERRUPT_STATUS_ADDR:0x%08x data:0x%08x\n",(unsigned int *)INTERRUPT_STATUS_ADDR,val);

        if((val & 0x00000003))
            break;

        if(timeout == 0) {
            //  lprintf(7, "Timeout for CMD-CMPLT\n");
            //  lprintf(7, "Clear Interrupt addr:0x%08x wrVl:0x%08x\n", (unsigned int *)INTERRUPT_STATUS_ADDR,val);
            //  lprintf(7, "addr:0x%08x data:0x%08x\n", (unsigned int *)INTERRUPT_STATUS_ADDR,val);

            printf("Timeout for CMD-CMPLT\n");
            printf("Clear Interrupt addr:0x%08x wrVl:0x%08x\n", (unsigned int *)INTERRUPT_STATUS_ADDR,val);
            printf("addr:0x%08x data:0x%08x\n", (unsigned int *)INTERRUPT_STATUS_ADDR,val);

            WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, val);
        	arch_timer_msdelay(1);
	        return 0;
        }

        timeout--;

	} while (1);

	/* Clear interrupt */
	WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, val);
    arch_timer_msdelay(1);
//    printf("Write INT-CLR INTSTS addr:0x%08x wrVl:0x%08x\n", (unsigned int *)INTERRUPT_STATUS_ADDR,val);

//    printf("sdio_wait_cmd_complete <- out\n");

    return val;
}

//static unsigned int sdio_send_acmd(unsigned char sdio_no,unsigned int cmd_tm, unsigned int cmd55_arg, unsigned int arg)
//{
//	unsigned int val,val1;
//
//    //  lprintf(7, "sdio_send_acmd -> in\n");
//
//	/* Send App Mode command - CMD55 ARG 0 Response R1 */
//	WRITE_SDIO(sdio_no,ARGUMENT_ADDR, cmd55_arg);
//    ipp_udelay(DELAY_1);
//    //  lprintf(7, "Write ARGNT addr:0x%08x wrVl:0x%08x\n", (unsigned int *)ARGUMENT_ADDR,cmd55_arg);
//
//	WRITE_SDIO(sdio_no,TRANSFERMODE_COMMAND_ADDR, 0x371a0000);
//    ipp_udelay(DELAY_1);
//    //  lprintf(7, "Write TRNS-MODE addr:0x%08x 0x371a0000\n", (unsigned int *)TRANSFERMODE_COMMAND_ADDR);
//
//	val = sdio_wait_cmd_complete(sdio_no);
//	if ((val & 0x00008000) && (val & 0x00000002) == 0) {
//        //  lprintf(3, "ACMD55 Fail NoData TransferDone addr:0x30 data:0x%08x\n",val);
//		return val;	/* Error */
//    }
//
//    val = READ_SDIO(sdio_no,RESPONSE_0_1_ADDR);
//    //  lprintf(7, "Read RESP addr:0x%08x rdVl:0x%08x\n",(unsigned int *)RESPONSE_0_1_ADDR,val);
//
//    val1 = READ_SDIO(sdio_no,RESPONSE_2_3_ADDR);
//    //  lprintf(7, "Read RESP addr:0x%08x rdVl:0x%08x\n",(unsigned int *)RESPONSE_2_3_ADDR,val1);
//
//	if (!(val & 0x00000020)) {
//        //  lprintf(3, "ACMD Fail NoRespnse addr:0x30 data:0x%08x\n",RESPONSE_0_1_ADDR, val);
//		return 0xFFFFFFFF; /* Card not go to ACMD mode */
//    }
//
//    /* Send ACMD */
//	WRITE_SDIO(sdio_no,ARGUMENT_ADDR, arg);
//    ipp_udelay(DELAY_1);
//    //  lprintf(7, "Write ARGNT addr:0x%08x wrVl:0x%08x\n", (unsigned int *)ARGUMENT_ADDR,arg);
//
//	WRITE_SDIO(sdio_no,TRANSFERMODE_COMMAND_ADDR, cmd_tm);
//    ipp_udelay(DELAY_1);
//    //  lprintf(7, "Write TRNS-MODE addr:0x%08x wrVal:0x%08x\n", (unsigned int *)TRANSFERMODE_COMMAND_ADDR,cmd_tm);
//
//	val = sdio_wait_cmd_complete(sdio_no);
//	if ((val & 0x00008000) && (val & 0x00000002) == 0)  {
//        //  lprintf(3, "ACMD Fail NoData TransferDone addr:0x30 cmd_tm:0x%08x\n val:0x%08x",cmd_tm,val);
//		return val;	/* Error */
//    }
//
//    //  lprintf(7, "sdio_send_acmd <- out\n");
//
//	return 0;
//}
//======================================================================================================//
//khuynh add function write command
static u32 send_command_to_card(u8 sdio_no,u32 arg , u32 cmd)
{
	    u32 card_id,temp1,temp2,temp3,temp4;
		u32 istat;
		u32 rc=0;
	    u32 timeout=0;
	    int retval=0;

	    timeout=10;
//	        printf("\nWait for CMD line Free,");
	    	do {
	    	    rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
	            timeout--;
	            arch_timer_msdelay(1);
	            if(timeout == 0) {
	                printf("Timeout for CMD line Free addr:0x%08x rdvl:0x%08x \r\n",(unsigned int *)PRESENT_STATE_ADDR,rc);
	                return 1;
	            }
	            if((rc & 0x01) == 0x00)
	                break;
	    	} while (1);
//	        printf("Done\n");

	        // Send reset command - CMD0 ARG 0
//	        printf("\nSend Reset Command (GO_IDEL_STATE) CMD0\n");
	        arch_timer_msdelay(1);
	        WRITE_SDIO(sdio_no,ARGUMENT_ADDR, arg);
	        arch_timer_msdelay(1);
	    	WRITE_SDIO(sdio_no,TRANSFERMODE_COMMAND_ADDR, cmd);
	        arch_timer_msdelay(1);
	    	istat = sdio_wait_cmd_complete(sdio_no);
	    	if (istat & 0x00008000) {
	            printf("Fail! CMD0 ResetCmd = 0x%08x\n", istat );
	            retval=6;
	    		return retval;	///Error
	        }
//	        printf("Done\n");

	    	temp1 = READ_SDIO(sdio_no,RESPONSE_0_1_ADDR);
	        temp2 = READ_SDIO(sdio_no,RESPONSE_2_3_ADDR);
	        temp3 = READ_SDIO(sdio_no,RESPONSE_4_5_ADDR);
	        temp4 = READ_SDIO(sdio_no,RESPONSE_6_7_ADDR);

	        respond_0_1 = temp1 ;
	        respond_2_3 = temp2 ;
	        respond_4_5 = temp3 ;
	        respond_6_7 = temp4 ;

	        //CMD 55-41 run OK if add this print
	    	printf("RESP-1 addr:0x%08x data:0x%08x\n",(unsigned int *)RESPONSE_0_1_ADDR,temp1);
	    	printf("RESP-2 addr:0x%08x data:0x%08x\n",(unsigned int *)RESPONSE_2_3_ADDR,temp2);
	    	printf("RESP-3 addr:0x%08x data:0x%08x\n",(unsigned int *)RESPONSE_4_5_ADDR,temp3);
	        printf("RESP-4 addr:0x%08x data:0x%08x\n",(unsigned int *)RESPONSE_6_7_ADDR,temp4);
	        printf("\n");
	        //end this print

}

//end function write command
//=======================================================================================================//
//-------------- SDMA Mode End -------------------------
//=======================================================================================================//

unsigned int test_write_pio (unsigned char sdio_no, unsigned int lba ){

	unsigned int rc=0 ,counter ;
	unsigned int res ;
//	unsigned int lba = 0x20;
	lba *= SDIO_BLOCK_SIZE;

    //Set block size and block count
	//preparing to receive DATA

	rc = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
	printf("BLOCK_DEF_ADDR data:0x%08x\n",rc);
	rc = 0x00010200 ; // 1 block; size 512 byte --> no run OK
	//rc = 0x00020200 ;
	//rc = 0x00010080 ;
//	rc = 0x00020008 ; //run OK
	//rc = 0x00040008 ; //run OK
	//rc = 0x00080010 ; //no run --> need debugging
	arch_timer_msdelay(20);
	WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, rc);
	arch_timer_msdelay(20);
	rc = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
	printf("BLOCK_DEF_ADDR after data:0x%08x\n",rc);

	arch_timer_msdelay(20);
	WRITE_SDIO(sdio_no,ARGUMENT_ADDR, lba);
    printf("ARGUMENT_ADDR:0x%08x data:0x%08x\n",ARGUMENT_ADDR, lba);
	arch_timer_msdelay(10);

	//CMD 25 --> Write multi block ============//
	arch_timer_msdelay(20);
	//
//	res = send_command_to_card(sdio_no ,0x00000002 ,0x193a0020 ); //OK
//	res = send_command_to_card(sdio_no ,0x00000002 ,0x193a0022 ); //no OK
//	res = send_command_to_card(sdio_no ,0x00000000 ,0x193a0020 ); //no OK
    res = send_command_to_card(sdio_no ,0x00000000 ,0x183a0000 ); //no OK

	rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
	printf("PRESENT_STATE_ADDR data:0x%08x\n",rc);
	arch_timer_msdelay(20);
	//begin write data
	//rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
//	rc = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
//	printf("INTERRUPT_STATUS_ADDR data1:0x%08x\n",rc);
	counter = 0 ;
    //while (rc & 0x00000400){
//	while (rc & 0x00000100){
	int i,j;
	u32  mask = 0;
	u32  retry = 100000;

	for (j = 0; j < retry; j++) {
		mask = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
		if (mask & XGENE_SDHCI_NORINTSTS_ERR_INTERRUPT) {
			/* Error Interrupt */
			WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR,mask);
			printf("Error ERR_INTERRUPT)\n");
			return -1;
		}
		/* BUFFER_WRITE_READY */
		if (mask & BUFFER_WRITE_READY) {
			printf("INTERRUPT_STATUS_ADDR BUFFER_WRITE_READY data1:0x%08x\n",mask);
			WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR,mask);
			break;
		}
		arch_timer_usdelay(1);
	}
	if (i == retry) {
		printf("BUFFER_WRITE_READY timeout\n");
		WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR,mask);
		return -1;
	}
	retry = 100000;



	for (counter = 0; counter <1024/4; counter++)
	{
	   //rc = READ_SDIO(sdio_no,BUFFER_DATA_PORT_ADDR);
		arch_timer_msdelay(2);
	   WRITE_SDIO(sdio_no,BUFFER_DATA_PORT_ADDR,0xcafe0000 + counter);
	   printf("wr_data_port[%d] = 0x%08x \r\n",sdio_no-1, 0xcafe0000 + counter);
	   counter ++ ;
	   //if (counter == 512 ) break ;
	   if (counter == 1024/4 ) break ;
	   //rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
//	   rc = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
	}
	arch_timer_msdelay(20);
    rc = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
    printf("BLOCK_DEF_ADDR after xfer data:0x%08x\n",rc);

    printf("End test PIO write \n");

}
//=======================================================================================================//

unsigned int test_read_pio (unsigned char sdio_no, unsigned int lba ){

	unsigned int rc=0 ,counter ;
	unsigned int res ;
//	unsigned int lba = 0x20;
	lba *= SDIO_BLOCK_SIZE;

    //Set block size and block count
	//preparing to receive DATA
	arch_timer_msdelay(100);
	rc = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
	printf("BLOCK_DEF_ADDR data:0x%08x\n",rc);
//	rc = rc | 0x00010008 ; //run OK
	rc = 0x00010200 ; // 1 block; size 512 byte --> no run OK
	//rc = 0x00020200 ;
	//rc = 0x00010080 ;
	//rc = 0x00020008 ; //run OK
	//rc = 0x00040008 ; //run OK
	//rc = 0x00080010 ; //no run --> need debugging
	arch_timer_msdelay(100);
	WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, rc);
	arch_timer_msdelay(100);
	rc = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
	printf("BLOCK_DEF_ADDR after data:0x%08x\n",rc);

	arch_timer_msdelay(10);
	WRITE_SDIO(sdio_no,ARGUMENT_ADDR, lba);
    printf("ARGUMENT_ADDR:0x%08x data:0x%08x\n",ARGUMENT_ADDR, lba);

	//CMD 17 --> Read single block ============//
	arch_timer_msdelay(100);
 	res = send_command_to_card(sdio_no ,0x00000000 ,0x113a0032 ); //no OK
//	res = send_command_to_card(sdio_no ,0x00000000 ,0x123a0032 ); // Add

	rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
	    printf("PRESENT_STATE_ADDR data:0x%08x\n",rc);


		rc = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
		printf("INTERRUPT_STATUS_ADDR data1:0x%08x\n",rc);
//	    while (rc & 0x00000800){

		int i,j;
		u32  mask = 0;
		u32  retry = 100000;

		for (j = 0; j < retry; j++) {
			mask = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
			if (mask & XGENE_SDHCI_NORINTSTS_ERR_INTERRUPT) {
				/* Error Interrupt */
				WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR,mask);
				printf("Error ERR_INTERRUPT)\n");
				return -1;
			}
			/* BUFFER_WRITE_READY */
			if (mask & BUFFER_READ_READY) {
				WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR,mask);
				break;
			}
			arch_timer_usdelay(1);
		}
		if (i == retry) {
			printf("BUFFER_READ_READY timeout\n");
			WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR,mask);
			return -1;
		}
		retry = 100000;

		for (counter = 0; counter <SDIO_BLOCK_SIZE/4; counter++)
		{
			arch_timer_msdelay(2);
	    	rc = READ_SDIO(sdio_no,BUFFER_DATA_PORT_ADDR);
 	 	    printf("rd_data_port[%d] = 0x%08x \r\n",sdio_no-1, rc);

			if (rc != 0xcafe0000 + counter*2)
			{
				return IPP_ERR_FAIL;
			}
	    	rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
	    }
	    printf("Data for read above!!! \n");

	arch_timer_msdelay(100);
    rc = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
    printf("BLOCK_DEF_ADDR after xfer data:0x%08x\n",rc);

    printf("End test PIO read \n");
	return IPP_OK;
}
//=======================================================================================================//

unsigned int test_write_sdma (unsigned char sdio_no ,unsigned int lba ){

	unsigned int rc=0 ,counter ;
	unsigned int res ;

	unsigned int cmd;
	unsigned int istat,temp,timeout=0;

	printf("\nread_vfatdev_sdio_block -> in\n");
	printf("lba:0x%x\n",lba);

	timeout=10;
	printf("\nWait for CMD line Free,");
    do {
		istat = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
	        timeout--;
	        if(timeout == 0) {
	        printf("Timeout for CMD line Free addr:0x%08x rdvl:0x%08x\n",(unsigned int *)PRESENT_STATE_ADDR,istat);
	        break;
	        }
	        if((istat & 0x01) == 0x00)
	            break;
		} while (1);
	 printf("Done\n");

	 WRITE_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR, SDIO_OCM_PHYS_ADDR_RD);
	 printf("Write addr:0x%08x wrVal:0x%08x\n",(unsigned int *)SDMA_SYSTEM_ADDRESS_ADDR, (unsigned int *)SDIO_OCM_PHYS_ADDR_RD);

	 temp = ((1 << 16) | SDIO_BLOCK_SIZE);
	 WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, temp);   //  writing both block count(=1) and block size regs

	 	cmd =     (24 << 24)  	// Single write Command Index
	     		| ( 0 << 22)   	// Command type
	 	    	| ( 1 << 21)    // Data Present
	 		    | ( 1 << 20) 	// Command Index check enable
	     		| ( 1 << 19)	// Command CRC check enable
	 	    	| ( 2 << 16)	// Response type - R1
	 		    | ( 0 << 4) 	// Write Direction
	     		| ( 1 << 1)	    // Disable block count
	 	    	| ( 1 << 0)	    // DMA Enable
	 	    	| ( 0 << 2)	    // AUTO CMD12 Enable
	 		    | ( 0 << 5);	// Multiple Block Select


	 //Send CMD ============//
	 ipp_udelay(20);
	 res = send_command_to_card(sdio_no ,lba ,cmd ); //no OK



     rc = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
     printf("BLOCK_DEF_ADDR after xfer data:0x%08x\n",rc);

     printf("End test PIO read sdma \n");

}
//=======================================================================================================//

u32 sdio_hw_init(u8 sdio_no)
{
	u32 cap;
	u32 card_id,temp1,temp2;
	u32 istat;
	u32 rc=0;
	u8  bw_4bits , clock_select=3;
	u8 *buf = (u8*)SDIO_OCM_PHYS_ADDR_RD;
    u32 timeout=0;
    int retval=0;
    u32 res,i ;
	char c;

	high_capacity = 0;
    rc = READ_SDIO(sdio_no,SLOT_INTR_STATUS_HOST_CONTROLLER_VERSION_ADDR);

    rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
    if (!(rc & 0x00010000)) {
            retval=2;
        	printf("\n;=;=;=;=;=;=;=;=;=;=;=;= Card is not DETECTED ;=;=;=;=;=;=;=;=;=;=;=;= \r\n");
			return IPP_ERR_FAIL;
        }
    else
    	printf("\n;=;=;=;=;=;=;=;=;=;=;=;= Card is DETECTED ;=;=;=;=;=;=;=;=;=;=;=;= \r\n");
	rc = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
	printf("=========== SRESET_CLOCK_CONTROL_ADDR = 0x%08x=========== \n",rc );

    rc  = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);

    rc = rc | 0x00070000;
	WRITE_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR, rc);
	arch_timer_usdelay(1);
    WRITE_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR, rc);
	arch_timer_usdelay(1);
    rc  = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
	arch_timer_usdelay(200);
    timeout=100;
	do {
		rc  = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
        timeout--;
    	arch_timer_usdelay(1);
        if(timeout == 0) {
            retval=1;
            break;
        }
	}
	while (rc & 0x00070000);
	rc = READ_SDIO(sdio_no,INTERRUPT_STATUS_ENABLE_ADDR);
	printf("=========== INTERRUPT_STATUS_ENABLE_ADDR = 0x%08x=========== \n",rc );
	rc = 0x02ff00cb; // following linux driver 09-01-2012
    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ENABLE_ADDR, rc);
	arch_timer_usdelay(1);

	rc = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
    rc = rc & 0xF0FFFFFF;
//	rc = rc | 0x0E003007;
//	rc = rc | 0x0E001005;
	rc = rc | 0x0E001005;
    WRITE_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR, rc);
	arch_timer_usdelay(1);
	rc = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);

	printf("\n======================== CMD 0 ======================== \r\n");
    res = send_command_to_card(sdio_no,0x00000000 ,0x00000000 );

	printf("\n======================== CMD 0 ======================== \r\n"); // work arround
    res = send_command_to_card(sdio_no,0x00000000 ,0x00000000 );
    printf("\n======================== CMD 8 ======================== \r\n");
    res = send_command_to_card(sdio_no ,0x000001aa ,0x081a0000 );

    timeout = 100;
    while (1){
    	arch_timer_usdelay(100);
        printf("\n======================== CMD 55 ======================== \r\n");
    	res = send_command_to_card(sdio_no ,0x00000000 ,0x371a0000 ); //OK
    	arch_timer_usdelay(100);
        printf("\n======================== CMD 41 ======================== \r\n");
    	res = send_command_to_card(sdio_no ,0x40300000 ,0x29020000 ); //OK

    	if (respond_0_1&0xf0000000 ) break ;
    	if (timeout == 0 ) break ;
    	timeout -- ;

    }
    if (respond_0_1&0x40000000 ) printf("\r This card is SDHC \r\n");
    else {
    	 if (timeout)            printf("\rThis card is SD \r\n");
         }
    high_capacity = (respond_0_1&0x40000000 ) ? 1 : 0;

    if (timeout == 0 ) printf("\n CONFIG FAILED !!! \n");

	arch_timer_usdelay(20);
    printf("\n======================== CMD 2 ======================== \r\n");
    res = send_command_to_card(sdio_no ,0x00000000 ,0x02090000 ); //OK

    printf("Res CMD2 \n");
    printf("RESP-1 data:0x%08x\n",respond_0_1);
    printf("RESP-2 data:0x%08x\n",respond_2_3);
    printf("RESP-3 data:0x%08x\n",respond_4_5);
    printf("RESP-4 data:0x%08x\n",respond_6_7);
    printf("\n");


    printf("\n======================== CMD 3 ======================== \r\n");
	arch_timer_usdelay(20);
    res = send_command_to_card(sdio_no ,0x00000000 ,0x031a0000 ); //OK

    printf("Res CMD3 \n");
    printf("RESP-1 data:0x%08x\n",respond_0_1);
    printf("RESP-2 data:0x%08x\n",respond_2_3);
    printf("RESP-3 data:0x%08x\n",respond_4_5);
    printf("RESP-4 data:0x%08x\n",respond_6_7);
    printf("\n");

    respond_0_1_cmd3 = (respond_0_1 >> 16)& 0xffff  ;
    respond_0_1_cmd3 = respond_0_1_cmd3 << 16 ;

    printf("\n======================== CMD 9 ======================== \r\n");
	arch_timer_usdelay(20);
    res = send_command_to_card(sdio_no ,respond_0_1_cmd3 ,0x09090000 );

    printf("Res CMD9 -->CSD Card \n");
    printf("RESP-1 data:0x%08x\n",respond_0_1);
    printf("RESP-2 data:0x%08x\n",respond_2_3);
    printf("RESP-3 data:0x%08x\n",respond_4_5);
    printf("RESP-4 data:0x%08x\n",respond_6_7);
    printf("\n");

    printf("\n======================== CMD 7 ======================== \r\n");
	arch_timer_usdelay(20);
    res = send_command_to_card(sdio_no ,respond_0_1_cmd3 ,0x071b0000 );
    printf("Res CMD7 --> CMD_SELECT_CARD Card \n");
    printf("RESP-1 data:0x%08x\n",respond_0_1);
    printf("RESP-2 data:0x%08x\n",respond_2_3);
    printf("RESP-3 data:0x%08x\n",respond_4_5);
    printf("RESP-4 data:0x%08x\n",respond_6_7);
    printf("\n");

    //preparing to receive DATA
    rc = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
	printf("=========== BLOCK_DEF_ADDR = 0x%08x=========== \n",rc );

    rc = rc | 0x00010008 ; //run OK
    WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, rc);
	arch_timer_msdelay(1);
    rc = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);

        printf("\n======================== CMD 55 ======================== \r\n");

    	arch_timer_usdelay(20);
        res = send_command_to_card(sdio_no ,respond_0_1_cmd3 ,0x371a0000 ); //OK

        printf("\n======================== CMD 51 ======================== \r\n");

    	arch_timer_usdelay(20);
        res = send_command_to_card(sdio_no ,0x00000000 ,0x333a0032 ); //OK 0x330a0000 danguyen

        printf("Res CMD51 --> CMD_APP_SEND_SCR Card \n");
        printf("RESP-1 data:0x%08x\n",respond_0_1);
        printf("RESP-2 data:0x%08x\n",respond_2_3);
        printf("RESP-3 data:0x%08x\n",respond_4_5);
        printf("RESP-4 data:0x%08x\n",respond_6_7);
        printf("\n");

        rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
        while (rc & 0x00000800){
        	rc = READ_SDIO(sdio_no,BUFFER_DATA_PORT_ADDR);
        	rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
        }
        rc = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);

    	timeout = 4 ;
        printf("\n========================Begin CMD 06 ======================== \r\n");
        while (1){
        	arch_timer_msdelay(10);
        	rc = 0x00010040 ; //run OK  // DATASHEET BUG ==> Count_Block is ON Upper Byte.
        	WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, rc);
        	rc = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
        	res = send_command_to_card(sdio_no ,0x80fffff1 ,0x063a0032 ); //OK
        	rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);

        	while (rc & 0x00000800){
        		rc = READ_SDIO(sdio_no,BUFFER_DATA_PORT_ADDR);
        		rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
    		}

        	if (timeout == 0 ) break ;
        	timeout -- ;
        }

    #if 1
        //SET FOR CHANGE BUS_WIDTH 4_bit
        printf("\n======================== CMD 55 ======================== \r\n");
    	arch_timer_usdelay(20);
        res = send_command_to_card(sdio_no ,respond_0_1_cmd3 ,0x371a0000 ); //OK
        printf("\n======================== CMD 06 ======================== \r\n");
    	arch_timer_usdelay(20);
        res = send_command_to_card(sdio_no ,0x00000002 ,0x061a0000 ); //OK

        printf("Res CMD06 --> CMD_APP_CHANGE_BUS_WIDTH Card \n");
        printf("RESP-1 data:0x%08x\n",respond_0_1);
        printf("RESP-2 data:0x%08x\n",respond_2_3);
        printf("RESP-3 data:0x%08x\n",respond_4_5);
        printf("RESP-4 data:0x%08x\n",respond_6_7);
        printf("\n");
    #endif
        //=====================================================================//
        //     RECONFIG SDIO HOST FOR RUN 4-BIT MODE , HI-SPEED                            //
        //=====================================================================//


    	rc = READ_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR);
		printf("=========== GAP_WAKEUP_POWER_HOST_CONTROL_ADDR = 0x%08x=========== \n",rc );

    	rc=rc&0xffffff00;
        rc = rc | 0x13 ;          // 4-bit ; Nor-Speed; ADMA1 32 ;
        WRITE_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR, rc);
    	arch_timer_msdelay(1);
        rc = READ_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR);

//		rc = READ_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR);
////		printf("=========== GAP_WAKEUP_POWER_HOST_CONTROL_ADDR = 0x%08x=========== \n",rc );
//
//		rc=rc&0xffffff00;
//		rc = 0x00000f02;
//		WRITE_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR, rc);
//		arch_timer_msdelay(1);
//		rc = READ_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR);

retry_send_command_cmd16:
    	printf("\n======================== CMD 16 ======================== \r\n");
    	arch_timer_usdelay(20);
        res = send_command_to_card(sdio_no ,0x00000200 ,0x101a0000 ); //OK

        rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);

        while (rc & 0x00000800){
            rc = READ_SDIO(sdio_no,BUFFER_DATA_PORT_ADDR);
            rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
        }
        printf("\n");
        printf("Res CMD16 --> MMC_CMD_SET_BLOCKLEN Card \n");
        printf("RESP-1 data:0x%08x\n",respond_0_1);
        printf("RESP-2 data:0x%08x\n",respond_2_3);
        printf("RESP-3 data:0x%08x\n",respond_4_5);
        printf("RESP-4 data:0x%08x\n",respond_6_7);
        printf("\n\r");

    	if ( respond_0_1 == 0x00000920 ) {
    		reset_cmd_data_line(sdio_no);
    		goto retry_send_command_cmd16 ;
    	}
    	arch_timer_msdelay(100);
    	printf("\n======================== TEST WRITE ADMA ======================== \r\n");
    	rc = write_vfatdev_sdio_adma_2_multi_block_test_suspend_resume(sdio_no,0x00000000,1);
    	arch_timer_msdelay(100);
    	printf("\n======================== TEST READ  ADMA ======================== \r\n");
    	rc = read_vfatdev_sdio_adma_2_multi_block_test_suspend_resume(sdio_no,0x00000000,1);

    	return rc;
}

/*
u32 sdio_hw_init(u8 sdio_no)
{
	u32 cap;
	u32 card_id,temp1,temp2;
	u32 istat;
	u32 rc=0;
	u8  bw_4bits , clock_select=3;
	u8 *buf = (u8*)SDIO_OCM_PHYS_ADDR_RD;
    u32 timeout=0;
    int retval=0;
    u32 res,i ;
	char c;

	high_capacity = 0;
    rc = READ_SDIO(sdio_no,SLOT_INTR_STATUS_HOST_CONTROLLER_VERSION_ADDR);

    rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
    if (!(rc & 0x00010000)) {
            retval=2;
            printf("\n ----- Fail! NoCardPresent addr:0x%08x rdvl:0x%08x ------- \r\n",(unsigned int *)PRESENT_STATE_ADDR,rc);
        }
    else
    	printf("\n;=;=;=;=;=;=;=;=;=;=;=;= Card is DETECTED ;=;=;=;=;=;=;=;=;=;=;=;= \r\n");

    rc  = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);

    rc = rc | 0x00070000;
	WRITE_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR, rc);
	arch_timer_usdelay(1);
    WRITE_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR, rc);
	arch_timer_usdelay(1);
    rc  = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
	arch_timer_usdelay(200);
    timeout=100;
	do {
		rc  = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
        timeout--;
    	arch_timer_usdelay(1);
        if(timeout == 0) {
            retval=1;
            break;
        }
	}
	while (rc & 0x00070000);

	rc = READ_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR);
    rc = rc | 0x1;          // 1-bit, NormalSpeed,LedOn
    WRITE_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR, rc);
	arch_timer_usdelay(1);
    rc = READ_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR);
    // Read capabilities register of host controller
	cap = READ_SDIO(sdio_no,CAPABILITIES_0_ADDR);

	// Select voltage level
	rc  = READ_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR);

	rc |= 0x00000E00 | 0x00000100;	// 3.3v support
    WRITE_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR, rc);
	arch_timer_usdelay(1);

	rc  = READ_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR);

	// Enable interrupt and clear interrupt
	rc = 0x02ff00cb; // following linux driver 09-01-2012
    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ENABLE_ADDR, rc);
	arch_timer_usdelay(1);

    WRITE_SDIO(sdio_no,INTERRUPT_SIGNAL_ENABLE_ADDR, rc);
	arch_timer_usdelay(1);

    rc = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, rc);
	arch_timer_usdelay(1);

	// Enable internal clock
	temp1 = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
    temp1 = temp1 & 0xFFFF0000;   // 1-bit, NormalSpeed,LedOn
    temp1 = temp1 | 0x0C001005; // Set time_out
	WRITE_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR, temp1); // less than 1 MHz
	arch_timer_usdelay(1);

	temp1 = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);

	// Wait until internal clock is stable before continue
    timeout=10;
	do {
		rc  = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
        timeout--;
    	arch_timer_usdelay(1);
        if(timeout == 0) {
            printf("Timeout! IntClkStbl in ClockCtrlReg addr:0x%08x rdvl:0x%08x\n",(unsigned int *)SRESET_CLOCK_CONTROL_ADDR,rc);
            retval=3;
            return 0;  //
        }
	} while (!(rc & 0x02));

	// Set timeout for data
	rc = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
    rc = rc & 0xF0FFFFFF;
    rc = rc | 0x0E000000;
    WRITE_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR, rc);
	arch_timer_usdelay(1);
	rc = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);

	printf("\n======================== CMD 0 ======================== \r\n");
    res = send_command_to_card(sdio_no,0x00000000 ,0x00000000 );

	printf("\n======================== CMD 0 ======================== \r\n"); // work arround
    res = send_command_to_card(sdio_no,0x00000000 ,0x00000000 );
    printf("\n======================== CMD 8 ======================== \r\n");
    res = send_command_to_card(sdio_no ,0x000001aa ,0x081a0000 );

    timeout = 100;
    while (1){
    	arch_timer_usdelay(100);
        printf("\n======================== CMD 55 ======================== \r\n");
    	res = send_command_to_card(sdio_no ,0x00000000 ,0x371a0000 ); //OK
    	arch_timer_usdelay(100);
        printf("\n======================== CMD 41 ======================== \r\n");
    	res = send_command_to_card(sdio_no ,0x40300000 ,0x29020000 ); //OK
//        printf("\n======================== Respone = 0x%08x ======================== \r\n", res);

    	if (respond_0_1&0xf0000000 ) break ;
    	if (timeout == 0 ) break ;
    	timeout -- ;

    }
    if (respond_0_1&0x40000000 ) printf("\r This card is SDHC \r\n");
    else {
    	 if (timeout)            printf("\rThis card is SD \r\n");
         }
    high_capacity = (respond_0_1&0x40000000 ) ? 1 : 0;

    if (timeout == 0 ) printf("\n CONFIG FAILED !!! \n");

	arch_timer_usdelay(20);
    printf("\n======================== CMD 2 ======================== \r\n");
    res = send_command_to_card(sdio_no ,0x00000000 ,0x02090000 ); //OK

    printf("Res CMD2 \n");
    printf("RESP-1 data:0x%08x\n",respond_0_1);
    printf("RESP-2 data:0x%08x\n",respond_2_3);
    printf("RESP-3 data:0x%08x\n",respond_4_5);
    printf("RESP-4 data:0x%08x\n",respond_6_7);
    printf("\n");


    printf("\n======================== CMD 3 ======================== \r\n");
	arch_timer_usdelay(20);
    res = send_command_to_card(sdio_no ,0x00000000 ,0x031a0000 ); //OK

    printf("Res CMD3 \n");
    printf("RESP-1 data:0x%08x\n",respond_0_1);
    printf("RESP-2 data:0x%08x\n",respond_2_3);
    printf("RESP-3 data:0x%08x\n",respond_4_5);
    printf("RESP-4 data:0x%08x\n",respond_6_7);
    printf("\n");

    respond_0_1_cmd3 = (respond_0_1 >> 16)& 0xffff  ;
    respond_0_1_cmd3 = respond_0_1_cmd3 << 16 ;

    printf("\n======================== CMD 9 ======================== \r\n");
	arch_timer_usdelay(20);
    res = send_command_to_card(sdio_no ,respond_0_1_cmd3 ,0x09090000 );

    printf("Res CMD9 -->CSD Card \n");
    printf("RESP-1 data:0x%08x\n",respond_0_1);
    printf("RESP-2 data:0x%08x\n",respond_2_3);
    printf("RESP-3 data:0x%08x\n",respond_4_5);
    printf("RESP-4 data:0x%08x\n",respond_6_7);
    printf("\n");

    printf("\n======================== CMD 7 ======================== \r\n");
	arch_timer_usdelay(20);
    res = send_command_to_card(sdio_no ,respond_0_1_cmd3 ,0x071b0000 );
    printf("Res CMD7 --> CMD_SELECT_CARD Card \n");
    printf("RESP-1 data:0x%08x\n",respond_0_1);
    printf("RESP-2 data:0x%08x\n",respond_2_3);
    printf("RESP-3 data:0x%08x\n",respond_4_5);
    printf("RESP-4 data:0x%08x\n",respond_6_7);
    printf("\n");


    //preparing to receive DATA
    rc = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
    rc = rc | 0x00010008 ; //run OK
    WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, rc);
	arch_timer_msdelay(1);
    rc = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);

    printf("\n======================== CMD 55 ======================== \r\n");

	arch_timer_usdelay(20);
    res = send_command_to_card(sdio_no ,respond_0_1_cmd3 ,0x371a0000 ); //OK

    printf("\n======================== CMD 51 ======================== \r\n");

	arch_timer_usdelay(20);
    res = send_command_to_card(sdio_no ,0x00000000 ,0x333a0032 ); //OK 0x330a0000 danguyen

    printf("Res CMD51 --> CMD_APP_SEND_SCR Card \n");
    printf("RESP-1 data:0x%08x\n",respond_0_1);
    printf("RESP-2 data:0x%08x\n",respond_2_3);
    printf("RESP-3 data:0x%08x\n",respond_4_5);
    printf("RESP-4 data:0x%08x\n",respond_6_7);
    printf("\n");

    rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
    while (rc & 0x00000800){
    	rc = READ_SDIO(sdio_no,BUFFER_DATA_PORT_ADDR);
    	rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
    }
    rc = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);

	timeout = 4 ;
    printf("\n========================Begin CMD 06 ======================== \r\n");
    while (1){
    	ipp_udelay(100);

    	rc = 0x00010040 ; //run OK  // DATASHEET BUG ==> Count_Block is ON Upper Byte.
    	WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, rc);
    	ipp_udelay(DELAY_1);
    	rc = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);

    	res = send_command_to_card(sdio_no ,0x80fffff1 ,0x063a0032 ); //OK

    	rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);

    	while (rc & 0x00000800){
    		rc = READ_SDIO(sdio_no,BUFFER_DATA_PORT_ADDR);
    		rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
		}

    	if (timeout == 0 ) break ;
    	timeout -- ;
    }

// disble for test normal speed
# if 1
    //SET FOR CHANGE SPEED
	arch_timer_usdelay(100);

    rc = 0x00010040 ; //run OK  // DATASHEET BUG ==> Count_Block is ON Upper Byte.
    WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, rc);
	arch_timer_msdelay(1);
    rc = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);

    printf("\n======================== CMD 6 ======================== \r\n");

    res = send_command_to_card(sdio_no ,0x80fffff1 ,0x063a0032 ); //OK

    rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);

    while (rc & 0x00000800){
    rc = READ_SDIO(sdio_no,BUFFER_DATA_PORT_ADDR);
    rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
    }
#endif
 // end disble for test normal speed

// disble for test 4_bit mode
#if 1
    //SET FOR CHANGE BUS_WIDTH 4_bit
    printf("\n======================== CMD 55 ======================== \r\n");
	arch_timer_usdelay(20);
    res = send_command_to_card(sdio_no ,respond_0_1_cmd3 ,0x371a0000 ); //OK
    printf("\n======================== CMD 06 ======================== \r\n");
	arch_timer_usdelay(20);
    res = send_command_to_card(sdio_no ,0x00000002 ,0x061a0000 ); //OK

    printf("Res CMD06 --> CMD_APP_CHANGE_BUS_WIDTH Card \n");
    printf("RESP-1 data:0x%08x\n",respond_0_1);
    printf("RESP-2 data:0x%08x\n",respond_2_3);
    printf("RESP-3 data:0x%08x\n",respond_4_5);
    printf("RESP-4 data:0x%08x\n",respond_6_7);
    printf("\n");
#endif
    //=====================================================================//
    //     RECONFIG SDIO HOST FOR RUN 4-BIT MODE , HI-SPEED                            //
    //=====================================================================//

	printf("SELECT CLOCK FOR MEASURING ... !!!\n");
	printf("Please press '1' for 50MHz \n");
	printf("Please press '2' for 25MHz \n");
	clock_select = 2 ;

        rc = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
        rc = rc & 0xFFFF0000;
    	WRITE_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR, rc); // less than 1 MHz
    	arch_timer_msdelay(1);
//		if (clock_select == 1) rc = rc | 0x00000205; // divide Clock to 4     // 50 MHz  // no run OK
        if (clock_select == 2) rc = rc | 0x00000405; // divide Clock to 8      // 25 MHz
        rc = 0x000e0107;

        WRITE_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR, rc); // less than 1 MHz
    	arch_timer_msdelay(1);

    	rc = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);

    	// Wait until internal clock is stable before continue
        timeout=10;
        rc  = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
    	do {
    		rc  = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
            timeout--;
        	arch_timer_msdelay(1);
            if(timeout == 0) {
                printf("Timeout! IntClkStbl in ClockCtrlReg addr:0x%08x rdvl:0x%08x\n",(unsigned int *)SRESET_CLOCK_CONTROL_ADDR,rc);
                retval=3;
                return 0; //
            }
    	} while (!(rc & 0x02));
        printf("SD Clock is ENABLED again !!! \n");
    	rc = READ_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR);
    	rc=rc&0xffffff00;
        rc = rc | 0x13 ;          // 4-bit ; Nor-Speed; ADMA1 32 ;
        WRITE_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR, rc);
    	arch_timer_msdelay(1);
        rc = READ_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR);


//    rc = READ_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR);
//    rc = rc | 0x16 ;          // 4-bit ; Nor-Speed; ADMA1 32 ;
//    WRITE_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR, rc);
	arch_timer_msdelay(1);
    rc = READ_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR);

retry_send_command_cmd16:
	printf("\n======================== CMD 16 ======================== \r\n");
	arch_timer_usdelay(20);
    res = send_command_to_card(sdio_no ,0x00000200 ,0x101a0000 ); //OK

    rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);

    while (rc & 0x00000800){
        rc = READ_SDIO(sdio_no,BUFFER_DATA_PORT_ADDR);
        rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
    }
    printf("\n");
    printf("Res CMD16 --> MMC_CMD_SET_BLOCKLEN Card \n");
    printf("RESP-1 data:0x%08x\n",respond_0_1);
    printf("RESP-2 data:0x%08x\n",respond_2_3);
    printf("RESP-3 data:0x%08x\n",respond_4_5);
    printf("RESP-4 data:0x%08x\n",respond_6_7);
    printf("\n\r");

	if ( respond_0_1 == 0x00000920 ) {
		reset_cmd_data_line(sdio_no);
		goto retry_send_command_cmd16 ;
	}

	printf("\n======================== TEST WRITE ADMA ======================== \r\n");
	rc = write_vfatdev_sdio_adma_2_multi_block_test_suspend_resume(sdio_no,0x00000000,1);
	printf("\n======================== TEST READ  ADMA ======================== \r\n");
	rc = read_vfatdev_sdio_adma_2_multi_block_test_suspend_resume(sdio_no,0x00000000,1);

	return rc;
}
*/
void reset_cmd_data_line (u8 sdio_no)
{
    u32 rc ;
	u32 timeout=0;
    int retval=0;

	rc  = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
    printf("SRESET_CLOCK_CONTROL_ADDR-0 addr:0x%08x rdvl:0x%08x\n",(unsigned int *)SRESET_CLOCK_CONTROL_ADDR,rc);

    //rc = rc | 0x01000000;
    //rc = rc | 0x00010000; //khuynh edit for reset HC
    //rc = rc | 0x00040000; //khuynh edit for reset HC
	rc = rc | 0x00020000; //khuynh edit for reset HC
	WRITE_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR, rc);
	arch_timer_msdelay(100);
    WRITE_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR, rc);
    arch_timer_msdelay(100);
    rc  = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
    printf("SRESET_CLOCK_CONTROL_ADDR-1 addr:0x%08x rdvl:0x%08x\n",(unsigned int *)SRESET_CLOCK_CONTROL_ADDR,rc);
    printf("Done\n");
    printf("SRESET_CLOCK_CONTROL_ADDR-1 after reset All addr:0x%08x rdvl:0x%08x\n",(unsigned int *)SRESET_CLOCK_CONTROL_ADDR,rc);
    arch_timer_usdelay(1000);
    //if (rc & 0x00010000) printf("Reset All Done !!!\n");
    // Wait until hardware returns from reset
    //Workaround for run SDHC because all reset bit NOT return '0' value after write '1'
	rc = rc & 0xfff0ffff;
    WRITE_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR, 0x00);
    arch_timer_usdelay(100);
    //khuynh add above

	printf("\nPoll Config RersetAll,");
    timeout=100;
	do {
		rc  = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
        timeout--;
        arch_timer_msdelay(100);
        if(timeout == 0) {
            ////  lprintf(7, "Timeout! RersetAll in SWResetReg addr:0x%08x rdvl:0x%08x\n",(unsigned int *)SRESET_CLOCK_CONTROL_ADDR,rc);
            retval=1;
        }
	}  //while (rc & 0x01000000);
	//while (rc & 0x00010000);
	while (rc & 0x00070000);
	printf("Reset All Done !!!\n");
}


//===================================================================================================
//===================================================================================================
//-------------- SDMA Mode Start -------------------------

unsigned int read_vfatdev_sdio_block(u8 sdio_no,unsigned int lba)
{
	unsigned int cmd,rc,i;
	unsigned int istat,temp,timeout=0;
    unsigned int *data_read_add = &data_read_test[0];
    unsigned int data ;
    //printf("\nread_vfatdev_sdio_block -> in\n");
    //printf("lba:0x%x\n",lba);
//    &data_read_test[0] = 0x1d0c1000;
    data_read_add = 0x1d0c1000;
    printf("Before transfer data...\n\n ");
    for (i=1 ; i< (128+1) ; i++){
        data = *((volatile unsigned int *)data_read_add);
        printf("add = 0x%08x, data = 0x%08x ", data_read_add, data);
        data_read_add ++ ;
        if ((i%4)==0) printf("\n\r");
        }
    printf("\n\n ");
    //timeout=10000000;
    timeout=100; //test for 50Mhz
    printf("\nWait for CMD line Free\r\n");
	do {
	    istat = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
        timeout--;
        if(timeout == 0) {
            printf("Timeout for CMD line Free addr:0x%08x rdvl:0x%08x\n",PRESENT_STATE_ADDR,istat);
			//return IPP_ERR_FAIL;
            break;  // test 50MHz
        }
        if((istat & 0x01) == 0x00)
            break;
	} while (1);
    printf("Done\n");

#if 1
	//if (!high_capacity[sdio_no-1]) {
	if (!high_capacity) {
		lba *= SDIO_BLOCK_SIZE;
		//printf("high_cpacity:%d lba:0x%x\n",high_capacity[sdio_no-1], lba);
		printf("high_cpacity,  lba:0x%08x r\n",lba);
    }
#endif

	//WRITE_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR, SDIO_OCM_PHYS_ADDR_RD);
	printf("SDMA read address0 = 0x%08x \r\n", &data_read_test[0]);
	printf("SDMA read address1 = 0x%08x \r\n", data_read_add);
//	 WRITE_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR, &data_read_test[0]);
	 WRITE_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR, data_read_add);
	 rc  = READ_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR);
	 printf("SDMA_SYSTEM_ADDRESS_ADDR sdio 1 addr:0x%08x rdvl:0x%08x\n",SDMA_SYSTEM_ADDRESS_ADDR,rc);
    printf("Write addr0:0x%08x wrVal:0x%08x\n",SDMA_SYSTEM_ADDRESS_ADDR, SDIO_OCM_PHYS_ADDR_RD);

	cmd =     (17 << 24)  	/* Single read Command Index */
    		| ( 0 << 22)   	/* Command type */
	    	| ( 1 << 21)    /* Data Present */
		    | ( 1 << 20) 	/* Command Index check enable */
    		| ( 1 << 19)	/* Command CRC check enable */
	    	| ( 2 << 16)	/* Response type - R1 */
		    | ( 1 << 4) 	/* Read Direction */
    		| ( 1 << 1)	    /* Enable block count */
	    	| ( 1 << 0)	    /* DMA Enable */
	    	| ( 0 << 2)	    /* AUTO CMD12 Enable */
		    | ( 0 << 5);	/* Multiple Block Select */

    temp = ((1 << 16) | SDIO_BLOCK_SIZE);
	WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, temp);   /*  writing both block count(=1) and block size regs  */
    printf("Write addr1:0x%08x wrVal:0x%08x\n",BLOCK_DEF_ADDR, temp);

	WRITE_SDIO(sdio_no,ARGUMENT_ADDR, lba);
    printf("Write addr2:0x%08x wrVal:0x%08x\n",ARGUMENT_ADDR, lba);

	WRITE_SDIO(sdio_no,TRANSFERMODE_COMMAND_ADDR, cmd);
    ipp_udelay(DELAY_1);
    printf("Write addr3:0x%08x wrVal:0x%08x\n",TRANSFERMODE_COMMAND_ADDR, cmd);

	/* Wait for transfer to complete or error bit set */
    //timeout=10000000; //test for 25Mhz
    timeout=100; //test for 50Mhz
	while (1)
	{
        istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
        printf("Read addr1:0x%08x rdVal1:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
		if ((istat & 0x00000003)) {
            if(istat & 0x00000001) {
                printf("Read Command Done\n");
 	            istat = istat & 0x00000001;
                WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
                printf("Clear INT addr:0x%08x data:0x%08x\n",INTERRUPT_STATUS_ADDR,istat);

                istat = READ_SDIO(sdio_no,RESPONSE_0_1_ADDR);
                printf("READ RESPONSE_0_1_ADDR addr:0x%08x wrVal:0x%08x\n",RESPONSE_0_1_ADDR, istat);

                istat = READ_SDIO(sdio_no,RESPONSE_2_3_ADDR);
                printf("READ RESPONSE_2_3_ADDR addr:0x%08x wrVal:0x%08x\n",RESPONSE_2_3_ADDR, istat);
            }
            if(istat & 0x00000002) {
                printf("Read Data Transfer Done\n");
                istat = istat & 0x00000002;
	            WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
                printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
			    //return IPP_OK;
                break;
            }
		}

		if (istat & 0xFFFF8000) {
            printf( "Fail Read Data\n");
			WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
            printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
		}

        timeout--;
        if(timeout == 0) {
            printf("Timeout Read Data\n");
            break;
        }
	}

	WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
    printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);

    //debug data from SD card read out
    printf("After transfer data1...\n\n\r");
    data_read_add = &data_read_test[0];
    for (i=1 ; i< (128+1) ;i++ ){
    data = *((volatile unsigned int *)data_read_add);
    printf("address = 0x%08x, wr_data = 0x%08x ",*data_read_add, data);
    data_read_add ++ ;
    if ((i%4)==0) printf("\n\r");
    }
    printf("\n\r read_vfatdev_sdio_block <- out\n");
	return IPP_OK;
}

//===================================================================================================//
//-------------- SDMA Mode Start -------------------------

unsigned int read_vfatdev_sdio_sdma_multi_block(u8 sdio_no,unsigned int lba ,u16 blkNo)
{
	unsigned int cmd,rc,i;
	unsigned int istat,temp,timeout=0;
    unsigned int *data_read_add = &data_read_test[1];
    unsigned int data ,n ;
    //unsigned int ocm_mem_addr = 0xc0001000;
    //unsigned int ocm_mem_addr = 0x02E10100;
    unsigned int ocm_mem_addr = 0x1d0c1000; //  0x02E20100;
    //printf("\nread_vfatdev_sdio_block -> in\n");
    //printf("lba:0x%x\n",lba);

    data_read_add = ocm_mem_addr ; // just test for OCM mem

        	for ( n =0 ; n < blkNo ; n++){
        	data_read_add = data_read_add + 96*n ;
        	  for (i=1 ; i< (32+1) ; i++){
        	    *((volatile unsigned int *)data_read_add)= 0x5A5A5A5A;
                data_read_add ++ ;
        	    }
        	}


    data_read_add = ocm_mem_addr ; // just test for OCM mem
     printf("Before transfer data0...\n");
    	for ( n =0 ; n < blkNo ; n++){
    	printf("\n\nBlock %d ...\n",n);
    	data_read_add = data_read_add + 96*n ;
    	  for (i=1 ; i< (32+1) ; i++){
    	    data = *((volatile unsigned int *)data_read_add);
//    	    printf("addr = 0x%08x, data = 0x%08x, ",data_read_add, data);
            data_read_add ++ ;
//    	    if ((i%4)==0) printf("\n\r");
    	    }
    	}
    printf("DONE CHECK \n\n");

	data_read_add = ocm_mem_addr ; // just test for OCM mem
	printf("Fill data1...\n");
			for ( n =0 ; n < blkNo ; n++){
			data_read_add = data_read_add + 96*n ;
			  for (i=1 ; i< (32+1) ; i++){
				*((volatile unsigned int *)data_read_add)= 0xffffffff;
				data_read_add ++ ;
				}
			}

	data_read_add = ocm_mem_addr ; // just test for OCM mem
	 printf("Before transfer data1...\n");
		for ( n =0 ; n < blkNo ; n++){
		printf("\n\nBlock %d ...\n",n);
		data_read_add = data_read_add + 96*n ;
		  for (i=1 ; i< (32+1) ; i++){
			data = *((volatile unsigned int *)data_read_add);
//    	    printf("addr = 0x%08x, data = 0x%08x, ",data_read_add, data);
			data_read_add ++ ;
//			if ((i%4)==0) printf("\n\r");
			}
		}
		printf("\n\n");

    timeout=100;
//    printf("\nWait for CMD line Free,");
	do {
	    istat = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
        timeout--;
        if(timeout == 0) {
            printf("Timeout for CMD line Free addr:0x%08x rdvl:0x%08x\n",PRESENT_STATE_ADDR,istat);
			//return IPP_ERR_FAIL;  //
            break;
        }
        if((istat & 0x01) == 0x00)
            break;
	} while (1);
    //printf("Done\n");

#if 1
	//if (!high_capacity[sdio_no-1]) {
//	if (!high_capacity) {
		lba *= SDIO_BLOCK_SIZE;
		//printf("high_cpacity:%d lba:0x%x\n",high_capacity[sdio_no-1], lba);
//    }
#endif

	istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
	arch_timer_msdelay(10);
    WRITE_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR, ocm_mem_addr);  // just test for OCM
	//WRITE_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR, SDIO_OCM_PHYS_ADDR_RD);
	 //WRITE_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR, &data_read_test[0]);
	 rc  = READ_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR);
	 printf("SDMA_SYSTEM_ADDRESS_ADDR sdio 1 addr:0x%08x rdvl:0x%08x\n",SDMA_SYSTEM_ADDRESS_ADDR,rc);
    //printf("Write addr:0x%08x wrVal:0x%08x\n",SDMA_SYSTEM_ADDRESS_ADDR, SDIO_OCM_PHYS_ADDR_RD);

	cmd =     (18 << 24)  	/* Multiple Read Command Index */
			| ( 0 << 22)   	/* Command type */
			| ( 1 << 21)    /* Data Present */
			| ( 1 << 20) 	/* Command Index check enable */
			| ( 1 << 19)	/* Command CRC check enable */
			| ( 2 << 16)	/* Response type - R1 */
			| ( 1 << 4) 	/* Read Direction */
			| ( 1 << 1)	    /* Enable block count */
			| ( 1 << 0)	    /* DMA Enable */
			| ( 2 << 2)	    /* AUTO CMD12 Enable */
			| ( 1 << 5);	/* Multiple Block Select */


	//temp = ((1 << 16) | SDIO_BLOCK_SIZE);
	//temp = ((blkNo << 16) | SDIO_BLOCK_SIZE);
	//temp = (((blkNo*2) << 16) | SDIO_BLOCK_SIZE);
	//temp = (((blkNo*3) << 16) | SDIO_BLOCK_SIZE);
	//temp = (((blkNo*4) << 16) | SDIO_BLOCK_SIZE)|(3<<12);
	//temp = (((blkNo*4) << 16) | SDIO_BLOCK_SIZE)|(7<<12);
	temp = (((blkNo*8) << 16) | SDIO_BLOCK_SIZE)|(7<<12);
	//temp = ((blkNo << 16) | SDIO_BLOCK_SIZE)|(7<<12);
	//temp = ((blkNo << 16) | SDIO_BLOCK_SIZE)|(3<<12);
	//temp = (((blkNo*2) << 16) | SDIO_BLOCK_SIZE)|(3<<12);
	arch_timer_msdelay(10);
	WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, temp);   /*  writing both block count(=blkNo) and block size regs  */
//    printf("BLOCK_DEF_ADDR:0x%08x wrVal:0x%08x\n",BLOCK_DEF_ADDR, temp);
	arch_timer_msdelay(10);
	WRITE_SDIO(sdio_no,ARGUMENT_ADDR, lba);
//    printf("Write addr:0x%08x wrVal:0x%08x\n",ARGUMENT_ADDR, lba);

retry_sdma_multi:

    cmd = 0x123a0037 ; // khuynh test cmd + transfer mode // run OK
	WRITE_SDIO(sdio_no,TRANSFERMODE_COMMAND_ADDR, cmd);
//    ipp_udelay(DELAY_1);
//    printf("\nretry_sdma_multi \r\n,");
//    printf("TRANSFERMODE_COMMAND_ADDR:0x%08x wrVal:0x%08x\n",TRANSFERMODE_COMMAND_ADDR, cmd);

	/* Wait for transfer to complete or error bit set */
    timeout=100;
//    ipp_udelay(DELAY_1);
//    printf("\timeout = 100 \r\n,");
	while (1)
	{
        istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
        printf("INTERRUPT_STATUS_ADDR:0x%08x rdVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);

        //fix SDMA multi block bug
        if(istat & 0x00000008){
        	//istat = istat & 0x00000008;
        	//WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);

        	rc  = READ_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR);
        	printf("Fix bug SDMA multi ...\n");
        	WRITE_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR, rc);

        	data = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
        	printf("BLOCK_DEF_ADDR debug :0x%08x wrVal:0x%08x\n",BLOCK_DEF_ADDR, data);
        	//goto retry_sdma_multi;
        }
		if ((istat & 0x00000003)) {
            if(istat & 0x00000001) {
                printf("Read Command Done\n");
                //printf("Read addr:0x%08x rdVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
 	            //istat = istat | 0x00000001;
                istat = istat & 0x00000001;
                WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
                //printf("Clear INT addr:0x%08x data:0x%08x\n",INTERRUPT_STATUS_ADDR,istat);

                //istat = READ_SDIO(sdio_no,RESPONSE_0_1_ADDR);
                //printf("READ RESPONSE_0_1_ADDR addr:0x%08x wrVal:0x%08x\n",RESPONSE_0_1_ADDR, istat);

                //istat = READ_SDIO(sdio_no,RESPONSE_2_3_ADDR);
                //printf("READ RESPONSE_2_3_ADDR addr:0x%08x wrVal:0x%08x\n",RESPONSE_2_3_ADDR, istat);
            }
            if(istat & 0x00000002) {
                printf("Read Data Transfer Done\n");
                istat = istat & 0x00000002;
	            WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
                printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
			    //return IPP_OK;
                break;
            }
		}
/*
		if (istat & 0xFFFF8000) {
            printf( "Fail Read Data\n");
			WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
            printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
		}
*/
        timeout--;
        if(timeout == 0) {
            printf("Timeout Read Data\n");
            break;
        }
	}

	//test block
	data = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
//	printf("BLOCK_DEF_ADDR after :0x%08x wrVal:0x%08x\n",BLOCK_DEF_ADDR, data);
	arch_timer_msdelay(10);

	WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
    printf("INTERRUPT_STATUS_ADDR addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);

    //data_read_add = &data_read_test[0];
    data_read_add = ocm_mem_addr ;  // just test for OCM
    //debug data from SD card read out
    printf("After...\n");
        	for ( n =0 ; n < blkNo ; n++){
//        	printf("\n\nBlock %d ...\n",n);
        	data_read_add = data_read_add + 96*n ;
        	  for (i=1 ; i< (32+1) ; i++){
        	    data = *((volatile unsigned int *)data_read_add);
        	    printf("addr = 0x%08x, rd_data = 0x%08x, ",data_read_add, data);
                data_read_add ++ ;
        	    if ((i%4)==0) printf("\n\r");
//    			if (data != 0x5A5A5A5A)
    			if (data != 0xcafe0000 + i)
    				return IPP_ERR_FAIL;

        	    }
        	}
//    printf("\n\n");
    printf("\n\r read_vfatdev_sdio_block <- out\n");
	return IPP_OK;
}
//===================================================================================================
unsigned int write_vfatdev_sdio_sdma_multi_block(u8 sdio_no,unsigned int lba ,u16 blkNo)
{
	unsigned int cmd,rc,i;
	unsigned int istat,temp,timeout=0;
    unsigned int *data_read_add = &data_read_test[0];
    unsigned int data ,n ;
    //unsigned int ocm_mem_addr = 0xc0001000;
    //unsigned int ocm_mem_addr = 0x02E10100;
    unsigned int ocm_mem_addr = 0x1d0c0000; //  0x02E20100;
    //printf("\nread_vfatdev_sdio_block -> in\n");
    //printf("lba:0x%x\n",lba);

    data_read_add = ocm_mem_addr ; // just test for OCM mem
    printf("Fill data...\n");
        	for ( n =0 ; n < blkNo ; n++){
        	data_read_add = data_read_add + 96*n ;
        	  for (i=1 ; i< (32+1) ; i++){
//        	    *((volatile unsigned int *)data_read_add)= 0x5A5A5A5A;
        	    *((volatile unsigned int *)data_read_add)= 0xcafe0000 + i;
                data_read_add ++ ;
        	    }
        	}


    data_read_add = ocm_mem_addr ; // just test for OCM mem
     printf("Before transfer data...\n");
    	for ( n =0 ; n < blkNo ; n++){
    	printf("\n\nBlock %d ...\n",n);
    	data_read_add = data_read_add + 96*n ;
    	  for (i=1 ; i< (32+1) ; i++){
    	    data = *((volatile unsigned int *)data_read_add);
    	    printf("addr = 0x%08x, wr_data = 0x%08x, ",data_read_add, data);
            data_read_add ++ ;
    	    if ((i%4)==0) printf("\n\r");
    	    }
    	}
    	printf("\n\n");

    timeout=100;
    //printf("\nWait for CMD line Free,");
	do {
	    istat = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
        timeout--;
        if(timeout == 0) {
            printf("Timeout for CMD line Free addr:0x%08x rdvl:0x%08x\n",PRESENT_STATE_ADDR,istat);
// 			return IPP_ERR_FAIL;
            break;
        }
        if((istat & 0x01) == 0x00)
            break;
	} while (1);
    //printf("Done\n");

#if 1
	//if (!high_capacity[sdio_no-1]) {
//	if (!high_capacity) {
		lba *= SDIO_BLOCK_SIZE;
		//printf("high_cpacity:%d lba:0x%x\n",high_capacity[sdio_no-1], lba);
//    }
#endif

	istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);

    WRITE_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR, ocm_mem_addr);  // just test for OCM
	//WRITE_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR, SDIO_OCM_PHYS_ADDR_RD);
	 //WRITE_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR, &data_read_test[0]);
	 rc  = READ_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR);
	 printf("SDMA_SYSTEM_ADDRESS_ADDR sdio 1 addr:0x%08x rdvl:0x%08x\n",SDMA_SYSTEM_ADDRESS_ADDR,rc);
    //printf("Write addr:0x%08x wrVal:0x%08x\n",SDMA_SYSTEM_ADDRESS_ADDR, SDIO_OCM_PHYS_ADDR_RD);

	cmd =     (24 << 24)  	/* Single write Command Index */
		    	| ( 0 << 22)   	/* Command type */
			    | ( 1 << 21)    /* Data Present */
	    		| ( 1 << 20) 	/* Command Index check enable */
		    	| ( 1 << 19)	/* Command CRC check enable */
			    | ( 2 << 16)	/* Response type - R1 */
	    		| ( 0 << 4) 	/* Write Direction */
		    	| ( 1 << 1)	    /* Enable block count */
	    		| ( 1 << 0)	    /* DMA Enable */
		    	| ( 0 << 2)	    /* AUTO CMD12 Enable */
			    | ( 0 << 5);	/* Multiple Block Select */


	  //temp = ((1 << 16) | SDIO_BLOCK_SIZE);
	  temp = (((1) << 16) | SDIO_BLOCK_SIZE)|(7<<12);
	//temp = ((blkNo << 16) | SDIO_BLOCK_SIZE);
	//temp = (((blkNo*2) << 16) | SDIO_BLOCK_SIZE);
	//temp = (((blkNo*3) << 16) | SDIO_BLOCK_SIZE);
	//temp = (((blkNo*4) << 16) | SDIO_BLOCK_SIZE)|(3<<12);
	//temp = (((blkNo*4) << 16) | SDIO_BLOCK_SIZE)|(7<<12);
	//temp = (((blkNo*8) << 16) | SDIO_BLOCK_SIZE)|(7<<12);
	//temp = ((blkNo << 16) | SDIO_BLOCK_SIZE)|(7<<12);
	//temp = ((blkNo << 16) | SDIO_BLOCK_SIZE)|(3<<12);
	//temp = (((blkNo*2) << 16) | SDIO_BLOCK_SIZE)|(3<<12);
	WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, temp);   /*  writing both block count(=blkNo) and block size regs  */
    printf("BLOCK_DEF_ADDR:0x%08x wrVal:0x%08x\n",BLOCK_DEF_ADDR, temp);
	arch_timer_msdelay(10);
	WRITE_SDIO(sdio_no,ARGUMENT_ADDR, lba);
    printf("Write addr:0x%08x wrVal:0x%08x\n",ARGUMENT_ADDR, lba);
	arch_timer_msdelay(10);

retry_sdma_multi_write:

    cmd = 0x193a0027;//khuynh
	WRITE_SDIO(sdio_no,TRANSFERMODE_COMMAND_ADDR, cmd);
    ipp_udelay(DELAY_1);
    printf("TRANSFERMODE_COMMAND_ADDR:0x%08x wrVal:0x%08x\n",TRANSFERMODE_COMMAND_ADDR, cmd);

	/* Wait for transfer to complete or error bit set */
    timeout=100;
    ipp_udelay(DELAY_1);
	while (1)
	{
        istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
        printf("INTERRUPT_STATUS_ADDR:0x%08x rdVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);

        //fix SDMA multi block bug
        if(istat & 0x00000008){
        	//istat = istat & 0x00000008;
        	//WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);

        	rc  = READ_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR);
        	printf("Fix bug SDMA multi ...\n");
        	WRITE_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR, rc);

        	data = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
        	printf("BLOCK_DEF_ADDR debug :0x%08x wrVal:0x%08x\n",BLOCK_DEF_ADDR, data);
        	//goto retry_sdma_multi_write;
        }
		if ((istat & 0x00000003)) {
            if(istat & 0x00000001) {
                printf("Write Command Done\n");
                //printf("Read addr:0x%08x rdVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
 	            //istat = istat | 0x00000001;
                istat = istat & 0x00000001;
                WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
                //printf("Clear INT addr:0x%08x data:0x%08x\n",INTERRUPT_STATUS_ADDR,istat);

                //istat = READ_SDIO(sdio_no,RESPONSE_0_1_ADDR);
                //printf("READ RESPONSE_0_1_ADDR addr:0x%08x wrVal:0x%08x\n",RESPONSE_0_1_ADDR, istat);

                //istat = READ_SDIO(sdio_no,RESPONSE_2_3_ADDR);
                //printf("READ RESPONSE_2_3_ADDR addr:0x%08x wrVal:0x%08x\n",RESPONSE_2_3_ADDR, istat);
            }
            if(istat & 0x00000002) {
                printf("Write Data Transfer Done\n");
                istat = istat & 0x00000002;
	            WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
                printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
			    //return IPP_OK;
                break;
            }
		}
/*
		if (istat & 0xFFFF8000) {
            printf( "Fail Read Data\n");
			WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
            printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
		}
*/
        timeout--;
        if(timeout == 0) {
            printf("Timeout Write Data\n");
            break;
        }
	}

	//test block
	arch_timer_msdelay(10);
	data = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
	printf("BLOCK_DEF_ADDR after :0x%08x wrVal:0x%08x\n",BLOCK_DEF_ADDR, data);
	arch_timer_msdelay(10);
	WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
    printf("INTERRUPT_STATUS_ADDR addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);

    //data_read_add = &data_read_test[0];
    data_read_add = ocm_mem_addr ;  // just test for OCM
    //debug data from SD card read out
//    printf("After transfer data...\n");
//        	for ( n =0 ; n < blkNo ; n++){
//        	printf("\n\nBlock %d ...\n",n);
//        	data_read_add = data_read_add + 96*n ;
//        	  for (i=1 ; i< (32+1) ; i++){
//        	    data = *((volatile unsigned int *)data_read_add);
//        	    printf("addr = 0x%08x, data = 0x%08x ",data_read_add, data);
//                data_read_add ++ ;
//        	    if ((i%4)==0) printf("\n\r");
//        	    }
//        	}
//    printf("\n\n");
    printf("\n\r read_vfatdev_sdio_block <- out\n");
	return IPP_OK;
}
//===================================================================================================
//unsigned int write_vfatdev_sdio_block(u8 sdio_no,unsigned int lba)
//{
//	unsigned int cmd ,rc,i ;
//	unsigned int istat,status_value ,temp,timeout=0;
//	unsigned int *data_write_add = &data_write_test[0];
//	unsigned int data ;
//    //printf("\nwrite_vfatdev_sdio_block -> in\n");
//    //printf("lba:0x%x\n",lba);
////	&data_write_test[0] = 0x1d0c0000;
//	data_write_add = 0x1d0c0000;
//	printf("Fill parttern ...\n\n ");
//	    for (i=1 ; i< (128+1) ; i++){
//	        *((volatile unsigned int *)data_write_add) = 0x55667788;
////	        printf("0x%08x ",data_write_test[i-1]);
//	        printf("0x%08x ",*data_write_add);
//	        data_write_add ++ ;
//	        //if ((i%4)==0) printf("\n\r");
//	        }
//	printf("\n\n ");
//
//    printf("check data...\n\n ");
//    for (i=1 ; i< (128+1) ; i++){
//        data = *((volatile unsigned int *)data_write_add);
//        printf("add = 0x%08x, data = 0x%08x ", data_write_add, data);
//        data_write_add ++ ;
//        if ((i%4)==0) printf("\n\r");
//        }
//    printf("\n\n ");
//
//
//
//
//	istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
//	printf("INTERRUPT_STATUS_ADDR before command :0x%08x rdVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
//
//    timeout=100;
//    //printf("\nWait for CMD line Free,");
//	do {
//	    istat = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
//        timeout--;
//        if(timeout == 0) {
//            printf("Timeout for CMD line Free addr:0x%08x rdvl:0x%08x\n",PRESENT_STATE_ADDR,istat);
//			//return IPP_ERR_FAIL;
//            break;
//        }
//        if((istat & 0x01) == 0x00)
//            break;
//	} while (1);
//    //printf("Done\n");
//
//#if 1
////	if (!high_capacity[sdio_no-1]) {
//	if (!high_capacity) {
//		lba *= SDIO_BLOCK_SIZE;
////      printf("high_cpacity:%d lba:0x%x\n",high_capacity[sdio_no-1], lba);
//    }
//#endif
//	//printf("\n\n\n sdio 1 addr_data_test :0x%08x \n",&data_test[0]);
//	//WRITE_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR, SDIO_OCM_PHYS_ADDR_WR);
//	//WRITE_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR, 0x00200000);
//	//WRITE_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR, 0x00000000);
//	//WRITE_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR, 0x40000200);
//	printf("SDMA write address0 = 0x%08x \r\n", &data_write_test[0]);
//	printf("SDMA write address1 = 0x%08x \r\n", data_write_add);
////	WRITE_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR, &data_write_test[0]);
//	WRITE_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR, data_write_add);
//	//khuynh test
//	rc  = READ_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR);
//	printf("SDMA_SYSTEM_ADDRESS_ADDR sdio 1 addr:0x%08x rdvl:0x%08x\n",SDMA_SYSTEM_ADDRESS_ADDR,rc);
//    //printf("\n\n\nWrite addr:0x%08x wrVal:0x%08x\n",SDMA_SYSTEM_ADDRESS_ADDR, SDIO_OCM_PHYS_ADDR_WR);
//
//	cmd =     (24 << 24)  	/* Single write Command Index */
//	    	| ( 0 << 22)   	/* Command type */
//		    | ( 1 << 21)    /* Data Present */
//    		//| ( 1 << 20) 	/* Command Index check enable */
//	    	//| ( 1 << 19)	/* Command CRC check enable */
//		    | ( 2 << 16)	/* Response type - R1 */
//    		| ( 0 << 4) 	/* Write Direction */
//	    	//| ( 1 << 1)	    /* Enable block count */
//    		| ( 1 << 0)	    /* DMA Enable */
//	    	| ( 0 << 2)	    /* AUTO CMD12 Enable */
//		    | ( 0 << 5);	/* Multiple Block Select */
//
//    temp = ((1 << 16) | SDIO_BLOCK_SIZE);
//    //temp = ((0 << 16) | SDIO_BLOCK_SIZE);
//
//	WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, temp);   /*  writing both block count(=1) and block size regs  */
//    //printf("Write addr:0x%08x wrVal:0x%08x\n",BLOCK_DEF_ADDR, temp);
//
//	WRITE_SDIO(sdio_no,ARGUMENT_ADDR, lba);
//    //printf("Write addr:0x%08x wrVal:0x%08x\n",ARGUMENT_ADDR, lba);
//
//	//khuynh test
////	cmd = 0x183a0900 ;
//	cmd = 0x183a0023 ;  //
//	WRITE_SDIO(sdio_no,TRANSFERMODE_COMMAND_ADDR, cmd);
//    ipp_udelay(DELAY_1);
//    printf("Write addr:0x%08x wrVal:0x%08x\n",TRANSFERMODE_COMMAND_ADDR, cmd);
//
//    ipp_udelay(DELAY_1);
//    istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
//    printf("INTERRUPT_STATUS_ADDR after command :0x%08x rdVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
//
//	/* Wait for transfer to complete or error bit set */
//    timeout=100;
//	while (1) {
//
//	    istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
//        printf("Read addr:0x%08x rdVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
//        if(istat & 0x00000003) {
//        //if(istat & 0x00000002) {
//            if(istat & 0x00000001) {
//                printf("Write Command Done\n");
//    	        //istat = istat & 0x00000001;
//                istat = istat | 0x00000001;
//                WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
//                //printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
//
//                istat = READ_SDIO(sdio_no,RESPONSE_0_1_ADDR);
//                //printf("READ RESPONSE_0_1_ADDR addr:0x%08x wrVal:0x%08x\n",RESPONSE_0_1_ADDR, istat);
//
//                istat = READ_SDIO(sdio_no,RESPONSE_2_3_ADDR);
//                //printf("READ RESPONSE_2_3_ADDR addr:0x%08x wrVal:0x%08x\n",RESPONSE_2_3_ADDR, istat);
//
//                istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
//                //printf("Read addr:0x%08x rdVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
//            }
//            if(istat & 0x00000002) {
//                printf("Write Data Transfer Done\n");
//                istat = istat | 0x00000002;
//	            WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
//                //printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
//                //return 0;
//	            break;
//            }
//        }
///*
//		if (istat & 0xFFFF8000) {
//            printf( "Fail Write Data\n");
//			WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
//            printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
//		}
//*/
//        if(timeout == 0) {
//            printf("Timeout Write Data\n");
//            break;
//        }
//
//        timeout--;
//	}
//
//	status_value = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
//	printf("PRESENT_STATE_ADDR:0x%08x wrVal:0x%08x\n",PRESENT_STATE_ADDR, status_value);
//
//	WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
//    printf("CLear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
//
//    printf("write_vfatdev_sdio_block <- out\n");
//	return IPP_OK;
//}
//=========================================================================================================//
//--------------------------           ADMA Mode        ---------------------------------------------------//
//=========================================================================================================//
//unsigned int read_vfatdev_sdio_adma_mono_block(u8 sdio_no,unsigned int lba)
//{
//	unsigned int cmd,rc,i;
//	unsigned int istat,temp,timeout=0;
//    unsigned int *data_for_table_adma_temp = &data_for_table_adma_0[0];
//    unsigned int *data_read_add = &addr_for_data_adma_0[0];
//    unsigned int data , data_write ;
//    //printf("\nread_vfatdev_sdio_block -> in\n");
//    //printf("lba:0x%x\n",lba);
//
//    printf("Before transfer data...\n\n ");
//    data_read_add = 0x1d0c0000 ; // just test for OCM mem
//    printf("Fill data...\n");
//	for (i=1 ; i< (128+1) ; i++){
//	    *((volatile unsigned int *)data_read_add)= 0x12345678;
//		data_read_add ++ ;
////		if ((i%4)==0) printf("\n\r");
//		}
//
//
//    printf("Before transfer data...\n\n ");
//    data_read_add = 0x1d0c0000; //0x02000000;      // test ADMA1
//    for (i=1 ; i< (128+1) ; i++){
//        data = *((volatile unsigned int *)data_read_add);
//        printf("add = 0x%08x, data =0x%08x ",data_read_add, data);
//        data_read_add ++ ;
//        if ((i%4)==0) printf("add0 = 0x%08x, data =0x%08x ",data_read_add, data);
//        }
//    printf("Before transfer data...\n\n ");
//    data_read_add = 0x1d0c0000 ; // just test for OCM mem
//    printf("Fill data...\n");
//	for (i=1 ; i< (128+1) ; i++){
//	    *((volatile unsigned int *)data_read_add)= 0xFFFFFFFF;
//		data_read_add ++ ;
////		if ((i%4)==0) printf("\n\r");
//		}
//
//
//    printf("Before transfer data...\n\n ");
//    data_read_add = 0x1d0c0000; //0x02000000;      // test ADMA1
//    for (i=1 ; i< (128+1) ; i++){
//        data = *((volatile unsigned int *)data_read_add);
//        printf("add = 0x%08x, data =0x%08x ",data_read_add, data);
//        data_read_add ++ ;
//        if ((i%4)==0) printf("add0 = 0x%08x, data =0x%08x ",data_read_add, data);
//        }
//    printf("\n\n ");
//    //timeout=10000000;
//    timeout=100; //test for 50Mhz
//    printf("\nWait for CMD line Free,");
//	do {
//	    istat = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
//        timeout--;
//        if(timeout == 0) {
//            printf("Timeout for CMD line Free addr:0x%08x rdvl:0x%08x\n",PRESENT_STATE_ADDR,istat);
//			//return IPP_ERR_FAIL;
//            break;  // test 50MHz
//        }
//        if((istat & 0x01) == 0x00)
//            break;
//	} while (1);
//    //printf("Done\n");
//
//#if 1
//	//if (!high_capacity[sdio_no-1]) {
//	if (!high_capacity) {
//		lba *= SDIO_BLOCK_SIZE;
//		//printf("high_cpacity:%d lba:0x%x\n",high_capacity[sdio_no-1], lba);
//    }
//#endif
//
//	 printf("ADMA_ADDRESS_LOW_ADDR: 0x%08x \r\n", &data_for_table_adma_0[0] );
//	 WRITE_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR, &data_for_table_adma_0[0]);
//	 rc  = READ_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR);
//	 printf("ADMA_ADDRESS_LOW_ADDR sdio 1 addr:0x%08x rdvl:0x%08x\n",ADMA_ADDRESS_LOW_ADDR,rc);
//
//	 WRITE_SDIO(sdio_no,ADMA_ADDRESS_HIGH_ADDR,0x00000000);
//	 rc  = READ_SDIO(sdio_no,ADMA_ADDRESS_HIGH_ADDR);
//	 printf("ADMA_ADDRESS_HIGH_ADDR sdio 1 addr:0x%08x rdvl:0x%08x\n",ADMA_ADDRESS_HIGH_ADDR,rc);
//
//
//	 //prepare table for ADMA
//     //data_write = 0x21000002 ;
//	 data_write = 0x23000002 ;   //512 bytes
//	 data_write = sd_bswap32(0x23000002) ;
//     rc = sdio_out32(data_for_table_adma_temp,data_write);
//      printf("data_temp0 = 0x%08x, data = 0x%08x ",data_for_table_adma_temp, data_write);
//     data_for_table_adma_temp ++ ;
//
//     data_read_add = &addr_for_data_adma_0[0];
//     printf("data_read_add 0x%08x ",data_read_add);
////     data_write = sd_bswap32(data_read_add) ;
//     //data_write = data_read_add ;
//     rc = sdio_out32(data_for_table_adma_temp,data_write);
//     data_for_table_adma_temp ++ ;
//
//     data_write = 0x07000000 ;
//     data_write = sd_bswap32(0x07000000) ;
//     rc = sdio_out32(data_for_table_adma_temp,data_write);
//     printf("data_temp1 = 0x%08x, data = 0x%08x ",data_for_table_adma_temp, data_write);
//
//     //test data of table
//     printf("Test data of table1...\n\n ");
//     data_for_table_adma_temp = &data_for_table_adma_0[0];
//         for (i=1 ; i<17 ; i++){
//         data = *((volatile unsigned int *)data_for_table_adma_temp);
//         printf("data_temp = 0x%08x, data = 0x%08x ",data_for_table_adma_temp, data);
//         data_for_table_adma_temp ++ ;
//         if ((i%4)==0) printf("data1 = 0x%08x \n\r", data);
//         }
//
//
//
//    //printf("Write addr:0x%08x wrVal:0x%08x\n",SDMA_SYSTEM_ADDRESS_ADDR, SDIO_OCM_PHYS_ADDR_RD);
//
//	cmd =     (17 << 24)  	/* Single read Command Index */
//    		| ( 0 << 22)   	/* Command type */
//	    	| ( 1 << 21)    /* Data Present */
//		    | ( 1 << 20) 	/* Command Index check enable */
//    		| ( 1 << 19)	/* Command CRC check enable */
//	    	| ( 2 << 16)	/* Response type - R1 */
//		    | ( 1 << 4) 	/* Read Direction */
//    		| ( 1 << 1)	    /* Enable block count */
//		    | ( 0 << 1)	    /* Disable block count */
//	    	| ( 1 << 0)	    /* DMA Enable */
//	    	| ( 0 << 2)	    /* AUTO CMD12 Enable */
//	    	| ( 1 << 2)	    /* AUTO CMD12 Enable */
//		    | ( 0 << 5);	/* Multiple Block Select */
//
//
//    temp = ((1 << 16) | SDIO_BLOCK_SIZE);
//    temp = sd_bswap32(temp) ;
//	WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, temp);   /*  writing both block count(=1) and block size regs  */
//    printf("Write addr:0x%08x wrVal:0x%08x\n",BLOCK_DEF_ADDR, temp);
//
//	WRITE_SDIO(sdio_no,ARGUMENT_ADDR, lba);
//    printf("Write addr:0x%08x wrVal:0x%08x\n",ARGUMENT_ADDR, lba);
//
//	WRITE_SDIO(sdio_no,TRANSFERMODE_COMMAND_ADDR, cmd);
//    ipp_udelay(DELAY_1);
//    printf("Write addr:0x%08x wrVal:0x%08x\n",TRANSFERMODE_COMMAND_ADDR, cmd);
//
//	/* Wait for transfer to complete or error bit set */
//    //timeout=10000000; //test for 25Mhz
//    timeout=100; //test for 50Mhz
//	while (1)
//	{
//        istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
//        printf("INTERRUPT_STATUS_ADDR:0x%08x rdVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
//		if ((istat & 0x00000003)) {
//            if(istat & 0x00000001) {
//                printf("Read Command Done\n");
// 	            istat = istat & 0x00000001;
//                WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
//                printf("Clear INT addr:0x%08x data:0x%08x\n",INTERRUPT_STATUS_ADDR,istat);
//
//                istat = READ_SDIO(sdio_no,RESPONSE_0_1_ADDR);
//                printf("READ RESPONSE_0_1_ADDR addr:0x%08x wrVal:0x%08x\n",RESPONSE_0_1_ADDR, istat);
//
//                istat = READ_SDIO(sdio_no,RESPONSE_2_3_ADDR);
//                printf("READ RESPONSE_2_3_ADDR addr:0x%08x wrVal:0x%08x\n",RESPONSE_2_3_ADDR, istat);
//            }
//            if(istat & 0x00000002) {
//                printf("Read Data Transfer Done\n");
//                istat = istat & 0x00000002;
//	            WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
//                printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
//			    //return IPP_OK;
//                break;
//            }
//		}
//
////		if (istat & 0xFFFF8000) {
////            printf( "Fail Read Data\n");
////			WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
////            printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
////		}
//
//        timeout--;
//        if(timeout == 0) {
//            printf("Timeout Read Data\n");
//            break;
//        }
//	}
//
//	WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
//    printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
//
//    //debug data from SD card read out
//    printf("After transfer data...\n\n\r");
//    //data_read_add = &addr_for_data_adma_0[0];
//    data_read_add = 0x1d0c0000; // 0x02000000;           // test ADMA1
//    for (i=1 ; i< (128+1) ;i++ ){
//    data = *((volatile unsigned int *)data_read_add);
//    printf("add = 0x%08x, data =0x%08x ",data_read_add, data);
////    printf("0x%08x ",data);
//    data_read_add ++ ;
//    if ((i%4)==0) printf("\n\r");
//    }
//    printf("\n\r read_vfatdev_sdio_block <- out\n");
//	return IPP_OK;
//}


//=========================================================================================================
//unsigned int write_vfatdev_sdio_adma_mono_block(u8 sdio_no,unsigned int lba)
//{
//	unsigned int cmd,rc,i;
//	unsigned int istat,temp,timeout=10;
//    unsigned int *data_for_table_adma_temp = &data_for_table_adma_0[1];
//    unsigned int *data_read_add = &addr_for_data_adma_0[1];
//    unsigned int data , data_write ;
//    //printf("\nread_vfatdev_sdio_block -> in\n");
//    //printf("lba:0x%x\n",lba);
//
//    printf("Before transfer data...\n\n ");
//    data_read_add = 0x1d0c0000 ; // just test for OCM mem
//    printf("Fill data...\n");
//	for (i=1 ; i< (128+1) ; i++){
//	    *((volatile unsigned int *)data_read_add)= 0xABABABAB;
//		data_read_add ++ ;
//		if ((i%4)==0) printf("\n\r");
//		}
//
//    data_read_add = 0x1d0c0000; //  0x02000000;      //test ADMA1
//
//    for (i=1 ; i< (128+1) ; i++){
//        data = *((volatile unsigned int *)data_read_add);
//	    printf("addr = 0x%08x, data = 0x%08x ",data_read_add, data);
//        data_read_add ++ ;
//        if ((i%4)==0) printf("\n\r");
//        }
//    printf("\n\n ");
//    //timeout=10000000;
//    //timeout=1000; //test for 50Mhz
//    //printf("\nWait for CMD line Free,");
//	do {
//	    istat = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
//        timeout--;
//        if(timeout == 0) {
//            printf("Timeout for CMD line Free addr:0x%08x rdvl:0x%08x\n",PRESENT_STATE_ADDR,istat);
//			//return IPP_ERR_FAIL;
//            break;  // test 50MHz
//        }
//        if((istat & 0x01) == 0x00)
//            break;
//	} while (1);
//    //printf("Done\n");
//
//#if 1
//	//if (!high_capacity[sdio_no-1]) {
//	if (!high_capacity) {
//		lba *= SDIO_BLOCK_SIZE;
//		//printf("high_cpacity:%d lba:0x%x\n",high_capacity[sdio_no-1], lba);
//    }
//#endif
//
//
/////	 WRITE_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR, &data_for_table_adma_0[0]);
//	 WRITE_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR, &data_for_table_adma_0[0]);
//	 rc  = READ_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR);
//	 printf("ADMA_ADDRESS_LOW_ADDR sdio 1 addr:0x%08x rdvl:0x%08x\n",ADMA_ADDRESS_LOW_ADDR,rc);
//
//	 WRITE_SDIO(sdio_no,ADMA_ADDRESS_HIGH_ADDR,0x00000000);
//	 rc  = READ_SDIO(sdio_no,ADMA_ADDRESS_HIGH_ADDR);
//	 printf("ADMA_ADDRESS_HIGH_ADDR sdio 1 addr:0x%08x rdvl:0x%08x\n",ADMA_ADDRESS_HIGH_ADDR,rc);
//
//	 //prepare table for ADMA
//     //data_write = 0x21000002 ;
//	 data_write = 0x23000002 ;   //512 bytes
//	 data_write = sd_bswap32(0x23000002) ;
//     rc = sdio_out32(data_for_table_adma_temp,data_write);
//     data_for_table_adma_temp ++ ;
//
//     data_read_add = &addr_for_data_adma_0[0];
//     printf("data_read_add 0x%08x ",data_read_add);
////     data_write = sd_bswap32(data_read_add) ;
//     //data_write = data_read_add ;
//     rc = sdio_out32(data_for_table_adma_temp,data_write);
//     data_for_table_adma_temp ++ ;
//
//     data_write = 0x07000000 ;
//     data_write = sd_bswap32(0x07000000) ;
//     rc = sdio_out32(data_for_table_adma_temp,data_write);
//
//     //test data of table
//     printf("Test data of table...\n\n ");
//     data_for_table_adma_temp = &data_for_table_adma_0[0];
//         for (i=1 ; i<17 ; i++){
//         data = *((volatile unsigned int *)data_for_table_adma_temp);
//         printf("addr = 0x%08x, data = 0x%08x ",data_for_table_adma_temp, data);
//         data_for_table_adma_temp ++ ;
//         if ((i%4)==0) printf("\n\r");
//         }
//
//
//
//    //printf("Write addr:0x%08x wrVal:0x%08x\n",SDMA_SYSTEM_ADDRESS_ADDR, SDIO_OCM_PHYS_ADDR_RD);
//
//	cmd =     (24 << 24)  	/* Single write Command Index */
//			    	| ( 0 << 22)   	/* Command type */
//				    | ( 1 << 21)    /* Data Present */
//		    		| ( 1 << 20) 	/* Command Index check enable */
//			    	| ( 1 << 19)	/* Command CRC check enable */
//				    | ( 2 << 16)	/* Response type - R1 */
//		    		| ( 0 << 4) 	/* Write Direction */
//			    	| ( 1 << 1)	    /* Enable block count */
//		    		| ( 1 << 0)	    /* DMA Enable */
////			    	| ( 1 << 2)	    /* AUTO CMD12 Enable */
//			    	| ( 0 << 2)	    /* AUTO CMD12 Enable */
//				    | ( 0 << 5);	/* Multiple Block Select */
//
//    temp = ((1 << 16) | SDIO_BLOCK_SIZE);
//    temp = sd_bswap32(temp) ;
//	WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, temp);   /*  writing both block count(=1) and block size regs  */
//    printf("Write addr:0x%08x wrVal:0x%08x\n",BLOCK_DEF_ADDR, temp);
//
//	WRITE_SDIO(sdio_no,ARGUMENT_ADDR, lba);
//    printf("Write addr:0x%08x wrVal:0x%08x\n",ARGUMENT_ADDR, lba);
//
//	WRITE_SDIO(sdio_no,TRANSFERMODE_COMMAND_ADDR, cmd);
//    ipp_udelay(DELAY_1);
//    printf("Write addr:0x%08x wrVal:0x%08x\n",TRANSFERMODE_COMMAND_ADDR, cmd);
//
//	/* Wait for transfer to complete or error bit set */
//    //timeout=10000000; //test for 25Mhz
//    timeout=10; //test for 50Mhz
//	while (1)
//	{
//        istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
//        printf("INTERRUPT_STATUS_ADDR:0x%08x rdVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
//		if ((istat & 0x00000003)) {
//            if(istat & 0x00000001) {
//                printf("Write Command Done\n");
// 	            istat = istat & 0x00000001;
//                WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
//                printf("Clear INT addr:0x%08x data:0x%08x\n",INTERRUPT_STATUS_ADDR,istat);
//
//                istat = READ_SDIO(sdio_no,RESPONSE_0_1_ADDR);
////                printf("READ RESPONSE_0_1_ADDR addr:0x%08x wrVal:0x%08x\n",RESPONSE_0_1_ADDR, istat);
////
//                istat = READ_SDIO(sdio_no,RESPONSE_2_3_ADDR);
////                printf("READ RESPONSE_2_3_ADDR addr:0x%08x wrVal:0x%08x\n",RESPONSE_2_3_ADDR, istat);
//            }
//            if(istat & 0x00000002) {
//                printf("Write Data Transfer Done\n");
//                istat = istat & 0x00000002;
//	            WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
//                printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
//			    //return IPP_OK;
//                break;
//            }
//		}
//
////		if (istat & 0xFFFF8000) {
////            printf( "Fail Write Data\n");
////			WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
////            printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
////		}
//
//        timeout--;
//        if(timeout == 0) {
//            printf("Timeout Read Data\n");
//            break;
//        }
//	}
//
//	WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
//    printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
//
//    //debug data from SD card read out
//    printf("After transfer data...\n\n\r");
//    //data_read_add = &addr_for_data_adma_0[0];
//    data_read_add = 0x1d0c0000; //  0x02000000;           //test ADMA1
//    for (i=1 ; i< (128+1) ;i++ ){
//    data = *((volatile unsigned int *)data_read_add);
//    printf("addr = 0x%08x, data 0x%08x ",data_read_add, data);
//    data_read_add ++ ;
//    if ((i%4)==0) printf("\n\r");
//    }
//    printf("\n\r read_vfatdev_sdio_block <- out\n");
//	return IPP_OK;
//}

//==========================================================================================================

//unsigned int write_vfatdev_sdio_adma_multi_block(u8 sdio_no,unsigned int lba)
//{
//	unsigned int cmd,rc,i;
//	unsigned int istat,temp,timeout=1000;
//    unsigned int *data_for_table_adma_temp = &data_for_table_adma_0[0];
//    unsigned int *data_read_add = &addr_for_data_adma_0[0];
//    unsigned int data , data_write ;
//    //printf("\nread_vfatdev_sdio_block -> in\n");
//    //printf("lba:0x%x\n",lba);
//
//    printf("Before transfer data...\n\n ");
//    //data_read_add = 0x00000007;      //test ADMA1
//    data_read_add = &data_for_table_adma_0[0];      //test ADMA1
//    //data_read_add = &data_for_table_adma_0[0];
//    for (i=1 ; i< (128+1) ; i++){
//        data = *((volatile unsigned int *)data_read_add);
//	    printf("addr = 0x%08x, data = 0x%08x ",data_read_add, data);
//        data_read_add ++ ;
//        if ((i%4)==0) printf("\n\r");
//        }
//    printf("\n\n ");
//    //timeout=10000000;
//    timeout=100; //test for 50Mhz
//    //printf("\nWait for CMD line Free,");
//	do {
//	    istat = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
//	    printf("\nWait for CMD line Free,");
//        timeout--;
//        if(timeout == 0) {
//            printf("Timeout for CMD line Free addr:0x%08x rdvl:0x%08x\n",PRESENT_STATE_ADDR,istat);
//			//return IPP_ERR_FAIL;
//            break;  // test 50MHz
//        }
//        if((istat & 0x01) == 0x00)
//            break;
//	} while (1);
//    //printf("Done\n");
//
//#if 1
//	//if (!high_capacity[sdio_no-1]) {
//	if (!high_capacity) {
//		lba *= SDIO_BLOCK_SIZE;
//		//printf("high_cpacity:%d lba:0x%x\n",high_capacity[sdio_no-1], lba);
//    }
//#endif
//
//     printf("data_for_table_adma_0 = 0x%08x \r\n ",&data_for_table_adma_0[0]);
//	 WRITE_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR, &data_for_table_adma_0[0]);
//	 rc  = READ_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR);
//	 printf("ADMA_ADDRESS_LOW_ADDR sdio 1 addr:0x%08x rdvl:0x%08x\n",ADMA_ADDRESS_LOW_ADDR,rc);
//
//	 WRITE_SDIO(sdio_no,ADMA_ADDRESS_HIGH_ADDR,0x00000000);
//	 rc  = READ_SDIO(sdio_no,ADMA_ADDRESS_HIGH_ADDR);
//	 printf("ADMA_ADDRESS_HIGH_ADDR sdio 1 addr:0x%08x rdvl:0x%08x\n",ADMA_ADDRESS_HIGH_ADDR,rc);
//
//
//	 //prepare table for ADMA
//     //data_write = 0x21000002 ;
//	 //data_write = 0x23000002 ;   //512 bytes run OK
//	 //data_write = 0x23000004 ;     //1KB run OK
//	 data_write = 0x2300002C ;     //8KB run
//	 //data_write = sd_bswap32(0x23000002) ;
//     rc = sdio_out32(data_for_table_adma_temp,data_write);
//     data_for_table_adma_temp ++ ;
///*
//     data_read_add = &addr_for_data_adma_0[0];
//     printf("data_read_add 0x%08x ",data_read_add);
//     data_write = sd_bswap32(data_read_add) ;
//     //data_write = data_read_add ;
//     rc = sdio_out32(data_for_table_adma_temp,data_write);
//     data_for_table_adma_temp ++ ;
//*/
//     data_write = 0x07000000 ;
//     //data_write = sd_bswap32(0x07000000) ;
//     rc = sdio_out32(data_for_table_adma_temp,data_write);
//
//     //test data of table
//     printf("Test data of table...\n\n ");
//     data_for_table_adma_temp = &data_for_table_adma_0[0];
//         for (i=1 ; i<17 ; i++){
//         data = *((volatile unsigned int *)data_for_table_adma_temp);
//         //printf("0x%08x ",data);
// 	     printf("addr = 0x%08x, data = 0x%08x ",data_for_table_adma_temp, data);
//         data_for_table_adma_temp ++ ;
//         if ((i%4)==0) printf("\n\r");
//         }
//
//
//
//    //printf("Write addr:0x%08x wrVal:0x%08x\n",SDMA_SYSTEM_ADDRESS_ADDR, SDIO_OCM_PHYS_ADDR_RD);
//
//
//	cmd =     (25<< 24)  	/* Multiple Write Command Index */
//			| ( 0 << 22)   	/* Command type */
//			| ( 1 << 21)    /* Data Present */
//			| ( 1 << 20) 	/* Command Index check enable */
//			| ( 1 << 19)	/* Command CRC check enable */
//			| ( 2 << 16)	/* Response type - R1 */
//			| ( 0 << 4) 	/* Write Direction */
//			| ( 1 << 1)	/* Enable block count */
//			| ( 1 << 0)	/* DMA Enable */
//			| ( 1 << 2)	/* AUTO CMD12 Enable */
//			//| ( 0 << 2)	/* AUTO CMD12 Disable */
//			//| ( 2 << 2)	/* AUTO CMD23 Disable */
//			| ( 1 << 5);	/* Multiple Block Select */
//    cmd = 0x193a0027;//khuynh
//    //temp = ((1 << 16) | SDIO_BLOCK_SIZE); // return Transfer complete OK !!!
//	//temp = ((2 << 16) | SDIO_BLOCK_SIZE);
//	temp = ((16 << 16) | SDIO_BLOCK_SIZE);
//	//temp = ((8 << 16) | SDIO_BLOCK_SIZE)|(7<<12);
//	WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, temp);   /*  writing both block count(=1) and block size regs  */
//    printf("Write addr:0x%08x wrVal:0x%08x\n",BLOCK_DEF_ADDR, temp);
//
//	WRITE_SDIO(sdio_no,ARGUMENT_ADDR, lba);
//    printf("Write addr:0x%08x wrVal:0x%08x\n",ARGUMENT_ADDR, lba);
//
//	WRITE_SDIO(sdio_no,TRANSFERMODE_COMMAND_ADDR, cmd);
//    ipp_udelay(DELAY_1);
//    printf("Write addr:0x%08x wrVal:0x%08x\n",TRANSFERMODE_COMMAND_ADDR, cmd);
//    ipp_udelay(DELAY_1);
//    ipp_udelay(DELAY_1);
//
//	/* Wait for transfer to complete or error bit set */
//    //timeout=10000000; //test for 25Mhz
//    timeout=100; //test for 50Mhz
//	while (1)
//	{
//		//ipp_udelay(DELAY_1);
//        istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
//        printf("Read addr:0x%08x rdVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
//		if ((istat & 0x00000003)) {
//            if(istat & 0x00000001) {
//                printf("Write Multi Block Command Done\n");
// 	            istat = istat & 0x00000001;
//                WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
//                printf("Clear INT addr:0x%08x data:0x%08x\n",INTERRUPT_STATUS_ADDR,istat);
//
//                istat = READ_SDIO(sdio_no,RESPONSE_0_1_ADDR);
//                printf("READ RESPONSE_0_1_ADDR addr:0x%08x wrVal:0x%08x\n",RESPONSE_0_1_ADDR, istat);
//
//                istat = READ_SDIO(sdio_no,RESPONSE_2_3_ADDR);
//                printf("READ RESPONSE_2_3_ADDR addr:0x%08x wrVal:0x%08x\n",RESPONSE_2_3_ADDR, istat);
//            }
//            if(istat & 0x00000002) {
//                printf("Write Multi Block Data Transfer Done\n");
//                istat = istat & 0x00000002;
//	            WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
//                printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
//			    //return IPP_OK;
//                break;
//            }
//		}
//
//		if (istat & 0xFFFF8000) {
//            printf( "Fail write Data\n");
//			WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
//            printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
//		}
//
//        timeout--;
//        if(timeout == 0) {
//            printf("Timeout Read Data\n");
//            break;
//        }
//	}
//
//	//test block
//	data = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
//	printf("BLOCK_DEF_ADDR after :0x%08x wrVal:0x%08x\n",BLOCK_DEF_ADDR, data);
//
//	WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
//    printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
//
//    //debug data from SD card read out
//    printf("After transfer data...\n\n\r");
//    //data_read_add = &addr_for_data_adma_0[0];
//    data_read_add = &data_for_table_adma_0[0];            //test ADMA1
//    for (i=1 ; i< (128+1) ;i++ ){
//    data = *((volatile unsigned int *)data_read_add);
//    printf("addr = 0x%08x, data = 0x%08x ",data_read_add, data);
//    data_read_add ++ ;
//    if ((i%4)==0) printf("\n\r");
//    }
//    printf("\n\r write_vfatdev_sdio_block <- out\n");
//	return IPP_OK;
//}
//==========================================================================================================
//unsigned int write_vfatdev_sdio_adma_2_multi_block(u8 sdio_no,unsigned int lba,u16 blkNo)
//{
//	unsigned int cmd,rc,i,n;
//	unsigned int istat,temp,timeout=1000;
//    unsigned int *data_for_table_adma_temp = &data_for_table_adma_0[0];
//    unsigned int *data_read_add = &addr_for_data_adma_0[0];
//    unsigned int data , data_write ;
//    //printf("\nread_vfatdev_sdio_block -> in\n");
//    //printf("lba:0x%x\n",lba);
//    unsigned int ocm_mem_addr = 0x1d0c0000; //  0x02E20100;
//
//
//    data_read_add = ocm_mem_addr ; // just test for OCM mem
//    printf("Fill data...\n");
//        	for ( n =0 ; n < blkNo ; n++){
//        	data_read_add = data_read_add + 96*n ;
//        	  for (i=1 ; i< (32+1) ; i++){
//        	    *((volatile unsigned int *)data_read_add)= 0xABABABAB;
//                data_read_add ++ ;
//        	    }
//        	}
//
//
//    data_read_add = ocm_mem_addr ; // just test for OCM mem
//     printf("Before transfer data...\n");
//    	for ( n =0 ; n < blkNo ; n++){
//    	printf("\n\nBlock %d ...\n",n);
//    	data_read_add = data_read_add + 96*n ;
//    	  for (i=1 ; i< (32+1) ; i++){
//    	    data = *((volatile unsigned int *)data_read_add);
//    	    printf("addr = 0x%08x, data = 0x%08x ",data_read_add, data);
//            data_read_add ++ ;
//    	    if ((i%4)==0) printf("\n\r");
//    	    }
//    	}
//    	printf("\n\n");
//
//    timeout=100;
//
//	do {
//	    istat = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
//        timeout--;
//        if(timeout == 0) {
//            printf("Timeout for CMD line Free addr:0x%08x rdvl:0x%08x\n",PRESENT_STATE_ADDR,istat);
//			//return IPP_ERR_FAIL;
//            break;  // test 50MHz
//        }
//        if((istat & 0x01) == 0x00)
//            break;
//	} while (1);
//    printf("Done\n");
//
//#if 1
//	//if (!high_capacity[sdio_no-1]) {
//	if (!high_capacity) {
//		lba *= SDIO_BLOCK_SIZE;
//		//printf("high_cpacity:%d lba:0x%x\n",high_capacity[sdio_no-1], lba);
//    }
//#endif
//	istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
//    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
//
////	 WRITE_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR, &data_for_table_adma_0[0]);
//	 WRITE_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR, ocm_mem_addr);
//	 rc  = READ_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR);
//	 printf("ADMA_ADDRESS_LOW_ADDR sdio 1 addr:0x%08x rdvl:0x%08x\n",ADMA_ADDRESS_LOW_ADDR,rc);
//
//	 WRITE_SDIO(sdio_no,ADMA_ADDRESS_HIGH_ADDR,0x00000000);
//	 rc  = READ_SDIO(sdio_no,ADMA_ADDRESS_HIGH_ADDR);
//	 printf("ADMA_ADDRESS_HIGH_ADDR sdio 1 addr:0x%08x rdvl:0x%08x\n",ADMA_ADDRESS_HIGH_ADDR,rc);
//
//	 data_for_table_adma_temp = ocm_mem_addr;
//	 //prepare table for ADMA
//     //data_write = 0x21000002 ;
//	 //data_write = 0x23000002 ;   //512 bytes run OK
//	 //data_write = 0x23000004 ;     //1KB run OK
//	  //data_write = 0x2300002C ;     //8KB run
//	 //data_write = 0x23000020 ;
//	 data_write = 0x23000040 ;
//	 //data_write = sd_bswap32(0x23000002) ;
//	 //data_write = ((blkNo*512)<<16)|0x0023 ;
//	 //data_write = sd_bswap32(data_write) ;
//     rc = sdio_out32(data_for_table_adma_temp,data_write);
//     data_for_table_adma_temp ++ ;
//
//     //data_read_add = &addr_for_data_adma_0[0];
//     //printf("data_read_add 0x%08x ",data_read_add);
//     //data_write = sd_bswap32(data_read_add) ;
//     //data_write = data_read_add ;
//     //data_write = 0x00003000 ;
//     //data_write = 0x00000000 ;
//     data_write = sd_bswap32(0x1d0c0000) ; // 0x1d0c0000  0x00300000
//     rc = sdio_out32(data_for_table_adma_temp,data_write);
//     printf("data_temp0 = 0x%08x, data = 0x%08x ",data_for_table_adma_temp, data_write);
//     data_for_table_adma_temp ++ ;
//
//     data_write = 0x07000000 ;
//     //data_write = sd_bswap32(0x07000000) ;
//     rc = sdio_out32(data_for_table_adma_temp,data_write);
//     printf("data_temp1 = 0x%08x, data = 0x%08x ",data_for_table_adma_temp, data_write);
//
//     data_for_table_adma_temp ++ ;
//
//     data_write = 0x12345678 ;
//     //data_write = sd_bswap32(0x07000000) ;
//     rc = sdio_out32(data_for_table_adma_temp,data_write);
//     printf("data_temp2 = 0x%08x, data = 0x%08x ",data_for_table_adma_temp, data_write);
//
//     //test data of table
//     printf("Test data of table...\n\n ");
//     data_for_table_adma_temp = &data_for_table_adma_0[0];
//         for (i=1 ; i<17 ; i++){
//         data = *((volatile unsigned int *)data_for_table_adma_temp);
//         printf("data_temp= 0x%08x, data = 0x%08x ",data_for_table_adma_temp, data);
//         data_for_table_adma_temp ++ ;
//         if ((i%4)==0) printf("\n\r");
//         }
//
//
//
//    //printf("Write addr:0x%08x wrVal:0x%08x\n",SDMA_SYSTEM_ADDRESS_ADDR, SDIO_OCM_PHYS_ADDR_RD);
//
//
//	cmd =     (25 << 24)  	/* Multiple Write Command Index */
//			| ( 0 << 22)   	/* Command type */
//			| ( 1 << 21)    /* Data Present */
//			| ( 1 << 20) 	/* Command Index check enable */
//			| ( 1 << 19)	/* Command CRC check enable */
//			| ( 2 << 16)	/* Response type - R1 */
//			| ( 0 << 4) 	/* Write Direction */
//			| ( 1 << 1)	/* Enable block count */
//			| ( 1 << 0)	/* DMA Enable */
//			| ( 1 << 2)	/* AUTO CMD12 Enable */
//			//| ( 0 << 2)	/* AUTO CMD12 Disable */
//			//| ( 2 << 2)	/* AUTO CMD23 Disable */
//			| ( 1 << 5);	/* Multiple Block Select */
//
//    //temp = ((blkNo << 16) | SDIO_BLOCK_SIZE); // return Transfer complete OK !!!
//	//temp = ((2 << 16) | SDIO_BLOCK_SIZE);
//	//temp = ((16 << 16) | SDIO_BLOCK_SIZE);
//	temp = ((32 << 16) | SDIO_BLOCK_SIZE); //
//	//temp = ((8 << 16) | SDIO_BLOCK_SIZE)|(7<<12);
//	WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, temp);   /*  writing both block count(=1) and block size regs  */
//    printf("Write addr:0x%08x wrVal:0x%08x\n",BLOCK_DEF_ADDR, temp);
//
//	WRITE_SDIO(sdio_no,ARGUMENT_ADDR, lba);
//    printf("Write addr:0x%08x wrVal:0x%08x\n",ARGUMENT_ADDR, lba);
//
////    cmd = 0x193a0027 ;
//	cmd = 0x193a0023 ;   //run OK with SD card
//	WRITE_SDIO(sdio_no,TRANSFERMODE_COMMAND_ADDR, cmd);
//    ipp_udelay(DELAY_1);
//    printf("Write addr:0x%08x wrVal:0x%08x\n",TRANSFERMODE_COMMAND_ADDR, cmd);
//
//    /* Wait for transfer to complete or error bit set */
//    timeout=100;
//    ipp_udelay(DELAY_1);
//	while (1)
//	{
//		//ipp_udelay(DELAY_1);
//        istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
//        printf("Read addr:0x%08x rdVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
//        //fix SDMA multi block bug
//        if(istat & 0x00000008){
//        	//istat = istat & 0x00000008;
//        	//WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
//
//        	rc  = READ_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR);
//        	printf("Fix bug SDMA multi ...\n");
//        	WRITE_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR, rc);
//
//        	rc  = READ_SDIO(sdio_no,ADMA_ADDRESS_HIGH_ADDR);
//        	printf("Fix bug SDMA multi ...\n");
//        	WRITE_SDIO(sdio_no,ADMA_ADDRESS_HIGH_ADDR, rc);
//
//        	data = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
//        	printf("BLOCK_DEF_ADDR debug :0x%08x wrVal:0x%08x\n",BLOCK_DEF_ADDR, data);
//        	//goto retry_sdma_multi_write;
//        }
//		if ((istat & 0x00000003)) {
//            if(istat & 0x00000001) {
//                printf("Write ADMA 2 Multi Block Command Done\n");
// 	            istat = istat & 0x00000001;
//                WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
//                //printf("Clear INT addr:0x%08x data:0x%08x\n",INTERRUPT_STATUS_ADDR,istat);
//
//                //istat = READ_SDIO(sdio_no,RESPONSE_0_1_ADDR);
//                //printf("READ RESPONSE_0_1_ADDR addr:0x%08x wrVal:0x%08x\n",RESPONSE_0_1_ADDR, istat);
//
//                //istat = READ_SDIO(sdio_no,RESPONSE_2_3_ADDR);
//                //printf("READ RESPONSE_2_3_ADDR addr:0x%08x wrVal:0x%08x\n",RESPONSE_2_3_ADDR, istat);
//            }
//            if(istat & 0x00000002) {
//                printf("Write ADMA 2 Multi Block Data Transfer Done\n");
//                istat = istat & 0x00000002;
//	            WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
//                printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
//			    //return IPP_OK;
//                break;
//            }
//		}
//
//		if (istat & 0xFFFF8000) {
//            printf( "Fail write Data\n");
//			WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
//            printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
//		}
//
//        timeout--;
//        if(timeout == 0) {
//            printf("Timeout Read Data\n");
//            break;
//        }
//	}
//
//	//test block
//	data = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
//	printf("BLOCK_DEF_ADDR after :0x%08x wrVal:0x%08x\n",BLOCK_DEF_ADDR, data);
//
//	WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
//    printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
//
//
////    //debug data from SD card read out
////    printf("After transfer data...\n\n\r");
////    //data_read_add = &addr_for_data_adma_0[0];
////    data_read_add = 0x1d0c0000; // 0x02000000;           //test ADMA1
////    for (i=1 ; i< (128+1) ;i++ ){
////    data = *((volatile unsigned int *)data_read_add);
////    printf("0x%08x ",data);
////    data_read_add ++ ;
////    if ((i%4)==0) printf("\n\r");
////    }
//
//    printf("\n\r write_vfatdev_sdio_block <- out\n");
//	return IPP_OK;
//}
//==========================================================================================================
//unsigned int read_vfatdev_sdio_adma_2_multi_block(u8 sdio_no,unsigned int lba,u16 blkNo)
//{
//	unsigned int cmd,rc,i,n;
//	unsigned int istat,temp,timeout=1000;
//    unsigned int *data_for_table_adma_temp = &data_for_table_adma_0[0];
//    unsigned int *data_read_add = &addr_for_data_adma_0[0];
//    unsigned int data , data_write ;
//    //printf("\nread_vfatdev_sdio_block -> in\n");
//    //printf("lba:0x%x\n",lba);
//    unsigned int ocm_mem_addr = 0x1d0c1000; //  0x02E20100;
//
//    data_read_add = ocm_mem_addr ; // just test for OCM mem
//    printf("Fill data0...\n");
//        	for ( n =0 ; n < blkNo ; n++){
//        	data_read_add = data_read_add + 96*n ;
//        	  for (i=1 ; i< (32+1) ; i++){
//        	    *((volatile unsigned int *)data_read_add)= 0x12345678;
//                data_read_add ++ ;
//        	    }
//        	}
//
//
//    data_read_add = ocm_mem_addr ; // just test for OCM mem
//     printf("Before transfer data0...\n");
//    	for ( n =0 ; n < blkNo ; n++){
//    	printf("\n\nBlock %d ...\n",n);
//    	data_read_add = data_read_add + 96*n ;
//    	  for (i=1 ; i< (32+1) ; i++){
//    	    data = *((volatile unsigned int *)data_read_add);
//    	    printf("addr = 0x%08x, data = 0x%08x ",data_read_add, data);
//            data_read_add ++ ;
//    	    if ((i%4)==0) printf("\n\r");
//    	    }
//    	}
//    printf("DONE CHECK \n\n");
//
//	data_read_add = ocm_mem_addr ; // just test for OCM mem
//	printf("Fill data1...\n");
//			for ( n =0 ; n < blkNo ; n++){
//			data_read_add = data_read_add + 96*n ;
//			  for (i=1 ; i< (32+1) ; i++){
//				*((volatile unsigned int *)data_read_add)= 0xffffffff;
//				data_read_add ++ ;
//				}
//			}
//
//	data_read_add = ocm_mem_addr ; // just test for OCM mem
//	 printf("Before transfer data1...\n");
//		for ( n =0 ; n < blkNo ; n++){
//		printf("\n\nBlock %d ...\n",n);
//		data_read_add = data_read_add + 96*n ;
//		  for (i=1 ; i< (32+1) ; i++){
//			data = *((volatile unsigned int *)data_read_add);
//    	    printf("addr = 0x%08x, data = 0x%08x ",data_read_add, data);
//			data_read_add ++ ;
//			if ((i%4)==0) printf("\n\r");
//			}
//		}
//		printf("\n\n");
//
//    timeout=100;
//	do {
//	    istat = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
//        timeout--;
//        if(timeout == 0) {
//            printf("Timeout for CMD line Free addr:0x%08x rdvl:0x%08x\n",PRESENT_STATE_ADDR,istat);
//			//return IPP_ERR_FAIL;
//            break;  // test 50MHz
//        }
//        if((istat & 0x01) == 0x00)
//            break;
//	} while (1);
//    //printf("Done\n");
//
//#if 1
//	//if (!high_capacity[sdio_no-1]) {
//	if (!high_capacity) {
//		lba *= SDIO_BLOCK_SIZE;
////		printf("high_cpacity:%d lba:0x%x\n",high_capacity[sdio_no-1], lba);
//    }
//#endif
//
//
////	 WRITE_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR, &data_for_table_adma_0[0]);
//	 WRITE_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR, ocm_mem_addr);
//	 rc  = READ_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR);
//	 printf("ADMA_ADDRESS_LOW_ADDR sdio 1 addr:0x%08x rdvl:0x%08x\n",ADMA_ADDRESS_LOW_ADDR,rc);
//
//	 WRITE_SDIO(sdio_no,ADMA_ADDRESS_HIGH_ADDR,0x00000000);
//	 rc  = READ_SDIO(sdio_no,ADMA_ADDRESS_HIGH_ADDR);
//	 printf("ADMA_ADDRESS_HIGH_ADDR sdio 1 addr:0x%08x rdvl:0x%08x\n",ADMA_ADDRESS_HIGH_ADDR,rc);
//
//
//	 //prepare table for ADMA
//     //data_write = 0x21000002 ;
//	 //data_write = 0x23000002 ;   //512 bytes run OK
//	 //data_write = 0x23000004 ;     //1KB run OK
//	  //data_write = 0x2300002C ;     //8KB run
//	 //data_write = 0x23000020 ;
//	 //data_write = 0x23000040 ;
//	 //data_write = 0x21000040 ;
//	   data_write = 0x27000040 ;
//	 //data_write = sd_bswap32(0x23000002) ;
//	 //data_write = ((blkNo*512)<<16)|0x0023 ;
//	 //data_write = sd_bswap32(data_write) ;
//     rc = sdio_out32(data_for_table_adma_temp,data_write);
//     data_for_table_adma_temp ++ ;
//
//     //data_read_add = &addr_for_data_adma_0[0];
//     //printf("data_read_add 0x%08x ",data_read_add);
//     //data_write = sd_bswap32(data_read_add) ;
//     //data_write = data_read_add ;
//     //data_write = 0x00003000 ;
//     data_write = 0x12345678 ;
////     data_write = sd_bswap32(0x1d0c0000) ; //0x1d0c0000; //  0x00300000 ;
//     rc = sdio_out32(data_for_table_adma_temp,data_write);
//     data_for_table_adma_temp ++ ;
//
//     data_write = 0x07000000 ;
//     //data_write = sd_bswap32(0x07000000) ;
//     rc = sdio_out32(data_for_table_adma_temp,data_write);
//
//     //test data of table
//     printf("Test data of table1...\n\n ");
//     data_for_table_adma_temp = &data_for_table_adma_0[0];
//         for (i=1 ; i<17 ; i++){
//         data = *((volatile unsigned int *)data_for_table_adma_temp);
//         printf("0x%08x ",data);
//         data_for_table_adma_temp ++ ;
//         if ((i%4)==0) printf("\n\r");
//         }
//
//
//
//    //printf("Write addr:0x%08x wrVal:0x%08x\n",SDMA_SYSTEM_ADDRESS_ADDR, SDIO_OCM_PHYS_ADDR_RD);
//
//
//	cmd =     (25 << 24)  	/* Multiple Write Command Index */
//			| ( 0 << 22)   	/* Command type */
//			| ( 1 << 21)    /* Data Present */
//			| ( 1 << 20) 	/* Command Index check enable */
//			| ( 1 << 19)	/* Command CRC check enable */
//			| ( 2 << 16)	/* Response type - R1 */
//			| ( 0 << 4) 	/* Write Direction */
//			| ( 1 << 1)	/* Enable block count */
//			| ( 1 << 0)	/* DMA Enable */
//			| ( 1 << 2)	/* AUTO CMD12 Enable */
//			//| ( 0 << 2)	/* AUTO CMD12 Disable */
//			//| ( 2 << 2)	/* AUTO CMD23 Disable */
//			| ( 1 << 5);	/* Multiple Block Select */
//
//    //temp = ((blkNo << 16) | SDIO_BLOCK_SIZE); // return Transfer complete OK !!!
//	//temp = ((2 << 16) | SDIO_BLOCK_SIZE);
//	//temp = ((16 << 16) | SDIO_BLOCK_SIZE);
//	//temp = ((32 << 16) | SDIO_BLOCK_SIZE);
//	//temp = ((32 << 16) | SDIO_BLOCK_SIZE)|(7<<12);
//	temp = (((blkNo*8) << 16) | SDIO_BLOCK_SIZE)|(7<<12);
//	WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, temp);   /*  writing both block count(=1) and block size regs  */
//    printf("Write addr:0x%08x wrVal:0x%08x\n",BLOCK_DEF_ADDR, temp);
//
//	WRITE_SDIO(sdio_no,ARGUMENT_ADDR, lba);
//    printf("Write addr:0x%08x wrVal:0x%08x\n",ARGUMENT_ADDR, lba);
//
//    //cmd = 0x193a0027 ;
////    cmd = 0x123a0037 ;
//    cmd = 0x123a0033 ;  //no autoCMD12 run OK
//	WRITE_SDIO(sdio_no,TRANSFERMODE_COMMAND_ADDR, cmd);
//    ipp_udelay(DELAY_1);
//    printf("Write addr:0x%08x wrVal:0x%08x\n",TRANSFERMODE_COMMAND_ADDR, cmd);
//    ipp_udelay(DELAY_1);
//    ipp_udelay(DELAY_1);
//
//	/* Wait for transfer to complete or error bit set */
//    //timeout=10000000; //test for 25Mhz
//    timeout=100; //test for 50Mhz
//	while (1)
//	{
//		//ipp_udelay(DELAY_1);
//        istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
//        printf("Read addr:0x%08x rdVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
//        //fix SDMA multi block bug
//        if(istat & 0x00000008){
//        	//istat = istat & 0x00000008;
//        	//WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
//
//        	rc  = READ_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR);
//        	printf("Fix bug SDMA multi ...\n");
//        	WRITE_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR, rc);
//
//        	data = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
//        	printf("BLOCK_DEF_ADDR debug :0x%08x wrVal:0x%08x\n",BLOCK_DEF_ADDR, data);
//        	//goto retry_sdma_multi;
//        }
//		if ((istat & 0x00000003)) {
//            if(istat & 0x00000001) {
//                printf("Read ADMA 2 Multi Block Command Done\n");
// 	            istat = istat & 0x00000001;
//                WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
//                //printf("Clear INT addr:0x%08x data:0x%08x\n",INTERRUPT_STATUS_ADDR,istat);
//
//                istat = READ_SDIO(sdio_no,RESPONSE_0_1_ADDR);
//                //printf("READ RESPONSE_0_1_ADDR addr:0x%08x wrVal:0x%08x\n",RESPONSE_0_1_ADDR, istat);
//
//                istat = READ_SDIO(sdio_no,RESPONSE_2_3_ADDR);
//                //printf("READ RESPONSE_2_3_ADDR addr:0x%08x wrVal:0x%08x\n",RESPONSE_2_3_ADDR, istat);
//            }
//            if(istat & 0x00000002) {
//                printf("Read ADMA 2 Multi Block Data Transfer Done\n");
//                istat = istat & 0x00000002;
//	            WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
//                printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
//			    //return IPP_OK;
//                break;
//            }
//		}
//
//		if (istat & 0xFFFF8000) {
//            printf( "Fail read Data\n");
//			WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
//            printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
//		}
//
//        timeout--;
//        if(timeout == 0) {
//            printf("Timeout Read Data\n");
//            break;
//        }
//	}
//
//	//test block
//	data = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
//	printf("BLOCK_DEF_ADDR after :0x%08x wrVal:0x%08x\n",BLOCK_DEF_ADDR, data);
//
//	WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
//    printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
//
//    //Data after excute ADMA2
//    //data_read_add = &data_read_test[0];
//    data_read_add = ocm_mem_addr ;  // just test for OCM
//    //debug data from SD card read out
//    printf("After...\n");
//        	for ( n =0 ; n < blkNo ; n++){
////        	printf("\n\nBlock %d ...\n",n);
//        	data_read_add = data_read_add + 96*n ;
//        	  for (i=1 ; i< (32+1) ; i++){
//        	    data = *((volatile unsigned int *)data_read_add);
//        	    printf("addr = 0x%08x, data = 0x%08x ",data_read_add, data);
//                data_read_add ++ ;
//        	    if ((i%4)==0) printf("\n\r");
//        	    }
//        	}
////    printf("\n\n");
//    printf("\n\r read_vfatdev_sdio_block <- out\n");
//	return IPP_OK;
//}
//==========================================================================================================
//==========================================================================================================
u32 write_vfatdev_sdio_adma_2_multi_block_test_suspend_resume(u8 sdio_no,u32 lba,u16 blkNo)
{
	u32 cmd,rc,i,n;
	u32 istat,temp,timeout=100;
    u32 *data_for_table_adma_temp ;// = &data_for_table_adma_0[0];
    u32 *data_read_add ;//= &addr_for_data_adma_0[0];
    u32 data , data_write,datatemp = 0xcafe0000 ;
    u32 ocm_mem_addr = 0x1d0c0000; //  0x02E20100;
	char c;

	data_for_table_adma_temp = 0x1d0c3000;
    data_read_add = ocm_mem_addr ; // just test for OCM mem
	for ( n =0 ; n < blkNo ; n++)
	{
		for (i=1 ; i< (128+1) ; i++)
		{
//			*((volatile unsigned int *)data_read_add)= datatemp;
			*((volatile unsigned int *)data_read_add)= 0xcafe0000 + i;
			data_read_add ++ ;
		}
	}

    data_read_add = ocm_mem_addr ; // just test for OCM mem
	for ( n =0 ; n < blkNo ; n++)
	{
		printf("\nBlock %d ...\n",n);
		for (i=1 ; i< (128+1) ; i++)
		{
			data = *((volatile unsigned int *)data_read_add);
			printf("addr = 0x%08x, wr_data = 0x%08x, ",data_read_add, data);
			data_read_add ++ ;
			if ((i%4)==0) printf("\n\r");
		}
	}
	printf("\n\n");

    timeout=300;
	do {
	    istat = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
		arch_timer_msdelay(10);

        timeout--;
        if(timeout == 0) {
            printf("Timeout for CMD line Free addr:0x%08x rdvl:0x%08x\n",PRESENT_STATE_ADDR,istat);
			//return IPP_ERR_FAIL;
            break;  // test 50MHz
        }
        if((istat & 0x01) == 0x00)
            break;
	} while (1);
#if 1
//	if (!high_capacity) {
		lba *= SDIO_BLOCK_SIZE;
//    }
#endif

	WRITE_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR, data_for_table_adma_temp);
	rc  = READ_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR);
	WRITE_SDIO(sdio_no,ADMA_ADDRESS_HIGH_ADDR,0x00000000);
	rc  = READ_SDIO(sdio_no,ADMA_ADDRESS_HIGH_ADDR);

	 //prepare table for ADMA
     //data_write = 0x21000002 ;
	 data_write = 0x27000002 ;   //512 bytes run OK
	 //data_write = 0x23000004 ;     //1KB run OK
	  //data_write = 0x2300002C ;     //8KB run
	 //data_write = 0x23000020 ;
//	 data_write = 0x27000040 ;       //32 blocks
	 //data_write = 0x23000080 ;       //64 blocks
	 //data_write = 0x27000080 ;
	 //data_write = 0x230000FE ;     // 127 blocks
//	 data_write = 0x270000FE ;     // 127 blocks
	 //data_write = sd_bswap32(0x23000002) ;
	 //data_write = ((blkNo*512)<<16)|0x0023 ;
	 data_write = sd_bswap32(data_write) ;
     rc = sdio_out32(data_for_table_adma_temp,data_write);
     printf("addr:0x%08x data:0x%08x\n",data_for_table_adma_temp, data_write);
     data_for_table_adma_temp ++ ;

     //data_read_add = &addr_for_data_adma_0[0];
     //printf("data_read_add 0x%08x ",data_read_add);
     //data_write = sd_bswap32(data_read_add) ;
     //data_write = data_read_add ;
     //data_write = 0x00003000 ;
     //data_write = 0x00000000 ;
//     data_write = sd_bswap32(0x1d0c0000) ;//0x1d0c0000; //  0x00300000 ;
     data_write = ocm_mem_addr ; //  0x00300000 ;
     rc = sdio_out32(data_for_table_adma_temp,data_write);
     printf("addr:0x%08x data:0x%08x\n",data_for_table_adma_temp, data_write);
     data_for_table_adma_temp ++ ;

     data_write = 0x07000000 ;

     data_write = sd_bswap32(0x07000000) ;
     rc = sdio_out32(data_for_table_adma_temp,data_write);
     printf("addr:0x%08x data:0x%08x\n",data_for_table_adma_temp, data_write);

	cmd =     (25 << 24)  	/* Multiple Write Command Index */
			| ( 0 << 22)   	/* Command type */
			| ( 1 << 21)    /* Data Present */
			| ( 1 << 20) 	/* Command Index check enable */
			| ( 1 << 19)	/* Command CRC check enable */
			| ( 2 << 16)	/* Response type - R1 */
			| ( 0 << 4) 	/* Write Direction */
			| ( 1 << 1)	/* Enable block count */
			| ( 1 << 0)	/* DMA Enable */
			| ( 1 << 2)	/* AUTO CMD12 Enable */
			//| ( 0 << 2)	/* AUTO CMD12 Disable */
			//| ( 2 << 2)	/* AUTO CMD23 Disable */
			| ( 0 << 5);	/* Multiple Block Select */

    //temp = ((blkNo << 16) | SDIO_BLOCK_SIZE); // return Transfer complete OK !!!
	temp = ((1 << 16) | SDIO_BLOCK_SIZE);
	//temp = ((16 << 16) | SDIO_BLOCK_SIZE);
	//temp = ((32 << 16) | SDIO_BLOCK_SIZE);
	//temp = ((64 << 16) | SDIO_BLOCK_SIZE);
//	temp = ((32 << 16) | SDIO_BLOCK_SIZE)|(7<<12);
	//  temp = (((1) << 16) | SDIO_BLOCK_SIZE)|(7<<12);
	//temp = ((64 << 16) | SDIO_BLOCK_SIZE)|(7<<12);
	//temp = ((8 << 16) | SDIO_BLOCK_SIZE)|(7<<12);
//	temp = ((2 << 16) | SDIO_BLOCK_SIZE)|(7<<12);
	//temp = ((64 << 16) | SDIO_BLOCK_SIZE);
    //temp = sd_bswap32(temp) ;
	arch_timer_msdelay(10);
	WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, temp);   /*  writing both block count(=1) and block size regs  */
    printf("BLOCK_DEF_ADDR:0x%08x data:0x%08x\n",BLOCK_DEF_ADDR, temp);
	arch_timer_msdelay(10);

	WRITE_SDIO(sdio_no,ARGUMENT_ADDR, lba);
    printf("ARGUMENT_ADDR:0x%08x data:0x%08x\n",ARGUMENT_ADDR, lba);
	arch_timer_msdelay(10);

//    cmd = 0x183a0007 ;
//    cmd = 0x193a00027 ;
	//cmd = 0x193a0023 ;
	//cmd = 0x193a0025 ;
    cmd = 0x193a0027 ;
	WRITE_SDIO(sdio_no,TRANSFERMODE_COMMAND_ADDR, cmd);
	arch_timer_msdelay(1000);
    printf("TRANSFERMODE_COMMAND_ADDR:0x%08x data:0x%08x\n",TRANSFERMODE_COMMAND_ADDR, cmd);
	arch_timer_msdelay(1000);

    timeout=100;
	while (1)
	{
		arch_timer_msdelay(100);
//		ipp_udelay(DELAY_1);
        istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);

		if (istat) {printf("INTERRUPT_STATUS_ADDR:0x%08x rdVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);}		if ((istat & 0x00000003)) {
            if(istat & 0x00000001) {
                printf("Write ADMA 2 Multi Block Command Done\n");
 	            istat = istat & 0x00000001;
                WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
                printf("Clear INT addr:0x%08x data:0x%08x\n",INTERRUPT_STATUS_ADDR,istat);

                istat = READ_SDIO(sdio_no,RESPONSE_0_1_ADDR);
//                printf("READ RESPONSE_0_1_ADDR addr:0x%08x wrVal:0x%08x\n",RESPONSE_0_1_ADDR, istat);

                istat = READ_SDIO(sdio_no,RESPONSE_2_3_ADDR);
//                printf("READ RESPONSE_2_3_ADDR addr:0x%08x wrVal:0x%08x\n",RESPONSE_2_3_ADDR, istat);
            }
            if(istat & 0x00000002) {
                printf("Write ADMA 2 Multi Block Data Transfer Done\n");
                istat = istat & 0x00000002;
	            WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
			    //return IPP_OK;
                break;
            }
		}

		if (istat & 0xFFFF8000) {
            printf( "Fail write Data\n");
			WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
            printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
		}

        timeout--;
        if(timeout == 0) {
            printf("Timeout Read Data\n");
            break;
        }
	}
    data_read_add = data_for_table_adma_temp ; // just test for OCM mem
	for ( n =0 ; n < blkNo ; n++)
	{
		for (i=1 ; i< (128+1) ; i++)
		{
			*((volatile unsigned int *)data_read_add)= 0xFFFFFFFF;
			data_read_add ++ ;
		}
	}

    data_read_add = ocm_mem_addr ; // just test for OCM mem
	for ( n =0 ; n < blkNo ; n++)
	{
		for (i=1 ; i< (128+1) ; i++)
		{
			*((volatile unsigned int *)data_read_add)= 0xFFFFFFFF;
			data_read_add ++ ;
		}
	}

	//test block
	data = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
	WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
    istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
    istat = istat & 0x00000001;
    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
    istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
    istat = istat & 0x00000002;
    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
    istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
    istat = istat & 0xFFFF8000;
    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
	return IPP_OK;
}

//==========================================================================================================
u32 read_vfatdev_sdio_adma_2_multi_block_test_suspend_resume(u8 sdio_no,u32 lba,u16 blkNo)
{
	u32 cmd,rc,i,n;
	u32 istat,temp,timeout=100;
    u32 *data_for_table_adma_temp ;
    u32 *data_read_add ;
    u32 data , data_write ;
    u32 ocm_mem_addr =  0x1d0c1000;  //  0x02E20100;

    data_for_table_adma_temp = 0x1d0c5000;
    data_read_add = ocm_mem_addr ; // just test for OCM mem
	for ( n =0 ; n < blkNo ; n++)
	{
		for (i=1 ; i< (128+1) ; i++)
		{
			*((volatile unsigned int *)data_read_add)= 0xffffffff;
			data_read_add ++ ;
		}
	}
    data_read_add = data_for_table_adma_temp ; // just test for OCM mem
	for ( n =0 ; n < blkNo ; n++)
	{
		for (i=1 ; i< (128+1) ; i++)
		{
			*((volatile unsigned int *)data_read_add)= 0xffffffff;
			data_read_add ++ ;
		}
	}

	timeout=100;
	do {
	    istat = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
		arch_timer_msdelay(10);
        timeout--;
        if(timeout == 0) {
            printf("Timeout for CMD line Free addr:0x%08x rdvl:0x%08x\n",PRESENT_STATE_ADDR,istat);
			//return IPP_ERR_FAIL;
            break;  // test 50MHz
        }
        if((istat & 0x01) == 0x00)
            break;
	} while (1);
#if 1
	//if (!high_capacity[sdio_no-1]) {
//	if (!high_capacity) {
		lba *= SDIO_BLOCK_SIZE;
		//printf("high_cpacity:%d lba:0x%x\n",high_capacity[sdio_no-1], lba);
//    }
#endif
 	 WRITE_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR, 8);
	 WRITE_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR, data_for_table_adma_temp);
	 rc  = READ_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR);
	 WRITE_SDIO(sdio_no,ADMA_ADDRESS_HIGH_ADDR,0x00000000);
	 rc  = READ_SDIO(sdio_no,ADMA_ADDRESS_HIGH_ADDR);

	 //prepare table for ADMA
	 data_write = 0x27000002 ;   //512 bytes run OK
	 data_write = sd_bswap32(data_write) ;
     rc = sdio_out32(data_for_table_adma_temp,data_write);
     printf("addr:0x%08x data:0x%08x\n",data_for_table_adma_temp, data_write);

     data_for_table_adma_temp ++ ;

     data_write = ocm_mem_addr ;//0x1d0c0000; //  0x00300000 ;
     rc = sdio_out32(data_for_table_adma_temp,data_write);
     printf("addr:0x%08x data:0x%08x\n",data_for_table_adma_temp, data_write);
     data_for_table_adma_temp ++ ;

     data_write = 0x07000000 ;
     data_write = sd_bswap32(0x07000000) ;
     rc = sdio_out32(data_for_table_adma_temp,data_write);
     printf("addr:0x%08x data:0x%08x\n",data_for_table_adma_temp, data_write);

	cmd =     (17 << 24)  	/* Multiple Write Command Index */
			| ( 0 << 22)   	/* Command type */
			| ( 1 << 21)    /* Data Present */
			| ( 1 << 20) 	/* Command Index check enable */
			| ( 1 << 19)	/* Command CRC check enable */
			| ( 2 << 16)	/* Response type - R1 */
			| ( 0 << 4) 	/* Write Direction */
			| ( 1 << 1)	/* Enable block count */
			| ( 1 << 0)	/* DMA Enable */
			| ( 1 << 2)	/* AUTO CMD12 Enable */
			//| ( 0 << 2)	/* AUTO CMD12 Disable */
			//| ( 2 << 2)	/* AUTO CMD23 Disable */
			| ( 0 << 5);	/* Multiple Block Select */

	temp = ((1 << 16) | SDIO_BLOCK_SIZE);
	arch_timer_msdelay(10);
	WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, temp);   /*  writing both block count(=1) and block size regs  */
    printf("BLOCK_DEF_ADDR:0x%08x data:0x%08x\n",BLOCK_DEF_ADDR, temp);
	arch_timer_msdelay(10);
	WRITE_SDIO(sdio_no,ARGUMENT_ADDR, lba);
    printf("ARGUMENT_ADDR:0x%08x data:0x%08x\n",ARGUMENT_ADDR, lba);

    cmd = 0x123a0033 ;  //no autoCMD12 run OK
	arch_timer_msdelay(10);
	WRITE_SDIO(sdio_no,TRANSFERMODE_COMMAND_ADDR, cmd);
    ipp_udelay(DELAY_1);
    printf("TRANSFERMODE_COMMAND_ADDR:0x%08x data:0x%08x\n",TRANSFERMODE_COMMAND_ADDR, cmd);
    ipp_udelay(DELAY_1);
    ipp_udelay(DELAY_1);
	arch_timer_msdelay(10);
	/* Wait for transfer to complete or error bit set */
    timeout=1000;
	while (1)
	{
		//ipp_udelay(DELAY_1);
		arch_timer_msdelay(3);
        istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
		if (istat) {printf("INTERRUPT_STATUS_ADDR:0x%08x rdVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);}
		if ((istat & 0x00000003)) {
            if(istat & 0x00000001) {
                printf("Read ADMA 2 Multi Block Command Done\n");
 	            istat = istat & 0x00000001;
                WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
                printf("Clear INT addr:0x%08x data:0x%08x\n",INTERRUPT_STATUS_ADDR,istat);

                istat = READ_SDIO(sdio_no,RESPONSE_0_1_ADDR);
//                printf("READ RESPONSE_0_1_ADDR addr:0x%08x wrVal:0x%08x\n",RESPONSE_0_1_ADDR, istat);
//
                istat = READ_SDIO(sdio_no,RESPONSE_2_3_ADDR);
//                printf("READ RESPONSE_2_3_ADDR addr:0x%08x wrVal:0x%08x\n",RESPONSE_2_3_ADDR, istat);

				//break; //for test suspend/resume
            }
            if(istat & 0x00000002) {
                printf("Read ADMA 2 Multi Block Data Transfer Done\n");
                istat = istat & 0x00000002;
	            WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
                printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
			    //return IPP_OK;
                break;
            }
		}

		if (istat & 0xFFFF8000) {
            printf( "Fail read Data\n");
			WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
            printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
		}

        timeout--;
        if(timeout == 0) {
            printf("Timeout Read Data\n");
            break;
        }
	}

	//test block
	arch_timer_msdelay(10);
	data = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
	printf("BLOCK_DEF_ADDR after :0x%08x wrVal:0x%08x\n",BLOCK_DEF_ADDR, data);
	arch_timer_msdelay(10);

	WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
	arch_timer_msdelay(10);
    printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
    data_read_add = ocm_mem_addr ; // just test for OCM mem
	for ( n =0 ; n < blkNo ; n++)
	{
	    for (i=1 ; i< (128+1) ; i++)
	    {
			data = *((volatile unsigned int *)data_read_add);
			printf("addr = 0x%08x, rd_data = 0x%08x, ",data_read_add, data);
			data_read_add ++ ;
			if ((i%4)==0) printf("\n\r");
//			if (data != 0x5A5A5A5A)
			if (data != 0xcafe0000 + i)
				return IPP_ERR_FAIL;
		}
	}
    data_read_add = ocm_mem_addr ; // just test for OCM mem
	for ( n =0 ; n < blkNo ; n++)
	{
		for (i=1 ; i< (128+1) ; i++)
		{
			*((volatile unsigned int *)data_read_add)= 0xffffffff;
			data_read_add ++ ;
		}
	}

    data_read_add = data_for_table_adma_temp ; // just test for OCM mem
	for ( n =0 ; n < blkNo ; n++)
	{
		for (i=1 ; i< (128+1) ; i++)
		{
			*((volatile unsigned int *)data_read_add)= 0xffffffff;
			data_read_add ++ ;
		}
	}
	WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
    istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
    istat = istat & 0x00000001;
    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
    istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
    istat = istat & 0x00000002;
    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
    istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
    istat = istat & 0xFFFF8000;
    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
	return IPP_OK;
}

unsigned int sdio_send_suspend_resume_command (unsigned char sdio_no)
{
	unsigned int res , rc ,cmd ,i ;

	cmd =     (52 << 24)  	/* Multiple Write Command Index */
			| ( 1 << 22)   	/* Suspend Command type */
			| ( 0 << 21)    /* Data Present */
			| ( 0 << 20) 	/* Command Index check enable */
			| ( 0 << 19)	/* Command CRC check enable */
			| ( 2 << 16)	/* Response type - R1 */
			| ( 0 << 4) 	/* Write Direction */
			| ( 0 << 1)	/* Enable block count */
			| ( 0 << 0)	/* DMA Enable */
			| ( 0 << 2)	/* AUTO CMD12 Enable */
			//| ( 0 << 2)	/* AUTO CMD12 Disable */
			//| ( 2 << 2)	/* AUTO CMD23 Disable */
			| ( 0 << 5);	/* Multiple Block Select */

	//printf("Value of the CMD52 is :0x%08x\n",cmd);

	//cmd = 0x34430000;
	//cmd = 0x348a0000; // Resume
	//cmd = 0x344a0000; // Suspend
	//cmd = 0x34a00000; // Suspend
	//cmd = 0x34420000;
	//cmd = 0x34520000;
	//cmd = 0x346a0000;
	cmd = 0x344a0000;
	//cmd = 0x34aa0000; // Suspend
	printf("Value of the CMD52 is :0x%08x\n",cmd);
	//ipp_udelay(20);
    //res = send_command_to_card(sdio_no ,0x00000000 ,0x341a0000 ); //CMD 52 for suspend

	//res = send_command_to_card(sdio_no ,0x00000000 ,0 );  //CMD0
	for (i=0 ; i<1 ; i++ )
	{
    cmd = 0x344a0000;
	res = send_command_to_card(sdio_no ,0x00000000 ,cmd ); //CMD 52 for suspend
	//res = send_command_to_card(sdio_no ,0x00000025 ,cmd ); //CMD 52 for suspend

    printf("Delay !!!\n");
	cmd = 0x384a0000;
	res = send_command_to_card(sdio_no ,0x00000000 ,cmd ); //CMD 52 for suspend
	ipp_udelay(200);
	}

    rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
    printf("PRESENT_STATE_ADDR data:0x%08x\n",rc);

    printf("\n Data after CMD \n");
    while (rc & 0x00000800){
        rc = READ_SDIO(sdio_no,BUFFER_DATA_PORT_ADDR);
        printf("0x%08x ",rc);
        rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
    }
    printf("\n\n");

    printf("Res CMD52 --> For suspend transfer data \n");
    printf("RESP-1 data:0x%08x\n",respond_0_1);
    printf("RESP-2 data:0x%08x\n",respond_2_3);
    printf("RESP-3 data:0x%08x\n",respond_4_5);
    printf("RESP-4 data:0x%08x\n",respond_6_7);
    printf("\n\r");



	return res ;

}

//==========================================================================================================
int sdio_detect(unsigned char sdio_no) {

    int retval=0;
	/* Detect if card present */
	retval = sdio_card_present(sdio_no);
	if (retval) {
		//
//        if(sdio_no == 1)
//            //  lprintf(7, "SDIO-1 SD Card is Detected\n");
//        else if(sdio_no == 2)
//            //  lprintf(7, "SDIO-2 SD Card is Detected\n");
        retval=0;
    }
    else {
//
//        if(sdio_no == 1)
//            //  lprintf(7, "SDIO-1 SD Card Not Detected\n");
//        else if(sdio_no == 2)
//            //  lprintf(7, "SDIO-2 SD Card Not Detected\n");
        retval=1;
    }

    return retval;
}
//==========================================================================================================

unsigned int init_vfatdev_sdio(unsigned int *block_size)
{
	return IPP_OK;
}

//-------------- PIO Mode Start -------------------------
//unsigned int write_vfatdev_sdio_block_pio(unsigned int lba, unsigned int *bufptr)
unsigned int write_vfatdev_sdio_block_pio(unsigned char sdio_no,unsigned int lba)
{
	unsigned int cmd;
	unsigned int istat,temp,timeout=0,pattern;

    //  lprintf(7, "\nwrite_vfatdev_sdio_block_pio -> in\n");
    //  lprintf(7, "lba:0x%x \n",lba);

#if 0
	if (!high_capacity) {
		lba *= SDIO_BLOCK_SIZE;
        //  lprintf(7, "high_cpacity:%d lba:0x%x\n",high_capacity, lba);
    }
#endif

	cmd =     (24 << 24)  	/* Single read Command Index */
		| ( 0 << 22)   	/* Command type */
		| ( 1 << 21)    /* Data Present */
		| ( 1 << 20) 	/* Command Index check enable */
		| ( 1 << 19)	/* Command CRC check enable */
		| ( 2 << 16)	/* Response type - R1 */
		| ( 0 << 4) 	/* Write Direction */
		| ( 1 << 1)	/* Disable block count for single block */
		| ( 0 << 0)	/* DMA Disable */
		| ( 0 << 2)	/* AUTO CMD12 Enable */
		| ( 0 << 5);	/* Multiple Block Select */
    //temp = ((1 << 16) | SDIO_BLOCK_SIZE);
    temp = ((1 << 16) | 4);
	WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, temp);   /*  writing both block count(=1) and block size regs  */
    //  lprintf(7, "Write addr:0x%08x wrVal:0x%08x\n",(unsigned int *)BLOCK_DEF_ADDR, temp);

	WRITE_SDIO(sdio_no,ARGUMENT_ADDR, lba);
    //  lprintf(7, "Write addr:0x%08x wrVal:0x%08x\n",(unsigned int *)ARGUMENT_ADDR, lba);

	WRITE_SDIO(sdio_no,TRANSFERMODE_COMMAND_ADDR, cmd);
    //  lprintf(7, "Write addr:0x%08x wrVal:0x%08x\n",(unsigned int *)TRANSFERMODE_COMMAND_ADDR, cmd);

    timeout=10;
    while(1) {
	    istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
        //  lprintf(7, "Read addr:0x%08x rdVal:0x%08x\n",(unsigned int *)INTERRUPT_STATUS_ADDR, istat);
        if(istat & 0x00000011) {
            //  lprintf(7, "Write Command Done\n");

            WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, 0x00000001);
            //  lprintf(7, "Clear INT addr:0x%08x wrVal:0x00000001\n",(unsigned int *)INTERRUPT_STATUS_ADDR);

            istat = READ_SDIO(sdio_no,RESPONSE_0_1_ADDR);
            //  lprintf(7, "READ RESPONSE_0_1_ADDR addr:0x%08x wrVal:0x%08x\n",(unsigned int *)RESPONSE_0_1_ADDR, istat);

            istat = READ_SDIO(sdio_no,RESPONSE_2_3_ADDR);
            //  lprintf(7, "READ RESPONSE_2_3_ADDR addr:0x%08x wrVal:0x%08x\n",(unsigned int *)RESPONSE_2_3_ADDR, istat);

            istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
            //  lprintf(7, "Read addr:0x%08x rdVal:0x%08x\n",(unsigned int *)INTERRUPT_STATUS_ADDR, istat);

            if(istat & 0x00000010) {
                pattern = 0x11223344;
                WRITE_SDIO(sdio_no,BUFFER_DATA_PORT_ADDR,pattern);
                //  lprintf(7, "BUFFER_DATA_PORT_ADDR addr:0x%08x data:0x%08x\n",(unsigned int *)BUFFER_DATA_PORT_ADDR, pattern);

	            WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
                //  lprintf(7, "Clear INT addr:0x%08x wrVal:0x%08x\n",(unsigned int *)INTERRUPT_STATUS_ADDR, istat);
                break;
            }
        }

		if (istat & 0xFFFF8000) {
			WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
            //  lprintf(7, "Clear INT addr:0x%08x wrVal:0x%08x\n",(unsigned int *)INTERRUPT_STATUS_ADDR, istat);
		}

        if(timeout == 0) {
            //  lprintf(7, "Timeout Write\n");
            break;
        }

        timeout--;
   	}
	WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
    //  lprintf(7, "CLear INT addr:0x%08x wrVal:0x%08x\n",(unsigned int *)INTERRUPT_STATUS_ADDR, istat);

    //  lprintf(7, "write_vfatdev_sdio_block_pio <- out\n");
	return IPP_OK;
}

//-------------- PIO Mode End -------------------------


//-------------- SDMA Mode Start -------------------------
unsigned int write_vfatdev_sdio_block(u8 sdio_no,unsigned int lba)
{
	unsigned int cmd,rc;
	unsigned int istat,temp,timeout=0;

    //  lprintf(7, "\nwrite_vfatdev_sdio_block -> in\n");
    //  lprintf(7, "lba:0x%x\n",lba);

    timeout=10;
    //  lprintf(7, "\nWait for CMD line Free,");
	do {
	    istat = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
        timeout--;
        if(timeout == 0) {
            //  lprintf(7, "Timeout for CMD line Free addr:0x%08x rdvl:0x%08x\n",(unsigned int *)PRESENT_STATE_ADDR,istat);
            break;
        }
        if((istat & 0x01) == 0x00)
            break;
	} while (1);
    //  lprintf(7, "Done\n");

#if 0
	if (!high_capacity) {
		lba *= SDIO_BLOCK_SIZE;
      //  lprintf(7, "high_cpacity:%d lba:0x%x\n",high_capacity, lba);
    }
#endif
	istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);

	WRITE_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR, SDIO_OCM_PHYS_ADDR_WR);
    //  lprintf(7, "Write addr:0x%08x wrVal:0x%08x\n",(unsigned int *)SDMA_SYSTEM_ADDRESS_ADDR, (unsigned int *)SDIO_OCM_PHYS_ADDR_WR);
	 rc  = READ_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR);
	 printf("SDMA_SYSTEM_ADDRESS_ADDR sdio 1 addr:0x%08x rdvl:0x%08x\n",SDMA_SYSTEM_ADDRESS_ADDR,rc);
   //printf("Write addr:0x%08x wrVal:0x%08x\n",SDMA_SYSTEM_ADDRESS_ADDR, SDIO_OCM_PHYS_ADDR_RD);


	cmd =     (24 << 24)  	// Single read Command Index
	    	| ( 0 << 22)   	// Command type
		    | ( 1 << 21)    // Data Present
    		| ( 1 << 20) 	// Command Index check enable
	    	| ( 1 << 19)	// Command CRC check enable
		    | ( 2 << 16)	// Response type - R1
    		| ( 0 << 4) 	// Write Direction
	    	| ( 1 << 1)	    // Enable block count
    		| ( 1 << 0)	    // DMA Enable
	    	| ( 0 << 2)	    // AUTO CMD12 Enable
		    | ( 0 << 5);	// Multiple Block Select

    temp = ((1 << 16) | SDIO_BLOCK_SIZE);
    //temp = ((0 << 16) | SDIO_BLOCK_SIZE);

	WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, temp);   //  writing both block count(=1) and block size regs
    //  lprintf(7, "Write addr:0x%08x wrVal:0x%08x\n",(unsigned int *)BLOCK_DEF_ADDR, temp);

	WRITE_SDIO(sdio_no,ARGUMENT_ADDR, lba);
    //  lprintf(7, "Write addr:0x%08x wrVal:0x%08x\n",(unsigned int *)ARGUMENT_ADDR, lba);

	WRITE_SDIO(sdio_no,TRANSFERMODE_COMMAND_ADDR, cmd);
    ipp_udelay(DELAY_1);
    //  lprintf(7, "Write addr:0x%08x wrVal:0x%08x\n",(unsigned int *)TRANSFERMODE_COMMAND_ADDR, cmd);

	// Wait for transfer to complete or error bit set
    timeout=10;
	while (1) {
	    istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
        //  lprintf(7, "Read addr:0x%08x rdVal:0x%08x\n",(unsigned int *)INTERRUPT_STATUS_ADDR, istat);
        if(istat & 0x00000003) {
            if(istat & 0x00000001) {
                //  lprintf(7, "Write Command Done\n");
    	        istat = istat & 0x00000001;
                WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
                //  lprintf(7, "Clear INT addr:0x%08x wrVal:0x%08x\n",(unsigned int *)INTERRUPT_STATUS_ADDR, istat);

                istat = READ_SDIO(sdio_no,RESPONSE_0_1_ADDR);
                //  lprintf(7, "READ RESPONSE_0_1_ADDR addr:0x%08x wrVal:0x%08x\n",(unsigned int *)RESPONSE_0_1_ADDR, istat);

                istat = READ_SDIO(sdio_no,RESPONSE_2_3_ADDR);
                //  lprintf(7, "READ RESPONSE_2_3_ADDR addr:0x%08x wrVal:0x%08x\n",(unsigned int *)RESPONSE_2_3_ADDR, istat);

                //istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
                //  lprintf(7, "Read addr:0x%08x rdVal:0x%08x\n",(unsigned int *)INTERRUPT_STATUS_ADDR, istat);
            }
            if(istat & 0x00000002) {
                //  lprintf(7, "Write Data Transfer Done\n");
                istat = istat & 0x00000002;
	            WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
                //  lprintf(7, "Clear INT addr:0x%08x wrVal:0x%08x\n",(unsigned int *)INTERRUPT_STATUS_ADDR, istat);
                return 0;
            }
        }

		if (istat & 0xFFFF8000) {
            //  lprintf(3, "Fail Write Data\n");
			WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
            //  lprintf(7, "Clear INT addr:0x%08x wrVal:0x%08x\n",(unsigned int *)INTERRUPT_STATUS_ADDR, istat);
		}

        if(timeout == 0) {
            //  lprintf(7, "Timeout Write Data\n");
            break;
        }

        timeout--;
	}

	WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
    //  lprintf(7, "CLear INT addr:0x%08x wrVal:0x%08x\n",(unsigned int *)INTERRUPT_STATUS_ADDR, istat);

    //  lprintf(7, "write_vfatdev_sdio_block <- out\n");
	return IPP_OK;
}



//==========================================================================================
//-------------- SDMA Mode Multiple Block Start -------------------------
//unsigned int read_vfatdev_sdio_block_muliple(u8 sdio_no, unsigned int lba, u16 blkNo)
//{
//	unsigned int cmd;
//	unsigned int istat,temp;
//	unsigned int *data_read_add = &data_read_test[0];
//	unsigned int time_out,data ;
//	unsigned int i, n ;
//
//    //  lprintf(7, "\nread_vfatdev_sdio_block_multiple -> in\n");
//    //  lprintf(7, "lba:0x%x\n",lba);
//
//    printf("\nread_vfatdev_sdio_block_multiple -> in\n");
//    printf("lba:0x%x\n",lba);
//
//	if (!high_capacity) {
//		lba *= SDIO_BLOCK_SIZE;
//        printf("high_cpacity:%d lba:0x%x\n",high_capacity, lba);
//    }
//
//	WRITE_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR, &data_read_test[0]);
//    //  lprintf(7, "Write addr:0x%08x wrVal:0x%08x\n",(unsigned int *)SDMA_SYSTEM_ADDRESS_ADDR, (unsigned int *)SDIO_OCM_PHYS_ADDR_RD);
//
//	cmd =     (18 << 24)  	/* Multiple Read Command Index */
//		| ( 0 << 22)   	/* Command type */
//		| ( 1 << 21)    /* Data Present */
//		| ( 1 << 20) 	/* Command Index check enable */
//		| ( 1 << 19)	/* Command CRC check enable */
//		| ( 2 << 16)	/* Response type - R1 */
//		| ( 1 << 4) 	/* Read Direction */
//		| ( 1 << 1)	    /* Enable block count */
//		| ( 1 << 0)	    /* DMA Enable */
//		| ( 2 << 2)	    /* AUTO CMD12 Enable */
//		| ( 1 << 5);	/* Multiple Block Select */
//    temp = ((blkNo << 16) | SDIO_BLOCK_SIZE);
//	WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, temp);   /*  writing both block count(=1) and block size regs  */
//    //  lprintf(7, "Write addr:0x%08x wrVal:0x%08x\n",(unsigned int *)BLOCK_DEF_ADDR, temp);
//    printf("Write addr:0x%08x wrVal:0x%08x\n",(unsigned int *)BLOCK_DEF_ADDR, temp);
//    data = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
//    printf("BLOCK_DEF_ADDR :0x%08x wrVal:0x%08x\n",(unsigned int *)BLOCK_DEF_ADDR, data);
//
//    lba = 0x01;
//	WRITE_SDIO(sdio_no,ARGUMENT_ADDR, lba);
//    //  lprintf(7, "Write addr:0x%08x wrVal:0x%08x\n",(unsigned int *)ARGUMENT_ADDR, lba);
//    //printf("ARGUMENT_ADDR :0x%08x wrVal:0x%08x\n",(unsigned int *)ARGUMENT_ADDR, lba);
//    data = READ_SDIO(sdio_no,ARGUMENT_ADDR);
//    printf("ARGUMENT_ADDR :0x%08x wrVal:0x%08x\n",(unsigned int *)ARGUMENT_ADDR, data);
//
//    cmd = 0x123a0037 ;
//	WRITE_SDIO(sdio_no,TRANSFERMODE_COMMAND_ADDR, cmd);
//    //  lprintf(7, "Write addr:0x%08x wrVal:0x%08x\n",(unsigned int *)TRANSFERMODE_COMMAND_ADDR, cmd);
//    //printf("Write addr:0x%08x wrVal:0x%08x\n",(unsigned int *)TRANSFERMODE_COMMAND_ADDR, cmd);
//    data = READ_SDIO(sdio_no,TRANSFERMODE_COMMAND_ADDR);
//    printf("TRANSFERMODE_COMMAND_ADDR test :0x%08x wrVal:0x%08x\n",(unsigned int *)TRANSFERMODE_COMMAND_ADDR, data);
//
//    ipp_udelay(DELAY_1);
//    time_out = 10;
//	/* Wait for transfer to complete or error bit set */
//	while (1) {
//
//		istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
//        //  lprintf(7, "Read addr:0x%08x rdVal:0x%08x\n",(unsigned int *)INTERRUPT_STATUS_ADDR, istat);
//        printf("INTERRUPT_STATUS_ADDR:0x%08x rdVal:0x%08x\n",(unsigned int *)INTERRUPT_STATUS_ADDR, istat);
//		if (istat & 0x00000002) {
//			printf("Read data OK !!!\n");
//			break;
//		}
//		if (istat & 0x00000001) {
//			printf("Command data OK !!!\n");
//			break;
//		}
//		/*
//		if (istat & 0xFFFF8000) {
//			WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
//            //  lprintf(7, "Write addr:0x%08x wrVal:0x%08x\n",(unsigned int *)INTERRUPT_STATUS_ADDR, istat);
//			return IPP_ERR_FAIL; 	// Clear interrupt
//		}
//	    */
//		time_out --;
//		if ( time_out == 0 ){
//		    printf("Time_out .... !!!\n");
//		    break;
//		}
//	}
//	//WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
//    ////  lprintf(7, "Write addr:0x%08x wrVal:0x%08x\n",(unsigned int *)INTERRUPT_STATUS_ADDR, istat);
//
//	ipp_udelay(DELAY_1);
//	istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
//    //  lprintf(7, "Read addr:0x%08x rdVal:0x%08x\n",(unsigned int *)INTERRUPT_STATUS_ADDR, istat);
//    printf("INTERRUPT_STATUS_ADDR:0x%08x rdVal:0x%08x\n",(unsigned int *)INTERRUPT_STATUS_ADDR, istat);
//
//	ipp_udelay(DELAY_1);
//
//	printf("After transfer data...\n");
//	for ( n =0 ; n < blkNo ; n++){
//	printf("\n\nBlock %d ...\n",n);
//	data_read_add = data_read_add + 96*n ;
//	  for (i=1 ; i< (32+1) ; i++){
//	    data = *((volatile unsigned int *)data_read_add);
//	    printf("0x%08x ",data);
//        data_read_add ++ ;
//	    if ((i%4)==0) printf("\n\r");
//	    }
//	}
//	printf("\n\n");
//
//    //  lprintf(7, "read_vfatdev_sdio_block_multiple <- out\n");
//    printf("read_vfatdev_sdio_block_multiple <- out\n");
//	return IPP_OK;
//}

//=========================================================================================================================================
unsigned int write_vfatdev_sdio_block_multiple(u8 sdio_no, unsigned int lba, u16 blkNo)
{
	unsigned int cmd;
	unsigned int istat,temp;
	unsigned int time_out ;

    //  lprintf(7, "\nwrite_vfatdev_sdio_block_multiple -> in\n");
    //  lprintf(7, "lba:0x%x\n",lba);

	if (!high_capacity) {
		lba *= SDIO_BLOCK_SIZE;
        //  lprintf(7, "high_cpacity:%d lba:0x%x\n",high_capacity, lba);
    }
	WRITE_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR, SDIO_OCM_PHYS_ADDR_WR);
    //  lprintf(7, "Write addr:0x%08x wrVal:0x%08x\n",(unsigned int *)SDMA_SYSTEM_ADDRESS_ADDR, (unsigned int *)SDIO_OCM_PHYS_ADDR_WR);

	cmd =     (25 << 24)  	/* Multiple Write Command Index */
		| ( 0 << 22)   	/* Command type */
		| ( 1 << 21)    /* Data Present */
		| ( 1 << 20) 	/* Command Index check enable */
		| ( 1 << 19)	/* Command CRC check enable */
		| ( 2 << 16)	/* Response type - R1 */
		| ( 0 << 4) 	/* Write Direction */
		| ( 1 << 1)	/* Enable block count */
		| ( 1 << 0)	/* DMA Enable */
		| ( 0 << 2)	/* AUTO CMD12 Enable */
		| ( 1 << 5);	/* Multiple Block Select */

    temp = ((blkNo << 16) | SDIO_BLOCK_SIZE);

	WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, temp);   /*  writing both block count(=1) and block size regs  */
    ////  lprintf(7, "Write addr:0x%08x wrVal:0x%08x\n",(unsigned int *)BLOCK_DEF_ADDR, temp);
	printf("Write addr:0x%08x wrVal:0x%08x\n",(unsigned int *)BLOCK_DEF_ADDR, temp);

	WRITE_SDIO(sdio_no,ARGUMENT_ADDR, lba);
    ////  lprintf(7, "Write addr:0x%08x wrVal:0x%08x\n",(unsigned int *)ARGUMENT_ADDR, lba);
	printf("Write addr:0x%08x wrVal:0x%08x\n",(unsigned int *)ARGUMENT_ADDR, lba);

    //cmd = 0x193a0027;//khuynh
	//cmd = 0x193a002b;//khuynh
	WRITE_SDIO(sdio_no,TRANSFERMODE_COMMAND_ADDR, cmd);
    ////  lprintf(7, "Write addr:0x%08x wrVal:0x%08x\n",(unsigned int *)TRANSFERMODE_COMMAND_ADDR, cmd);
	printf("Write addr:0x%08x wrVal:0x%08x\n",(unsigned int *)TRANSFERMODE_COMMAND_ADDR, cmd);

	//ipp_udelay(DELAY_1);
	printf("Wait for cmd complete 0...!!! \n");
	printf("Wait for cmd complete 1...!!! \n");
    time_out = 100 ;
	/* Wait for transfer to complete or error bit set */
	while (1) {

		//ipp_udelay(DELAY_1);
		//ipp_udelay(DELAY_1);
		printf("Wait for cmd complete ...!!! \n");
		istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
        //  lprintf(7, "Read addr:0x%08x rdVal:0x%08x\n",(unsigned int *)INTERRUPT_STATUS_ADDR, istat);
        if (istat & 0x00000002) {
        	printf("Transfer data complete ...!!! \n");
			break;
		}

        if (istat & 0xFFFF8000) {
			WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
            //  lprintf(7, "Write addr:0x%08x wrVal:0x%08x\n",(unsigned int *)INTERRUPT_STATUS_ADDR, istat);
			return IPP_ERR_FAIL; 	/* Clear interrupt */
		}
        time_out--;
        if (time_out == 0){
        	printf("Time out for write multi_block!!! \n");
        	break ;
        }
	}

	WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
    //  lprintf(7, "Write addr:0x%08x wrVal:0x%08x\n",(unsigned int *)INTERRUPT_STATUS_ADDR, istat);

	istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
    //  lprintf(7, "Read addr:0x%08x rdVal:0x%08x\n",(unsigned int *)INTERRUPT_STATUS_ADDR, istat);

	ipp_udelay(DELAY_1);

    //  lprintf(7, "write_vfatdev_sdio_block_multiple <- out\n");
	return IPP_OK;
}

//=================================================================================================================================
//-------------- SDMA Mode Multiple Block Start -------------------------

//-------------- Only Read with SDMA Mode with File System Start-------------------------
unsigned int read_vfatdev_sdio(unsigned char *dest, unsigned int lba, unsigned int blkoff, unsigned int len)
{
    return 0;
}
//=================================================//
int sdio_init(u8 sdio_no) {

    int retval = 1;
	u32 rc,reg;
    struct am862xx_reset_ctrl reset_ctrl;
    u32 *block_size;

    u32 sdu_shutdown, block_mem_rdy;
    u32 ReadData,i;
    sdu_shutdown = 0;
    block_mem_rdy = 0;


//  printf("\n------- CFG_PIN_MUX_SEL_1, CFG_PIN_MUX_SEL_2 -------\r\n");
    WRITE32(0x1f2a016c, 0x00000000);
    WRITE32(0x1f2a0170, 0x00000000);
//  printf("\n-------  AHBC_CLKEN -------\r\n");
    WRITE32(0x1f2ac008, 0x0000030f);
//  printf("\n-------  AHBC_SRST -------\r\n");
    WRITE32(0x1f2ac000, 0x000000F0);

//  printf("\n-------   REGSPEC_CFG_MEM_RAM_SHUTDOWN_ADDR -------\r\n");
    WRITE32(0x1f2ad070, 0x0);
//  printf("\n-------  REGSPEC_BLOCK_MEM_RDY_ADDR -------\r\n");
    WRITE32(0x1f2ad074, 0xFFFFFFFF);
//  printf("\n-------  cap_low_base -------\r\n");
    WRITE32(0x1f2a0024, 0xa0fc1970);
//  printf("\n-------  cap_high_base -------\r\n");
    WRITE32(0x1f2a0028, 0x0000008f);
//	printf("\n------- SDHCI_CAPABILITIES -------\r\n");
    ReadData = READ32(0x1c000040);
//	printf("\n------- sdhci_enable_card_detection -------\r\n");
	ReadData = READ32(0x1c000034);
	WRITE32(0x1c000034, 0x00FF0003);
	WRITE32(0x1c000038, 0x00FF0003);

	ipp_udelay(1000);

	retval = sdio_hw_init(sdio_no);

	return retval;
}

//==============================================================================
//void config_io_expander_for_sdhc ( void)
//{
//   int rc = 0, i = 0;
//   unsigned char *data_iic ;
//   unsigned char data_iic_write[2];
//
//
//}
//==============================================================================
void dump_all_sdhc_reg_for_debug (unsigned char sdio_no)
{
    unsigned int read_value ;

	printf("\n\n======================================================================================================\n\n");
}

//==============================================================================
int sdio_enum(unsigned char sdio_no) {
    int retval=0;
    unsigned int istat,rc;

    //  lprintf (7, "\nSDIO-1 Read CID (Card Identification Data CID) from device\n");
    /* Send command for all CID numbers - CMD2 ARG 0 */
	WRITE_SDIO(sdio_no,ARGUMENT_ADDR, 0x0);
	WRITE_SDIO(sdio_no,TRANSFERMODE_COMMAND_ADDR, 0x02090000);
    //  lprintf (7, "Read 16 byte CID Data,");
	istat = sdio_wait_cmd_complete(sdio_no);
	if (istat & 0x00008000) {
        rc = READ_SDIO(sdio_no,RESPONSE_0_1_ADDR);
    	rc = READ_SDIO(sdio_no,RESPONSE_2_3_ADDR);
    	rc = READ_SDIO(sdio_no,RESPONSE_4_5_ADDR);
	    rc = READ_SDIO(sdio_no,RESPONSE_6_7_ADDR);
        retval=9;
    }
    else {
        rc = READ_SDIO(sdio_no,RESPONSE_0_1_ADDR);
        rc = READ_SDIO(sdio_no,RESPONSE_2_3_ADDR);
        rc = READ_SDIO(sdio_no,RESPONSE_4_5_ADDR);
	    rc = READ_SDIO(sdio_no,RESPONSE_6_7_ADDR);
    }

    return retval;
}

//int sdio_read_write(u8 sdio_no, unsigned int lba, unsigned int pattern) {
//
//    int retval=0, n=0;
//	unsigned int i,addr,readsz,writesz;
//    unsigned int *readptr,*writeptr,ran_pattern[1024];
//
////     if(sdio_no == 1)
//      	//  lprintf(7, "\nSDIO-1 Write in SDMA Mode Lba:0x%08x\n",lba);
////  else
//      	//  lprintf(7, "\nSDIO-2 Write in SDMA Mode Lba:0x%08x\n",lba);
//    writeptr = (unsigned int*)SDIO_OCM_PHYS_ADDR_WR;
//    if(pattern != 0) {
//        //  lprintf(7, "Filling Fixed Pattern:0x%08x in DDR addr:0x%08x,",pattern,writeptr);
//        for(i=0; i<SDIO_BLOCK_SIZE; i+=4) {
//            *writeptr = pattern;
//            //  lprintf(7, "Write addr:0x%08x data:0x%08x\n",writeptr,*writeptr);
//            writeptr++;
//        }
//    }
//    else {
//        //  lprintf(7, "Filling 32 Bit Random Pattern in DDR addr:0x%08x,",writeptr);
//        for(i=0; i<SDIO_BLOCK_SIZE; i+=4) {
////             *writeptr = ran_pattern[i] = rand_32();
//            *writeptr = ran_pattern[i] = rand();
//            //  lprintf(7, "Write addr:0x%08x data:0x%08x\n",writeptr,*writeptr);
//            writeptr++;
//        }
//    }
//    retval = write_vfatdev_sdio_block(sdio_no,lba);
//    if(retval != 0)
//        printf("Fail,WriteCMDFail\n");
//
//    readptr = (unsigned int*)SDIO_OCM_PHYS_ADDR_RD;
//    for(i=0; i<SDIO_BLOCK_SIZE; i+=4) {
//        *readptr = 0x12345678;
//        readptr++;
//    }
//    //  lprintf(7, "Done\n");
//
////     if(sdio_no == 1)
//        //  lprintf (7, "\nSDIO-1 Read in SDMA Mode Start\n");
//    //      else
//        //  lprintf (7, "\nSDIO-2 Read in SDMA Mode Start\n");
//    //  lprintf(7, "\nReading data from Device to DDR addr:0x%08x,",(unsigned int)SDIO_OCM_PHYS_ADDR_RD);
//    retval = read_vfatdev_sdio_block(sdio_no,lba);
//    if(retval != 0)
//        printf("Fail,ReadCMDFail\n");
//
//    readptr = (unsigned int*)SDIO_OCM_PHYS_ADDR_RD;
//    if(pattern != 0) {
//        for(i=0; i<SDIO_BLOCK_SIZE; i+=4) {
//            if(*readptr != pattern) {
//               //  lprintf(3, "Fail,lba:0x%08x,off:0x%08x,exp:0x%08x,got:0x%08x\n",lba,i,pattern,*readptr);
//               retval=1;
//               break;
//            }
//            //  lprintf(7, "SDIO-1 addr:0x%08x data:0x%08x\n",readptr,*readptr);
//            readptr++;
//        }
//    }
//    else {
//        for(i=0; i<SDIO_BLOCK_SIZE; i+=4) {
//            if(*readptr != ran_pattern[i]) {
//               //  lprintf(3, "Fail,lba:0x%08x,off:0x%08x,exp:0x%08x,got:0x%08x\n",lba,i,ran_pattern[i],*readptr);
//               retval=1;
//               break;
//            }
//            //  lprintf(7, "SDIO-1 addr:0x%08x data:0x%08x\n",readptr,*readptr);
//            readptr++;
//        }
//    }
//    if(retval == 0)
//        //  lprintf(7, "Done\n");
//
//    //  lprintf(7, "\n");
//
//    return retval;
//}

//int sdio_read_write_test(u8 sdio_no) {
//    unsigned int lba,pattern;
//
//
//
//    pattern = 0x55aa55aa;
//    lba = 512; // use multiple block 0, 512,1024, etc
//    sdio_read_write(sdio_no, lba, pattern);
//
//
//    return 0;
//}




//------------ for VDIAG End -----------------
u32 sdio_hw_adma(u8 sdio_no,u32 capacity)
{
	u32 cap;
	u32 card_id,temp1,temp2;
	u32 istat;
	u32 rc=0;
	u8  bw_4bits , clock_select=3;
	u8 *buf = (u8*)SDIO_OCM_PHYS_ADDR_RD;
    u32 timeout=0;
    int retval=0;
    u32 res,i ;
	char c;

	high_capacity = 0;
    rc = READ_SDIO(sdio_no,SLOT_INTR_STATUS_HOST_CONTROLLER_VERSION_ADDR);

    rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
    if (!(rc & 0x00010000)) {
            retval=2;
        	printf("\n;=;=;=;=;=;=;=;=;=;=;=;= Card is not DETECTED ;=;=;=;=;=;=;=;=;=;=;=;= \r\n");
			return IPP_ERR_FAIL;
        }
    else
    	printf("\n;=;=;=;=;=;=;=;=;=;=;=;= Card is DETECTED ;=;=;=;=;=;=;=;=;=;=;=;= \r\n");
	rc = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
	printf("=========== SRESET_CLOCK_CONTROL_ADDR = 0x%08x=========== \n",rc );

    rc  = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);

    rc = rc | 0x00070000;
	WRITE_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR, rc);
	arch_timer_usdelay(1);
    WRITE_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR, rc);
	arch_timer_usdelay(1);
    rc  = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
	arch_timer_usdelay(200);
    timeout=100;
	do {
		rc  = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
        timeout--;
    	arch_timer_usdelay(1);
        if(timeout == 0) {
            retval=1;
            break;
        }
	}
	while (rc & 0x00070000);
	rc = READ_SDIO(sdio_no,INTERRUPT_STATUS_ENABLE_ADDR);
	printf("=========== INTERRUPT_STATUS_ENABLE_ADDR = 0x%08x=========== \n",rc );
	rc = 0x02ff00cb; // following linux driver 09-01-2012
    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ENABLE_ADDR, rc);
	arch_timer_usdelay(1);

	rc = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
    rc = rc & 0xF0FFFFFF;
//	rc = rc | 0x0E003007;
//	rc = rc | 0x0E001005;
	rc = rc | 0x0E001005;
    WRITE_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR, rc);
	arch_timer_usdelay(1);
	rc = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);

	printf("\n======================== CMD 0 ======================== \r\n");
    res = send_command_to_card(sdio_no,0x00000000 ,0x00000000 );

	printf("\n======================== CMD 0 ======================== \r\n"); // work arround
    res = send_command_to_card(sdio_no,0x00000000 ,0x00000000 );
    printf("\n======================== CMD 8 ======================== \r\n");
    res = send_command_to_card(sdio_no ,0x000001aa ,0x081a0000 );

    timeout = 100;
    while (1){
    	arch_timer_usdelay(100);
        printf("\n======================== CMD 55 ======================== \r\n");
    	res = send_command_to_card(sdio_no ,0x00000000 ,0x371a0000 ); //OK
    	arch_timer_usdelay(100);
        printf("\n======================== CMD 41 ======================== \r\n");
    	res = send_command_to_card(sdio_no ,0x40300000 ,0x29020000 ); //OK

    	if (respond_0_1&0x80000000 ) break ;
    	if (timeout == 0 ) break ;
    	timeout -- ;

    }
    if (respond_0_1&0x40000000 ) printf("\r This card is SDHC \r\n");
    else {
    	 if (timeout)            printf("\rThis card is SD \r\n");
         }
    high_capacity = (respond_0_1&0x40000000 ) ? 1 : 0;

    if (timeout == 0 ) printf("\n CONFIG FAILED !!! \n");

	arch_timer_usdelay(20);
    printf("\n======================== CMD 2 ======================== \r\n");
    res = send_command_to_card(sdio_no ,0x00000000 ,0x02090000 ); //OK

    printf("Res CMD2 \n");
    printf("RESP-1 data:0x%08x\n",respond_0_1);
    printf("RESP-2 data:0x%08x\n",respond_2_3);
    printf("RESP-3 data:0x%08x\n",respond_4_5);
    printf("RESP-4 data:0x%08x\n",respond_6_7);
    printf("\n");


    printf("\n======================== CMD 3 ======================== \r\n");
	arch_timer_usdelay(20);
    res = send_command_to_card(sdio_no ,0x00000000 ,0x031a0000 ); //OK

    printf("Res CMD3 \n");
    printf("RESP-1 data:0x%08x\n",respond_0_1);
    printf("RESP-2 data:0x%08x\n",respond_2_3);
    printf("RESP-3 data:0x%08x\n",respond_4_5);
    printf("RESP-4 data:0x%08x\n",respond_6_7);
    printf("\n");

    respond_0_1_cmd3 = (respond_0_1 >> 16)& 0xffff  ;
    respond_0_1_cmd3 = respond_0_1_cmd3 << 16 ;

    printf("\n======================== CMD 9 ======================== \r\n");
	arch_timer_usdelay(20);
    res = send_command_to_card(sdio_no ,respond_0_1_cmd3 ,0x09090000 );

    printf("Res CMD9 -->CSD Card \n");
    printf("RESP-1 data:0x%08x\n",respond_0_1);
    printf("RESP-2 data:0x%08x\n",respond_2_3);
    printf("RESP-3 data:0x%08x\n",respond_4_5);
    printf("RESP-4 data:0x%08x\n",respond_6_7);
    printf("\n");

    printf("\n======================== CMD 7 ======================== \r\n");
	arch_timer_usdelay(20);
    res = send_command_to_card(sdio_no ,respond_0_1_cmd3 ,0x071b0000 );
    printf("Res CMD7 --> CMD_SELECT_CARD Card \n");
    printf("RESP-1 data:0x%08x\n",respond_0_1);
    printf("RESP-2 data:0x%08x\n",respond_2_3);
    printf("RESP-3 data:0x%08x\n",respond_4_5);
    printf("RESP-4 data:0x%08x\n",respond_6_7);
    printf("\n");

    //preparing to receive DATA
    rc = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
	printf("=========== BLOCK_DEF_ADDR = 0x%08x=========== \n",rc );

    rc = rc | 0x00010008 ; //run OK
	arch_timer_msdelay(10);
    WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, rc);
	arch_timer_msdelay(10);
    rc = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);

        printf("\n======================== CMD 55 ======================== \r\n");

    	arch_timer_usdelay(20);
        res = send_command_to_card(sdio_no ,respond_0_1_cmd3 ,0x371a0000 ); //OK

        printf("\n======================== CMD 51 ======================== \r\n");

    	arch_timer_usdelay(20);
        res = send_command_to_card(sdio_no ,0x00000000 ,0x333a0032 ); //OK 0x330a0000 danguyen

        printf("Res CMD51 --> CMD_APP_SEND_SCR Card \n");
        printf("RESP-1 data:0x%08x\n",respond_0_1);
        printf("RESP-2 data:0x%08x\n",respond_2_3);
        printf("RESP-3 data:0x%08x\n",respond_4_5);
        printf("RESP-4 data:0x%08x\n",respond_6_7);
        printf("\n");

        rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
        while (rc & 0x00000800){
        	rc = READ_SDIO(sdio_no,BUFFER_DATA_PORT_ADDR);
        	rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
        }
        rc = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);

    	timeout = 4 ;
        printf("\n========================Begin CMD 06 ======================== \r\n");
        while (1){
        	arch_timer_msdelay(20);
        	rc = 0x00010040 ; //run OK  // DATASHEET BUG ==> Count_Block is ON Upper Byte.
        	WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, rc);
        	arch_timer_msdelay(20);
        	rc = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
        	res = send_command_to_card(sdio_no ,0x80fffff1 ,0x063a0032 ); //OK
        	rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);

        	while (rc & 0x00000800){
        		rc = READ_SDIO(sdio_no,BUFFER_DATA_PORT_ADDR);
        		rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
    		}

        	if (timeout == 0 ) break ;
        	timeout -- ;
        }

    #if 1
        //SET FOR CHANGE BUS_WIDTH 4_bit
        printf("\n======================== CMD 55 ======================== \r\n");
    	arch_timer_usdelay(20);
        res = send_command_to_card(sdio_no ,respond_0_1_cmd3 ,0x371a0000 ); //OK
        printf("\n======================== CMD 06 ======================== \r\n");
    	arch_timer_usdelay(20);
        res = send_command_to_card(sdio_no ,0x00000002 ,0x061a0000 ); //OK

        printf("Res CMD06 --> CMD_APP_CHANGE_BUS_WIDTH Card \n");
        printf("RESP-1 data:0x%08x\n",respond_0_1);
        printf("RESP-2 data:0x%08x\n",respond_2_3);
        printf("RESP-3 data:0x%08x\n",respond_4_5);
        printf("RESP-4 data:0x%08x\n",respond_6_7);
        printf("\n");
    #endif
        //=====================================================================//
        //     RECONFIG SDIO HOST FOR RUN 4-BIT MODE , HI-SPEED                            //
        //=====================================================================//


    	rc = READ_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR);
		printf("=========== GAP_WAKEUP_POWER_HOST_CONTROL_ADDR = 0x%08x=========== \n",rc );

    	rc=rc&0xffffff00;
        rc = rc | 0x13 ;          // 4-bit ; Nor-Speed; ADMA1 32 ;
        WRITE_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR, rc);
    	arch_timer_msdelay(1);
        rc = READ_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR);

//		rc = READ_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR);
////		printf("=========== GAP_WAKEUP_POWER_HOST_CONTROL_ADDR = 0x%08x=========== \n",rc );
//
//		rc=rc&0xffffff00;
//		rc = 0x00000f02;
//		WRITE_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR, rc);
//		arch_timer_msdelay(1);
//		rc = READ_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR);

retry_send_command_cmd16:
    	printf("\n======================== CMD 16 ======================== \r\n");
    	arch_timer_usdelay(20);
        res = send_command_to_card(sdio_no ,0x00000200 ,0x101a0000 ); //OK

        rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);

        while (rc & 0x00000800){
            rc = READ_SDIO(sdio_no,BUFFER_DATA_PORT_ADDR);
            rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
        }
        printf("\n");
        printf("Res CMD16 --> MMC_CMD_SET_BLOCKLEN Card \n");
        printf("RESP-1 data:0x%08x\n",respond_0_1);
        printf("RESP-2 data:0x%08x\n",respond_2_3);
        printf("RESP-3 data:0x%08x\n",respond_4_5);
        printf("RESP-4 data:0x%08x\n",respond_6_7);
        printf("\n\r");

    	if ( respond_0_1 == 0x00000920 ) {
    		reset_cmd_data_line(sdio_no);
    		goto retry_send_command_cmd16 ;
    	}
    	arch_timer_msdelay(100);
    	printf("\n======================== TEST WRITE ADMA ======================== \r\n");
    	rc = write_vfatdev_sdio_adma_2_multi_block_test_suspend_resume(sdio_no,capacity,1);
    	arch_timer_msdelay(100);
    	printf("\n======================== TEST READ  ADMA ======================== \r\n");
    	rc = read_vfatdev_sdio_adma_2_multi_block_test_suspend_resume(sdio_no,capacity,1);
    	arch_timer_msdelay(100);
    	printf("\n======================== RESET SD CARD  ======================== \r\n");
    	printf("\n======================== CMD 0 ======================== \r\n");
    	res = send_command_to_card(sdio_no,0x00000000 ,0x00000000 );
    	arch_timer_msdelay(100);
    	return rc;
}


int sdio_adma(u8 sdio_no,u32 capacity) {

    int retval = 1;
	u32 rc,reg;
    struct am862xx_reset_ctrl reset_ctrl;
    u32 *block_size;

    u32 sdu_shutdown, block_mem_rdy;
    u32 ReadData,i;
    sdu_shutdown = 0;
    block_mem_rdy = 0;


//  printf("\n------- CFG_PIN_MUX_SEL_1, CFG_PIN_MUX_SEL_2 -------\r\n");
    WRITE32(0x1f2a016c, 0x00000000);
    WRITE32(0x1f2a0170, 0x00000000);
//  printf("\n-------  AHBC_CLKEN -------\r\n");
    WRITE32(0x1f2ac008, 0x0000030f);
//  printf("\n-------  AHBC_SRST -------\r\n");
//    WRITE32(0x1f2ac000, 0x000000F0);

//    // disable command conflict logic
//    WRITE32(0x1f2a0020, 0x00000001);

//  printf("\n-------   REGSPEC_CFG_MEM_RAM_SHUTDOWN_ADDR -------\r\n");
    WRITE32(0x1f2ad070, 0x0);
//  printf("\n-------  REGSPEC_BLOCK_MEM_RDY_ADDR -------\r\n");
    WRITE32(0x1f2ad074, 0xFFFFFFFF);
//  printf("\n-------  cap_low_base -------\r\n");
    WRITE32(0x1f2a0024, 0xa0fc1970);
//  printf("\n-------  cap_high_base -------\r\n");
    WRITE32(0x1f2a0028, 0x0000008f);
//	printf("\n------- SDHCI_CAPABILITIES -------\r\n");
    ReadData = READ32(0x1c000040);
//	printf("\n------- sdhci_enable_card_detection -------\r\n");
	ReadData = READ32(0x1c000034);
	WRITE32(0x1c000034, 0x00FF0003);
	WRITE32(0x1c000038, 0x00FF0003);

	ipp_udelay(1000);

	retval = sdio_hw_adma(sdio_no,capacity);

	return retval;
}





//=================================================//

u32 sdio_hw_sdma(u8 sdio_no,u32 capacity)
{
	u32 cap;
	u32 card_id,temp1,temp2;
	u32 istat;
	u32 rc=0;
	u8  bw_4bits , clock_select=3;
	u8 *buf = (u8*)SDIO_OCM_PHYS_ADDR_RD;
    u32 timeout=0;
    int retval=0;
    u32 res,i ;
	char c;

	high_capacity = 0;
    rc = READ_SDIO(sdio_no,SLOT_INTR_STATUS_HOST_CONTROLLER_VERSION_ADDR);

    rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
    if (!(rc & 0x00010000)) {
            retval=2;
        	printf("\n;=;=;=;=;=;=;=;=;=;=;=;= Card is not DETECTED ;=;=;=;=;=;=;=;=;=;=;=;= \r\n");
			return IPP_ERR_FAIL;
        }
    else
    	printf("\n;=;=;=;=;=;=;=;=;=;=;=;= Card is DETECTED ;=;=;=;=;=;=;=;=;=;=;=;= \r\n");
	rc = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);

    rc  = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);

    rc = rc | 0x00070000;
	WRITE_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR, rc);
	arch_timer_usdelay(1);
    WRITE_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR, rc);
	arch_timer_usdelay(1);
    rc  = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
	arch_timer_usdelay(200);
    timeout=100;
	do {
		rc  = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
        timeout--;
    	arch_timer_usdelay(1);
        if(timeout == 0) {
            retval=1;
            break;
        }
	}
	while (rc & 0x00070000);
	rc = READ_SDIO(sdio_no,INTERRUPT_STATUS_ENABLE_ADDR);
	rc = 0x02ff00cb; // following linux driver 09-01-2012
    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ENABLE_ADDR, rc);
	arch_timer_usdelay(1);

	rc = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
    rc = rc & 0xF0FFFFFF;
//	rc = rc | 0x0E003007;
//	rc = rc | 0x0E001005;
	rc = rc | 0x0E001005;
    WRITE_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR, rc);
	arch_timer_usdelay(1);
	rc = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);

	printf("\n======================== CMD 0 ======================== \r\n");
    res = send_command_to_card(sdio_no,0x00000000 ,0x00000000 );

	printf("\n======================== CMD 0 ======================== \r\n"); // work arround
    res = send_command_to_card(sdio_no,0x00000000 ,0x00000000 );
    printf("\n======================== CMD 8 ======================== \r\n");
    res = send_command_to_card(sdio_no ,0x000001aa ,0x081a0000 );

    timeout = 100;
    while (1){
    	arch_timer_usdelay(100);
        printf("\n======================== CMD 55 ======================== \r\n");
    	res = send_command_to_card(sdio_no ,0x00000000 ,0x371a0000 ); //OK
    	arch_timer_usdelay(100);
        printf("\n======================== CMD 41 ======================== \r\n");
    	res = send_command_to_card(sdio_no ,0x40300000 ,0x29020000 ); //OK

    	if (respond_0_1&0x80000000) break ;
    	if (timeout == 0 ) break ;
    	timeout -- ;

    }
    if (respond_0_1&0x40000000 ) printf("\r This card is SDHC \r\n");
    else {
    	 if (timeout)            printf("\rThis card is SD \r\n");
         }
    high_capacity = (respond_0_1&0x40000000 ) ? 1 : 0;

    if (timeout == 0 ) printf("\n CONFIG FAILED !!! \n");

	arch_timer_usdelay(20);
    printf("\n======================== CMD 2 ======================== \r\n");
    res = send_command_to_card(sdio_no ,0x00000000 ,0x02090000 ); //OK

    printf("Res CMD2 \n");
    printf("RESP-1 data:0x%08x\n",respond_0_1);
    printf("RESP-2 data:0x%08x\n",respond_2_3);
    printf("RESP-3 data:0x%08x\n",respond_4_5);
    printf("RESP-4 data:0x%08x\n",respond_6_7);
    printf("\n");


    printf("\n======================== CMD 3 ======================== \r\n");
	arch_timer_usdelay(20);
    res = send_command_to_card(sdio_no ,0x00000000 ,0x031a0000 ); //OK

    printf("Res CMD3 \n");
    printf("RESP-1 data:0x%08x\n",respond_0_1);
    printf("RESP-2 data:0x%08x\n",respond_2_3);
    printf("RESP-3 data:0x%08x\n",respond_4_5);
    printf("RESP-4 data:0x%08x\n",respond_6_7);
    printf("\n");

    respond_0_1_cmd3 = (respond_0_1 >> 16)& 0xffff  ;
    respond_0_1_cmd3 = respond_0_1_cmd3 << 16 ;

    printf("\n======================== CMD 9 ======================== \r\n");
	arch_timer_usdelay(20);
    res = send_command_to_card(sdio_no ,respond_0_1_cmd3 ,0x09090000 );

    printf("Res CMD9 -->CSD Card \n");
    printf("RESP-1 data:0x%08x\n",respond_0_1);
    printf("RESP-2 data:0x%08x\n",respond_2_3);
    printf("RESP-3 data:0x%08x\n",respond_4_5);
    printf("RESP-4 data:0x%08x\n",respond_6_7);
    printf("\n");

    printf("\n======================== CMD 7 ======================== \r\n");
	arch_timer_usdelay(20);
    res = send_command_to_card(sdio_no ,respond_0_1_cmd3 ,0x071b0000 );
    printf("Res CMD7 --> CMD_SELECT_CARD Card \n");
    printf("RESP-1 data:0x%08x\n",respond_0_1);
    printf("RESP-2 data:0x%08x\n",respond_2_3);
    printf("RESP-3 data:0x%08x\n",respond_4_5);
    printf("RESP-4 data:0x%08x\n",respond_6_7);
    printf("\n");

    //preparing to receive DATA
    rc = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
	arch_timer_msdelay(20);
    rc = rc | 0x00010008 ; //run OK
    WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, rc);
	arch_timer_msdelay(1);
    rc = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);

        printf("\n======================== CMD 55 ======================== \r\n");

    	arch_timer_usdelay(20);
        res = send_command_to_card(sdio_no ,respond_0_1_cmd3 ,0x371a0000 ); //OK

        printf("\n======================== CMD 51 ======================== \r\n");

    	arch_timer_usdelay(20);
        res = send_command_to_card(sdio_no ,0x00000000 ,0x333a0032 ); //OK 0x330a0000 danguyen

        printf("Res CMD51 --> CMD_APP_SEND_SCR Card \n");
        printf("RESP-1 data:0x%08x\n",respond_0_1);
        printf("RESP-2 data:0x%08x\n",respond_2_3);
        printf("RESP-3 data:0x%08x\n",respond_4_5);
        printf("RESP-4 data:0x%08x\n",respond_6_7);
        printf("\n");

        rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
        while (rc & 0x00000800){
        	rc = READ_SDIO(sdio_no,BUFFER_DATA_PORT_ADDR);
        	rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
        }
        rc = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);

    	timeout = 4 ;
        printf("\n========================Begin CMD 06 ======================== \r\n");
        while (1){
//        	ipp_udelay(100);
        	arch_timer_msdelay(20);
        	rc = 0x00010040 ; //run OK  // DATASHEET BUG ==> Count_Block is ON Upper Byte.
        	WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, rc);
        	ipp_udelay(DELAY_1);
        	rc = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);

        	res = send_command_to_card(sdio_no ,0x80fffff1 ,0x063a0032 ); //OK

        	rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);

        	while (rc & 0x00000800){
        		rc = READ_SDIO(sdio_no,BUFFER_DATA_PORT_ADDR);
        		rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
    		}

        	if (timeout == 0 ) break ;
        	timeout -- ;
        }

    #if 1
        //SET FOR CHANGE BUS_WIDTH 4_bit
        printf("\n======================== CMD 55 ======================== \r\n");
    	arch_timer_usdelay(20);
        res = send_command_to_card(sdio_no ,respond_0_1_cmd3 ,0x371a0000 ); //OK
        printf("\n======================== CMD 06 ======================== \r\n");
    	arch_timer_usdelay(20);
        res = send_command_to_card(sdio_no ,0x00000002 ,0x061a0000 ); //OK

        printf("Res CMD06 --> CMD_APP_CHANGE_BUS_WIDTH Card \n");
        printf("RESP-1 data:0x%08x\n",respond_0_1);
        printf("RESP-2 data:0x%08x\n",respond_2_3);
        printf("RESP-3 data:0x%08x\n",respond_4_5);
        printf("RESP-4 data:0x%08x\n",respond_6_7);
        printf("\n");
    #endif
        //=====================================================================//
        //     RECONFIG SDIO HOST FOR RUN 4-BIT MODE , HI-SPEED                            //
        //=====================================================================//

		rc = READ_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR);

		rc=rc&0xffffff00;
		rc = 0x00000f02;
		WRITE_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR, rc);
		arch_timer_msdelay(1);
		rc = READ_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR);

retry_send_command_cmd16:
    	printf("\n======================== CMD 16 ======================== \r\n");
    	arch_timer_usdelay(20);
        res = send_command_to_card(sdio_no ,0x00000200 ,0x101a0000 ); //OK

        rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);

        while (rc & 0x00000800){
            rc = READ_SDIO(sdio_no,BUFFER_DATA_PORT_ADDR);
            rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
        }
        printf("\n");
        printf("Res CMD16 --> MMC_CMD_SET_BLOCKLEN Card \n");
        printf("RESP-1 data:0x%08x\n",respond_0_1);
        printf("RESP-2 data:0x%08x\n",respond_2_3);
        printf("RESP-3 data:0x%08x\n",respond_4_5);
        printf("RESP-4 data:0x%08x\n",respond_6_7);
        printf("\n\r");

    	if ( respond_0_1 == 0x00000920 ) {
    		reset_cmd_data_line(sdio_no);
    		goto retry_send_command_cmd16 ;
    	}
    	arch_timer_usdelay(1000);
    	printf("\n======================== TEST WRITE SDMA ======================== \r\n");
        write_vfatdev_sdio_sdma_multi_block(sdio_no,capacity,1);
    	printf("\n======================== TEST READ  SDMA ======================== \r\n");
        rc = read_vfatdev_sdio_sdma_multi_block(sdio_no, capacity ,1);
        arch_timer_usdelay(1000);

        printf("\n======================== CMD 0 ======================== \r\n");
        res = send_command_to_card(sdio_no,0x00000000 ,0x00000000 );
        arch_timer_usdelay(1000);

        printf("\n======================== CMD 0 ======================== \r\n");
        res = send_command_to_card(sdio_no,0x00000000 ,0x00000000 );
        arch_timer_usdelay(1000);


    	return rc;
}

//=================================================//
int sdio_sdma(u8 sdio_no,u32 capacity) {

    int retval = 1;
	u32 rc,reg;
    struct am862xx_reset_ctrl reset_ctrl;
    u32 *block_size;

    u32 sdu_shutdown, block_mem_rdy;
    u32 ReadData,i;
    sdu_shutdown = 0;
    block_mem_rdy = 0;


//  printf("\n------- CFG_PIN_MUX_SEL_1, CFG_PIN_MUX_SEL_2 -------\r\n");
    WRITE32(0x1f2a016c, 0x00000000);
    WRITE32(0x1f2a0170, 0x00000000);
//  printf("\n-------  AHBC_CLKEN -------\r\n");
    WRITE32(0x1f2ac008, 0x0000030f);
//  printf("\n-------  AHBC_SRST -------\r\n");
    WRITE32(0x1f2ac000, 0x000000F0);

//  printf("\n-------   REGSPEC_CFG_MEM_RAM_SHUTDOWN_ADDR -------\r\n");
    WRITE32(0x1f2ad070, 0x0);
//  printf("\n-------  REGSPEC_BLOCK_MEM_RDY_ADDR -------\r\n");
    WRITE32(0x1f2ad074, 0xFFFFFFFF);
//  printf("\n-------  cap_low_base -------\r\n");
    WRITE32(0x1f2a0024, 0xa0fc1970);
//  printf("\n-------  cap_high_base -------\r\n");
    WRITE32(0x1f2a0028, 0x0000008f);
//	printf("\n------- SDHCI_CAPABILITIES -------\r\n");
    ReadData = READ32(0x1c000040);
//	printf("\n------- sdhci_enable_card_detection -------\r\n");
	ReadData = READ32(0x1c000034);
	WRITE32(0x1c000034, 0x00FF0003);
	WRITE32(0x1c000038, 0x00FF0003);

	ipp_udelay(1000);

	retval = sdio_hw_sdma(sdio_no,capacity);

	return retval;
}


u32 sdio_hw_pio(u8 sdio_no, unsigned int capacity)
{
//	u32 cap;
//	u32 card_id,temp1,temp2;
//	u32 istat;
//	u32 rc=0;
//	u8  bw_4bits , clock_select=3;
//	u8 *buf = (u8*)SDIO_OCM_PHYS_ADDR_RD;
//    u32 timeout=0;
//    int retval=0;
//    u32 res,i ;
//	char c;
//
//	high_capacity = 0;
//    rc = READ_SDIO(sdio_no,SLOT_INTR_STATUS_HOST_CONTROLLER_VERSION_ADDR);
//
//    rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
//    if (!(rc & 0x00010000)) {
//            retval=2;
//        	printf("\n;=;=;=;=;=;=;=;=;=;=;=;= Card is not DETECTED ;=;=;=;=;=;=;=;=;=;=;=;= \r\n");
//			return IPP_ERR_FAIL;
//        }
//    else
//    	printf("\n;=;=;=;=;=;=;=;=;=;=;=;= Card is DETECTED ;=;=;=;=;=;=;=;=;=;=;=;= \r\n");
//
//	rc = 0x02ff00cb; // following linux driver 09-01-2012
//    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ENABLE_ADDR, rc);
//	arch_timer_usdelay(1);
//
//	rc = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
//    rc = rc & 0xF0FFFFFF;
////	rc = rc | 0x0E003007;
//	rc = rc | 0x0E001005;
//    WRITE_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR, rc);
//	arch_timer_msdelay(100);
//	rc = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
////	if(sdio_no == 2){
////        WRITE_SDIO(sdio_no,ARGUMENT_ADDR, 0);
////        arch_timer_msdelay(1);
////    	WRITE_SDIO(sdio_no,TRANSFERMODE_COMMAND_ADDR, 0);
////	}
//
//	/*
//	 * RSTALL[0] : Software reset for all
//	 * 1 = reset
//	 * 0 = work
//	 */
//////	xgene_sdhci_writeb(host, mask, &host->reg->swrst);
////	WRITE_SDIO_8(sdio_no,SRESET_ADDR, 0x0E);
////
////	/* Wait max 100 ms */
////	timeout = 100;
////
////	/* hw clears the bit when it's done */
////	while (READ_SDIO_8(sdio_no,SRESET_ADDR) & 0x01) {
////		if (timeout == 0) {
////			printf("reset Timeout Error\n");
////			return -1;
////		}
////		timeout--;
////		arch_timer_usdelay(1000);
////	}
//////	if (sdio_no == 2) {
//////		//        WRITE_SDIO(sdio_no,ARGUMENT_ADDR, 0);
//////		arch_timer_msdelay(1);
//////		WRITE_SDIO(sdio_no, TRANSFERMODE_COMMAND_ADDR, 0);
//////	}
////
////	arch_timer_msdelay(100);
////
////	/* Enable internal clock */
////	rc  = READ_SDIO_16(sdio_no, SRESET_CLOCK_CONTROL_ADDR);
////	rc |= 0x0001;
////	WRITE_SDIO_16(sdio_no, SRESET_CLOCK_CONTROL_ADDR , rc);
////
////	/* Wait until internal clock is stable before continue */
////	do {
////		arch_timer_usdelay(200);
////		rc = READ_SDIO_16(sdio_no, SRESET_CLOCK_CONTROL_ADDR);
////	} while (!(rc & 0x02));
////
////	/* Enable SD clock after internal clock is stable */
////	rc |= 0x0004;
////	WRITE_SDIO_16(sdio_no, SRESET_CLOCK_CONTROL_ADDR , rc);
////	arch_timer_usdelay(200);
////	/* Check to make sure SD clock is enabled */
////	rc = READ_SDIO_16(sdio_no, SRESET_CLOCK_CONTROL_ADDR);
////
////	if (rc & 0x0004)
////		printf("Enable clk SD ok\n");
////	else{
////		printf("Enable clk SD fail\n");
////		return -1;
////	}
////
////	arch_timer_msdelay(100);
//
//
//
//
//
//
//
//
//	printf("\n======================== CMD 0 ======================== \r\n");
//    res = send_command_to_card(sdio_no,0x00000000 ,0x00000000 );
//
//	printf("\n======================== CMD 0 ======================== \r\n"); // work arround
//    res = send_command_to_card(sdio_no,0x00000000 ,0x00000000 );
//    printf("\n======================== CMD 8 ======================== \r\n");
//    res = send_command_to_card(sdio_no ,0x000001aa ,0x081a0000 );
//
//    timeout = 100;
//    while (1){
//    	arch_timer_usdelay(100);
//        printf("\n======================== CMD 55 ======================== \r\n");
//    	res = send_command_to_card(sdio_no ,0x00000000 ,0x371a0000 ); //OK
//    	arch_timer_usdelay(100);
//        printf("\n======================== CMD 41 ======================== \r\n");
//    	res = send_command_to_card(sdio_no ,0x40300000 ,0x29020000 ); //OK
////        printf("\n======================== Respone = 0x%08x ======================== \r\n", res);
//
//    	if (respond_0_1&0x80000000 ) break ;
//    	if (timeout == 0 ) break ;
//    	timeout -- ;
//
//    }
//    if (respond_0_1&0x40000000 ) printf("\r This card is SDHC \r\n");
//    else {
//    	 if (timeout)            printf("\rThis card is SD \r\n");
//         }
//    high_capacity = (respond_0_1&0x40000000 ) ? 1 : 0;
//
//    if (timeout == 0 ) printf("\n CONFIG FAILED !!! \n");
//
//	arch_timer_usdelay(20);
//    printf("\n======================== CMD 2 ======================== \r\n");
//    res = send_command_to_card(sdio_no ,0x00000000 ,0x02090000 ); //OK
//
//    printf("Res CMD2 \n");
//    printf("RESP-1 data:0x%08x\n",respond_0_1);
//    printf("RESP-2 data:0x%08x\n",respond_2_3);
//    printf("RESP-3 data:0x%08x\n",respond_4_5);
//    printf("RESP-4 data:0x%08x\n",respond_6_7);
//    printf("\n");
//
//
//    printf("\n======================== CMD 3 ======================== \r\n");
//	arch_timer_usdelay(20);
//    res = send_command_to_card(sdio_no ,0x00000000 ,0x031a0000 ); //OK
//
//    printf("Res CMD3 \n");
//    printf("RESP-1 data:0x%08x\n",respond_0_1);
//    printf("RESP-2 data:0x%08x\n",respond_2_3);
//    printf("RESP-3 data:0x%08x\n",respond_4_5);
//    printf("RESP-4 data:0x%08x\n",respond_6_7);
//    printf("\n");
//
//    respond_0_1_cmd3 = (respond_0_1 >> 16)& 0xffff  ;
//    respond_0_1_cmd3 = respond_0_1_cmd3 << 16 ;
//
//    printf("\n======================== CMD 9 ======================== \r\n");
//	arch_timer_usdelay(20);
//    res = send_command_to_card(sdio_no ,respond_0_1_cmd3 ,0x09090000 );
//
//    printf("Res CMD9 -->CSD Card \n");
//    printf("RESP-1 data:0x%08x\n",respond_0_1);
//    printf("RESP-2 data:0x%08x\n",respond_2_3);
//    printf("RESP-3 data:0x%08x\n",respond_4_5);
//    printf("RESP-4 data:0x%08x\n",respond_6_7);
//    printf("\n");
//
//    printf("\n======================== CMD 7 ======================== \r\n");
//	arch_timer_usdelay(20);
//    res = send_command_to_card(sdio_no ,respond_0_1_cmd3 ,0x071b0000 );
//    printf("Res CMD7 --> CMD_SELECT_CARD Card \n");
//    printf("RESP-1 data:0x%08x\n",respond_0_1);
//    printf("RESP-2 data:0x%08x\n",respond_2_3);
//    printf("RESP-3 data:0x%08x\n",respond_4_5);
//    printf("RESP-4 data:0x%08x\n",respond_6_7);
//    printf("\n");
//
//	arch_timer_msdelay(1);
//    rc = READ_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR);
//
//retry_send_command_cmd16:
//	printf("\n======================== CMD 16 ======================== \r\n");
//	arch_timer_usdelay(20);
//    res = send_command_to_card(sdio_no ,0x00000200 ,0x101a0000 ); //OK
//
//    rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
//
//    while (rc & 0x00000800){
//        rc = READ_SDIO(sdio_no,BUFFER_DATA_PORT_ADDR);
//        rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
//    }
//    printf("\n");
//    printf("Res CMD16 --> MMC_CMD_SET_BLOCKLEN Card \n");
//    printf("RESP-1 data:0x%08x\n",respond_0_1);
//    printf("RESP-2 data:0x%08x\n",respond_2_3);
//    printf("RESP-3 data:0x%08x\n",respond_4_5);
//    printf("RESP-4 data:0x%08x\n",respond_6_7);
//    printf("\n\r");
//
//	if ( respond_0_1 == 0x00000920 ) {
//		reset_cmd_data_line(sdio_no);
//		goto retry_send_command_cmd16 ;
//	}

	u32 cap;
	u32 card_id,temp1,temp2;
	u32 istat;
	u32 rc=0;
	u8  bw_4bits , clock_select=3;
	u8 *buf = (u8*)SDIO_OCM_PHYS_ADDR_RD;
    u32 timeout=0;
    int retval=0;
    u32 res,i ;
	char c;

	high_capacity = 0;
    rc = READ_SDIO(sdio_no,SLOT_INTR_STATUS_HOST_CONTROLLER_VERSION_ADDR);

    rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
    if (!(rc & 0x00010000)) {
            retval=2;
        	printf("\n;=;=;=;=;=;=;=;=;=;=;=;= Card is not DETECTED ;=;=;=;=;=;=;=;=;=;=;=;= \r\n");
			return IPP_ERR_FAIL;
        }
    else
    	printf("\n;=;=;=;=;=;=;=;=;=;=;=;= Card is DETECTED ;=;=;=;=;=;=;=;=;=;=;=;= \r\n");
	rc = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);

    rc  = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);

    rc = rc | 0x00070000;
	WRITE_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR, rc);
	arch_timer_usdelay(1);
    WRITE_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR, rc);
	arch_timer_usdelay(1);
    rc  = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
	arch_timer_usdelay(200);
    timeout=100;
	do {
		rc  = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
        timeout--;
    	arch_timer_usdelay(1);
        if(timeout == 0) {
            retval=1;
            break;
        }
	}
	while (rc & 0x00070000);
	rc = READ_SDIO(sdio_no,INTERRUPT_STATUS_ENABLE_ADDR);
	rc = 0x02ff00cb; // following linux driver 09-01-2012
    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ENABLE_ADDR, rc);
	arch_timer_usdelay(1);

	rc = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
    rc = rc & 0xF0FFFFFF;
//	rc = rc | 0x0E003007;
//	rc = rc | 0x0E001005;
	rc = rc | 0x0E001005;
    WRITE_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR, rc);
	arch_timer_usdelay(1);
	rc = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);

	printf("\n======================== CMD 0 ======================== \r\n");
    res = send_command_to_card(sdio_no,0x00000000 ,0x00000000 );

	printf("\n======================== CMD 0 ======================== \r\n"); // work arround
    res = send_command_to_card(sdio_no,0x00000000 ,0x00000000 );
    printf("\n======================== CMD 8 ======================== \r\n");
    res = send_command_to_card(sdio_no ,0x000001aa ,0x081a0000 );

    timeout = 100;
    while (1){
    	arch_timer_usdelay(100);
        printf("\n======================== CMD 55 ======================== \r\n");
    	res = send_command_to_card(sdio_no ,0x00000000 ,0x371a0000 ); //OK
    	arch_timer_usdelay(100);
        printf("\n======================== CMD 41 ======================== \r\n");
    	res = send_command_to_card(sdio_no ,0x40300000 ,0x29020000 ); //OK

    	if (respond_0_1&0x80000000) break ;
    	if (timeout == 0 ) break ;
    	timeout -- ;

    }
    if (respond_0_1&0x40000000 ) printf("\r This card is SDHC \r\n");
    else {
    	 if (timeout)            printf("\rThis card is SD \r\n");
         }
    high_capacity = (respond_0_1&0x40000000 ) ? 1 : 0;

    if (timeout == 0 ) printf("\n CONFIG FAILED !!! \n");

	arch_timer_usdelay(20);
    printf("\n======================== CMD 2 ======================== \r\n");
    res = send_command_to_card(sdio_no ,0x00000000 ,0x02090000 ); //OK

    printf("Res CMD2 \n");
    printf("RESP-1 data:0x%08x\n",respond_0_1);
    printf("RESP-2 data:0x%08x\n",respond_2_3);
    printf("RESP-3 data:0x%08x\n",respond_4_5);
    printf("RESP-4 data:0x%08x\n",respond_6_7);
    printf("\n");


    printf("\n======================== CMD 3 ======================== \r\n");
	arch_timer_usdelay(20);
    res = send_command_to_card(sdio_no ,0x00000000 ,0x031a0000 ); //OK

    printf("Res CMD3 \n");
    printf("RESP-1 data:0x%08x\n",respond_0_1);
    printf("RESP-2 data:0x%08x\n",respond_2_3);
    printf("RESP-3 data:0x%08x\n",respond_4_5);
    printf("RESP-4 data:0x%08x\n",respond_6_7);
    printf("\n");

    respond_0_1_cmd3 = (respond_0_1 >> 16)& 0xffff  ;
    respond_0_1_cmd3 = respond_0_1_cmd3 << 16 ;

    printf("\n======================== CMD 9 ======================== \r\n");
	arch_timer_usdelay(20);
    res = send_command_to_card(sdio_no ,respond_0_1_cmd3 ,0x09090000 );

    printf("Res CMD9 -->CSD Card \n");
    printf("RESP-1 data:0x%08x\n",respond_0_1);
    printf("RESP-2 data:0x%08x\n",respond_2_3);
    printf("RESP-3 data:0x%08x\n",respond_4_5);
    printf("RESP-4 data:0x%08x\n",respond_6_7);
    printf("\n");

    printf("\n======================== CMD 7 ======================== \r\n");
	arch_timer_usdelay(20);
    res = send_command_to_card(sdio_no ,respond_0_1_cmd3 ,0x071b0000 );
    printf("Res CMD7 --> CMD_SELECT_CARD Card \n");
    printf("RESP-1 data:0x%08x\n",respond_0_1);
    printf("RESP-2 data:0x%08x\n",respond_2_3);
    printf("RESP-3 data:0x%08x\n",respond_4_5);
    printf("RESP-4 data:0x%08x\n",respond_6_7);
    printf("\n");

    //preparing to receive DATA
    rc = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
	arch_timer_msdelay(20);
    rc = rc | 0x00010008 ; //run OK
    WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, rc);
	arch_timer_msdelay(1);
    rc = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);

        printf("\n======================== CMD 55 ======================== \r\n");

    	arch_timer_usdelay(20);
        res = send_command_to_card(sdio_no ,respond_0_1_cmd3 ,0x371a0000 ); //OK

        printf("\n======================== CMD 51 ======================== \r\n");

    	arch_timer_usdelay(20);
        res = send_command_to_card(sdio_no ,0x00000000 ,0x333a0032 ); //OK 0x330a0000 danguyen

        printf("Res CMD51 --> CMD_APP_SEND_SCR Card \n");
        printf("RESP-1 data:0x%08x\n",respond_0_1);
        printf("RESP-2 data:0x%08x\n",respond_2_3);
        printf("RESP-3 data:0x%08x\n",respond_4_5);
        printf("RESP-4 data:0x%08x\n",respond_6_7);
        printf("\n");

        rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
        while (rc & 0x00000800){
        	rc = READ_SDIO(sdio_no,BUFFER_DATA_PORT_ADDR);
        	rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
        }
        rc = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);

    	timeout = 4 ;
        printf("\n========================Begin CMD 06 ======================== \r\n");
        while (1){
//        	ipp_udelay(100);
        	arch_timer_msdelay(20);
        	rc = 0x00010040 ; //run OK  // DATASHEET BUG ==> Count_Block is ON Upper Byte.
        	WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, rc);
        	ipp_udelay(DELAY_1);
        	rc = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);

        	res = send_command_to_card(sdio_no ,0x80fffff1 ,0x063a0032 ); //OK

        	rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);

        	while (rc & 0x00000800){
        		rc = READ_SDIO(sdio_no,BUFFER_DATA_PORT_ADDR);
        		rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
    		}

        	if (timeout == 0 ) break ;
        	timeout -- ;
        }

    #if 1
        //SET FOR CHANGE BUS_WIDTH 4_bit
        printf("\n======================== CMD 55 ======================== \r\n");
    	arch_timer_usdelay(20);
        res = send_command_to_card(sdio_no ,respond_0_1_cmd3 ,0x371a0000 ); //OK
        printf("\n======================== CMD 06 ======================== \r\n");
    	arch_timer_usdelay(20);
        res = send_command_to_card(sdio_no ,0x00000002 ,0x061a0000 ); //OK

        printf("Res CMD06 --> CMD_APP_CHANGE_BUS_WIDTH Card \n");
        printf("RESP-1 data:0x%08x\n",respond_0_1);
        printf("RESP-2 data:0x%08x\n",respond_2_3);
        printf("RESP-3 data:0x%08x\n",respond_4_5);
        printf("RESP-4 data:0x%08x\n",respond_6_7);
        printf("\n");
    #endif
        //=====================================================================//
        //     RECONFIG SDIO HOST FOR RUN 4-BIT MODE , HI-SPEED                            //
        //=====================================================================//

		rc = READ_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR);

		rc=rc&0xffffff00;
		rc = 0x00000f02;
		WRITE_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR, rc);
		arch_timer_msdelay(1);
		rc = READ_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR);

retry_send_command_cmd16:
    	printf("\n======================== CMD 16 ======================== \r\n");
    	arch_timer_usdelay(20);
        res = send_command_to_card(sdio_no ,0x00000200 ,0x101a0000 ); //OK

        rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);

        while (rc & 0x00000800){
            rc = READ_SDIO(sdio_no,BUFFER_DATA_PORT_ADDR);
            rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
        }
        printf("\n");
        printf("Res CMD16 --> MMC_CMD_SET_BLOCKLEN Card \n");
        printf("RESP-1 data:0x%08x\n",respond_0_1);
        printf("RESP-2 data:0x%08x\n",respond_2_3);
        printf("RESP-3 data:0x%08x\n",respond_4_5);
        printf("RESP-4 data:0x%08x\n",respond_6_7);
        printf("\n\r");

    	if ( respond_0_1 == 0x00000920 ) {
    		reset_cmd_data_line(sdio_no);
    		goto retry_send_command_cmd16 ;
    	}
    	arch_timer_usdelay(1000);

	printf("\n======================== TEST WRITE PIO ======================== \r\n");
	rc = test_write_pio(sdio_no, capacity);
	arch_timer_msdelay(100);
	printf("\n======================== TEST READ  PIO ======================== \r\n");
	rc = test_read_pio(sdio_no, capacity);
	printf("\n======================== CMD 0 ======================== \r\n");
//	res = send_command_to_card(sdio_no,0x00000000 ,0x00000000 );
	send_command_to_card(sdio_no,0x00000000 ,0x00000000 );
	arch_timer_msdelay(100);
	send_command_to_card(sdio_no,0x00000000 ,0x00000000 );
	arch_timer_msdelay(100);
	return rc;
}

int sdio_pio(u8 sdio_no,unsigned int capacity) {

    int retval = 1;
	u32 rc,reg;
    struct am862xx_reset_ctrl reset_ctrl;
    u32 *block_size;

    u32 sdu_shutdown, block_mem_rdy;
    u32 ReadData,i;
    sdu_shutdown = 0;
    block_mem_rdy = 0;


//  printf("\n------- CFG_PIN_MUX_SEL_1, CFG_PIN_MUX_SEL_2 -------\r\n");
    WRITE32(0x1f2a016c, 0x00000000);
    WRITE32(0x1f2a0170, 0x00000000);
//  printf("\n-------  AHBC_CLKEN -------\r\n");
    WRITE32(0x1f2ac008, 0x0000030f);
//  printf("\n-------  AHBC_SRST -------\r\n");
    WRITE32(0x1f2ac000, 0x000000F0);

//  printf("\n-------   REGSPEC_CFG_MEM_RAM_SHUTDOWN_ADDR -------\r\n");
    WRITE32(0x1f2ad070, 0x0);
//  printf("\n-------  REGSPEC_BLOCK_MEM_RDY_ADDR -------\r\n");
    WRITE32(0x1f2ad074, 0xFFFFFFFF);
//  printf("\n-------  cap_low_base -------\r\n");
    WRITE32(0x1f2a0024, 0xa0fc1970);
//  printf("\n-------  cap_high_base -------\r\n");
    WRITE32(0x1f2a0028, 0x0000008f);
//	printf("\n------- SDHCI_CAPABILITIES -------\r\n");
    ReadData = READ32(0x1c000040);
//	printf("\n------- sdhci_enable_card_detection -------\r\n");
	ReadData = READ32(0x1c000034);
	WRITE32(0x1c000034, 0x00FF0003);
	WRITE32(0x1c000038, 0x00FF0003);

	WRITE32(0x1f2a0020, 0x1fe07);

	ipp_udelay(1000);

	retval = sdio_hw_pio(sdio_no,capacity);
//	retval = sdio_hw_pio(sdio_no,capacity);

	return retval;
}




u32 sdio_hw_emmc(u8 sdio_no)
{
	u32 cap;
	u32 card_id,temp1,temp2;
	u32 istat;
	u32 rc = 0;
	u8  bw_4bits , clock_select=3;
	u8 *buf = (u8*)SDIO_OCM_PHYS_ADDR_RD;
    u32 timeout=0;
    int retval=0;
    u32 res,i ;
	char c;

	high_capacity = 0;
    rc = READ_SDIO(sdio_no,SLOT_INTR_STATUS_HOST_CONTROLLER_VERSION_ADDR);

    rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
    if (!(rc & 0x00010000)) {
            retval=2;
        	printf("\n;=;=;=;=;=;=;=;=;=;=;=;= Card is not DETECTED ;=;=;=;=;=;=;=;=;=;=;=;= \r\n");
			return IPP_ERR_FAIL;
        }
    else
    	printf("\n;=;=;=;=;=;=;=;=;=;=;=;= Card is DETECTED ;=;=;=;=;=;=;=;=;=;=;=;= \r\n");

	rc = 0x02ff00cb; // following linux driver 09-01-2012
    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ENABLE_ADDR, rc);
	arch_timer_usdelay(1);

	rc = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
	printf("\nSRESET_CLOCK_CONTROL_ADDR_Test0 = 0x%08x \r\n", rc);
    rc = rc & 0xF0FFFFFF;
	rc = rc | 0x0E003F07;
    WRITE_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR, rc);
	arch_timer_usdelay(1);
	rc = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
	printf("\nSRESET_CLOCK_CONTROL_ADDR_Test1 = 0x%08x \r\n", rc);
	// Reset MMC card
	printf("\n======================== CMD 0 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x00000 ,0x000000);
	printf("\n======================== CMD 0 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x00000 ,0x000000);

	printf("\n======================== CMD 1 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x000 ,0x01020000);
	printf("\n======================== CMD 0 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x00000 ,0x000000);

	printf("\n======================== CMD 1 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x000 ,0x01020000);
	printf("\n======================== CMD 1 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x40300000 ,0x01020000);
	printf("\n======================== CMD 1 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x40300000 ,0x01020000);

	printf("\n======================== CMD2 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x0 ,0x02090000);
	printf("\n======================== CMD 3 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x10000 ,0x031a0000);

	printf("\n======================== CMD 9 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x10000 ,0x09090000);

	printf("\n======================== CMD 7 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x10000 ,0x071a0000);


	printf("\n======================== CMD 6 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x3af0101 ,0x061b0000);

	printf("\n======================== CMD 13 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x10000 ,0x0d1a0000);

	printf("\n======================== CMD 6 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x3b90101 ,0x061b0000);

	printf("\n======================== CMD 13 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x10000 ,0x0d1a0000);

	// set clock to 50 Mhz
	rc=READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
	printf("\nSRESET_CLOCK_CONTROL_ADDR_Test2 = 0x%08x \r\n", rc);
	rc = rc&0xFFFF0000;
	rc = rc| 0x0007;
	WRITE_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR, rc);
	arch_timer_msdelay(10);

	rc=READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
	printf("\nSRESET_CLOCK_CONTROL_ADDR_Test3 = 0x%08x \r\n", rc);

	rc = rc&0xFFF0FFFF;
	rc = rc| 0x00090000;
	WRITE_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR, rc);
	arch_timer_msdelay(10);

	printf("\n======================== CMD 6 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x3bb0401 ,0x061b0000);
	printf("\n======================== CMD 13 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x10000 ,0x0d1a0000);


	printf("\n======================== CMD 6 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x3b70101 ,0x061b0000);
	printf("\n======================== CMD 13 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x10000 ,0x0d1a0000);

	printf("\n======================== CMD 6 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x3a10101 ,0x061b0000);
	printf("\n======================== CMD 13 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x10000 ,0x0d1a0000);


	rc = READ_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR);
	rc=rc&0xffffff00;
    rc = rc | 0x17 ;          // 4-bit ; Nor-Speed; ADMA1 32 ;
    WRITE_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR, rc);
	arch_timer_msdelay(1);
    rc = READ_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR);
	printf("\nSRESET_CLOCK_CONTROL_ADDR_Test2 = 0x%08x \r\n", rc);
	printf("\n======================== INIT COMPLETE ======================== \r\n");


	printf("\n======================== TEST WRITE ADMA 8block======================== \r\n");

	rc = write_vfatdev_emmc_adma_2_multi_block_test_suspend_resume(sdio_no,0x00000000,1);

	printf("\n======================== TEST READ  ADMA 8block ======================== \r\n");
	stop_monitor_axi();
	bw_masterRD_stop_count(64);
	start_monitor_axi();
	monitor_dump();
	rc = read_vfatdev_emmc_adma_2_multi_block_test_suspend_resume(sdio_no,0x00000000,1);
	monitor_dump();
	// Reset MMC card
	printf("\n======================== CMD 0 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x00000 ,0x000000);
	printf("\n======================== CMD 0 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x00000 ,0x000000);
	return rc;
}

int emmc_adma(u8 sdio_no) {

    int retval = 1;
	u32 rc,reg;
    struct am862xx_reset_ctrl reset_ctrl;
    u32 *block_size;

    u32 sdu_shutdown, block_mem_rdy;
    u32 ReadData,i;
    sdu_shutdown = 0;
    block_mem_rdy = 0;


//  printf("\n------- CFG_PIN_MUX_SEL_1, CFG_PIN_MUX_SEL_2 -------\r\n");
    WRITE32(0x1f2a016c, 0x00000000);
    WRITE32(0x1f2a0170, 0x00000000);
//  printf("\n-------  AHBC_CLKEN -------\r\n");
    WRITE32(0x1f2ac008, 0x0000030f);
//  printf("\n-------  AHBC_SRST -------\r\n");
    WRITE32(0x1f2ac000, 0x000000F0);

//  printf("\n-------   REGSPEC_CFG_MEM_RAM_SHUTDOWN_ADDR -------\r\n");
    WRITE32(0x1f2ad070, 0x0);
//  printf("\n-------  REGSPEC_BLOCK_MEM_RDY_ADDR -------\r\n");
    WRITE32(0x1f2ad074, 0xFFFFFFFF);
//  printf("\n-------  cap_low_base -------\r\n");
    WRITE32(0x1f2a0024, 0xa0fc1970);
//  printf("\n-------  cap_high_base -------\r\n");
    WRITE32(0x1f2a0028, 0x0000008f);
//	printf("\n------- SDHCI_CAPABILITIES -------\r\n");
    ReadData = READ32(0x1c000040);
//	printf("\n------- sdhci_enable_card_detection -------\r\n");
	ReadData = READ32(0x1c000034);
	WRITE32(0x1c000034, 0x00FF0003);
	WRITE32(0x1c000038, 0x00FF0003);

	ipp_udelay(1000);

	retval = sdio_hw_emmc(sdio_no);

	return retval;
}


void stop_monitor_axi(void){
	unsigned int read_val;
	WRITE32(0x1f2a0000 + CFG_DIAG_START_STOP, 0);
	printf("Master clock start stop[0x%08x] : %x\n",0x1f2a0000 + CFG_DIAG_START_STOP, READ32(0x1f2a0000 + CFG_DIAG_START_STOP));
	read_val = READ32(0x1f2a0000 + CFG_DIAG_START_STOP);
}

void start_monitor_axi(void){
	WRITE32(0x1f2a0000 + CFG_DIAG_START_STOP, 0x1f);
	printf("Master clock start stop[0x%08x] : %x\n", (0x1f2a0000 + CFG_DIAG_START_STOP),READ32(0x1f2a0000 + CFG_DIAG_START_STOP));
}

void bw_masterWR_stop_count(int kbytes){
	kbytes = kbytes << 16;
	WRITE32(0x1f2a0000 + CFG_BW_MSTR_STOP_CNT, kbytes);
	printf("Master clock stop limit[0x%08x]: %x\n", (0x1f2a0000 + CFG_BW_MSTR_STOP_CNT), READ32(0x1f2a0000 + CFG_BW_MSTR_STOP_CNT));
}
void bw_masterRD_stop_count(int kbytes){
	WRITE32(0x1f2a0000 + CFG_BW_MSTR_STOP_CNT, kbytes);
	printf("Master clock stop limit[0x%08x]: %x\n",(0x1f2a0000 + CFG_BW_MSTR_STOP_CNT), READ32(0x1f2a0000 + CFG_BW_MSTR_STOP_CNT));
}

void monitor_dump(void){
	unsigned long clkWR_cnt, byteWR_cnt, clkRD_cnt, byteRD_cnt, result,mantissa;
	clkWR_cnt= 	READ32(0x1f2a0000 + STS_AXI_MWR_BW_CLK_CNT);
	byteWR_cnt= READ32(0x1f2a0000 + STS_AXI_MWR_BW_BYTE_CNT);
	clkRD_cnt= 	READ32(0x1f2a0000 + STS_AXI_MRD_BW_CLK_CNT);
	byteRD_cnt= READ32(0x1f2a0000 + STS_AXI_MRD_BW_BYTE_CNT);

	printf("Master write  clock  count[0x%08x] : %x\n",(0x1f2a0000 + STS_AXI_MWR_BW_CLK_CNT) , clkWR_cnt);
	printf("Master write  byte   count[0x%08x] : %x\n",(0x1f2a0000 + STS_AXI_MWR_BW_BYTE_CNT), byteWR_cnt);
	printf("Master read clock  count[0x%08x] : %x\n", (0x1f2a0000 + STS_AXI_MRD_BW_CLK_CNT), clkRD_cnt);
	printf("Master read byte   count[0x%08x] : %x\n", (0x1f2a0000 + STS_AXI_MRD_BW_BYTE_CNT), byteRD_cnt);
//	result = (byteWR_cnt) / (clkWR_cnt / (250*10^6));
//	printf("Actual Write Speed = %d Mbps\n", result);
//	result = (byteRD_cnt) / (clkRD_cnt / (250*10^6));
//	printf("Actual Read Speed = %d Mbps\n",  result);

	result = (byteRD_cnt*250000000)/(clkRD_cnt*1048576);
	mantissa = ((byteRD_cnt*250000000*10000)/(clkRD_cnt*1048576))%10000;
	printf("\n Performace (Read): %ld.%ld Mbyte/s\n", result, mantissa);


	result = (byteWR_cnt*250000000)/(clkWR_cnt*1048576);
	mantissa = ((byteWR_cnt*250000000*10000)/(clkWR_cnt*1048576))%10000;
	printf("\n Performace (Write): %ld.%ld Mbyte/s\n", result, mantissa);
}




u32 write_vfatdev_emmc_adma_2_multi_block_test_suspend_resume(u8 sdio_no,u32 lba,u16 blkNo)
{
	u32 cmd,rc,i,n;
	u32 istat,temp,timeout=100;
    u32 *data_for_table_adma_temp ;// = &data_for_table_adma_0[0];
    u32 *data_read_add ;//= &addr_for_data_adma_0[0];
    u32 data , data_write,datatemp = 0x5A5A5A5A ;
//    u32 ocm_mem_addr = 0x1d0c0000;
    u32 ocm_mem_addr = 0x1d0c0000;
	char c;

	data_for_table_adma_temp = 0x1d0c3000;
    data_read_add = ocm_mem_addr ; // just test for OCM mem
	for ( n =0 ; n < blkNo ; n++)
	{
		for (i=1 ; i< (128+1) ; i++)
		{
			*((volatile unsigned int *)data_read_add)= datatemp;
			data_read_add ++ ;
		}
	}

	  data_cache_flush_all();
		stop_monitor_axi();
		bw_masterWR_stop_count(blkNo);
		start_monitor_axi();
		monitor_dump();
	WRITE_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR, data_for_table_adma_temp);
	rc  = READ_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR);
	WRITE_SDIO(sdio_no,ADMA_ADDRESS_HIGH_ADDR,0x00000000);
	rc  = READ_SDIO(sdio_no,ADMA_ADDRESS_HIGH_ADDR);
	//---------------------------------------------------------------------------
	data_write = 0x27000000 + blkNo*2 ;   //512 bytes run OK
	for ( n =0 ; n < blkNo ; n++)
	{
//		data_write = 0x27000020 ;   //512 bytes run OK
		data_write = sd_bswap32(data_write) ;
		rc = sdio_out32(data_for_table_adma_temp,data_write);
		data_for_table_adma_temp ++ ;
		rc = sdio_out32(data_for_table_adma_temp,ocm_mem_addr + (n*SDIO_BLOCK_SIZE));
		data_for_table_adma_temp ++ ;
	}
//	  data_cache_flush_all();
	 //---------------------------------------------------------------------------
     data_write = 0x07000000 ;
     data_write = sd_bswap32(0x07000000) ;
     rc = sdio_out32(data_for_table_adma_temp,data_write);
	cmd =     (25 << 24)  	/* Multiple Write Command Index */
			| ( 0 << 22)   	/* Command type */
			| ( 1 << 21)    /* Data Present */
			| ( 1 << 20) 	/* Command Index check enable */
			| ( 1 << 19)	/* Command CRC check enable */
			| ( 2 << 16)	/* Response type - R1 */
			| ( 0 << 4) 	/* Write Direction */
			| ( 1 << 1)	/* Enable block count */
			| ( 1 << 0)	/* DMA Enable */
			| ( 1 << 2)	/* AUTO CMD12 Enable */
			//| ( 0 << 2)	/* AUTO CMD12 Disable */
			//| ( 2 << 2)	/* AUTO CMD23 Disable */
			| ( 0 << 5);	/* Multiple Block Select */

    temp = ((blkNo << 16) | SDIO_BLOCK_SIZE); // return Transfer complete OK !!!
	WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, temp);   /*  writing both block count(=1) and block size regs  */
    lba=0;
	WRITE_SDIO(sdio_no,ARGUMENT_ADDR, lba);

    cmd = 0x193a0027 ;
	WRITE_SDIO(sdio_no,TRANSFERMODE_COMMAND_ADDR, cmd);
//    timeout=1000;
    timeout=10000;
	while (1)
	{
		arch_timer_msdelay(1);
        istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
		if (istat) {debug_sdio("INTERRUPT_STATUS_ADDR:0x%08x rdVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);}		if ((istat & 0x00000003)) {
            if(istat & 0x00000001) {
 	            istat = istat & 0x00000001;
                WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
                istat = READ_SDIO(sdio_no,RESPONSE_0_1_ADDR);
                istat = READ_SDIO(sdio_no,RESPONSE_2_3_ADDR);
            }
            if(istat & 0x00000002) {
                istat = istat & 0x00000002;
	            WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
			    //return IPP_OK;
                break;
            }
		}

		if (istat & 0xFFFF8000) {
			printf( "Fail write Data\n");
			WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
			printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
		}

        timeout--;
        if(timeout == 0) {
        	printf("Timeout Read Data\n");
            break;
        }
	}
	monitor_dump();
	data_cache_flush_all();
	//test block
	data = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
	WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
    istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
    istat = istat & 0x00000001;
    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
    istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
    istat = istat & 0x00000002;
    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
    istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
    istat = istat & 0xFFFF8000;
    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
	return IPP_OK;
}

//==========================================================================================================
u32 read_vfatdev_emmc_adma_2_multi_block_test_suspend_resume(u8 sdio_no,u32 lba,u16 blkNo)
{
	u32 cmd,rc,i,n;
	u32 istat,temp,timeout=100;
    u32 *data_for_table_adma_temp ;
    u32 *data_read_add ;
    u32 data , data_write ;
//    u32 ocm_mem_addr =  0x1d0e1000;  //  0x02E20100;
    u32 ocm_mem_addr =  0x1d0e0000;  //  0x02E20100;

    data_for_table_adma_temp = 0x1d0e3000;

	  data_cache_flush_all();
	 WRITE_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR, data_for_table_adma_temp);
	 rc  = READ_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR);
	 WRITE_SDIO(sdio_no,ADMA_ADDRESS_HIGH_ADDR,0x00000000);
	 rc  = READ_SDIO(sdio_no,ADMA_ADDRESS_HIGH_ADDR);
 //---------------------------------------------------------------------------
	data_write = 0x27000000 + blkNo*2 ;   //512 bytes run OK
	for ( n =0 ; n < blkNo ; n++)
	{
		data_write = sd_bswap32(data_write) ;
		rc = sdio_out32(data_for_table_adma_temp,data_write);
		data_for_table_adma_temp ++ ;
		rc = sdio_out32(data_for_table_adma_temp,ocm_mem_addr + (n*SDIO_BLOCK_SIZE));
		data_for_table_adma_temp ++ ;
	}
	  data_cache_flush_all();

	 //---------------------------------------------------------------------------
     data_write = 0x07000000 ;
     data_write = sd_bswap32(data_write) ;
     rc = sdio_out32(data_for_table_adma_temp,data_write);
	cmd =     (18 << 24)  	/* Multiple Write Command Index */
			| ( 0 << 22)   	/* Command type */
			| ( 1 << 21)    /* Data Present */
			| ( 1 << 20) 	/* Command Index check enable */
			| ( 1 << 19)	/* Command CRC check enable */
			| ( 2 << 16)	/* Response type - R1 */
			| ( 0 << 4) 	/* Write Direction */
			| ( 1 << 1)	/* Enable block count */
			| ( 1 << 0)	/* DMA Enable */
			| ( 1 << 2)	/* AUTO CMD12 Enable */
			//| ( 0 << 2)	/* AUTO CMD12 Disable */
			//| ( 2 << 2)	/* AUTO CMD23 Disable */
			| ( 0 << 5);	/* Multiple Block Select */

    temp = ((blkNo << 16) | SDIO_BLOCK_SIZE|0x7000); // return Transfer complete OK !!!
	WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, temp);   /*  writing both block count(=1) and block size regs  */
    lba=0;
	WRITE_SDIO(sdio_no,ARGUMENT_ADDR, lba);
    cmd = 0x123a003b ;  //no autoCMD12 run OK
	WRITE_SDIO(sdio_no,TRANSFERMODE_COMMAND_ADDR, cmd);

	/* Wait for transfer to complete or error bit set */
    timeout=10000;
	while (1)
	{
		arch_timer_msdelay(1);
        istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
		if (istat) {;}
		if ((istat & 0x00000003)) {
            if(istat & 0x00000001) {
 	            istat = istat & 0x00000001;
                WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);

                istat = READ_SDIO(sdio_no,RESPONSE_0_1_ADDR);
                istat = READ_SDIO(sdio_no,RESPONSE_2_3_ADDR);
            }
            if(istat & 0x00000002) {
                istat = istat & 0x00000002;
	            WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
                break;
            }
		}

		if (istat & 0xFFFF8000) {
			printf( "Fail read Data\n");
			WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
			printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
		}
        timeout--;
        if(timeout == 0) {
        	printf("Timeout Read Data\n");
            break;
        }
	}
	data_cache_flush_all();
	//test block
	data = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
	WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
    data_read_add = ocm_mem_addr ; // just test for OCM mem
	for ( n =0 ; n < blkNo ; n++)
	{
	    for (i=1 ; i< (128+1) ; i++)
	    {
			data = *((volatile unsigned int *)data_read_add);
			printf("addr = 0x%08x, data = 0x%08x ",data_read_add, data);
			data_read_add ++ ;
			if ((i%4)==0) printf("\n\r");
			if (data != 0x5A5A5A5A)
				return IPP_ERR_FAIL;
		}
	}
	WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
    istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
    istat = istat & 0x00000001;
    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
    istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
    istat = istat & 0x00000002;
    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
    istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
    istat = istat & 0xFFFF8000;
    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
	return IPP_OK;
}



u32 write_vfatdev_mmc_adma_2_multi_block_test_suspend_resume(u8 sdio_no,u32 lba,u16 blkNo)
{
	u32 cmd,rc,i,n;
	u32 istat,temp,timeout=100;
    u32 *data_for_table_adma_temp ;// = &data_for_table_adma_0[0];
    u32 *data_read_add ;//= &addr_for_data_adma_0[0];
    u32 data , data_write,datatemp = 0x5a5a5a5a;
    u32 ocm_mem_addr = 0x1d0c0000; // datnguyen 0x02E20100;
	char c;
    //data_for_table_adma_temp = 0x1d0cb788;
    data_for_table_adma_temp = 0x1d0c3000;
    data_read_add = ocm_mem_addr ; // just test for OCM mem
    printf("Fill data...\n");
	for ( n =0 ; n < blkNo ; n++)
	{
		for (i=1 ; i< (128+1) ; i++)
		{
			*((volatile unsigned int *)data_read_add)= datatemp;
			data_read_add ++ ;
		}
	}

    data_read_add = ocm_mem_addr ; // just test for OCM mem
     printf("Before transfer data...\n");
    	for ( n =0 ; n < blkNo ; n++){
    	printf("\n\nBlock %d ...\n",n);
    	  for (i=1 ; i< (128+1) ; i++){
    	    data = *((volatile unsigned int *)data_read_add);
    	    //printf("addr = 0x%08x, data = 0x%08x ",data_read_add, data);
            data_read_add ++ ;
    	    //if ((i%4)==0) printf("\n\r");
    	    }
    	}
    	printf("\n\n");

    timeout=300;
	do {
	    istat = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
        timeout--;
        if(timeout == 0) {
            printf("Timeout for CMD line Free addr:0x%08x rdvl:0x%08x\n",PRESENT_STATE_ADDR,istat);
			//return IPP_ERR_FAIL;
            break;  // test 50MHz
        }
        if((istat & 0x01) == 0x00)
            break;
	} while (1);
    //printf("Done\n");

#if 1
	//if (!high_capacity[sdio_no-1]) {
	if (!high_capacity) {
		lba *= SDIO_BLOCK_SIZE;
		//printf("high_cpacity:%d lba:0x%x\n",high_capacity[sdio_no-1], lba);
    }
#endif


	 //WRITE_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR, &data_for_table_adma_0[0]);
	 WRITE_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR, data_for_table_adma_temp);
     printf("addr:0x%08x data:0x%08x\n",data_for_table_adma_temp, data_write);

	 rc  = READ_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR);
	 printf("ADMA_ADDRESS_LOW_ADDR sdio 1 addr:0x%08x rdvl:0x%08x\n",ADMA_ADDRESS_LOW_ADDR,data_for_table_adma_temp);

	 WRITE_SDIO(sdio_no,ADMA_ADDRESS_HIGH_ADDR,0x00000000);
	 rc  = READ_SDIO(sdio_no,ADMA_ADDRESS_HIGH_ADDR);
	 printf("ADMA_ADDRESS_HIGH_ADDR sdio 1 addr:0x%08x rdvl:0x%08x\n",ADMA_ADDRESS_HIGH_ADDR,rc);
	 //---------------------------------------------------------------------------
	  	for ( n =0 ; n < blkNo ; n++)
	  	{
	 	 data_write = 0x27000010 ;   //512 bytes run OK
	 	 data_write = sd_bswap32(data_write) ;
	      rc = sdio_out32(data_for_table_adma_temp,data_write);
	     // printf("addr:0x%08x data:0x%08x\n",data_for_table_adma_temp, data_write);
	      data_for_table_adma_temp ++ ;
	      rc = sdio_out32(data_for_table_adma_temp,ocm_mem_addr + (n*SDIO_BLOCK_SIZE));
	     // printf("addr:0x%08x data:0x%08x\n",data_for_table_adma_temp, ocm_mem_addr + (n*SDIO_BLOCK_SIZE));
	      data_for_table_adma_temp ++ ;
	  	}
	 //---------------------------------------------------------------------------
//
//
//	 //prepare table for ADMA
//     //data_write = 0x21000002 ;
//	 data_write = 0x27000002 ;   //512 bytes run OK
//	 //data_write = 0x23000004 ;     //1KB run OK
//	  //data_write = 0x2300002C ;     //8KB run
//	 //data_write = 0x23000020 ;
////	 data_write = 0x27000040 ;       //32 blocks
//	 //data_write = 0x23000080 ;       //64 blocks
//	 //data_write = 0x27000080 ;
//	 //data_write = 0x230000FE ;     // 127 blocks
////	 data_write = 0x270000FE ;     // 127 blocks
//	 //data_write = sd_bswap32(0x23000002) ;
//	 //data_write = ((blkNo*512)<<16)|0x0023 ;
//	 data_write = sd_bswap32(data_write) ;
//     rc = sdio_out32(data_for_table_adma_temp,data_write);
//     printf("addr:0x%08x data:0x%08x\n",data_for_table_adma_temp, data_write);
//     data_for_table_adma_temp ++ ;
//
//     //data_read_add = &addr_for_data_adma_0[0];
//     //printf("data_read_add 0x%08x ",data_read_add);
//     //data_write = sd_bswap32(data_read_add) ;
//     //data_write = data_read_add ;
//     //data_write = 0x00003000 ;
//     //data_write = 0x00000000 ;
////     data_write = sd_bswap32(0x1d0c0000) ;//0x1d0c0000; // datnguyen 0x00300000 ;
//     data_write = ocm_mem_addr ; // datnguyen 0x00300000 ;
//     rc = sdio_out32(data_for_table_adma_temp,data_write);
//     printf("addr:0x%08x data:0x%08x\n",data_for_table_adma_temp, data_write);
//     data_for_table_adma_temp ++ ;

     data_write = 0x07000000 ;

     data_write = sd_bswap32(0x07000000) ;
     rc = sdio_out32(data_for_table_adma_temp,data_write);
     printf("addr:0x%08x data:0x%08x\n",data_for_table_adma_temp, data_write);

     //test data of table
     printf("Test data of table...\n\n ");
     data_for_table_adma_temp = 0x1d0c3000; //&data_for_table_adma_0[0];

	 for (i=1 ; i<17 ; i++)
	 {
		 data = *((volatile unsigned int *)data_for_table_adma_temp);
		 //printf("add1 = 0x%08x, data = 0x%08x ",data_for_table_adma_temp, data);
		 data_for_table_adma_temp ++ ;
		 //if ((i%4)==0) printf("\n\r");
	 }
	 arch_timer_msdelay(1000);

	cmd =     (25 << 24)  	/* Multiple Write Command Index */
			| ( 0 << 22)   	/* Command type */
			| ( 1 << 21)    /* Data Present */
			| ( 1 << 20) 	/* Command Index check enable */
			| ( 1 << 19)	/* Command CRC check enable */
			| ( 2 << 16)	/* Response type - R1 */
			| ( 0 << 4) 	/* Write Direction */
			| ( 1 << 1)	/* Enable block count */
			| ( 1 << 0)	/* DMA Enable */
			| ( 1 << 2)	/* AUTO CMD12 Enable */
			//| ( 0 << 2)	/* AUTO CMD12 Disable */
			//| ( 2 << 2)	/* AUTO CMD23 Disable */
			| ( 0 << 5);	/* Multiple Block Select */

    temp = ((blkNo << 16) | SDIO_BLOCK_SIZE); // return Transfer complete OK !!!
	//temp = ((1 << 16) | SDIO_BLOCK_SIZE);
	//temp = ((16 << 16) | SDIO_BLOCK_SIZE);
	//temp = ((32 << 16) | SDIO_BLOCK_SIZE);
	//temp = ((64 << 16) | SDIO_BLOCK_SIZE);
	//  temp = (((1) << 16) | SDIO_BLOCK_SIZE)|(7<<12);
	//temp = ((64 << 16) | SDIO_BLOCK_SIZE)|(7<<12);
	//temp = ((8 << 16) | SDIO_BLOCK_SIZE)|(7<<12);
//	temp = ((2 << 16) | SDIO_BLOCK_SIZE)|(7<<12);
	//temp = ((64 << 16) | SDIO_BLOCK_SIZE);
    //temp = sd_bswap32(temp) ;
   arch_timer_msdelay(10);
	WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, temp);   /*  writing both block count(=1) and block size regs  */
    printf("Write addr:0x%08x wrVal:0x%08x\n",BLOCK_DEF_ADDR, temp);
//    arch_timer_msdelay(10);
	WRITE_SDIO(sdio_no,ARGUMENT_ADDR, lba);
    printf("Write addr:0x%08x wrVal:0x%08x\n",ARGUMENT_ADDR, lba);

//    cmd = 0x183a0007 ;
//    cmd = 0x193a00027 ;
	//cmd = 0x193a0023 ;
	//cmd = 0x193a0025 ;
    cmd = 0x193a0027 ;
	WRITE_SDIO(sdio_no,TRANSFERMODE_COMMAND_ADDR, cmd);
    printf("Write addr:0x%08x wrVal:0x%08x\n",TRANSFERMODE_COMMAND_ADDR, cmd);
	/* Wait for transfer to complete or error bit set */
    //timeout=10000000; //test for 25Mhz
    timeout=10; //test for 50Mhz
	while (1)
	{
		arch_timer_msdelay(300);
//		ipp_udelay(DELAY_1);
        istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
		if (istat) {printf("INTERRUPT_STATUS_ADDR:0x%08x rdVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);}		if ((istat & 0x00000003)) {
            if(istat & 0x00000001) {
                printf("Write ADMA 2 Multi Block Command Done\n");
 	            istat = istat & 0x00000001;
                WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
                printf("Clear INT addr:0x%08x data:0x%08x\n",INTERRUPT_STATUS_ADDR,istat);

                istat = READ_SDIO(sdio_no,RESPONSE_0_1_ADDR);
//                printf("READ RESPONSE_0_1_ADDR addr:0x%08x wrVal:0x%08x\n",RESPONSE_0_1_ADDR, istat);

                istat = READ_SDIO(sdio_no,RESPONSE_2_3_ADDR);
//                printf("READ RESPONSE_2_3_ADDR addr:0x%08x wrVal:0x%08x\n",RESPONSE_2_3_ADDR, istat);
            }
            if(istat & 0x00000002) {
                printf("Write ADMA 2 Multi Block Data Transfer Done\n");
                istat = istat & 0x00000002;
	            WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
                printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
			    //return IPP_OK;
                break;
            }
		}

		if (istat & 0xFFFF8000) {
            printf( "Fail write Data\n");
			WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
            printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
		}

        timeout--;
        if(timeout == 0) {
            printf("Timeout Read Data\n");
            break;
        }
	}

	//test block
	data = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
	printf("BLOCK_DEF_ADDR after :0x%08x wrVal:0x%08x\n",BLOCK_DEF_ADDR, data);

	WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
    printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
    istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
    istat = istat & 0x00000001;
    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);

    printf("Clear INT addr:0x%08x data:0x%08x\n",INTERRUPT_STATUS_ADDR,istat);
    istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
    istat = istat & 0x00000002;
    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
    printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);

    istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
    istat = istat & 0xFFFF8000;
    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
    printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);

    printf("\n\r write_vfatdev_sdio_block <- out\n");
	return IPP_OK;
}

//==========================================================================================================
u32 read_vfatdev_mmc_adma_2_multi_block_test_suspend_resume(u8 sdio_no,u32 lba,u16 blkNo)
{
	u32 cmd,rc,i,n;
	u32 istat,temp,timeout=100;
    u32 *data_for_table_adma_temp ;
    u32 *data_read_add ;
    u32 data , data_write ;
    u32 ocm_mem_addr =  0x1d0c1000;  // datnguyen 0x02E20100;
//    data_for_table_adma_temp = 0x1d0cb6e0;

    data_for_table_adma_temp = 0x1d0c5000;
    data_read_add = ocm_mem_addr ; // just test for OCM mem
	printf("Fill data1...\n");
	for ( n =0 ; n < blkNo ; n++)
	{
		//			data_read_add = data_read_add + 96*n ;
		for (i=1 ; i< (128+1) ; i++)
		{
			*((volatile unsigned int *)data_read_add)= 0xffffffff;
			data_read_add ++ ;
		}
	}

	data_read_add = ocm_mem_addr ; // just test for OCM mem
	printf("Before transfer data1...\n");
	for ( n =0 ; n < blkNo ; n++)
	{
		printf("\n\nBlock %d ...\n",n);
		//		data_read_add = data_read_add + 96*n ;
		for (i=1 ; i< (128+1) ; i++)
		{
			data = *((volatile unsigned int *)data_read_add);
			//printf("addr = 0x%08x, data = 0x%08x ",data_read_add, data);
			data_read_add ++ ;
			//if ((i%4)==0) printf("\n\r");
		}
	}
	printf("\n\n");
	timeout=100;
	do {
	    istat = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
        timeout--;
        if(timeout == 0) {
            printf("Timeout for CMD line Free addr:0x%08x rdvl:0x%08x\n",PRESENT_STATE_ADDR,istat);
			//return IPP_ERR_FAIL;
            break;  // test 50MHz
        }
        if((istat & 0x01) == 0x00)
            break;
	} while (1);
    printf("Done\n");

#if 1
	//if (!high_capacity[sdio_no-1]) {
	if (!high_capacity) {
		lba *= SDIO_BLOCK_SIZE;
		//printf("high_cpacity:%d lba:0x%x\n",high_capacity[sdio_no-1], lba);
    }
#endif
	WRITE_SDIO(sdio_no,SDMA_SYSTEM_ADDRESS_ADDR, 8);
//	 WRITE_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR, &data_for_table_adma_0[0]);
	 WRITE_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR, data_for_table_adma_temp);
//	 WRITE_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR, ocm_mem_addr);
	 rc  = READ_SDIO(sdio_no,ADMA_ADDRESS_LOW_ADDR);
	 printf("ADMA_ADDRESS_LOW_ADDR  addr:0x%08x rdvl:0x%08x\n",ADMA_ADDRESS_LOW_ADDR,data_for_table_adma_temp);

	 WRITE_SDIO(sdio_no,ADMA_ADDRESS_HIGH_ADDR,0x00000000);
	 rc  = READ_SDIO(sdio_no,ADMA_ADDRESS_HIGH_ADDR);
	 printf("ADMA_ADDRESS_HIGH_ADDR sdio 1 addr:0x%08x rdvl:0x%08x\n",ADMA_ADDRESS_HIGH_ADDR,rc);
	 //---------------------------------------------------------------------------
	  	for ( n =0 ; n < blkNo ; n++)
	  	{
	 	 data_write = 0x27000010 ;   //512 bytes run OK
	 	 data_write = sd_bswap32(data_write) ;
	      rc = sdio_out32(data_for_table_adma_temp,data_write);
	      printf("addr:0x%08x data:0x%08x\n",data_for_table_adma_temp, data_write);
	      data_for_table_adma_temp ++ ;
	      rc = sdio_out32(data_for_table_adma_temp,ocm_mem_addr + (n*SDIO_BLOCK_SIZE));
	      printf("addr:0x%08x data:0x%08x\n",data_for_table_adma_temp, ocm_mem_addr + (n*SDIO_BLOCK_SIZE));
	      data_for_table_adma_temp ++ ;
	  	}
	 //---------------------------------------------------------------------------


//	 //prepare table for ADMA
//     //data_write = 0x21000002 ;
//	 data_write = 0x27000002 ;   //512 bytes run OK
//	 //data_write = 0x23000004 ;     //1KB run OK
//	  //data_write = 0x2300002C ;     //8KB run
//	 //data_write = 0x23000020 ;
//	 //data_write = 0x23000040 ;
//	 //data_write = 0x21000040 ;
//	 //  data_write = 0x27000040 ;
//	 //data_write = 0x27000080 ;     //64 block (*512)
////	 data_write = 0x270000FE ;       // 127 blocks
//
//	 //data_write = sd_bswap32(0x23000002) ;
//	 //data_write = ((blkNo*512)<<16)|0x0023 ;
//	 //data_write = ((16*32*512)<<16)|0x0027 ;
//	 data_write = sd_bswap32(data_write) ;
//     rc = sdio_out32(data_for_table_adma_temp,data_write);
//     printf("addr:0x%08x data:0x%08x\n",data_for_table_adma_temp, data_write);
//
//     data_for_table_adma_temp ++ ;
//
//     //data_read_add = &addr_for_data_adma_0[0];
//     //printf("data_read_add 0x%08x ",data_read_add);
//     //data_write = sd_bswap32(data_read_add) ;
//     //data_write = data_read_add ;
//     //data_write = 0x00003000 ;
//     //data_write = 0x00000000 ;
////     data_write = sd_bswap32(0x1d0c1000) ;//0x1d0c0000; // datnguyen 0x00300000 ;
//     data_write = ocm_mem_addr ;//0x1d0c0000; // datnguyen 0x00300000 ;
//     rc = sdio_out32(data_for_table_adma_temp,data_write);
//     printf("addr:0x%08x data:0x%08x\n",data_for_table_adma_temp, data_write);
//     data_for_table_adma_temp ++ ;

     data_write = 0x07000000 ;
     data_write = sd_bswap32(data_write) ;
     rc = sdio_out32(data_for_table_adma_temp,data_write);
     printf("addr:0x%08x data:0x%08x\n",data_for_table_adma_temp, data_write);

     //test data of table
     printf("Test data of table...\n\n");
     data_for_table_adma_temp = 0x1d0c5000;
 	 for (i=1 ; i<17 ; i++)
	 {
		data = *((volatile unsigned int *)data_for_table_adma_temp);
		//printf("addr1 = 0x%08x, data = 0x%08x ",data_for_table_adma_temp, data);
		data_for_table_adma_temp ++ ;
		//if ((i%4)==0) printf("\n\r");
	 }
 	 // delay 1 seconds
 	 ipp_udelay(1000000);
 	 //mdelay(1000);

	cmd =     (18 << 24)  	/* Multiple Write Command Index */
			| ( 0 << 22)   	/* Command type */
			| ( 1 << 21)    /* Data Present */
			| ( 1 << 20) 	/* Command Index check enable */
			| ( 1 << 19)	/* Command CRC check enable */
			| ( 2 << 16)	/* Response type - R1 */
			| ( 0 << 4) 	/* Write Direction */
			| ( 1 << 1)	/* Enable block count */
			| ( 1 << 0)	/* DMA Enable */
			| ( 1 << 2)	/* AUTO CMD12 Enable */
			//| ( 0 << 2)	/* AUTO CMD12 Disable */
			//| ( 2 << 2)	/* AUTO CMD23 Disable */
			| ( 0 << 5);	/* Multiple Block Select */

    temp = ((blkNo << 16) | SDIO_BLOCK_SIZE|0x7000); // return Transfer complete OK !!!
	//temp = ((1 << 16) | SDIO_BLOCK_SIZE); // test ok
	//temp = ((16 << 16) | SDIO_BLOCK_SIZE);
	//temp = ((32 << 16) | SDIO_BLOCK_SIZE);
	//temp = ((32 << 16) | SDIO_BLOCK_SIZE)|(7<<12);
//datnguyen	temp = ((127 << 16) | SDIO_BLOCK_SIZE)|(7<<12);
//	temp = ((2 << 16) | SDIO_BLOCK_SIZE)|(7<<12);
	WRITE_SDIO(sdio_no,BLOCK_DEF_ADDR, temp);   /*  writing both block count(=1) and block size regs  */
    printf("BLOCK_DEF_ADDR:0x%08x wrVal:0x%08x\n",BLOCK_DEF_ADDR, temp);
    lba=0;
	WRITE_SDIO(sdio_no,ARGUMENT_ADDR, lba);
    printf("ARGUMENT_ADDR:0x%08x wrVal:0x%08x\n",ARGUMENT_ADDR, lba);

    //cmd = 0x193a0027 ;
//    cmd = 0x123a0037 ;
//    cmd = 0x123a0033 ;  //no autoCMD12 run OK
    cmd = 0x123a003b ;  //no autoCMD12 run OK
	WRITE_SDIO(sdio_no,TRANSFERMODE_COMMAND_ADDR, cmd);
    ipp_udelay(DELAY_1);
    printf("Write addr:0x%08x wrVal:0x%08x\n",TRANSFERMODE_COMMAND_ADDR, cmd);
    ipp_udelay(DELAY_1);
    ipp_udelay(DELAY_1);

	/* Wait for transfer to complete or error bit set */
    timeout=10; //test for 50Mhz
	while (1)
	{
		arch_timer_msdelay(300);
		//ipp_udelay(DELAY_1);
        istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
		if (istat) {printf("INTERRUPT_STATUS_ADDR:0x%08x rdVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);}
		if ((istat & 0x00000003)) {
            if(istat & 0x00000001) {
                printf("Read ADMA 2 Multi Block Command Done\n");
 	            istat = istat & 0x00000001;
                WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
                printf("Clear INT addr:0x%08x data:0x%08x\n",INTERRUPT_STATUS_ADDR,istat);

                istat = READ_SDIO(sdio_no,RESPONSE_0_1_ADDR);
//                printf("READ RESPONSE_0_1_ADDR addr:0x%08x wrVal:0x%08x\n",RESPONSE_0_1_ADDR, istat);
//
                istat = READ_SDIO(sdio_no,RESPONSE_2_3_ADDR);
//                printf("READ RESPONSE_2_3_ADDR addr:0x%08x wrVal:0x%08x\n",RESPONSE_2_3_ADDR, istat);

				//break; //for test suspend/resume
            }
            if(istat & 0x00000002) {
                printf("Read ADMA 2 Multi Block Data Transfer Done\n");
                istat = istat & 0x00000002;
	            WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
                printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
			    //return IPP_OK;
                break;
            }
		}

		if (istat & 0xFFFF8000) {
            printf( "Fail read Data\n");
			WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
            printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
		}
		arch_timer_msdelay(1);
        timeout--;
        if(timeout == 0) {
            printf("Timeout Read Data\n");
            break;
        }
	}
	//test block
	data = READ_SDIO(sdio_no,BLOCK_DEF_ADDR);
	printf("BLOCK_DEF_ADDR after :0x%08x wrVal:0x%08x\n",BLOCK_DEF_ADDR, data);

	WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
    printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
    printf("After...\n");
    data_read_add = ocm_mem_addr ; // just test for OCM mem
	for ( n =0 ; n < blkNo ; n++)
	{
		//data_read_add = data_read_add + 96*n ;
	    for (i=1 ; i< (128+1) ; i++)
	    {
			data = *((volatile unsigned int *)data_read_add);
			printf("addr = 0x%08x, data = 0x%08x ",data_read_add, data);
			data_read_add ++ ;
			if ((i%4)==0) printf("\n\r");
			if (data != 0x5A5A5A5A)
				return IPP_ERR_FAIL;
		}
	}
    printf("\n\n");
	WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
    printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
    istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
    istat = istat & 0x00000001;
    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);

    printf("Clear INT addr:0x%08x data:0x%08x\n",INTERRUPT_STATUS_ADDR,istat);
    istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
    istat = istat & 0x00000002;
    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
    printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);

    istat = READ_SDIO(sdio_no,INTERRUPT_STATUS_ADDR);
    istat = istat & 0xFFFF8000;
    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ADDR, istat);
    printf("Clear INT addr:0x%08x wrVal:0x%08x\n",INTERRUPT_STATUS_ADDR, istat);
    printf("\n\r read_vfatdev_sdio_block <- out\n");
	return IPP_OK;
}

u32 sdio_hw_mmc(u8 sdio_no)
{
	u32 cap;
	u32 card_id,temp1,temp2;
	u32 istat;
	u32 rc=0;
	u8  bw_4bits , clock_select=3;
	u8 *buf = (u8*)SDIO_OCM_PHYS_ADDR_RD;
    u32 timeout=0;
    int retval=0;
    u32 res,i ;
	char c;

	high_capacity = 0;
    rc = READ_SDIO(sdio_no,SLOT_INTR_STATUS_HOST_CONTROLLER_VERSION_ADDR);

    rc = READ_SDIO(sdio_no,PRESENT_STATE_ADDR);
    if (!(rc & 0x00010000)) {
            retval=2;
        	printf("\n;=;=;=;=;=;=;=;=;=;=;=;= Card is not DETECTED ;=;=;=;=;=;=;=;=;=;=;=;= \r\n");
			return IPP_ERR_FAIL;
        }
    else
    	printf("\n;=;=;=;=;=;=;=;=;=;=;=;= Card is DETECTED ;=;=;=;=;=;=;=;=;=;=;=;= \r\n");

	rc = 0x02ff00cb; // following linux driver 09-01-2012
    WRITE_SDIO(sdio_no,INTERRUPT_STATUS_ENABLE_ADDR, rc);
	arch_timer_usdelay(1);

	rc = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);
    rc = rc & 0xF0FFFFFF;
	rc = rc | 0x0E003007;
    WRITE_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR, rc);
	arch_timer_usdelay(1);
	rc = READ_SDIO(sdio_no,SRESET_CLOCK_CONTROL_ADDR);

	printf("\n======================== CMD 0 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x00000 ,0x000000);
	printf("\n======================== CMD 0 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x00000 ,0x000000);

	printf("\n======================== CMD 1 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x000 ,0x01020000);
	printf("\n======================== CMD 0 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x00000 ,0x000000);

	printf("\n======================== CMD 1 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x40300000 ,0x01020000);
	printf("\n======================== CMD 1 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x40300000 ,0x01020000);

	printf("\n======================== CMD2 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x0 ,0x02090000);
	printf("\n======================== CMD 3 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x10000 ,0x031a0000);

	printf("\n======================== CMD 9 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x10000 ,0x09090000);

	printf("\n======================== CMD 7 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x10000 ,0x071a0000);

	printf("\n======================== CMD 6 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x3b90101 ,0x061b0000);
	printf("\n======================== CMD 13 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x10000 ,0x0d1a0000);
	printf("\n======================== CMD 6 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x3b70101 ,0x061b0000);
	printf("\n======================== CMD 13 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x10000 ,0x0d1a0000);

	rc = READ_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR);
	rc=rc&0xffffff00;
    rc = rc | 0x13 ;          // 4-bit ; Nor-Speed; ADMA1 32 ;
    WRITE_SDIO(sdio_no,GAP_WAKEUP_POWER_HOST_CONTROL_ADDR, rc);
	arch_timer_msdelay(1);

	printf("\n--------------------------- INIT COMPLETE----------------------- ... !!!\n");
	rc = write_vfatdev_mmc_adma_2_multi_block_test_suspend_resume(sdio_no,0x00000000,8);
	printf("\n------------- write_vfatdev_sdio_adma_2, rc = 00x%08x ----------------------- \n", rc);
	rc = read_vfatdev_mmc_adma_2_multi_block_test_suspend_resume(sdio_no,0x00000000,8);
	printf("\n------------- read_vfatdev_sdio_adma_2, rc = 00x%08x ----------------------- \n", rc);

	// Reset MMC card
	printf("\n======================== CMD 0 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x00000 ,0x000000);
	printf("\n======================== CMD 0 ======================== \r\n");
	res = send_command_to_card(sdio_no ,0x00000 ,0x000000);

	return rc;
}

int sdio_mmc(u8 sdio_no) {

    int retval=0;
	u32 rc,reg;
    struct am862xx_reset_ctrl reset_ctrl;
    u32 *block_size;

    u32 sdu_shutdown, block_mem_rdy;
    u32 ReadData,i;
    sdu_shutdown = 0;
    block_mem_rdy = 0;

//  printf("\n------- CFG_PIN_MUX_SEL_1, CFG_PIN_MUX_SEL_2 -------\r\n");
    WRITE32(AHBC_TOP_REG_BASE_ADDR + CFG_PIN_MUX_SEL_1, 0x00000000);
    WRITE32(AHBC_TOP_REG_BASE_ADDR + CFG_PIN_MUX_SEL_2, 0x00000000);
//  printf("\n-------  AHBC_CLKEN -------\r\n");
    WRITE32(AHBC_TOP_REG_BASE_ADDR + AHBC_CLKEN, 0x0000030f);
//  printf("\n-------  AHBC_SRST -------\r\n");
    WRITE32(AHBC_TOP_REG_BASE_ADDR + AHBC_SRST, 0x000000F0);

//  printf("\n-------   REGSPEC_CFG_MEM_RAM_SHUTDOWN_ADDR -------\r\n");
    WRITE32(AHBC_TOP_REG_BASE_ADDR + AHBC_CFG_MEM_RAM_SHUTDOWN, 0x0);
//  printf("\n-------  REGSPEC_BLOCK_MEM_RDY_ADDR -------\r\n");
    WRITE32(AHBC_TOP_REG_BASE_ADDR + AHBC_BLOCK_MEM_RDY, 0xFFFFFFFF);

//  printf("\n-------  cap_low_base -------\r\n");
    WRITE32(AHBC_TOP_REG_BASE_ADDR + SDHC_CAP_REG_LOW_S1_ADDR, 0xa0fc1970); // config clock time out
//  printf("\n-------  cap_high_base -------\r\n");
    WRITE32(AHBC_TOP_REG_BASE_ADDR + SDHC_CAP_REG_HIGH_S1_ADDR, 0x0000008f);



//	printf("\n------- SDHCI_CAPABILITIES -------\r\n");
    ReadData = READ32(SDHC_REG_BASE_ADDR +  CAPABILITIES_0_ADDR );
//	printf("\n------- SDHCI_CAPABILITIES = 0x1c000040, ReadData = 0x%08x -------\r\n", ReadData);

//	printf("\n------- sdhci_enable_card_detection -------\r\n");
	ReadData = READ32(SDHC_REG_BASE_ADDR + INTERRUPT_STATUS_ENABLE_ADDR);
	WRITE32(SDHC_REG_BASE_ADDR + INTERRUPT_STATUS_ENABLE_ADDR, 0x00FF0003);
	WRITE32(SDHC_REG_BASE_ADDR + INTERRUPT_SIGNAL_ENABLE_ADDR, 0x00FF0003);

	retval = sdio_hw_mmc(sdio_no);

	return retval;
}
