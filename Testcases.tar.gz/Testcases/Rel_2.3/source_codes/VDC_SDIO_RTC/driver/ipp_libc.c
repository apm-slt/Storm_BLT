/*=============================================================================
**
** Copyright (C) 2009 AppliedMicro Confidential Information
**
** All Rights Reserved.
**
** THIS WORK CONTAINS PROPRIETARY INFORMATION WHICH IS THE PROPERTY OF
** AppliedMicro AND IS SUBJECT TO THE TERMS OF NON-DISCLOSURE AGREEMENT
** BETWEEN AppliedMicro AND THE COMPANY USING THIS FILE.
**
** File: ipp_libc.c
** Version: 1.0
** Authors: Anup Patel (apatel@amcc.com)
** Description: C library source file
*/

#include "../include/ipp_libc.h"

u16 sd_bswap16(u16 h) {
	return ((h & 0xff00) >> 8) | ((h & 0x00ff) << 8); 
}

u32 sd_bswap32(u32 h) {
	return ((h >> 24) | ((h & 0x00ff0000) >> 8) | ((h & 0x0000ff00) << 8) | (h << 24));
}

void *ipp_memcpy(void *dest, void *src, size_t count)
{
	u8 *dst8 = (u8 *)dest;
	u8 *src8 = (u8 *)src;

	if (count & 1) {
		dst8[0] = src8[0];
		dst8 += 1;
		src8 += 1;
	}

	count /= 2;
	while (count>0) {
		dst8[0] = src8[0];
		dst8[1] = src8[1];

		dst8 += 2;
		src8 += 2;

		count--;
	}

	return dest;
}

void *ipp_memset(void *dest, int c, size_t count) {
	u8 *dst8 = (u8 *)dest;
	u8 ch = (u8)c;

	if (count & 1) {
		dst8[0] = ch;
		dst8 += 1;
	}

	count /= 2;
	while (count>0) {
		dst8[0] = ch;
		dst8[1] = ch;

		dst8 += 2;

		count--;
	}

	return dest;
}

int ipp_memcmp(const void * s1, const void *s2, size_t count)
{
	u8 *p1 = (u8 *)s1;
	u8 *p2 = (u8 *)s2;
	if (count > 0) {
		do {
			if (*p1++ != *p2++)
				return (*--p1 - *--p2);

			count--;
		} while (count > 0);
	}
	return (0);
}

/* Delay in ns */
void ipp_udelay(int usecs)
{
	int delay = usecs*250;

	while (delay-- > 0);
}
