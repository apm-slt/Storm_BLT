
#include "../include/ipp_libc.h"
#include "../include/ipp_vfatdev_sdio.h"
#include "../include/ipp_vfatdev.h"
#include "../include/ipp_bootdev.h"
#include "../include/ipp_hardware.h"
#if 0
#include "../driver/ipp_libc.c"
#include "../driver/ipp_vfatdev.c"
#include "../driver/ipp_vfatdev_sdio.c"
#include "../driver/ipp_vfatdev_usb.c"
#endif 


//#define READ_BUFFER_SIZE	512*20
//#define READ_BUFFER_SIZE	512*24
#define READ_BUFFER_SIZE	512*1


int sdio_enum_test(void)
{
	u32 i,addr,readsz,writesz,lba;
	u8 readbuf[READ_BUFFER_SIZE],*readptr,pattern;
	u8 writebuf[READ_BUFFER_SIZE],*writeptr;
	ipp_bootdev_t vfat_dev;
    u32 *ptr1, *ptr2, pattern1;

	printf("\nInitoialize SDHC and detect SD Card\n");
	IPP_BOOTDEV_VFAT(&vfat_dev);
	vfat_dev.device_id = IPP_PPCBOOTDEV_SDIO;
	if (vfat_dev.init_device(&vfat_dev) != IPP_OK) {
		printf ("SDIO: Error during initialisation\n");
		return 0;
	}
#if 1    
    printf("\n---------- SDIO Read in SDMA Mode ----------\n");
	printf("Read Bytes:");
	addr=0;
	readsz = vfat_dev.read_device(&vfat_dev,readbuf, addr, READ_BUFFER_SIZE);
	printf("0x%x\n",readsz);
	readptr = readbuf;
	for (i = 0; i < readsz; i+= 4) {
		if ((i%32) == 0)
			printf("\n0x%08X: 0x", addr);		
		printf("%02X%02X%02X%02X ",readptr[i], readptr[i+1], readptr[i+2], readptr[i+3]);
		addr += 4;
	}
	printf("\n");
#endif

#if 1	
    readbuf[READ_BUFFER_SIZE-1]='\0';
    printf ("\nSDIO Test: File PPCIMG contents: \n");
	for (i=0;i<READ_BUFFER_SIZE;i++)
		printf ("%c",readbuf[i]);
	printf("\n");
#endif
        
#if 0
    lba = 0xccb;
    printf("\n---------- SDIO Write in SDMA Mode ----------\n");
	printf("Write 0x%x bytes at 0x%x block\n\n",READ_BUFFER_SIZE, lba);

#if 0 
    printf("Read before Write\n");
    read_vfatdev_sdio_block(lba);
    readptr = (u8*)SDIO_OCM_VIRT_ADDR;
    printf("readptr:0x%08x\n",readptr);
    for(i=0; i<SDIO_BLOCK_SIZE; i++) { 
        printf("%x ", *readptr++);
    }
    printf("\n");
#endif

    pattern = 0xa5;
    writeptr = (u8*)SDIO_OCM_VIRT_ADDR_WR;
    printf("\nWrite 0x%x Pattern at addr writeptr:0x%08x\n",pattern,writeptr);
    for(i=0; i<SDIO_BLOCK_SIZE; i++) { 
        *writeptr++ = pattern;
    }    
    write_vfatdev_sdio_block(lba);
    printf("Write Done\n");

    printf("\nRead After Write\n");
    read_vfatdev_sdio_block(lba);
    readptr = (u8*)SDIO_OCM_VIRT_ADDR;
	printf("readsz:0x%x readAddr:0x%08x\n",SDIO_BLOCK_SIZE,readptr);
    addr=0;
	for (i = 0; i <SDIO_BLOCK_SIZE; i+= 4) {
		if ((i%32) == 0)
			printf("\n0x%08X: 0x", addr);		
		printf("%02X%02X%02X%02X ",readptr[i], readptr[i+1], readptr[i+2], readptr[i+3]);
		addr += 4;
	}
    printf("\n");
#endif
#if 0
    printf("\n---------- SDIO Write in NON DMA Mode ----------\n");
    pattern1 = 0x12345600;
    ptr1 = ptr2 = (u32*)SDIO_OCM_VIRT_ADDR_WR;    
	printf("Write 0x%08x pattern 0x%x block 0x%x bytes\n\n",pattern1, lba, READ_BUFFER_SIZE);
    for(i=0; i<SDIO_BLOCK_SIZE; i+=4) { 
        *ptr1++ = pattern1 + i;
    }
    write_vfatdev_sdio_block_pio(lba,ptr2);

    printf("\n---------- SDIO Read in NON DMA Mode ----------\n");
    lba = 0xccb;
    read_vfatdev_sdio_block_pio(lba);    
#endif    

	printf("\nSDIO Test: Finish\n\n");

	return 0;
}








