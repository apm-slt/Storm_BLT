/* Author: your_name@apm.com 
*  Company: Applied Micro Cierroruits Corporation (AMCC)
* 
* Describe the purpose of your Test here
*
*/
#include "L0_I2C_0_STANDARD_SPEED.h"


int i2c_0_ss (void) {
	int error = 0;
//----- Put your code here -------
	u32_s i2c_test_data_tx[I2C_NO_BYTES_RW_TEST];
	u32_s i2c_test_data_rx[I2C_NO_BYTES_RW_TEST];
	u8 data_modifier,i;
	int fs_scl_hcnt,fs_scl_lcnt;
	data_modifier = 1;
	printf("I2C0\n");

	for(i=0;i<I2C_NO_BYTES_RW_TEST;i++){
		i2c_test_data_tx[i]=i+data_modifier;
	}
	error = config_i2c_i2c0(MAMBA_I2C0, I2C_STANDARD_SPEED, I2C0_EEPROM_ADDR, ADDRESSING_7BIT);
	if (error !=0)
		return error;

	error = i2c_rw_test_i2c0(MAMBA_I2C0,I2C_ADDR_RW_TEST2, I2C_NO_BYTES_RW_TEST, i2c_test_data_tx, i2c_test_data_rx) ;
	if (error !=0)
		return error;

	printf("Compare TX_DATA and RX_DATA :\n");
	for(i = 0; i<I2C_NO_BYTES_RW_TEST; i++){
		printf( "%d: TX DATA: 0x%x RX DATA: 0x%x\n", i, i2c_test_data_tx[i], i2c_test_data_rx[i]);
		if (i2c_test_data_tx[i] != i2c_test_data_rx[i]){
			error++;
		}
	}
/*

	printf("Communicate with Aarvark Slave mode address 10 Bits ....\n");
	error = config_i2c_i2c0(MAMBA_I2C0, I2C_FAST_SPEED, 0x300, ADDRESSING_7BIT);
	if (error !=0)
		return error;
	error = i2c_write_to_aardvark(MAMBA_I2C0);
*/


//--------------------------------

	if (error == 0) 
		printPASS_i2c0();
	else
		printFAIL_i2c0();

	return 0;
}
