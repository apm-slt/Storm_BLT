/* Author: your_name@apm.com 
*  Company: Applied Micro Circuits Corporation (AMCC)
* 
* Describe the purpose of your Test here
*
*/
#include "L0_I2C_1_STANDARD_SPEED.h"


int i2c_1_ss (void) {
	int error = 0;
//----- Put your code here -------
	u32_s i2c_test_data_tx[I2C_NO_BYTES_RW_TEST];
	u32_s i2c_test_data_rx[I2C_NO_BYTES_RW_TEST];
	u8 data_modifier,i;
	data_modifier = 1;
	for(i=0;i<I2C_NO_BYTES_RW_TEST;i++){
		i2c_test_data_tx[i]=i+data_modifier;
	}
	enable_i2c1_i2c1();
	error = config_i2c_i2c1(MAMBA_I2C1, I2C_FAST_SPEED, I2C1_EEPROM_ADDR, ADDRESSING_7BIT);
	if (error !=0)
		return error;

	error = i2c_rw_test_i2c1(MAMBA_I2C1,I2C_ADDR_RW_TEST2, I2C_NO_BYTES_RW_TEST, i2c_test_data_tx, i2c_test_data_rx) ;
	if (error !=0)
		return error;

	printf("Compare TX_DATA and RX_DATA :\n");
	for(i = 0; i<I2C_NO_BYTES_RW_TEST; i++){
		printf( "%d: TX DATA: 0x%x RX DATA: 0x%x\n", i, i2c_test_data_tx[i], i2c_test_data_rx[i]);
		if (i2c_test_data_tx[i] != i2c_test_data_rx[i]){
			error++;
		}
	}
//--------------------------------

	if (error == 0) 
		printPASS_i2c1();
	else
		printFAIL_i2c1();

	return 0;
}
