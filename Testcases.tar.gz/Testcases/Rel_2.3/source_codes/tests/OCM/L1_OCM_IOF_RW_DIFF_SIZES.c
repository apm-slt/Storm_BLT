/* Author: your_name@apm.com 
*  Company: Applied Micro Circuits Corporation (AMCC)
* 
* Describe the purpose of your Test here
*
*/
//Tinh-SLT: change the path to include right header files
#include "L1_OCM_IOF_RW_DIFF_SIZES.h"
#include "../../OCM/include/global.h"
#define printPASS printPASS_ocm
#define printFAIL printFAIL_ocm


//Tinh-SLT: change function name to ocm_rw_diff_sizes
int ocm_rw_diff_sizes (void) {
	int error = 0;
	
//----- Put your code here -------

printf("Start IOF read write different size test\n");
ocm_init();

/*For testing AXI burst size*/
char data8;
u16 data16;
u32 data32;
u64 data64;
WRITE8(0x1d000000,0xCA);
data8=READ8(0x1d000000);
printf("data8 =0x%x\n",data8);

WRITE8(0x1d000001,0xFE);
data8=READ8(0x1d000001);
printf("data8 =0x%x\n",data8);


WRITE16(0x1d000000,0xCAFE);
data16=READ16(0x1d000000);
printf("data16 =0x%x\n",data16);

WRITE16(0x1d000002,0xCAFE);
data16=READ16(0x1d000002);
printf("data16 =0x%x\n",data16);


WRITE32(0x1d000000,0xCAFECAFE);
data32=READ32(0x1d000000);
printf("data32 =0x%x\n",data32);

WRITE32(0x1d000004,0xCAFECAFE);
data32=READ32(0x1d000004);
printf("data32 =0x%x\n",data32);

WRITE64(0x1d000008,0xCAFECAFECAFECAFE);
data64= READ64(0x1d000000);
printf("data64 = 0x%x\n",data64);

//--------------------------------

	if (error == 0) 
		printPASS();
	else
		printFAIL();

	return 0;
}
