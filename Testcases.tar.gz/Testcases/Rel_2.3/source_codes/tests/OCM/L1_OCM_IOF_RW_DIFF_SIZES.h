/* Author: your_name@apm.com 
*  Company: Applied Micro Circuits Corporation (AMCC)
* 
* Describe the purpose of your Test here
*/




//#include <config.h>
#include <common.h>
//#include <command.h>
#include <stdio.h>
#include <string.h>

//Tinh-SLT: change path to include right header files
#include "../../OCM/include/common.h"
#include "../../OCM/include/vOCM_regs.h"
#include "../../OCM/include/vOCM_defines.h"
#include "../../OCM/include/vOCM_macros.h"
#include "../../OCM/include/sm_addr_map.h"
