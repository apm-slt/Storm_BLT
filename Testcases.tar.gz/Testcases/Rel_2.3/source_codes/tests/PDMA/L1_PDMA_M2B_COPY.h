/* Author: your_name@apm.com 
*  Company: Applied Micro Circuits Corporation (AMCC)
* 
* Describe the purpose of your Test here
*/
//#include <stdio.h>
//#include <string.h>
//#include <common.h>
//#include <config.h>
//#include "../include/common.h"
//#include <../include/PDMA/vPDMA_regs.h>
//#include <../include/PDMA/vPDMA_defines.h>
//#include <../include/PDMA/vPDMA_macros.h>


#include <types.h>
//#include <config.h>
//#include <common.h>
//#include <command.h>
#include <stdio.h>
#include <string.h>

//#include "../include/common.h"
//#include "../include/vPDMA_regs.h"
//#include "../include/vPDMA_defines.h"
//#include "../include/vPDMA_macros.h"

//#include "../include/sm_qm_csr.h"
//#include "../include/msg_format.h"
//#include "../include/sm_common_reg_offset.h"

//#include "../include/pdma_lib.h"
//#include "../include/pdma_crc_lib.h"
//#include "../include/pdma_check.h"

//Tinh-SLT: give full path to include header files
#include "../../PDMA/include/common.h"
#include "../../PDMA/include/vPDMA_regs.h"
#include "../../PDMA/include/vPDMA_defines.h"
#include "../../PDMA/include/vPDMA_macros.h"
#include "../../PDMA/include/sm_qm_csr.h"
#include "../../PDMA/include/msg_format.h"
#include "../../PDMA/include/sm_common_reg_offset.h"
#include "../../PDMA/include/pdma_lib.h"
#include "../../PDMA/include/pdma_crc_lib.h"
#include "../../PDMA/include/pdma_check.h"
//End of Tinh-SLT



int L1_PDMA_M2B_COPY (void);

