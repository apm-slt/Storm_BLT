/* Author: your_name@apm.com 
*  Company: Applied Micro Circuits Corporation (AMCC)
* 
* Describe the purpose of your Test here
*
*/
#include "L1_PDMA_M2B_COPY.h"
//Tinh-SLT:
#define printPASS printPASS_pdma_copy
#define printFAIL printFAIL_pdma_copy
//End of Tinh-SLT


int M2B_COPY_DDR_DDR (void) {
	int error = 0;
	
//----- Put your code here -------
	dma_work_msg_32b_t work_msg;
	dma_cmplt_msg_32b_t cmplt_msg;
	dma_params_t dma_params;
	int status = 0;

	printf("\n############################################################\n");
	printf("## Start    %-40s %8s",__FUNCTION__,"##\n");
	printf("############################################################\n");

	init_dma_platform();

	_init_dma();

	setup_qm_dma();

	unsigned int j;
	/*Reset all field to Zero
	* It's important to do this for DDR test
	* */

	for(j=0;j<8;j++){
		work_msg.data[j]=0x0;
		cmplt_msg.data[j]=0x0;
	}
	/*Reset all endqueue/dequeue*/
	dma_init_enq_deq_ptr();

	dma_setup_FP(FPQID4, 1);  //qid and num_of_pointers max can be 24 only

	dma_setup_msg_32b (FPQID0, WQID0, FPQPBID0, 16*1024, 0, 0, 1, &work_msg);

	dma_set_copy_bufdest_msg_32b(&work_msg);

	dma_init_data( &work_msg);

	dma_dump_work_msg_32b( &work_msg);

	dma_enqueue_msg_32b(WQID4,&work_msg);

	poll_dma_queues(WQID0,&cmplt_msg);

	dma_dump_cmplt_msg_32b(&cmplt_msg);

	dma_get_params_from_32b(&work_msg,&dma_params);

	dma_get_params_from_cmplt_32b(&cmplt_msg,&dma_params);


	status = dma_check_gather_scatter(dma_params);

	dma_check_status(status);

	error = status;

//--------------------------------

	if (error == 0) 
		printPASS();
	else
		printFAIL();

	return error;
}


int M2B_COPY_OCM_DDR (void) {
	int error = 0;

//----- Put your code here -------
	dma_work_msg_32b_t work_msg;
	dma_cmplt_msg_32b_t cmplt_msg;
	dma_params_t dma_params;
	int status = 0;

	printf("\n############################################################\n");
	printf("## Start    %-40s %8s",__FUNCTION__,"##\n");
	printf("############################################################\n");

	init_dma_platform();

	_init_dma();

	setup_qm_dma();

	unsigned int j;
	/*Reset all field to Zero
	* It's important to do this for DDR test
	* */

	for(j=0;j<8;j++){
		work_msg.data[j]=0x0;
		cmplt_msg.data[j]=0x0;
	}
	/*Reset all endqueue/dequeue*/
	dma_init_enq_deq_ptr();

	dma_setup_FP(FPQID4, 1);  //qid and num_of_pointers max can be 24 only

	dma_setup_msg_32b_ocm(FPQID0, WQID0, FPQPBID0, 16*1024, 0, 0, 1, &work_msg);

	dma_set_copy_bufdest_msg_32b(&work_msg);

	dma_init_data( &work_msg);

	dma_dump_work_msg_32b( &work_msg);

	dma_enqueue_msg_32b(WQID4,&work_msg);

	poll_dma_queues(WQID0,&cmplt_msg);

	dma_dump_cmplt_msg_32b(&cmplt_msg);

	dma_get_params_from_32b(&work_msg,&dma_params);

	dma_get_params_from_cmplt_32b(&cmplt_msg,&dma_params);


	status = dma_check_gather_scatter(dma_params);

	dma_check_status(status);

	error = status;

//--------------------------------

	if (error == 0)
		printPASS();
	else
		printFAIL();

	return error;
}



int M2B_COPY_DDR_OCM (void) {
	int error = 0;

//----- Put your code here -------
	dma_work_msg_32b_t work_msg;
	dma_cmplt_msg_32b_t cmplt_msg;
	dma_params_t dma_params;
	int status = 0;

	printf("\n############################################################\n");
	printf("## Start    %-40s %8s",__FUNCTION__,"##\n");
	printf("############################################################\n");

	init_dma_platform();

	_init_dma();

	setup_qm_dma();

	unsigned int j;
	/*Reset all field to Zero
	* It's important to do this for DDR test
	* */

	for(j=0;j<8;j++){
		work_msg.data[j]=0x0;
		cmplt_msg.data[j]=0x0;
	}
	/*Reset all endqueue/dequeue*/
	dma_init_enq_deq_ptr();

	dma_setup_FP_ocm(FPQID4, 1);  //qid and num_of_pointers max can be 24 only

	dma_setup_msg_32b(FPQID0, WQID0, FPQPBID0, 16*1024, 0, 0, 1, &work_msg);

	dma_set_copy_bufdest_msg_32b(&work_msg);

	dma_init_data( &work_msg);

	dma_dump_work_msg_32b( &work_msg);

	dma_enqueue_msg_32b(WQID4,&work_msg);

	poll_dma_queues(WQID0,&cmplt_msg);

	dma_dump_cmplt_msg_32b(&cmplt_msg);

	dma_get_params_from_32b(&work_msg,&dma_params);

	dma_get_params_from_cmplt_32b(&cmplt_msg,&dma_params);


	status = dma_check_gather_scatter(dma_params);

	dma_check_status(status);

	error = status;

//--------------------------------

	if (error == 0)
		printPASS();
	else
		printFAIL();

	return error;
}


int M2B_COPY_OCM_OCM (void) {
	int error = 0;

//----- Put your code here -------
	dma_work_msg_32b_t work_msg;
	dma_cmplt_msg_32b_t cmplt_msg;
	dma_params_t dma_params;
	int status = 0;

	printf("\n############################################################\n");
	printf("## Start    %-40s %8s",__FUNCTION__,"##\n");
	printf("############################################################\n");

	init_dma_platform();

	_init_dma();

	setup_qm_dma();

	unsigned int j;
	/*Reset all field to Zero
	* It's important to do this for DDR test
	* */

	for(j=0;j<8;j++){
		work_msg.data[j]=0x0;
		cmplt_msg.data[j]=0x0;
	}
	/*Reset all endqueue/dequeue*/
	dma_init_enq_deq_ptr();

	dma_setup_FP_ocm(FPQID4, 1);  //qid and num_of_pointers max can be 24 only

	dma_setup_msg_32b_ocm(FPQID0, WQID0, FPQPBID0, 16*1024, 0, 0, 1, &work_msg);

	dma_set_copy_bufdest_msg_32b(&work_msg);

	dma_init_data( &work_msg);

	dma_dump_work_msg_32b( &work_msg);

	dma_enqueue_msg_32b(WQID4,&work_msg);

	poll_dma_queues(WQID0,&cmplt_msg);

	dma_dump_cmplt_msg_32b(&cmplt_msg);

	dma_get_params_from_32b(&work_msg,&dma_params);

	dma_get_params_from_cmplt_32b(&cmplt_msg,&dma_params);


	status = dma_check_gather_scatter(dma_params);

	dma_check_status(status);

	error = status;

//--------------------------------

	if (error == 0)
		printPASS();
	else
		printFAIL();

	return error;
}


int M2B_COPY (int argc, char *argv[]) {
	int error = 0;
	int number =0;

	if(argc == 0){
		printf("Run all test\n");
		error += M2B_COPY_DDR_DDR();
		arch_timer_msdelay(2000);
		error += M2B_COPY_DDR_OCM();
		arch_timer_msdelay(2000);
		error += M2B_COPY_OCM_DDR();
		arch_timer_msdelay(2000);
		error += M2B_COPY_OCM_OCM();
	}
	else if (argc > 1){
		printf("Wrong number of arguments\n");
		printf("Please enter go %s <number>\n",__FUNCTION__);
		return 0;
	}
	else {
			if(argv[0][0]>=0x30 && argv[0][0]<=0x39){
			number = atoi(argv[0]);
		}
		else {
			printf("Wrong datatype of argv[0]\n");
			printf("Please enter go %s <number>\n",__FUNCTION__);
			return 0;
		}
		switch(number){
		case 1:
			error += M2B_COPY_DDR_DDR();
			break;
		case 2:
			error += M2B_COPY_DDR_OCM();
			break;
		case 3:
			error += M2B_COPY_OCM_DDR();
			break;
		case 4:
			error += M2B_COPY_OCM_OCM();
			break;
		default:
			printf("####################################################\n");
			printf("###   Run DDR-DDR/DDR-OCM/OCM-DDR/OCM-OCM test   ###\n");
			printf("####################################################\n");
			error += M2B_COPY_DDR_DDR();
			arch_timer_msdelay(2000);
			error += M2B_COPY_DDR_OCM();
			arch_timer_msdelay(2000);
			error += M2B_COPY_OCM_DDR();
			arch_timer_msdelay(2000);
			error += M2B_COPY_DDR_OCM();


		}

	}
	if (error == 0)
		printPASS();
	else
		printFAIL();
	return error;
}









