oo===================================================================================oo
How to Compile :
----------------
   - Run one-by-one :
        source setup.csh
        make INTERNAL_SERDES_TX2RX_LOOPBACK=<0 or 1>
   - Examples INTERNAL_SERDES_TX2RX_LOOPBACK :
	For Enabling internal serdes loopback	--> use INTERNAL_SERDES_TX2RX_LOOPBACK=1
	For Disabling internal serdes loopback	--> use INTERNAL_SERDES_TX2RX_LOOPBACK=0
   - Command Example :
	make INTERNAL_SERDES_TX2RX_LOOPBACK=1
oo===================================================================================oo
Test Sequencie (1gig & 10 gig): 

- Configures SERDES level Tx-2-Rx loopback bit for all 4 Ports 
- Send 10,000 Packets 
- Receive Back 10,000 Packets 
- Validate 10,000 Packets (Verify the Pay load)
- Dumps the Pass/Fail Status 

oo===================================================================================oo
Below External Loopback test details for 1gig only:

You can also disable the loopback bit by running below commands 
This feature is only for Debug Purpose

External loop back test can be verified by removing internal Tx-2-Rx loopback test 

Prerequisites 
- Connect a CAT-5 cable between Port-0 to Port-1
- Connect a CAT-5 cable between Port-2 to Port-3

Run below commands:
Type 104  then Hit Enter
You will see the below menu
0->Set_MAC_lpbk 1->Set_PHY_lpbk 2->Reset_MAC_lpbk 3->Reset_PHY_lpbk
4->Set_SERDES_Tx-2-Rx_lpbk 5->ReSet_SERDES_Tx-2-Rx_lpbk

Type Option 5  then Hit Enter
The 5th option will remove the SERDES level Tx-2-Rx loopback mode 

After Disabling loopback bit run the test 

Run below commands:
Type 105  then Hit Enter
You will see the below menu
0->XFI-SGMII 1->SATA-SGMII 2->Both

Type Option 1  then Hit Enter
Option 1 will sending packets to SATA-SGMII ports 

Now 10,000 Packets will be sent through SATA-SGMII and Payload checking will be done assuming external loopback is connected 

If External loopback in Not Connected then test will Fail


oo===================================================================================oo
Steps for Running Image from NOR DDR (nor_ddr_up)
 
1. Change BUILD_TYPE=nor_ddr_up from setup.csh file before compiling the image   
     load a binary of bulid type = ocm_up
     so that we can load nor compatible image which was built in the the first step into NOR
     - reset halt; reset halt; ocm_map; load_image /tftpboot/md/st/eth_tx2rx_slt_ocm.bin 0x1d000000; resume 0
 
3. Load NOR DDR image in to DDR space (using below OCD_CLIENT command)
     load_image <image-location> <ddr-address>
     <ddr_address>   take this address from typing nor_upd in VBIOS

VBIOS-0>nor_upd
Erase, program and verify NOR flash (assumes image is downloaded at 0x100000000)
Usage: nor_upd <size-in-bytes> [<dest-nor-offset>]

Potenza> load_image /tftpboot/md/st/eth_tx2rx_slt_ddr_new.bin 0x100000000                                        
target_write64_buffer: wrote 842880 aligned bytes
842880 bytes written at address 0x100000000
downloaded 842880 bytes in 27.998512s (29.399 kb/s)
    
     - Note down the <Total_Bytes_Written> 

4. From Board Side (BB2) Connect below jumpers for NOR Boot
   - Connect Jumper(s) 5-6 on CON-15 
   - Connect Jumper(s) 1-2, 3-4, & 5-6 on J-9
   - Connect Jumper(s) 3-4, 5-6, 7-8, 9-10 & 15-16 on J-8
 
5. For Flashing the image, Run below command from VBIOS prompt 
   - nor_up <Total_Bytes_Written> 
           After successful completion you will see following log
VBIOS-0>nor_upd
Erase, program and verify NOR flash (assumes image is downloaded at 0x100000000)
Usage: nor_upd <size-in-bytes> [<dest-nor-offset>]
VBIOS-0>nor_upd 842880
Erasing NOR sector   0 @ 0x00000000
Erasing NOR sector   1 @ 0x00004000
Erasing NOR sector   2 @ 0x00008000
Erasing NOR sector   3 @ 0x0000C000
Erasing NOR sector   4 @ 0x00010000
Erasing NOR sector   5 @ 0x00020000
Erasing NOR sector   6 @ 0x00030000
Erasing NOR sector   7 @ 0x00040000
Erasing NOR sector   8 @ 0x00050000
Erasing NOR sector   9 @ 0x00060000
Starting write-buffer program of 421440 words ............................
................................................................... done
word-wise verifying ... done 
VBIOS-0>

6. After this switch Off and switch On the board, Image will be booted from Flash by reallocating the code to DDR 
 
oo===================================================================================oo


