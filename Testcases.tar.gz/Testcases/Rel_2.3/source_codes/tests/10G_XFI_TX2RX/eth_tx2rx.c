/////////////////////////////////////////////////////////////////////////////////////////
//file name:    eth_tx2rx.c
//create date:  25-Jun-2014
//description:  This is tx2rx test case with ext/int , port-to-port/self loopback modes
//////////////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <common.h>
#include "eth_common.h"
#include "eth_xg_csr.h"
#include "eth_mg_csr.h"
#include "eth_1g_csr.h"

#include "sm_xxx_serdes.h"//Added to match Chidvilas latest code

#include "qm_drv.h" 
#include "qm_misc.h"
#include "qm_vfw.h"

//#include "phy-xgene.h"

// Added by HG:
//#include "cle_csr.h"
//#include "cle_drv.h"
//#include "cle_util.h"
//#include "cle_com.h"
//#include "cle_def.h"
//#include "cle_db.h"


//Include required CLE Rule book by enabling one of the below files
//#include "cle_eth_tcp_udp.h"
//#include "cle_eth_hdr_split.h"

//#include "basic.h"
// Added by HG:


// Added by HG:
#include <common.h> 
#include <iolib/i2c/i2c.h> 
#include <iolib/i2c/apm_i2c.h> 
// Added by HG:

static int read_rpkt_as_xg[4]={0, 0, 0, 0};
static int read_rpkt_as_bak_xg[4]={0, 0, 0, 0};
static int read_rfcs_as_xg[4]={0, 0, 0, 0};
static int read_rfcs_as_bak_xg[4] = {0, 0, 0, 0};

extern fwd_uc_tbl_t fwd_xge1_tbl;

unsigned int gVerboseLevel=2; 

extern int xgenet_base_addr;
int mac_mode = 2;
int gating_bypass = 1; // FIXME : 
int an_en_xg = 1;
int total_err_count_xfi[4]={0, 0, 0, 0};
int qm_err_count_xfi[4]={0, 0, 0, 0};
int total_no_of_pkts=0;

static int advanced_debug_xg = 0; // 1 = Promt for options with xgenet_main, 0= quit to Menu

int terminal_server_serial_port = 0;//1 : Terminal Server, 0 : Minicom

int itr_count[4];
unsigned int reconfig_loop = 20;
//static  int read_command = 0x40000000;
//static int  pemstat1_address  = 0x00000020;
//static int  mcxmac_pemstat1_address  = 0x00000020;


#if 1 //md:
u64 buf_xfi[16]; //changes to work tx-2-rx md:
u64 buf32_xfi[16]; //changes to work tx-2-rx md:
u64 buf33_xfi[16]; //changes to work tx-2-rx md:
u64 buf34_xfi[16]; //changes to work tx-2-rx md:

#if 1 // Old function "sys_alloc_enet_buf"
qm_ret_t sys_alloc_enet_buf_old(unsigned int qmid, unsigned int mn, qm_buf_t *p_buf)
{
    qm_ret_t ret;

    p_buf->fpqid = QID0; 
    p_buf->qmid  = qmid; 

    //printf("sys_alloc data @0x408080000= 0x%x\n",read_ddr(0x408080000));
    //printf("sys_alloc data @0x408080010= 0x%x\n",read_ddr(0x408080000));
    //printf("sys_alloc data @0x408080020= 0x%x\n",read_ddr(0x408080000));
    //printf("sys_alloc data @0x408080030= 0x%x\n",read_ddr(0x408080000));
    p_buf->mid  = 0;            //changes to work tx-2-rx md:
    p_buf->rtype = QM_PROC_RTYPE; //changes to work tx-2-rx md:

    p_buf->bn = 1;
    p_buf->bs = 0;

    ret = qm_buf_alloc(p_buf);
    //ret = qm_proc_deq_dir(qmid, QID1, QM_MSG_SZ_16B, &mn, msgbuf); //changes to work tx-2-rx md:

    //printf("\nsys_alloc_enet_buf QM qm_proc_deq_dir done: mn=%d.... qmid:%d\n", mn,qmid);
    if (ret != QM_OK)
        printf("\r\nqm_buf_alloc failed: ret = %d....\n", ret);

    return ret;
}
#endif

qm_ret_t sys_alloc_enet_buf(u8 qmid, u32 fpqid, int mn, qm_buf_t *p_buf)
{
        qm_ret_t ret;

    p_buf->fpqid = fpqid;
    p_buf->qmid  = qmid;

    p_buf->mid  = 0;            //changes to work tx-2-rx md:
    p_buf->rtype = QM_PROC_RTYPE; //changes to work tx-2-rx md:

    p_buf->bn = 1;
    p_buf->bs = 0;

    ret = qm_buf_alloc(p_buf);
    if (ret != QM_OK)
        printf("\r\nqm_buf_alloc failed: ret = %d....\n", ret);

        return ret;
}


enq_req_t *sys_enet_enq_cfg(u64 da, u64 len)
{
    enq_cfg_t enq_cfg;
    enq_req_t *enq_req_test;

    enq_cfg.rt = QM_PROC_RTYPE; //QM_ENET_0_RTYPE;   
    enq_cfg.ui = QM_TEST_PATTERN; //0xc0def00d;
    enq_cfg.pl = len;
    enq_cfg.da = da;
    enq_cfg.fpqn = QID1;            
    enq_cfg.hl = 1;
    enq_cfg.qid = QID32; //QID32; //QID64;            
    enq_cfg.mn = 1; //QM_TEST_MSG_NUM;
    enq_cfg.ms = QM_MSG_SZ_32B;
    enq_cfg.notif = QM_PROC_NOTNO;  

    //return (qm_proc_bld_enq_req(&enq_cfg));// -- ORIGINAL CODE
    //printf("\n$$$$$$$$$$$$$$$$$$$$ enq_cfg.qid = %d enq_cfg.ms = %d \n",enq_cfg.qid,enq_cfg.ms);
    enq_req_test=qm_proc_bld_enq_req(&enq_cfg);
    //   extern enq_req_t er;
    //   enq_req_test=&er;
    //printf("\nenq_req_test : 0x%012lx, &er : 0x%012lx \n",enq_req_test, &er);//_tp

    //printf("\n@@@@@@@@ After  enq_req.qid = %d enq_req.msg_size = %d \n",enq_req_test->qid,enq_req_test->msg_size);
    //printf("@@@@@@@@@@ address of enq_req_test = 0x%x \n",enq_req_test);
    //printf("with and address of enq_req_test = 0x%x \n",&enq_req_test);
    return enq_req_test;

}

enq_req_t *sys_enet_enq_cfg32(u64 da, unsigned int len)
{
    enq_cfg_t enq_cfg;
    enq_req_t *enq_req_test;

    enq_cfg.rt = QM_PROC_RTYPE; //QM_ENET_0_RTYPE;   
    enq_cfg.ui = QM_TEST_PATTERN; //0xc0def00d;
    enq_cfg.pl = len;
    enq_cfg.da = da;
    enq_cfg.fpqn = QID1;            
    enq_cfg.hl = 1;
    enq_cfg.qid = QID33; //QID32; //QID64;            
    enq_cfg.mn = 1; //QM_TEST_MSG_NUM;
    enq_cfg.ms = QM_MSG_SZ_32B;
    enq_cfg.notif = QM_PROC_NOTNO;  

    enq_req_test = qm_proc_bld_enq_req32(&enq_cfg);

    return enq_req_test;
}

enq_req_t *sys_enet_enq_cfg33(u64 da, unsigned int len)
{
    enq_cfg_t enq_cfg;
    enq_req_t *enq_req_test;

    enq_cfg.rt = QM_PROC_RTYPE; //QM_ENET_0_RTYPE;   
    enq_cfg.ui = QM_TEST_PATTERN; //0xc0def00d;
    enq_cfg.pl = len;
    enq_cfg.da = da;
    enq_cfg.fpqn = QID1;            
    enq_cfg.hl = 1;
    enq_cfg.qid = QID32; //QID32; //QID64;            
    enq_cfg.mn = 1; //QM_TEST_MSG_NUM;
    enq_cfg.ms = QM_MSG_SZ_32B;
    enq_cfg.notif = QM_PROC_NOTNO;  

    enq_req_test = qm_proc_bld_enq_req33(&enq_cfg);

    return enq_req_test;
}

enq_req_t *sys_enet_enq_cfg34(u64 da, unsigned int len)
{
    enq_cfg_t enq_cfg;
    enq_req_t *enq_req_test;

    enq_cfg.rt = QM_PROC_RTYPE; //QM_ENET_0_RTYPE;   
    enq_cfg.ui = QM_TEST_PATTERN; //0xc0def00d;
    enq_cfg.pl = len;
    enq_cfg.da = da;
    enq_cfg.fpqn = QID1;            
    enq_cfg.hl = 1;
    enq_cfg.qid = QID33; //QID32; //QID64;            
    enq_cfg.mn = 1; //QM_TEST_MSG_NUM;
    enq_cfg.ms = QM_MSG_SZ_32B;
    enq_cfg.notif = QM_PROC_NOTNO;  

    enq_req_test = qm_proc_bld_enq_req34(&enq_cfg);

    return enq_req_test;
}

#if 0 // Old "sys_enet_enq_cfg_xfi"
//Start : XFI_10G
enq_req_t *sys_enet_enq_cfg_xfi(u64 da, u64 len)
{
    enq_cfg_t enq_cfg;
    enq_req_t *enq_req_test;

#if 0
	int user_input;
	printf("\nEnter mn = 0x");
	if(terminal_server_serial_port==1) user_input = get_val(); user_input = get_val();
        enq_cfg.mn = user_input; //QM_TEST_MSG_NUM;
#endif

    enq_cfg.rt = QM_PROC_RTYPE; //QM_ENET_0_RTYPE;   
    enq_cfg.ui = QM_TEST_PATTERN; //0xc0def00d;
    enq_cfg.pl = len;
    enq_cfg.da = da;
    enq_cfg.fpqn = QID1;            
    enq_cfg.hl = 1;
    enq_cfg.qid = QID32; //QID32; //QID64;            
    enq_cfg.mn = 1; //QM_TEST_MSG_NUM;
    enq_cfg.ms = QM_MSG_SZ_32B;
    enq_cfg.notif = QM_PROC_NOTNO;  

    //return (qm_proc_bld_enq_req(&enq_cfg));// -- ORIGINAL CODE
    //printf("\n$$$$$$$$$$$$$$$$$$$$ enq_cfg.qid = %d enq_cfg.ms = %d \n",enq_cfg.qid,enq_cfg.ms);
    enq_req_test=qm_proc_bld_enq_req_xfi(&enq_cfg);
    //extern enq_req_t er_xfi;
    //enq_req_test=&er_xfi;
    //printf("\nenq_req_test : 0x%012lx, &er : 0x%012lx \n",enq_req_test, &er);//_tp

    //printf("\n@@@@@@@@ After  enq_req.qid = %d enq_req.msg_size = %d \n",enq_req_test->qid,enq_req_test->msg_size);
    //printf("@@@@@@@@@@ address of enq_req_test = 0x%x \n",enq_req_test);
    //printf("with and address of enq_req_test = 0x%x \n",&enq_req_test);
    return enq_req_test;

}

enq_req_t *sys_enet_enq_cfg32_xfi(u64 da, unsigned int len)
{
    enq_cfg_t enq_cfg;
    enq_req_t *enq_req_test;

    enq_cfg.rt = QM_PROC_RTYPE; //QM_ENET_0_RTYPE;   
    enq_cfg.ui = QM_TEST_PATTERN; //0xc0def00d;
    enq_cfg.pl = len;
    enq_cfg.da = da;
    enq_cfg.fpqn = QID1;            
    enq_cfg.hl = 1;
    enq_cfg.qid = QID33; //QID32; //QID64;            
    enq_cfg.mn = 1; //QM_TEST_MSG_NUM;
    enq_cfg.ms = QM_MSG_SZ_32B;
    enq_cfg.notif = QM_PROC_NOTNO;  

    //return (qm_proc_bld_enq_req32_xfi(&enq_cfg));
    enq_req_test=qm_proc_bld_enq_req32_xfi(&enq_cfg);
    return enq_req_test;
 
}

enq_req_t *sys_enet_enq_cfg33_xfi(u64 da, unsigned int len)
{
    enq_cfg_t enq_cfg;
    enq_req_t *enq_req_test;

    enq_cfg.rt = QM_PROC_RTYPE; //QM_ENET_0_RTYPE;   
    enq_cfg.ui = QM_TEST_PATTERN; //0xc0def00d;
    enq_cfg.pl = len;
    enq_cfg.da = da;
    enq_cfg.fpqn = QID1;            
    enq_cfg.hl = 1;
    enq_cfg.qid = QID32; //QID32; //QID64;            
    enq_cfg.mn = 1; //QM_TEST_MSG_NUM;
    enq_cfg.ms = QM_MSG_SZ_32B;
    enq_cfg.notif = QM_PROC_NOTNO;  

    //return (qm_proc_bld_enq_req33_xfi(&enq_cfg));
    enq_req_test=qm_proc_bld_enq_req33_xfi(&enq_cfg);
    return enq_req_test;
}

enq_req_t *sys_enet_enq_cfg34_xfi(u64 da, unsigned int len)
{
    enq_cfg_t enq_cfg;
    enq_req_t *enq_req_test;

    enq_cfg.rt = QM_PROC_RTYPE; //QM_ENET_0_RTYPE;   
    enq_cfg.ui = QM_TEST_PATTERN; //0xc0def00d;
    enq_cfg.pl = len;
    enq_cfg.da = da;
    enq_cfg.fpqn = QID1;            
    enq_cfg.hl = 1;
    enq_cfg.qid = QID33; //QID32; //QID64;            
    enq_cfg.mn = 1; //QM_TEST_MSG_NUM;
    enq_cfg.ms = QM_MSG_SZ_32B;
    enq_cfg.notif = QM_PROC_NOTNO;  

    //return (qm_proc_bld_enq_req34_xfi(&enq_cfg));
    enq_req_test=qm_proc_bld_enq_req34_xfi(&enq_cfg);
    return enq_req_test;
}

//End : XFI_10G

#endif // Old "sys_enet_enq_cfg_xfi"

#if 1  // New "sys_enet_enq_cfg_xfi"
enq_req_t *sys_enet_enq_cfg_xfi(u64 da, u32 len)
{
    enq_cfg_t enq_cfg;
    enq_req_t *enq_req_test;

    enq_cfg.rt = QM_PROC_RTYPE;
    enq_cfg.ui = QM_TEST_PATTERN;
    enq_cfg.pl = len;
    enq_cfg.da = da;
    enq_cfg.fpqn = QID0;
    enq_cfg.hl = 1;
    enq_cfg.qid = QID32;
    enq_cfg.mn = SLT_MSG_NUM;
    enq_cfg.ms = QM_MSG_SZ_32B;
    enq_cfg.notif = QM_PROC_NOTNO;

    enq_req_test=qm_proc_bld_enq_req_xfi(&enq_cfg);

    return enq_req_test;
}

enq_req_t *sys_enet_enq_cfg32_xfi(u64 da, u32 len)
{
    enq_cfg_t enq_cfg;
    enq_req_t *enq_req_test;

    enq_cfg.rt = QM_PROC_RTYPE;
    enq_cfg.ui = QM_TEST_PATTERN;
    enq_cfg.pl = len;
    enq_cfg.da = da;
    enq_cfg.fpqn = QID1;
    enq_cfg.hl = 1;
    enq_cfg.qid = QID33;
    enq_cfg.mn = SLT_MSG_NUM;
    enq_cfg.ms = QM_MSG_SZ_32B;
    enq_cfg.notif = QM_PROC_NOTNO;

    enq_req_test=qm_proc_bld_enq_req32_xfi(&enq_cfg);

    return enq_req_test;
}

enq_req_t *sys_enet_enq_cfg33_xfi(u64 da, u32 len)
{
    enq_cfg_t enq_cfg;
    enq_req_t *enq_req_test;

    enq_cfg.rt = QM_PROC_RTYPE;
    enq_cfg.ui = QM_TEST_PATTERN;
    enq_cfg.pl = len;
    enq_cfg.da = da;
    enq_cfg.fpqn = QID0;
    enq_cfg.hl = 1;
    enq_cfg.qid = QID32;
    enq_cfg.mn = SLT_MSG_NUM;
    enq_cfg.ms = QM_MSG_SZ_32B;
    enq_cfg.notif = QM_PROC_NOTNO;

    enq_req_test=qm_proc_bld_enq_req33_xfi(&enq_cfg);

    return enq_req_test;
}

enq_req_t *sys_enet_enq_cfg34_xfi(u64 da, u32 len)
{
    enq_cfg_t enq_cfg;
    enq_req_t *enq_req_test;

    enq_cfg.rt = QM_PROC_RTYPE;
    enq_cfg.ui = QM_TEST_PATTERN;
    enq_cfg.pl = len;
    enq_cfg.da = da;
    enq_cfg.fpqn = QID1;
    enq_cfg.hl = 1;
    enq_cfg.qid = QID33;
    enq_cfg.mn = SLT_MSG_NUM;
    enq_cfg.ms = QM_MSG_SZ_32B;
    enq_cfg.notif = QM_PROC_NOTNO;

    enq_req_test=qm_proc_bld_enq_req34_xfi(&enq_cfg);

    return enq_req_test;
}

#endif // New "sys_enet_enq_cfg_xfi"

void set_mac_level_lpbk() {

    unsigned int temp;
    int port;

#if 0
    printf("\nConfigure MAC level Tx-2-Rx lpbk Mode for XFI-SGMII Ports\n");
    // Configure MAC level tx-2-rx internal loopback mode for all 4 ports 
    for(port=0; port<4; port++) {
        temp = mcxmac_ind_rd(PE_MCXMAC_MAC_CONFIG_1__ADDR, XGENET,port,0);
        printf("\r\nBefore Write portNo:%d reg:%x val:%x\r\n",port,PE_MCXMAC_MAC_CONFIG_1__ADDR,temp);

        temp = temp | 0x100;
        mcxmac_ind_wr(PE_MCXMAC_MAC_CONFIG_1__ADDR,temp,XGENET,port,0);

        temp = mcxmac_ind_rd(PE_MCXMAC_MAC_CONFIG_1__ADDR, XGENET,port,0);
        printf("After Write  portNo:%d reg:%x val:%x\r\n",port,PE_MCXMAC_MAC_CONFIG_1__ADDR,temp);
    }
#endif
#if 0
    printf("\nConfigure MAC level Tx-2-Rx lpbk Mode for SATA-SGMII Ports\n");
    // Configure MAC level tx-2-rx internal loopback mode for all 4 ports 
    for(port=0; port<4; port++) {
        temp = mcxmac_ind_rd(PE_MCXMAC_MAC_CONFIG_1__ADDR, ENET,port,0);
        printf("\r\nBefore Write portNo:%d reg:%x val:%x\r\n",port,PE_MCXMAC_MAC_CONFIG_1__ADDR,temp);

        temp = temp | 0x100;
        mcxmac_ind_wr(PE_MCXMAC_MAC_CONFIG_1__ADDR,temp,ENET,port,0);

        temp = mcxmac_ind_rd(PE_MCXMAC_MAC_CONFIG_1__ADDR, ENET,port,0);
        printf("After Write  portNo:%d reg:%x val:%x\r\n",port,PE_MCXMAC_MAC_CONFIG_1__ADDR,temp);
    }
#endif
}

void reset_mac_level_lpbk() {

    unsigned int temp;
    int port;
#if 0
    printf("\nReset MAC level Tx-2-Rx lpbk Mode for XFI-SGMII\n");
    // Configure MAC level tx-2-rx internal loopback mode for all 4 ports 
    for(port=0; port<4; port++) {
        temp = mcxmac_ind_rd(PE_MCXMAC_MAC_CONFIG_1__ADDR, XGENET,port,0);
        printf("\r\nBefore Write portNo:%d reg:%x val:%x\r\n",port,PE_MCXMAC_MAC_CONFIG_1__ADDR,temp);

        temp = temp & 0xFEFF;
        mcxmac_ind_wr(PE_MCXMAC_MAC_CONFIG_1__ADDR,temp,XGENET,port,0);

        temp = mcxmac_ind_rd(PE_MCXMAC_MAC_CONFIG_1__ADDR, XGENET,port,0);
        printf("After Write  portNo:%d reg:%x val:%x\r\n",port,PE_MCXMAC_MAC_CONFIG_1__ADDR,temp);
    }
#endif
#if 0
    printf("\nReset MAC level Tx-2-Rx lpbk Mode SATA-SGMII\n");
    // Configure MAC level tx-2-rx internal loopback mode for all 4 ports 
    for(port=0; port<4; port++) {
        temp = mcxmac_ind_rd(PE_MCXMAC_MAC_CONFIG_1__ADDR, ENET,port,0);
        printf("\r\nBefore Write portNo:%d reg:%x val:%x\r\n",port,PE_MCXMAC_MAC_CONFIG_1__ADDR,temp);

        temp = temp & 0xFEFF;
        mcxmac_ind_wr(PE_MCXMAC_MAC_CONFIG_1__ADDR,temp,ENET,port,0);

        temp = mcxmac_ind_rd(PE_MCXMAC_MAC_CONFIG_1__ADDR, ENET,port,0);
        printf("After Write  portNo:%d reg:%x val:%x\r\n",port,PE_MCXMAC_MAC_CONFIG_1__ADDR,temp);
    }
#endif
}

#if 1
void set_phy_level_lpbk() {

    int phy_addr=0,phy_reg=0,rd_data,port,ind_address,ind_data;

    printf("\nConfigure PHY level Tx-2-Rx loopback\n");
    phy_reg=0;
    /* 
       PHY_ADDR = 0x11 to 0x14 for SATA-SGMII PHY
       PHY_ADDR = 0x15 to 0x18 for XFI-SGMII  PHY
       */
    for (phy_addr=0x15; phy_addr<0x19; phy_addr++) {
        ind_address = ((phy_addr << 8) | phy_reg);
        ind_data = mdio_rd(ind_address,MENET,0,0);
        printf("Before phy_addr:0x%x phy_reg:0x%x ind_address:0x%x ind_data:0x%x \n",phy_addr,phy_reg,ind_address,ind_data);

        ind_data = ind_data | 0x4000;
        mdio_wr(ind_address,ind_data,MENET,0,0); // Enable 

        ind_address = ((phy_addr << 8) | phy_reg);
        ind_data = mdio_rd(ind_address,MENET,0,0);
        printf("After  phy_addr:0x%x phy_reg:0x%x ind_address:0x%x ind_data:0x%x \n",phy_addr,phy_reg,ind_address,ind_data);
    }
}
#endif

#if 1
void reset_phy_level_lpbk() {

    int phy_addr=0,phy_reg=0,rd_data,port,ind_address,ind_data;

    printf("\nReset PHY level Tx-2-Rx loopback\n");
    phy_reg=0;
    /* 
       PHY_ADDR = 0x11 to 0x14 for SATA-SGMII PHY
       PHY_ADDR = 0x15 to 0x18 for XFI-SGMII  PHY
       */    
    for (phy_addr=0x15; phy_addr<0x19; phy_addr++) {
        ind_address = ((phy_addr << 8) | phy_reg);
        ind_data = mdio_rd(ind_address,MENET,0,0);
        printf("Before phy_addr:0x%x phy_reg:0x%x ind_address:0x%x ind_data:0x%x \n",phy_addr,phy_reg,ind_address,ind_data);

        ind_data = ind_data & 0xbfff;
        mdio_wr(ind_address,ind_data,MENET,0,0); // Enable 

        ind_address = ((phy_addr << 8) | phy_reg);
        ind_data = mdio_rd(ind_address,MENET,0,0);
        printf("After  phy_addr:0x%x phy_reg:0x%x ind_address:0x%x ind_data:0x%x \n",phy_addr,phy_reg,ind_address,ind_data);
    }
}
#endif

int eth_tx2rx_lpbk_test_xfi_1g() {

    total_err_count_xfi[0]=0;
    total_err_count_xfi[1]=0;
    total_err_count_xfi[2]=0;
    total_err_count_xfi[3]=0;
#if 0    
    printf("lpbk_test  data @0x408080000= 0x%x\n",read_ddr(0x408080000));
    printf("lpbk_test  data @0x408080010= 0x%x\n",read_ddr(0x408080000));
    printf("lpbk_test  data @0x408080020= 0x%x\n",read_ddr(0x408080000));
    printf("lpbk_test  data @0x408080030= 0x%x\n",read_ddr(0x408080000));
    printf("lpbk_test  data @0x408580000= 0x%x\n",read_ddr(0x408080000));
    printf("lpbk_test  data @0x408580010= 0x%x\n",read_ddr(0x408080000));
    printf("lpbk_test  data @0x408580020= 0x%x\n",read_ddr(0x408080000));
    printf("lpbk_test  data @0x408580030= 0x%x\n",read_ddr(0x408080000));
#endif
    unsigned int mn,qmid,ps,pn,temp;
    qm_ret_t ret;
    enq_req_t *per;
    enq_req_t *per32;
    enq_req_t *per33;
    enq_req_t *per34;
    qm_buf_t qm_buf_xfi;
    qm_buf_t qm_buf32_xfi;
    qm_buf_t qm_buf33_xfi;
    qm_buf_t qm_buf34_xfi;
    enq_cfg_t enq_cfg;
    q_state_t cfg;
    int port,i;
    int port_num_calc=0;

    //printf("\nDelay while entering eth_tx2rx_lpbk_test_xfi_1g ...");USDELAY(10000);
    //printf("\n +++++++++++++ XFI-SGMII Tx-2-Rx loopback test +++++++++++++++\n");//Commented by Hrishikesh. This print may not be required
    qm_buf_xfi.bp = buf_xfi;
    qm_buf32_xfi.bp = buf32_xfi;
    qm_buf33_xfi.bp = buf33_xfi;
    qm_buf34_xfi.bp = buf34_xfi;
/*
    q_state_t q_state_pq_32_0[20];
    u64 wn1[] ={1,1,1,1,1};
    u64 hd_ptr_32_0; 
    u64 hd_ptr_33_0; 
    u64 hd_ptr_32_2; 
    u64 hd_ptr_33_2; 
*/
	USDELAY(1000);
    memset ((char *)msgbuf_xfi, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
	USDELAY(1000);
    memset ((char *)msgbuf32_xfi, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
	USDELAY(1000);
    memset ((char *)msgbuf33_xfi, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
	USDELAY(1000);
    memset ((char *)msgbuf34_xfi, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    //printf("\nEnter Packet Size : 0x");
    //if(terminal_server_serial_port==1) ps = get_val(); ps = get_val();
    ps = 256;//printf("\n");
    //printf("Packet Size entered (in int) : %d",ps);

    printf("\nEnter Number of Packets : 0x");
    if(terminal_server_serial_port==1) pn = get_val(); pn = get_val();
    //pn = 1000000; //printf("\n"); // 1-m
    //pn = 100000; //printf("\n");  // 100k
    //pn = 10000; //printf("\n");   // 10k
    //pn = 1000; //printf("\n");
    //pn = 10; //printf("\n");
    //pn = 5; //printf("\n");
    //pn = 1; //printf("\n");
    printf("\nNumber of Packets entered (in int) : %d\n\n",pn);
    printf("Running Ethernet Traffic ... \n\n");

    //printf("\nPress <Enter> to continue ..."); if(terminal_server_serial_port==1) get_val(); get_val();

    /*
       ps = 128; //PKT_SIZE; //packet size
       pn = 1; //PKT_NUM; // Number of PAckets to send
       */

    pn = pn*4;

    qmid = 0;
    //while (qmid<3) {
    //USDELAY(1000);

//    mn = QM_TEST_MSG_NUM;
    mn = 100;

#if 1 //Port-0/1
    //	printf("\nsys_alloc_enet_buf  ... # P-0\n");
    //printf("\nDelay for sys_alloc_enet_buf P0 ...");
    USDELAY(100);
    ret = sys_alloc_enet_buf_old(0, mn, &qm_buf_xfi); //// Allocate the FPQ Buffer
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf_old Fail qmid:%d\r\n",qmid);
        return ret;
    }
    //	printf("\nsys_alloc_enet_buf  ... # P-1\n");
    //printf("\nDelay for sys_alloc_enet_buf P1 ...");
    USDELAY(100);
    ret = sys_alloc_enet_buf_old(0, mn, &qm_buf32_xfi); //// Allocate the FPQ Buffer
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf32_old Fail qmid:%d\r\n",qmid);
        return ret;
    }
#endif
#if 1 // Port-2/3
    //	printf("\nsys_alloc_enet_buf  ... # P-2\n");
    //printf("\nDelay for sys_alloc_enet_buf P2 ...");
    USDELAY(100);
    ret = sys_alloc_enet_buf_old(2, mn, &qm_buf33_xfi); //// Allocate the FPQ Buffer
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf33_old Fail qmid:%d\r\n",qmid);
        return ret;
    }
    //printf("\nsys_alloc_enet_buf  ... # P-3\n");
    //printf("\nDelay for sys_alloc_enet_buf P3 ...");
    USDELAY(100);
    ret = sys_alloc_enet_buf_old(2, mn, &qm_buf34_xfi); //// Allocate the FPQ Buffer
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf34_old Fail qmid:%d\r\n",qmid);
        return ret;
    }
    //	printf("\nsys_alloc_enet_buf  ... # End\n");

#endif


#if 1


    //printf("\nQM sys_alloc_enet_buf done....  qmid:%d\r\n",qmid);//Not required for SLT Test
#if 1  //Port-0/1
    //printf("\nDelay for qm_build_eth_pkt P0 ...");
    USDELAY(100);
    ret = qm_build_eth_pkt((unsigned char *)buf_xfi[0], ps);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt Fail qmid:%d\r\n",qmid);
        return ret;

    }
    //printf("\nDelay for qm_build_eth_pkt P1 ...");
    USDELAY(100);
    ret = qm_build_eth_pkt((unsigned char *)buf32_xfi[0], ps);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt32 Fail qmid:%d\r\n",qmid);
        return ret;

    }
#endif
#if 1 //Port-2/3
    //printf("\nDelay for qm_build_eth_pkt P2 ...");
    USDELAY(100);
    ret = qm_build_eth_pkt((unsigned char *)buf33_xfi[0], ps);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt33 Fail qmid:%d\r\n",qmid);
        return ret;

    }
    //printf("\nDelay for qm_build_eth_pkt P3 ...");
    USDELAY(100);
    ret = qm_build_eth_pkt((unsigned char *)buf34_xfi[0], ps);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt34 Fail qmid:%d\r\n",qmid);
        return ret;

    }
#endif

    //printf("QM qm_build_eth_pkt done....    qmid:%d\r\n",qmid);//Not required for SLT Test

    //printf("\n\nEth packet dump just after bld eth pkt for buf1");
    //eth_pkt_dump((unsigned char *)buf1[0], ps);//DELETE THIS
#if 1 //Port-0/1
    //printf("\nDelay for sys_enet_enq_cfg_xfi P0 ...");
    USDELAY(100);
    per = sys_enet_enq_cfg_xfi(buf_xfi[0], ps);
    extern enq_req_t er_xfi;
    per = &er_xfi;
    if (!per) {
        printf("QM qm_proc_bld_enq_req failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }

    //printf("\nDelay for sys_enet_enq_cfg_xfi P1 ...");
    USDELAY(100);
    per32 = sys_enet_enq_cfg32_xfi(buf32_xfi[0], ps);
    extern enq_req_t er32_xfi;
    per32 = &er32_xfi;
    if (!per32) {
        printf("QM qm_proc_bld_enq_req failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }
#endif

#if 1 // Port-2/3
    //printf("\nDelay for sys_enet_enq_cfg_xfi P2 ...");
    USDELAY(100);
    per33 = sys_enet_enq_cfg33_xfi(buf33_xfi[0], ps);
    extern enq_req_t er33_xfi;
    per33 = &er33_xfi;
    if (!per33) {
        printf("QM qm_proc_bld_enq_req failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }

    //printf("\nDelay for sys_enet_enq_cfg_xfi P3 ...");
    USDELAY(100);
    per34 = sys_enet_enq_cfg34_xfi(buf34_xfi[0], ps);
    extern enq_req_t er34_xfi;
    per34 = &er34_xfi;
    if (!per34) {
        printf("QM qm_proc_bld_enq_req failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }
#endif


    q_state_t q_state_pq_32_0[20];
/*
    u64 volatile wn1[] ={1,1,1,1,1};
    u64 volatile hd_ptr_32_0; 
    u64 volatile hd_ptr_33_0; 
    u64 volatile hd_ptr_32_2; 
    u64 volatile hd_ptr_33_2; 
*/
    //u64 wn1[] ={1,1,1,1,1};
    u8 wn1[] ={1,1,1,1,1};
    u64 hd_ptr_32_0; 
    u64 hd_ptr_33_0; 
    u64 hd_ptr_32_2; 
    u64 hd_ptr_33_2; 

    	    //printf("\nDelay for qm_get_q_state_dir P0 ...");USDELAY(1000);
    QM_CHK_RET(qm_get_q_state_dir(0,32,1,wn1,&q_state_pq_32_0[0]));
    	    //printf("\nDelay for hd_ptr P0 ...");
		//USDELAY(100000);
    hd_ptr_32_0 = (q_state_pq_32_0[0].pqfp.hd_ptr);
    //printf("\nhd_ptr_32_0 = 0x%x",hd_ptr_32_0);
    	    //printf("\nDelay for qm_get_q_state_dir P1 ...");USDELAY(1000);
    QM_CHK_RET(qm_get_q_state_dir(0,33,1,wn1,&q_state_pq_32_0[0]));
    	    //printf("\nDelay for hd_ptr P1 ...");
		//USDELAY(100000);
    hd_ptr_33_0 = (q_state_pq_32_0[0].pqfp.hd_ptr);
    //printf("\nhd_ptr_33_0 = 0x%x",hd_ptr_33_0);
    	    //printf("\nDelay for qm_get_q_state_dir P2 ...");USDELAY(1000);
    QM_CHK_RET(qm_get_q_state_dir(2,32,1,wn1,&q_state_pq_32_0[0]));
    	    //printf("\nDelay for hd_ptr P2 ...");
		//USDELAY(100000);
    hd_ptr_32_2 = (q_state_pq_32_0[0].pqfp.hd_ptr);
    //printf("\nhd_ptr_32_2 = 0x%x",hd_ptr_32_2);
    	    //printf("\nDelay for qm_get_q_state_dir P3 ...");USDELAY(1000);
    QM_CHK_RET(qm_get_q_state_dir(2,33,1,wn1,&q_state_pq_32_0[0]));
    	    //printf("\nDelay for hd_ptr P3 ...");
		//USDELAY(100000);
    hd_ptr_33_2 = (q_state_pq_32_0[0].pqfp.hd_ptr);
    //printf("\nhd_ptr_33_2 = 0x%x",hd_ptr_33_2);
    	    //printf("\nLast delay ...");USDELAY(1000);
    //printf("QM qm_proc_bld_enq_req done.... qmid:%d\r\n",qmid);//Not required for SLT Test
    for(i=0; i<pn; i++) {
        //	for(i=0; i<2; i++) {//Port-0/1
        //	for(i=2; i<4; i++) {//Port-2/3
        //printf("\n------------------ PacketNo:%d -----------------\n",i);//Not required for SLT Test

	//printf("\nPacket No. : %d",i);

        if((i%4) == 0)
        {	
		port_num_calc=0;
            per->qid = QID32; // port-0
	    //USDELAY(1000);
            ret = qm_proc_enq_dir(0,per);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                return ret;
            }
    	    //printf("\nDelay for qm_proc_enq_dir P0 ...");
	    //USDELAY(10000);
            pkt_compare_xfi(port_num_calc, hd_ptr_32_0, i/4);
//            pkt_compare_xfi(port_num_calc, hd_ptr_32_0, i);
            //pkt_compare_xfi(port_num_calc, 0);
        }

#if 1  //Comment this part to not send packets on XGE-1/2/3
        else if((i%4) == 1)
        {	port_num_calc=1;
            per32->qid = QID33; // port-1
	    //USDELAY(1000);
            ret = qm_proc_enq_dir(0,per32);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir per32 qmid:%d failed ret:%d\r\n",qmid,ret);
                return ret;
            }
    	    //printf("\nDelay for qm_proc_enq_dir P1 ...");
	    //USDELAY(100000);
            pkt_compare_xfi(port_num_calc, hd_ptr_33_0, i/4);
            //pkt_compare_xfi(port_num_calc, 0);

        }
        else if((i%4) == 2)
        {	port_num_calc=2;
            per33->qid = QID32; // port-0
	    //USDELAY(1000);
            ret = qm_proc_enq_dir(2,per33);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir per33 qmid:%d failed ret:%d\r\n",qmid,ret);
                return ret;
            }
    	    //printf("\nDelay for qm_proc_enq_dir P2 ...");
	    //USDELAY(100000);
            pkt_compare_xfi(port_num_calc, hd_ptr_32_2, i/4);
            //pkt_compare_xfi(port_num_calc, 0);
        }
        else if((i%4) == 3)
        {	port_num_calc=3;
            per34->qid = QID33; // port-1
	    //USDELAY(1000);
            ret = qm_proc_enq_dir(2,per34);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir per34 qmid:%d failed ret:%d\r\n",qmid,ret);
                return ret;
            }
    	    //printf("\nDelay for qm_proc_enq_dir P3 ...");
	    //USDELAY(100000);
            pkt_compare_xfi(port_num_calc, hd_ptr_33_2, i/4);
            //pkt_compare_xfi(port_num_calc, 0);
        }
#endif  //Comment this part to not send packets on XGE-1/2/3

        //			ret = qm_proc_enq_dir(qmid,per);
        //printf("QM qm_proc_enq_dir done....     qmid:%d per->qid:%d PortNo:%d\n",qmid,per->qid,(i%2));//Not required for SLT Test
        //USDELAY(3000);
        //pkt_compare_xfi(port_num_calc, hd_ptr_32_0);
    }
    //USDELAY(1000);
    //	qmid+=2;
    //	} // while(qmid<3)

    /*    
          read_statistics_mcxmac(0);
          read_statistics_mcxmac(1);
          read_statistics_mcxmac(2);
          read_statistics_mcxmac(3);
          */    
#endif
    }

    /*
       void disable_mgmt_neg_edge() {
       int rd_data;

       rd_data = mcxmac_ind_rd(PE_MCXMAC_MII_MGMT_CONFIG__ADDR, MENET, 0, 0);
       printf("Before PE_MCXMAC_MII_MGMT_CONFIG__ADDR0x%x rd_data:0x%x\n",PE_MCXMAC_MII_MGMT_CONFIG__ADDR, rd_data);

       rd_data = rd_data & 0xbfffffff; // disable negedge
       mcxmac_ind_wr(PE_MCXMAC_MII_MGMT_CONFIG__ADDR,rd_data,MENET, 0, 0);

       rd_data = mcxmac_ind_rd(PE_MCXMAC_MII_MGMT_CONFIG__ADDR, MENET, 0, 0);
       printf("After PE_MCXMAC_MII_MGMT_CONFIG__ADDR0x%x rd_data:0x%x\n",PE_MCXMAC_MII_MGMT_CONFIG__ADDR, rd_data);
       }
       */

#if 0
    void phy_rd() {

        // PHY MDIO access for all 9 ports 
        int phy_addr=0,phy_reg=0,rd_data,port,ind_address,ind_data;

        //disable_mgmt_neg_edge();

#if 1   
        /*
           phy_reg=2;
           for (phy_addr=0x1; phy_addr<0x20; phy_addr++) {
           ind_address = ((phy_addr << 8) | phy_reg);
           ind_data = mdio_rd(ind_address,MENET,0,0);
           printf("phy_addr:0x%x phy_reg:0x%x ind_address:0x%x ind_data:0x%x \n",phy_addr,phy_reg,ind_address,ind_data);
           }
           */

        phy_reg=0;
        while(phy_reg < 19) {
            printf("\n <<<<<<------------ PHY Reg_Addr:%d --------->>>>>>\n",phy_reg);
            for (port=0; port<1; port++) {
                /*
                   printf("\n ------------ PHY reg_addr:0x%x portNo:%d ---------\n",phy_reg,port);
                   rd_data = mcxmac_ind_rd(PE_MCXMAC_MII_MGMT_CONFIG__ADDR, MENET, port, 0);
                   printf("Before port:%d PE_MCXMAC_MII_MGMT_CONFIG__ADDR0x%x rd_data:0x%x\n",port,PE_MCXMAC_MII_MGMT_CONFIG__ADDR, rd_data);

                   rd_data = rd_data & 0xbfffffff; // disable negedge
                   mcxmac_ind_wr(PE_MCXMAC_MII_MGMT_CONFIG__ADDR,rd_data,MENET, port, 0);

                   rd_data = mcxmac_ind_rd(PE_MCXMAC_MII_MGMT_CONFIG__ADDR, MENET, port, 0);
                   printf("After port:%d PE_MCXMAC_MII_MGMT_CONFIG__ADDR0x%x rd_data:0x%x\n",port,PE_MCXMAC_MII_MGMT_CONFIG__ADDR, rd_data);                       */
                /*
                   rd_data = mcxmac_ind_rd(PE_MCXMAC_MII_MGMT_CONTROL__ADDR, MENET, port, 0);
                   printf("port:%d PE_MCXMAC_MII_MGMT_CONTROL__ADDR0x%x rd_data:0x%x\n",port,PE_MCXMAC_MII_MGMT_CONTROL__ADDR, rd_data);

                   rd_data = mcxmac_ind_rd(PE_MCXMAC_MII_MGMT_STATUS__ADDR, MENET, port, 0);
                   printf("port:%d PE_MCXMAC_MII_MGMT_STATUS__ADDR0x%x rd_data:0x%x\n",port,PE_MCXMAC_MII_MGMT_STATUS__ADDR, rd_data);

                   rd_data = mcxmac_ind_rd(PE_MCXMAC_MII_MGMT_INDICATORS__ADDR, MENET, port, 0);
                   printf("port:%d PE_MCXMAC_MII_MGMT_INDICATORS__ADDR0x%x rd_data:0x%x\n",port,PE_MCXMAC_MII_MGMT_INDICATORS__ADDR, rd_data);
                   */
                /*
                   printf("\nPHY CSR Access for Port:%d\n",port);
                   phy_addr = 2; // for RGMII port
                   ind_address = ((phy_addr << 8) | phy_reg);
                   ind_data = mdio_rd(ind_address,MENET,port,1);
                   printf("RGMII Port phy_addr:0x%x phy_reg:0x%x ind_address:0x%x ind_data:0x%x \n",phy_addr,phy_reg,ind_address,ind_data);
                   */    
                for (phy_addr=0x15; phy_addr<0x19; phy_addr++) {
                    ind_address = ((phy_addr << 8) | phy_reg);
                    ind_data = mdio_rd(ind_address,MENET,0,0);
                    printf("SGMII Port phy_addr:0x%x phy_reg:0x%x ind_address:0x%x ind_data:0x%x \n",phy_addr,phy_reg,ind_address,ind_data);
                }

                printf("Configure PHY level Tx-2-Rx loopback\n");
                phy_reg=0;
                for (phy_addr=0x15; phy_addr<0x19; phy_addr++) {
                    ind_address = ((phy_addr << 8) | phy_reg);
                    ind_data = mdio_rd(ind_address,MENET,0,0);
                    printf("Before phy_addr:0x%x phy_reg:0x%x ind_address:0x%x ind_data:0x%x \n",phy_addr,phy_reg,ind_address,ind_data);

                    ind_data = ind_data | 0x4000;
                    mdio_wr(ind_address,ind_data,MENET,0,0); // Enable 

                    ind_address = ((phy_addr << 8) | phy_reg);
                    ind_data = mdio_rd(ind_address,MENET,0,0);
                    printf("After  phy_addr:0x%x phy_reg:0x%x ind_address:0x%x ind_data:0x%x \n",phy_addr,phy_reg,ind_address,ind_data);
                }
            } // for
            phy_reg++;
        } // while 
#endif

        printf("\nEnter PHY Address (hex): \n");
        phy_addr = get_val();
        printf("\nEnter Reg Address (hex): \n");
        phy_reg = get_val();

        ind_address = ((phy_addr << 8) | phy_reg);

        ind_data = mdio_rd(ind_address,MENET,0,0);
        printf("\nphy_addr:0x%x phy_reg:0x%x ind_address:0x%x ind_data:0x%x \n",phy_addr,phy_reg,ind_address,ind_data);    

    }
#endif
    // for MENENT Port   
    void menet_init_ecc() {
        uint32_t rd_data;
        int i;
        //   printf("\nMENET MEM RAM SHUTDOWN Configuration\n");
        eth_wr(SM_GLBL_DIAG_CSR_CFG_MEM_RAM_SHUTDOWN__ADDR, 0x0,MENET,0,0);
        rd_data = eth_rd(SM_GLBL_DIAG_CSR_CFG_MEM_RAM_SHUTDOWN__ADDR,MENET,0,0);
        //   printf("SM_GLBL_DIAG_CSR_CFG_MEM_RAM_SHUTDOWN = 0x%x\n", rd_data);

        rd_data = eth_rd(SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY__ADDR,MENET,0,0);
        while (rd_data != 0xFFFFFFFF) {
            rd_data = eth_rd(SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY__ADDR,MENET,0,0);
        }
        for (i = 0; i < 5; i++) {
            rd_data = eth_rd(SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY__ADDR,MENET,0,0);
        }
    }

    void menet_clkcfg() {
        int timeout;

        //   printf("MENET SRST & CLKEN Configuration\n");
        eth_wr(SM_MENET_CLKRST_CSR_ENET_CLKEN__ADDR,0x00000000,MENET,0,0); 
        eth_wr(SM_MENET_CLKRST_CSR_ENET_SRST__ADDR ,0xFFFFFFFF,MENET,0,0); 
        for(timeout=0;timeout<8000;timeout++);

        eth_wr(SM_MENET_CLKRST_CSR_ENET_CLKEN__ADDR,0xFFFFFFFF,MENET,0,0); 
        for(timeout=0;timeout<8000;timeout++);

        eth_wr(SM_MENET_CLKRST_CSR_ENET_SRST__ADDR ,0x00000002,MENET,0,0); 
        for(timeout=0;timeout<8000;timeout++);

        eth_wr(SM_MENET_CLKRST_CSR_ENET_SRST__ADDR ,0x00000000,MENET,0,0);

        menet_init_ecc();
    }

    void mgmt_mac_config() {
        int rd_data;

        rd_data = mcxmac_ind_rd(PE_MCXMAC_MAC_CONFIG_1__ADDR, MENET,0, 0);
        //   printf("Before PE_MCXMAC_MAC_CONFIG_1__ADDR:x%x rd_data:0x%x\n",PE_MCXMAC_MAC_CONFIG_1__ADDR, rd_data);

        rd_data = 0x35; // release reset; tx/rx enable; tx/rx flow enable
        mcxmac_ind_wr(PE_MCXMAC_MAC_CONFIG_1__ADDR,rd_data,MENET, 0, 0);

        rd_data = mcxmac_ind_rd(PE_MCXMAC_MAC_CONFIG_1__ADDR, MENET, 0, 0);
        //   printf("After PE_MCXMAC_MAC_CONFIG_1__ADDR:x%x rd_data:0x%x\n",PE_MCXMAC_MAC_CONFIG_1__ADDR, rd_data);
    }

    /*
       SGMII-SATA PHY Address=0x11 to 0x14
       SGMII-XFI  PHY Address=0x15 to 0x16
       */
    u32 mdio_sgmii_phyId_regression_test(int phy_addr, int phy_reg, int count) {

        u32 fail_count=0,tmp;
        int ind_address,ind_data;

        tmp = count;

        printf("\nSGMII Port MDIO PHY_Addr:0x%x PHY-ID Read RegressionTest Started ... TotalIteration:%d\n",phy_addr,tmp);

        ind_address = ((phy_addr << 8) | phy_reg);
        while (count) {
            ind_data = mdio_rd(ind_address,MENET,0,0);
            if(ind_data != 0x141) {
                fail_count++;
                //printf("0x%08x ",ind_data);
            }
            count--;
        }
        if(fail_count)
            printf("MDIO PHY-ID Read RegressionTest for PHY_Addr:0x%x PHY_ID:0x%x Fail, FailCount:%d/%d Iteration\n",phy_addr,ind_data,fail_count, tmp);
        else
            printf("MDIO PHY-ID Read RegressionTest for PHY_Addr:0x%x PHY_ID:0x%x Pass\n",phy_addr,ind_data);
    }

    /*
       RGMII PHY Address=2
       */
    /*
       u32 mdio_rgmii_phyId_regression_test(int phy_addr, int phy_reg, int count) {

       u32 fail_count=0,tmp;
       int ind_address,ind_data;

       tmp = count;

       printf("\nRGMII Port MDIO PHY_Addr:0x%x PHY-ID Read RegressionTest Started ... TotalIteration:%d\n",phy_addr,tmp);

       ind_address = ((phy_addr << 8) | phy_reg);
       while (count) {
       ind_data = mdio_rd(ind_address,MENET,0,0);
       if(ind_data != 0x1c) {
       fail_count++;
    //printf("0x%08x ",ind_data);
    }
    count--;
    }
    if(fail_count)
    printf("MDIO PHY-ID Read RegressionTest for PHY_Addr:0x%x PHY_ID:0x%x Fail, FailCount:%d/%d Iteration\n",phy_addr,ind_data,fail_count, tmp);
    else
    printf("MDIO PHY-ID Read RegressionTest for PHY_Addr:0x%x PHY_ID:0x%x Pass\n",phy_addr,ind_data);
    }
    */

    // Laser Enable for 10Gig Ports HG:
    void sfp_plus_laser_on(int sfpp_port, int display) {
        /*
           I2C-IO Expander U35 pin-map on Blackbird | I2C-IO Expander U36 pin-map on Blackbird
           IO[7] : P0_SFPP_RXLOS     [IN]           | IO[7] : P2_SFPP_RXLOS     [IN]
           IO[6] : P0_SFPP_TXFAULT   [IN]           | IO[6] : P2_SFPP_TXFAULT   [IN]
           IO[5] : P0_SFPP_MODABS    [IN]           | IO[5] : P2_SFPP_MODABS    [IN]
           IO[4] : P0_SFPP_TXDISABLE [OUT]          | IO[4] : P2_SFPP_TXDISABLE [OUT]
           |
           IO[3] : P1_SFPP_RXLOS     [IN]           | IO[3] : P3_SFPP_RXLOS     [IN]
           IO[2] : P1_SFPP_TXFAULT   [IN]           | IO[2] : P3_SFPP_TXFAULT   [IN]
           IO[1] : P1_SFPP_MODABS    [IN]           | IO[1] : P3_SFPP_MODABS    [IN]
           IO[0] : P1_SFPP_TXDISABLE [OUT]          | IO[0] : P3_SFPP_TXDISABLE [OUT]
           ( I2C Address : 0x26 )             |       ( I2C Address : 0x27 )
           */

        u8 buf_sfp[2], m0_status, read_i2c_status_01, read_i2c_status_03;

        i2c_set_bus_num(1);//This is done to make sure that it enables correct I2C Bus in nor_ddr_up mode

        if(display==1)
            printf("\nTurning on SFP+ laser for port P%d ... ",sfpp_port);

        buf_sfp[0] = 0x01; buf_sfp[1] = 0;
        i2c_write(0x71,0x0,0,buf_sfp,1);

        if (sfpp_port == 0) {
            buf_sfp[0] = 0x01; i2c_write(0x26,0x0,0,buf_sfp,1); i2c_read(0x26,0x0,0,buf_sfp,1); read_i2c_status_01 = buf_sfp[0];
            buf_sfp[0] = 0x03; i2c_write(0x26,0x0,0,buf_sfp,1); i2c_read(0x26,0x0,0,buf_sfp,1); read_i2c_status_03 = buf_sfp[0];

            buf_sfp[0] = 0x01; buf_sfp[1] = read_i2c_status_01 & 0xEF; i2c_write(0x26,0x0,0,buf_sfp,2);
            buf_sfp[0] = 0x03; buf_sfp[1] = read_i2c_status_03 & 0xEF; i2c_write(0x26,0x0,0,buf_sfp,2);

            buf_sfp[0] = 0x01; i2c_write(0x26,0x0,0,buf_sfp,1); i2c_read(0x26,0x0,0,buf_sfp,1); m0_status = buf_sfp[0] & 0x10;

            if (m0_status == 0x00) {
                if(display==1)
                    printf("Successful for port P%d !",sfpp_port);
            } else {
                if(display==1)
                    printf("ERROR: SFP+ laser hasn't been turned on for port P%d !!! Please check !\n\r",sfpp_port);
            }
        }

        if (sfpp_port == 1) {
            buf_sfp[0] = 0x01; i2c_write(0x26,0x0,0,buf_sfp,1); i2c_read(0x26,0x0,0,buf_sfp,1); read_i2c_status_01 = buf_sfp[0];
            buf_sfp[0] = 0x03; i2c_write(0x26,0x0,0,buf_sfp,1); i2c_read(0x26,0x0,0,buf_sfp,1); read_i2c_status_03 = buf_sfp[0];

            buf_sfp[0] = 0x01; buf_sfp[1] = read_i2c_status_01 & 0xFE; i2c_write(0x26,0x0,0,buf_sfp,2);
            buf_sfp[0] = 0x03; buf_sfp[1] = read_i2c_status_03 & 0xFE; i2c_write(0x26,0x0,0,buf_sfp,2);

            buf_sfp[0] = 0x01; i2c_write(0x26,0x0,0,buf_sfp,1); i2c_read(0x26,0x0,0,buf_sfp,1); m0_status = buf_sfp[0] & 0x01;

            if (m0_status == 0x00) {
                if(display==1)
                    printf("Successful for port P%d !",sfpp_port);
            } else {
                if(display==1)
                    printf("ERROR: SFP+ laser hasn't been turned on for port P%d !!! Please check !\n\r",sfpp_port);
            }
        }

        if (sfpp_port == 2) {
            buf_sfp[0] = 0x01; i2c_write(0x27,0x0,0,buf_sfp,1); i2c_read(0x27,0x0,0,buf_sfp,1); read_i2c_status_01 = buf_sfp[0];
            buf_sfp[0] = 0x03; i2c_write(0x27,0x0,0,buf_sfp,1); i2c_read(0x27,0x0,0,buf_sfp,1); read_i2c_status_03 = buf_sfp[0];

            buf_sfp[0] = 0x01; buf_sfp[1] = read_i2c_status_01 & 0xEF; i2c_write(0x27,0x0,0,buf_sfp,2);
            buf_sfp[0] = 0x03; buf_sfp[1] = read_i2c_status_03 & 0xEF; i2c_write(0x27,0x0,0,buf_sfp,2);

            buf_sfp[0] = 0x01; i2c_write(0x27,0x0,0,buf_sfp,1); i2c_read(0x27,0x0,0,buf_sfp,1); m0_status = buf_sfp[0] & 0x10;

            if (m0_status == 0x00) {
                if(display==1)
                    printf("Successful for port P%d !",sfpp_port);
            } else {
                if(display==1)
                    printf("ERROR: SFP+ laser hasn't been turned on for port P%d !!! Please check !\n\r",sfpp_port);
            }
        }

        if (sfpp_port == 3) {
            buf_sfp[0] = 0x01; i2c_write(0x27,0x0,0,buf_sfp,1); i2c_read(0x27,0x0,0,buf_sfp,1); read_i2c_status_01 = buf_sfp[0];
            buf_sfp[0] = 0x03; i2c_write(0x27,0x0,0,buf_sfp,1); i2c_read(0x27,0x0,0,buf_sfp,1); read_i2c_status_03 = buf_sfp[0];

            buf_sfp[0] = 0x01; buf_sfp[1] = read_i2c_status_01 & 0xFE; i2c_write(0x27,0x0,0,buf_sfp,2);
            buf_sfp[0] = 0x03; buf_sfp[1] = read_i2c_status_03 & 0xFE; i2c_write(0x27,0x0,0,buf_sfp,2);

            buf_sfp[0] = 0x01; i2c_write(0x27,0x0,0,buf_sfp,1); i2c_read(0x27,0x0,0,buf_sfp,1); m0_status = buf_sfp[0] & 0x01;

            if (m0_status == 0x00) {
                if(display==1)
                    printf("Successful for port P%d !",sfpp_port);
            } else {
                if(display==1)
                    printf("ERROR: SFP+ laser hasn't been turned on for port P%d !!! Please check !\n\r",sfpp_port);
            }
        }

    }//End of sfp_plus_laser_on()
#endif


    //================== flowing function called by init_xgenet() ===================
    //Storm_XGENET_r1.1: section 5, 1: Program XGMII or SGMII mode
    void eth_reg_wr_mode (int addr, int data2, int data1, int data0, int eth_type, int port, int display ) {
        if (mac_mode==2)     eth_wr(addr, data2,eth_type,port,display);
        else if(mac_mode==1) eth_wr(addr, data1,eth_type,port,display);
        else                 eth_wr(addr, data0,eth_type,port,display);
    }

    void mcxmac_ind_wr_mode(int offset, int wr_data2, int wr_data1, int wr_data0, int eth_type, int port, int display){
        if (mac_mode==2)      mcxmac_ind_wr(offset,wr_data2,eth_type, port, display);
        else if(mac_mode==1)  mcxmac_ind_wr(offset,wr_data1,eth_type, port, display);
        else                  mcxmac_ind_wr(offset,wr_data0,eth_type, port, display);
    }

    void clk_reset_cfg_xfi(int port, int display) {
        int read_data;
        // clock and reset; mem shutdown
        eth_wr(SM_XGENET_CLKRST_CSR_XGENET_SRST__ADDR, 0x7,XGENET,port,display);//rst core &csr blk
        //delay(10000);
	//printf("\nclock reset cfg delay 1 ...");
	USDELAY(10000);
        eth_wr(SM_XGENET_CLKRST_CSR_XGENET_CLKEN__ADDR, 0x0,XGENET,port,display);//core blk clk & csr clk enable
        //delay(10000);
	//printf("\nclock reset cfg delay 2 ...");
	USDELAY(10000);

#ifdef CONFIG_XGENET_IF_XGMII
        eth_wr(SM_XGENET_CLKRST_CSR_XGENET_CONFIG_REG__ADDR,0x02,XGENET,port,display); // use AXI clock in CLE//XGMII
        //eth_wr(SM_XGENET_CLKRST_CSR_XGENET_CONFIG_REG__ADDR,0x12,XGENET,port,display); // use sds_xgenet_usrclk in CLE
#else
        eth_wr(SM_XGENET_CLKRST_CSR_XGENET_CONFIG_REG__ADDR,0x01,XGENET,port,display); // use AXI clock in CLE//SGMII
#endif

        eth_wr(SM_XGENET_CLKRST_CSR_XGENET_CLKEN__ADDR, 0x3,XGENET,port,display);//core blk clk & csr clk enable
        eth_wr(SM_XGENET_CLKRST_CSR_XGENET_SRST__ADDR, 0x3,XGENET,port,display);//rst core &csr blk
        eth_wr(SM_XGENET_CLKRST_CSR_XGENET_SRST__ADDR, 0x2,XGENET,port,display);

#ifdef CONFIG_XGENET_IF_XGMII
#ifdef CONFIG_XGENET_XGBASER_TX2RX_LPBK  
        eth_wr(SM_XGENET_XGBASER_PCS_IND_CSR_XGBASER_CONFIG_REG1__ADDR, 0x1,XGENET,port,display); // Tx2Rx loopback after PCS before SerDes
        printf("\n====== CONFIG_XGENET_XGBASER_TX2RX_LPBK!-(Tx2Rx loopback after PCS before SerDes) =======\n");
#elif CONFIG_XGENET_XGBASER_RX2TX_LPBK 
        eth_wr(SM_XGENET_XGBASER_PCS_IND_CSR_XGBASER_CONFIG_REG1__ADDR, 0x2,XGENET,port,display);//Rx2Tx lpbk after PCS before Rx MAC   
        printf("\n====== CONFIG_XGENET_XGBASER_RX2TX_LPBK!-(Rx2Tx loopback after PCS before MAC) ======\n");
#else
        eth_wr(SM_XGENET_XGBASER_PCS_IND_CSR_XGBASER_CONFIG_REG1__ADDR, 0x0,XGENET,port,display);
#endif
#endif


    }

    //Storm_XGENET_r1.1: section 5, 2: Memory initialization
    void xgenet_init_ecc(int port, int display) {
        uint32_t rd_data;
        int i;

        eth_wr(SM_XGENET_CLKRST_CSR_XGENET_SRST__ADDR, 0x0,XGENET,port,display);//release rst
        //delay(400);
	USDELAY(1000);

        eth_wr(SM_GLBL_DIAG_CSR_CFG_MEM_RAM_SHUTDOWN__ADDR, 0x0,XGENET,port,display);
        rd_data = eth_rd(SM_GLBL_DIAG_CSR_CFG_MEM_RAM_SHUTDOWN__ADDR,XGENET,port,display);
        if(display==1)
            printf("SM_GLBL_DIAG_CSR_CFG_MEM_RAM_SHUTDOWN = 0x%x\n", rd_data);

        rd_data = eth_rd(SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY__ADDR,XGENET,port,display);
        while (rd_data != 0xFFFFFFFF) {
            rd_data = eth_rd(SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY__ADDR,XGENET,port,display);
        }

        for (i = 0; i < 5; i++) {
            rd_data = eth_rd(SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY__ADDR,XGENET,port,display);
        }

    }

    //Storm_XGENET_r1.1: section 5, 
    //  3: XGENET_PLL programming
    //  4: Dessert Serdes reset
    //  5: Program Serdes
    //  6: Assert Clock enables
    //  7: Deassert CSR reset
    //  8: Deassert Block reset
    void init_xgenet_serdes(int port, int display) {
        uint32_t rd_data;
        uint32_t infmode;

        rd_data = eth_rd(SM_XGENET_CLKRST_CSR_XGENET_CONFIG_REG__ADDR,XGENET,port,display);
        //last two bit for XGMII or SGMII
        rd_data = FIELD_XGENET_CONFIG_REG_CFG_SGMII_EN_RD(rd_data);

        if (rd_data == 0x2) {
            infmode = 1;//XGMII
            if(display==1)
                printf("XGENET Interface Mode : XFI \n\r");
        } else if (rd_data == 0x1) { infmode = 0; //SGMII
            printf("XGENET Interface Mode : SGMII \n\r");
        } else {} //reseved

        //refclk_cmos_sel = 0; - External differential clk
        //refclk_cmos_sel = 1; - Internal single ended (cmos) clk

        if(INTERNAL_SERDES_TX2RX_LOOPBACK) {
            lprintf(7,"\n\n<Setting Internal Serdes Tx2Rx Loopback>\n\n");
            sm_xgenet_module_init_enet_serdes(infmode, 0, 1,XGENET,port,display);  //serdes lpbk
            //printf("\nSetting XFI 10Gig Port:%d in Internal Clock Mode\n",port);
            //sm_xgenet_module_init_enet_serdes(infmode, 1, 1,XGENET,port,display);  //IntClk Mode

        }
        else {
            lprintf(7,"\n\n<Internal Serdes Tx2Rx Loopback will not be set>\n\n");
            sm_xgenet_module_init_enet_serdes(infmode, 0, 0,XGENET,port,display);
            //printf("\nSetting XFI 10Gig Port:%d in Internal Clock Mode\n",port);
            //sm_xgenet_module_init_enet_serdes(infmode, 1, 0,XGENET,port,display); //IntClk Mode

        }
        //  sm_xgenet_module_init_enet_serdes(infmode, 0, INTERNAL_SERDES_TX2RX_LOOPBACK ,XGENET,port,display);

          //gen_avg_val_xfi(port);
          //gen_avg_val_xfi_17Jul(port);
   	  xgene_phy_gen_avg_val(port); // hardcoding lane to 0

    }

    void init_axgmac(int port, int display) { // md: for 10gig
        // AXGMAC reset
        axgmac_ind_write(AXGMAC_AXGMAC_CONFIG_0__ADDR, 0xe601,port,display);//reset module in Rx & Tx
        axgmac_ind_write(AXGMAC_AXGMAC_CONFIG_0__ADDR, 0x0,port,display);//release reset

        // configure AXGMAC
        axgmac_ind_write(AXGMAC_AXGMAC_CONFIG_1__ADDR, 0xf000008d,port,display);//pad2:64,FCS,len_field,pause
        // jumbo size setting for 10gig; Refer tthe XGENET Reg Spec for more details AXGMAC_MAXFRAME_LENGTH
        axgmac_ind_write(AXGMAC_AXGMAC_MAXFRAME_LENGTH__ADDR, 0x09602580,port,display);//Tx:d'9600,Rx:d'1536
        // jumbo size
    }

    void init_mcxmac(int eth_type, int port, int display) {
        int read_data;

        // eth_reg_wr_mode(SM_XGENET_MCXMAC_CSR_ICM_CONFIG0_REG_0__ADDR,0x0008503f,0x0004503f,0x0000503f,eth_type,port,display);  //ICM_CONFIG0_REG_0 -- MacMode[12:13]:0=10M,1=100M,2=1G
        // eth_reg_wr_mode(SM_XGENET_MCXMAC_CSR_ICM_CONFIG2_REG_0__ADDR,0x0001000f,0x00010050,0x000101f4,eth_type,port,display);  // ICM_Config2_reg_0 -Async read  //AXI freq  => 100MHz

        mcxmac_ind_wr(     PE_MCXMAC_MAC_CONFIG_1__ADDR,     0x00000035                      ,eth_type,port,display);// mac tx from sys,Rx from phy,pasue
        // mcxmac_ind_wr_mode(PE_MCXMAC_MAC_CONFIG_2__ADDR,     0x00005211,0x00006111,0x00007111,eth_type,port,display);//FD,frm_len,mac)inf:nible vs byte
        // mcxmac_ind_wr_mode(PE_MCXMAC_INTERFACE_CONTROL__ADDR,0x04000000,0x02000000,0x00000000,eth_type,port,display); // MAC mode - 1g,100m,10m

        // md: for Jumbo packet size
        mcxmac_ind_wr(PE_MCXMAC_MAC_CONFIG_2__ADDR, 0x00005235,eth_type,port,display);
        mcxmac_ind_wr(PE_MCXMAC_MAX_FRAME_LEN__ADDR,0x00002580,eth_type,port,display);
        // for Jumbo packet size
    }

    void bypass_resume_cfg(int port, int display) {
        eth_wr(SM_XGENET_CSR_CFG_BYPASS__ADDR, 0x1,XGENET,port,display);//can trsn independent link up 0x2204
#ifdef CONFIG_XGENET_IF_XGMII
        eth_wr(SM_XGENET_CSR_CFG_LINK_STS__ADDR, 0x0,XGENET,port,display); // XGMII 0x2210
        eth_wr(SM_XGENET_AXGMAC_CSR_XGENET_RX_DV_GATE_REG_0__ADDR, 0x0,XGENET,port,display);//link speed, gate
#else
        eth_wr(SM_XGENET_CSR_CFG_LINK_STS__ADDR, 0x1,XGENET,port,display); // SGMII
        eth_wr(SM_XGENET_MCXMAC_CSR_RX_DV_GATE_REG_0__ADDR, 0x0,XGENET,port,display);
#endif

        eth_wr(SM_XGENET_CSR_CFG_LINK_AGGR_RESUME_0__ADDR, 0x1,XGENET,port,display);//traffic resume on port0
        eth_wr(SM_XGENET_CSR_ENET_SPARE_CFG_REG__ADDR, 0x22407040,XGENET,port,display);

    }

    void loopback_cfg(int port, int display) {
        int read_data;

#ifdef CONFIG_XGENET_RX2TSO_TX_LPBK 
        eth_wr(SM_XGENET_CSR_DEBUG_REG__ADDR, 0x003e03fe,XGENET,port,display);
        printf("\n====== CONFIG_XGENET_RX2TSO_LPBK ========\n");
#else
#ifdef CONFIG_XGENET_QM_RX2TX_LPBK 
        eth_wr(SM_XGENET_CSR_DEBUG_REG__ADDR, 0x003e03ee,XGENET,port,display);//QM Loopback
        printf("\n====== CONFIG_XGENET_QN_RX2TX_LPBK ======\n");
#endif  
#endif
        read_data = eth_rd(SM_XGENET_CSR_DEBUG_REG__ADDR,XGENET,port,display);
        printf("LOOPBACK REG read back"); printf(" is 0x");  putnum(read_data);  printf("\n\r");
    }

    void cle_bypass_mode_cfg (int port, int display) {

        u32 read_data; 
#if 0 // md: QM-Level-lpbk-test
        printf("\r\nQM Level Loopback Test\r\n");
        if(port == 0) {    
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
            printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110020,XGENET,port,display);
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110020,XGENET,port,display);

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data); 

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data); 

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
            eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
            // cfg to enable capture of Rx cntrl wd's
            eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
        }
        else if(port == 1) {    
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
            printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110021,XGENET,port,display);
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110021,XGENET,port,display);

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data); 

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data); 
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
            eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
            // cfg to enable capture of Rx cntrl wd's
            eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
        }
        else if(port == 2) {    
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1
            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
            printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110820,XGENET,port,display);
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110820,XGENET,port,display);

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data); 

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data); 

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
            eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
            // cfg to enable capture of Rx cntrl wd's
            eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
        }
        else if(port == 3) {    
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
            printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110821,XGENET,port,display);
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110821,XGENET,port,display);

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data); 

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data); 

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
            eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
            eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
        }
#endif // QM-Level-Lpbk-test

#if  0 // md: CPU-Level-lpbk-test
        printf("\r\n++++++++++++ CPU Level Loopback Test +++++++++++++\r\n");
        if(port == 0) {    
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
            printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110040,XGENET,port,display);
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110040,XGENET,port,display);

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data);
            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data);

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
            eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
            // cfg to enable capture of Rx cntrl wd's
            eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
        }
        else if(port == 1) {    
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
            printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110041,XGENET,port,display);
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110041,XGENET,port,display);

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data);
            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data);

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
            eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
            // cfg to enable capture of Rx cntrl wd's
            eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
        }
        else if(port == 2) {    
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
            printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110840,XGENET,port,display);
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110840,XGENET,port,display);

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data);
            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data);

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
            eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
            // cfg to enable capture of Rx cntrl wd's
            eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
        }
        else if(port == 3) {    
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
            printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110841,XGENET,port,display);
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110841,XGENET,port,display);

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data);
            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data);

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
            eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
            // cfg to enable capture of Rx cntrl wd's
            eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
        }
#endif // CPU-level-lpbk-test   

#if 0 // md: Snake-test
        printf("\r\nSNAKE Test\r\n");
        if(port == 0) {    
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
            printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110021,XGENET,port,display);
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110021,XGENET,port,display);

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data); 

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data); 

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
            eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
            // cfg to enable capture of Rx cntrl wd's
            eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
        }
        else if(port == 1) {    
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
            printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110020,XGENET,port,display);
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110020,XGENET,port,display);

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data); 

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data); 
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
            eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
            // cfg to enable capture of Rx cntrl wd's
            eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
        }
        else if(port == 2) {    
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1
            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
            printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110821,XGENET,port,display);
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110821,XGENET,port,display);

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data); 

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data); 

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
            eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
            // cfg to enable capture of Rx cntrl wd's
            eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
        }
        else if(port == 3) {    
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
            printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110820,XGENET,port,display);
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110820,XGENET,port,display);

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data); 

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data); 

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
            eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
            eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
        }
#endif // snake test



    }
    /*
       void diagmod_cfg (int port, int display) {
       eth_wr(SM_GLBL_DIAG_CSR_CFG_DIAG_SEL__ADDR,0x000008D2,XGENET,port,display); // CFG_DIAG_SEL For bringing rx_dv at the i/p of mac on the dbg bus
       eth_wr(SM_GLBL_DIAG_CSR_CFG_DIAG_SEL__ADDR,0x00000902,XGENET,port,display); // CFG_DIAG_SEL For bringing dbg_rfn0 of pemcxmac 
       eth_wr(SM_GLBL_DIAG_CSR_CFG_DIAG_SEL__ADDR,0x000008da,XGENET,port,display); // CFG_DIAG_SEL For bringing icm_idh of pemcxmac 
       eth_wr(SM_GLBL_DIAG_CSR_CFG_DIAG_SEL__ADDR,0x000008df,XGENET,port,display); // CFG_DIAG_SEL For bringing infoctrl of pemcxmac 
       }
       */

    /*
       void init_xgenet_plc() {
       enet_plc_wr(0x0,0xFFFF,0xFFFF,0x0,0x0); // Full bandwidth
       eth_wr(SM_XGENET_CSR_RSIF_POLICER_REG7__ADDR,0xF2000F0F,XGENET,port,display); // Policer Enable - Dualbucket[31]
       eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG3__ADDR, 0x20000000,XGENET,port,display); // Policer
#ifdef XGENET_CLE_ENABLE
eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG3__ADDR, 0x20000000,XGENET,port,display); // Policer
#endif   
}
*/

void xgbaser_pcs_cfg (int port, int display) { // md: for 10 gig mode
    int read_data;

    read_data = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_CONTROL_1__ADDR,port,display);
}

//============================= all the initialization =====================
void init_xgenet(int port, int display) {
    int lpbk_dat;
    int read_data;
    int loop = 50;
    int link, an_done = 0;
    int poll_done = 0;
    int timeout;
    if(display==1)
        printf("Select Port\n\r");

    // printf("Memset is started CHANGE ACCORDING TO DIMM FIXME\n");
    //memset((420000000),0,0xc000000);
    //printf("Memset is DONE\n");

    clk_reset_cfg_xfi(port, display);
    init_xgenet_serdes(port, display);
    xgenet_init_ecc(   port, display);

#ifdef CONFIG_XGENET_IF_XGMII 
    if(display==1)
        printf("\r\n------- Configuring XGENET_XFI (10 Gig XFI) I/F Mode --------\r\n");
    init_axgmac(port,display);
    xgbaser_pcs_cfg(port, display);

    // Added by HG: Turn On SFP+ Lasers ...
    /*//Shifted to main eth_rx2tx code
      int sfpp_port_no;
      for (sfpp_port_no = 0; sfpp_port_no <= 3; sfpp_port_no++) 
      sfp_plus_laser_on(sfpp_port_no); 
      USDELAY(100); //To allow some time after SFP+ Lasers are turned on
    // Added by HG:
    */
#else
    init_mcxmac(XGENET,port,display);

    mdio_wr(0x1e11,0     ,XGENET,port,display); // Deassert Reset
#ifdef STORM_A2 
    configure_sgmii_xg(port,0x0, 1);
#else
    configure_sgmii_xg(port,0x0, reconfig_loop);
#endif

#endif

    bypass_resume_cfg(port,display);
    //loopback_cfg(port,display);//Commented by Hrishikesh. Loopback will be configured henceforth per-test basis.

#ifndef XGENET_CLE_ENABLE
    cle_bypass_mode_cfg(port,display);
#else
    cfg_cle();
#endif  

    //diagmod_cfg (port,display);
    //init_xgenet_plc();

    // miscellaneous
#ifdef CONFIG_XGENET_IF_XGMII
    eth_wr(SM_XGENET_AXGMAC_CSR_XGENET_RX_DV_GATE_REG_0__ADDR, 0x0,XGENET,port,display);//Rx/Tx no traffic be gated off
#else
    eth_wr(SM_XGENET_MCXMAC_CSR_RX_DV_GATE_REG_0__ADDR, 0x0,XGENET,port,display);//Rx/Tx no traffic be gated off 
#endif

    // loopback all error packets
    eth_wr(SM_XGENET_CSR_RSIF_LERR_MASK__ADDR, 0x0,XGENET,port,display);
    // cfg to enable capture of Rx cntrl wd's
    eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x21010000,XGENET,port,display);

    //#ifdef CONFIG_SDS_SERDES_RX_CLK_INV //???
    //eth_wr(SM_XGENET_CSR_ENET_SPARE_CFG_REG_1, 0x8,XGENET,port,display); // invert Rx clock from serdes
    //#endif
}

void read_common_statistics(int port){
    int i,j;
    int display =1;
    printf("\nMACOUT reg ");
    eth_rd(SM_XGENET_CSR_MACOUT_ENET_STAT_REG__ADDR,XGENET,port,display);//0x2444: byte_cnt, pht_cnt
    printf("\nMACIN reg ");
    eth_rd(SM_XGENET_CSR_MACIN_ENET_STAT_REG__ADDR,XGENET,port,display);//0x2440: byte_cnt, pkt_cnt
    printf("\nRXBIN reg ");
    eth_rd(SM_XGENET_CSR_RXBIN_ENET_STAT_REG__ADDR,XGENET,port,display);//0x2448: byt_cnt, pkt_cnt
    printf("\nRSIF CNTR reg ");
    eth_rd(SM_XGENET_CSR_RSIF_STS_CNTR_REG0__ADDR,XGENET,port,display);//0x212c: mirror_pkt_cnt, pkt_cnt
    printf("\nRX_TX_BUF_STS reg ");
    eth_rd(SM_XGENET_CSR_RX_TX_BUF_STS_REG0__ADDR,XGENET,port,display);//0x2360: Tx, Rx buf_empty
    printf("\nRSIF FIFO STS reg ");
    eth_rd(SM_XGENET_CSR_RSIF_FIFO_EMPTYSTS0__ADDR,XGENET,port,display);//0x2104: Rx all fifo_empty stat
    printf("\nTSIF FIFO STS reg ");
    eth_rd(SM_XGENET_CSR_TSIF_FIFO_EMPTYSTS0__ADDR,XGENET,port,display);//0x22c0: Tx all fiof_empty stat
    printf("\nTSIF STS reg0 "); 
    eth_rd(SM_XGENET_CSR_TSIF_STS_REG0__ADDR,XGENET,port,display);//0x22c4: no of valid wk msg processed by tsif
    printf("\nTSIF STS reg1 ");
    eth_rd(SM_XGENET_CSR_TSIF_STS_REG1__ADDR,XGENET,port,display);//0x22c8: no of valid wk msg processed by tsif
    printf("\nTSIF STS reg2 ");
    eth_rd(SM_XGENET_CSR_TSIF_STS_REG2__ADDR,XGENET,port,display);//0x22d0: no of valid wk msg processed by tsif
    printf("\nTSIF STS reg3 ");
    eth_rd(SM_XGENET_CSR_TSIF_STS_REG3__ADDR,XGENET,port,display);//0x22d4: no of valid wk msg processed by tsif

    printf("\nCFG_LINK_STS reg ");
    eth_rd(SM_XGENET_CSR_CFG_LINK_STS__ADDR,XGENET,port,display);//0x2210 link stat
    printf("\nLINK AGGR RESUMEreg ");
    eth_rd(SM_XGENET_CSR_CFG_LINK_AGGR_RESUME_0__ADDR,XGENET,port,display);//0x2214:Tx_port:1=traffic can resume on port0
    printf("\nLINK AGGR ");
    eth_rd(SM_XGENET_CSR_CFG_LINK_AGGR__ADDR,XGENET,port,display);//0x2200: arb_sel, link_ggr_feature_en, revert traffic
    printf("\nLINK STATUS ");
    eth_rd(SM_XGENET_CSR_LINK_STATUS__ADDR,XGENET,port,display);//2228 link stat
    printf("\nCLKEN ");
    eth_rd(SM_XGENET_CLKRST_CSR_XGENET_CLKEN__ADDR,XGENET,port,display);//0xc008: xgenet_clken, csr_clken
    printf("\nSRST ");
    eth_rd(SM_XGENET_CLKRST_CSR_XGENET_SRST__ADDR,XGENET,port,display);//0xc000: xgenet_sds_rst, xgenet_rst, csr_rst
    printf("\nCFG_BYPASS ");
    eth_rd(SM_XGENET_CSR_CFG_BYPASS__ADDR,XGENET,port,display);//0x2204: resume_tx
    printf("\nTXB STAT ");
    eth_rd(SM_XGENET_CSR_TXB_ENET_STAT_REG__ADDR,XGENET,port,display);//0x243c: byte_cnt, pkt_cnt

    printf("\n\n =====QM AXI BW monitor======");
    qm_reg_rd(SM_GLBL_DIAG_CSR_STS_AXI_MRD_BW_CLK_CNT__ADDR);//0xd024
    qm_reg_rd(SM_GLBL_DIAG_CSR_STS_AXI_MRD_BW_BYTE_CNT__ADDR);//0xd028
    qm_reg_rd(SM_GLBL_DIAG_CSR_STS_AXI_MWR_BW_CLK_CNT__ADDR);//0xd02c
    qm_reg_rd(SM_GLBL_DIAG_CSR_STS_AXI_MWR_BW_BYTE_CNT__ADDR);//0xd030
    qm_reg_rd(SM_GLBL_DIAG_CSR_STS_AXI_SRD_BW_CLK_CNT__ADDR);//0xd034
    qm_reg_rd(SM_GLBL_DIAG_CSR_STS_AXI_SRD_BW_BYTE_CNT__ADDR);//0xd038
    qm_reg_rd(SM_GLBL_DIAG_CSR_STS_AXI_SWR_BW_CLK_CNT__ADDR);//0xd03c
    qm_reg_rd(SM_GLBL_DIAG_CSR_STS_AXI_SWR_BW_BYTE_CNT__ADDR);//0xd040
}

void read_common_statistics_port() {
  int port;
  printf("\nEnter XGE port no. : "); if(terminal_server_serial_port==1) port = get_val(); port = get_val();
  read_common_statistics(port);
} 

void read_statistics_axgmac(int port){
    int read_data;
    int i,j;
    int counter = 0;
    int display = 0;
    read_common_statistics(port);

    printf("\nAXGMAC FIFO STS reg ");
    eth_rd(SM_XGENET_AXGMAC_CSR_XGENET_ICM_ECM_FIFO_STS_0__ADDR,XGENET,port,display);//0x2920: ecm, icm fifo_empty
    printf("\nAXGMAC RX DV GATE reg ");
    eth_rd(SM_XGENET_AXGMAC_CSR_XGENET_RX_DV_GATE_REG_0__ADDR,XGENET,port,display);//0x2804, tx, rc dv_gate_en, resume_rx

    i = 0;
    printf("AXGMAC Pemstats 0\n\r");
    for (j=0; j<48; j++)
    {
        i = i + 1;
        eth_wr( SM_XGENET_AXGMACIP_IND_CSR_STAT_IND_ADDR_0__ADDR, 0x00000020 + j,XGENET,port,display);
        eth_wr(SM_XGENET_AXGMACIP_IND_CSR_STAT_IND_COMMAND_0__ADDR,0x40000000,XGENET,port,display); 
        do {
            read_data = eth_rd(SM_XGENET_AXGMACIP_IND_CSR_STAT_IND_COMMAND_DONE_0__ADDR,XGENET,port,display);
            counter++;
        } while (read_data != 0x00000001 && counter != MAX_INDCMD_DONE_COUNTER);

        if(read_data != 0x1) { printf("ERROR : XGENET_INDIRECT AXGMAC WR timeout");printf("\n\r"); }

        eth_wr(SM_XGENET_AXGMACIP_IND_CSR_STAT_IND_COMMAND_0__ADDR, 0x0,XGENET,port,display);
        read_data = eth_rd(SM_XGENET_AXGMACIP_IND_CSR_STAT_IND_RDATA_0__ADDR,XGENET,port,display);
        printf("0x");putnum(0x00000020 + j);printf(" = 0x");putnum(read_data);printf(" \t");

        if(i==4)
        {
            i = 0;
            printf("\n\r");
        }
    }
}

void read_statistics_axgmac_port() {
  int port;
  printf("\nEnter XGE port no. : "); if(terminal_server_serial_port==1) port = get_val(); port = get_val();
  read_statistics_axgmac(port);
} 

void read_statistics_mcxmac(int port){
    int read_data;
    int i,j;
    int counter = 0;
    int display = 1;
    read_common_statistics(port);

    printf("MCXMAC FIFO STS reg ");
    eth_rd(SM_XGENET_MCXMAC_CSR_ICM_ECM_FIFO_STS_0__ADDR,XGENET,port,display);
    printf("MCXMAC RX DV GATE reg ");
    eth_rd(SM_XGENET_MCXMAC_CSR_RX_DV_GATE_REG_0__ADDR,XGENET,port,display);

    i = 0; display=0;
    printf("MCXMAC Pemstats 0\n\r");
    for (j=0; j<48; j++) {
        i = i + 1;
        eth_wr(SM_XGENET_MCXMACIP_IND_CSR_STAT_IND_ADDR_0__ADDR, 0x00000020 + j,XGENET,port,display);
        eth_wr(SM_XGENET_MCXMACIP_IND_CSR_STAT_IND_COMMAND_0__ADDR, 0x40000000,XGENET,port,display);
        do {
            read_data = eth_rd(SM_XGENET_MCXMACIP_IND_CSR_STAT_IND_COMMAND_DONE_0__ADDR,XGENET,port,display);
            counter++;
        } while (read_data != 0x00000001 && counter != MAX_INDCMD_DONE_COUNTER);

        if(read_data != 0x1) { printf("ERROR : XGENET_INDIRECT AXGMAC WR timeout");printf("\n\r"); }

        eth_wr(SM_XGENET_MCXMACIP_IND_CSR_STAT_IND_COMMAND_0__ADDR, 0x0,XGENET,port,display);
        read_data = eth_rd(SM_XGENET_MCXMACIP_IND_CSR_STAT_IND_RDATA_0__ADDR,XGENET,port,display); 
        printf("0x");putnum(0x00000020 + j);printf(" = 0x");putnum(read_data);printf(" \t");

        if(i==4) {
            i = 0;
            printf("\n\r");
        }   
    }
}   
/////////*********MAIN CODE*************/////////

int eth_tx2rx_10g() {
    int val = 0;
    int quit_r;
    int ind_address, ind_data;
    int port = 0; 
    int phy_addr=0,phy_reg=0; 
    int retval=0;

#if 1 //XFI-SGMII 

    //Printing of Header
    printf_test_suite_header();

    //printing Test Menu
    printf("\n\n\t-- Test Menu --\n");					//Not required for SLT Test
    printf("\t_______________\n");					//Not required for SLT Test	
    printf("\n 0x34 (0d52) External tx2rx Self level   Loopback Test - 4 ports");	//Not required for SLT Test
    printf("\n 0x35 (0d53) External tx2rx Port-to-port Loopback Test - 4 ports");	//Not required for SLT Test
    printf("\n 0x36 (0d54) External tx2rx Port-to-port Loopback Test - 4 ports [With Enhancements]");
    printf("\n");
    printf("\n 0x40 (0d64) Vary Serdes Params in Test No. 0x36 (0d54)");
    

    int test_num;
    printf("\n\nSelect Test no. from the above Menu : 0x");  if(terminal_server_serial_port==1) test_num = get_val(); test_num = get_val();
    //test_num = 0x34; //printf("\n");//Temp only -- DELETE LATER --
    //test_num = 0x35; printf("\n");//Temp only -- DELETE LATER --
    if(terminal_server_serial_port==0) printf("\n"); // If minicom is used, then put additional new-line
    printf("(You entered Test No. %d)\n",test_num);//This is displayed just to confirm

    init_and_configure_xfi_ports();

    //SFP+ Laser Enable 
    sfp_laser_enable_top_level_function();

    //gen_avg_val
    //gen_avg_val_top_level();

    //Check link status on all 4 XFI ports ...
#if 0	// -- ORIGINAL CODE --
    printf("\n");
    int read_link_status_reg , port_link;
    for(port_link=0;port_link<=3;port_link++) {
        read_link_status_reg = eth_rd(SM_XGENET_CSR_LINK_STATUS__ADDR , XGENET , port_link , 0);
	read_link_status_reg = read_link_status_reg & 0x1;
	if(read_link_status_reg == 0) { printf("\nLink down on XGE-%d",port_link); test_num = 0x100;}
    }
#endif	// -- ORIGINAL CODE --
#if 1	// -- NEW      CODE --
    printf("\n");
    int read_link_status_reg , port_link;
    for(port_link=0;port_link<=3;port_link++) {
        read_link_status_reg = eth_rd(SM_XGENET_CSR_LINK_STATUS__ADDR , XGENET , port_link , 0);
	read_link_status_reg = read_link_status_reg & 0x1;
	if(read_link_status_reg == 0)  reset_pcs(port_link);//If link is down, do PCS Reset once ...
    }

    // Re-check link on all 4 ports again ...
    for(port_link=0;port_link<=3;port_link++) {
        read_link_status_reg = eth_rd(SM_XGENET_CSR_LINK_STATUS__ADDR , XGENET , port_link , 0);
	read_link_status_reg = read_link_status_reg & 0x1;
	if(read_link_status_reg == 0) {
		printf("\nLink down on XGE-%d",port_link); 
		if(port_link==0 || port_link==1) {
			printf("\tTraffic test will not be run if Link is found Down on XGE-0 or XGE-1");
			test_num = 0x100;
		}
	}
    }
#endif	// -- NEW      CODE --


    //Calling required test routine
    int err_flag=0;
    if(test_num == 0x34)  { 
	err_flag = cable_connect_check(0x34); 
	if(err_flag == 0) { external_tx2rx_loopback_test_4_ports(); total_err_count_result_xfi(); }
    }

    if(test_num == 0x35)  { 
	if(INTERNAL_SERDES_TX2RX_LOOPBACK==0) {// If External Loopback is used, then only proceed ...
		err_flag = cable_connect_check(0x35);
		if(err_flag == 0) { external_tx2rx_p2p_loopback_test_4_ports(); total_err_count_result_xfi();  }
	}
	else { // If Internal serdes loopback is used, then this test can not be run
		printf("\n\nInternal loopback is set per port, so port-to-port loopback test CAN NOT run");
		printf("\nPlease set appropriate loopback and re-run the suitable test case\n");
	}
    }

    if(test_num == 0x36)  {
        if(INTERNAL_SERDES_TX2RX_LOOPBACK==0) {// If External Loopback is used, then only proceed ...
                err_flag = cable_connect_check(0x36);
                if(err_flag == 0) { 
			//retval=0;
			retval = external_tx2rx_p2p_new_loopback_test_4_ports(); 
			//if(retval==0) 
			xfi_stat_check();//This will check mac stats and increase error counter
			total_err_count_result_xfi();  
		}
		else {
			test_num=0x101;
		}
        }
        else { // If Internal serdes loopback is used, then this test can not be run
                printf("\n\nInternal loopback is set per port, so port-to-port loopback test CAN NOT run");
                printf("\nPlease set appropriate loopback and re-run the suitable test case\n");
        }
    }

    if(test_num == 0x40)  {
//This section added on top of Test No. 0x36, rest all the same [Start]
	int rxtx_reg1_change , rxtx_reg125_change;
	printf("\nDo you wish to change CTLE_EQ by programming RXTX_REG1? (0:No, 1:Yes) : ");
	if(terminal_server_serial_port==1) rxtx_reg1_change=get_val(); rxtx_reg1_change=get_val();
	if(rxtx_reg1_change==1) 
		program_rxtx_reg1();	//This allows to change CTLE_EQ value as required
	else {
		printf("\nYou opted for not to change RXTX_REG1, so displaying current values ...");
		read_rxtx_reg1();
	}
	printf("\n\nDo you wish to change PQ_REG by programming RXTX_REG125? (0:No, 1:Yes) : ");
	if(terminal_server_serial_port==1) rxtx_reg125_change=get_val(); rxtx_reg125_change=get_val();
	if(rxtx_reg125_change==1) 
		program_rxtx_reg125();	//This allows to change pq_reg value as required
	else {
		printf("\nYou opted for not to change RXTX_REG125, so displaying current values ...");
		read_rxtx_reg125();
	}
//This section added on top of Test No. 0x36, rest all the same [End]

        if(INTERNAL_SERDES_TX2RX_LOOPBACK==0) {// If External Loopback is used, then only proceed ...
                err_flag = cable_connect_check(0x36);//Test No 0x40 is same as 0x36
                if(err_flag == 0) { 
			//retval=0;
			retval = external_tx2rx_p2p_new_loopback_test_4_ports(); 
			//if(retval==0) 
			xfi_stat_check();//This will check mac stats and increase error counter
			total_err_count_result_xfi();  
		}
		else {
			test_num=0x101;
		}
        }
        else { // If Internal serdes loopback is used, then this test can not be run
                printf("\n\nInternal loopback is set per port, so port-to-port loopback test CAN NOT run");
                printf("\nPlease set appropriate loopback and re-run the suitable test case\n");
        }
    }


    if(test_num == 0x100) 
	no_test_dueto_link_error();

    if(test_num == 0x101) 
	cable_issue();

    //if(test_num < 0x32 || test_num > 0x36) printf("\n\nInvalid Test No. entered ...");

    //printf("\n\n(Note : Issue a power cycle if you wish to repeat the test or run another test)\n\n"); //Not required for SLT Test

	//USDELAY(1000000);//1-Sec

    //if(test_num != 0x100) total_err_count_result_xfi();	

#if 0 //md:
    menet_clkcfg();
    mgmt_mac_config();
#endif

#if 0  //md: QM-level-lpbk-test & CPU-level-lpbk-test
    unsigned int reg,tmp;

    // QMI configuration for Port-2/3
    printf("\r\nQMI configuration for Port-2 & Port-3\r\n");
    printf("Before write\r\n");
    reg = 0x1f7190dc;       
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7190e0;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7190f0;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7190f4;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);

    reg = 0x1f7290dc;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7290e0;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7290f0;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7290f4;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);

    // Port-2
    //write((unsigned int *)(0x1f7190dc), 0xffffffff); // CfgSsQmiFPQAssoc 
    //write((unsigned int *)(0x1f7190e0), 0xffffffff); // CfgSsQmiWQQAssoc 
    write((unsigned int *)(0x1f7190f0), 0xffffffff); // CfgSsQmiQMLiteFPQAssoc 
    write((unsigned int *)(0x1f7190f4), 0xffffffff); // CfgSsQmiQMLiteWQAssoc 

    // Port-3
    //write((unsigned int *)(0x1f7290dc), 0xffffffff); // CfgSsQmiFPQAssoc 
    //write((unsigned int *)(0x1f7290e0), 0xffffffff); // CfgSsQmiWQAssoc 
    write((unsigned int *)(0x1f7290f0), 0xffffffff); // CfgSsQmiQMLitePFQAssoc
    write((unsigned int *)(0x1f7290f4), 0xffffffff); // CfgSsQmiQMLiteWQAssoc

    printf("\r\nAftre write\r\n");
    reg = 0x1f7190dc;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7190e0;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7190f0;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7190f4;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);

    reg = 0x1f7290dc;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7290e0;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7290f0;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7290f4;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);

    /*
       qm_ocm_n(qm_enable,qm_ip);
       qm_enable => QM_QM0=1, QM_QM1=2, QM_QM2=4
       qm_ip => QM_ETH=0, QM_PDMA=1, QM_CTX=2, QM_SEC=3, QM_CLE0=4 QM_COP=5, QM_SLIMPRO=6
       */
#if 1    //md:
    printf("\nQM-0/1/2 Init\r\n");
    qm_n((QM_QM0 | QM_QM1 | QM_QM2), QM_ETH);
    //qm_n_dump((QM_QM0 | QM_QM1 | QM_QM2), QM_ETH);
#endif

#if 0 // md: CPU-level-lpbk-test
    /*
       qm_uc_fwder(u32 rpt, u32 batch, fwd_uc_tbl_t *p_uc);
       rpt   -> repeat counter for scanning the input queues
       batch -> batch counter for each input queue
       p_uc -> pointer to the unicast forwarding table

Application: 
This is GE Port CPU level self loopback
GE0_Rx -> GE0_Tx 
GE1_Rx -> GE1_Tx
GE2_Rx -> GE2_Tx
GE3_Rx -> GE3_Tx

fwd_uc_tbl_t fwd_xge1_tbl
*/
    fwd_ctrl_t fc;
    unsigned int i;
    fc.rpt = 1;
    fc.batch = 1;
    fc.chk_errq = 0;
    printf("\r\nCPU level loopback, polling for qm_uc_fwder()\r\n");
    i = 0;
    while(1)
    {
        qm_uc_fwder(&fc, &fwd_xge1_tbl);


        //enqueue related call, no need to do this.
        if ((i & 0xffff) == 0)
        {
            //qm_uc_fwder(&fc, &fwd_xge1_tbl);
            //qm_dump_pb_state(2, 0, 0);
            //qm_dump_pb_state(2, 0, 0x21);
#if 0
            read_statistics_axgmac(0);// Function Call to print all the Statistics
            printf("QM0:\n");
            qm_dump_qstate(0, 4, 32);
            qm_dump_qstate(0, 1, 1);
            printf("QM2:\n");
            qm_dump_qstate(2, 4, 32);
            qm_dump_qstate(2, 1, 1);
#endif
        }
        i++;
    }
#endif // CPU-level-lpbk-test & CPU-level-lpbk-test

#endif // QM-level-lpbk-test and CPU-level-lpbk-test

    write((unsigned int *)(0x17001398), 0x001e1e1e); //MDIO enable config
#ifndef STORM_A2
    //fix_crc_xg();
#endif
    if(advanced_debug_xg) {
        do
        {
            printf("\n\r99. Configure Port\n\r");
            printf("\n\r1. Read Register\n\r");
            printf("\n\r2. Write Register\n\r");
            printf("\n\r3. Read AXGMAC port stats\n\r");
            printf("\n\r4. AXGMAC Indirect Read  \n\r");
            printf("\n\r5. AXGMAC Indirect Write \n\r");
            printf("\n\r6. 10GBaseR Indirect Read  \n\r");
            printf("\n\r7. 10GBaseR Indirect Write \n\r");
            printf("\n\r8. MDIO Read  \n\r");
            printf("\n\r9. MDIO Write \n\r");
            printf("\n\r10. SerDes Read \n\r");
            printf("\n\r11. SerDes Write \n\r");
            printf("\n\r13. Read MCXMAC port stats\n\r");
            printf("\n\r16. Reautoneg SGMII\n\r");
            printf("\n\r17. SerDes analog reset only\n\r");
            printf("30. TEST Profile  \n\r");
            printf("31. QM Dump PB state\n\r");
            printf("37. Send AXGMAC SW pause frame and force RX OSET to idles  \n\r");
            printf("38. Send AXGMAC SW pause frame  \n\r");
            printf("40. Send MCXMAC SW pause frame  \n\r");
            printf("\n\rq. to quit.. \n\r");

            val = get_val();
            quit_r = val + 0x57;

            // command interpretation
            if (val == 0x01) // read command 
            {
                printf("\n\rread address (hex)=?\n\r");
                ind_address = get_val();
                printf("\n\rread address entered = 0x%x \n\r", val);
                ind_data = read(ind_address);
                printf("\n\rread data = 0x");putnum(ind_data);printf(" from address = 0x");putnum(ind_address);printf("\n\r");
            } 

            else if (val == 0x02)    // Write command
            {
                printf("\n\rwrite address (hex)=?\n\r");      
                ind_address  = get_val();
                printf("\n\rwrite address entered = 0x%x \n\r", ind_address);
                printf("\n\rwrite data=?\n\r");
                ind_data = get_val();
                printf("\n\rwrite data entered = 0x%x\n\r", ind_data);
                write(ind_address,ind_data);
                printf("\n\rwritten data = 0x");putnum(ind_data);printf(" at address = 0x");putnum(ind_address);printf("\n\r");  
            } 

            else if (val == 0x03)    //Read AXGMAC port stats
            {
#ifdef CONFIG_XGENET_IF_XGMII
                //read_statistics_axgmac(0);// Function Call to print all the Statistics
                read_statistics_axgmac(0);
                read_statistics_axgmac(1);
                read_statistics_axgmac(2);
                read_statistics_axgmac(3);

#else
                printf("Select port to print Statistics : ");
                read_statistics_mcxmac(get_val());
#endif
            } 

            else if (val == 0x04)    //axgmac ind rd command
            { int port =0;

                printf("\n\rRead address (hex)=?\n\r");
                ind_address = get_val();
#ifdef CONFIG_XGENET_IF_XGMII
                ind_data = axgmac_ind_read(ind_address);
#else
                printf("Select port to print Statistics : ");
                ind_data = mcxmac_ind_rd(ind_address, XGENET,get_val(),1);
#endif
                printf("\n\rdata read is = 0x");putnum(ind_data);printf("\n\r");
            } 

            else if (val == 0x05)    //axgmac ind wr command
            {
                printf("\n\renter write address \n\r");
                ind_address = get_val();
                printf("\n\r enter write data=?\n\r");
                ind_data = get_val();
                printf("\n\rwriting....\n\r");
#ifdef CONFIG_XGENET_IF_XGMII
                axgmac_ind_write(ind_address,ind_data);
#else
                printf("Select port to print Statistics : ");
                mcxmac_ind_wr(ind_address,ind_data,XGENET,get_val(),0);
#endif
                printf("\n\rwritten data = 0x");putnum(ind_data);printf(" at address = 0x");putnum(ind_address);printf("\n\r");
            } 

            else if (val == 0x06)    // 10GBaseR ind rd command
            {
                printf("\n\rRead address (hex)=?\n\r");
                ind_address = get_val();
                printf("Select port : 0x"); 
                ind_data = xgbaser_ind_read(ind_address,get_val(),0);
                printf("\n\rdata read is = 0x");putnum(ind_data);printf("\n\r");
            } 

            else if (val == 0x07)    // 10GBaswR ind Wr command
            {
                printf("\n\renter write address \n\r");
                ind_address = get_val();
                printf("\n\r enter write data=?\n\r");
                ind_data = get_val();
                printf("\n\rwriting....\n\r");
                printf("Select port : 0x"); //md: for 10gig
                xgbaser_ind_write(ind_address,ind_data,get_val(),1);
                printf("\n\rwritten data = 0x");putnum(ind_data);printf(" at address = 0x");putnum(ind_address);printf("\n\r");
            } 
            else if (val == 0x08)    //// MDIO read
            {
                printf("\n\r Phy addr and reg address combined.in [0:31] format,[0:18] = 19'b0, [19:23]= Phyaddress, [24:26] = 3'b0, [27:31] = reg address in (hex)=?\n\r");
                ind_address = get_val();
                printf("Select port to print Statistics : ");
                ind_data = mdio_rd(ind_address,XGENET,get_val(),1);
            } 

            else if (val == 0x09)    //// MDIO write
            {
                printf("\n\r Phy addr and reg address combined in [0:31] format,[0:18] = 19'b0, [19:23]= Phyaddress, [24:26] = 3'b0, [27:31] = reg address in (hex)=?\n\r");
                printf("\n\renter write address \n\r");
                ind_address = get_val();
                printf("\n\r enter write data=?\n\r");
                ind_data = get_val();
                printf("\n\rwriting....\n\r");
                printf("Select port to print Statistics : ");
                mdio_wr(ind_address,ind_data,XGENET,get_val(),1);
                printf("\n\rwritten data = 0x");putnum(ind_data);printf(" at address = 0x");putnum(ind_address);printf("\n\r");
            } 

            else if (val == 0x10)    //// SerDes read
            {
                printf("\n\rNote: PHY SerDes has two base addres for rxtx_reg (0x400 and 0x600), one base address for CMU (0x0)\n\r");
                printf("\n\rFor each configuration, you must write one for 0x400 and one for 0x600\n\r");
                printf("\n\rPHY SerDes read address in (hex)=?\n\r");
                ind_address = get_val();
                printf("Select port to print Statistics : ");
                ind_data = enet_sds_ind_csr_reg_rd("SerDes_reg", ind_address,XGENET,get_val(),1);
                printf("\n\rdata read is = 0x");putnum(ind_data);printf("\n\r");
            } 

            else if (val == 0x11)    //// SerDes write
            {
                printf("\n\rNote: PHY SerDes has two base addres for rxtx_reg (0x400 and 0x600), one base address for CMU (0x0)\n\r");
                printf("\n\rFor each configuration, you must write one for 0x400 and one for 0x600\n\r");
                printf("\n\r Phy Write address in (hex)=?\n\r");
                ind_address = get_val();
                printf("\n\r enter write data=?\n\r");
                ind_data = get_val();
                printf("\n\rwriting....\n\r");
                printf("Select port to print Statistics : ");
                enet_sds_ind_csr_reg_wr("sedes_reg",ind_address,ind_data,XGENET,get_val(),1);
                printf("\n\rwritten data = 0x");putnum(ind_data);printf(" at address = 0x");putnum(ind_address);printf("\n\r");
            } 
            else if (val == 0x15) {

                int rd_data;
                int counter = 10;
                int eth_type = XGENET;
                int port=  0;

                mcxmac_ind_wr(PE_MCXMAC_MII_MGMT_ADDRESS__ADDR,0x1e11   , eth_type, port, 0);
                mcxmac_ind_wr(PE_MCXMAC_MII_MGMT_CONTROL__ADDR,0x0   , eth_type, port, 0);
                do {
                    rd_data = mcxmac_ind_rd(PE_MCXMAC_MII_MGMT_INDICATORS__ADDR, eth_type, port, 0);
                }while(rd_data != 0x0);

                printf("MDIO WR P%x : [0x%x] <- 0x%x \n\r",port,0x1e11,0x0);

                mcxmac_ind_wr(PE_MCXMAC_MII_MGMT_ADDRESS__ADDR,0x1e00   , eth_type, port, 0);
                mcxmac_ind_wr(PE_MCXMAC_MII_MGMT_CONTROL__ADDR,0x9140   , eth_type, port, 0);
                do {
                    rd_data = mcxmac_ind_rd(PE_MCXMAC_MII_MGMT_INDICATORS__ADDR, eth_type, port, 0);
                }while(rd_data != 0x0);

                printf("MDIO WR P%x : [0x%x] <- 0x%x \n\r",port,0x1e00,0x9140);
                mcxmac_ind_wr(PE_MCXMAC_MII_MGMT_ADDRESS__ADDR,0x1e00   , eth_type, port, 0);
                mcxmac_ind_wr(PE_MCXMAC_MII_MGMT_COMMAND__ADDR,0x00000001, eth_type, port, 0);
                do {
                    rd_data = mcxmac_ind_rd(PE_MCXMAC_MII_MGMT_INDICATORS__ADDR, eth_type, port, 0);
                    counter--;
                }while(rd_data != 0x0);

                printf("MDIO RD P%x : [0x%x] -> 0x%x \n\r",port,0x1e00,mcxmac_ind_rd(PE_MCXMAC_MII_MGMT_STATUS__ADDR, eth_type, port, 0));

            }


            else if (val == 0x16)
            {
                int port =0;
                int display = 1;
                int read_data =0;
                printf("Enter XGENET Port serdes to be reset (0/1/2/3) : ");
                port = get_val();
                mdio_wr(0x1e11,0     ,XGENET,port,display); // Deassert Reset
                mdio_wr(0x1e00,0x9140,XGENET,port,display); // Enable Auto Neg
                int loop = 50;
                int link, an_done = 0;
                while((loop != 0) && (an_done == 0)){
                    link, an_done = 0;
                    read_data = mdio_rd(0x1e01,XGENET,port,display);
                    link    = (read_data >> 2) & 0x1;
                    an_done = (read_data >> 5) & 0x1;
                    loop--;
                }
                printf("Autonegotiation %s complete \n\r", an_done ? "" : "NOT");
                printf("Link Status : %s \n\r", link == 1 ? "UP" : "DOWN");
                printf("Link Parameters : 0x%x \n\r", mdio_rd(0x1e05,XGENET,port,display));
                //	  val = get_val();
                //	  plc_rd_wr_test(val);
            }
            else if (val == 0x17) //Serdes analog reset only
            {
                printf("Enter XGENET Port serdes to be reset (0/1/2/3) : ");
                serdes_reset_rxa_xg(XGENET,get_val(),0x1);
            }

            else if (val == 0x30) //test_profile
            {
                //	      set_test_profile();
            }

            else if (val == 0x31) //qm_dump pb state
            {
                err_info_t ei;
                // qm_dump_pb_state(0, 0, 0);
                // qm_dump_pb_state(0, 0, 0x21);
                // qm_dump_qstate(0, 2, 32);
                // qm_dump_qstate(0, 1, 1);

                printf("\r\n ---- QM-0 queue state dump:\r\n");
                qm_dump_qstate(0, 4, 32);
                qm_dump_qstate(0, 1, 1);
                printf("\r\n ---- QM-2 queue state dump:\r\n"); 
                qm_dump_qstate(2, 4, 32);
                qm_dump_qstate(2, 1, 1);

                // printf("\r\n ---- QM1 queue statedump:\r\n"); 
                // qm_dump_pb_state(1, 0, 0);
                // qm_dump_pb_state(1, 0, 8);
                // qm_dump_pb_state(1, 1, 0);
                // qm_dump_pb_state(1, 1, 8);
                // qm_dump_qstate(1, 4, 32);
                // qm_dump_qstate(1, 1, 1);

                //qm_chk_errq(0, &ei);
                //qm_dump_qstate(0, 1, QM_ERROR_QID);
                //qm_dump_qstate(0, 1, QM_E_ERROR_QID);
                qm_dump_qm_errq(1);
                qm_err_dump(1);
            }

            else if (val == 0x37) // Send AXGMAC SW pause frame and force RX OSET to idles 
            {
                int port;
                printf("Select port : 0x");
                port = get_val();
                // force idles for removing local fault
                xgbaser_ind_write(0x14082,0x0707,port,0); //md: for 10 gig mode
                xgbaser_ind_write(0x14084,0x0707,port,0);
                xgbaser_ind_write(0x14086,0x0707,port,0);
                xgbaser_ind_write(0x14088,0x0707,port,0);
                xgbaser_ind_write(0x14080,0x3FF ,port,0);

                eth_wr(SM_XGENET_AXGMAC_CSR_XGENET_CSR_ECM_CFG_0__ADDR, 0x08000000,XGENET,port,1);
                while(eth_rd(SM_XGENET_AXGMAC_CSR_XGENET_CSR_ECM_CFG_0__ADDR,XGENET,port,1) != 0){
                    printf("\n\rWaiting for AXGMAC SW pause_req bit to get cleared\n\r");
                }
            }

            else if (val == 0x38) //Send AXGMAC SW pause frame
            {
                eth_wr(SM_XGENET_AXGMAC_CSR_XGENET_CSR_ECM_CFG_0__ADDR, 0x08000000,XGENET,port,1);
                while(eth_rd(SM_XGENET_AXGMAC_CSR_XGENET_CSR_ECM_CFG_0__ADDR,XGENET,port,1) != 0){
                    printf("\n\rWaiting for AXGMAC SW pause_req bit to get cleared\n\r");
                }

            }
            else if (val == 0x40) {
                send_pause_frame_xg(0);
            }
            else if (val == 0x88) {
                printf("Enter Debug bus : 0x");
                val = get_val();
                printf("\n\r");
                eth_wr(SM_GLBL_DIAG_CSR_CFG_DIAG_SEL__ADDR,val,XGENET,0,1);
                eth_rd(SM_GLBL_DIAG_CSR_DBG_BLOCK_AXI__ADDR,XGENET,0,1);
                eth_rd(SM_GLBL_DIAG_CSR_DBG_BLOCK_NON_AXI__ADDR,XGENET,0,1);

            }

            else if (val == 0x89) {
                int loop = get_val();
                eth_rd(SM_GLBL_DIAG_CSR_DBG_BLOCK_AXI__ADDR,XGENET,0,1);

                do {
                    eth_rd(SM_GLBL_DIAG_CSR_DBG_BLOCK_NON_AXI__ADDR,XGENET,0,1);
                    loop --;
                }while(loop != 0);
            }
            else if(val == 0x99) {
                printf("Enter XGENET Port to Configure(0/1/2/3) : ");
                init_xgenet(get_val(), 0x1);
            }
            /*
               else if (val == 0x101)  //md:  
               {
               printf("Set MAC loopback mode:\n");
            //          set_mac_level_lpbk();
            }
            else if (val == 0x102)    
            {
            printf("ReSet MAC loopback mode:\n"); 
            //         reset_mac_level_lpbk();
            }
            else if (val == 0x103)    
            {
            printf("Set PHY loopback mode:\n"); 
            //          set_phy_level_lpbk();          
            }
            else if (val == 0x104)   
            {
            printf("ReSet PHY loopback mode:\n"); 
            reset_phy_level_lpbk();          
            }
            */      
            else if (val == 0x105)    
            {
                printf("Send PAckets\n"); 
                eth_tx2rx_lpbk_test_xfi_1g();
            }
            else if (val == 0x106)    
            {
                printf("Read From PHY\n"); 
                printf("\nEnter PHY Address (hex): \n");
                phy_addr = get_val();
                printf("\nEnter Reg Address (hex): \n");
                phy_reg = get_val();

                ind_address = ((phy_addr << 8) | phy_reg);

                ind_data = mdio_rd(ind_address,MENET,0,0);
                printf("\nphy_addr:0x%x phy_reg:0x%x ind_address:0x%x ind_data:0x%x \n",phy_addr,phy_reg,ind_address,ind_data);
            }
            else if (val == 0x107)    
            {
                printf("\nEnter PHY Address (hex): \n");
                phy_addr = get_val();
                printf("\nEnter Reg Address (hex): \n");
                phy_reg = get_val();
                printf("\nEnter Write Value (hex): \n");
                ind_data = get_val();

                ind_address = ((phy_addr << 8) | phy_reg);
                mdio_wr(ind_address,ind_data,MENET,0,0);
                printf("\nphy_addr:0x%x phy_reg:0x%x ind_address:0x%x ind_data:0x%x \n",phy_addr,phy_reg,ind_address,ind_data);
            }
            else if (val == 0x108)    
            {
                int count=0;
                printf("MDIO Regress Test\n");
                //phy_rd(); 
                printf("\nEnter IterationNo: (hex): ");
                count = get_val();
                /*
                   mdio_sgmii_phyId_regression_test(0x11, 2, count);
                   mdio_sgmii_phyId_regression_test(0x12, 2, count);
                   mdio_sgmii_phyId_regression_test(0x13, 2, count);
                   mdio_sgmii_phyId_regression_test(0x14, 2, count);
                   mdio_sgmii_phyId_regression_test(0x15, 2, count);
                   mdio_sgmii_phyId_regression_test(0x16, 2, count);
                   mdio_sgmii_phyId_regression_test(0x17, 2, count);
                   mdio_sgmii_phyId_regression_test(0x18, 2, count);
                   */
                /*
                   printf("\nEnter PHY Address (hex): \n");
                   phy_reg = get_val();
                   for(phy_addr=0x11; phy_addr<0x19; phy_addr++) {
                   ind_address = ((phy_addr << 8) | phy_reg);
                   ind_data = mdio_rd(ind_address,MENET,0,0);
                   printf("\nphy_addr:0x%x phy_reg:0x%x ind_address:0x%x ind_data:0x%x \n",phy_addr,phy_reg,ind_address,ind_data);
                   }
                   */
            }
            /*
               else if (val == 0x109)    
               {
               printf("Disbale MDIO NegEdge\n");
               disable_mgmt_neg_edge(); 
               }
               */
            else if (val == 0x200)    
            {
                printf("OPTIONAL : 201 rst_sds_xg      - Reset Serdes \n");
                printf("OPTIONAL : 202 rst_sds_rxa_xg  - Reset Serdes All 4 port Analog only\n");
                printf("OPTIONAL : 203 rst_sds_rxda_xg - Reset Serdes All 4 port Digital and Analog\n");
                printf("OPTIONAL : 204 pll_status_xg   - Prints PLL status of both Instances \n");
                printf("OPTIONAL : 205 link_status_xg  - Prints Link Status of four ports\n");
                printf("OPTIONAL : 206 mac_stat_xg     - Prints MAC  Statistics of four ports\n");
                printf("OPTIONAL : 207 print_stat   - Prints Full Statistics \n");
                printf("OPTIONAL : 208 print_calib_xg  - Prints Serdes Calibration settings \n");
                printf("OPTIONAL : 209 fix_crc_xg      - Fixes CRC error by reseting serdes \n");
            }
            else if (val == 0x201)    
            {rst_sds_xg();
            }
            else if (val == 0x202)    
            {rst_sds_rxa_xg();
            }
            else if (val == 0x203)    
            {rst_sds_rxda_xg();
            }
            else if (val == 0x204)    
            {pll_status_xg();
            }
            else if (val == 0x205)    
            {link_status_xg();
            }
            else if (val == 0x206)    
            {mac_stat_xg();
            }
            else if (val == 0x207)    
            {//print_stat();
            }
            else if (val == 0x208)    
            {print_calib_xg();
            }
            else if (val == 0x209)    
            {fix_crc_xg();
            }


        }while (quit_r != 0x71);//end while
    }

    /*
       int config_val;
    //  printf("\n\nEnter AXGMAC_CONFIG_1 val : ");
    //  config_val = get_val(); config_val = get_val();
    config_val = 0xf400000c;
    int axgmac_config_1 , modify_axgmac_config_1 , kkk;
    for(kkk=0;kkk<=3;kkk++)
    axgmac_ind_write(AXGMAC_AXGMAC_CONFIG_1__ADDR, config_val , kkk , 0);
    printf("\n\n AXGMAC_CONFIG_1 set to : 0x%x",config_val);
    */

    /*
       printf("\n");
       int read_rpkt , read_tpkt , port_rxpf_txpf;

    //RPKT, TPKT
    port_rxpf_txpf=0;
    printf("\nXGE-%d==>",port_rxpf_txpf);
    read_rpkt = axgmac_stat_rd(PEMSTAT_RPKT__ADDR , port_rxpf_txpf);printf("[RPKT:%d]",read_rpkt);
    read_tpkt = axgmac_stat_rd(PEMSTAT_TPKT__ADDR , port_rxpf_txpf);printf("[TPKT:%d]",read_tpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR64__ADDR , port_rxpf_txpf);printf("[TR64:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR127__ADDR , port_rxpf_txpf);printf("[TR127:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR255__ADDR , port_rxpf_txpf);printf("[TR255:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR511__ADDR , port_rxpf_txpf);printf("[TR511:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR1K__ADDR , port_rxpf_txpf);printf("[TR1K:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TRMAX__ADDR , port_rxpf_txpf);printf("[TRMAX:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_RFCS__ADDR , port_rxpf_txpf);printf("[RFCS:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TFCS__ADDR , port_rxpf_txpf);printf("[TFCS:%d]",read_rpkt);
    port_rxpf_txpf++;//Port-1
    printf("\nXGE-%d==>",port_rxpf_txpf);
    read_rpkt = axgmac_stat_rd(PEMSTAT_RPKT__ADDR , port_rxpf_txpf);printf("[RPKT:%d]",read_rpkt);
    read_tpkt = axgmac_stat_rd(PEMSTAT_TPKT__ADDR , port_rxpf_txpf);printf("[TPKT:%d]",read_tpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR64__ADDR , port_rxpf_txpf);printf("[TR64:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR127__ADDR , port_rxpf_txpf);printf("[TR127:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR255__ADDR , port_rxpf_txpf);printf("[TR255:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR511__ADDR , port_rxpf_txpf);printf("[TR511:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR1K__ADDR , port_rxpf_txpf);printf("[TR1K:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TRMAX__ADDR , port_rxpf_txpf);printf("[TRMAX:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_RFCS__ADDR , port_rxpf_txpf);printf("[RFCS:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TFCS__ADDR , port_rxpf_txpf);printf("[TFCS:%d]",read_rpkt);
    port_rxpf_txpf++;//Port-2
    printf("\nXGE-%d==>",port_rxpf_txpf);
    read_rpkt = axgmac_stat_rd(PEMSTAT_RPKT__ADDR , port_rxpf_txpf);printf("[RPKT:%d]",read_rpkt);
    read_tpkt = axgmac_stat_rd(PEMSTAT_TPKT__ADDR , port_rxpf_txpf);printf("[TPKT:%d]",read_tpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR64__ADDR , port_rxpf_txpf);printf("[TR64:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR127__ADDR , port_rxpf_txpf);printf("[TR127:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR255__ADDR , port_rxpf_txpf);printf("[TR255:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR511__ADDR , port_rxpf_txpf);printf("[TR511:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR1K__ADDR , port_rxpf_txpf);printf("[TR1K:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TRMAX__ADDR , port_rxpf_txpf);printf("[TRMAX:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_RFCS__ADDR , port_rxpf_txpf);printf("[RFCS:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TFCS__ADDR , port_rxpf_txpf);printf("[TFCS:%d]",read_rpkt);
    port_rxpf_txpf++;//Port-3
    printf("\nXGE-%d==>",port_rxpf_txpf);
    read_rpkt = axgmac_stat_rd(PEMSTAT_RPKT__ADDR , port_rxpf_txpf);printf("[RPKT:%d]",read_rpkt);
    read_tpkt = axgmac_stat_rd(PEMSTAT_TPKT__ADDR , port_rxpf_txpf);printf("[TPKT:%d]",read_tpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR64__ADDR , port_rxpf_txpf);printf("[TR64:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR127__ADDR , port_rxpf_txpf);printf("[TR127:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR255__ADDR , port_rxpf_txpf);printf("[TR255:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR511__ADDR , port_rxpf_txpf);printf("[TR511:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR1K__ADDR , port_rxpf_txpf);printf("[TR1K:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TRMAX__ADDR , port_rxpf_txpf);printf("[TRMAX:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_RFCS__ADDR , port_rxpf_txpf);printf("[RFCS:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TFCS__ADDR , port_rxpf_txpf);printf("[TFCS:%d]",read_rpkt);


    printf("\n\nCalling 'eth_tx2rx_lpbk_test_xfi_1g()' ...\n\n");
    eth_tx2rx_lpbk_test_xfi_1g();

    printf("\n\nPort Stats at the end of the test ...\n");
    //RPKT, TPKT
    port_rxpf_txpf=0;
    printf("\nXGE-%d==>",port_rxpf_txpf);
    read_rpkt = axgmac_stat_rd(PEMSTAT_RPKT__ADDR , port_rxpf_txpf);printf("[RPKT:%d]",read_rpkt);
    read_tpkt = axgmac_stat_rd(PEMSTAT_TPKT__ADDR , port_rxpf_txpf);printf("[TPKT:%d]",read_tpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR64__ADDR , port_rxpf_txpf);printf("[TR64:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR127__ADDR , port_rxpf_txpf);printf("[TR127:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR255__ADDR , port_rxpf_txpf);printf("[TR255:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR511__ADDR , port_rxpf_txpf);printf("[TR511:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR1K__ADDR , port_rxpf_txpf);printf("[TR1K:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TRMAX__ADDR , port_rxpf_txpf);printf("[TRMAX:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_RFCS__ADDR , port_rxpf_txpf);printf("[RFCS:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TFCS__ADDR , port_rxpf_txpf);printf("[TFCS:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TRMGV__ADDR , port_rxpf_txpf);printf("[TRMGV:%d]",read_rpkt);
    port_rxpf_txpf++;//Port-1
    printf("\nXGE-%d==>",port_rxpf_txpf);
    read_rpkt = axgmac_stat_rd(PEMSTAT_RPKT__ADDR , port_rxpf_txpf);printf("[RPKT:%d]",read_rpkt);
    read_tpkt = axgmac_stat_rd(PEMSTAT_TPKT__ADDR , port_rxpf_txpf);printf("[TPKT:%d]",read_tpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR64__ADDR , port_rxpf_txpf);printf("[TR64:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR127__ADDR , port_rxpf_txpf);printf("[TR127:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR255__ADDR , port_rxpf_txpf);printf("[TR255:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR511__ADDR , port_rxpf_txpf);printf("[TR511:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR1K__ADDR , port_rxpf_txpf);printf("[TR1K:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TRMAX__ADDR , port_rxpf_txpf);printf("[TRMAX:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_RFCS__ADDR , port_rxpf_txpf);printf("[RFCS:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TFCS__ADDR , port_rxpf_txpf);printf("[TFCS:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TRMGV__ADDR , port_rxpf_txpf);printf("[TRMGV:%d]",read_rpkt);
    port_rxpf_txpf++;//Port-2
    printf("\nXGE-%d==>",port_rxpf_txpf);
    read_rpkt = axgmac_stat_rd(PEMSTAT_RPKT__ADDR , port_rxpf_txpf);printf("[RPKT:%d]",read_rpkt);
    read_tpkt = axgmac_stat_rd(PEMSTAT_TPKT__ADDR , port_rxpf_txpf);printf("[TPKT:%d]",read_tpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR64__ADDR , port_rxpf_txpf);printf("[TR64:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR127__ADDR , port_rxpf_txpf);printf("[TR127:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR255__ADDR , port_rxpf_txpf);printf("[TR255:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR511__ADDR , port_rxpf_txpf);printf("[TR511:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR1K__ADDR , port_rxpf_txpf);printf("[TR1K:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TRMAX__ADDR , port_rxpf_txpf);printf("[TRMAX:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_RFCS__ADDR , port_rxpf_txpf);printf("[RFCS:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TFCS__ADDR , port_rxpf_txpf);printf("[TFCS:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TRMGV__ADDR , port_rxpf_txpf);printf("[TRMGV:%d]",read_rpkt);
    port_rxpf_txpf++;//Port-3
    printf("\nXGE-%d==>",port_rxpf_txpf);
    read_rpkt = axgmac_stat_rd(PEMSTAT_RPKT__ADDR , port_rxpf_txpf);printf("[RPKT:%d]",read_rpkt);
    read_tpkt = axgmac_stat_rd(PEMSTAT_TPKT__ADDR , port_rxpf_txpf);printf("[TPKT:%d]",read_tpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR64__ADDR , port_rxpf_txpf);printf("[TR64:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR127__ADDR , port_rxpf_txpf);printf("[TR127:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR255__ADDR , port_rxpf_txpf);printf("[TR255:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR511__ADDR , port_rxpf_txpf);printf("[TR511:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TR1K__ADDR , port_rxpf_txpf);printf("[TR1K:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TRMAX__ADDR , port_rxpf_txpf);printf("[TRMAX:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_RFCS__ADDR , port_rxpf_txpf);printf("[RFCS:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TFCS__ADDR , port_rxpf_txpf);printf("[TFCS:%d]",read_rpkt);
    read_rpkt = axgmac_stat_rd(PEMSTAT_TRMGV__ADDR , port_rxpf_txpf);printf("[TRMGV:%d]",read_rpkt);


    printf("\n\n");
    */


        //  printf("\n*****************************************\n\r");
        //  printf("******** XFI-SGMII Test Complete ********\n\r");
        //  printf("*****************************************\n\r");
#endif //XFI-SGMII 

#if 0 // md: SATA-SGMII
        printf("\r\n<---------- SATA-SGMII Test Starts --------->\n\r");
    //enet_main();
    eth_tx2rx_1g();
    printf("\r\n<---------- SATA-SGMII Test Completes --------->\n\r");
#endif 

    //pkt_compare_xfi(0);
    //total_err_count_result_xfi();	
    return 0;
}

int pkt_compare_xfi(int port_num_calc, u64 hd_ptr, int packet_count)
{

    u64 st_address1; 	
    u64 st_address2; 	
    u64 st_address3; 	
    u64 st_address4; 	
    u64 addr_1,addr_2,addr_3,addr_4;
    u8 wn1[] = {1, 1, 1, 1, 1};
    u64 crc_data_tx_0,crc_data_rx_0;
    u64 crc_data_tx_1,crc_data_rx_1;
    u64 crc_data_tx_2,crc_data_rx_2;
    u64 crc_data_tx_3,crc_data_rx_3;
    u64 ddr_base_tx_pkt[4]={0};
    u64 ddr_base_rx_pkt[4]={0};
    u64 k,number_errors[4]={0};
    u64 temp_tx,temp_rx;
    int read_rpkt_as[4]={0}; 
    int read_rfcs_as[4]={0};
    int i;
    u64 dela;
    q_state_t q_state_pq_32_0[50];
    q_state_t q_state_pq_32_2[50];
    q_state_t q_state_pq_33_0[50];
    q_state_t q_state_pq_33_2[50];
    q_state_t q_state_pq_64_0[50];
    q_state_t q_state_pq_64_2[50];
    q_state_t q_state_pq_65_0[50];
    q_state_t q_state_pq_65_2[50];
    q_state_t q_state_pq_dbg[50];

    int iter_count;
    /*
       int itrcb;
       for (itrcb=0; itrcb<36; itrcb++)
       {
       QM_CHK_RET(qm_get_q_state_dir(0,(32+itrcb),1,wn1,&q_state_pq_dbg[0]));
       printf("ST_ADDR_ITRCB = 0x%x\n" ,  (q_state_pq_dbg[0].pqfp.st_addr));
       }
       */
    QM_CHK_RET(qm_get_q_state_dir(0,32,1,wn1,&q_state_pq_32_0[0]));
    QM_CHK_RET(qm_get_q_state_dir(0,33,1,wn1,&q_state_pq_33_0[0]));

    QM_CHK_RET(qm_get_q_state_dir(0,64,1,wn1,&q_state_pq_64_0[0]));
    QM_CHK_RET(qm_get_q_state_dir(0,65,1,wn1,&q_state_pq_65_0[0]));
#if 1
    QM_CHK_RET(qm_get_q_state_dir(2,32,1,wn1,&q_state_pq_32_2[0]));
    QM_CHK_RET(qm_get_q_state_dir(2,33,1,wn1,&q_state_pq_33_2[0]));

    QM_CHK_RET(qm_get_q_state_dir(2,64,1,wn1,&q_state_pq_64_2[0]));
    QM_CHK_RET(qm_get_q_state_dir(2,65,1,wn1,&q_state_pq_65_2[0]));
#endif
    /*
       printf("DUMPING QSTATE\n");
       qm_dump_qstate(0, 2, 32);
       qm_dump_qstate(0, 2, 64);
#if 1  
qm_dump_qstate(2, 2, 32);
qm_dump_qstate(2, 2, 64);
#endif
*/  
    //ddr_base_tx_pkt[0]
    switch(port_num_calc)
    {
        case 0:

            st_address1 = (q_state_pq_32_0[0].pqfp.st_addr);
              //printf("\nst_address1 : 0x%x",st_address1);
            st_address2 = (st_address1<<8);
            //printf("\tst_address2 : 0x%x",st_address2);
            st_address1 = (hd_ptr);
             //printf("\tst_address1 : 0x%x",st_address1);
            st_address2 += (st_address1<<4);
             //printf("\tst_address2 : 0x%x",st_address2);
            st_address2+=8;
             //printf("\tst_address2 : 0x%x",st_address2);

		st_address2 = qm_get_va(st_address2);// _tp

            addr_1 = read(st_address2);
             //printf("\naddr_1 : 0x%x",addr_1);
            addr_1 = addr_1 & 0x00000000ffffffff;   //masking uppar 32 bits
             //printf("\naddr_1 : 0x%x",addr_1);

            addr_2 = read(st_address2+4);
             //printf("\naddr_2 : 0x%x",addr_2);
            addr_2 = addr_2 & 0x00000000000003ff;   //keeping only last 10 bits
             //printf("\naddr_2 : 0x%x",addr_2);
            addr_3 = addr_2 << 32;
              //printf("\naddr_3 : 0x%x",addr_3);

            addr_4 = addr_3 + addr_1;               //getting 42 bits DATA ADDRESS field
             //printf("\naddr_4 : 0x%x\n",addr_4);
            //ddr_base_tx_pkt[0]= addr_4;
		ddr_base_tx_pkt[0] = qm_get_va(addr_4);
            lprintf(8,"\nddr_base_tx_pkt[0] : 0x%x",ddr_base_tx_pkt[0]);
            //  printf("\nddr_base_tx_pkt[0] : 0x%x",ddr_base_tx_pkt[0]);
            //printf("\nq_state_pq_32_0 ===> st_address1 = 0x%x \t addr_1 = 0x%x \t addr_2 = 0x%x \t ddr_base_tx_pkt[0] : 0x%x",st_address1,addr_1,addr_2, ddr_base_tx_pkt[0]);
            break;
            //ddr_base_tx_pkt[1]
        case 1:
            st_address1 = (q_state_pq_33_0[0].pqfp.st_addr);
            st_address2 = (st_address1<<8);
            st_address1 = (hd_ptr);
            st_address2 += (st_address1<<4);
            st_address2+=8;

		st_address2 = qm_get_va(st_address2);// _tp

            addr_1 = read(st_address2);
            addr_1 = addr_1 & 0x00000000ffffffff;   //masking uppar 32 bits

            addr_2 = read(st_address2+4);
            addr_2 = addr_2 & 0x00000000000003ff;   //keeping only last 10 bits
            addr_3 = addr_2 << 32;

            addr_4 = addr_3 + addr_1;               //getting 42 bits DATA ADDRESS field
            //ddr_base_tx_pkt[1]= addr_4;
		ddr_base_tx_pkt[1] = qm_get_va(addr_4);
            lprintf(8,"\nddr_base_tx_pkt[1] : 0x%x",ddr_base_tx_pkt[1]);
            //  printf("\nq_state_pq_33_0 ===> st_address1 = 0x%x \t addr_1 = 0x%x \t addr_2 = 0x%x \t ddr_base_tx_pkt[1] : 0x%x",st_address1,addr_1,addr_2, ddr_base_tx_pkt[1]);

#if 1 // port2-3
            //ddr_base_tx_pkt[3]
            break;
        case 2:
            st_address1 = (q_state_pq_32_2[0].pqfp.st_addr);
            st_address2 = (st_address1<<8);
            st_address1 = (hd_ptr);
            st_address2 += (st_address1<<4);
            st_address2+=8;

		st_address2 = qm_get_va(st_address2);// _tp

            addr_1 = read(st_address2);
            addr_1 = addr_1 & 0x00000000ffffffff;   //masking uppar 32 bits
            addr_2 = read(st_address2+4);
            addr_2 = addr_2 & 0x00000000000003ff;   //keeping only last 10 bits
            addr_3 = addr_2 << 32;
            addr_4 = addr_3 + addr_1;               //getting 42 bits DATA ADDRESS field
            //ddr_base_tx_pkt[2]= addr_4;
		ddr_base_tx_pkt[2] = qm_get_va(addr_4);
            lprintf(8,"\nddr_base_tx_pkt[2] : 0x%x",ddr_base_tx_pkt[2]);
            //  printf("\nq_state_pq_32_2 ===> st_address1 = 0x%x \t addr_1 = 0x%x \t addr_2 = 0x%x \t ddr_base_tx_pkt[2] : 0x%x",st_address1,addr_1,addr_2, ddr_base_tx_pkt[2]);

            //ddr_base_tx_pkt[4]
            break;
        case 3:

            st_address1 = (q_state_pq_33_2[0].pqfp.st_addr);
            st_address2 = (st_address1<<8);
            st_address1 = (hd_ptr);
            st_address2 += (st_address1<<4);
            st_address2+=8;

		st_address2 = qm_get_va(st_address2);// _tp

            addr_1 = read(st_address2);
            addr_1 = addr_1 & 0x00000000ffffffff;   //masking uppar 32 bits
            addr_2 = read(st_address2+4);
            addr_2 = addr_2 & 0x00000000000003ff;   //keeping only last 10 bits
            addr_3 = addr_2 << 32;
            addr_4 = addr_3 + addr_1;               //getting 42 bits DATA ADDRESS field
            //ddr_base_tx_pkt[3]= addr_4;
		ddr_base_tx_pkt[3] = qm_get_va(addr_4);
            lprintf(8,"\nddr_base_tx_pkt[3] : 0x%x",ddr_base_tx_pkt[3]);
            //  printf("\nq_state_pq_33_2 ===> st_address1 = 0x%x \t addr_1 = 0x%x \t addr_2 = 0x%x \t ddr_base_tx_pkt[3] : 0x%x",st_address1,addr_1,addr_2, ddr_base_tx_pkt[3]);
            break;
#endif 
        default:
            printf("Wrong Port number\n");
    }

    switch(port_num_calc)
    {
        case 0:
            st_address1 = (q_state_pq_64_0[0].pqfp.st_addr);
            st_address2 = (st_address1<<8);
            st_address1 = (hd_ptr);
            st_address2 += (st_address1<<4);
            st_address2+=8;

		st_address2 = qm_get_va(st_address2);// _tp

            //printf("\nst_address2 : 0x%x",st_address2);
            addr_1 = read(st_address2);
            addr_1 = addr_1 & 0x00000000ffffffff;   //masking uppar 32 bits
            //printf("\t addr_1 : 0x%x",addr_1);

            addr_2 = read(st_address2+4);
            addr_2 = addr_2 & 0x00000000000003ff;   //keeping only last 10 bits
            addr_3 = addr_2 << 32;
            //printf("\t addr_2: 0x%x \t addr_3: 0x%x",addr_2,addr_3);

            addr_4 = addr_3 + addr_1;               //getting 42 bits DATA ADDRESS field
		//printf("\n\ndelay - 1"); 
		//USDELAY(1000);
            //ddr_base_rx_pkt[0]= addr_4;
		//printf("\n\ndelay - 2"); 
		//USDELAY(1000);
		ddr_base_rx_pkt[0] = qm_get_va(addr_4);
		//printf("\n\ndelay - 3"); 
		//USDELAY(1000);
            lprintf(8,"\nddr_base_rx_pkt[0] : 0x%x",ddr_base_rx_pkt[0]);
		//printf("\n\ndelay - done ..."); 
            //printf("\t ddr_base_rx_pkt[0] : 0x%x",ddr_base_rx_pkt[0]);
            //    printf("\nq_state_pq_64_0 ===> st_address1 = 0x%x \t addr_1 = 0x%x \t addr_2 = 0x%x \t ddr_base_rx_pkt[0] : 0x%x",st_address1,addr_1,addr_2, ddr_base_rx_pkt[0]);
            break;
        case 1:


            st_address1 = (q_state_pq_65_0[0].pqfp.st_addr);
            st_address2 = (st_address1<<8);
            st_address1 = (hd_ptr);
            st_address2 += (st_address1<<4);
            st_address2+=8;

		st_address2 = qm_get_va(st_address2);// _tp

            addr_1 = read(st_address2);
            addr_1 = addr_1 & 0x00000000ffffffff;   //masking uppar 32 bits

            addr_2 = read(st_address2+4);
            addr_2 = addr_2 & 0x00000000000003ff;   //keeping only last 10 bits
            addr_3 = addr_2 << 32;

            addr_4 = addr_3 + addr_1;               //getting 42 bits DATA ADDRESS field
            //ddr_base_rx_pkt[1]= addr_4;
		ddr_base_rx_pkt[1] = qm_get_va(addr_4);
            lprintf(8,"\nddr_base_rx_pkt[1] : 0x%x",ddr_base_rx_pkt[1]);
            //   printf("\nq_state_pq_65_0 ===> st_address1 = 0x%x \t addr_1 = 0x%x \t addr_2 = 0x%x \t ddr_base_rx_pkt[1] : 0x%x",st_address1,addr_1,addr_2, ddr_base_rx_pkt[1]);

            break;
        case 2:
#if 1    
            st_address1 = (q_state_pq_64_2[0].pqfp.st_addr);
            st_address2 = (st_address1<<8);
            st_address1 = (hd_ptr);
            st_address2 += (st_address1<<4);
            st_address2+=8;

		st_address2 = qm_get_va(st_address2);// _tp

            addr_1 = read(st_address2);
            addr_1 = addr_1 & 0x00000000ffffffff;   //masking uppar 32 bits

            addr_2 = read(st_address2+4);
            addr_2 = addr_2 & 0x00000000000003ff;   //keeping only last 10 bits
            addr_3 = addr_2 << 32;

            addr_4 = addr_3 + addr_1;               //getting 42 bits DATA ADDRESS field
            //ddr_base_rx_pkt[2]= addr_4;
		ddr_base_rx_pkt[2] = qm_get_va(addr_4);
            lprintf(8,"\nddr_base_rx_pkt[2] : 0x%x",ddr_base_rx_pkt[2]);

            //  printf("\nq_state_pq_64_2 ===> st_address1 = 0x%x \t addr_1 = 0x%x \t addr_2 = 0x%x \t ddr_base_rx_pkt[2] : 0x%x",st_address1,addr_1,addr_2, ddr_base_rx_pkt[2]);
            break;
        case 3:
            st_address1 = (q_state_pq_65_2[0].pqfp.st_addr);
            st_address2 = (st_address1<<8);
            st_address1 = (hd_ptr);
            st_address2 += (st_address1<<4);
            st_address2+=8;

		st_address2 = qm_get_va(st_address2);// _tp

            addr_1 = read(st_address2);
            addr_1 = addr_1 & 0x00000000ffffffff;   //masking uppar 32 bits
            addr_2 = read(st_address2+4);
            addr_2 = addr_2 & 0x00000000000003ff;   //keeping only last 10 bits
            addr_3 = addr_2 << 32;
            addr_4 = addr_3 + addr_1;               //getting 42 bits DATA ADDRESS field
            //ddr_base_rx_pkt[3]= addr_4;
		ddr_base_rx_pkt[3] = qm_get_va(addr_4);
            lprintf(8,"\nddr_base_rx_pkt[3] : 0x%x",ddr_base_rx_pkt[3]);
            //   printf("\nq_state_pq_65_2 ===> st_address1 = 0x%x \t addr_1 = 0x%x \t addr_2 = 0x%x \t ddr_base_rx_pkt[3] : 0x%x",st_address1,addr_1,addr_2, ddr_base_rx_pkt[3]);

#endif
            break;
        default :
            printf("Worng port\n");
    }

    //USDELAY(1000);//-- ORIGINAL CODE --
    //USDELAY(5000);
    //	for(dela=0;dela<1000000;dela++);		
    //	for(dela=0;dela<1000000;dela++);		
    //	for(dela=0;dela<1000000;dela++);		

	//printf("\n\nHere - 1");

    //do {
    for(iter_count=0;iter_count<=1010;iter_count++) {
	//printf("\ndo-while for XGE-%d",port_num_calc);
    	read_rpkt_as[port_num_calc] = axgmac_stat_rd(PEMSTAT_RPKT__ADDR , port_num_calc);
    	read_rfcs_as[port_num_calc] = axgmac_stat_rd(PEMSTAT_RFCS__ADDR , port_num_calc);
	if(read_rpkt_as[port_num_calc] != 0 || read_rfcs_as[port_num_calc] != 0) break;
	USDELAY(1000);
    }
    //} while(read_rpkt_as[port_num_calc] == 0 && read_rfcs_as[port_num_calc] == 0);

    if(iter_count>1000) {
	printf("\n\n## Taking too long for packet reception !!! \n\n");
	printf("Waited for %d-ms\n\n",iter_count);
	printf("Packet count : %d",packet_count);
	stat_dump_per_port(port_num_calc,1);
    }

    stat_dump_per_port(port_num_calc,0);
	//printf("\n\nHere - 2");

    switch(port_num_calc) {
        case 0 :
            if(read_rpkt_as[0] || read_rfcs_as[0]){

                //printf("\n************** Comapring for port 0 ***************\n");
                //printf(".");

                for(k=0;k<64;k++){

                    //	crc_data_tx_0=read_as_32(temp_tx);
	//printf("\n\nHere - 3");
                    crc_data_tx_0=read_word(ddr_base_tx_pkt[0]+k*4);
                    crc_data_rx_0=read_word(ddr_base_rx_pkt[0]+k*4);


	//printf("\n\nHere - 4");
                    /*printf("^^^^^^^^^^^^^^^^^^^PASS : Port 0   ^^^^^^^^^^^^^^^^^ \n");
                      printf("############ MATCH at address 0x%x and 0x%x ###############\n",ddr_base_tx_pkt[0]+k*4,ddr_base_rx_pkt[0]+k*4);
                      printf("\n");
                      printf("############ MATCH data 0x%x and 0x%x ###############\n",crc_data_tx_0,crc_data_rx_0);
                      printf("\n");*/
                    if(crc_data_tx_0!=crc_data_rx_0)
                    {	
                        printf("^^^^^FAIL : Port 0 ( CRC ERROR)  ^^^^^^^^^^ \n");
                        printf("############ Mismatch at address 0x%x and 0x%x ###############\n",ddr_base_tx_pkt[0]+k*4,ddr_base_rx_pkt[0]+k*4);
                        printf("\n");
                        printf("############ Mismatch data 0x%x and 0x%x ###############\n",crc_data_tx_0,crc_data_rx_0);
                        printf("\n");
                        number_errors[0]++;
                        //memset(ddr_base_tx_pkt[0]+k*4, 0,4);
                        // memset(ddr_base_rx_pkt[0]+k*4, 0,4);
                        //break;// -- ORIGINAL CODE -- Temp commented
                    }

                }
            }
            else
            {
                printf("^^^^FAIL : Port 0 (didn't receive a packet) ^^^^^^^^\n");
                number_errors[0]++;
                //memset(ddr_base_tx_pkt[0]+k*4, 0,4);// -- ORIGINAL CODE -- Temp commented
                //memset(ddr_base_rx_pkt[0]+k*4, 0,4);// -- ORIGINAL CODE -- Temp commented
            }
            break;


        case 1 :
            if(read_rpkt_as[1] || read_rfcs_as[1]){

                //printf("\n************** Comapring for port 1 ***************\n");
                //printf(".");

                for(k=0;k<64;k++){

                    crc_data_tx_1=read_word(ddr_base_tx_pkt[1]+k*4);
                    crc_data_rx_1=read_word(ddr_base_rx_pkt[1]+k*4);
                    /*printf("^^^^^^^^^^^^^^^^^^^PASS : Port 1  ^^^^^^^^^^^^^^^^^ \n");
                      printf("############ MATCH at address 0x%x and 0x%x ###############\n",ddr_base_tx_pkt[0]+k*4,ddr_base_rx_pkt[0]+k*4);
                      printf("\n");
                      printf("############ MATCH data 0x%x and 0x%x ###############\n",crc_data_tx_0,crc_data_rx_0);
                      printf("\n");*/

                    if(crc_data_tx_1!=crc_data_rx_1)
                    {
                        printf("^^^^^^FAIL : Port 1 ( CRC ERROR)  ^^^^^^^^^^\n");
                        printf("############ Mismatch at 0x%x and 0x%x ###############\n",ddr_base_tx_pkt[1]+k*4,ddr_base_rx_pkt[1]+k*4);
                        printf("\n");
                        printf("############ Mismatch data 0x%x and 0x%x ###############\n",crc_data_tx_1,crc_data_rx_1);
                        printf("\n");
                        number_errors[1]++;
                        //  memset(ddr_base_tx_pkt[1]+k*4, 0,4);
                        //   memset(ddr_base_rx_pkt[1]+k*4, 0,4);
                        //break;// -- ORIGINAL CODE -- Temp commented
                    }
                }
            }
            else
            {
                printf("^^^^^^^^FAIL : Port 1 (didn't receive a packet) ^^^^^^^^^^\n");
                number_errors[1]++;
                //memset(ddr_base_tx_pkt[1]+k*4, 0,4);// -- ORIGINAL CODE -- Temp commented
                //memset(ddr_base_rx_pkt[1]+k*4, 0,4);// -- ORIGINAL CODE -- Temp commented
            }
            break;

#if 1

        case 2 :
            if(read_rpkt_as[2] || read_rfcs_as[2]){

                //printf("\n************** Comapring for port 2 ***************\n");
                //printf(".");

                for(k=0;k<64;k++){

                    crc_data_tx_2=read_word(ddr_base_tx_pkt[2]+k*4);
                    crc_data_rx_2=read_word(ddr_base_rx_pkt[2]+k*4);
                    /*printf("^^^^^^^^^^^^^^^^^^^PASS : Port 2   ^^^^^^^^^^^^^^^^^ \n");
                      printf("############ MATCH at address 0x%x and 0x%x ###############\n",ddr_base_tx_pkt[0]+k*4,ddr_base_rx_pkt[0]+k*4);
                      printf("\n");
                      printf("############ MATCH data 0x%x and 0x%x ###############\n",crc_data_tx_0,crc_data_rx_0);
                      printf("\n");*/

                    if(crc_data_tx_2!=crc_data_rx_2)
                    {				
                        printf("^^^^^^^^^^^^^^^^^^^FAIL : Port 2 ( CRC ERROR)  ^^^^^^^^^^^^^^^^^ \n");
                        printf("############ Mismatch at 0x%x and 0x%x ###############\n",ddr_base_tx_pkt[2]+k*4,ddr_base_rx_pkt[2]+k*4);
                        printf("\n");
                        printf("############ Mismatch data 0x%x and 0x%x ###############\n",crc_data_tx_2,crc_data_rx_2);
                        printf("\n");
                        number_errors[2]++;
                        //  memset(ddr_base_tx_pkt[2]+k*4, 0,4);
                        //memset(ddr_base_rx_pkt[2]+k*4, 0,4);
                        //break;// -- ORIGINAL CODE -- Temp commented
                    }
                }
            }
            else
            {printf("^^^^^^^^^^^^^^^^^^^FAIL : Port 2 (didn't receive a packet) ^^^^^^^^^^^^^^^^^ \n");
                number_errors[2]++;
                //memset(ddr_base_tx_pkt[2]+k*4, 0,4);// -- ORIGINAL CODE -- Temp commented
                //memset(ddr_base_rx_pkt[2]+k*4, 0,4);// -- ORIGINAL CODE -- Temp commented
            }
            break;



        case 3 :
            if(read_rpkt_as[3] || read_rfcs_as[3]){

                //printf("\n************** Comapring for port 3 ***************\n");
                //printf(".");
                /*printf("^^^^^^^^^^^^^^^^^^^PASS : Port 3   ^^^^^^^^^^^^^^^^^ \n");
                  printf("############ MATCH at address 0x%x and 0x%x ###############\n",ddr_base_tx_pkt[0]+k*4,ddr_base_rx_pkt[0]+k*4);
                  printf("\n");
                  printf("############ MATCH data 0x%x and 0x%x ###############\n",crc_data_tx_0,crc_data_rx_0);
                  printf("\n");*/

                for(k=0;k<64;k++){
                    crc_data_tx_3=read_word(ddr_base_tx_pkt[3]+k*4);
                    crc_data_rx_3=read_word(ddr_base_rx_pkt[3]+k*4);

                    if(crc_data_tx_3!=crc_data_rx_3)
                    {	
                        printf("^^^^^^^^^^^^^^^^^^^FAIL : Port 3 ( CRC ERROR)  ^^^^^^^^^^^^^^^^^ \n");
                        printf("############ Mismatch at 0x%x and 0x%x ###############\n",ddr_base_tx_pkt[3]+k*4,ddr_base_rx_pkt[3]+k*4);
                        printf("\n");
                        printf("############ Mismatch data 0x%x and 0x%x ###############\n",crc_data_tx_3,crc_data_rx_3);
                        printf("\n");
                        number_errors[3]++;
                        //    memset(ddr_base_tx_pkt[3]+k*4, 0,4);
                        //  memset(ddr_base_rx_pkt[3]+k*4, 0,4);
                        //break;// -- ORIGINAL CODE -- Temp commented
                    }
                }
            }
            else
            {printf("^^^^^^^^^^^^^^^^^^^FAIL : Port 3 (didn't receive a packet) ^^^^^^^^^^^^^^^^^ \n");
                number_errors[3]++;
                //memset(ddr_base_tx_pkt[3]+k*4, 0,4);// -- ORIGINAL CODE -- Temp commented
                //memset(ddr_base_rx_pkt[3]+k*4, 0,4);// -- ORIGINAL CODE -- Temp commented
            }
            break;
#endif
        default :
            printf("\nOops !! Invalid port number passed\n");


    }




    /*
       switch(port_num_calc) {
       case 0 :
       if(number_errors[0])
       {printf("^^^^^^^^^^^^^^^^^^^FAIL for PORT 0^^^^^^^^^^^^^^^^^^^^^^\n");}
       else
       {printf("^^^^^^^^^^^^^^^^^^^PASS for PORT 0^^^^^^^^^^^^^^^^^^^^^^\n");}

       printf("\n");	
       printf("\n");	
       break;

       case 1 :
       if(number_errors[1])
       {printf("^^^^^^^^^^^^^^^^^^^FAIL for PORT 1^^^^^^^^^^^^^^^^^^^^^^\n");}
       else
       {printf("^^^^^^^^^^^^^^^^^^^PASS for PORT 1^^^^^^^^^^^^^^^^^^^^^^\n");}

       printf("\n");
       printf("\n");
       break;

       case 2 :
       if(number_errors[2])
       {printf("^^^^^^^^^^^^^^^^^^^FAIL for PORT 2^^^^^^^^^^^^^^^^^^^^^^\n");}
       else
       {printf("^^^^^^^^^^^^^^^^^^^PASS for PORT 2^^^^^^^^^^^^^^^^^^^^^^\n");}

       printf("\n");
       printf("\n");
       break;

       case 3 :
       if(number_errors[3])
       {printf("^^^^^^^^^^^^^^^^^^^FAIL for PORT 3^^^^^^^^^^^^^^^^^^^^^^\n");}
       else
       {printf("^^^^^^^^^^^^^^^^^^^PASS for PORT 3^^^^^^^^^^^^^^^^^^^^^^\n");}

       printf("\n");
       printf("\n");
       break;

       default :
       printf("\nOops !! Invalid port number passed\n");

       }
       */

	//printf("\n\nHere - 5");
    total_err_count_xfi[port_num_calc] = total_err_count_xfi[port_num_calc] + number_errors[port_num_calc];

    //printf("\n\nFunction pkt_compare ends for port no. %d",port_num_calc);

}

void total_err_count_result_xfi() {

    //check_pcsfifo_status();

    printf("\n");	
    printf("\n");	

    if(qm_err_count_xfi[0]>0) printf("\tXFI-10G Port-0 - [QM FAILED] \n");
    if(qm_err_count_xfi[1]>0) printf("\tXFI-10G Port-1 - [QM FAILED] \n");
    if(qm_err_count_xfi[2]>0) printf("\tXFI-10G Port-2 - [QM FAILED, Ignoring] \n");
    if(qm_err_count_xfi[3]>0) printf("\tXFI-10G Port-3 - [QM FAILED, Ignoring] \n");

    if(qm_err_count_xfi[0]+qm_err_count_xfi[1]+qm_err_count_xfi[2]+qm_err_count_xfi[3]==0) {
    if(total_err_count_xfi[0])
    {printf("\tXFI-10G Port-0 - [FAIL] \n");}
    else
    {printf("\tXFI-10G Port-0 - [PASS] \n");}

    printf("\n");	

    if(total_err_count_xfi[1])
    {printf("\tXFI-10G Port-1 - [FAIL] \n");}
    else
    {printf("\tXFI-10G Port-1 - [PASS] \n");}

    printf("\n");

    if(total_err_count_xfi[2])
    {printf("\tXFI-10G Port-2 - [FAIL] \n");}
    else
    {printf("\tXFI-10G Port-2 - [PASS] \n");}

    printf("\n");

    if(total_err_count_xfi[3])
    {printf("\tXFI-10G Port-3 - [FAIL] \n");}
    else
    {printf("\tXFI-10G Port-3 - [PASS] \n");}

    printf("\n");
    }


    if(total_err_count_xfi[0]>0 || total_err_count_xfi[1]>0)
        printf("\nTest Result : FAIL\n");
    else {
	if(total_err_count_xfi[2]>0 || total_err_count_xfi[3]>0) {
		printf("\nTest Passes for XGE-0 & XGE-1. (Ignoring failure on XGE-2/XGE-3)");
        	printf("\n\nTest Result : PASS\n");
	}
    }
    if(total_err_count_xfi[0]==0 && total_err_count_xfi[1]==0 && total_err_count_xfi[2]==0 && total_err_count_xfi[3]==0) {
	printf("\nTest Passes for all 4 XFI_10G ports.");
        printf("\n\nTest Result : PASS\n");
    }

}

void send_pause_frame_xg(int port ) {
    int display = 0;
    int it;
    int bypass_en,drop_data;

    eth_wr(SM_XGENET_CSR_DEBUG_REG__ADDR,0x3e03ee,XGENET,port,display); 
    bypass_en = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
    bypass_en = bypass_en | 0x80000000;
    eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,bypass_en,XGENET,port,display); 

    drop_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG4__ADDR,XGENET,port,display);
    drop_data = drop_data | 0x00000001;
    eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG4__ADDR,drop_data,XGENET,port,display); 


    eth_wr(SM_XGENET_MCXMAC_CSR_CSR_ECM_CFG_0__ADDR, 0x08000005,XGENET,port,display);

    //  for (it = 0 ; it < 1000; it++);

    // bypass_en = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,XGENET,port,display);
    // bypass_en = bypass_en & 0x7fffffff;
    // eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,bypass_en,XGENET,port,display); 
    // drop_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG4_0__ADDR,XGENET,port,display);
    // drop_data = drop_data & 0xfffffffe;
    // eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_0__ADDR,drop_data,XGENET,port,display); 

    //#ifdef CONFIG_XGENET_RX2TSO_TX_LPBK 
    //    eth_wr(SM_XGENET_CSR_DEBUG_REG__ADDR,0x3e03fe,XGENET,port,display); 
    //#endif  

}
int link_status_xg(){
    int an_sts;
    an_sts = lnk_sts_xg(FIRST_PORT,LAST_PORT,1);
    return an_sts;
}

int lnk_sts_xg(int srt_port, int end_port, int display){
    int tmp;
    int link = 0;
    int an_done = 0;
    int an_comp = 0;
    int port;
    int intf;
    int an_sts = 0;
    int  read_data;
    //-----------------------------------
    // Print Final Link Status
    //-----------------------------------
    for (port=srt_port;port<=end_port;port++) {
        if(display)printf("\n\r\n\r======== Link Status : Port%d ==========\n\r", port);
        link, an_done = 0;
        read_data = mdio_rd(0x1e01,XGENET,port,0);
        link    = (read_data >> 2) & 0x1;
        an_comp = (read_data >> 5) & 0x1;
        an_done = an_en_xg ? an_comp : link;
        int my_loop = 1000;
        while((my_loop > 0) && an_done) {
            read_data = mdio_rd(0x1e01,XGENET,port,0);
            link    = ((read_data >> 2) & 0x1) && link;
            an_comp = ((read_data >> 5) & 0x1) && an_comp;
            an_done = an_en_xg ? an_comp : link;
            my_loop--;
        }
        if(display)printf("Autonegotiation %s complete %s\n\r", an_comp ? "" : "NOT",an_en_xg ? "" : " : NON-AUTONEG MODE");
        if(display)printf("Link Status : %s \n\r", link == 1 ? "UP" : "DOWN");
        if(an_en_xg)
            if(display) printf("Link Parameters : 0x%x \n\r\n\r", mdio_rd(0x1e05,XGENET,port,0));

        //printf("Link Status after %d iterations \n\r", itr_count[port]);

        tmp =   eth_rd(SM_XGENET_CSR_LINK_STATUS__ADDR,XGENET,port,display) & 0x1;
        if(gating_bypass) {
            eth_wr(SM_XGENET_CSR_CFG_LINK_AGGR_RESUME_0__ADDR,0x00000001,XGENET,port,0);
            eth_wr(SM_XGENET_MCXMAC_CSR_RX_DV_GATE_REG_0__ADDR,0x0,XGENET,port,0);
            an_sts = an_sts | (an_done << port);
        } else if(tmp != 0) {
            eth_wr(SM_XGENET_CSR_CFG_LINK_AGGR_RESUME_0__ADDR,0x00000001,XGENET,port,0);
            eth_wr(SM_XGENET_MCXMAC_CSR_RX_DV_GATE_REG_0__ADDR,0x7,XGENET,port,0);
            an_sts = an_sts | (an_done << port);
        } else {
            printf("Port%d : Traffic GATED\n",port);
        }
        eth_rd(SM_XGENET_CSR_LINK_STATUS__ADDR,XGENET,port,display);
        eth_rd(SM_XGENET_CSR_LINK_STS_INTR__ADDR,XGENET,port,display);
    }

    return an_sts;
}


int vco_status_xg(int inst, int display) {
    int rd_val,pll_ready,pll_lock,vco_calibration,tx_ready,rx_ready;
    int pll_det;
    int vco_cal_fail;

    //rd_val = enet_sds_ind_csr_reg_rd("CMU_reg7", CMU + 2*7,XGENET,inst,1);
    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg7", CMU + 2*7,XGENET,inst,0);//Changed display to '0'

    //pll_ready = FIELD_SATA_ENET_SDS_CMU_STATUS0_CFG_CMU_O_PLL_READY_RD(rd_val);
    pll_lock        = (rd_val >> 15) & 0x1;
    vco_calibration = (rd_val >> 14) & 0x1;
    pll_det         = (rd_val >> 12) & 0x3;
    vco_cal_fail    = (rd_val >> 10) & 0x3;
    if(display){
        //printf("XGENET%d  VCO_CALIB: PLL is %sREADY\n", inst, pll_ready ? "" : "not ");
        printf("XGENET%d  VCO_CALIB: PLL %sLOCKed\n", inst, pll_lock ? "" : "not ");
        printf("XGENET%d  VCO_CALIB: PLL VCO Calibration %s\n", inst,  vco_calibration ? "DONE" : "not done");
        printf("XGENET%d  VCO_CALIB: PLL VCO Calibration %s : 0x%x\n", inst,  vco_cal_fail == 0 ? "NO FAILURE" : "FAILED",vco_cal_fail);
        printf("XGENET%d  VCO_CALIB: PLL DET : %d\n", inst, pll_det);
    }

    return (((vco_cal_fail<<3) | (pll_det<<1) | (pll_lock == 0))); 

}

/*
   void momsel_sweep_xg(){
   int port = 0;
   int iter = 0;
   int delay = 0;
   int an_sts;
   int momsel_sts;
   int abrt_cnd;
   int max_itr;
   int i,j;
   int momsel_count[64][4];
   for(i=0; i < 64; i++){
   for(j=0; j < 64; j++){
   momsel_count[i][j] = 0;
   }
   }

   max_itr = my_get_val_xfi("\nNumber of iterations per momsel: 0x"); 
   for(i=0; i < 32; i++) {
   vco_momsel_init = i;

   for(iter=0; iter < max_itr; iter++){
// Reconfigure XGENET // kchidvil
for(port=FIRST_PORT; port <=LAST_PORT; port++)
init_xgenet(port,0);
an_sts = link_status_xg();
for(port=FIRST_PORT; port <=LAST_PORT; port++){
if(((an_sts >> port) & 0x1) == 1)
momsel_count[vco_momsel_init][port]++;
}
}

for(delay=0; delay < 10000; delay++);
}
printf("\n\r\n\r======== MOMSEL SWEEP RESULT  ==========\n\r");
for(i=0; i < 64; i++) {
printf("[MOMSEL %x out of %d] : \t %d \t %d \t %d \t%d\n\r",i,max_itr,momsel_count[i][0],momsel_count[i][1],momsel_count[i][2],momsel_count[i][3]);
}
}
*/

void enable_an_xg(){
    int display = 0;
    int delay;
    int port;
    an_en_xg = 1;

    for(port =FIRST_PORT; port <= LAST_PORT ; port++) {
        mdio_wr(0x1e00,0x9140,XGENET,port,display);
    }
    for(delay=0;delay<10000;delay++);
    link_status_xg();
}


int configure_sgmii_xg(int port, int display, unsigned int reconfig_count){
    int link, an_comp, an_done = 0;
    int pass_cnt = 0;
    int  read_data;
    // int reconfig_count = 20;
    itr_count[port] = 0;
    if(an_en_xg) 
        mdio_wr(0x1e00,0x9140,XGENET,port,display); // Enable Auto Neg
    else
        mdio_wr(0x1e00,0x8140,XGENET,port,display); // Non Auto Neg

    do {
        int loop = 100;
        int ext_link,speed;
        int loop_var = 0;
        link =0;
        an_done = 0;
        do {
            int timeout;
            link, an_done = 0;
            read_data = mdio_rd(0x1e01,XGENET,port,display);
            link    = (read_data >> 2) & 0x1;
            an_comp = (read_data >> 5) & 0x1;
            loop_var = an_en_xg ? an_comp : link;
            if(loop_var) {
                pass_cnt++;
                printf("?");
                an_done = (pass_cnt == 100);
            }
            else {
                pass_cnt = 0;
                loop--;
            }
            for(timeout=0;timeout<8000;timeout++);
        }while(((loop != 0) && (an_done == 0) && (pass_cnt == 0)) || ((pass_cnt != 0 ) && (an_done == 0)));

        read_data = mdio_rd(0x1e05,XGENET,port,display);
        ext_link = (read_data >> 15) & 0x1;
        mac_mode = (read_data >> 10) & 0x3;
        if(display) {
            printf("Autonegotiation %s complete %s\n\r", an_done ? "" : "NOT" ,an_en_xg ? "" : " : NON-AUTONEG MODE");
            printf("Link Status : %s \n\r", link == 1 ? "UP" : "DOWN");
            if(an_en_xg){
                printf("Link Parameters : 0x%x \n\r", read_data);
                if(link == 1) printf("Speed = %x \n\r", mac_mode);
            }
        }
        reconfig_count--;
        itr_count[port]++;

        if(an_done == 0 & reconfig_count != 0) {
            int timeout;
            int rd_val, wr_val;
            int momsel;
            printf(".");

            mdio_wr(0x00001e11,0x8000,XGENET,port,0); //Soft Reset
            serdes_reset_rxd_rxa_xg(XGENET,port,0);
            mdio_wr(0x00001e11,0x0000,XGENET,port,0);
            // init_enet_serdes();
            for(timeout=0;timeout<100000;timeout++);
        }
        else {
            printf("\n\r---------------------------------------- \n\r");
            printf("\t Autonegotiation %s complete \n\r", an_done ? "" : "NOT");
            printf("\t Link Status Port%x: %s \n\r", port, link == 1 ? "UP" : "DOWN");
            printf("\t Link Parameters : 0x%x \n\r", read_data);
            printf("\t Speed = %s mbps\n\r", (mac_mode == 2) ? "1000" : ((mac_mode == 1) ? "100" : "10"));
            printf("Interation Count : %d\n\r", (reconfig_loop - reconfig_count));
            printf("---------------------------------------- \n\r");
            if(ext_link == 1){
                // printf("Configure MAC/SGMII as per new speed : %s mbps\n\r", (mac_mode == 2) ? "1000" : ((mac_mode == 1) ? "100" : "10"));
                eth_reg_wr_mode(SM_XGENET_MCXMAC_CSR_ICM_CONFIG0_REG_0__ADDR,0x0008503f,0x0004503f,0x0000503f,XGENET,port,display);  //ICM_CONFIG0_REG_0 -- MacMode[12:13]:0=10M,1=100M,2=1G
                eth_reg_wr_mode(SM_XGENET_MCXMAC_CSR_ICM_CONFIG2_REG_0__ADDR,0x0001000f,0x00010050,0x000101f4,XGENET,port,display);  // ICM_Config2_reg_0 -Async read  //AXI freq  => 100MHz
                //mcxmac_ind_wr_mode(PE_MCXMAC_MAC_CONFIG_2__ADDR,     0x00005211,0x00006111,0x00007111,XGENET,port,display);//FD,frm_len,mac)inf:nible vs byte
                mcxmac_ind_wr_mode(PE_MCXMAC_MAC_CONFIG_2__ADDR,     0x00005235,0x00006111,0x00007111,XGENET,port,display);//FD,frm_len,mac)inf:nible vs byte
                mcxmac_ind_wr_mode(PE_MCXMAC_INTERFACE_CONTROL__ADDR,0x04000000,0x02000000,0x00000000,XGENET,port,display); // MAC mode - 1g,100m,10m
                eth_wr(SM_XGENET_CSR_CFG_LINK_AGGR_RESUME_0__ADDR,0x00000001,XGENET,port,display);
                if(gating_bypass)
                    eth_wr(SM_XGENET_MCXMAC_CSR_RX_DV_GATE_REG_0__ADDR,0x0,XGENET,port,display);
                else
                    eth_wr(SM_XGENET_MCXMAC_CSR_RX_DV_GATE_REG_0__ADDR,0x7,XGENET,port,display);

            }
        }
    } while(an_done == 0 & reconfig_count != 0);
    return an_done;
}
void help_xg( ) {

    printf("\n");
    printf("ONE-STEP: eth_rx2tx        - Main function for Complete Initialization \n");
    printf("\n");
    printf("OPTIONAL : set_calib_xg    - Change Calibration Mode (NOT WORKING :x FIXME \n");
    printf("OPTIONAL : print_calib_xg  - Prints Serdes Calibration settings \n\n");

    printf("OPTIONAL : rst_sds_xg      - Reset Serdes \n");
    printf("OPTIONAL : rst_sds_rxa_xg  - Reset Serdes All 4 port Analog only\n");
    printf("OPTIONAL : rst_sds_rxda_xg - Reset Serdes All 4 port Digital and Analog\n");

    printf("OPTIONAL : pll_status_xg   - Prints PLL status of both Instances \n");
    printf("OPTIONAL : link_status_xg  - Prints Link Status of four ports\n");
    printf("OPTIONAL : mac_stat_xg     - Prints MAC  Statistics of four ports\n");
    printf("OPTIONAL : print_stat_xg   - Prints Full Statistics \n");

    printf("OPTIONAL : fix_crc_xg      - Fixes CRC error by reseting serdes \n");
    /* printf("OPTIONAL : go enable_an_xg <PORT_NUM>      - Port based AN Restart/Enable \n"); */
    printf("OPTIONAL : go enable_an_xg                 - All Ports AN Restart/Enable \n");
    /* printf("OPTIONAL : go cleanup_crc_xg <PORT_NUM>    - Port based Fixes CRC error by reseting serdes \n"); */
    /* printf("OPTIONAL : go set_reconfig_loop_xg <VALUE> - Set number of times Serdes reset is asserted before timeout. USE 0 for 0xFFFF_FFFF \n"); */
    printf("OPTIONAL : go set_reconfig_loop_xg         - Set number of times Serdes reset is asserted before timeout to  0xFFFF_FFFF \n");
    printf("\n");
    printf("ADVANCED : toggle_adv_xg   - Toggle Advance Debug Mode. Default disabled.\n");
    printf("ADVANCED : reg_full_config_xg - Runs 200 iterations of init_enet.\n");
    printf("\n");
    printf("\n");


}

#if 0
void reg_full_config_xg(){
    int port = 0;
    int iter = 0;
    int delay = 0;
    int an_fail_count[4];
    int momsel_count_sml[4];
    int an_sts;
    int momsel_sts;
    int abrt_cnd;
    int max_itr;
    int i,j;
    int momsel_count[64][4];
    int momsel_count_pass[64][4];
    for(i=0; i < 64; i++){
        for(j=0; j < 64; j++){
            momsel_count[i][j] = 0;
            momsel_count_pass[i][j] = 0;
        }
    }
    for(port=FIRST_PORT; port <= LAST_PORT; port++) {
        an_fail_count[port] = 0;
        momsel_count_sml[port] = 0;
    }
    printf("Select abort condition : 0=any down , Num = that port up\n");
    abrt_cnd = get_val();
    max_itr = my_get_val_xfi("\nNumber of iterations: 0x"); 
    for(iter=0; iter < max_itr; iter++) {
        // Reconfigure XGENET // kchidvil
        init_xgenet(3,0);
        // for(port=FIRST_PORT; port <=LAST_PORT; port++)
        //   init_xgenet(port,0);

        an_sts = link_status_xg();
        for(port=FIRST_PORT; port <= LAST_PORT; port++){
            if(((an_sts >> port) & 0x1) == 0)
                an_fail_count[port]++;
        }
        momsel_sts = print_calib_xg();
        for(port=FIRST_PORT; port <=LAST_PORT; port++){
            int momsel_port = (momsel_sts >> ((port)*8)) & 0x3f;
            momsel_count_pass[momsel_port][port]++;
        }
        if(an_sts != 0xf)  { // kchidvil Any port down
            // if((an_sts|0x3) != 0xf) { // P2 P3 down
            //if((an_sts|0xc) != 0xf) { // P0 P1 down
            //if((an_sts & 0x3) != 0x0) { // P0 P1 up
            for(port=FIRST_PORT; port <=LAST_PORT; port++){
                int momsel_port = (momsel_sts >> ((port)*8)) & 0x3f;
                if(((an_sts >> port) & 0x1) != 0x1) {
                    if((((momsel_port & 0x11) != 0x11) && ((momsel_port & 0x12) != 0x12)))
                        momsel_count_sml[port]++;

                    momsel_count[momsel_port][port]++;
                }
            }
            vco_status_xg(0x0,0x1);
            vco_status_xg(0x2,0x1);
#if 0
            if(my_get_val_xfi("Press 0=Continue iteration\n\r")) {
                while(my_get_val_xfi("Press 0=Continue iteration else enter reset sds\n\r")) {
                    if(my_get_val_xfi("Press 0=Continue reset sds else break\n\r"))     
                        break;
                    rst_sds();
                }
            }
#endif
        }
        if(abrt_cnd == 0 &&  an_sts != 0xf){
            return 0;

        }
        else if((abrt_cnd & an_sts) != 0){
            return 0;
        }
        }
        printf("\n\r\n\r======== AN Regression Status  ==========\n\r");
        for(port=FIRST_PORT; port <= LAST_PORT; port++) {
            printf("[PORT%d] : %d/%d   Momsel count: %d\n\r",port,an_fail_count[port],iter,momsel_count_sml[port]);
        }

        for(i=0; i < 64; i++) {
            if(max_itr,momsel_count[i][0]||momsel_count[i][1]||momsel_count[i][2]||momsel_count[i][3])
                printf("[MOMSEL FAILED 0x%x:[%d]] : \t %d \t %d \t %d \t%d\n\r",i,max_itr,momsel_count[i][0],momsel_count[i][1],momsel_count[i][2],momsel_count[i][3]);
        }
        printf("\n\r\n\r");
        for(i=0; i < 64; i++) {
            if(momsel_count_pass[i][0] || momsel_count_pass[i][1] || momsel_count_pass[i][2] || momsel_count_pass[i][3])
                printf("[MOMSEL Calib 0x%x :[%d]] : \t %d \t %d \t %d \t%d\n\r",i,max_itr,momsel_count_pass[i][0],momsel_count_pass[i][1],momsel_count_pass[i][2],momsel_count_pass[i][3]);
        }

        print_calib_xg();

        for(delay=0; delay < 10000; delay++);
        printf("done\n\r\n\r");

        }

#endif	// End of void reg_full_config_xg()

        void fix_crc_xg(){
            int temp, intf, port;
            int display = 0;
            //temp = my_get_val_xfi("select port 0/1/2/3");
            //intf = temp & 0x2;
            //port = temp & 0x3;
            printf("\n\n==============================\n");
            printf("=====CLEAN XFI-SGMII CRC ERROR==========\n");
            printf("==============================\n");

            for(port=FIRST_PORT;port<=LAST_PORT;port++)
                cleanup_crc_xg(port);
        }

        void cleanup_crc_xg(int port){
            int num_pkt = 0;
            int fcs_err;
            int loop = 50;
            int an_sts;
            int temp;

            printf("XGENET%d CRC Cleanup Link Status Check \n", port);  
            if(((lnk_sts_xg(port,port,0) >> port) & 0x1)  != 0x1)
                temp = configure_sgmii_xg(port,0, reconfig_loop);
            else
                temp = 1;
            if(temp == 0) {
                printf("AN FAIL Aborting for PORT%d\n\n ",port);
                return ;
            }


            while(loop){
                // // Clean Statistics
                // mcxmac_stat_rd(PEMSTAT_RPKT__ADDR,port);
                // mcxmac_stat_rd(PEMSTAT_RFCS__ADDR,port);

                // Accummulate Stats
                printf("Waiting for Packets on Port%d\n",port);
                while(num_pkt < 100000) {
                    num_pkt = num_pkt +  mcxmac_stat_rd(PEMSTAT_RPKT__ADDR,port);
                    if(((lnk_sts_xg(port,port,0) >> port) & 0x1)  != 0x1) {
                        printf("AN FAIL Aborting for PORT%d\n",port);
                        break ;
                    }
                }
                fcs_err = mcxmac_stat_rd(PEMSTAT_RFCS__ADDR,port);
                printf("PEMSTAT_RFCS%d : %d\n",port,fcs_err);

                if(fcs_err) {
                    printf("CRC-Check-FAILED-XFI-SGMII-GE-%d\n",port);
                    mdio_wr(0x00001e11,0x8000,XGENET,port,0);
                    serdes_reset_rxd_rxa_xg(XGENET,port,0);
                    temp = configure_sgmii_xg(port,0x0, reconfig_loop);
                    if(temp==0) break;
                    num_pkt = 0;
                }
                else {
                    printf("CRC-Check-PASSED-XFI-SGMII-GE-%d\n",port);
                    return;
                }
                loop--;
            }
            printf("Port%d is NOT CRC clean, TIMEOUT \n\n",port);
        }

        /*
           void set_calib_xg(){
           pll_manualcal = my_get_val_xfi("Select Calibration Mode (0:AutoCalib 1:Manual) : ");
           vco_momsel_init = my_get_val_xfi("Select Momsel init value : 0x");
           printf("\nCalibration mode changed to %s \n", pll_manualcal ? "MANUAL" : "AUTOMATIC");
           printf("Please Reconfigure Serdes .....\n");
           }
           */

        int print_calib_xg(){
            int port=0;
            int rd_val;
            int ret_val = 0;
            for(port = FIRST_PORT ; port <= LAST_PORT ; port++) {
                rd_val = enet_sds_ind_csr_reg_rd("CMU_reg3", CMU + 2*3,XGENET,port,1);
                rd_val = (rd_val & 0x3f0 ) >> 4;
                printf("Inst%d MAN Momsel init = 0x%x\n",port,rd_val);
                rd_val = enet_sds_ind_csr_reg_rd("CMU_reg19", CMU + 2*19,XGENET,port,1);
                rd_val = (rd_val & 0xfc00 ) >> 10;
                printf("Inst%d Momsel Calib = 0x%x\n",port,rd_val);
                ret_val = ret_val | (rd_val << port*8);
                ret_val = ret_val | (rd_val << (port+1)*8);
            }
            return ret_val; // kchidvil : 18 June 2013
        }
        void mac_stat_xg(){
            int port = 0;
            for(port=FIRST_PORT; port <= LAST_PORT; port++){
                printf("-------Port%d----------\n",port);
                printf("PEMSTAT_RPKT__ADDR : %d \n",mcxmac_stat_rd(PEMSTAT_RPKT__ADDR,port));
                printf("PEMSTAT_TPKT__ADDR : %d \n",mcxmac_stat_rd(PEMSTAT_TPKT__ADDR,port));
                printf("PEMSTAT_RFCS__ADDR : %d \n",mcxmac_stat_rd(PEMSTAT_RFCS__ADDR,port));
                printf("PEMSTAT_TFCS__ADDR : %d \n",mcxmac_stat_rd(PEMSTAT_TFCS__ADDR,port));
                printf("\n");
            }
        }

        void pll_status_xg() {
            int rd_val,pll_ready,pll_lock,vco_calibration,tx_ready,rx_ready;
            int inst;
            int eth_type = XGENET;
            for(inst=FIRST_PORT; inst <= LAST_PORT ; inst++) {

                rd_val = eth_rd(SM_XGENET_SDS_CSR_REGS_XGENET_SDS_CMU_STATUS0__ADDR,eth_type,inst,0x1); 
                pll_ready = FIELD_XGENET_SDS_CMU_STATUS0_CFG_CMU_O_PLL_READY_RD(rd_val);
                pll_lock = FIELD_XGENET_SDS_CMU_STATUS0_CFG_CMU_O_PLL_LOCK_RD(rd_val);
                vco_calibration = FIELD_XGENET_SDS_CMU_STATUS0_CFG_CMU_O_VCO_CALDONE_RD(rd_val);
                printf("XGENET%d INIT_SERDES : PLL is %sREADY\n", inst,  pll_ready ? "" : "not ");
                printf("XGENET%d INIT_SERDES : PLL %sLOCKed\n", inst,  pll_lock ? "" : "not ");
                printf("XGENET%d INIT_SERDES : PLL VCO Calibration %s\n", inst, inst+1, vco_calibration ? "Successful" : "not Successful");
                printf("XGENET%d INIT_SERDES : Check TX/RX Ready\n", inst);
                rd_val = eth_rd(SM_XGENET_SDS_CSR_REGS_XGENET_SDS_RXTX_STATUS__ADDR,eth_type,inst,0x1); 
                tx_ready = FIELD_XGENET_SDS_RXTX_STATUS_CFG_TX_O_TX_READY_RD(rd_val);
                rx_ready = FIELD_XGENET_SDS_RXTX_STATUS_CFG_RX_O_RX_READY_RD(rd_val);
                printf("XGENET%d INIT_SERDES : TX is %sready\n", inst,  tx_ready ? "" : "not ");
                printf("XGENET%d INIT_SERDES : RX is %sready\n\n", inst,  rx_ready ? "" : "not ");

                vco_status_xg(inst,0x1);

            }

        }

        void rst_sds_rxa_xg(){
            int port;
            for(port = FIRST_PORT; port <= LAST_PORT ; port++){
                printf(" Port%d Serdes analog Reset ...\n",port);

                mdio_wr(0x00001e11,0x8000,XGENET,port,0);
                serdes_reset_rxa_xg(XGENET,port,0x0);
                mdio_wr(0x00001e11,0,XGENET,port,0);
                configure_sgmii_xg(port,0x0, reconfig_loop);
            }
        }
        void rst_sds_rxda_xg(){
            int port;
            for(port =FIRST_PORT; port <= LAST_PORT ; port++) {
                mdio_wr(0x00001e11,0x8000,XGENET,port,0);
                serdes_reset_rxd_rxa_xg(XGENET,port,0);
                mdio_wr(0x00001e11,0x0000,XGENET,port,0);
                printf(" Port%d Serdes Digital analog Reset ...\n",port);
                configure_sgmii_xg(port,0x0, reconfig_loop);
            }
        }

        void rst_sds_xg(){
            int temp, intf, port;
            int display = 0;
            temp = my_get_val_xfi("select port 0/1/2/3");
            intf = temp & 0x2;
            port = temp & 0x3;

            temp = my_get_val_xfi("select : 0-Analog Only \t 1-Digital and Analog");

            mdio_wr(0x00001e11,0x8000,XGENET,port,0);

            if(temp == 0) 
                serdes_reset_rxa_xg(XGENET,port,0x0);
            else 
                serdes_reset_rxd_rxa_xg(XGENET,port,0);

            mdio_wr(0x00001e11,0x0000,XGENET,port,0);
        }

        void rst_sds_port_xg(int port){
            int display = 0;
            int delay;

            mdio_wr(0x00001e11,0x8000,XGENET,port,0);
            serdes_reset_rxa_xg(XGENET,port,0x0);
            for(delay=0;delay<10000;delay++);
            configure_sgmii_xg(port,0x0, reconfig_loop);
        }

        void toggle_adv_xg(){
            advanced_debug_xg = advanced_debug_xg^0x1;
        }
        void set_basex_xg(){
            int  port  =0;
            an_en_xg =1;
            mdio_wr(0x00001e11,0x8000,XGENET,port,0);
            mdio_wr(0x00001e04,0x0040,XGENET,port,0);
            configure_sgmii_xg(port,0x0, 1);
        }

        void set_sgmii_xg(){
            int  port  =0;
            an_en_xg =1;
            //eth_wr(SM_XGENET_CSR_RGMII_SGMII_REG_0__ADDR, ,XGENET,port,0);
            mdio_wr(0x00001e11,0x8000,XGENET,port,0);
            mdio_wr(0x00001e04,0x9801,XGENET,port,0);
            configure_sgmii_xg(port,0x0, 1);
        }
        void set_reconfig_loop_xg(){
            printf("reconfig_loop was %d\n",reconfig_loop);
            reconfig_loop = 0;
            printf("reconfig_loop = %d\n",reconfig_loop);
        }
        void print_stat_xg() {
            printf("Select port to print Statistics : ");
            read_statistics_mcxmac(get_val());
        }

        int axgmac_stat_rd(int offset , int port){
            int read_data;
            int i,j;
            int counter = 0;
            int display = 0;

            eth_wr( SM_XGENET_AXGMACIP_IND_CSR_STAT_IND_ADDR_0__ADDR, offset , XGENET,port,display);
            eth_wr(SM_XGENET_AXGMACIP_IND_CSR_STAT_IND_COMMAND_0__ADDR,0x40000000,XGENET,port,display);
            do {
                read_data = eth_rd(SM_XGENET_AXGMACIP_IND_CSR_STAT_IND_COMMAND_DONE_0__ADDR,XGENET,port,display);
                counter++;
            } while (read_data != 0x00000001 && counter != MAX_INDCMD_DONE_COUNTER);

            if(read_data != 0x1) { printf("ERROR : XGENET_INDIRECT AXGMAC WR timeout");printf("\n\r"); }

            eth_wr(SM_XGENET_AXGMACIP_IND_CSR_STAT_IND_COMMAND_0__ADDR, 0x0,XGENET,port,display);
            read_data = eth_rd(SM_XGENET_AXGMACIP_IND_CSR_STAT_IND_RDATA_0__ADDR,XGENET,port,display);

            return read_data;
        }

        int my_get_val_xfi(char *str){
            int val;
            printf(str);
            val = get_val();
            printf("\n\r");
            return val;
        }

        void stat(){

            read_statistics_axgmac(0);
            read_statistics_axgmac(1);
            read_statistics_axgmac(2);
            read_statistics_axgmac(3);

        }

        void wm(){
            err_info_t ei;

            qm_dump_pb_state(0, 0, 0); // P01, WQ0
            qm_dump_pb_state(0, 0, 8); // P01, WQ8
            qm_dump_pb_state(0, 0, 32); // P01, FQ0
            qm_dump_pb_state(0, 0, 33); // P01, FQ8
            qm_dump_pb_state(0, 0, 34); // P01, FQ0
            qm_dump_pb_state(0, 0, 35); // P01, FQ8

            qm_dump_pb_state(0, 1, 0); // P23, WQ0
            qm_dump_pb_state(0, 1, 8); // P23, WQ8
            qm_dump_pb_state(0, 1, 32); // P23, FQ0
            qm_dump_pb_state(0, 1, 33); // P23, FQ8
            qm_dump_pb_state(0, 1, 34); // P23, FQ0
            qm_dump_pb_state(0, 1, 35); // P23, FQ8

            qm_dump_qstate(0, 4, 0);
            qm_dump_qstate(0, 4, 32);
            //qm_dump_qstate(1, 4, 64);


            /*
               printf("\nQMI Status Reg Dump:\n");
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIFPPTR0__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIFPPTR1__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIFPPTR2__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIFPPTR3__ADDR,ENET,port,1);
               printf("\n");
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIFPNUMENTRIES0__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIFPNUMENTRIES1__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIFPNUMENTRIES2__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIFPNUMENTRIES3__ADDR,ENET,port,1);
               printf("\n");
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIWQPTR0__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIWQPTR1__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIWQPTR2__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIWQPTR3__ADDR,ENET,port,1);
               printf("\n");
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES0__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES1__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES2__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES3__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES4__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES5__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES6__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES7__ADDR,ENET,port,1);
               printf("\n");
               */


            // qm_dump_pb_state(0, 0, 0);
            // qm_dump_pb_state(0, 0, 0x21);
            // qm_dump_qstate(0, 2, 32);
            // qm_dump_qstate(0, 1, 1);
            /*
               printf("\r\n ---- QM-0 queue state dump:\r\n"); 
               qm_dump_qstate(0, 4, 32);
               qm_dump_qstate(0, 1, 1);
               printf("\r\n ---- QM-2 queue state dump:\r\n"); 
               qm_dump_qstate(2, 4, 32);
               qm_dump_qstate(2, 1, 1);
               */
            // printf("\r\n ---- QM1 queue statedump:\r\n"); 
            // qm_dump_pb_state(1, 0, 0);
            // qm_dump_pb_state(1, 0, 8);
            // qm_dump_pb_state(1, 1, 0);
            // qm_dump_pb_state(1, 1, 8);
            // qm_dump_qstate(1, 4, 32);
            // qm_dump_qstate(1, 1, 1);

            //qm_chk_errq(0, &ei);
            //qm_dump_qstate(0, 1, QM_ERROR_QID);
            //qm_dump_qstate(0, 1, QM_E_ERROR_QID);
            //qm_dump_qm_errq(1);
            //qm_err_dump(1);

        }

        //gen_avg_val() related code added as per Chidvilas comment ...
        //void gen_avg_val(){
        void gen_avg_val_xfi(int port){
            int avg_loop,max_loop_1;
            int MAX_LOOP = 10;
            int timeout = 20;
            int lat_do,lat_xo,lat_eo,lat_so;
            int lat_de,lat_xe,lat_ee,lat_se;
            int sum_cal = 0;
            int lat_do_itr,lat_xo_itr,lat_eo_itr,lat_so_itr;
            int lat_de_itr,lat_xe_itr,lat_ee_itr,lat_se_itr;
            int sum_cal_itr = 0;
            int data32;
            int display =0;
            //int port;//Commented by Hrishikesh -- Temp
            int pcs_rxfault = 0;
            int pcs_txfault = 0;
            int fail_even = 0;
            int fail_odd = 0;
            uint32_t inst, inst_base;
            unsigned int  wr_val, rd_val;

            printf("\n\nGenerating Average calibration Value for XFI ports :\n");//Added by Hrishikesh

            //for(port=0;port<4;port++) {

            lat_do_itr = 0;lat_de_itr = 0;
            lat_xo_itr = 0;lat_xe_itr = 0;
            lat_eo_itr = 0;lat_ee_itr = 0;
            lat_so_itr = 0;lat_se_itr = 0;
            sum_cal_itr = 0;

            lat_do = 0;lat_de = 0;
            lat_xo = 0;lat_xe = 0;
            lat_eo = 0;lat_ee = 0;
            lat_so = 0;lat_se = 0;

            sum_cal   = 0;
            avg_loop  = MAX_LOOP;
            max_loop_1 = 20;

            //printf("\n Generating Average calibration Value for Port %d \n",port);//Commented by Hrishikesh
            printf("[XGE-%d ",port);//Added by Hrishikesh

            inst = 0;
            inst_base = 0x0400 + inst*0x0200;
            // Enable RX Hi-Z termination enable
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg12", inst_base + 12*2,XGENET,port,display);
            wr_val = sm_enet_set(rd_val,1, 1, 1);
            enet_sds_ind_csr_reg_wr("rxtx_reg12", inst_base + 12*2, wr_val,XGENET,port,display);
            // Turn off DFE 
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg28", inst_base + 28*2,XGENET,port,display);
            wr_val = sm_enet_set(rd_val, 0x0, 15, display);
            enet_sds_ind_csr_reg_wr("rxtx_reg28", inst_base + 28*2, wr_val,XGENET,port,display);
            // DFE Presets to zero 
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg31", inst_base + 31*2,XGENET,port,display);
            wr_val = sm_enet_set(rd_val, 0x0, 15, display);
            enet_sds_ind_csr_reg_wr("rxtx_reg31", inst_base + 31*2, wr_val,XGENET,port,display);


            while (avg_loop > 0) {
                //force_lat_summer_cal(XGENET,port,0);
                force_lat_summer_cal_xg(XGENET,port,0);
                //for(timeout=0; timeout<0x4000000; ++timeout);
			//printf("\ngen_avg_val delay - 1 ...");
			USDELAY(500000);
			//printf(" Done");
                //data32 = enet_sds_ind_csr_reg_rd("RXTX_REG21", KC_SERDES_RXTX_REGS_RXTX_REG21__ADDR,XGENET,port,display);
                data32 = enet_sds_ind_csr_reg_rd("RXTX_REG21", inst_base + 21*2,XGENET,port,display);
                lat_do_itr = FIELD_RXTX_REG21_DO_LATCH_CALOUT_RD(data32);
                lat_xo_itr = FIELD_RXTX_REG21_XO_LATCH_CALOUT_RD(data32);
                fail_odd   = FIELD_RXTX_REG21_LATCH_CAL_FAIL_ODD_RD(data32);

                //data32 = enet_sds_ind_csr_reg_rd("RXTX_REG22", KC_SERDES_RXTX_REGS_RXTX_REG22__ADDR,XGENET,port,display);
                data32 = enet_sds_ind_csr_reg_rd("RXTX_REG22", inst_base + 22*2,XGENET,port,display);
                lat_eo_itr = FIELD_RXTX_REG22_EO_LATCH_CALOUT_RD(data32);
                lat_so_itr = FIELD_RXTX_REG22_SO_LATCH_CALOUT_RD(data32);
                fail_even  = FIELD_RXTX_REG22_LATCH_CAL_FAIL_EVEN_RD(data32);

                //data32 = enet_sds_ind_csr_reg_rd("RXTX_REG23", KC_SERDES_RXTX_REGS_RXTX_REG23__ADDR,XGENET,port,display);
                data32 = enet_sds_ind_csr_reg_rd("RXTX_REG23", inst_base + 23*2,XGENET,port,display);
                lat_de_itr = FIELD_RXTX_REG23_DE_LATCH_CALOUT_RD(data32);
                lat_xe_itr = FIELD_RXTX_REG23_XE_LATCH_CALOUT_RD(data32);

                //data32 = enet_sds_ind_csr_reg_rd("RXTX_REG24", KC_SERDES_RXTX_REGS_RXTX_REG24__ADDR,XGENET,port,display);
                data32 = enet_sds_ind_csr_reg_rd("RXTX_REG24", inst_base + 24*2,XGENET,port,display);
                lat_ee_itr = FIELD_RXTX_REG24_EE_LATCH_CALOUT_RD(data32);
                lat_se_itr = FIELD_RXTX_REG24_SE_LATCH_CALOUT_RD(data32);

                //data32  = enet_sds_ind_csr_reg_rd("RXTX_REG121", KC_SERDES_RXTX_REGS_RXTX_REG121__ADDR,XGENET,port,display);
                data32  = enet_sds_ind_csr_reg_rd("RXTX_REG121", inst_base + 121*2,XGENET,port,display);
                sum_cal_itr = FIELD_RXTX_REG121_SUMOS_CAL_CODE_RD(data32);


                if ((fail_even == 0 || fail_even ==1) && (fail_odd == 0 || fail_odd ==1)) {
                    lat_do += lat_do_itr;
                    lat_xo += lat_xo_itr;
                    lat_eo += lat_eo_itr;
                    lat_so += lat_so_itr;
                    lat_de += lat_de_itr;
                    lat_xe += lat_xe_itr;
                    lat_ee += lat_ee_itr;
                    lat_se += lat_se_itr;
                    sum_cal += sum_cal_itr;

                    if(display==1) printf("\n Interation Value : %d\n",avg_loop);
                    printf(".");//Added by Hrishikesh

                    //      printf("DO=0x%x  XO=0x%x  EO=0x%x  SO=0x%x  \n",lat_do_itr,lat_xo_itr,lat_eo_itr,lat_so_itr);
                    //      printf("DE=0x%x  XE=0x%x  EE=0x%x  SE=0x%x  \n",lat_de_itr,lat_xe_itr,lat_ee_itr,lat_se_itr);
                    //      printf("sum_cal = 0x%x\n",sum_cal_itr);
                    avg_loop--;
                }
                else //{ if(display==1) printf("\n Interation Failed : %d\n",avg_loop); printf("!");}
		{
	            //lprintf(8, "\n Iteration Failed : %d\n",avg_loop); 
		    printf("\n Interation Failed : %d\n",avg_loop); printf("!");
	            avg_loop--;
        	    timeout--;
	        }

	        if(timeout == 0) {
        	    lprintf(8, "FAILED for port %",port);
	            break; 
	        }

                serdes_reset_rxd_xg(XGENET,port,0);
                //printf(".");//Added by Hrishikesh
/*
                max_loop_1--;
                if(max_loop_1 == 0){
                    printf("\n MAX Loop count reached, EXITING gen_avg_val \n ");
                    break;
                }
*/
            }

            printf(" done]");//Added by Hrishikesh


            // Update with Average Value
            //--------------------------------------------------
            // Latch Calibration Value
            //data32 = enet_sds_ind_csr_reg_rd("RXTX_REG127", KC_SERDES_RXTX_REGS_RXTX_REG127__ADDR,XGENET,port,display);
            data32 = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,XGENET,port,display);
            data32 = FIELD_RXTX_REG127_DO_LATCH_MANCAL_SET(data32,get_avg(lat_do,MAX_LOOP));
            data32 = FIELD_RXTX_REG127_XO_LATCH_MANCAL_SET(data32,get_avg(lat_xo,MAX_LOOP));
            //enet_sds_ind_csr_reg_wr("RXTX_REG127", KC_SERDES_RXTX_REGS_RXTX_REG127__ADDR, data32,XGENET,port,display);
            enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, data32,XGENET,port,display);

            //data32 = enet_sds_ind_csr_reg_rd("RXTX_REG128", KC_SERDES_RXTX_REGS_RXTX_REG128__ADDR,XGENET,port,display);
            data32 = enet_sds_ind_csr_reg_rd("RXTX_REG128", inst_base + 128*2,XGENET,port,display);
            data32 = FIELD_RXTX_REG128_EO_LATCH_MANCAL_SET(data32,get_avg(lat_eo,MAX_LOOP));
            data32 = FIELD_RXTX_REG128_SO_LATCH_MANCAL_SET(data32,get_avg(lat_so,MAX_LOOP));
            //enet_sds_ind_csr_reg_wr("RXTX_REG128", KC_SERDES_RXTX_REGS_RXTX_REG128__ADDR, data32,XGENET,port,display);
            enet_sds_ind_csr_reg_wr("RXTX_REG128", inst_base + 128*2, data32,XGENET,port,display);

            //data32 = enet_sds_ind_csr_reg_rd("RXTX_REG129", KC_SERDES_RXTX_REGS_RXTX_REG129__ADDR,XGENET,port,display);
            data32 = enet_sds_ind_csr_reg_rd("RXTX_REG129", inst_base + 129*2,XGENET,port,display);
            data32 = FIELD_RXTX_REG129_DE_LATCH_MANCAL_SET(data32,get_avg(lat_de,MAX_LOOP));
            data32 = FIELD_RXTX_REG129_XE_LATCH_MANCAL_SET(data32,get_avg(lat_xe,MAX_LOOP));
            //enet_sds_ind_csr_reg_wr("RXTX_REG129", KC_SERDES_RXTX_REGS_RXTX_REG129__ADDR, data32,XGENET,port,display);
            enet_sds_ind_csr_reg_wr("RXTX_REG129", inst_base + 129*2, data32,XGENET,port,display);

            //data32 = enet_sds_ind_csr_reg_rd("RXTX_REG130", KC_SERDES_RXTX_REGS_RXTX_REG130__ADDR,XGENET,port,display);
            data32 = enet_sds_ind_csr_reg_rd("RXTX_REG130", inst_base + 130*2,XGENET,port,display);
            data32 = FIELD_RXTX_REG130_EE_LATCH_MANCAL_SET(data32,get_avg(lat_ee,MAX_LOOP));
            data32 = FIELD_RXTX_REG130_SE_LATCH_MANCAL_SET(data32,get_avg(lat_se,MAX_LOOP));
            //enet_sds_ind_csr_reg_wr("RXTX_REG130", KC_SERDES_RXTX_REGS_RXTX_REG130__ADDR, data32,XGENET,port,display);
            enet_sds_ind_csr_reg_wr("RXTX_REG130", inst_base + 130*2, data32,XGENET,port,display);

            // Summer Calibration Value
            //data32 = enet_sds_ind_csr_reg_rd("RXTX_REG14", KC_SERDES_RXTX_REGS_RXTX_REG14__ADDR,XGENET,port,display);
            data32 = enet_sds_ind_csr_reg_rd("RXTX_REG14", inst_base + 14*2,XGENET,port,display);
            data32 = FIELD_RXTX_REG14_CLTE_LATCAL_MAN_PROG_SET(data32,get_avg(sum_cal,MAX_LOOP));
            //enet_sds_ind_csr_reg_wr("RXTX_REG14", KC_SERDES_RXTX_REGS_RXTX_REG14__ADDR, data32,XGENET,port,display);
            enet_sds_ind_csr_reg_wr("RXTX_REG14", inst_base + 14*2, data32,XGENET,port,display);

                //printf("\n Average Value : \n");
                //printf("DO=0x%x  XO=0x%x  EO=0x%x  SO=0x%x  \n",get_avg(lat_do,MAX_LOOP),get_avg(lat_xo,MAX_LOOP),get_avg(lat_eo,MAX_LOOP),get_avg(lat_so,MAX_LOOP));
                //printf("DE=0x%x  XE=0x%x  EE=0x%x  SE=0x%x  \n",get_avg(lat_de,MAX_LOOP),get_avg(lat_xe,MAX_LOOP),get_avg(lat_ee,MAX_LOOP),get_avg(lat_se,MAX_LOOP));
            //    printf("sum_cal = 0x%x\n",get_avg(sum_cal,MAX_LOOP));
		USDELAY(600000);
            // Manual Summer Calibration
            //data32 = enet_sds_ind_csr_reg_rd("RXTX_REG14", KC_SERDES_RXTX_REGS_RXTX_REG14__ADDR,XGENET,port,display);
            data32 = enet_sds_ind_csr_reg_rd("RXTX_REG14", inst_base + 14*2,XGENET,port,display);
            data32 = FIELD_RXTX_REG14_CTLE_LATCAL_MAN_ENA_SET(data32,0x1);
            //enet_sds_ind_csr_reg_wr("RXTX_REG14", KC_SERDES_RXTX_REGS_RXTX_REG14__ADDR, data32,XGENET,port,display);
            enet_sds_ind_csr_reg_wr("RXTX_REG14", inst_base + 14*2, data32,XGENET,port,display);
            //    printf("Manual Summer Calibration Enabled\n");


            //for(timeout=0; timeout<0x4000000; ++timeout);
		USDELAY(500000);
            // Manual Latch Calibration
            //data32 = enet_sds_ind_csr_reg_rd("RXTX_REG127", KC_SERDES_RXTX_REGS_RXTX_REG127__ADDR,XGENET,port,display);
            data32 = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,XGENET,port,display);
            data32 = FIELD_RXTX_REG127_LATCH_MAN_CAL_ENA_SET(data32,0x1);
            //enet_sds_ind_csr_reg_wr("RXTX_REG127", KC_SERDES_RXTX_REGS_RXTX_REG127__ADDR, data32,XGENET,port,display);
            enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, data32,XGENET,port,display);
            //    printf("Manual Latch Calibration Enabled\n");

            //for(timeout=0; timeout<0x4000000; ++timeout);
		USDELAY(500000);

            // Turn on DFE 
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg28", inst_base + 28*2,XGENET,port,display);
            wr_val = sm_enet_set(rd_val,0x7, 15, display);
            enet_sds_ind_csr_reg_wr("rxtx_reg28", inst_base + 28*2, wr_val,XGENET,port,display);
            // DFE Presets to 0x2a00(default)
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg31", inst_base + 31*2,XGENET,port,display);
            wr_val = sm_enet_set(rd_val, 0x2a00, 15, display);
            enet_sds_ind_csr_reg_wr("rxtx_reg31", inst_base + 31*2, wr_val,XGENET,port,display);
            // Disable RX Hi-Z termination enable
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg12", inst_base + 12*2,XGENET,port,display);
            wr_val = sm_enet_set(rd_val,0, 1, 1);
            enet_sds_ind_csr_reg_wr("rxtx_reg12", inst_base + 12*2, wr_val,XGENET,port,display);
            //for(timeout=0;timeout<1000000;timeout++);
		USDELAY(500000);
            data32 = enet_sds_ind_csr_reg_rd("rxtx_reg121", inst_base + 121*2, XGENET, port, display);

            reset_pcs(port);
            //} //for-loop

        }


////------

#if 0

static void sds_wr(void __iomem *csr_base, u32 indirect_cmd_reg,
		   u32 indirect_data_reg, u32 addr, u32 data)
{
	unsigned long deadline = jiffies + HZ;
	u32 val;
	u32 cmd;

	cmd = CFG_IND_WR_CMD_MASK | CFG_IND_CMD_DONE_MASK;
	cmd = CFG_IND_ADDR_SET(cmd, addr);
	writel(data, csr_base + indirect_data_reg);
	readl(csr_base + indirect_data_reg); /* Force a barrier */
	writel(cmd, csr_base + indirect_cmd_reg);
	readl(csr_base + indirect_cmd_reg); /* Force a barrier */
	usleep_range(1000,1000);
	do {
		val = readl(csr_base + indirect_cmd_reg);
	} while (!(val & CFG_IND_CMD_DONE_MASK) &&
		 time_before(jiffies, deadline));
	if (!(val & CFG_IND_CMD_DONE_MASK))
		pr_err("SDS WR timeout at 0x%p offset 0x%08X value 0x%08X\n",
		       csr_base + indirect_cmd_reg, addr, data);
}

static void sds_rd(void __iomem *csr_base, u32 indirect_cmd_reg,
		   u32 indirect_data_reg, u32 addr, u32 *data)
{
	unsigned long deadline = jiffies + HZ;
	u32 val;
	u32 cmd;

	cmd = CFG_IND_RD_CMD_MASK | CFG_IND_CMD_DONE_MASK;
	cmd = CFG_IND_ADDR_SET(cmd, addr);
	writel(cmd, csr_base + indirect_cmd_reg);
	readl(csr_base + indirect_cmd_reg); /* Force a barrier */
	usleep_range(1000,1000);
	do {
		val = readl(csr_base + indirect_cmd_reg);
	} while (!(val & CFG_IND_CMD_DONE_MASK)&&
		 time_before(jiffies, deadline));
	*data = readl(csr_base + indirect_data_reg);
	if (!(val & CFG_IND_CMD_DONE_MASK))
		pr_err("SDS WR timeout at 0x%p offset 0x%08X value 0x%08X\n",
		       csr_base + indirect_cmd_reg, addr, *data);
}

static void cmu_wr(struct xgene_phy_ctx *ctx, enum cmu_type_t cmu_type,
		   u32 reg, u32 data)
{
	void __iomem *sds_base;
	u32 cmd_reg;
	u32 wr_reg;
	u32 rd_reg;
	u32 val;

	if (cmu_type == REF_CMU && ctx->ext_cmu_base &&
	    (ctx->clk_type == CLK_INT_DIFF || ctx->clk_type == CLK_INT_SING))
		/* Reference CMU out side of the IP */
		sds_base = ctx->ext_cmu_base;
	else
		sds_base = ctx->sds_base;

	if (ctx->mode == MODE_PCIE) {
		cmd_reg = PCIE_IND_CMD_REG;
		wr_reg = PCIE_IND_WDATA_REG;
		rd_reg = PCIE_IND_RDATA_REG;
	} else if (ctx->mode == MODE_USB) {
		cmd_reg = USB_IND_CMD_REG;
		wr_reg = USB_IND_WDATA_REG;
		rd_reg = USB_IND_RDATA_REG;
	} else {
		cmd_reg = SATA_ENET_SDS_IND_CMD_REG;
		wr_reg = SATA_ENET_SDS_IND_WDATA_REG;
		rd_reg = SATA_ENET_SDS_IND_RDATA_REG;
	}

	if (cmu_type == REF_CMU)
		reg += SERDES_PLL_REF_INDIRECT_OFFSET;
	else if (cmu_type == PHY_CMU)
		reg += SERDES_PLL_INDIRECT_OFFSET;
	else
		reg += SERDES_PLL2_INDIRECT_OFFSET;
	sds_wr(sds_base, cmd_reg, wr_reg, reg, data);
	sds_rd(sds_base, cmd_reg, rd_reg, reg, &val);
	pr_debug("CMU WR addr 0x%X value 0x%08X <-> 0x%08X\n", reg, data, val);
}

static void cmu_rd(struct xgene_phy_ctx *ctx, enum cmu_type_t cmu_type,
		   u32 reg, u32 *data)
{
	void __iomem *sds_base;
	u32 cmd_reg;
	u32 rd_reg;

	if (cmu_type == REF_CMU && ctx->ext_cmu_base &&
	    (ctx->clk_type == CLK_INT_DIFF || ctx->clk_type == CLK_INT_SING))
		/* Reference CMU out side of the IP */
		sds_base = ctx->ext_cmu_base;
	else
		sds_base = ctx->sds_base;

	if (ctx->mode == MODE_PCIE) {
		cmd_reg = PCIE_IND_CMD_REG;
		rd_reg = PCIE_IND_RDATA_REG;
	} else if (ctx->mode == MODE_USB) {
		cmd_reg = USB_IND_CMD_REG;
		rd_reg = USB_IND_RDATA_REG;
	} else {
		cmd_reg = SATA_ENET_SDS_IND_CMD_REG;
		rd_reg = SATA_ENET_SDS_IND_RDATA_REG;
	}

	if (cmu_type == REF_CMU)
		reg += SERDES_PLL_REF_INDIRECT_OFFSET;
	else if (cmu_type == PHY_CMU)
		reg += SERDES_PLL_INDIRECT_OFFSET;
	else
		reg += SERDES_PLL2_INDIRECT_OFFSET;
	sds_rd(sds_base, cmd_reg, rd_reg, reg, data);
	pr_debug("CMU RD addr 0x%X value 0x%08X\n", reg, *data);
}

static void serdes_wr(struct xgene_phy_ctx *ctx, int lane, u32 reg, u32 data)
{
	void __iomem *sds_base = ctx->sds_base;
	u32 cmd_reg;
	u32 wr_reg;
	u32 rd_reg;
	u32 val;

	if (ctx->mode == MODE_PCIE) {
		cmd_reg = PCIE_IND_CMD_REG;
		wr_reg = PCIE_IND_WDATA_REG;
		rd_reg = PCIE_IND_RDATA_REG;
	} else if (ctx->mode == MODE_USB) {
		cmd_reg = USB_IND_CMD_REG;
		wr_reg = USB_IND_WDATA_REG;
		rd_reg = USB_IND_RDATA_REG;
	} else {
		cmd_reg = SATA_ENET_SDS_IND_CMD_REG;
		wr_reg = SATA_ENET_SDS_IND_WDATA_REG;
		rd_reg = SATA_ENET_SDS_IND_RDATA_REG;
	}

	reg += (lane / 4) * SERDES_LANE_X4_STRIDE;
	reg += SERDES_INDIRECT_OFFSET;
	reg += (lane % 4) * SERDES_LANE_STRIDE;
	sds_wr(sds_base, cmd_reg, wr_reg, reg, data);
	sds_rd(sds_base, cmd_reg, rd_reg, reg, &val);
	pr_debug("SERDES WR addr 0x%X value 0x%08X <-> 0x%08X\n", reg, data,
		 val);
}

static void serdes_rd(struct xgene_phy_ctx *ctx, int lane, u32 reg, u32 *data)
{
	void __iomem *sds_base = ctx->sds_base;
	u32 cmd_reg;
	u32 rd_reg;

	if (ctx->mode == MODE_PCIE) {
		cmd_reg = PCIE_IND_CMD_REG;
		rd_reg = PCIE_IND_RDATA_REG;
	} else if (ctx->mode == MODE_USB) {
		cmd_reg = USB_IND_CMD_REG;
		rd_reg = USB_IND_RDATA_REG;
	} else {
		cmd_reg = SATA_ENET_SDS_IND_CMD_REG;
		rd_reg = SATA_ENET_SDS_IND_RDATA_REG;
	}

	reg += (lane / 4) * SERDES_LANE_X4_STRIDE;
	reg += SERDES_INDIRECT_OFFSET;
	reg += (lane % 4) * SERDES_LANE_STRIDE;
	sds_rd(sds_base, cmd_reg, rd_reg, reg, data);
	pr_debug("SERDES RD addr 0x%X value 0x%08X\n", reg, *data);
}

static void serdes_clrbits(struct xgene_phy_ctx *ctx, int lane, u32 reg,
			   u32 bits)
{
	u32 val;

	serdes_rd(ctx, lane, reg, &val);
	val &= ~bits;
	serdes_wr(ctx, lane, reg, val);
}

static void serdes_setbits(struct xgene_phy_ctx *ctx, int lane, u32 reg,
			   u32 bits)
{
	u32 val;

	serdes_rd(ctx, lane, reg, &val);
	val |= bits;
	serdes_wr(ctx, lane, reg, val);
}


#endif


int xgene_phy_get_avg(int accum, int samples)
{
	return (accum / samples);
}

//static void xgene_phy_gen_avg_val(struct xgene_phy_ctx *ctx, int lane)
void xgene_phy_gen_avg_val(int port)
{
	int max_loop = 10;
	int avg_loop = 0;
	int lat_do = 0, lat_xo = 0, lat_eo = 0, lat_so = 0;
	int lat_de = 0, lat_xe = 0, lat_ee = 0, lat_se = 0;
	int sum_cal = 0;
	int lat_do_itr, lat_xo_itr, lat_eo_itr, lat_so_itr;
	int lat_de_itr, lat_xe_itr, lat_ee_itr, lat_se_itr;
	int sum_cal_itr = 0;
	int fail_even;
	int fail_odd;
	u32 val;
	u32 dfepreset_old;
	u32 dfe_tap;
	int loop;
	uint32_t inst, inst_base;
	unsigned int  wr_val, rd_val;
	int data32;
	int display =0;
	
	inst = 0;
	inst_base = 0x0400 + inst*0x0200;

	printf("\nGenerating avg calibration value for XGE-%d",port);

	/* Enable RX Hi-Z termination */
	//serdes_setbits(ctx, lane, RXTX_REG12,RXTX_REG12_RX_DET_TERM_ENABLE_MASK);
	rd_val = enet_sds_ind_csr_reg_rd("RXTX_REG12", inst_base + 12*2,XGENET,port,display);
	wr_val = FIELD_RXTX_REG12_RX_DET_TERM_ENABLE_SET(rd_val,1);
	enet_sds_ind_csr_reg_wr("RXTX_REG12", inst_base + 12*2, wr_val,XGENET,port,display);

	/* Turn off DFE */
	//serdes_rd(ctx, lane, RXTX_REG28, &dfe_tap);
	rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg28", inst_base + 28*2,XGENET,port,display);
	//serdes_wr(ctx, lane, RXTX_REG28, 0x0000);
	enet_sds_ind_csr_reg_wr("rxtx_reg28", inst_base + 28*2, 0x0000,XGENET,port,display);

	/* DFE Presets to zero */
	//serdes_rd(ctx, lane, RXTX_REG31, &dfepreset_old);
	rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg31", inst_base + 31*2,XGENET,port,display);
	//serdes_wr(ctx, lane, RXTX_REG31, 0x0000);
	enet_sds_ind_csr_reg_wr("rxtx_reg31", inst_base + 31*2, 0x0000,XGENET,port,display);

	/*
	 * Receiver Offset Calibration:
	 * Calibrate the receiver signal path offset in two steps - summar
	 * and latch calibration.
	 * Runs the "Receiver Offset Calibration multiple times to determine
	 * the average value to use.
	 */
	while (avg_loop < max_loop) {
		/* Start SUMMER calibration */

		//serdes_setbits(ctx, lane, RXTX_REG127,RXTX_REG127_FORCE_SUM_CAL_START_MASK);
		rd_val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,XGENET,port,display);
		wr_val = FIELD_RXTX_REG127_FORCE_SUM_CAL_START_SET(rd_val,1);
		enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, wr_val,XGENET,port,display);

		/*
		 * As per PHY design spec, the Summer calibration requires a minimum
		 * of 100us to complete.
		 */
		//usleep_range(100, 500);	
		USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500

		//serdes_clrbits(ctx, lane, RXTX_REG127,RXTX_REG127_FORCE_SUM_CAL_START_MASK);
		rd_val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,XGENET,port,display);
		wr_val = FIELD_RXTX_REG127_FORCE_SUM_CAL_START_SET(rd_val,0);
		enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, wr_val,XGENET,port,display);

		/*
		 * As per PHY design spec, the auto calibration requires a minimum
		 * of 100us to complete.
		 */
		//usleep_range(100, 500);
		USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500
		
		loop = 100;
		do {
			//serdes_rd(ctx, lane, RXTX_REG158, &val);
			val = enet_sds_ind_csr_reg_rd("rxtx_reg158", inst_base + 158*2,XGENET,port,display);
			if (FIELD_RXTX_REG158_SUM_CALIB_DONE_RD(val) && (FIELD_RXTX_REG158_SUM_CALIB_ERR_RD(val) == 0))
				break;

			//usleep_range(10, 100);
			USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500
		} while (--loop > 0);

		//serdes_rd(ctx, lane, RXTX_REG158, &val);
		val = enet_sds_ind_csr_reg_rd("rxtx_reg158", inst_base + 158*2,XGENET,port,display);

		if (FIELD_RXTX_REG158_SUM_CALIB_DONE_RD(val) && (FIELD_RXTX_REG158_SUM_CALIB_ERR_RD(val) == 0))  {
			lprintf(8,"rxtx_channel%d  summer calib pass \n", port);
			//serdes_rd(ctx, lane, RXTX_REG121, &val);
			val = enet_sds_ind_csr_reg_rd("rxtx_reg121", inst_base + 121*2,XGENET,port,display);

			sum_cal_itr = FIELD_RXTX_REG121_SUMOS_CAL_CODE_RD(val);
			sum_cal += sum_cal_itr;
			++avg_loop;
		}
		//xgene_phy_reset_rxd(ctx, lane);
		serdes_reset_rxd_xg(XGENET,port,0);
	}

	/* Update SUMMER calibration with average value */
	//serdes_rd(ctx, lane, RXTX_REG14, &val);
	rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg14", inst_base + 14*2,XGENET,port,display);
	wr_val = FIELD_RXTX_REG14_CLTE_LATCAL_MAN_PROG_SET(rd_val,xgene_phy_get_avg(sum_cal, max_loop));
	//serdes_wr(ctx, lane, RXTX_REG14, val);
	enet_sds_ind_csr_reg_wr("RXTX_REG14", inst_base + 14*2,wr_val,XGENET,port,display);

	lprintf(8,"SUM 0x%x\n",xgene_phy_get_avg(sum_cal, max_loop));

	//serdes_rd(ctx, lane, RXTX_REG14, &val);
	rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg14", inst_base + 14*2,XGENET,port,display);
	wr_val = FIELD_RXTX_REG14_CTLE_LATCAL_MAN_ENA_SET(rd_val, 0x1);
	//serdes_wr(ctx, lane, RXTX_REG14, val);
	enet_sds_ind_csr_reg_wr("RXTX_REG14", inst_base + 14*2,wr_val,XGENET,port,display);
	lprintf(8,"Enable Manual Summer calibration\n");

	avg_loop = 0;

	while (avg_loop < max_loop) {
		/* Start latch calibration */
		//serdes_setbits(ctx, lane, RXTX_REG127,RXTX_REG127_FORCE_LAT_CAL_START_MASK);
		rd_val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,XGENET,port,display);
		wr_val = FIELD_RXTX_REG127_FORCE_LAT_CAL_START_SET(rd_val,1);
		enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, wr_val,XGENET,port,display);

		/*
		 * As per PHY design spec, the latch calibration requires a minimum
		 * of 100us to complete.
		 */
		//usleep_range(100, 500); 
		USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500

		//serdes_clrbits(ctx, lane, RXTX_REG127,RXTX_REG127_FORCE_LAT_CAL_START_MASK);		
		rd_val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,XGENET,port,display);
		wr_val = FIELD_RXTX_REG127_FORCE_LAT_CAL_START_SET(rd_val,0);
		enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, wr_val,XGENET,port,display);

		/* check lat calib, 
		 * The lat_calib is take about 200ms to be done 
		 * after release serdes reset. 
		 * It only occured 1time
		 */
		//usleep_range(100, 500); 
		USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500
		loop = 1000;
		do {
			//serdes_rd(ctx, lane, RXTX_REG158, &val);
			val = enet_sds_ind_csr_reg_rd("rxtx_reg158", inst_base + 158*2,XGENET,port,display);

			if (FIELD_RXTX_REG158_LAT_CALIB_DONE_RD(val))
				break;
			//usleep_range(100, 500); 
			USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500

		} while (--loop > 0);

		//serdes_rd(ctx, lane, RXTX_REG158, &val);
		val = enet_sds_ind_csr_reg_rd("rxtx_reg158", inst_base + 158*2,XGENET,port,display);

		if (FIELD_RXTX_REG158_LAT_CALIB_DONE_RD(val)) 
			lprintf(8,"rxtx_channel%d  lat calib pass and time taken =%dms \n",port, (1000-loop)*2);
		else 
			lprintf(8,"rxtx_channel%d  lat calib failed even after %d loops\n",port, (1000-loop));

		//serdes_rd(ctx, lane, RXTX_REG21, &val);
		val = enet_sds_ind_csr_reg_rd("rxtx_reg21", inst_base + 21*2,XGENET,port,display);
		lat_do_itr = FIELD_RXTX_REG21_DO_LATCH_CALOUT_RD(val);
		lat_xo_itr = FIELD_RXTX_REG21_XO_LATCH_CALOUT_RD(val);
		fail_odd = FIELD_RXTX_REG21_LATCH_CAL_FAIL_ODD_RD(val);

		//serdes_rd(ctx, lane, RXTX_REG22, &val);
		val = enet_sds_ind_csr_reg_rd("rxtx_reg22", inst_base + 22*2,XGENET,port,display);
		lat_eo_itr = FIELD_RXTX_REG22_EO_LATCH_CALOUT_RD(val);
		lat_so_itr = FIELD_RXTX_REG22_SO_LATCH_CALOUT_RD(val);
		fail_even = FIELD_RXTX_REG22_LATCH_CAL_FAIL_EVEN_RD(val);

		//serdes_rd(ctx, lane, RXTX_REG23, &val);
		val = enet_sds_ind_csr_reg_rd("rxtx_reg23", inst_base + 23*2,XGENET,port,display);
		lat_de_itr = FIELD_RXTX_REG23_DE_LATCH_CALOUT_RD(val);
		lat_xe_itr = FIELD_RXTX_REG23_XE_LATCH_CALOUT_RD(val);

		//serdes_rd(ctx, lane, RXTX_REG24, &val);
		val = enet_sds_ind_csr_reg_rd("rxtx_reg24", inst_base + 24*2,XGENET,port,display);
		lat_ee_itr = FIELD_RXTX_REG24_EE_LATCH_CALOUT_RD(val);
		lat_se_itr = FIELD_RXTX_REG24_SE_LATCH_CALOUT_RD(val);

		/* Check for failure. If passed, sum them for averaging */
		if ((fail_even == 0 || fail_even == 1) && (fail_odd == 0 || fail_odd == 1)) {
			lat_do += lat_do_itr;
			lat_xo += lat_xo_itr;
			lat_eo += lat_eo_itr;
			lat_so += lat_so_itr;
			lat_de += lat_de_itr;
			lat_xe += lat_xe_itr;
			lat_ee += lat_ee_itr;
			lat_se += lat_se_itr;

			lprintf(8,"Iteration %d:\n", avg_loop);
			lprintf(8,"DO 0x%x XO 0x%x EO 0x%x SO 0x%x\n",lat_do_itr, lat_xo_itr, lat_eo_itr,lat_so_itr);
			lprintf(8,"DE 0x%x XE 0x%x EE 0x%x SE 0x%x\n",lat_de_itr, lat_xe_itr, lat_ee_itr,lat_se_itr);
			lprintf(8,"SUM 0x%x\n", sum_cal_itr);
			++avg_loop;
		} else {
			lprintf(8,"Receiver calibration failed at %d loop\n",avg_loop);
		}
		//xgene_phy_reset_rxd(ctx, lane);
		serdes_reset_rxd_xg(XGENET,port,0);
	}

	/* Update latch manual calibration with average value */
	//serdes_rd(ctx, lane, RXTX_REG127, &val);
	val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,XGENET,port,display);
	val = FIELD_RXTX_REG127_DO_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_do, max_loop));
	val = FIELD_RXTX_REG127_XO_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_xo, max_loop));
	//serdes_wr(ctx, lane, RXTX_REG127, val);
	enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, val,XGENET,port,display);

	//serdes_rd(ctx, lane, RXTX_REG128, &val);
	val = enet_sds_ind_csr_reg_rd("RXTX_REG128", inst_base + 128*2,XGENET,port,display);
	val = FIELD_RXTX_REG128_EO_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_eo, max_loop));
	val = FIELD_RXTX_REG128_SO_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_so, max_loop));
	//serdes_wr(ctx, lane, RXTX_REG128, val);
	enet_sds_ind_csr_reg_wr("RXTX_REG128", inst_base + 128*2, val,XGENET,port,display);

	//serdes_rd(ctx, lane, RXTX_REG129, &val);
	val = enet_sds_ind_csr_reg_rd("RXTX_REG129", inst_base + 129*2,XGENET,port,display);
	val = FIELD_RXTX_REG129_DE_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_de, max_loop));
	val = FIELD_RXTX_REG129_XE_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_xe, max_loop));
	//serdes_wr(ctx, lane, RXTX_REG129, val);
	enet_sds_ind_csr_reg_wr("RXTX_REG129", inst_base + 129*2, val,XGENET,port,display);

	//serdes_rd(ctx, lane, RXTX_REG130, &val);
	val = enet_sds_ind_csr_reg_rd("RXTX_REG130", inst_base + 130*2,XGENET,port,display);
	val = FIELD_RXTX_REG130_EE_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_ee, max_loop));
	val = FIELD_RXTX_REG130_SE_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_se, max_loop));
	//serdes_wr(ctx, lane, RXTX_REG130, val);
	enet_sds_ind_csr_reg_wr("RXTX_REG130", inst_base + 130*2, val,XGENET,port,display);

	lprintf(8,"Average Value:\n");
	lprintf(8,"DO 0x%x XO 0x%x EO 0x%x SO 0x%x\n",
			xgene_phy_get_avg(lat_do, max_loop),
			xgene_phy_get_avg(lat_xo, max_loop),
			xgene_phy_get_avg(lat_eo, max_loop),
			xgene_phy_get_avg(lat_so, max_loop));
	lprintf(8,"DE 0x%x XE 0x%x EE 0x%x SE 0x%x\n",
			xgene_phy_get_avg(lat_de, max_loop),
			xgene_phy_get_avg(lat_xe, max_loop),
			xgene_phy_get_avg(lat_ee, max_loop),
			xgene_phy_get_avg(lat_se, max_loop));
	//serdes_rd(ctx, lane, RXTX_REG127, &val);
	val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,XGENET,port,display);
	val = FIELD_RXTX_REG127_LATCH_MAN_CAL_ENA_SET(val, 0x1);
	lprintf(8,"Enable Manual Latch calibration\n");
	//serdes_wr(ctx, lane, RXTX_REG127, val);
	enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, val,XGENET,port,display);

	//usleep_range(800, 1000);
	USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500

	/* Disable RX Hi-Z termination */
	//serdes_rd(ctx, lane, RXTX_REG12, &val);
	val = enet_sds_ind_csr_reg_rd("RXTX_REG12", inst_base + 12*2,XGENET,port,display);
	val = FIELD_RXTX_REG12_RX_DET_TERM_ENABLE_SET(val, 0);
	//serdes_wr(ctx, lane, RXTX_REG12, val);
	enet_sds_ind_csr_reg_wr("RXTX_REG12", inst_base + 12*2, val,XGENET,port,display);


	/* Turn on/off DFE */
#if 0
	if (ctx->mode == MODE_SATA)
		serdes_wr(ctx, lane, RXTX_REG28,(ctx->sata_param.txequalizer[lane * 3 + ctx->sata_param.speed[lane]]) ? 0x0007 : 0x0000);
	else if (ctx->mode == MODE_PCIE)
		serdes_wr(ctx, lane, RXTX_REG28, dfe_tap);
	else
#endif
		//serdes_wr(ctx, lane, RXTX_REG28, 0x7);
		enet_sds_ind_csr_reg_wr("RXTX_REG28", inst_base + 28*2, 0x7,XGENET,port,display);
#if 0
	if (ctx->mode == MODE_PCIE) {
		serdes_rd(ctx, lane, RXTX_REG8, &val);
		val = RXTX_REG8_CDR_LOOP_ENA_SET(val, 0x1);
		serdes_wr(ctx, lane, RXTX_REG8, val);
	}
#endif

#if 0
	/* Restore DFE Presets */
	if (ctx->mode == MODE_SATA)
		serdes_wr(ctx, lane, RXTX_REG31,
				ctx->sata_param.txequalizer[lane * 3 +
				ctx->sata_param.speed[lane]] ? 0x7e00 : 0x0000);
	else
#endif
		//serdes_wr(ctx, lane, RXTX_REG31, dfepreset_old);
	enet_sds_ind_csr_reg_wr("RXTX_REG31", inst_base + 31*2, val,XGENET,port,display);

        reset_pcs(port);
}



///--------





        int get_avg(int accum,int samples){
            return ((accum + (samples/2))/samples);
        }
        void pcs_prbs_en(int port){
            int data32;
            // PCS PRBS enable in Tx and Rx(Monitor)
            //==================================================
            // PRBS31
            //----------
            data32 = 0x30;
            xgbaser_ind_write(SM_XGENET_XGBASER_PCS_PCS_TEST_PAT_CONTROL__ADDR,data32,port,0);

            // PRBS9
            //----------
            // data32 = 0x40;
            // xgbaser_ind_write(SM_XGENET_XGBASER_PCS_PCS_TEST_PAT_CONTROL__ADDR,data32,port,0);
            // data32 = 0x4;
            // xgbaser_ind_write(SM_XGENET_XGBASER_PCS_PCS_RX_VS_CONTROL__ADDR,data32,port,0);
            //
            // Square
            //----------
            // data32 = 0xe;
            // xgbaser_ind_write(SM_XGENET_XGBASER_PCS_PCS_TEST_PAT_CONTROL__ADDR,data32,port,0);
        }
        void pcs_prbs_dis(int port){
            int data32;

            // PCS PRBS enable in Tx and Rx(Monitor)
            //==================================================
            data32 = 0x00;
            xgbaser_ind_write(SM_XGENET_XGBASER_PCS_PCS_TEST_PAT_CONTROL__ADDR,data32,port,0);
            xgbaser_ind_write(SM_XGENET_XGBASER_PCS_PCS_RX_VS_CONTROL__ADDR,data32,port,0);
        }
        void cmd_reset_pcs(){
            int port;
            printf("select Port : 0x");
            port = get_val();
            reset_pcs(port);
        }
        void reset_pcs(int port){
            int timeout;
            xgbaser_ind_write(SM_XGENET_XGBASER_PCS_PCS_CONTROL_1__ADDR,0xa640,port,0);
            //for(timeout=0; timeout<0x4000; ++timeout);
		//printf("\nStart of delay for reset_pcs ...");
		USDELAY(1000); 
		//printf(" Done");
            xgbaser_ind_write(SM_XGENET_XGBASER_PCS_PCS_CONTROL_1__ADDR,0x2640,port,0);
        }
        void cleanup_rf() {
            int timeout;
            int port;
            int pcs_txfault,pcs_rxfault;
            int rd_data;
            for(port=0;port<4;port++) {
                xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_2__ADDR,port,0); // Clear Latched Values
                for(timeout=0; timeout<0x40000; ++timeout);
                rd_data = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_2__ADDR,port,0);
                pcs_txfault = FIELD_PCS_STATUS_2_PCS_TX_FAULT_LH_RD(rd_data) ;
                pcs_rxfault = FIELD_PCS_STATUS_2_PCS_RX_FAULT_LH_RD(rd_data);
                if(pcs_rxfault | pcs_txfault) {
                    printf("PCS Fault detected on Port%d RX=%x TX=%x\n",port,pcs_rxfault,pcs_txfault);
                    // reset PCS
                    reset_pcs(port);
                }
            }
        }
        void delay_1(int val){
            int timeout;
            for(timeout=0; timeout<(0x1000*val); ++timeout);
        }

        void sweep_full_xfi() {
            sweep_port_xfi(0,1); // TX2RX LOOPBACK - PRBS ENABLE  
            sweep_port_xfi(1,1); // TX2RX LOOPBACK - PRBS ENABLE  
            //sweep_port_xfi(2,0); // IDLE from IXIA - PRBS DISABLED
            sweep_port_xfi(3,1); // TX2RX LOOPBACK - PRBS ENABLE  
        }
        void sweep_port_xfi(int port,int prbs) {
            // PQ REG
            int START_VAL0 = 4;
            int END_VAL0 = 24;
            int STEP0 = 2;
            int swp_var0;
            // CTLE
            int START_VAL1 = 4;
            int END_VAL1 = 28;
            int STEP1 = 4;
            int swp_var1;
            int data32;
            int NUM_SAMPLE = 2;
            //int result[END_VAL0][END_VAL1];
            //int result[24][28];
            int result[11][7];
            uint32_t inst, inst_base;

            inst = 0;
            inst_base = 0x0400 + inst*0x0200;

            printf("\n====================\n");
            printf("--  PQ REG Sweep test : Port%d",port);
            printf("\n====================\n");

            // Enable PRBS
            if(prbs) pcs_prbs_en(port);

            for(swp_var1=START_VAL1;swp_var1<=END_VAL1;swp_var1+=STEP1){
                // Update Sweep Val
                //data32 = enet_sds_ind_csr_reg_rd("RXTX_REG1", KC_SERDES_RXTX_REGS_RXTX_REG1__ADDR,XGENET,port,0);
                data32 = enet_sds_ind_csr_reg_rd("RXTX_REG1", inst_base + 1*2,XGENET,port,0);
                data32 = FIELD_RXTX_REG1_CTLE_EQ_SET(data32,swp_var1);
                //enet_sds_ind_csr_reg_wr("RXTX_REG1", KC_SERDES_RXTX_REGS_RXTX_REG1__ADDR,data32,XGENET,port,0);
                enet_sds_ind_csr_reg_wr("RXTX_REG1", inst_base + 1*2,data32,XGENET,port,0);

                for(swp_var0=START_VAL0;swp_var0<=END_VAL0;swp_var0+=STEP0){
                    // Update Sweep Val
                    //data32 = enet_sds_ind_csr_reg_rd("RXTX_REG125", KC_SERDES_RXTX_REGS_RXTX_REG125__ADDR,XGENET,port,0);
                    data32 = enet_sds_ind_csr_reg_rd("RXTX_REG125", inst_base + 125*2,XGENET,port,0);
                    data32 = FIELD_RXTX_REG125_PQ_REG_SET(data32,swp_var0);
                    //enet_sds_ind_csr_reg_wr("RXTX_REG125", KC_SERDES_RXTX_REGS_RXTX_REG125__ADDR,data32,XGENET,port,0);
                    enet_sds_ind_csr_reg_wr("RXTX_REG125", inst_base + 125*2,data32,XGENET,port,0);
                    // Wait for  Stability
                    delay_1(400);
                    // 
                    result[(swp_var0-START_VAL0)/STEP0][(swp_var1-START_VAL1)/STEP1] = get_ber(port,NUM_SAMPLE,prbs);
                }
            }
            // Disable PRBS
            if(prbs) pcs_prbs_dis(port);

            // Print Stat
            printf("--  PQ(Vertical) CTLE(Horizontal) REG Sweep Result :\n",port);
            for(swp_var0=START_VAL0;swp_var0<=END_VAL0;swp_var0+=STEP0){
                if(swp_var0==START_VAL0) {
                    printf("\n CTLE --> : ",swp_var0);
                    for(swp_var1=START_VAL1;swp_var1<=END_VAL1;swp_var1+=STEP1){
                        printf("%8x ", swp_var1);
                    }
                }
                printf("\n %8x : ",swp_var0);
                for(swp_var1=START_VAL1;swp_var1<=END_VAL1;swp_var1+=STEP1){
                    printf("%8x ", result[(swp_var0-START_VAL0)/STEP0][(swp_var1-START_VAL1)/STEP1]);
                }
            }
            printf("\n \n done\n\n ");

        }

        int get_ber(int port, int samples,int prbs){
            int data32;
            int sample_num;
            long ber=0;
            // Cleanup Accumulated Values
            read_ber_port(port,0);
            read_ber_port(port,0);
            for (sample_num=1;sample_num<=samples;sample_num++) {
                if(prbs) {
                    // Wait Fixed Delay
                    delay_1(4);
                    eth_wr(SM_XGENET_XGBASER_PCS_IND_CSR_XGBASER_CONFIG_REG0__ADDR,0x1,XGENET,port,0); // Latch pulse
                    data32 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_PRBS_ERR_COUNT_0__ADDR,port,0);
                    data32 |= xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_PRBS_ERR_COUNT_1__ADDR,port,0) << 16;
                }
                else {
                    int temp;
                    // Wait Fixed Delay
                    delay_1(40000);
                    eth_wr(SM_XGENET_XGBASER_PCS_IND_CSR_XGBASER_CONFIG_REG0__ADDR,0x1,XGENET,port,0); // Latch pulse
                    data32 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_4__ADDR,port,0);
                    // printf("\n PCS_HI_BER_LH      : 0x%x",FIELD_PCS_STATUS_4_PCS_HI_BER_LH_RD(data32));
                    // printf("\n PCS_BER            : 0x%x",FIELD_PCS_STATUS_4_PCS_BER_RD(data32));
                    // printf("\n PCS_ERRORED_BLOCKS : 0x%x",FIELD_PCS_STATUS_4_PCS_ERRORED_BLOCKS_RD(data32));
                    temp = (FIELD_PCS_STATUS_4_PCS_BER_RD(data32) << 16) + FIELD_PCS_STATUS_4_PCS_ERRORED_BLOCKS_RD(data32);

                    data32 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_4_AMCC_COUNT__ADDR,port,0);
                    // printf("\n AMCC_COUNT_PCS_BER     : %x",FIELD_PCS_STATUS_4_AMCC_COUNT_PCS_BER_VALUE_RD(data32));
                    // printf("\n AMCC_COUNT_PCS_ERRORED : %x",FIELD_PCS_STATUS_4_AMCC_COUNT_PCS_ERRORED_BLOCKS_VALUE_RD(data32));
                    temp += (FIELD_PCS_STATUS_4_AMCC_COUNT_PCS_BER_VALUE_RD(data32) << 16) + FIELD_PCS_STATUS_4_AMCC_COUNT_PCS_ERRORED_BLOCKS_VALUE_RD(data32);
                    data32 = temp;
                }
                ber += data32;
            }

            return (ber/samples);

        }

        void read_ber_port(int port,int display) {
            int data32;
            if(display) printf("\n ========== Port %d ==========",port);
            eth_wr(SM_XGENET_XGBASER_PCS_IND_CSR_XGBASER_CONFIG_REG0__ADDR,0x1,XGENET,port,0); // Latch pulse

            data32 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_2__ADDR,port,0);
            if(display) printf("\n PCS_TX_FAULT_LH : 0x%x",FIELD_PCS_STATUS_2_PCS_TX_FAULT_LH_RD(data32));
            if(display) printf("\n PCS_RX_FAULT_LH : 0x%x",FIELD_PCS_STATUS_2_PCS_RX_FAULT_LH_RD(data32));
            if(FIELD_PCS_STATUS_2_PCS_TX_FAULT_LH_RD(data32) | FIELD_PCS_STATUS_2_PCS_RX_FAULT_LH_RD(data32)) {
                data32 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_2__ADDR,port,0);
                if(display) printf("\n PCS_TX_FAULT_LH : 0x%x",FIELD_PCS_STATUS_2_PCS_TX_FAULT_LH_RD(data32));
                if(display) printf("\n PCS_RX_FAULT_LH : 0x%x",FIELD_PCS_STATUS_2_PCS_RX_FAULT_LH_RD(data32));
            }

            data32 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_3__ADDR,port,0);
            if(display) printf("\n PCS_LINK_STATUS : 0x%x",FIELD_PCS_STATUS_3_PCS_LINK_STATUS_RD(data32));

            data32 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_4__ADDR,port,0);
            // printf("\n SM_XGENET_XGBASER_PCS_PCS_STATUS_4__ADDR : 0x%x",data32);
            if(display) printf("\n PCS_HI_BER_LH      : 0x%x",FIELD_PCS_STATUS_4_PCS_HI_BER_LH_RD(data32));
            if(display) printf("\n PCS_BER            : 0x%x",FIELD_PCS_STATUS_4_PCS_BER_RD(data32));
            if(display) printf("\n PCS_ERRORED_BLOCKS : 0x%x",FIELD_PCS_STATUS_4_PCS_ERRORED_BLOCKS_RD(data32));

            data32 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_4_AMCC_COUNT__ADDR,port,0);
            //printf("\n SM_XGENET_XGBASER_PCS_PCS_STATUS_4_AMCC_COUNT__ADDR : %d",data32);
            if(display) printf("\n AMCC_COUNT_PCS_BER     : %d",FIELD_PCS_STATUS_4_AMCC_COUNT_PCS_BER_VALUE_RD(data32));
            if(display) printf("\n AMCC_COUNT_PCS_ERRORED : %d",FIELD_PCS_STATUS_4_AMCC_COUNT_PCS_ERRORED_BLOCKS_VALUE_RD(data32));

            data32 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_TEST_PAT_ERR_COUNT__ADDR,port,0);
            if(display) printf("\n SM_XGENET_XGBASER_PCS_PCS_TEST_PAT_ERR_COUNT__ADDR : %d",data32);

            data32 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_TEST_PAT_ERR_COUNT_AMCC_COUNT__ADDR,port,0);
            if(display) printf("\n SM_XGENET_XGBASER_PCS_PCS_TEST_PAT_ERR_COUNT_AMCC_COUNT__ADDR : %d",data32);

            data32 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_PRBS_ERR_COUNT_0__ADDR,port,0);
            if(display) printf("\n SM_XGENET_XGBASER_PCS_PCS_PRBS_ERR_COUNT_0__ADDR : %d",data32);
            data32 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_PRBS_ERR_COUNT_1__ADDR,port,0);
            if(display) printf("\n SM_XGENET_XGBASER_PCS_PCS_PRBS_ERR_COUNT_1__ADDR : %d",data32);

            //data32 = xgbaser_ind_read(,data32,port,0);
            //printf("\n  : %d",data32);
            if(display) printf("\n  ");
        }

        //End of gen_avg_val() related code


        //Top_level_functions
        void printf_test_suite_header() {
            printf("\n -------------------------------------------------------------");
            printf("\n| SLT Test Suite : Tx-2-Rx   Loopback    Test (XFI:10GE Mode) |");
            printf("\n| Device Family : Storm                       Device Rev : B0 |");
            printf("\n -------------------------------------------------------------");
            printf("\n");
        }

        void init_and_configure_xfi_ports() {
            int port;
            printf("\nConfiguring XFI ports : ");
            xgenet_base_addr = XGENET_0_BASE_ADDR;
            for (port=0;port<=3;port++) {
                printf("\nXGE-%d  ",port);//New Line //Added by Hrishikesh
                init_xgenet(port, 0x0); // Port 0 - Display configuration 
                //init_xgenet(port, 0x1); // Port 0 - Display configuration 
            }
            printf(" ... Done");
        }

        void sfp_laser_enable_top_level_function() {
            int sfpp_port_no;
            printf("\n\nTurning on SFP+ Lasers ...");
            for (sfpp_port_no = 0; sfpp_port_no <= 3; sfpp_port_no++)
                sfp_plus_laser_on(sfpp_port_no,1);
            //printf("\nStart of delay for sfp_plus_laser_on ...");
	    USDELAY(100000);
	    //printf(" Done"); //To allow some time after SFP+ Lasers are turned on
        }

        void gen_avg_val_top_level() {
            //Added as per Chidvilas comment ...
            int port;
            printf("\n\nCalling fn 'gen_avg_val()' ... ");
            for(port=0;port<=3;port++)
                gen_avg_val_xfi(port);
            printf("\nXFI SERDES tuning/calibration is done");
        }

        //Test Menu Functions
        void external_tx2rx_loopback_test_4_ports() {
            int port,display=0;
            int read_data;

		//printf("\nDelay while entering external_tx2rx_loopback_test_4_ports ...");USDELAY(1000000);//1-Sec

            printf("\n");
            int reg_1 , reg_2 , reg_3 , reg_4;
            reg_1 = read(0x1f60c200); reg_2 = read(0x1f60c208); reg_3 = read(0x1f70c200); reg_4 = read(0x1f70c208);
            if(reg_1==0x3 && reg_2==0 && reg_3==0x3 && reg_4==0) {
                cle_bypass_function_xfi();
            }


		//printf("\nDelay after cle_bypass_function_xfi ...");USDELAY(10000);//1-Sec

            /*
            //  enable_l3_cache();//Enable L3 cache ...
            //  axi_clock_250();//Set AXI Clock to 250 MHz
            //  iob_clock_400();//Set IOB Clock to 400 MHz


            //Configure unisec bypass mode in DEBUG_CSR. This is same as used in QM Loopback mode
            //config_debug_csr_for_unisec_bypass();

            //CLE_BYPASS config ...
            //printf("\r\n++++++++++++ CPU Level Loopback Test +++++++++++++\r\n");
            for(port=0; port<=3; port++) {
            if(port == 0) {
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000000e,XGENET,port,display);//cfg_cle_bypass=1
            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
            printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00000040,XGENET,port,display);
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00000040,XGENET,port,display);

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data);
            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data);

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
            eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
            // cfg to enable capture of Rx cntrl wd's
            eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
            }
            else if(port == 1) {
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000000e,XGENET,port,display);//cfg_cle_bypass=1
            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
            printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110041,XGENET,port,display);
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110041,XGENET,port,display);

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data);
            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data);

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
            eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
            // cfg to enable capture of Rx cntrl wd's
            eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
            }
            else if(port == 2) {
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000000e,XGENET,port,display);//cfg_cle_bypass=1
            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
            printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00000840,XGENET,port,display);
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00000840,XGENET,port,display);

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data);
            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data);

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
            eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
            // cfg to enable capture of Rx cntrl wd's
            eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
            }
            else if(port == 3) {
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000000e,XGENET,port,display);//cfg_cle_bypass=1
            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
            printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110841,XGENET,port,display);
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110841,XGENET,port,display);

            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data);
            read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
            printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data);

            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
            eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
            eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
            // cfg to enable capture of Rx cntrl wd's
            eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
        }
        }
        //End of CLE_BYPASS config
        */
	

		//printf("\nDelay before qmi_config_local_xfi ...");
		USDELAY(100);
		//printf(" Done");//1-Sec

            qmi_config_local_xfi();

        /*
        //QMI Config ...
        unsigned int reg,tmp;

        // QMI configuration for Port-2/3
        printf("\r\nQMI configuration for Port-2 & Port-3\r\n");
        //printf("Before write\r\n");
        reg = 0x1f7190dc;
        tmp = read32(reg);
        //printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f7190e0;
        tmp = read32(reg);
        //printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f7190f0;
        tmp = read32(reg);
        //printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f7190f4;
        tmp = read32(reg);
        //printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);

        reg = 0x1f7290dc;
        tmp = read32(reg);
        //printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f7290e0;
        tmp = read32(reg);
        //printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f7290f0;
        tmp = read32(reg);
        //printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f7290f4;
        tmp = read32(reg);
        //printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);

        // Port-2
        //write((unsigned int *)(0x1f7190dc), 0xffffffff); // CfgSsQmiFPQAssoc 
        //write((unsigned int *)(0x1f7190e0), 0xffffffff); // CfgSsQmiWQQAssoc 
        write((unsigned int *)(0x1f7190f0), 0xffffffff); // CfgSsQmiQMLiteFPQAssoc 
        write((unsigned int *)(0x1f7190f4), 0xffffffff); // CfgSsQmiQMLiteWQAssoc 

        // Port-3
        //write((unsigned int *)(0x1f7290dc), 0xffffffff); // CfgSsQmiFPQAssoc 
        //write((unsigned int *)(0x1f7290e0), 0xffffffff); // CfgSsQmiWQAssoc 
        write((unsigned int *)(0x1f7290f0), 0xffffffff); // CfgSsQmiQMLitePFQAssoc
        write((unsigned int *)(0x1f7290f4), 0xffffffff); // CfgSsQmiQMLiteWQAssoc

        //printf("\r\nAftre write\r\n");
        reg = 0x1f7190dc;
        tmp = read32(reg);
        //printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f7190e0;
        tmp = read32(reg);
        //printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f7190f0;
        tmp = read32(reg);
        //printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f7190f4;
        tmp = read32(reg);
        //printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);

        reg = 0x1f7290dc;
        tmp = read32(reg);
        //printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f7290e0;
        tmp = read32(reg);
        //printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f7290f0;
        tmp = read32(reg);
        //printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f7290f4;
        tmp = read32(reg);
        //printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);

        printf("\nQM-0/1/2 Init\r\n");
        */
            /*	
                int read_reg_1;
                read_reg_1 = read(0x1f60c200); printf("\nVal_1 : 0x%x",read_reg_1);
                read_reg_1 = read(0x1f60c208); printf("\nVal_2 : 0x%x",read_reg_1);
                read_reg_1 = read(0x1f70c200); printf("\nVal_3 : 0x%x",read_reg_1);
                read_reg_1 = read(0x1f70c208); printf("\nVal_4 : 0x%x",read_reg_1);
                write(0x1f60c200,0x3); 
                USDELAY(10000);
                write(0x1f60c208,0x0); 
                USDELAY(10000);
                write(0x1f70c200,0x3);
                USDELAY(10000);
                write(0x1f70c208,0x0);
                USDELAY(10000);
                read_reg_1 = read(0x1f60c200); printf("\nVal_1 : 0x%x",read_reg_1);
                read_reg_1 = read(0x1f60c208); printf("\nVal_2 : 0x%x",read_reg_1);
                read_reg_1 = read(0x1f70c200); printf("\nVal_3 : 0x%x",read_reg_1);
                read_reg_1 = read(0x1f70c208); printf("\nVal_4 : 0x%x",read_reg_1);
                */	


            // --- ORIGINAL CODE ---
            /*
               reg_1 = read(0x1f60c200); reg_2 = read(0x1f60c208); reg_3 = read(0x1f70c200); reg_4 = read(0x1f70c208);
               if(reg_1==0x3 && reg_2==0 && reg_3==0x3 && reg_4==0) {
               qm_n_function_xfi();
               }
               */


		//printf("\nDelay before qm_n ...");
		USDELAY(1000);
		//printf(" Done");//1-Sec

            qm_n_function_xfi_dummy_1();
        //qm_n_function_xfi();


        //qm_n((QM_QM0 | QM_QM1 | QM_QM2), QM_ETH);
        //qm_n_dump((QM_QM0 | QM_QM1 | QM_QM2), QM_ETH);

        //End of QMI Config

        //Configure AXGMAC_CONFIG_1 ...
        //int config_val , kkk;
        //printf("\nEnter AXGMAC_CONFIG_1 val : ");
        //config_val = get_val(); config_val = get_val();
        //config_val = 0xf400008d;
        //for(kkk=0;kkk<=3;kkk++)
        //	axgmac_ind_write(AXGMAC_AXGMAC_CONFIG_1__ADDR, config_val , kkk , 0);
        //printf("AXGMAC_CONFIG_1 set to : 0x%x",config_val); //Not required for SLT Test

        //Stat dump before sending packets
        //printf("\n\nStat dump before sending eth packets ...");
        //stat_dump();

        //Transmit eth packet
        //printf("\nCalling 'eth_tx2rx_lpbk_test_xfi_1g()' ...");

	USDELAY(10000);
        eth_tx2rx_lpbk_test_xfi_1g();

        //Stat dump at the end of the test
        //printf("\nStat dump after sending eth packets ...");
        //stat_dump();
        }

        void config_debug_csr_for_unisec_bypass() {
            int port , display=0;
            for(port=0; port<=3; port++)
                eth_wr(SM_XGENET_CSR_DEBUG_REG__ADDR, 0x003e03ee,XGENET,port,display);//This config is used in QM Loopback Mode
        }

        void enable_l3_cache() {
            int l3c_size;
            //   printf("\n\nEnter L3 Cache size ( Valid val = [2,4,8] ) : ");
            //   l3c_size = get_val(); l3c_size = get_val();
            l3c_size = 8;
            //   printf("Storm L3C init: \n\r\n\r");
            printf("\n\n");
            l3c_init(l3c_size,1,1);
            //   printf("\nL3C enabled\n");
            //   printf("\nPress any key to continue ..."); get_val(); get_val();
            //   printf("\n");
        }

        void axi_clock_250() {
            printf("\n\nSetting AXI Clock to 250 MHz ...");  write(0x17000160 , 4);  printf(" Done");
        }

        void iob_clock_400() {
            printf("\n\nSetting IOB Clock to 400 MHz ...");  write(0x17000150 , 5);  printf(" Done");
        }

        //Debug Functions
        void stat_dump() {
            int port_rxpf_txpf , read_rpkt , read_tpkt;
            for(port_rxpf_txpf=0; port_rxpf_txpf<=3; port_rxpf_txpf++) {
                printf("\nXGE-%d==>",port_rxpf_txpf);
                read_rpkt = axgmac_stat_rd(PEMSTAT_RPKT__ADDR , port_rxpf_txpf);printf("[RPKT:%d]",read_rpkt);
                read_tpkt = axgmac_stat_rd(PEMSTAT_TPKT__ADDR , port_rxpf_txpf);printf("[TPKT:%d]",read_tpkt);
                read_rpkt = axgmac_stat_rd(PEMSTAT_TR64__ADDR , port_rxpf_txpf);printf("[TR64:%d]",read_rpkt);
                read_rpkt = axgmac_stat_rd(PEMSTAT_TR127__ADDR , port_rxpf_txpf);printf("[TR127:%d]",read_rpkt);
                read_rpkt = axgmac_stat_rd(PEMSTAT_TR255__ADDR , port_rxpf_txpf);printf("[TR255:%d]",read_rpkt);
                read_rpkt = axgmac_stat_rd(PEMSTAT_TR511__ADDR , port_rxpf_txpf);printf("[TR511:%d]",read_rpkt);
                read_rpkt = axgmac_stat_rd(PEMSTAT_TR1K__ADDR , port_rxpf_txpf);printf("[TR1K:%d]",read_rpkt);
                read_rpkt = axgmac_stat_rd(PEMSTAT_TRMAX__ADDR , port_rxpf_txpf);printf("[TRMAX:%d]",read_rpkt);
                read_rpkt = axgmac_stat_rd(PEMSTAT_RFCS__ADDR , port_rxpf_txpf);printf("[RFCS:%d]",read_rpkt);
                read_rpkt = axgmac_stat_rd(PEMSTAT_TFCS__ADDR , port_rxpf_txpf);printf("[TFCS:%d]",read_rpkt);
                read_rpkt = axgmac_stat_rd(PEMSTAT_TRMGV__ADDR , port_rxpf_txpf);printf("[TRMGV:%d]",read_rpkt);
            }
            printf("\n");

        }
	
	void stat_dump_per_port(int port, int display) {
            int port_rxpf_txpf , read_rpkt , read_tpkt;
	    port_rxpf_txpf = port;
            //for(port_rxpf_txpf=0; port_rxpf_txpf<=3; port_rxpf_txpf++) {
                if(display==1) printf("\nXGE-%d==>",port_rxpf_txpf);
                read_rpkt = axgmac_stat_rd(PEMSTAT_RPKT__ADDR , port_rxpf_txpf);if(display==1)printf("[RPKT:%d]",read_rpkt);
                read_tpkt = axgmac_stat_rd(PEMSTAT_TPKT__ADDR , port_rxpf_txpf);if(display==1)printf("[TPKT:%d]",read_tpkt);
                read_rpkt = axgmac_stat_rd(PEMSTAT_TR64__ADDR , port_rxpf_txpf);if(display==1)printf("[TR64:%d]",read_rpkt);
                read_rpkt = axgmac_stat_rd(PEMSTAT_TR127__ADDR , port_rxpf_txpf);if(display==1)printf("[TR127:%d]",read_rpkt);
                read_rpkt = axgmac_stat_rd(PEMSTAT_TR255__ADDR , port_rxpf_txpf);if(display==1)printf("[TR255:%d]",read_rpkt);
                read_rpkt = axgmac_stat_rd(PEMSTAT_TR511__ADDR , port_rxpf_txpf);if(display==1)printf("[TR511:%d]",read_rpkt);
                read_rpkt = axgmac_stat_rd(PEMSTAT_TR1K__ADDR , port_rxpf_txpf);if(display==1)printf("[TR1K:%d]",read_rpkt);
                read_rpkt = axgmac_stat_rd(PEMSTAT_TRMAX__ADDR , port_rxpf_txpf);if(display==1)printf("[TRMAX:%d]",read_rpkt);
                read_rpkt = axgmac_stat_rd(PEMSTAT_RFCS__ADDR , port_rxpf_txpf);if(display==1)printf("[RFCS:%d]",read_rpkt);
                read_rpkt = axgmac_stat_rd(PEMSTAT_TFCS__ADDR , port_rxpf_txpf);if(display==1)printf("[TFCS:%d]",read_rpkt);
                read_rpkt = axgmac_stat_rd(PEMSTAT_TRMGV__ADDR , port_rxpf_txpf);if(display==1)printf("[TRMGV:%d]",read_rpkt);
            //}
            if(display==1) printf("\n");

        }


        void dump_eth_packet() {
            int ps , port_num;
            printf("\n\nEnter Packet Size : 0x"); ps = get_val(); ps = get_val();
            //eth_pkt_dump((unsigned char *)buf1[0], ps);
        }

        void dump_qstate() {

            err_info_t ei;

            qm_dump_pb_state(0, 0, 0); // P01, WQ0
            qm_dump_pb_state(0, 0, 8); // P01, WQ8
            qm_dump_pb_state(0, 0, 32); // P01, FQ0
            qm_dump_pb_state(0, 0, 33); // P01, FQ8
            qm_dump_pb_state(0, 0, 34); // P01, FQ0
            qm_dump_pb_state(0, 0, 35); // P01, FQ8

            qm_dump_pb_state(0, 1, 0); // P23, WQ0
            qm_dump_pb_state(0, 1, 8); // P23, WQ8
            qm_dump_pb_state(0, 1, 32); // P23, FQ0
            qm_dump_pb_state(0, 1, 33); // P23, FQ8
            qm_dump_pb_state(0, 1, 34); // P23, FQ0
            qm_dump_pb_state(0, 1, 35); // P23, FQ8

            qm_dump_qstate(0, 4, 0);//qmid=0
            qm_dump_qstate(0, 4, 32);//qmid=0
            //qm_dump_qstate(1, 4, 64);
            qm_dump_qstate(2, 4, 0);//qmid=2
            qm_dump_qstate(2, 4, 32);//qmid=2

            /*
               printf("\nQMI Status Reg Dump:\n");
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIFPPTR0__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIFPPTR1__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIFPPTR2__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIFPPTR3__ADDR,ENET,port,1);
               printf("\n");
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIFPNUMENTRIES0__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIFPNUMENTRIES1__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIFPNUMENTRIES2__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIFPNUMENTRIES3__ADDR,ENET,port,1);
               printf("\n");
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIWQPTR0__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIWQPTR1__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIWQPTR2__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIWQPTR3__ADDR,ENET,port,1);
               printf("\n");
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES0__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES1__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES2__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES3__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES4__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES5__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES6__ADDR,ENET,port,1);
               tmp = eth_rd(SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES7__ADDR,ENET,port,1);
               printf("\n");
               */

            // qm_dump_pb_state(0, 0, 0);
            // qm_dump_pb_state(0, 0, 0x21);
            // qm_dump_qstate(0, 2, 32);
            // qm_dump_qstate(0, 1, 1);
            /*
               printf("\r\n ---- QM-0 queue state dump:\r\n"); 
               qm_dump_qstate(0, 4, 32);
               qm_dump_qstate(0, 1, 1);
               printf("\r\n ---- QM-2 queue state dump:\r\n"); 
               qm_dump_qstate(2, 4, 32);
               qm_dump_qstate(2, 1, 1);
               */
            // printf("\r\n ---- QM1 queue statedump:\r\n"); 
            // qm_dump_pb_state(1, 0, 0);
            // qm_dump_pb_state(1, 0, 8);
            // qm_dump_pb_state(1, 1, 0);
            // qm_dump_pb_state(1, 1, 8);
            // qm_dump_qstate(1, 4, 32);
            // qm_dump_qstate(1, 1, 1);

            //qm_chk_errq(0, &ei);
            //qm_dump_qstate(0, 1, QM_ERROR_QID);
            //qm_dump_qstate(0, 1, QM_E_ERROR_QID);
            //qm_dump_qm_errq(1);
            //qm_err_dump(1);

        }


        void cle_bypass_function_xfi(){
            int port,display=0;
            int read_data;

            printf("\n");

            //  enable_l3_cache();//Enable L3 cache ...
            //  axi_clock_250();//Set AXI Clock to 250 MHz
            //  iob_clock_400();//Set IOB Clock to 400 MHz


            //Configure unisec bypass mode in DEBUG_CSR. This is same as used in QM Loopback mode
            //config_debug_csr_for_unisec_bypass();

            //CLE_BYPASS config ...
            //printf("\r\n++++++++++++ CPU Level Loopback Test +++++++++++++\r\n");
            for(port=0; port<=3; port++) {
                if(port == 0) {
                    eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1
                    read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
                    if(display==1)
                        printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

                    eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00000040,XGENET,port,display);
                    eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00000040,XGENET,port,display);

                    read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
                    if(display==1)
                        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data);
                    read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
                    if(display==1)
                        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data);

                    eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
                    eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
                    eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
                    // cfg to enable capture of Rx cntrl wd's
                    eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
                }
                else if(port == 1) {
                    eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1
                    read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
                    if(display==1)
                        printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

                    eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110041,XGENET,port,display);
                    eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110041,XGENET,port,display);

                    read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
                    if(display==1)
                        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data);
                    read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
                    if(display==1)
                        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data);

                    eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
                    eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
                    eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
                    // cfg to enable capture of Rx cntrl wd's
                    eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
                }
                else if(port == 2) {
                    eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1
                    read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
                    if(display==1)
                        printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

                    eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00000840,XGENET,port,display);
                    eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00000840,XGENET,port,display);

                    read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
                    if(display==1)
                        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data);
                    read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
                    if(display==1)
                        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data);

                    eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
                    eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
                    eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
                    // cfg to enable capture of Rx cntrl wd's
                    eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
                }
                else if(port == 3) {
                    eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1
                    read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
                    if(display==1)
                        printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

                    eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110841,XGENET,port,display);
                    eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110841,XGENET,port,display);

                    read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
                    if(display==1)
                        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data);
                    read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
                    if(display==1)
                        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data);

                    eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
                    eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
                    eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
                    // cfg to enable capture of Rx cntrl wd's
                    eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
                }
            }
            //End of CLE_BYPASS config

        }

        void qmi_config_local_xfi() {
            //QMI Config ...
            unsigned int reg,tmp;
            int port,display=0;
            int read_data;


            // QMI configuration for Port-2/3
            lprintf(8,"\r\nQMI configuration for Port-2 & Port-3\r\n");
            lprintf(8,"Before write\r\n");
            reg = 0x1f7190dc;
            tmp = read32(reg);
            lprintf(8,"reg:0x%x tmp:0x%x\r\n",reg,tmp);
            reg = 0x1f7190e0;
            tmp = read32(reg);
            lprintf(8,"reg:0x%x tmp:0x%x\r\n",reg,tmp);
            reg = 0x1f7190f0;
            tmp = read32(reg);
            lprintf(8,"reg:0x%x tmp:0x%x\r\n",reg,tmp);
            reg = 0x1f7190f4;
            tmp = read32(reg);
            lprintf(8,"reg:0x%x tmp:0x%x\r\n",reg,tmp);

            reg = 0x1f7290dc;
            tmp = read32(reg);
            lprintf(8,"reg:0x%x tmp:0x%x\r\n",reg,tmp);
            reg = 0x1f7290e0;
            tmp = read32(reg);
            lprintf(8,"reg:0x%x tmp:0x%x\r\n",reg,tmp);
            reg = 0x1f7290f0;
            tmp = read32(reg);
            lprintf(8,"reg:0x%x tmp:0x%x\r\n",reg,tmp);
            reg = 0x1f7290f4;
            tmp = read32(reg);
            lprintf(8,"reg:0x%x tmp:0x%x\r\n",reg,tmp);

            // Port-2
            //write((unsigned int *)(0x1f7190dc), 0xffffffff); // CfgSsQmiFPQAssoc 
            //write((unsigned int *)(0x1f7190e0), 0xffffffff); // CfgSsQmiWQQAssoc 
            write((unsigned int *)(0x1f7190f0), 0xffffffff); // CfgSsQmiQMLiteFPQAssoc 
            write((unsigned int *)(0x1f7190f4), 0xffffffff); // CfgSsQmiQMLiteWQAssoc 

            // Port-3
            //write((unsigned int *)(0x1f7290dc), 0xffffffff); // CfgSsQmiFPQAssoc 
            //write((unsigned int *)(0x1f7290e0), 0xffffffff); // CfgSsQmiWQAssoc 
            write((unsigned int *)(0x1f7290f0), 0xffffffff); // CfgSsQmiQMLitePFQAssoc
            write((unsigned int *)(0x1f7290f4), 0xffffffff); // CfgSsQmiQMLiteWQAssoc

            lprintf(8,"\r\nAftre write\r\n");
            reg = 0x1f7190dc;
            tmp = read32(reg);
            lprintf(8,"reg:0x%x tmp:0x%x\r\n",reg,tmp);
            reg = 0x1f7190e0;
            tmp = read32(reg);
            lprintf(8,"reg:0x%x tmp:0x%x\r\n",reg,tmp);
            reg = 0x1f7190f0;
            tmp = read32(reg);
            lprintf(8,"reg:0x%x tmp:0x%x\r\n",reg,tmp);
            reg = 0x1f7190f4;
            tmp = read32(reg);
            lprintf(8,"reg:0x%x tmp:0x%x\r\n",reg,tmp);

            reg = 0x1f7290dc;
            tmp = read32(reg);
            lprintf(8,"reg:0x%x tmp:0x%x\r\n",reg,tmp);
            reg = 0x1f7290e0;
            tmp = read32(reg);
            lprintf(8,"reg:0x%x tmp:0x%x\r\n",reg,tmp);
            reg = 0x1f7290f0;
            tmp = read32(reg);
            lprintf(8,"reg:0x%x tmp:0x%x\r\n",reg,tmp);
            reg = 0x1f7290f4;
            tmp = read32(reg);
            lprintf(8,"reg:0x%x tmp:0x%x\r\n",reg,tmp);

            //printf("\nQM-0/1/2 Init\r\n");
		//USDELAY(10000);

        }
        void qm_n_function_xfi() {
            printf("\nQM-0/1/2 Init\r\n");
            qm_n((QM_QM0 | QM_QM1 | QM_QM2), QM_ETH);
        }

        void qm_n_function_xfi_dummy_1() {
            //printf("\nQM-0 Init\r\n");
            //     qm_n_xfi((QM_QM0), QM_ETH);
            //printf("\nQM-2 Init\r\n");
            //qm_n_xfi((QM_QM2), QM_ETH);
            //printf("\nQM-0/2 Init\r\n");
            qm_n_xfi((QM_QM0 |  QM_QM2), QM_ETH);
            //qm_n((QM_QM0 | QM_QM2), QM_ETH);

        }

void external_tx2rx_p2p_loopback_test_4_ports() {
  int port,display=0;
  int read_data;

  printf("\n");
  int reg_1 , reg_2 , reg_3 , reg_4;
  reg_1 = read(0x1f60c200); reg_2 = read(0x1f60c208); reg_3 = read(0x1f70c200); reg_4 = read(0x1f70c208);
  if(reg_1==0x3 && reg_2==0 && reg_3==0x3 && reg_4==0) {
      cle_bypass_function_xfi();
  }

  USDELAY(100);
  qmi_config_local_xfi();

  USDELAY(1000);
  qm_n_function_xfi_dummy_1();

  USDELAY(10000);
  eth_tx2rx_p2p_lpbk_test_xfi_1g();

}

int eth_tx2rx_p2p_lpbk_test_xfi_1g() {
    total_err_count_xfi[0]=0;
    total_err_count_xfi[1]=0;
    total_err_count_xfi[2]=0;
    total_err_count_xfi[3]=0;
    unsigned int mn,qmid,ps,pn,temp;
    qm_ret_t ret;
    enq_req_t *per;
    enq_req_t *per32;
    enq_req_t *per33;
    enq_req_t *per34;
    qm_buf_t qm_buf_xfi;
    qm_buf_t qm_buf32_xfi;
    qm_buf_t qm_buf33_xfi;
    qm_buf_t qm_buf34_xfi;
    enq_cfg_t enq_cfg;
    q_state_t cfg;
    int port,i;
    int port_num_calc=0;

    qm_buf_xfi.bp = buf_xfi;
    qm_buf32_xfi.bp = buf32_xfi;
    qm_buf33_xfi.bp = buf33_xfi;
    qm_buf34_xfi.bp = buf34_xfi;

	USDELAY(1000);
    memset ((char *)msgbuf_xfi, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
	USDELAY(1000);
    memset ((char *)msgbuf32_xfi, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
	USDELAY(1000);
    memset ((char *)msgbuf33_xfi, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
	USDELAY(1000);
    memset ((char *)msgbuf34_xfi, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    //printf("\nEnter Packet Size : 0x");
    //if(terminal_server_serial_port==1) ps = get_val(); ps = get_val();
    ps = 256;//printf("\n");
    //printf("Packet Size entered (in int) : %d",ps);

    printf("\nEnter Number of Packets : 0x");
    if(terminal_server_serial_port==1) pn = get_val(); pn = get_val();
    //pn = 1000000; //printf("\n");	//1-m
    //pn = 100000; //printf("\n");	//100k
    //pn = 10000; //printf("\n");	//10k
    //pn = 1000; //printf("\n");
    //pn = 10; //printf("\n");
    //pn = 5; //printf("\n");
    //pn = 1; //printf("\n");
    printf("\nNumber of Packets entered (in int) : %d\n\n",pn);
    printf("Running Ethernet Traffic ... \n\n");

    //printf("\nPress <Enter> to continue ..."); if(terminal_server_serial_port==1) get_val(); get_val();

    /*
       ps = 128; //PKT_SIZE; //packet size
       pn = 1; //PKT_NUM; // Number of PAckets to send
       */

    pn = pn*4;

    qmid = 0;
    //while (qmid<3) {
    //USDELAY(1000);

//    mn = QM_TEST_MSG_NUM;
    mn = 100;

#if 1 //Port-0/1
    //	printf("\nsys_alloc_enet_buf  ... # P-0\n");
    //printf("\nDelay for sys_alloc_enet_buf P0 ...");
    USDELAY(100);
    ret = sys_alloc_enet_buf_old(0, mn, &qm_buf_xfi); //// Allocate the FPQ Buffer
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf_old Fail qmid:%d\r\n",qmid);
        return ret;
    }
    //	printf("\nsys_alloc_enet_buf  ... # P-1\n");
    //printf("\nDelay for sys_alloc_enet_buf P1 ...");
    USDELAY(100);
    ret = sys_alloc_enet_buf_old(0, mn, &qm_buf32_xfi); //// Allocate the FPQ Buffer
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf32_old Fail qmid:%d\r\n",qmid);
        return ret;
    }
#endif
#if 1 // Port-2/3
    //	printf("\nsys_alloc_enet_buf  ... # P-2\n");
    //printf("\nDelay for sys_alloc_enet_buf P2 ...");
    USDELAY(100);
    ret = sys_alloc_enet_buf_old(2, mn, &qm_buf33_xfi); //// Allocate the FPQ Buffer
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf33_old Fail qmid:%d\r\n",qmid);
        return ret;
    }
    //printf("\nsys_alloc_enet_buf  ... # P-3\n");
    //printf("\nDelay for sys_alloc_enet_buf P3 ...");
    USDELAY(100);
    ret = sys_alloc_enet_buf_old(2, mn, &qm_buf34_xfi); //// Allocate the FPQ Buffer
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf34_old Fail qmid:%d\r\n",qmid);
        return ret;
    }
    //	printf("\nsys_alloc_enet_buf  ... # End\n");

#endif


#if 1


    //printf("\nQM sys_alloc_enet_buf done....  qmid:%d\r\n",qmid);//Not required for SLT Test
#if 1  //Port-0/1
    //printf("\nDelay for qm_build_eth_pkt P0 ...");
    USDELAY(100);
    ret = qm_build_eth_pkt((unsigned char *)buf_xfi[0], ps);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt Fail qmid:%d\r\n",qmid);
        return ret;

    }
    //printf("\nDelay for qm_build_eth_pkt P1 ...");
    USDELAY(100);
    ret = qm_build_eth_pkt((unsigned char *)buf32_xfi[0], ps);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt32 Fail qmid:%d\r\n",qmid);
        return ret;

    }
#endif
#if 1 //Port-2/3
    //printf("\nDelay for qm_build_eth_pkt P2 ...");
    USDELAY(100);
    ret = qm_build_eth_pkt((unsigned char *)buf33_xfi[0], ps);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt33 Fail qmid:%d\r\n",qmid);
        return ret;

    }
    //printf("\nDelay for qm_build_eth_pkt P3 ...");
    USDELAY(100);
    ret = qm_build_eth_pkt((unsigned char *)buf34_xfi[0], ps);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt34 Fail qmid:%d\r\n",qmid);
        return ret;

    }
#endif

    //printf("QM qm_build_eth_pkt done....    qmid:%d\r\n",qmid);//Not required for SLT Test

    //printf("\n\nEth packet dump just after bld eth pkt for buf1");
    //eth_pkt_dump((unsigned char *)buf1[0], ps);//DELETE THIS
#if 1 //Port-0/1
    //printf("\nDelay for sys_enet_enq_cfg_xfi P0 ...");
    USDELAY(100);
    per = sys_enet_enq_cfg_xfi(buf_xfi[0], ps);
    extern enq_req_t er_xfi;
    per = &er_xfi;
    if (!per) {
        printf("QM qm_proc_bld_enq_req failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }

    //printf("\nDelay for sys_enet_enq_cfg_xfi P1 ...");
    USDELAY(100);
    per32 = sys_enet_enq_cfg32_xfi(buf32_xfi[0], ps);
    extern enq_req_t er32_xfi;
    per32 = &er32_xfi;
    if (!per32) {
        printf("QM qm_proc_bld_enq_req failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }
#endif

#if 1 // Port-2/3
    //printf("\nDelay for sys_enet_enq_cfg_xfi P2 ...");
    USDELAY(100);
    per33 = sys_enet_enq_cfg33_xfi(buf33_xfi[0], ps);
    extern enq_req_t er33_xfi;
    per33 = &er33_xfi;
    if (!per33) {
        printf("QM qm_proc_bld_enq_req failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }

    //printf("\nDelay for sys_enet_enq_cfg_xfi P3 ...");
    USDELAY(100);
    per34 = sys_enet_enq_cfg34_xfi(buf34_xfi[0], ps);
    extern enq_req_t er34_xfi;
    per34 = &er34_xfi;
    if (!per34) {
        printf("QM qm_proc_bld_enq_req failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }
#endif


    q_state_t q_state_pq_32_0[20];

    u8 wn1[] ={1,1,1,1,1};
    u64 hd_ptr_32_0; 
    u64 hd_ptr_33_0; 
    u64 hd_ptr_32_2; 
    u64 hd_ptr_33_2; 

    QM_CHK_RET(qm_get_q_state_dir(0,32,1,wn1,&q_state_pq_32_0[0]));
    hd_ptr_32_0 = (q_state_pq_32_0[0].pqfp.hd_ptr);
    QM_CHK_RET(qm_get_q_state_dir(0,33,1,wn1,&q_state_pq_32_0[0]));
    hd_ptr_33_0 = (q_state_pq_32_0[0].pqfp.hd_ptr);
    QM_CHK_RET(qm_get_q_state_dir(2,32,1,wn1,&q_state_pq_32_0[0]));
    hd_ptr_32_2 = (q_state_pq_32_0[0].pqfp.hd_ptr);
    QM_CHK_RET(qm_get_q_state_dir(2,33,1,wn1,&q_state_pq_32_0[0]));
    hd_ptr_33_2 = (q_state_pq_32_0[0].pqfp.hd_ptr);
    //printf("QM qm_proc_bld_enq_req done.... qmid:%d\r\n",qmid);//Not required for SLT Test
    for(i=0; i<pn; i++) {
        //	for(i=0; i<2; i++) {//Port-0/1
        //	for(i=2; i<4; i++) {//Port-2/3
        //printf("\n------------------ PacketNo:%d -----------------\n",i);//Not required for SLT Test

	//printf("\nPacket No. : %d",i);

        if((i%4) == 0)
        {	
		port_num_calc=0;
            per->qid = QID32; // port-0
	    //USDELAY(1000);
            ret = qm_proc_enq_dir(0,per);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                return ret;
            }
    	    //printf("\nDelay for qm_proc_enq_dir P0 ...");
	    //USDELAY(10000);
//            pkt_compare_xfi(port_num_calc, hd_ptr_32_0, i/4);
//            pkt_compare_xfi_p2p(port_num_calc, hd_ptr_32_0, i/4);
//            pkt_compare_xfi(port_num_calc, hd_ptr_32_0, i);
            //pkt_compare_xfi(port_num_calc, 0);

            pkt_compare_xfi_p2p(0, hd_ptr_33_0, hd_ptr_32_0, i/4);//Check for XGE-0
        }

#if 1  //Comment this part to not send packets on XGE-1/2/3
        else if((i%4) == 1)
        {	port_num_calc=1;
            per32->qid = QID33; // port-1
	    //USDELAY(1000);
            ret = qm_proc_enq_dir(0,per32);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir per32 qmid:%d failed ret:%d\r\n",qmid,ret);
                return ret;
            }
    	    //printf("\nDelay for qm_proc_enq_dir P1 ...");
	    //USDELAY(100000);
//            pkt_compare_xfi(port_num_calc, hd_ptr_33_0, i/4);
            pkt_compare_xfi_p2p(1, hd_ptr_32_0, hd_ptr_33_0, i/4);//Check for XGE-1
            //pkt_compare_xfi(port_num_calc, 0);

        }
        else if((i%4) == 2)
        {	port_num_calc=2;
            per33->qid = QID32; // port-0
	    //USDELAY(1000);
            ret = qm_proc_enq_dir(2,per33);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir per33 qmid:%d failed ret:%d\r\n",qmid,ret);
                return ret;
            }
    	    //printf("\nDelay for qm_proc_enq_dir P2 ...");
	    //USDELAY(100000);
//            pkt_compare_xfi(port_num_calc, hd_ptr_32_2, i/4);
//            pkt_compare_xfi_p2p(port_num_calc, hd_ptr_32_2, i/4);
            //pkt_compare_xfi(port_num_calc, 0);

            pkt_compare_xfi_p2p(2, hd_ptr_33_2, hd_ptr_32_2, i/4);//Check for XGE-2
        }
        else if((i%4) == 3)
        {	port_num_calc=3;
            per34->qid = QID33; // port-1
	    //USDELAY(1000);
            ret = qm_proc_enq_dir(2,per34);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir per34 qmid:%d failed ret:%d\r\n",qmid,ret);
                return ret;
            }
    	    //printf("\nDelay for qm_proc_enq_dir P3 ...");
	    //USDELAY(100000);
//            pkt_compare_xfi(port_num_calc, hd_ptr_33_2, i/4);
            pkt_compare_xfi_p2p(3, hd_ptr_32_2, hd_ptr_33_2, i/4);//Check for XGE-3
            //pkt_compare_xfi(port_num_calc, 0);
        }
#endif  //Comment this part to not send packets on XGE-1/2/3

        //			ret = qm_proc_enq_dir(qmid,per);
        //printf("QM qm_proc_enq_dir done....     qmid:%d per->qid:%d PortNo:%d\n",qmid,per->qid,(i%2));//Not required for SLT Test
    }

#endif


}

int pkt_compare_xfi_p2p(int port_num_calc, u64 hd_ptr_tx, u64 hd_ptr_rx, int packet_count) {
    u64 st_address1; 	
    u64 st_address2; 	
    u64 st_address3; 	
    u64 st_address4; 	
    u64 addr_1,addr_2,addr_3,addr_4;
    u8 wn1[] = {1, 1, 1, 1, 1};
    u64 crc_data_tx_0,crc_data_rx_0;
    u64 crc_data_tx_1,crc_data_rx_1;
    u64 crc_data_tx_2,crc_data_rx_2;
    u64 crc_data_tx_3,crc_data_rx_3;
    u64 ddr_base_tx_pkt[4]={0};
    u64 ddr_base_rx_pkt[4]={0};
    u64 k,number_errors[4]={0};
    u64 temp_tx,temp_rx;
    int read_rpkt_as[4]={0}; 
    int read_rfcs_as[4]={0};
    int i;
    u64 dela;
    q_state_t q_state_pq_32_0[50];
    q_state_t q_state_pq_32_2[50];
    q_state_t q_state_pq_33_0[50];
    q_state_t q_state_pq_33_2[50];
    q_state_t q_state_pq_64_0[50];
    q_state_t q_state_pq_64_2[50];
    q_state_t q_state_pq_65_0[50];
    q_state_t q_state_pq_65_2[50];
    q_state_t q_state_pq_dbg[50];

    int port_num_wait;
    int iter_count;
    /*
       int itrcb;
       for (itrcb=0; itrcb<36; itrcb++)
       {
       QM_CHK_RET(qm_get_q_state_dir(0,(32+itrcb),1,wn1,&q_state_pq_dbg[0]));
       printf("ST_ADDR_ITRCB = 0x%x\n" ,  (q_state_pq_dbg[0].pqfp.st_addr));
       }
       */
    QM_CHK_RET(qm_get_q_state_dir(0,32,1,wn1,&q_state_pq_32_0[0]));
    QM_CHK_RET(qm_get_q_state_dir(0,33,1,wn1,&q_state_pq_33_0[0]));

    QM_CHK_RET(qm_get_q_state_dir(0,64,1,wn1,&q_state_pq_64_0[0]));
    QM_CHK_RET(qm_get_q_state_dir(0,65,1,wn1,&q_state_pq_65_0[0]));
#if 1
    QM_CHK_RET(qm_get_q_state_dir(2,32,1,wn1,&q_state_pq_32_2[0]));
    QM_CHK_RET(qm_get_q_state_dir(2,33,1,wn1,&q_state_pq_33_2[0]));

    QM_CHK_RET(qm_get_q_state_dir(2,64,1,wn1,&q_state_pq_64_2[0]));
    QM_CHK_RET(qm_get_q_state_dir(2,65,1,wn1,&q_state_pq_65_2[0]));
#endif
    /*
       printf("DUMPING QSTATE\n");
       qm_dump_qstate(0, 2, 32);
       qm_dump_qstate(0, 2, 64);
#if 1  
qm_dump_qstate(2, 2, 32);
qm_dump_qstate(2, 2, 64);
#endif
*/  
    switch(port_num_calc)
    {
        case 0:

            st_address1 = (q_state_pq_32_0[0].pqfp.st_addr);
              //printf("\nst_address1 : 0x%x",st_address1);
            st_address2 = (st_address1<<8);
            //printf("\tst_address2 : 0x%x",st_address2);
            st_address1 = (hd_ptr_tx);
             //printf("\tst_address1 : 0x%x",st_address1);
            st_address2 += (st_address1<<4);
             //printf("\tst_address2 : 0x%x",st_address2);
            st_address2+=8;
             //printf("\tst_address2 : 0x%x",st_address2);

		st_address2 = qm_get_va(st_address2);// _tp

            addr_1 = read(st_address2);
             //printf("\naddr_1 : 0x%x",addr_1);
            addr_1 = addr_1 & 0x00000000ffffffff;   //masking uppar 32 bits
             //printf("\naddr_1 : 0x%x",addr_1);

            addr_2 = read(st_address2+4);
             //printf("\naddr_2 : 0x%x",addr_2);
            addr_2 = addr_2 & 0x00000000000003ff;   //keeping only last 10 bits
             //printf("\naddr_2 : 0x%x",addr_2);
            addr_3 = addr_2 << 32;
              //printf("\naddr_3 : 0x%x",addr_3);

            addr_4 = addr_3 + addr_1;               //getting 42 bits DATA ADDRESS field
             //printf("\naddr_4 : 0x%x\n",addr_4);
            //ddr_base_tx_pkt[0]= addr_4;
		ddr_base_tx_pkt[0] = qm_get_va(addr_4);
            lprintf(8,"\nddr_base_tx_pkt[0] : 0x%x",ddr_base_tx_pkt[0]);
            //  printf("\nddr_base_tx_pkt[0] : 0x%x",ddr_base_tx_pkt[0]);
            //printf("\nq_state_pq_32_0 ===> st_address1 = 0x%x \t addr_1 = 0x%x \t addr_2 = 0x%x \t ddr_base_tx_pkt[0] : 0x%x",st_address1,addr_1,addr_2, ddr_base_tx_pkt[0]);
            break;
            //ddr_base_tx_pkt[1]
        case 1:
            st_address1 = (q_state_pq_33_0[0].pqfp.st_addr);
            st_address2 = (st_address1<<8);
            st_address1 = (hd_ptr_tx);
            st_address2 += (st_address1<<4);
            st_address2+=8;

		st_address2 = qm_get_va(st_address2);// _tp

            addr_1 = read(st_address2);
            addr_1 = addr_1 & 0x00000000ffffffff;   //masking uppar 32 bits

            addr_2 = read(st_address2+4);
            addr_2 = addr_2 & 0x00000000000003ff;   //keeping only last 10 bits
            addr_3 = addr_2 << 32;

            addr_4 = addr_3 + addr_1;               //getting 42 bits DATA ADDRESS field
            //ddr_base_tx_pkt[1]= addr_4;
		ddr_base_tx_pkt[1] = qm_get_va(addr_4);
            lprintf(8,"\nddr_base_tx_pkt[1] : 0x%x",ddr_base_tx_pkt[1]);
            //  printf("\nq_state_pq_33_0 ===> st_address1 = 0x%x \t addr_1 = 0x%x \t addr_2 = 0x%x \t ddr_base_tx_pkt[1] : 0x%x",st_address1,addr_1,addr_2, ddr_base_tx_pkt[1]);

#if 1 // port2-3
            //ddr_base_tx_pkt[3]
            break;
        case 2:
            st_address1 = (q_state_pq_32_2[0].pqfp.st_addr);
            st_address2 = (st_address1<<8);
            st_address1 = (hd_ptr_tx);
            st_address2 += (st_address1<<4);
            st_address2+=8;

		st_address2 = qm_get_va(st_address2);// _tp

            addr_1 = read(st_address2);
            addr_1 = addr_1 & 0x00000000ffffffff;   //masking uppar 32 bits
            addr_2 = read(st_address2+4);
            addr_2 = addr_2 & 0x00000000000003ff;   //keeping only last 10 bits
            addr_3 = addr_2 << 32;
            addr_4 = addr_3 + addr_1;               //getting 42 bits DATA ADDRESS field
            //ddr_base_tx_pkt[2]= addr_4;
		ddr_base_tx_pkt[2] = qm_get_va(addr_4);
            lprintf(8,"\nddr_base_tx_pkt[2] : 0x%x",ddr_base_tx_pkt[2]);
            //  printf("\nq_state_pq_32_2 ===> st_address1 = 0x%x \t addr_1 = 0x%x \t addr_2 = 0x%x \t ddr_base_tx_pkt[2] : 0x%x",st_address1,addr_1,addr_2, ddr_base_tx_pkt[2]);

            //ddr_base_tx_pkt[4]
            break;
        case 3:

            st_address1 = (q_state_pq_33_2[0].pqfp.st_addr);
            st_address2 = (st_address1<<8);
            st_address1 = (hd_ptr_tx);
            st_address2 += (st_address1<<4);
            st_address2+=8;

		st_address2 = qm_get_va(st_address2);// _tp

            addr_1 = read(st_address2);
            addr_1 = addr_1 & 0x00000000ffffffff;   //masking uppar 32 bits
            addr_2 = read(st_address2+4);
            addr_2 = addr_2 & 0x00000000000003ff;   //keeping only last 10 bits
            addr_3 = addr_2 << 32;
            addr_4 = addr_3 + addr_1;               //getting 42 bits DATA ADDRESS field
            //ddr_base_tx_pkt[3]= addr_4;
		ddr_base_tx_pkt[3] = qm_get_va(addr_4);
            lprintf(8,"\nddr_base_tx_pkt[3] : 0x%x",ddr_base_tx_pkt[3]);
            //  printf("\nq_state_pq_33_2 ===> st_address1 = 0x%x \t addr_1 = 0x%x \t addr_2 = 0x%x \t ddr_base_tx_pkt[3] : 0x%x",st_address1,addr_1,addr_2, ddr_base_tx_pkt[3]);
            break;
#endif 
        default:
            printf("Wrong Port number\n");
    }

    switch(port_num_calc)
    {
        //case 0:
        case 1:
            st_address1 = (q_state_pq_64_0[0].pqfp.st_addr);
            st_address2 = (st_address1<<8);
            st_address1 = (hd_ptr_rx);
            st_address2 += (st_address1<<4);
            st_address2+=8;

		st_address2 = qm_get_va(st_address2);// _tp

            //printf("\nst_address2 : 0x%x",st_address2);
            addr_1 = read(st_address2);
            addr_1 = addr_1 & 0x00000000ffffffff;   //masking uppar 32 bits
            //printf("\t addr_1 : 0x%x",addr_1);

            addr_2 = read(st_address2+4);
            addr_2 = addr_2 & 0x00000000000003ff;   //keeping only last 10 bits
            addr_3 = addr_2 << 32;
            //printf("\t addr_2: 0x%x \t addr_3: 0x%x",addr_2,addr_3);

            addr_4 = addr_3 + addr_1;               //getting 42 bits DATA ADDRESS field
		//printf("\n\ndelay - 1"); 
		//USDELAY(1000);
            //ddr_base_rx_pkt[0]= addr_4;
		//printf("\n\ndelay - 2"); 
		//USDELAY(1000);
		ddr_base_rx_pkt[0] = qm_get_va(addr_4);
		//printf("\n\ndelay - 3"); 
		//USDELAY(1000);
            lprintf(8,"\nddr_base_rx_pkt[0] : 0x%x",ddr_base_rx_pkt[0]);
		//printf("\n\ndelay - done ..."); 
            //printf("\t ddr_base_rx_pkt[0] : 0x%x",ddr_base_rx_pkt[0]);
            //    printf("\nq_state_pq_64_0 ===> st_address1 = 0x%x \t addr_1 = 0x%x \t addr_2 = 0x%x \t ddr_base_rx_pkt[0] : 0x%x",st_address1,addr_1,addr_2, ddr_base_rx_pkt[0]);
            break;

        //case 1:
        case 0:


            st_address1 = (q_state_pq_65_0[0].pqfp.st_addr);
//	    printf("\nst_address1 : 0x%x",st_address1);
            st_address2 = (st_address1<<8);
//	    printf("\nst_address2 : 0x%x",st_address2);
            st_address1 = (hd_ptr_rx);
//	    printf("\nst_address1 : 0x%x",st_address1);
            st_address2 += (st_address1<<4);
//	    printf("\nst_address2 : 0x%x",st_address2);
            st_address2+=8;
//	    printf("\nst_address2 : 0x%x",st_address2);

		st_address2 = qm_get_va(st_address2);// _tp
//	    printf("\nst_address2 : 0x%x",st_address2);

            addr_1 = read(st_address2);
//	    printf("\naddr_1 : 0x%x",addr_1);
            addr_1 = addr_1 & 0x00000000ffffffff;   //masking uppar 32 bits
//	    printf("\naddr_1 : 0x%x",addr_1);

            addr_2 = read(st_address2+4);
//	    printf("\naddr_2 : 0x%x",addr_2);
            addr_2 = addr_2 & 0x00000000000003ff;   //keeping only last 10 bits
//	    printf("\naddr_2 : 0x%x",addr_2);
            addr_3 = addr_2 << 32;
//	    printf("\naddr_3 : 0x%x",addr_3);

            addr_4 = addr_3 + addr_1;               //getting 42 bits DATA ADDRESS field
//	    printf("\naddr_4 : 0x%x",addr_4);
            //ddr_base_rx_pkt[1]= addr_4;
		ddr_base_rx_pkt[1] = qm_get_va(addr_4);
            lprintf(8,"\nddr_base_rx_pkt[1] : 0x%x",ddr_base_rx_pkt[1]);
               //printf("\nq_state_pq_65_0 ===> st_address1 = 0x%x \t addr_1 = 0x%x \t addr_2 = 0x%x \t ddr_base_rx_pkt[1] : 0x%x",st_address1,addr_1,addr_2, ddr_base_rx_pkt[1]);

            break;

        //case 2:
        case 3:
#if 1    
            st_address1 = (q_state_pq_64_2[0].pqfp.st_addr);
            st_address2 = (st_address1<<8);
            st_address1 = (hd_ptr_rx);
            st_address2 += (st_address1<<4);
            st_address2+=8;

		st_address2 = qm_get_va(st_address2);// _tp

            addr_1 = read(st_address2);
            addr_1 = addr_1 & 0x00000000ffffffff;   //masking uppar 32 bits

            addr_2 = read(st_address2+4);
            addr_2 = addr_2 & 0x00000000000003ff;   //keeping only last 10 bits
            addr_3 = addr_2 << 32;

            addr_4 = addr_3 + addr_1;               //getting 42 bits DATA ADDRESS field
            //ddr_base_rx_pkt[2]= addr_4;
		ddr_base_rx_pkt[2] = qm_get_va(addr_4);
            lprintf(8,"\nddr_base_rx_pkt[2] : 0x%x",ddr_base_rx_pkt[2]);

            //  printf("\nq_state_pq_64_2 ===> st_address1 = 0x%x \t addr_1 = 0x%x \t addr_2 = 0x%x \t ddr_base_rx_pkt[2] : 0x%x",st_address1,addr_1,addr_2, ddr_base_rx_pkt[2]);
            break;

        //case 3:
        case 2:
            st_address1 = (q_state_pq_65_2[0].pqfp.st_addr);
            st_address2 = (st_address1<<8);
            st_address1 = (hd_ptr_rx);
            st_address2 += (st_address1<<4);
            st_address2+=8;

		st_address2 = qm_get_va(st_address2);// _tp

            addr_1 = read(st_address2);
            addr_1 = addr_1 & 0x00000000ffffffff;   //masking uppar 32 bits
            addr_2 = read(st_address2+4);
            addr_2 = addr_2 & 0x00000000000003ff;   //keeping only last 10 bits
            addr_3 = addr_2 << 32;
            addr_4 = addr_3 + addr_1;               //getting 42 bits DATA ADDRESS field
            //ddr_base_rx_pkt[3]= addr_4;
		ddr_base_rx_pkt[3] = qm_get_va(addr_4);
            lprintf(8,"\nddr_base_rx_pkt[3] : 0x%x",ddr_base_rx_pkt[3]);
            //   printf("\nq_state_pq_65_2 ===> st_address1 = 0x%x \t addr_1 = 0x%x \t addr_2 = 0x%x \t ddr_base_rx_pkt[3] : 0x%x",st_address1,addr_1,addr_2, ddr_base_rx_pkt[3]);

#endif
            break;
        default :
            printf("Worng port\n");
    }

    //USDELAY(1000);//-- ORIGINAL CODE --
    //USDELAY(5000);
    //	for(dela=0;dela<1000000;dela++);		
    //	for(dela=0;dela<1000000;dela++);		
    //	for(dela=0;dela<1000000;dela++);		

	//printf("\n\nHere - 1");

    //do {
	if(port_num_calc==0) port_num_wait=1;
	if(port_num_calc==1) port_num_wait=0;
	if(port_num_calc==2) port_num_wait=3;
	if(port_num_calc==3) port_num_wait=2;
    for(iter_count=0;iter_count<=1010;iter_count++) {
	//printf("\ndo-while for XGE-%d",port_num_calc);
    	read_rpkt_as[port_num_wait] = axgmac_stat_rd(PEMSTAT_RPKT__ADDR , port_num_wait);
    	read_rfcs_as[port_num_wait] = axgmac_stat_rd(PEMSTAT_RFCS__ADDR , port_num_wait);
	if(read_rpkt_as[port_num_wait] != 0 || read_rfcs_as[port_num_wait] != 0) break;
	USDELAY(1000);
    }
    //} while(read_rpkt_as[port_num_calc] == 0 && read_rfcs_as[port_num_calc] == 0);

    if(iter_count>1000) {
	printf("\n\n## Taking too long for packet reception !!! \n\n");
	printf("Waited for %d-ms\n\n",iter_count);
	printf("Packet count : %d",packet_count);
	stat_dump_per_port(port_num_wait,1);
    }

    stat_dump_per_port(port_num_wait,0);
	//printf("\n\nHere - 2");

    switch(port_num_calc) {
        case 1 :
            if(read_rpkt_as[0] || read_rfcs_as[0]){

                //printf("\n************** Comapring for port 0 ***************\n");
                //printf(".");

                for(k=0;k<64;k++){

                    //	crc_data_tx_0=read_as_32(temp_tx);
	//printf("\n\nHere - 3");
                    crc_data_tx_1=read_word(ddr_base_tx_pkt[1]+k*4);
                    crc_data_rx_0=read_word(ddr_base_rx_pkt[0]+k*4);


	//printf("\n\nHere - 4");
                    /*printf("^^^^^^^^^^^^^^^^^^^PASS : Port 0   ^^^^^^^^^^^^^^^^^ \n");
                      printf("############ MATCH at address 0x%x and 0x%x ###############\n",ddr_base_tx_pkt[0]+k*4,ddr_base_rx_pkt[0]+k*4);
                      printf("\n");
                      printf("############ MATCH data 0x%x and 0x%x ###############\n",crc_data_tx_0,crc_data_rx_0);
                      printf("\n");*/
                    if(crc_data_tx_1!=crc_data_rx_0)
                    {	
                        printf(" ** FAIL : Port 0 ( CRC ERROR)  ** \n");
                        printf("############ Mismatch at address 0x%x and 0x%x ###############\n",ddr_base_tx_pkt[1]+k*4,ddr_base_rx_pkt[0]+k*4);
                        printf("\n");
                        printf("############ Mismatch data 0x%x and 0x%x ###############\n",crc_data_tx_1,crc_data_rx_0);
                        printf("\n");
                        number_errors[0]++;
    total_err_count_xfi[0] = total_err_count_xfi[0] + number_errors[0];
                        //memset(ddr_base_tx_pkt[0]+k*4, 0,4);
                        // memset(ddr_base_rx_pkt[0]+k*4, 0,4);
                        //break;// -- ORIGINAL CODE -- Temp commented
                    }

                }
            }
            else
            {
                printf("** FAIL : Port 0 (didn't receive a packet) ** \n");
                number_errors[0]++;
    total_err_count_xfi[0] = total_err_count_xfi[0] + number_errors[0];
                //memset(ddr_base_tx_pkt[0]+k*4, 0,4);// -- ORIGINAL CODE -- Temp commented
                //memset(ddr_base_rx_pkt[0]+k*4, 0,4);// -- ORIGINAL CODE -- Temp commented
            }
            break;


        case 0 :
            if(read_rpkt_as[1] || read_rfcs_as[1]){

                //printf("\n************** Comapring for port 1 ***************\n");
                //printf(".");

                for(k=0;k<64;k++){

                    crc_data_tx_0=read_word(ddr_base_tx_pkt[0]+k*4);
                    crc_data_rx_1=read_word(ddr_base_rx_pkt[1]+k*4);
                    /*printf("^^^^^^^^^^^^^^^^^^^PASS : Port 1  ^^^^^^^^^^^^^^^^^ \n");
                      printf("############ MATCH at address 0x%x and 0x%x ###############\n",ddr_base_tx_pkt[0]+k*4,ddr_base_rx_pkt[0]+k*4);
                      printf("\n");
                      printf("############ MATCH data 0x%x and 0x%x ###############\n",crc_data_tx_0,crc_data_rx_0);
                      printf("\n");*/

                    if(crc_data_tx_0!=crc_data_rx_1)
                    {
                        printf("** FAIL : Port 1 ( CRC ERROR)  ** \n");
                        printf("############ Mismatch at 0x%x and 0x%x ###############\n",ddr_base_tx_pkt[0]+k*4,ddr_base_rx_pkt[1]+k*4);
                        printf("\n");
                        printf("############ Mismatch data 0x%x and 0x%x ###############\n",crc_data_tx_0,crc_data_rx_1);
                        printf("\n");
                        number_errors[1]++;
    total_err_count_xfi[1] = total_err_count_xfi[1] + number_errors[1];
                        //  memset(ddr_base_tx_pkt[1]+k*4, 0,4);
                        //   memset(ddr_base_rx_pkt[1]+k*4, 0,4);
                        //break;// -- ORIGINAL CODE -- Temp commented
                    }
                }
            }
            else
            {
                printf("** FAIL : Port 1 (didn't receive a packet) ** \n");
                number_errors[1]++;
    total_err_count_xfi[1] = total_err_count_xfi[1] + number_errors[1];
                //memset(ddr_base_tx_pkt[1]+k*4, 0,4);// -- ORIGINAL CODE -- Temp commented
                //memset(ddr_base_rx_pkt[1]+k*4, 0,4);// -- ORIGINAL CODE -- Temp commented
            }
            break;

#if 1

        case 3 :
            if(read_rpkt_as[2] || read_rfcs_as[2]){

                //printf("\n************** Comapring for port 2 ***************\n");
                //printf(".");

                for(k=0;k<64;k++){

                    crc_data_tx_3=read_word(ddr_base_tx_pkt[3]+k*4);
                    crc_data_rx_2=read_word(ddr_base_rx_pkt[2]+k*4);
                    /*printf("^^^^^^^^^^^^^^^^^^^PASS : Port 2   ^^^^^^^^^^^^^^^^^ \n");
                      printf("############ MATCH at address 0x%x and 0x%x ###############\n",ddr_base_tx_pkt[0]+k*4,ddr_base_rx_pkt[0]+k*4);
                      printf("\n");
                      printf("############ MATCH data 0x%x and 0x%x ###############\n",crc_data_tx_0,crc_data_rx_0);
                      printf("\n");*/

                    if(crc_data_tx_3!=crc_data_rx_2)
                    {				
                        printf("** FAIL : Port 2 ( CRC ERROR)  ** \n");
                        printf("############ Mismatch at 0x%x and 0x%x ###############\n",ddr_base_tx_pkt[3]+k*4,ddr_base_rx_pkt[2]+k*4);
                        printf("\n");
                        printf("############ Mismatch data 0x%x and 0x%x ###############\n",crc_data_tx_3,crc_data_rx_2);
                        printf("\n");
                        number_errors[2]++;
    total_err_count_xfi[2] = total_err_count_xfi[2] + number_errors[2];
                        //  memset(ddr_base_tx_pkt[2]+k*4, 0,4);
                        //memset(ddr_base_rx_pkt[2]+k*4, 0,4);
                        //break;// -- ORIGINAL CODE -- Temp commented
                    }
                }
            }
            else
            {printf("** FAIL : Port 2 (didn't receive a packet) ** \n");
                number_errors[2]++;
    total_err_count_xfi[2] = total_err_count_xfi[2] + number_errors[2];
                //memset(ddr_base_tx_pkt[2]+k*4, 0,4);// -- ORIGINAL CODE -- Temp commented
                //memset(ddr_base_rx_pkt[2]+k*4, 0,4);// -- ORIGINAL CODE -- Temp commented
            }
            break;



        case 2 :
            if(read_rpkt_as[3] || read_rfcs_as[3]){

                //printf("\n************** Comapring for port 3 ***************\n");
                //printf(".");
                /*printf("^^^^^^^^^^^^^^^^^^^PASS : Port 3   ^^^^^^^^^^^^^^^^^ \n");
                  printf("############ MATCH at address 0x%x and 0x%x ###############\n",ddr_base_tx_pkt[0]+k*4,ddr_base_rx_pkt[0]+k*4);
                  printf("\n");
                  printf("############ MATCH data 0x%x and 0x%x ###############\n",crc_data_tx_0,crc_data_rx_0);
                  printf("\n");*/

                for(k=0;k<64;k++){
                    crc_data_tx_2=read_word(ddr_base_tx_pkt[2]+k*4);
                    crc_data_rx_3=read_word(ddr_base_rx_pkt[3]+k*4);

                    if(crc_data_tx_2!=crc_data_rx_3)
                    {	
                        printf("** FAIL : Port 3 ( CRC ERROR)  **  \n");
                        printf("############ Mismatch at 0x%x and 0x%x ###############\n",ddr_base_tx_pkt[2]+k*4,ddr_base_rx_pkt[3]+k*4);
                        printf("\n");
                        printf("############ Mismatch data 0x%x and 0x%x ###############\n",crc_data_tx_2,crc_data_rx_3);
                        printf("\n");
                        number_errors[3]++;
    total_err_count_xfi[3] = total_err_count_xfi[3] + number_errors[3];
                        //    memset(ddr_base_tx_pkt[3]+k*4, 0,4);
                        //  memset(ddr_base_rx_pkt[3]+k*4, 0,4);
                        //break;// -- ORIGINAL CODE -- Temp commented
                    }
                }
            }
            else
            {printf("** FAIL : Port 3 (didn't receive a packet) **  \n");
                number_errors[3]++;
    total_err_count_xfi[3] = total_err_count_xfi[3] + number_errors[3];
                //memset(ddr_base_tx_pkt[3]+k*4, 0,4);// -- ORIGINAL CODE -- Temp commented
                //memset(ddr_base_rx_pkt[3]+k*4, 0,4);// -- ORIGINAL CODE -- Temp commented
            }
            break;
#endif
        default :
            printf("\nOops !! Invalid port number passed\n");


    }


}

void no_test_dueto_link_error() {
  printf("\n\nTest Aborted due to following reason :\tLink Down on one or multiple XFI ports");
  printf("\n\nPlease check the setup, connections, etc. and re-run the test\n\n");
  printf("\nTest Result : FAIL\n");

}

int cable_connect_check(int test_num) {
  int k , port_count , rx_port_count , iteration_count;
  int link_down_pass_count , link_up_pass_count , link_down_intr_fail_count , link_up_intr_fail_count , reg_val_intr;
  int reg_val_1 , reg_val_2 , reg_val_3;
  int test_fail[4]={0};

  printf("\n\nRunning Cable Connection Check by using Link-up test...");

//Clear all interrupts ...
  for(port_count=0; port_count<=3; port_count++)
     eth_wr(SM_XGENET_CSR_LINK_STS_INTR__ADDR , 1, XGENET , port_count , 0);

  iteration_count = 100;

//Remember ... SFP+ Lasers are turned ON by by now

  if(test_num == 0x34) { // This is self loopback test

  for(port_count=0; port_count<=3; port_count++) {
     printf("\nRunning Link Up Test for XGE-%d ... ",port_count);
     link_down_pass_count = 0;
     link_up_pass_count = 0;
     link_down_intr_fail_count = 0;
     link_up_intr_fail_count = 0;
     for(k=0; k<iteration_count; k++) {

        sfp_plus_laser_off(port_count,0); USDELAY(2000);

        reg_val_intr = eth_rd(SM_XGENET_CSR_LINK_STS_INTR__ADDR , XGENET , port_count , 0);
        reg_val_intr = reg_val_intr & 0x1;
        if(reg_val_intr != 0x1) link_down_intr_fail_count++;
        eth_wr(SM_XGENET_CSR_LINK_STS_INTR__ADDR , 1, XGENET , port_count , 0);//Clear the Interrupt

        reset_pcs(port_count); USDELAY(100);

        reg_val_1 = eth_rd(SM_XGENET_CSR_LINK_STATUS__ADDR , XGENET , port_count , 0);
        reg_val_2 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_1__ADDR , port_count , 0);
        reg_val_2 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_1__ADDR , port_count , 0);
        reg_val_2 = (reg_val_2 >> 2) & 0x1;
        reg_val_3 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_3__ADDR , port_count , 0);
        reg_val_3 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_3__ADDR , port_count , 0);
        reg_val_3 = (reg_val_3 >> 12) & 0x1;
        if(reg_val_1 == 0 && reg_val_2 == 0 && reg_val_3 == 0 && link_down_intr_fail_count == 0) link_down_pass_count++;

        sfp_plus_laser_on(port_count,0); USDELAY(100);

        reg_val_intr = eth_rd(SM_XGENET_CSR_LINK_STS_INTR__ADDR , XGENET , port_count , 0);
        reg_val_intr = reg_val_intr & 0x1;
        if(reg_val_intr != 0x1) link_up_intr_fail_count++;
        eth_wr(SM_XGENET_CSR_LINK_STS_INTR__ADDR , 1, XGENET , port_count , 0);//Clear the Interrupt

        reset_pcs(port_count); USDELAY(100);

        reg_val_1 = eth_rd(SM_XGENET_CSR_LINK_STATUS__ADDR , XGENET , port_count , 0);
        reg_val_2 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_1__ADDR , port_count , 0);
        reg_val_2 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_1__ADDR , port_count , 0);
        reg_val_2 = (reg_val_2 >> 2) & 0x1;
        reg_val_3 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_3__ADDR , port_count , 0);
        reg_val_3 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_3__ADDR , port_count , 0);
        reg_val_3 = (reg_val_3 >> 12) & 0x1;
        if(reg_val_1 == 1 && reg_val_2 == 1 && reg_val_3 == 1 && link_up_intr_fail_count == 0) link_up_pass_count++;
     }

     if((link_down_pass_count != iteration_count) || (link_up_pass_count != iteration_count)) {
       printf("Test FAILED !! ([link_down_pass_count:%d][link_up_pass_count:%d][iteration_count:%d])",link_down_pass_count,link_up_pass_count,iteration_count);
       printf(" ([Link Down INTR fail count:%d][Link Up INTR fail count:%d])",link_down_intr_fail_count,link_up_intr_fail_count);
       test_fail[port_count]++;
     }
     else
       printf("Test PASSED !!");
  }

  } // if(test_num == 0x34)

  if(test_num == 0x35 || test_num == 0x36) { // This is port-to-port loopback test

  for(rx_port_count=0; rx_port_count<=3; rx_port_count++) {
     printf("\nRunning Link Up Test for XGE-%d ... ",rx_port_count);
     link_down_pass_count = 0;
     link_up_pass_count = 0;
     link_down_intr_fail_count = 0;
     link_up_intr_fail_count = 0;
     if(rx_port_count == 0 || rx_port_count == 2) port_count = rx_port_count + 1; else port_count = rx_port_count - 1;
     for(k=0; k<iteration_count; k++) {

        sfp_plus_laser_off(port_count,0); USDELAY(2000);

        reg_val_intr = eth_rd(SM_XGENET_CSR_LINK_STS_INTR__ADDR , XGENET , rx_port_count , 0);
        reg_val_intr = reg_val_intr & 0x1;
        if(reg_val_intr != 0x1) link_down_intr_fail_count++;
        eth_wr(SM_XGENET_CSR_LINK_STS_INTR__ADDR , 1, XGENET , rx_port_count , 0);//Clear the Interrupt

        reset_pcs(port_count);    USDELAY(100);
        reset_pcs(rx_port_count); USDELAY(100);

        reg_val_1 = eth_rd(SM_XGENET_CSR_LINK_STATUS__ADDR , XGENET , rx_port_count , 0);
        reg_val_2 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_1__ADDR , rx_port_count , 0);
        reg_val_2 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_1__ADDR , rx_port_count , 0);
        reg_val_2 = (reg_val_2 >> 2) & 0x1;
        reg_val_3 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_3__ADDR , rx_port_count , 0);
        reg_val_3 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_3__ADDR , rx_port_count , 0);
        reg_val_3 = (reg_val_3 >> 12) & 0x1;
        if(reg_val_1 == 0 && reg_val_2 == 0 && reg_val_3 == 0 && link_down_intr_fail_count == 0) link_down_pass_count++;

        sfp_plus_laser_on(port_count,0); USDELAY(100);

        reg_val_intr = eth_rd(SM_XGENET_CSR_LINK_STS_INTR__ADDR , XGENET , rx_port_count , 0);
        reg_val_intr = reg_val_intr & 0x1;
        if(reg_val_intr != 0x1) link_up_intr_fail_count++;
        eth_wr(SM_XGENET_CSR_LINK_STS_INTR__ADDR , 1, XGENET , rx_port_count , 0);//Clear the Interrupt

        reset_pcs(port_count);    USDELAY(100);
        reset_pcs(rx_port_count); USDELAY(100);

        reg_val_1 = eth_rd(SM_XGENET_CSR_LINK_STATUS__ADDR , XGENET , rx_port_count , 0);
        reg_val_2 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_1__ADDR , rx_port_count , 0);
        reg_val_2 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_1__ADDR , rx_port_count , 0);
        reg_val_2 = (reg_val_2 >> 2) & 0x1;
        reg_val_3 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_3__ADDR , rx_port_count , 0);
        reg_val_3 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_3__ADDR , rx_port_count , 0);
        reg_val_3 = (reg_val_3 >> 12) & 0x1;
        if(reg_val_1 == 1 && reg_val_2 == 1 && reg_val_3 == 1 && link_up_intr_fail_count == 0) link_up_pass_count++;
     }

     if((link_down_pass_count != iteration_count) || (link_up_pass_count != iteration_count)) {
       printf("Test FAILED !! ([link_down_pass_count:%d][link_up_pass_count:%d][iteration_count:%d])",link_down_pass_count,link_up_pass_count,iteration_count);
       printf(" ([Link Down INTR fail count:%d][Link Up INTR fail count:%d])",link_down_intr_fail_count,link_up_intr_fail_count);
       test_fail[rx_port_count]++;
     }
     else
       printf("Test PASSED !!");
  }

  } // if(test_num == 0x35 OR 0x36)

  if(test_fail[0]>0 || test_fail[1]>0) {
	printf("\n\nCable connection suspected to be wrong on one or multiple ports.");
	printf("\nPlease check cable connection and re-run the test.\n");
	printf("\nIf the symptom is repeating, this could be the part issue");
        printf("\nTest Result : FAIL\n");
  }
  if(test_fail[2]>0 || test_fail[3]>0) {
	printf("\nCable connection issue found on XGE-2/3, but not on XGE-0/1");
	printf("\nTest will be run on XGE-0/1\n");
  }
  if(test_fail[0]==0 && test_fail[1]==0 && test_fail[2]==0 && test_fail[3]==0) 
	printf("\nCable connection found ok, proceeding for the test ...\n");

  return test_fail[0]+test_fail[1];

}

int cable_connect_check_man() {
  int k , port_count , rx_port_count , iteration_count;
  int test_num;
  int link_down_pass_count , link_up_pass_count , link_down_intr_fail_count , link_up_intr_fail_count , reg_val_intr;
  int reg_val_1 , reg_val_2 , reg_val_3;
  int test_fail=0;

  printf("\nManual Cable connection check...");
  printf("\nEnter Test No. from Test Menu : 0x");
  if(terminal_server_serial_port==1) test_num = get_val(); test_num = get_val();

  printf("\n\nRunning Cable Connection Check by using Link-up test...");

//Clear all interrupts ...
  for(port_count=0; port_count<=3; port_count++)
     eth_wr(SM_XGENET_CSR_LINK_STS_INTR__ADDR , 1, XGENET , port_count , 0);

  iteration_count = 100;

//Remember ... SFP+ Lasers are turned ON by by now

  if(test_num == 0x34) { // This is self loopback test

  for(port_count=0; port_count<=3; port_count++) {
     printf("\nRunning Link Up Test for XGE-%d ... ",port_count);
     link_down_pass_count = 0;
     link_up_pass_count = 0;
     link_down_intr_fail_count = 0;
     link_up_intr_fail_count = 0;
     for(k=0; k<iteration_count; k++) {

        sfp_plus_laser_off(port_count,0); USDELAY(2000);

        reg_val_intr = eth_rd(SM_XGENET_CSR_LINK_STS_INTR__ADDR , XGENET , port_count , 0);
        reg_val_intr = reg_val_intr & 0x1;
        if(reg_val_intr != 0x1) link_down_intr_fail_count++;
        eth_wr(SM_XGENET_CSR_LINK_STS_INTR__ADDR , 1, XGENET , port_count , 0);//Clear the Interrupt

        reset_pcs(port_count); USDELAY(100);

        reg_val_1 = eth_rd(SM_XGENET_CSR_LINK_STATUS__ADDR , XGENET , port_count , 0);
        reg_val_2 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_1__ADDR , port_count , 0);
        reg_val_2 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_1__ADDR , port_count , 0);
        reg_val_2 = (reg_val_2 >> 2) & 0x1;
        reg_val_3 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_3__ADDR , port_count , 0);
        reg_val_3 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_3__ADDR , port_count , 0);
        reg_val_3 = (reg_val_3 >> 12) & 0x1;
        if(reg_val_1 == 0 && reg_val_2 == 0 && reg_val_3 == 0 && link_down_intr_fail_count == 0) link_down_pass_count++;

        sfp_plus_laser_on(port_count,0); USDELAY(100);

        reg_val_intr = eth_rd(SM_XGENET_CSR_LINK_STS_INTR__ADDR , XGENET , port_count , 0);
        reg_val_intr = reg_val_intr & 0x1;
        if(reg_val_intr != 0x1) link_up_intr_fail_count++;
        eth_wr(SM_XGENET_CSR_LINK_STS_INTR__ADDR , 1, XGENET , port_count , 0);//Clear the Interrupt

        reset_pcs(port_count); USDELAY(100);

        reg_val_1 = eth_rd(SM_XGENET_CSR_LINK_STATUS__ADDR , XGENET , port_count , 0);
        reg_val_2 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_1__ADDR , port_count , 0);
        reg_val_2 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_1__ADDR , port_count , 0);
        reg_val_2 = (reg_val_2 >> 2) & 0x1;
        reg_val_3 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_3__ADDR , port_count , 0);
        reg_val_3 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_3__ADDR , port_count , 0);
        reg_val_3 = (reg_val_3 >> 12) & 0x1;
        if(reg_val_1 == 1 && reg_val_2 == 1 && reg_val_3 == 1 && link_up_intr_fail_count == 0) link_up_pass_count++;
     }

     if((link_down_pass_count != iteration_count) || (link_up_pass_count != iteration_count)) {
       printf("Test FAILED !! ([link_down_pass_count:%d][link_up_pass_count:%d][iteration_count:%d])",link_down_pass_count,link_up_pass_count,iteration_count);
       printf(" ([Link Down INTR fail count:%d][Link Up INTR fail count:%d])",link_down_intr_fail_count,link_up_intr_fail_count);
       test_fail++;
     }
     else
       printf("Test PASSED !!");
  }

  } // if(test_num == 0x34)

  if(test_num == 0x35 || test_num == 0x36) { // This is port-to-port loopback test

  for(port_count=0; port_count<=3; port_count++) {
     printf("\nRunning Link Up Test for XGE-%d ... ",port_count);
     link_down_pass_count = 0;
     link_up_pass_count = 0;
     link_down_intr_fail_count = 0;
     link_up_intr_fail_count = 0;
     if(port_count == 0 || port_count == 2) rx_port_count = port_count + 1; else rx_port_count = port_count - 1;
     for(k=0; k<iteration_count; k++) {

        sfp_plus_laser_off(port_count,0); USDELAY(2000);

        reg_val_intr = eth_rd(SM_XGENET_CSR_LINK_STS_INTR__ADDR , XGENET , rx_port_count , 0);
        reg_val_intr = reg_val_intr & 0x1;
        if(reg_val_intr != 0x1) link_down_intr_fail_count++;
        eth_wr(SM_XGENET_CSR_LINK_STS_INTR__ADDR , 1, XGENET , rx_port_count , 0);//Clear the Interrupt

        reset_pcs(port_count);    USDELAY(100);
        reset_pcs(rx_port_count); USDELAY(100);

        reg_val_1 = eth_rd(SM_XGENET_CSR_LINK_STATUS__ADDR , XGENET , rx_port_count , 0);
        reg_val_2 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_1__ADDR , rx_port_count , 0);
        reg_val_2 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_1__ADDR , rx_port_count , 0);
        reg_val_2 = (reg_val_2 >> 2) & 0x1;
        reg_val_3 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_3__ADDR , rx_port_count , 0);
        reg_val_3 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_3__ADDR , rx_port_count , 0);
        reg_val_3 = (reg_val_3 >> 12) & 0x1;
        if(reg_val_1 == 0 && reg_val_2 == 0 && reg_val_3 == 0 && link_down_intr_fail_count == 0) link_down_pass_count++;

        sfp_plus_laser_on(port_count,0); USDELAY(100);

        reg_val_intr = eth_rd(SM_XGENET_CSR_LINK_STS_INTR__ADDR , XGENET , rx_port_count , 0);
        reg_val_intr = reg_val_intr & 0x1;
        if(reg_val_intr != 0x1) link_up_intr_fail_count++;
        eth_wr(SM_XGENET_CSR_LINK_STS_INTR__ADDR , 1, XGENET , rx_port_count , 0);//Clear the Interrupt

        reset_pcs(port_count);    USDELAY(100);
        reset_pcs(rx_port_count); USDELAY(100);

        reg_val_1 = eth_rd(SM_XGENET_CSR_LINK_STATUS__ADDR , XGENET , rx_port_count , 0);
        reg_val_2 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_1__ADDR , rx_port_count , 0);
        reg_val_2 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_1__ADDR , rx_port_count , 0);
        reg_val_2 = (reg_val_2 >> 2) & 0x1;
        reg_val_3 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_3__ADDR , rx_port_count , 0);
        reg_val_3 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_PCS_STATUS_3__ADDR , rx_port_count , 0);
        reg_val_3 = (reg_val_3 >> 12) & 0x1;
        if(reg_val_1 == 1 && reg_val_2 == 1 && reg_val_3 == 1 && link_up_intr_fail_count == 0) link_up_pass_count++;
     }

     if((link_down_pass_count != iteration_count) || (link_up_pass_count != iteration_count)) {
       printf("Test FAILED !! ([link_down_pass_count:%d][link_up_pass_count:%d][iteration_count:%d])",link_down_pass_count,link_up_pass_count,iteration_count);
       printf(" ([Link Down INTR fail count:%d][Link Up INTR fail count:%d])",link_down_intr_fail_count,link_up_intr_fail_count);
       test_fail++;
     }
     else
       printf("Test PASSED !!");
  }

  } // if(test_num == 0x35 OR 0x36)

  if(test_fail > 0) {
	printf("\n\nCable connection suspected to be wrong on one or multiple ports.");
	printf("\nPlease check cable connection and re-run the test.\n");
        printf("\nTest Result : FAIL\n");
  }
  else
	printf("\nCable connection found ok, proceeding for the test ...\n");

  return test_fail;

}

void sfp_plus_laser_off(int sfpp_port, int display)
{
/*
  I2C-IO Expander U35 pin-map on Blackbird | I2C-IO Expander U36 pin-map on Blackbird
  IO[7] : P0_SFPP_RXLOS     [IN]           | IO[7] : P2_SFPP_RXLOS     [IN]
  IO[6] : P0_SFPP_TXFAULT   [IN]           | IO[6] : P2_SFPP_TXFAULT   [IN]
  IO[5] : P0_SFPP_MODABS    [IN]           | IO[5] : P2_SFPP_MODABS    [IN]
  IO[4] : P0_SFPP_TXDISABLE [OUT]          | IO[4] : P2_SFPP_TXDISABLE [OUT]
                                           |
  IO[3] : P1_SFPP_RXLOS     [IN]           | IO[3] : P3_SFPP_RXLOS     [IN]
  IO[2] : P1_SFPP_TXFAULT   [IN]           | IO[2] : P3_SFPP_TXFAULT   [IN]
  IO[1] : P1_SFPP_MODABS    [IN]           | IO[1] : P3_SFPP_MODABS    [IN]
  IO[0] : P1_SFPP_TXDISABLE [OUT]          | IO[0] : P3_SFPP_TXDISABLE [OUT]
        ( I2C Address : 0x26 )             |       ( I2C Address : 0x27 )
*/

  u8 buf[2], m0_status, read_i2c_status_01, read_i2c_status_03;

  i2c_set_bus_num(1);//This is done to make sure that it enables correct I2C Bus in nor_ddr_up mode

  if(display == 1)
  printf("\nTurning off SFP+ laser for port P%d ... ",sfpp_port);

  buf[0] = 0x01; buf[1] = 0;
  i2c_write(0x71,0x0,0,buf,1);

  if (sfpp_port == 0) {
    buf[0] = 0x01; i2c_write(0x26,0x0,0,buf,1); i2c_read(0x26,0x0,0,buf,1); read_i2c_status_01 = buf[0];
    buf[0] = 0x03; i2c_write(0x26,0x0,0,buf,1); i2c_read(0x26,0x0,0,buf,1); read_i2c_status_03 = buf[0];

    buf[0] = 0x01; buf[1] = read_i2c_status_01 | 0x10; i2c_write(0x26,0x0,0,buf,2);
    buf[0] = 0x03; buf[1] = read_i2c_status_03 | 0x10; i2c_write(0x26,0x0,0,buf,2);

    buf[0] = 0x01; i2c_write(0x26,0x0,0,buf,1); i2c_read(0x26,0x0,0,buf,1); m0_status = buf[0] & 0x10;

    if (m0_status == 0x10) {
      if(display == 1)
      printf("Successful for port P%d !",sfpp_port);
    } else {
      if(display == 1)
      printf("ERROR: SFP+ laser hasn't been turned off for port P%d !!! Please check !\n\r",sfpp_port);
    }

  }

  if (sfpp_port == 1) {
    buf[0] = 0x01; i2c_write(0x26,0x0,0,buf,1); i2c_read(0x26,0x0,0,buf,1); read_i2c_status_01 = buf[0];
    buf[0] = 0x03; i2c_write(0x26,0x0,0,buf,1); i2c_read(0x26,0x0,0,buf,1); read_i2c_status_03 = buf[0];

    buf[0] = 0x01; buf[1] = read_i2c_status_01 | 0x01; i2c_write(0x26,0x0,0,buf,2);
    buf[0] = 0x03; buf[1] = read_i2c_status_03 | 0x01; i2c_write(0x26,0x0,0,buf,2);

    buf[0] = 0x01; i2c_write(0x26,0x0,0,buf,1); i2c_read(0x26,0x0,0,buf,1); m0_status = buf[0] & 0x01;

    if (m0_status == 0x01) {
      if(display == 1)
      printf("Successful for port P%d !",sfpp_port);
    } else {
      if(display == 1)
      printf("ERROR: SFP+ laser hasn't been turned off for port P%d !!! Please check !\n\r",sfpp_port);
    }

  }

  if (sfpp_port == 2) {
    buf[0] = 0x01; i2c_write(0x27,0x0,0,buf,1); i2c_read(0x27,0x0,0,buf,1); read_i2c_status_01 = buf[0];
    buf[0] = 0x03; i2c_write(0x27,0x0,0,buf,1); i2c_read(0x27,0x0,0,buf,1); read_i2c_status_03 = buf[0];

    buf[0] = 0x01; buf[1] = read_i2c_status_01 | 0x10; i2c_write(0x27,0x0,0,buf,2);
    buf[0] = 0x03; buf[1] = read_i2c_status_03 | 0x10; i2c_write(0x27,0x0,0,buf,2);

    buf[0] = 0x01; i2c_write(0x27,0x0,0,buf,1); i2c_read(0x27,0x0,0,buf,1); m0_status = buf[0] & 0x10;

    if (m0_status == 0x10) {
      if(display == 1)
      printf("Successful for port P%d !",sfpp_port);
    } else {
      if(display == 1)
      printf("ERROR: SFP+ laser hasn't been turned off for port P%d !!! Please check !\n\r",sfpp_port);
    }

  }

  if (sfpp_port == 3) {
    buf[0] = 0x01; i2c_write(0x27,0x0,0,buf,1); i2c_read(0x27,0x0,0,buf,1); read_i2c_status_01 = buf[0];
    buf[0] = 0x03; i2c_write(0x27,0x0,0,buf,1); i2c_read(0x27,0x0,0,buf,1); read_i2c_status_03 = buf[0];

    buf[0] = 0x01; buf[1] = read_i2c_status_01 | 0x01; i2c_write(0x27,0x0,0,buf,2);
    buf[0] = 0x03; buf[1] = read_i2c_status_03 | 0x01; i2c_write(0x27,0x0,0,buf,2);

    buf[0] = 0x01; i2c_write(0x27,0x0,0,buf,1); i2c_read(0x27,0x0,0,buf,1); m0_status = buf[0] & 0x01;

    if (m0_status == 0x01) {
      if(display == 1)
      printf("Successful for port P%d !",sfpp_port);
    } else {
      if(display == 1)
      printf("ERROR: SFP+ laser hasn't been turned off for port P%d !!! Please check !\n\r",sfpp_port);
    }

  }


}//End of sfp_plus_laser_off()

void enable_64_byte_axi_write_padding() {
   int reg_read , spare_config_enable , k;
   //printf("\n\nDo you wish to enable 64-Byte AXI Write padding ? (0:No, 1:Yes) : ");
   //spare_config_enable = get_val(); //spare_config_enable = get_val();
   spare_config_enable = 1;
   if(spare_config_enable == 1) {
//     printf("\n\nConfiguring ENET_SPARE_CFG_REG ...");
     printf("\nEnabling 64-Byte AXI Write padding ...");
     for(k=0; k<=3;k++) {
       reg_read = eth_rd(SM_XGENET_CSR_ENET_SPARE_CFG_REG__ADDR , XGENET , k , 0);//Read first time
       reg_read = reg_read | 0x00020000;                                          //Enable spare_cfg[4]
       eth_wr(SM_XGENET_CSR_ENET_SPARE_CFG_REG__ADDR , reg_read , XGENET , k , 0);//Write spare_cfg
       reg_read = eth_rd(SM_XGENET_CSR_ENET_SPARE_CFG_REG__ADDR , XGENET , k , 0);//Read new value
//       printf("\nXGE-%d ==> ENET_SPARE_CFG_REG : 0x%x", k , reg_read);            //Print latest value
     }
   }
}

void sw_workaround() {
  int k , display=0;
  printf("\n\nApplying Sw workaround for all 4 ports ...");
  for(k=0; k<=3; k++) {
     eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR  , 0xff010043 , XGENET , k , display);
     eth_wr(SM_XGENET_CSR_RSIF_CONFIG1_REG__ADDR , 0x00000141 , XGENET , k , display);
  }
  printf(" Done");
}

void config_rsif_vc2() {
  int k , display=0;
  int read_data;

  printf("\n\nSetting VC2 for XGENET RSIF for all 4 ports ...");
  for(k=0; k<=3; k++) {
     read_data = eth_rd(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR , XGENET , k , display);
     read_data = read_data & 0xfffbffff;
     read_data = read_data | 0x00080000;
     eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, read_data , XGENET , k , display);
  }
  printf(" Done");
}

void dis_compl_msg() {
  int k , display=0;
  int read_data;

  printf("\n\nDisabling Completion Msg in XGENET TSIF for all 4 ports ...");
  for(k=0; k<=3; k++) {
     read_data = eth_rd(SM_XGENET_CSR_TSIF_CONFIG_REG_0__ADDR , XGENET , k , display);
     read_data = read_data & 0xfffffbff;
     eth_wr(SM_XGENET_CSR_TSIF_CONFIG_REG_0__ADDR, read_data , XGENET , k , display);
  }
  printf(" Done");
}

void set_mcu_hpweight(int weight) {
  printf("\nSetting MCU_HPWEIGHT to 0x%x for all 4 MCUs ...",weight);
  write(0x7e800000,weight);  write(0x7e840000,weight);  write(0x7e880000,weight);  write(0x7e8c0000,weight);
  printf(" Done");
}

void set_mcu_lpweight(int weight) {
  printf("\nSetting MCU_LPWEIGHT to 0x%x for all 4 MCUs ...",weight);
  write(0x7e800004,weight);  write(0x7e840004,weight);  write(0x7e880004,weight);  write(0x7e8c0004,weight);
  printf(" Done");
}

void set_mcu_wpweight(int weight) {
  printf("\nSetting MCU_WPWEIGHT to 0x%x for all 4 MCUs ...",weight);
  write(0x7e800008,weight);  write(0x7e840008,weight);  write(0x7e880008,weight);  write(0x7e8c0008,weight);
  printf(" Done");
}

void set_mcu_ref_burst_cnt(int ref_burst_cnt) {
  printf("\nSetting MCU_REFRESH_BURST_CNT to 0x%x for all 4 MCUs ...",ref_burst_cnt);
  write(0x7e800098,ref_burst_cnt);  write(0x7e840098,ref_burst_cnt);  write(0x7e880098,ref_burst_cnt);  write(0x7e8c0098,ref_burst_cnt);
  printf(" Done");
}

int external_tx2rx_p2p_new_loopback_test_4_ports() {
  int port,display=0;
  int read_data , retval;

  enable_l3_cache();//Enable L3 cache ...
  enable_64_byte_axi_write_padding();//Enable 64-Byte AXI Write padding

  printf("\n");
  int reg_1 , reg_2 , reg_3 , reg_4;
  //reg_1 = read(0x1f60c200); reg_2 = read(0x1f60c208); reg_3 = read(0x1f70c200); reg_4 = read(0x1f70c208);
  //if(reg_1==0x3 && reg_2==0 && reg_3==0x3 && reg_4==0) {
      cle_bypass_function_xfi();
  //}

  USDELAY(100);
  qmi_config_local_xfi();

  //data_cache_flush_all();

  USDELAY(1000);
  qm_n_function_xfi_dummy_1();

  sw_workaround();//Sw workaround as given in XGENET EAS
  config_rsif_vc2();//Set VC2 for Eth RSIF
  dis_compl_msg();//Disable completion messages in TSIF


// Commented below lines due to issue with 2DPC used in CH-0 & 2
//  set_mcu_ref_burst_cnt(0x1);//Set DDR Refresh Burst count = 1
//  set_mcu_hpweight(0x300);//Set MCU_HPWEIGHT to highest priority
//  set_mcu_lpweight(0x200);//Set MCU_LPWEIGHT to 2nd highest priority
//  set_mcu_wpweight(0x100);//Set MCU_WPWEIGHT to lowest priority

  //Check for PCS FIFO Overflow/Underflow
  //If found, then declare as hard-failure
  //retval = check_pcsfifo_status();
  //if(retval==1) return 1;

  //Clear mac stat before we start eth traffic
  for(port=0;port<=3;port++) stat_dump_per_port(port,0); 

  USDELAY(10000);
  eth_tx2rx_lpbk_xfi_10g_p2p();

}


int eth_tx2rx_lpbk_xfi_10g_p2p() {	// 23-Jun-2014

  read_rpkt_as_xg[0] = 0;
  read_rpkt_as_xg[1] = 0;
  read_rpkt_as_xg[2] = 0;
  read_rpkt_as_xg[3] = 0;

  read_rpkt_as_bak_xg[0] = 0;
  read_rpkt_as_bak_xg[1] = 0;
  read_rpkt_as_bak_xg[2] = 0;
  read_rpkt_as_bak_xg[3] = 0;

    total_err_count_xfi[0]=0;
    total_err_count_xfi[1]=0;
    total_err_count_xfi[2]=0;
    total_err_count_xfi[3]=0;
    unsigned int ps,pn,temp;
    u64 *guess;
    qm_ret_t ret;
    enq_req_t *per;
    enq_req_t *per32;
    enq_req_t *per33;
    enq_req_t *per34;    
    qm_buf_t qm_buf_xfi;
    qm_buf_t qm_buf32_xfi;
    qm_buf_t qm_buf33_xfi;
    qm_buf_t qm_buf34_xfi;    
    enq_cfg_t enq_cfg;
    q_state_t cfg;
    int tx_port,rx_port, mn; 
    int port,i,retval;
    u32 fpqid , dots;
    u8 pdl_pattern,qmid;
    u16 tx_enq_qid, rx_deq_qid;

    qm_buf_xfi.bp = buf_xfi;
    qm_buf32_xfi.bp = buf32_xfi;
    qm_buf33_xfi.bp = buf33_xfi;
    qm_buf34_xfi.bp = buf34_xfi; 

    memset ((u8 *)msgbuf_xfi, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    memset ((u8 *)msgbuf32_xfi, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    memset ((u8 *)msgbuf33_xfi, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    memset ((u8 *)msgbuf34_xfi, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);

    //ps=256; 
    ps=512; 
    //pn=0x280000; //0x40000; //0x100000; //10; //10000; //100;
    //pn=0x140000; //0x40000; //0x100000; //10; //10000; //100; // -- ORIGINAL CODE --
    //pn=0x280000;//This sends out 10-M packets. Runs for about 6-mins //New BLT requirement
    //pn=250;
    //pn=0x220000;//This sends out 8.9-M packets. Runs for about 5-mins // -- New requirement for BLT
    //Tinh: change the 25M to 10M 
    //pn=0x5F5E10;//This sends out 25-M packets. Runs for about 5-mins // -- New requirement for BLT
    pn=0x2625a0; //This sends out 10-M packets. Runs for about 3-mins // -- New requirement for BLT

    total_no_of_pkts = pn * 4;

    //printf("\n\nEnter No of packets in hex : 0x");pn = get_val(); //pn = get_val(); 
    //printf("\nYou entered %d no. of packets with msg_num:%d... \n",pn,SLT_MSG_NUM);

    //printf("Number of Packets Expected to Transmit and Receive:%d for msg_num:%d\n",(pn*SLT_MSG_NUM),SLT_MSG_NUM);

    printf("\n\nTotal no. of packets =%d, Enqueued at a time with no of pkts :%d with pkt size: %d... \n",pn,SLT_MSG_NUM, ps);
    printf("Number of Packets Expected to Transmit and Receive:%d\n",(pn*SLT_MSG_NUM));

    if(pn==0x140000)	printf("\nEth traffic is now expected to run for about 3-mins");//Time incorrect
    if(pn==0x220000)	printf("\nEth traffic is now expected to run for about 5-mins");//Time mentioned incorrect
    if(pn==0x280000)	printf("\nEth traffic is now expected to run for about 1-mins");//10-M packets
    if(pn==0x2625a0)	printf("\nEth traffic is now expected to run for about 3-mins");//10-M packets

    #ifdef RANDOMIZE_SLT    
	printf("\n(Pseudo-random payload will be used)");
    #endif

    printf("\nRunning Ethernet Traffic [");

    pn = pn*4;
    dots = pn/20;
    mn = QM_TEST_MSG_NUM; 
    
    qmid = 0;
    fpqid=0;
    ret = sys_alloc_enet_buf(qmid, fpqid, mn, &qm_buf_xfi); //// Allocate the FPQ Buffer
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf Fail qmid:%d\r\n",qmid);
        return ret;
    }
    fpqid=1;
    ret = sys_alloc_enet_buf(qmid, fpqid, mn, &qm_buf32_xfi); //// Allocate the FPQ Buffer
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf qm_buf32_xfi Fail qmid:%d\r\n",qmid);
        return ret;
    }
    qmid = 2;
    fpqid=0;
    ret = sys_alloc_enet_buf(qmid, fpqid, mn, &qm_buf33_xfi); //// Allocate the FPQ Buffer
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf qm_buf33_xfi Fail qmid:%d\r\n",qmid);
        return ret;
    }
    fpqid=1;
    ret = sys_alloc_enet_buf(qmid, fpqid, mn, &qm_buf34_xfi); //// Allocate the FPQ Buffer
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf qm_buf34_xfi Fail qmid:%d\r\n",qmid);
        return ret;
    }
    
    pdl_pattern=0xAA;
    ret = qm_build_eth_pkt_pdl((unsigned char *)buf_xfi[0], ps, pdl_pattern);
    //ret = qm_build_eth_pkt_pdl_temp((unsigned char *)buf_xfi[0], ps, pdl_pattern);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt_pdl Fail qmid:%d\r\n",qmid);
        return ret;

    }    
    //pdl_pattern=0xBB;
    pdl_pattern=0x55;
    ret = qm_build_eth_pkt_pdl((unsigned char *)buf32_xfi[0], ps, pdl_pattern);
    //ret = qm_build_eth_pkt_pdl_temp((unsigned char *)buf32_xfi[0], ps, pdl_pattern);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt_pdl buf32_xfi Fail qmid:%d\r\n",qmid);
        return ret;

    }    
    //pdl_pattern=0xCC;
    pdl_pattern=0xAA;
    ret = qm_build_eth_pkt_pdl((unsigned char *)buf33_xfi[0], ps, pdl_pattern);
    //ret = qm_build_eth_pkt_pdl_temp((unsigned char *)buf33_xfi[0], ps, pdl_pattern);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt_pdl buf33_xfi Fail qmid:%d\r\n",qmid);
        return ret;

    }    
    //pdl_pattern=0xDD;
    pdl_pattern=0x55;
    ret = qm_build_eth_pkt_pdl((unsigned char *)buf34_xfi[0], ps, pdl_pattern);
    //ret = qm_build_eth_pkt_pdl_temp((unsigned char *)buf34_xfi[0], ps, pdl_pattern);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt_pdl buf34_xfi Fail qmid:%d\r\n",qmid);
        return ret;

    }

    per = sys_enet_enq_cfg_xfi(buf_xfi[0], ps);
    extern enq_req_t er_xfi;
    per = &er_xfi;
    if (!per) {
        printf("QM sys_enet_enq_cfg_xfi failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }
    per32 = sys_enet_enq_cfg32_xfi(buf32_xfi[0], ps);
    extern enq_req_t er32_xfi;
    per32 = &er32_xfi;
    if (!per32) {
        printf("QM sys_enet_enq_cfg32_xfi failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }
    per33 = sys_enet_enq_cfg33_xfi(buf33_xfi[0], ps);
    extern enq_req_t er33_xfi;
    per33 = &er33_xfi;
    if (!per33) {
        printf("QM sys_enet_enq_cfg33_xfi failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }
    per34 = sys_enet_enq_cfg34_xfi(buf34_xfi[0], ps);
    extern enq_req_t er34_xfi;
    per34 = &er34_xfi;
    if (!per34) {
        printf("QM sys_enet_enq_cfg34_xfi failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }

    for(i=0; i<pn; i++) {
        if((i%4) == 0) {
	    dcache_flush_all();
            tx_port=0;  rx_port=1;	
            tx_enq_qid = QID32; rx_deq_qid = QID65;
            per->qid =  tx_enq_qid;     // port-0
            ret = qm_proc_enq_dir(0,per);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                qm_err_count_xfi[0]++;
                //total_err_count_xfi[1]++;
                //total_err_count_xfi[2]++;
                //total_err_count_xfi[3]++;
                return ret;
            }

	#if 0 // -- ORIGINAL CODE --
            retval = pkt_compare_xfi_new(tx_port, rx_port, ps);
            if(retval)
                return 1;              
	#endif // -- ORIGINAL CODE --

            mn=SLT_MSG_NUM;
            while(mn) {
                mn = SLT_MSG_NUM;
                ret = qm_proc_deq_dir(0, rx_deq_qid, QM_MSG_SZ_32B, &mn, msgbuf_xfi); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    return ret;
                }
                mn=0; 
            }
        }
        else if((i%4) == 1)  {
	    dcache_flush_all();
            tx_port=1; rx_port=0;
            tx_enq_qid = QID33; rx_deq_qid = QID64;	
            per32->qid = tx_enq_qid;     // port-1
            ret = qm_proc_enq_dir(0,per32);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                qm_err_count_xfi[1]++;
                //total_err_count_xfi[2]++;
                //total_err_count_xfi[3]++;
                return ret;
            }            
	#if 0 // -- ORIGINAL CODE --
            retval = pkt_compare_xfi_new(tx_port, rx_port, ps);
            if(retval)
                return 1;              
	#endif // -- ORIGINAL CODE --
            mn=SLT_MSG_NUM;
            while(mn) {
                mn = SLT_MSG_NUM;
                ret = qm_proc_deq_dir(0, rx_deq_qid, QM_MSG_SZ_32B, &mn, msgbuf32_xfi); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    return ret;
                }
                mn=0; 
            }
        } 
        else if((i%4) == 2)  {
	    dcache_flush_all();
            tx_port=2; rx_port=3;	
            tx_enq_qid = QID32; rx_deq_qid = QID65;
            per33->qid = tx_enq_qid;    // port-1
            ret = qm_proc_enq_dir(2,per33);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                qm_err_count_xfi[2]++;
                //total_err_count_xfi[3]++;
                //return ret;
            }             
	#if 0 // -- ORIGINAL CODE --
            retval = pkt_compare_xfi_new(tx_port, rx_port ,ps);
            if(retval)
                return 1;              
	#endif // -- ORIGINAL CODE --
            mn=SLT_MSG_NUM;
            while(mn) {
                mn = SLT_MSG_NUM;
                ret = qm_proc_deq_dir(2, rx_deq_qid, QM_MSG_SZ_32B, &mn, msgbuf33_xfi); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    return ret;
                }
                mn=0; 
            }
        }
        else if((i%4) == 3)  {
	    dcache_flush_all();
            tx_port=3; rx_port=2;
            tx_enq_qid = QID33;	 rx_deq_qid = QID64;    
            per34->qid = tx_enq_qid;     // port-1
            ret = qm_proc_enq_dir(2,per34);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                qm_err_count_xfi[3]++;
                //return ret;
            }             
	#if 0 // -- ORIGINAL CODE --
            retval = pkt_compare_xfi_new(tx_port, rx_port, ps);
            if(retval)
                return 1;              
	#endif // -- ORIGINAL CODE --
            mn=SLT_MSG_NUM;
            while(mn) {
                mn = SLT_MSG_NUM;
                ret = qm_proc_deq_dir(2, rx_deq_qid, QM_MSG_SZ_32B, &mn, msgbuf34_xfi); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    return ret;
                }
                mn=0; 
            }
        }

        lprintf(8, "\n<----------------- PortNo:%d PacketNo:%d ------------------->\n",(i%4),(i/4));
        if ((i%dots==0)) printf(".");
    }
    printf("]\n");
    return 0;
}

int pkt_compare_xfi_new(int tx_port, int rx_port, u32 pn)
{
    u64 st_address1; 	
    int msg_num;
    u64 st_address2; 	
    u64 st_address3; 	
    u64 st_address4; 	
    u64 addr_1,addr_2;
    u64 addr_3,addr_4;
    u8 wn1[] = {1, 1, 1, 1, 1};

    //u64 crc_data_tx,crc_data_rx;
    u32 crc_data_tx,crc_data_rx;
    
    u64 n_msg_rx[4]={0};
    u64 ddr_base_tx_pkt[4]={0};
    u64 ddr_base_rx_pkt[4]={0};
    u64 k,number_errors[4]={0};
    u64 temp_tx,temp_rx;
    int i;
    u32 timeout, pn_tmp;
    int temp=0;
    int qmid_value;

    pn_tmp = pn/4; //required for comparing 4 bytes at atime

    q_state_t q_state_pq_32_1[50];
    q_state_t q_state_pq_33_1[50];
    q_state_t q_state_pq_34_1[50];
    q_state_t q_state_pq_35_1[50];

    q_state_t q_state_pq_64_1[50];
    q_state_t q_state_pq_65_1[50];
    q_state_t q_state_pq_66_1[50];
    q_state_t q_state_pq_67_1[50];

#if 0 // -- ORIGINAL CODE --
    timeout = 1000000;
    temp = 0;
    while(temp != SLT_MSG_NUM) {
        temp += read_rpkt_as_xg[rx_port] = axgmac_stat_rd(PEMSTAT_RPKT__ADDR , rx_port);
        timeout--;
        if(timeout==0) {
	    USDELAY(1000000);// 1 - Sec  -- TEMP
            printf("\nPEMSTAT Read Timeout Timeout\n");
            printf("PEMSTAT_RPKT on port-%d: pkt_num:%d temp:%d\n", rx_port, read_rpkt_as_xg[rx_port],temp);
	    stat_dump(); // -- TEMP
            total_err_count_xfi[0]++;
            total_err_count_xfi[1]++;
            total_err_count_xfi[2]++;
            total_err_count_xfi[3]++;
            return 1;
        }
        read_rpkt_as_bak_xg[rx_port] += read_rpkt_as_xg[rx_port]; 
    }
#endif // -- ORIGINAL CODE --

    switch(tx_port) {
        case 0:
            USDELAY(1);// required for even for 1 pkt to read qstate
            QM_CHK_RET(qm_get_q_state_dir(0,32,1,wn1,&q_state_pq_32_1[0]));
            st_address1 = (q_state_pq_32_1[0].pqfp.st_addr);        // start addess of the queue 
            lprintf(8,"\nst_address_tx[0]     : 0x%x\n",st_address1);
            lprintf(8,"n_msg_tx[0]          : 0x%x\n",(q_state_pq_32_1[0].pqfp.n_msg));
            st_address2 = (st_address1<<8);                         // get proper 42 bit start address queue (by shifting 8 bits, refer QM DS)
            
            if(!(q_state_pq_32_1[0].pqfp.hd_ptr == 0))              // head pointer wraparound 
                st_address1 = (q_state_pq_32_1[0].pqfp.hd_ptr-2);   // get head pointer of queue 
            else 
                st_address1 = 0x3fe;                                // last head pointer of the queue  
            lprintf(8,"hd_prt_tx[0]         : 0x%x\n",st_address1);
            st_address2 += (st_address1<<4);                        // get proper head pointer (by shifting 4 bits, refer QM DS)
            
            st_address2 +=8;                                        // get the proper offest freePool buffer 
            lprintf(8,"st_address2[0]       : 0x%x\n",st_address2);
            st_address2 = qm_get_va(st_address2);                   // get the virtual address
            addr_1      = read_64((u64 *)st_address2);
            addr_1      &= 0x3ffffffffff;
            lprintf(8,"addr_1[0]            : 0x%x\n",addr_1);
            ddr_base_tx_pkt[0] = qm_get_va(addr_1);

            lprintf(8,"ddr_base_tx_pkt[0]   : 0x%x\n",ddr_base_tx_pkt[0]);
            lprintf(8,"hd_ptr_tx[0]         : 0x%x\n",q_state_pq_32_1[0].pqfp.hd_ptr);
            lprintf(8,"addr_1[0]            : 0x%x\n",addr_1);
            break;

        case 1:
            USDELAY(1);// required for even for 1 pkt to read qstate
            QM_CHK_RET(qm_get_q_state_dir(0,33,1,wn1,&q_state_pq_33_1[0]));
            st_address1 = (q_state_pq_33_1[0].pqfp.st_addr);        // start addess of the queue 
            lprintf(8,"\nst_address_tx[1]     : 0x%x\n",st_address1);
            lprintf(8,"n_msg_tx[1]          : 0x%x\n",(q_state_pq_33_1[0].pqfp.n_msg));
            st_address2 = (st_address1<<8);                         // get proper 42 bit start address queue (by shifting 8 bits, refer QM DS)
            
            if(!(q_state_pq_33_1[0].pqfp.hd_ptr == 0))              // head pointer wraparound 
                st_address1 = (q_state_pq_33_1[0].pqfp.hd_ptr - 2); // get head pointer of queue 
            else 
                st_address1 = 0x3fe;                                // last head pointer of the queue   
            lprintf(8,"hd_prt_tx[1]         : 0x%x\n",st_address1);
            st_address2 += (st_address1<<4);                        // get proper head pointer (by shifting 4 bits, refer QM DS)
            
            st_address2 +=8;                                        // get the proper offest freePool buffer 
            st_address2 = qm_get_va(st_address2);                   // get the virtual address
            addr_1      = read_64((u64 *)st_address2);
            addr_1      &= 0x3ffffffffff;
            lprintf(8,"addr_1[1]            : 0x%x\n",addr_1);
            ddr_base_tx_pkt[1] = qm_get_va(addr_1);

            lprintf(8,"ddr_base_tx_pkt[1]   : 0x%x\n",ddr_base_tx_pkt[1]);
            lprintf(8,"hd_ptr_tx[1]         : 0x%x\n",q_state_pq_33_1[0].pqfp.hd_ptr);
            lprintf(8,"addr_1[1]            : 0x%x\n",addr_1);
            break;

        case 2:
            USDELAY(1);// required for even for 1 pkt to read qstate
            QM_CHK_RET(qm_get_q_state_dir(2,32,1,wn1,&q_state_pq_34_1[0]));
            st_address1 = (q_state_pq_34_1[0].pqfp.st_addr);
            lprintf(8,"\nst_address_tx[2]     : 0x%x\n",st_address1);
            lprintf(8,"n_msg_tx[2]          : 0x%x\n",(q_state_pq_34_1[0].pqfp.n_msg));
            st_address2 = (st_address1<<8);
            if(!(q_state_pq_34_1[0].pqfp.hd_ptr == 0))
                st_address1 = (q_state_pq_34_1[0].pqfp.hd_ptr - 2);     // get head pointer of queue 
            else 
                st_address1 = 0x3fe;     
            lprintf(8,"hd_prt_tx[2]         : 0x%x\n",st_address1);
            st_address2 += (st_address1<<4);
            st_address2 +=8;
            st_address2 = qm_get_va(st_address2);
            addr_1      = read_64((u64 *)st_address2);
            addr_1      &= 0x3ffffffffff;
            lprintf(8,"addr_1[2]            : 0x%x\n",addr_1);
            ddr_base_tx_pkt[2] = qm_get_va(addr_1);
            
            lprintf(8,"ddr_base_tx_pkt[2]   : 0x%x\n",ddr_base_tx_pkt[2]);
            lprintf(8,"hd_ptr_tx[2]         : 0x%x\n",q_state_pq_34_1[0].pqfp.hd_ptr);
            lprintf(8,"addr_1[2]            : 0x%x\n",addr_1);
            break;

        case 3:
            USDELAY(1);// required for even for 1 pkt to read qstate
            QM_CHK_RET(qm_get_q_state_dir(2,33,1,wn1,&q_state_pq_35_1[0]));
            st_address1 = (q_state_pq_35_1[0].pqfp.st_addr);
            lprintf(8,"\nst_address_tx[3]     : 0x%x\n",st_address1);
            lprintf(8,"n_msg_tx[3]          : 0x%x\n",(q_state_pq_35_1[0].pqfp.n_msg));
            st_address2 = (st_address1<<8);
            if(!(q_state_pq_35_1[0].pqfp.hd_ptr == 0))
                st_address1 = (q_state_pq_35_1[0].pqfp.hd_ptr - 2);     // get head pointer of queue 
            else 
                st_address1 = 0x3fe;     
            lprintf(8,"hd_prt_tx[3]         : 0x%x\n",st_address1);
            st_address2 += (st_address1<<4);            
            
            st_address2 +=8;
            st_address2 = qm_get_va(st_address2);
            addr_1      = read_64((u64 *)st_address2);
            addr_1      &= 0x3ffffffffff;
            lprintf(8,"addr_1[3]            : 0x%x\n",addr_1);
            ddr_base_tx_pkt[3] = qm_get_va(addr_1);
            
            lprintf(8,"ddr_base_tx_pkt[3]   : 0x%x\n",ddr_base_tx_pkt[3]);
            lprintf(8,"hd_ptr_tx[3]         : 0x%x\n",q_state_pq_35_1[0].pqfp.hd_ptr);
            lprintf(8,"addr_1[3]            : 0x%x\n",addr_1);
            break;

        defaut:
            printf("Wrong Port number\n");
    }
    switch(rx_port) {
        case 0:
	    qmid_value = 0;
            USDELAY(1);// required for even for 1 pkt to read qstate
            QM_CHK_RET(qm_get_q_state_dir(qmid_value,64,1,wn1,&q_state_pq_64_1[0]));
	    #if 0 // -- ORIGINAL CODE --
            timeout = 1000000;
            while((q_state_pq_64_1[0].pqfp.n_msg)!= SLT_MSG_NUM) {          // Polling number of msg Tx-Msg=Rx-Msg
                QM_CHK_RET(qm_get_q_state_dir(qmid_value,64,1,wn1,&q_state_pq_64_1[0]));
                timeout--;
                if(timeout==0) {
                    printf("Queue State Timeout Timeout\n");
                    printf("n_msg_rx[0]          : 0x%x\n",(q_state_pq_64_1[0].pqfp.n_msg));
                    printf("rpkt[0]              : %d\n",read_rpkt_as_bak_xg[0]);
                    printf("rpkt[1]              : %d\n",read_rpkt_as_bak_xg[1]);
                    printf("rpkt[2]              : %d\n",read_rpkt_as_bak_xg[2]);
                    printf("rpkt[3]              : %d\n",read_rpkt_as_bak_xg[3]);

                    total_err_count_xfi[0]++;
                    total_err_count_xfi[1]++;
                    total_err_count_xfi[2]++;
                    total_err_count_xfi[3]++;

                    return 1;
                }
            }
	    #endif  // -- ORIGINAL CODE --

            st_address1 = (q_state_pq_64_1[0].pqfp.st_addr);                // start addess of the queue 
            lprintf(8,"\nst_address_rx[0]     : 0x%x\n",st_address1);
            st_address2 = (st_address1<<8);                                 // get proper 42 bit start address queue (by shifting 8 bits, refer QM DS)
            lprintf(4,"n_msg_rx[0]           : 0x%x\t",(q_state_pq_64_1[0].pqfp.n_msg));   
            lprintf(4,"hd_ptr_rx[0]          : 0x%x\n",(q_state_pq_64_1[0].pqfp.hd_ptr));
            if(!((q_state_pq_64_1[0].pqfp.hd_ptr + 2*q_state_pq_64_1[0].pqfp.n_msg) == 0))      // get proper Rx buffer addresss
                st_address1 = (q_state_pq_64_1[0].pqfp.hd_ptr+ 2*q_state_pq_64_1[0].pqfp.n_msg -2);  
            else 
                st_address1 = 0x3fe;     
            st_address2 += (st_address1<<4);                    // get proper head pointer (by shifting 4 bits, refer QM DS)
            lprintf(4,"fetch_addr_rx[0]      : 0x%x\n",st_address1);
            st_address2 += 8;                                   // get the proper offest freePool buffer 
            st_address2 = qm_get_va(st_address2);               // get the virtual address
            addr_1 = read_64((u64 *)st_address2);
            addr_1 &= 0x3ffffffffff;
            lprintf(8,"addr_1[0]            : 0x%x\n",addr_1);
            ddr_base_rx_pkt[0] = qm_get_va(addr_1);

            lprintf(8,"ddr_base_rx_pkt[0]   : 0x%x\n",ddr_base_rx_pkt[0]);
            lprintf(8,"hd_ptr_rx[0]         : 0x%x\n",q_state_pq_33_1[0].pqfp.hd_ptr);
            lprintf(8,"addr_1[0]            : 0x%x\n",addr_1);
            data_cache_flush_all();
            break;

        case 1:
	    qmid_value = 0;
            USDELAY(1);// required for even for 1 pkt to read qstate
            QM_CHK_RET(qm_get_q_state_dir(qmid_value,65,1,wn1,&q_state_pq_65_1[0]));
            //lprintf(8,"\nst_address_rx[1]     : 0x%x\n",st_address1);
	    #if 0  // -- ORIGINAL CODE --
            timeout = 1000000;
            while((q_state_pq_65_1[0].pqfp.n_msg)!= SLT_MSG_NUM) {
                QM_CHK_RET(qm_get_q_state_dir(qmid_value,65,1,wn1,&q_state_pq_65_1[0]));
                timeout--;
                if(timeout==0) {
                    printf("Queue State Timeout Timeout\n");
                    printf("n_msg_rx[1]          : 0x%x\n",(q_state_pq_65_1[0].pqfp.n_msg));
                    printf("st_address_rx[1]     : 0x%x\n",(q_state_pq_65_1[0].pqfp.st_addr));
                    printf("rpkt[0]              : %d\n",read_rpkt_as_bak_xg[0]);
                    printf("rpkt[1]              : %d\n",read_rpkt_as_bak_xg[1]);
                    printf("rpkt[2]              : %d\n",read_rpkt_as_bak_xg[2]);
                    printf("rpkt[3]              : %d\n",read_rpkt_as_bak_xg[3]);

                    total_err_count_xfi[0]++;
                    total_err_count_xfi[1]++;
                    total_err_count_xfi[2]++;
                    total_err_count_xfi[3]++;

                    return 1;
                }                
            }
	    #endif  // -- ORIGINAL CODE --
            st_address1 = (q_state_pq_65_1[0].pqfp.st_addr);    // start addess of the queue 
            lprintf(8,"st_address_rx[1]      : 0x%x\n",st_address1);
            n_msg_rx[1]+= (q_state_pq_65_1[0].pqfp.n_msg);
            lprintf(4,"n_msg_rx[1]           : 0x%x\t",(q_state_pq_65_1[0].pqfp.n_msg));
            lprintf(4,"hd_ptr_rx[1]          : 0x%x\n",(q_state_pq_65_1[0].pqfp.hd_ptr));
            st_address2 = (st_address1<<8);                     // get proper 42 bit start address queue (by shifting 8 bits, refer QM DS)
            if(!((q_state_pq_65_1[0].pqfp.hd_ptr+ 2*q_state_pq_65_1[0].pqfp.n_msg) == 0))
                st_address1 = (q_state_pq_65_1[0].pqfp.hd_ptr+ 2*q_state_pq_65_1[0].pqfp.n_msg-2);   // get head pointer of queue
            else 
                st_address1 = 0x3fe;     
            lprintf(8,"hd_ptr_rx[1]         : 0x%x\n",st_address1);
            st_address2 += (st_address1<<4);                    // get proper head pointer (by shifting 4 bits, refer QM DS)
            st_address2 +=8;                                    // get the proper offest freePool buffer 
            st_address2 = qm_get_va(st_address2);               // get the virtual address
            addr_1 = read_64((u64 *)st_address2);
            addr_1 &= 0x3ffffffffff;
            lprintf(8,"addr_1[1]            : 0x%x\n",addr_1);
            ddr_base_rx_pkt[1] = qm_get_va(addr_1);

            lprintf(8,"ddr_base_rx_pkt[1]   : 0x%x\n",ddr_base_rx_pkt[1]);
            lprintf(8,"hd_ptr_rx[1]         : 0x%x\n",q_state_pq_32_1[0].pqfp.hd_ptr);
            lprintf(8,"addr_1[1]            : 0x%x\n",addr_1);
            data_cache_flush_all();
            break;

        case 2:
	    qmid_value = 2;
            USDELAY(1);// required for even for 1 pkt to read qstate
            QM_CHK_RET(qm_get_q_state_dir(qmid_value,64,1,wn1,&q_state_pq_66_1[0]));
	    #if 0  // -- ORIGINAL CODE --
            timeout = 1000000;
            while((q_state_pq_66_1[0].pqfp.n_msg)!= SLT_MSG_NUM) {
                QM_CHK_RET(qm_get_q_state_dir(qmid_value,64,1,wn1,&q_state_pq_66_1[0]));
                timeout--;
                if(timeout==0) {
                    printf("Queue State Timeout Timeout\n");
                    printf("n_msg_rx[2]          : 0x%x\n",(q_state_pq_66_1[0].pqfp.n_msg));
                    total_err_count_xfi[0]++;
                    total_err_count_xfi[1]++;
                    total_err_count_xfi[2]++;
                    total_err_count_xfi[3]++;

                    return 1;
                }                
            }
	    #endif  // -- ORIGINAL CODE --

            st_address1 = (q_state_pq_66_1[0].pqfp.st_addr);
            n_msg_rx[2]+= (q_state_pq_66_1[0].pqfp.n_msg);
            lprintf(4,"n_msg_rx[2]          : 0x%x\t",(q_state_pq_66_1[0].pqfp.n_msg));
            lprintf(4,"hd_ptr_rx[2]         : 0x%x\n",(q_state_pq_66_1[0].pqfp.hd_ptr));
            lprintf(8,"\nst_address_rx[2]   : 0x%x\n",st_address1);
            st_address2 = (st_address1<<8);
            if(!((q_state_pq_66_1[0].pqfp.hd_ptr+ 2*q_state_pq_66_1[0].pqfp.n_msg) == 0))
                st_address1 = (q_state_pq_66_1[0].pqfp.hd_ptr+ 2*q_state_pq_66_1[0].pqfp.n_msg -2);   // get head pointer of queue
            else 
                st_address1 = 0x3fe;     
            lprintf(8,"st_address_rx[2]     : 0x%x\n",st_address1);
            st_address2 += (st_address1<<4);
            st_address2+=8;
            st_address2 = qm_get_va(st_address2);
            addr_1 = read_64((u64 *)st_address2);
            addr_1 &= 0x3ffffffffff;
            lprintf(8,"addr_1[2]            : 0x%x\n",addr_1);
            ddr_base_rx_pkt[2] = qm_get_va(addr_1);

            lprintf(8,"ddr_base_rx_pkt[2]   : 0x%x\n",ddr_base_rx_pkt[2]);
            lprintf(8,"hd_ptr_rx[2]         : 0x%x\n",q_state_pq_35_1[0].pqfp.hd_ptr);
            lprintf(8,"addr_1[2]            : 0x%x\n",addr_1);
	    data_cache_flush_all();
            break;

        case 3:
	    qmid_value = 2;
            USDELAY(1);// required for even for 1 pkt to read qstate
            QM_CHK_RET(qm_get_q_state_dir(qmid_value,65,1,wn1,&q_state_pq_67_1[0]));
	    #if 0  // -- ORIGINAL CODE --
            timeout = 1000000;
            while((q_state_pq_67_1[0].pqfp.n_msg)!= SLT_MSG_NUM) {
                QM_CHK_RET(qm_get_q_state_dir(qmid_value,65,1,wn1,&q_state_pq_67_1[0]));
                timeout--;
                if(timeout==0) {
                    printf("Queue State Timeout Timeout\n");
                    printf("n_msg_rx[3]          : 0x%x\n",(q_state_pq_67_1[0].pqfp.n_msg));
                    total_err_count_xfi[0]++;
                    total_err_count_xfi[1]++;
                    total_err_count_xfi[2]++;
                    total_err_count_xfi[3]++;

                    return 1;
                }                
            }
	    #endif  // -- ORIGINAL CODE --

            st_address1 = (q_state_pq_67_1[0].pqfp.st_addr);
            n_msg_rx[3]+= (q_state_pq_67_1[0].pqfp.n_msg);
            lprintf(4,"n_msg_rx[3]          : 0x%x\t",(q_state_pq_67_1[0].pqfp.n_msg));
            lprintf(4,"hd_ptr_rx[3]         : 0x%x\n",(q_state_pq_67_1[0].pqfp.hd_ptr));
            st_address2 = (st_address1<<8);
            if(!((q_state_pq_67_1[0].pqfp.hd_ptr+ 2*q_state_pq_67_1[0].pqfp.n_msg) == 0))
                st_address1 = (q_state_pq_67_1[0].pqfp.hd_ptr+ 2*q_state_pq_67_1[0].pqfp.n_msg -2);   // get head pointer of queue
            else 
                st_address1 = 0x3fe;     
            lprintf(8,"st_address_rx[3]     : 0x%x\n",st_address1);
            st_address2 += (st_address1<<4);
            st_address2+=8;
            st_address2 = qm_get_va(st_address2); //works for DIMM suze (1/2/4/8/16GB)
            addr_1 = read_64((u64 *)st_address2);
            addr_1 &= 0x3ffffffffff;
            lprintf(8,"addr_1[3]            : 0x%x\n",addr_1);
            ddr_base_rx_pkt[3] = qm_get_va(addr_1);

            lprintf(8,"ddr_base_rx_pkt[3]   : 0x%x\n",ddr_base_rx_pkt[2]);
            lprintf(8,"hd_ptr_rx[3]         : 0x%x\n",q_state_pq_34_1[0].pqfp.hd_ptr);
            lprintf(8,"addr_1[3]            : 0x%x\n",addr_1);
	    data_cache_flush_all();
            break;
        default :
            printf("Worng port\n");
    }
     
    switch(rx_port) {
        case 0 :
            if(read_rpkt_as_xg[rx_port]) {
                for(msg_num=0;msg_num<SLT_MSG_NUM;msg_num++) {
                    for(k=0;k<pn_tmp;k++) {
                        crc_data_tx=(u32)read_word((u64 *)(ddr_base_tx_pkt[tx_port]+(k*4)));
                        crc_data_rx=(u32)read_word((u64 *)(ddr_base_rx_pkt[rx_port]+((SLT_FP_SIZE*msg_num)+(k*4)-SLT_FP_SIZE*(SLT_MSG_NUM-1))));//To Reset the Rx st_adress pointer to start of the Received Packet instead of current packet
                        if(crc_data_tx!=crc_data_rx) {
                            printf("\nPort 0 (CRC ERROR)\nmsg_num=%d ADDR_tx= 0x%x ADDR_rx= 0x%x\n", msg_num,ddr_base_tx_pkt[tx_port]+(k*4), ddr_base_rx_pkt[rx_port]+((SLT_FP_SIZE*msg_num)+(k*4)-SLT_FP_SIZE*(SLT_MSG_NUM-1) ));
                            printf("FAIL\n");
                            number_errors[0]++;
                    	    total_err_count_xfi[0]++;
                    	    total_err_count_xfi[1]++;
                    	    total_err_count_xfi[2]++;
                    	    total_err_count_xfi[3]++;
                            return 1;
                        }
                    }
                } 
            }
            else {
                printf("FAIL: Port 0 (didn't receive a packet)\n");
                number_errors[0]++;
                total_err_count_xfi[0]++;
                total_err_count_xfi[1]++;
                total_err_count_xfi[2]++;
                total_err_count_xfi[3]++;
                return 2;
            }
            break;

        case 1 :
            if(read_rpkt_as_xg[rx_port]) {
                for(msg_num=0;msg_num<SLT_MSG_NUM;msg_num++) {
                    for(k=0;k<pn_tmp;k++) {
                        crc_data_tx=(u32)read_word((u64 *)(ddr_base_tx_pkt[tx_port]+(k*4)));
                        crc_data_rx=(u32)read_word((u64 *)(ddr_base_rx_pkt[rx_port]+((SLT_FP_SIZE*msg_num)+(k*4) -SLT_FP_SIZE*(SLT_MSG_NUM-1)))); 
                        if(crc_data_tx!=crc_data_rx) {
                            printf("\nPort 1 (CRC ERROR)\nmsg_num=%d ADDR_tx= 0x%x ADDR_rx= 0x%x\n", msg_num,ddr_base_tx_pkt[tx_port]+(k*4), ddr_base_rx_pkt[rx_port]+((SLT_FP_SIZE*msg_num)+(k*4)) -SLT_FP_SIZE*(SLT_MSG_NUM-1));
                            printf("FAIL\n");
                            number_errors[1]++;
                    	    total_err_count_xfi[0]++;
                    	    total_err_count_xfi[1]++;
                    	    total_err_count_xfi[2]++;
                    	    total_err_count_xfi[3]++;
                            return 1;
                        }
                    }
                }
            }
            else {
                printf("\nFAIL: Port 1 (didn't receive a packet)\n");
                number_errors[1]++;
                total_err_count_xfi[0]++;
                total_err_count_xfi[1]++;
                total_err_count_xfi[2]++;
                total_err_count_xfi[3]++;
                return 2;
            }
            break;

       case 2 :
            if(read_rpkt_as_xg[rx_port]) {
                for(msg_num=0;msg_num<SLT_MSG_NUM;msg_num++) {
                    for(k=0;k<pn_tmp;k++) {
                        crc_data_tx=(u32)read_word((u64 *)(ddr_base_tx_pkt[tx_port]+(k*4)));
                        crc_data_rx=(u32)read_word((u64 *)(ddr_base_rx_pkt[rx_port]+((SLT_FP_SIZE*msg_num)+(k*4)-SLT_FP_SIZE*(SLT_MSG_NUM-1))));  
                        if(crc_data_tx!=crc_data_rx) {
                            printf("\nPort 2 (CRC ERROR)\nmsg_num=%d ADDR_tx= 0x%x ADDR_rx= 0x%x\n", msg_num,ddr_base_tx_pkt[tx_port]+(k*4), ddr_base_rx_pkt[rx_port]+((SLT_FP_SIZE*msg_num)+(k*4) -SLT_FP_SIZE*(SLT_MSG_NUM-1)));
                            printf("FAIL\n");
                            number_errors[2]++;
                    	    total_err_count_xfi[0]++;
                    	    total_err_count_xfi[1]++;
                    	    total_err_count_xfi[2]++;
                    	    total_err_count_xfi[3]++;
                            return 1;
                        }
                    }
                } 
            }
            else {
                printf("FAIL: Port 2 (didn't receive a packet)\n");
                number_errors[2]++;
                total_err_count_xfi[0]++;
                total_err_count_xfi[1]++;
                total_err_count_xfi[2]++;
                total_err_count_xfi[3]++;
                return 2;
            }
            break;

        case 3 :
            if(read_rpkt_as_xg[rx_port]) {
                for(msg_num=0;msg_num<SLT_MSG_NUM;msg_num++) {
                    for(k=0;k<pn_tmp;k++) {
                        crc_data_tx=(u32)read_word((u64 *)(ddr_base_tx_pkt[tx_port]+(k*4)));
                        crc_data_rx=(u32)read_word((u64 *)(ddr_base_rx_pkt[rx_port]+((SLT_FP_SIZE*msg_num)+(k*4) -SLT_FP_SIZE*(SLT_MSG_NUM-1))));
                        if(crc_data_tx!=crc_data_rx) {
                            printf("\nPort 3 (CRC ERROR)\nmsg_num=%d ADDR_tx= 0x%x ADDR_rx= 0x%x\n", msg_num,ddr_base_tx_pkt[tx_port]+(k*4), ddr_base_rx_pkt[rx_port]+((SLT_FP_SIZE*msg_num)+(k*4)-SLT_FP_SIZE*(SLT_MSG_NUM-1) ));
                            printf("FAIL\n");
                            number_errors[3]++;
                    	    total_err_count_xfi[0]++;
                    	    total_err_count_xfi[1]++;
                    	    total_err_count_xfi[2]++;
                    	    total_err_count_xfi[3]++;
                            return 1;
                        }
                    }
                }
            }
            else {
                printf("\nFAIL: Port 3 (didn't receive a packet) \n");
                number_errors[3]++;
                total_err_count_xfi[0]++;
                total_err_count_xfi[1]++;
                total_err_count_xfi[2]++;
                total_err_count_xfi[3]++;
                return 2;
            }
            break;

        default :
            printf("\nOops !! Invalid port number passed\n");
    }
    total_err_count_xfi[rx_port] = total_err_count_xfi[rx_port] + number_errors[rx_port];
    return 0;
}

void sfpp_i2c_read () {
        u8 buf[2],read_i2c_status;
        int port_no , addr , start_addr , end_addr;
        int base_addr;

        printf("\nEnter XGE Port No. : ");     port_no = get_val();    port_no = get_val();
        printf("\nEnter I2C Base Addr  : 0x"); base_addr = get_val();  base_addr = get_val();
        printf("\nEnter I2C St  offset : 0x"); start_addr = get_val(); start_addr = get_val();
        printf("\nEnter I2C End offset : 0x"); end_addr = get_val();   end_addr = get_val();

//      int port_no=atoi(argv[0]);
//      int addr=atoi(argv[1]);
//      int length=atoi(argv[2]);


        i2c_set_bus_num(1);//This is done to make sure that it enables correct I2C Bus in nor_ddr_up mode

//      if(argc != 3){
//              printf("\n Syntax: sfpp_i2c_read [PORT NO] [ADDR]");
//      }else{

                // printf("\n\nFunction to read SFP+ module port %d using I2C...\n",port_no);
                buf[0]=(0x01 << port_no);buf[1]=0;
                i2c_write(0x71,0x0,0,buf,1);
                i2c_read(0x71,0x0,0,buf,1);
                read_i2c_status=buf[0];

                for(addr=start_addr;addr<=end_addr;addr++) {
                buf[0]=addr;buf[1]=0;
                i2c_write(base_addr,0x0,0,buf,1);
                i2c_read(base_addr,0x0,0,buf,1);
                read_i2c_status=buf[0];
                printf("\nRead data at address %d = %d\t[0x%x]\t[%c]",addr,read_i2c_status,read_i2c_status,read_i2c_status);
                }
//      }
}


void read_rxtx_reg1() {
    uint32_t inst, inst_base;
    unsigned int  wr_val, rd_val;
    int port , display=0;
    inst = 0;
    inst_base = 0x0400 + inst*0x0200;
    printf("\n\nSERDES RXTX Reg 1 ==>");
    for(port=0;port<=3;port++) {
        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg1", inst_base + 1*2,XGENET,port,display);
        printf(" [XGE-%d:0x%x]",port,rd_val);
    }
}

void program_rxtx_reg1() {
    uint32_t inst, inst_base;
    unsigned int  wr_val, rd_val;
    int port , display=0;
    int new_val;
    inst = 0;
    inst_base = 0x0400 + inst*0x0200;
    printf("\n\nCurrent value of SERDES RXTX Reg 1 ==>\n");
    for(port=0;port<=3;port++) {
        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg1", inst_base + 1*2,XGENET,port,display);
        printf(" [XGE-%d:0x%x]",port,rd_val);
    }
    for(port=0;port<=3;port++) {
        printf("\nEnter new value for RXTX Reg 1 for XGE-%d : 0x",port); new_val = get_val();
        enet_sds_ind_csr_reg_wr("rxtx_reg1", inst_base + 1*2, new_val,XGENET,port,display);
    }
    printf("\n\nModified value of SERDES RXTX Reg 1 ==>\n");
    for(port=0;port<=3;port++) {
        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg1", inst_base + 1*2,XGENET,port,display);
        printf(" [XGE-%d:0x%x]",port,rd_val);
    }
}

void read_rxtx_reg125() {
    uint32_t inst, inst_base;
    unsigned int  wr_val, rd_val;
    int port , display=0;
    inst = 0;
    inst_base = 0x0400 + inst*0x0200;
    printf("\n\nSERDES RXTX Reg 125 ==>");
    for(port=0;port<=3;port++) {
        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg125", inst_base + 125*2,XGENET,port,display);
        printf(" [XGE-%d:0x%x]",port,rd_val);
    }
}

void program_rxtx_reg125() {
    uint32_t inst, inst_base;
    unsigned int  wr_val, rd_val;
    int port , display=0;
    int new_val;
    inst = 0;
    inst_base = 0x0400 + inst*0x0200;
    printf("\n\nCurrent value of SERDES RXTX Reg 125 ==>\n");
    for(port=0;port<=3;port++) {
        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg125", inst_base + 125*2,XGENET,port,display);
        printf(" [XGE-%d:0x%x]",port,rd_val);
    }
    for(port=0;port<=3;port++) {
        printf("\nEnter new value for RXTX Reg 125 for XGE-%d : 0x",port); new_val = get_val();
        enet_sds_ind_csr_reg_wr("rxtx_reg125", inst_base + 125*2, new_val,XGENET,port,display);
    }
    printf("\n\nModified value of SERDES RXTX Reg 125 ==>\n");
    for(port=0;port<=3;port++) {
        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg125", inst_base + 125*2,XGENET,port,display);
        printf(" [XGE-%d:0x%x]",port,rd_val);
    }
}

void xfi_serdes_cmu_reg_dump() {
  int inst_base_temp , xfi_port_num ,k , rd_reg_val , display_val ;
  inst_base_temp = 0x0400;
  display_val = 0;

  printf("\n\nXFI SERDES CMU REG Values : \n");
  printf("\t\t   XGE-0\t   XGE-1\t   XGE-2\t   XGE-3");
  for(k=0; k<=39; k++) {
     printf("\nCMU_REG_%d :", k);
     for(xfi_port_num=0; xfi_port_num<=3; xfi_port_num++) {
        rd_reg_val = enet_sds_ind_csr_reg_rd("CMU_reg0", CMU + 2*k , XGENET , xfi_port_num , display_val);
        printf("\t[0x%08x]", rd_reg_val);
     } 
  }

}

void xfi_serdes_rxtx_reg_dump() {
  int inst_base_temp , xfi_port_num ,k , rd_reg_val , display_val ;
  inst_base_temp = 0x0400;
  display_val = 0;

  printf("\n\nXFI SERDES RXTX REG Values : \n");
  printf("\t\t   XGE-0\t   XGE-1\t   XGE-2\t   XGE-3");

  for(k=0; k<=162; k++) {
     printf("\nRXTX_REG_%d :", k);
     for(xfi_port_num=0; xfi_port_num<=3; xfi_port_num++) {
        rd_reg_val = enet_sds_ind_csr_reg_rd("rxtx_reg0", inst_base_temp + 2*k , XGENET , xfi_port_num , display_val);
        printf("\t[0x%08x]", rd_reg_val);
     }
  }

}

void read_pcs_fifo_stat() {
  int read_value , port;
  printf("\n");
  for(port=0;port<=3;port++) {
	read_value = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_FIFO_STATUS__ADDR , port , 0);
	printf("[XGE-%d : 0x%x] ",port,read_value);
  }
}

int check_pcsfifo_status() {
  int r0 , r1 , r2 , r3 , port ,display=0;
  printf("\n\nChecking for PCS FIFO Overflow/Underflow ...\n");
  //for(port=0;port<=3;port++) stat_dump_per_port(port,display); // Clear all statistics
  //gen_eth_pkt();

  printf("\nPCS_FIFO_STATUS :\n");
  r0 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_FIFO_STATUS__ADDR , 0 , 0);
  r1 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_FIFO_STATUS__ADDR , 1 , 0);
  r2 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_FIFO_STATUS__ADDR , 2 , 0);
  r3 = xgbaser_ind_read(SM_XGENET_XGBASER_PCS_FIFO_STATUS__ADDR , 3 , 0);
  printf("[XGE-0 : 0x%x] ",r0); 
  printf("[XGE-1 : 0x%x] ",r1); 
  printf("[XGE-2 : 0x%x] ",r2);
  printf("[XGE-3 : 0x%x] ",r3);
  if(r0>0 || r1>0 || r2>0 || r3>0) {
	printf("\n\nXFI_10G Failure due to PCS FIFO Overflow/Underflow on following ports :\n");
	if(r0>0) { 
		printf("\tXGE-0");
		if(r0==0x1) printf(" [OvFl]");
		if(r0==0x2) printf(" [UndFl]");
		if(r0==0x3) printf(" [OvFl & UndFl]");
		total_err_count_xfi[0]++; 
	}
	if(r1>0) { 
		printf("\tXGE-1"); 
		if(r1==0x1) printf(" [OvFl]");
		if(r1==0x2) printf(" [UndFl]");
		if(r1==0x3) printf(" [OvFl & UndFl]");
		total_err_count_xfi[1]++; 
	}
	if(r2>0) { 
		printf("\tXGE-2"); 
		if(r2==0x1) printf(" [OvFl]");
		if(r2==0x2) printf(" [UndFl]");
		if(r2==0x3) printf(" [OvFl & UndFl]");
		total_err_count_xfi[2]++; 
	}
	if(r3>0) { 
		printf("\tXGE-3"); 
		if(r3==0x1) printf(" [OvFl]");
		if(r3==0x2) printf(" [UndFl]");
		if(r3==0x3) printf(" [OvFl & UndFl]");
		total_err_count_xfi[3]++; 
	}
        if(r0>0 || r1>0) printf("\n\nTest Result : FAIL\n");
        if((r0==0 && r1==0) && (r2>0 || r3>0)) printf("\n\nIgnoring the error...\n");

	#if 0
	total_err_count_xfi[0]++;
	total_err_count_xfi[1]++;
	total_err_count_xfi[2]++;
	total_err_count_xfi[3]++;
	return 1;
	#endif
  }
  else printf("\nPCS FIFO_STATUS found ok");
  printf("\n");

  //Clear stat counters at the end of this routine
  for(port=0;port<=3;port++) stat_dump_per_port(port,display); // Clear all statistics
}

int eyescan_xfi_10g_all_lane() {
  int port0=0 , port1=0 , port2=0 , port3=0;
  printf("\nDo you wish to run eyescan on XGE0 ? (0:No, 1:Yes) : ");
  if(terminal_server_serial_port==1) port0=get_val(); port0=get_val();
  printf("\nDo you wish to run eyescan on XGE1 ? (0:No, 1:Yes) : ");
  if(terminal_server_serial_port==1) port1=get_val(); port1=get_val();
  printf("\nDo you wish to run eyescan on XGE2 ? (0:No, 1:Yes) : ");
  if(terminal_server_serial_port==1) port2=get_val(); port2=get_val();
  printf("\nDo you wish to run eyescan on XGE3 ? (0:No, 1:Yes) : ");
  if(terminal_server_serial_port==1) port3=get_val(); port3=get_val();

  if(port0==1) eyescan_sub_xfi_10g(0);
  if(port1==1) eyescan_sub_xfi_10g(1);
  if(port2==1) eyescan_sub_xfi_10g(2);
  if(port3==1) eyescan_sub_xfi_10g(3);

}

void gen_swpf() {
  int i , port , count;
  printf("\nEnter port no. : "); if(terminal_server_serial_port==1) port = get_val(); port = get_val();
  //port = 0;
  printf("\nEnter frame count : "); if(terminal_server_serial_port==1) count = get_val(); count = get_val();
  //count = 50000000;
  for(i=0;i<count;i++) eth_wr(SM_XGENET_AXGMAC_CSR_XGENET_CSR_ECM_CFG_0__ADDR , 0x08000000 , XGENET , port , 0);
  printf("\nSent %d Swpf on XGE-%d\n",count,port);
}

void xfi_margin_util_rx() {
    uint32_t inst, inst_base;
    unsigned int  wr_val, rd_val;
    int port , display=0;
    int pq_reg_val , pq_reg_start_val , pq_reg_end_val , iter , rfcs , k, dummy , time_sec;
    int ctle_eq_start_val , ctle_eq_end_val , iter_ctle_eq;
    int rfcs_port[4];
    int tfcs_port[4];
    int ctle_eq , pq_reg;
    int count_tmp , prbs_tx_port , prbs_rx_port , prbs_pattern=7;
    int err_iter_count=0;
    //int result_vector[8][17];//[CTLE_EQ][PQ_REG]
    int result_vector[8][64];//[CTLE_EQ][PQ_REG]
    int result_vector_sign_pq_neg[8][64];//[CTLE_EQ][PQ_REG]
    //int result_vector[4][4];//[CTLE_EQ][PQ_REG]
    int prbs_test_ret_val=0 , sign_pq;
    int loopback_mode=1;
    inst = 0;
    inst_base = 0x0400 + inst*0x0200;

    init_xfi_10g(0x36);
    init_seq_1();

    printf("\nEnter XGE Port No. : "); if(terminal_server_serial_port==1) port = get_val(); port = get_val();
    printf("\nSelect data loopback option (0:Tx2rx Self Lpbk, 1:Tx2rx Port-to-Port Lpbk) : ");
	if(terminal_server_serial_port==1) loopback_mode=get_val(); loopback_mode=get_val();
    printf("\nSelect PRBS Pattern (7, 9, 11, 23, 31) : PRBS-"); if(terminal_server_serial_port==1) prbs_pattern      = get_val(); prbs_pattern      = get_val();
    printf("\nEnter CTLE_EQ sweep range start val : 0x");	if(terminal_server_serial_port==1) ctle_eq_start_val = get_val(); ctle_eq_start_val = get_val();
    printf("\nEnter CTLE_EQ sweep range end val : 0x");		if(terminal_server_serial_port==1) ctle_eq_end_val   = get_val(); ctle_eq_end_val   = get_val();
    printf("\nEnter pq_reg sweep range start val : 0x");	if(terminal_server_serial_port==1) pq_reg_start_val  = get_val(); pq_reg_start_val  = get_val();
    printf("\nEnter pq_reg sweep range end val   : 0x");	if(terminal_server_serial_port==1) pq_reg_end_val    = get_val(); pq_reg_end_val    = get_val();
    printf("\nEnter time in Sec. for each iteration : ");	
    printf("\n(Options : 1:1-sec, 5:5-sec, 15:15-sec, 30:30-sec, 60:1-min, 300:5-min, 600:10-min, 900:15-min)");
    printf("\nTime option : ");
    if(terminal_server_serial_port==1) time_sec	     = get_val(); time_sec	    = get_val();
    printf("\nYou selected Loopback mode option as : ");
    if(loopback_mode==0) printf("Tx2rx Self Loopback");
    if(loopback_mode==1) printf("Tx2rx Port-to-Port Loopback");
    printf("\nRange entered : [CTLE_EQ:0x%x-0x%x][pq_reg:0x%x-0x%x]\t< Running PRBS-%x on XGE-%d with POSITIVE 'sign_pq' >",ctle_eq_start_val , ctle_eq_end_val , pq_reg_start_val , pq_reg_end_val , prbs_pattern , port);
    //printf("\nRange entered : [CTLE_EQ:0x%x-0x%x][pq_reg:0x%x-0x%x]\t< Running the tool for XGE-%d >",ctle_eq_start_val , ctle_eq_end_val , pq_reg_start_val , pq_reg_end_val , port);

    ctle_eq=0;
    for(iter_ctle_eq=ctle_eq_start_val; iter_ctle_eq<=ctle_eq_end_val; iter_ctle_eq=iter_ctle_eq+0x4) {

    // Write to CTLE_EQ
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg1", inst_base + 1*2,XGENET,port,display);
    wr_val = sm_enet_set(rd_val, iter_ctle_eq , 11, 7);
    enet_sds_ind_csr_reg_wr("rxtx_reg1", inst_base + 1*2, wr_val,XGENET,port,display);

    pq_reg=0;
    for(iter=pq_reg_start_val; iter<=pq_reg_end_val; iter++) {
        pq_reg_val = iter;
	printf("\n-------------------------------------------------------------------------------------------------------------");
        printf("\nUsing CTLE_EQ : %d (0x%x) \tUsing pq_reg : 0x%x",iter_ctle_eq , iter_ctle_eq , pq_reg_val);
        pq_reg_val = pq_reg_val << 9;
        pq_reg_val = pq_reg_val | 0x2;//Enable Manual mode ... as per SERDES driver
	pq_reg_val = pq_reg_val & 0xfeff;//Clear bit-8 of RXTX_REG125 to make sign_pq positive
        printf("\tRXTX Reg 125 : 0x%x",pq_reg_val);
        enet_sds_ind_csr_reg_wr("rxtx_reg125", inst_base + 125*2, pq_reg_val , XGENET , port , display);

        if(loopback_mode==0) { // Tx2rx Self Loopback
	  if(port == 0) { prbs_tx_port = 0; prbs_rx_port = 0; }
	  if(port == 1) { prbs_tx_port = 1; prbs_rx_port = 1; }
	  if(port == 2) { prbs_tx_port = 2; prbs_rx_port = 2; }
	  if(port == 3) { prbs_tx_port = 3; prbs_rx_port = 3; }
	}

	if(loopback_mode==1) { //Tx2rx Port-to-Port Loopback
	  if(port == 0) { prbs_tx_port = 1; prbs_rx_port = 0; }
	  if(port == 1) { prbs_tx_port = 0; prbs_rx_port = 1; }
	  if(port == 2) { prbs_tx_port = 3; prbs_rx_port = 2; }
	  if(port == 3) { prbs_tx_port = 2; prbs_rx_port = 3; }
	}

	USDELAY(10);
	if(prbs_tx_port != prbs_rx_port)
	serdes_reset_rxd_xg(XGENET , prbs_tx_port , display);//Added on 14-Jul-2014
	serdes_reset_rxd_xg(XGENET , prbs_rx_port , display);//Added on 14-Jul-2014
	USDELAY(10);

	#if 1	//Using prbs pattern in SERDES
	err_iter_count = 0;
	while(err_iter_count < 3) {
		result_vector[ctle_eq][pq_reg] = serdes_prbs_test(prbs_tx_port , prbs_rx_port, prbs_pattern , time_sec);
		printf("\nPRBS-%x LSB Err Count (RXTX_REG153) = %d\n", prbs_pattern , result_vector[ctle_eq][pq_reg]);
		if(result_vector[ctle_eq][pq_reg] >= 1) {
			err_iter_count++;
			if(err_iter_count < 3) printf("\nSince PRBS Err Count is non-zero, repeating the test ...");
		}
		else
			break;
	}
	#endif	//Using prbs pattern in SERDES

        USDELAY(100000);
	printf("-------------------------------------------------------------------------------------------------------------\n");
	pq_reg++;
    } // pq_reg
    ctle_eq++;
    } // CTLE_EQ


// Start of Logic for NEGATIVE sign_pq
#if 1

    printf("\nRange entered : [CTLE_EQ:0x%x-0x%x][pq_reg:0x%x-0x%x]\t< Running PRBS-%x on XGE-%d with NEGATIVE 'sign_pq' >",ctle_eq_start_val , ctle_eq_end_val , pq_reg_start_val , pq_reg_end_val , prbs_pattern , port);

    ctle_eq=0;
    for(iter_ctle_eq=ctle_eq_start_val; iter_ctle_eq<=ctle_eq_end_val; iter_ctle_eq=iter_ctle_eq+0x4) {

    // Write to CTLE_EQ
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg1", inst_base + 1*2,XGENET,port,display);
    wr_val = sm_enet_set(rd_val, iter_ctle_eq , 11, 7);
    enet_sds_ind_csr_reg_wr("rxtx_reg1", inst_base + 1*2, wr_val,XGENET,port,display);

    pq_reg=0;
    for(iter=pq_reg_start_val; iter<=pq_reg_end_val; iter++) {
        pq_reg_val = iter;
	printf("\n-------------------------------------------------------------------------------------------------------------");
        printf("\nUsing CTLE_EQ : %d (0x%x) \tUsing pq_reg : 0x%x",iter_ctle_eq , iter_ctle_eq , pq_reg_val);
        pq_reg_val = pq_reg_val << 9;
        pq_reg_val = pq_reg_val | 0x2;//Enable Manual mode ... as per SERDES driver
	pq_reg_val = pq_reg_val | 0x100;//Set bit-8 of RXTX_REG125 to make sign_pq negative
        printf("\tRXTX Reg 125 : 0x%x",pq_reg_val);
        enet_sds_ind_csr_reg_wr("rxtx_reg125", inst_base + 125*2, pq_reg_val , XGENET , port , display);

	if(port == 0) { prbs_tx_port = 1; prbs_rx_port = 0; }
	if(port == 1) { prbs_tx_port = 0; prbs_rx_port = 1; }
	if(port == 2) { prbs_tx_port = 3; prbs_rx_port = 2; }
	if(port == 3) { prbs_tx_port = 2; prbs_rx_port = 3; }

	USDELAY(10);
	if(prbs_tx_port != prbs_rx_port)
	serdes_reset_rxd_xg(XGENET , prbs_tx_port , display);//Added on 14-Jul-2014
	serdes_reset_rxd_xg(XGENET , prbs_rx_port , display);//Added on 14-Jul-2014
	USDELAY(10);

	#if 1	//Using prbs pattern in SERDES
	err_iter_count = 0;
	while(err_iter_count < 3) {
		result_vector_sign_pq_neg[ctle_eq][pq_reg] = serdes_prbs_test(prbs_tx_port , prbs_rx_port, prbs_pattern , time_sec);
		printf("\nPRBS-%x LSB Err Count (RXTX_REG153) = %d\n", prbs_pattern , result_vector_sign_pq_neg[ctle_eq][pq_reg]);
		if(result_vector_sign_pq_neg[ctle_eq][pq_reg] >= 1) {
			err_iter_count++;
			if(err_iter_count < 3) printf("\nSince PRBS Err Count is non-zero, repeating the test ...");
		}
		else
			break;
	}
	#endif	//Using prbs pattern in SERDES

        USDELAY(100000);
	printf("-------------------------------------------------------------------------------------------------------------\n");
	pq_reg++;
    } // pq_reg
    ctle_eq++;
    } // CTLE_EQ

#endif
// End of Logic for NEGATIVE sign_pq


//Print Result Vector
#if 1
    printf("\n\t          =======================================");
    printf("\n\t          Result Vector for Rx shmooing on XGE-%d ",port);
    printf("\n\t          =======================================");
    printf("\n\t        (Each iteration is run for %x-sec duration)",time_sec);

    printf("\n\n\t\tCTLE_EQ");
    printf("\n");
    for(iter_ctle_eq=ctle_eq_start_val; iter_ctle_eq<=ctle_eq_end_val; iter_ctle_eq=iter_ctle_eq+0x4)
    	printf("\t%d",iter_ctle_eq);

    printf("\nPQ_REG");
//Print Negative sign_pq
#if 1
    for(pq_reg=63;pq_reg>=0;pq_reg--) {  // pq_reg[63]
        printf("\n-0x%x",pq_reg + pq_reg_start_val);
        //for(ctle_eq=0;ctle_eq<4;ctle_eq++)    // CTLE_EQ[4]
        for(ctle_eq=0;ctle_eq<8;ctle_eq++)      // CTLE_EQ[8]
        //for(ctle_eq=ctle_eq_start_val;ctle_eq<ctle_eq_end_val;ctle_eq=ctle_eq+0x4)    // CTLE_EQ[8]
                //printf("\t%d",result_vector[ctle_eq][pq_reg]);
                //printf("\t%s",result_vector[ctle_eq][pq_reg]?"PASS":"Fail");
                printf("\t%d",result_vector_sign_pq_neg[ctle_eq][pq_reg]);
	}
#endif

//Print Positive sign_pq
    //for(pq_reg=0;pq_reg<4;pq_reg++) {	// pq_reg[4]
    for(pq_reg=0;pq_reg<64;pq_reg++) {	// pq_reg[63]
	printf("\n0x%x",pq_reg + pq_reg_start_val);
	//for(ctle_eq=0;ctle_eq<4;ctle_eq++)	// CTLE_EQ[4]
	for(ctle_eq=0;ctle_eq<8;ctle_eq++)	// CTLE_EQ[8]
	//for(ctle_eq=ctle_eq_start_val;ctle_eq<ctle_eq_end_val;ctle_eq=ctle_eq+0x4)	// CTLE_EQ[8]
		//printf("\t%d",result_vector[ctle_eq][pq_reg]);
		//printf("\t%s",result_vector[ctle_eq][pq_reg]?"PASS":"Fail");
		printf("\t%d",result_vector[ctle_eq][pq_reg]);
	}
    printf("\n");
#endif

}

void serdes_prbs_test_wrap() {
  int tx_port , rx_port , prbs_pattern , time_sec , err_cnt;

  printf("\nEnter Tx port : "); if(terminal_server_serial_port==1) tx_port = get_val(); tx_port = get_val();
  printf("\nEnter Rx port : "); if(terminal_server_serial_port==1) rx_port = get_val(); rx_port = get_val();
  printf("\nEnter PRBS Pattern (7,9,11,23,31) : "); if(terminal_server_serial_port==1) prbs_pattern = get_val(); prbs_pattern = get_val();
  printf("\nEnter Time in sec : ");
  printf("\n(Options : 1:1-sec, 5:5-sec, 15:15-sec, 30:30-sec, 60:1-min, 300:5-min, 600:10-min, 900:15-min) : ");
  if(terminal_server_serial_port==1) time_sec = get_val(); time_sec = get_val();

  err_cnt = serdes_prbs_test(tx_port, rx_port, prbs_pattern, time_sec);
  printf("\nPRBS-%x Err Count : %d\n", prbs_pattern , err_cnt);

}

int serdes_prbs_test(int tx_port, int rx_port, int prbs_pattern, int time_sec) {

    uint32_t inst, inst_base;
    unsigned int  wr_val, rd_val;
    int display = 0;
    int ret_val=0;
    int swap_rxp_rxn=0;
    int prbs_err_count=0;
    int prbs_sel , t;
    inst = 0;
    inst_base = 0x0400 + inst*0x0200;

    if(prbs_pattern == 0x07) prbs_sel = 0;
    if(prbs_pattern == 0x09) prbs_sel = 1;
    if(prbs_pattern == 0x11) prbs_sel = 2;
    if(prbs_pattern == 0x23) prbs_sel = 3;
    if(prbs_pattern == 0x31) prbs_sel = 4;

    //TX PRBS SELECT in RXTX_REG4
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 4*2 , XGENET , tx_port , display);
    wr_val = sm_enet_set(rd_val,prbs_sel, 10, 8);
    enet_sds_ind_csr_reg_wr("rxtx_reg4", inst_base + 4*2, wr_val , XGENET , tx_port , display);
    //RX PRBS SELECT in RXTX_REG7
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 7*2 , XGENET , rx_port , display);
    wr_val = sm_enet_set(rd_val,prbs_sel, 5, 3);
    enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 7*2, wr_val , XGENET , rx_port , display);

    //RXP, RXN invert for PRBS-23
    #if 0
    if(prbs_pattern == 0x23) {
	printf("\nEnter if you wish to swap RXP/RXN (0:No, 1:Yes) : ");
	if(terminal_server_serial_port==1) swap_rxp_rxn = get_val(); swap_rxp_rxn = get_val();
	if(swap_rxp_rxn==0) {
		rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg12", inst_base + 12*2 , XGENET , rx_port , display);
		wr_val = sm_enet_set(rd_val,0, 11, 11);
		enet_sds_ind_csr_reg_wr("rxtx_reg12", inst_base + 12*2, wr_val , XGENET , rx_port , display);
	}
	if(swap_rxp_rxn==1) {
		printf("\nSwapping RXP/RXN for PRBS-%x ...",prbs_pattern);
		rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg12", inst_base + 12*2 , XGENET , rx_port , display);
		wr_val = sm_enet_set(rd_val,0x1, 11, 11);
		enet_sds_ind_csr_reg_wr("rxtx_reg12", inst_base + 12*2, wr_val , XGENET , rx_port , display);
	}
    }
    #endif

    //RXP, RXN invert for PRBS-31
    #if 0
    if(prbs_pattern == 0x31) {
	printf("\nEnter if you wish to swap RXP/RXN (0:No, 1:Yes) : ");
	if(terminal_server_serial_port==1) swap_rxp_rxn = get_val(); swap_rxp_rxn = get_val();
	if(swap_rxp_rxn==0) {
		rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg12", inst_base + 12*2 , XGENET , rx_port , display);
		wr_val = sm_enet_set(rd_val,0, 11, 11);
		enet_sds_ind_csr_reg_wr("rxtx_reg12", inst_base + 12*2, wr_val , XGENET , rx_port , display);
	}
	if(swap_rxp_rxn==1) {
		printf("\nSwapping RXP/RXN for PRBS-%x ...",prbs_pattern);
		//rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg12", inst_base + 12*2 , XGENET , rx_port , display);
		//wr_val = sm_enet_set(rd_val,0x1, 11, 11);
		//enet_sds_ind_csr_reg_wr("rxtx_reg12", inst_base + 12*2, wr_val , XGENET , rx_port , display);
		rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2 , XGENET , rx_port , display);
		wr_val = sm_enet_set(rd_val,0x1, 10, 10);
		enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, wr_val , XGENET , rx_port , display);
	}
    }
    #endif

    //BIST_EN_TX in RXTX_REG2
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2 , XGENET , tx_port , display);
    wr_val = sm_enet_set(rd_val,0x1, 11, 11);
    enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, wr_val , XGENET , tx_port , display);
    //BIST_EN_RX in RXTX_REG7
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 7*2 , XGENET , rx_port , display);
    wr_val = sm_enet_set(rd_val,0x1, 6, 6);
    enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 7*2, wr_val , XGENET , rx_port , display);

    USDELAY(1000);//1-msec

    prbs_err_count = read_prbs_err_cnt(rx_port);//Dummy Read-1 -- to clear any initial errors
    USDELAY(1000);//1-msec
    prbs_err_count = read_prbs_err_cnt(rx_port);//Dummy Read-2 -- to clear any initial errors

    if(time_sec == 0x1) {
    printf("\nWaiting for 1-Sec ... "); USDELAY(1000000);//1-sec
    prbs_err_count = read_prbs_err_cnt(rx_port);//Actual Read
    }

    if(time_sec == 0x5) {
    printf("\nWaiting for 5-Sec ... "); printf("\t["); for(t=0;t<5;t++) { USDELAY(1000000); printf(" ."); } printf(" ]");//5-sec
    prbs_err_count = read_prbs_err_cnt(rx_port);//Actual Read
    }

    if(time_sec == 0x15) {
    printf("\nRunning PRBS-%x Test for 15-Sec ... ",prbs_pattern); printf("\t["); for(t=0;t<15;t++) { USDELAY(1000000); printf(" %d",t+1); } printf(" ]");//15-sec
    prbs_err_count = read_prbs_err_cnt(rx_port);//Actual Read
    }

    if(time_sec == 0x30) {
    printf("\nRunning PRBS-%x Test for 30-Sec ... ",prbs_pattern); printf("["); for(t=0;t<30;t++) { USDELAY(1000000); printf(" %d",t+1); } printf(" ]");//30-sec
    prbs_err_count = read_prbs_err_cnt(rx_port);//Actual Read
    }

    if(time_sec == 0x60) {
    printf("\nPRBS Test running for 1-min"); printf("\nTest Progress (Time Completed in secs.) : ");
    for(t=0;t<10;t++) { USDELAY(6000000); printf("  %d",(t+1)*6); } // 10 Iterations of 6-Sec
    prbs_err_count = read_prbs_err_cnt(rx_port);//Actual Read
    }

    if(time_sec == 0x300) {
    printf("\nPRBS Test running for 5-mins"); printf("\nTest Progress (Time Completed in mins.) : ");
    for(t=0;t<5;t++) { USDELAY(60000000); printf("  %d",t+1); } // 5 Iterations of 1-Min
    prbs_err_count = read_prbs_err_cnt(rx_port);//Actual Read
    }

    if(time_sec == 0x600) {
    printf("\nPRBS Test running for 10-mins"); printf("\nTest Progress (Time Completed in mins.) : ");
    for(t=0;t<10;t++) { USDELAY(60000000); printf("  %d",t+1); } // 10 Iterations of 1-Min
    prbs_err_count = read_prbs_err_cnt(rx_port);//Actual Read
    }

    if(time_sec == 0x900) {
    printf("\nPRBS-9 Test running for 15-mins"); printf("\nTest Progress (Time Completed in mins.) : ");
    for(t=0;t<15;t++) { USDELAY(60000000); printf("  %d",t+1); } // 15 Iterations of 1-Min
    prbs_err_count = read_prbs_err_cnt(rx_port);//Actual Read
    }

    //BIST_EN_TX in RXTX_REG2 -- DISABLE
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2 , XGENET , tx_port , display);
    wr_val = sm_enet_set(rd_val,0x0, 11, 11);
    enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, wr_val , XGENET , tx_port , display);
    //BIST_EN_RX in RXTX_REG7 -- DISABLE
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 7*2 , XGENET , rx_port , display);
    wr_val = sm_enet_set(rd_val,0x0, 6, 6);
    enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 7*2, wr_val , XGENET , rx_port , display);

    return prbs_err_count;
}

int read_prbs_err_cnt(int rx_port) {
    uint32_t inst, inst_base;
    unsigned int  wr_val, rd_val;
    int display = 0;
    int ret_val=0;
    int prbs_err_count=0;
    inst = 0;
    inst_base = 0x0400 + inst*0x0200;

    USDELAY(2000);
    //Reset BERT_RESET_B in RXTX_REG61
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg61", inst_base + 61*2 , XGENET , rx_port , display);
    wr_val = sm_enet_set(rd_val,0x0, 5, 5);
    enet_sds_ind_csr_reg_wr("rxtx_reg61", inst_base + 61*2, wr_val , XGENET , rx_port , display);
    USDELAY(2000);
    //Reset BERT_RESET_B in RXTX_REG61
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg61", inst_base + 61*2 , XGENET , rx_port , display);
    wr_val = sm_enet_set(rd_val,0x1, 5, 5);
    enet_sds_ind_csr_reg_wr("rxtx_reg61", inst_base + 61*2, wr_val , XGENET , rx_port , display);

    USDELAY(2000);
    //Toggel RX_BIST_RESYNC in RXTX_REG6
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2 , XGENET , rx_port , display);
    wr_val = sm_enet_set(rd_val,0x1, 1, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val , XGENET , rx_port , display);
    USDELAY(2000);
    //Toggel RX_BIST_RESYNC in RXTX_REG6
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2 , XGENET , rx_port , display);
    wr_val = sm_enet_set(rd_val,0x0, 1, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val , XGENET , rx_port , display);
    USDELAY(2000);

    //RX_BIST_ERRCNT_RD in RXTX_REG6
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2 , XGENET , rx_port , display);
    wr_val = sm_enet_set(rd_val,0x1, 0, 0);
    enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val , XGENET , rx_port , display);

    //RX_BIST_ERRCNT_RD in RXTX_REG6
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2 , XGENET , rx_port , display);
    wr_val = sm_enet_set(rd_val,0x0, 0, 0);
    enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val , XGENET , rx_port , display);

    USDELAY(2000);
    //RX_BIST_ERRCNT_LSB in RXTX_REG153
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg153", inst_base + 153*2 , XGENET , rx_port , display);
    prbs_err_count = (int) rd_val;

    return prbs_err_count;

}

void init_xfi_10g(int test_num) {
    init_and_configure_xfi_ports();
    sfp_laser_enable_top_level_function();
    check_link_status_xfi(test_num);
    cable_connect_check(test_num);
}

void init_seq_1() {
    enable_l3_cache();//Enable L3 cache ...
    enable_64_byte_axi_write_padding();//Enable 64-Byte AXI Write padding
    printf("\n");
    cle_bypass_function_xfi();
    USDELAY(100);
    qmi_config_local_xfi();
    USDELAY(1000);
    qm_n_function_xfi_dummy_1();
    sw_workaround();//Sw workaround as given in XGENET EAS
    config_rsif_vc2();//Set VC2 for Eth RSIF
    dis_compl_msg();//Disable completion messages in TSIF
    //set_mcu_ref_burst_cnt(0x1);//Set DDR Refresh Burst count = 1
    //set_mcu_hpweight(0x300);//Set MCU_HPWEIGHT to highest priority
    //set_mcu_lpweight(0x200);//Set MCU_LPWEIGHT to 2nd highest priority
    //set_mcu_wpweight(0x100);//Set MCU_WPWEIGHT to lowest priority
    USDELAY(10000);
}

int check_link_status_xfi(int test_num) {
    int read_link_status_reg , port_link;
    printf("\n");
    for(port_link=0;port_link<=3;port_link++) {
        read_link_status_reg = eth_rd(SM_XGENET_CSR_LINK_STATUS__ADDR , XGENET , port_link , 0);
        read_link_status_reg = read_link_status_reg & 0x1;
        if(read_link_status_reg == 0)  reset_pcs(port_link);//If link is down, do PCS Reset once ...
    }

    // Re-check link on all 4 ports again ...
    for(port_link=0;port_link<=3;port_link++) {
        read_link_status_reg = eth_rd(SM_XGENET_CSR_LINK_STATUS__ADDR , XGENET , port_link , 0);
        read_link_status_reg = read_link_status_reg & 0x1;
        if(read_link_status_reg == 0) { printf("\nLink down on XGE-%d",port_link); test_num = 0x100;}
    }

    return test_num;
}

void turn_sfplaser_onoff() {
  int port , display=0;
  int laser_enable=1;
  printf("\nEnter XGE port no. : "); if(terminal_server_serial_port==1) port=get_val(); port=get_val();
  printf("\nDo you wish to turn SFP+ laser On or Off? (0:Off, 1:On"); if(terminal_server_serial_port==1) laser_enable=get_val(); laser_enable=get_val();
  if(laser_enable==1) sfp_plus_laser_on (port , display);
  if(laser_enable==0) sfp_plus_laser_off(port , display);
}

void serdesintlpbk_ena() {
        uint32_t inst, inst_base;
	int eth_type = XGENET;
	int port;
	int display=0;
	uint32_t rd_val , wr_val;
	printf("\nEnter XGE port no. for setting int. serdes tx2rx loopback : ");
	if(terminal_server_serial_port==1) port=get_val(); port=get_val();
	printf("INIT_SERDES : SERDES Tx2Rx Loopback Enable\n");
                for (inst = 0; inst < 1;  inst++) {
                        printf("INIT_SERDES : RXTX Inst %x\n", inst);
                        inst_base = 0x0400 + inst*0x0200;
                        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,eth_type,port,display);
                        wr_val = sm_enet_set(rd_val, 1, 6, 6);
                        enet_sds_ind_csr_reg_wr("rxtx_reg4",  inst_base + 0x4*2, wr_val,eth_type,port,display);

                        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,eth_type,port,display);
                        wr_val = sm_enet_set(rd_val, 1, 14, 14);
                        enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,eth_type,port,display);
                }
	printf("\t... Done");
}

void serdesintlpbk_dis() {
        uint32_t inst, inst_base;
        int eth_type = XGENET;
        int port;
        int display=0;
	uint32_t rd_val , wr_val;
        printf("\nEnter XGE port no. for clearing int. serdes tx2rx loopback : ");
        if(terminal_server_serial_port==1) port=get_val(); port=get_val();
        printf("INIT_SERDES : SERDES Tx2Rx Loopback Disable\n");
                for (inst = 0; inst < 1;  inst++) {
                        printf("INIT_SERDES : RXTX Inst %x\n", inst);
                        inst_base = 0x0400 + inst*0x0200;
                        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,eth_type,port,display);
                        wr_val = sm_enet_set(rd_val, 0, 6, 6);
                        enet_sds_ind_csr_reg_wr("rxtx_reg4",  inst_base + 0x4*2, wr_val,eth_type,port,display);

                        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,eth_type,port,display);
                        wr_val = sm_enet_set(rd_val, 0, 14, 14);
                        enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,eth_type,port,display);
                }
	printf("\t... Done");
}

void cable_issue() {
  printf("\n\nCable connection issue or part issue");
  printf("\nTest Result : FAIL\n");
}

void xfi_stat_check() {
  int tx_port , rx_port , read_rpkt , read_tpkt , read_tfcs , read_rfcs;
  int pkt_diff;

  for(rx_port=0;rx_port<=3;rx_port++) {
	printf("\n\nXGE-%d ==>",rx_port);
	if(rx_port==0) tx_port=1;
	if(rx_port==1) tx_port=0;
	if(rx_port==2) tx_port=3;
	if(rx_port==3) tx_port=2;
	read_tpkt = axgmac_stat_rd(PEMSTAT_TPKT__ADDR , tx_port);
	read_rpkt = axgmac_stat_rd(PEMSTAT_RPKT__ADDR , rx_port);
	read_tfcs = axgmac_stat_rd(PEMSTAT_TFCS__ADDR , tx_port);
	read_rfcs = axgmac_stat_rd(PEMSTAT_RFCS__ADDR , rx_port);
	#if 0
	  printf("\n[TPKT:%d][RPKT:%d][TFCS:%d][RFCS:%d]",read_tpkt,read_rpkt,read_tfcs,read_rfcs);
	#endif
	#if 0
	printf("\t[TPKT of XGE-%d : %d]",tx_port,read_tpkt);
	#endif
	pkt_diff = read_tpkt - read_rpkt;
	if(pkt_diff>0)	{
		printf("\nPacket Drop count: %d in %d",pkt_diff,4*0x5F5E10);
		total_err_count_xfi[rx_port]++;
	}
	if(read_tfcs>0)	{ printf("\nXGE-%d TFCS found : %d",tx_port,read_tfcs); total_err_count_xfi[tx_port]++; }
	if(read_rfcs>0)	{ printf("\nXGE-%d RFCS found : %d",rx_port,read_rfcs); total_err_count_xfi[rx_port]++; }
	if(pkt_diff>0 && (read_tfcs==0 && read_rfcs==0)) printf("\nNo TFCS on XGE-%d / No RFCS on XGE-%d",tx_port,rx_port);
	if(pkt_diff==0 && (read_tfcs==0 && read_rfcs==0)) printf("\nNo issues with pkt reception");
  }


  check_pcsfifo_status();
} 

#if 0
qm_ret_t qm_build_eth_pkt_pdl_temp(u8 *pa_ptr, u32 len, u8 data) //_tp
{
  int     i;
  u8 * ptr = (u8 *)qm_get_va(pa_ptr);
  lprintf(8, "input pa = 0x%x, used va = 0x%x (for FF)\n",pa_ptr,ptr);
  PF_LOG(PF_QM_FTRC, "Entering qm_build_eth_pkt....\n");
  if (len < 30) {
    PF_LOG(PF_QM_FTRC, "Exiting  qm_build_eth_pkt....\n");
    return QM_FAIL;
  }
  for (i=0; i < 6; i++)
    *ptr++ = 0xff;
  for (i=6; i < 12; i++)
    *ptr++ = 0xd0 + i - 6;

  *ptr++ = 0x08;
  *ptr++ = 0x06;

  for (i=14; i < len; i++)
  {
    *ptr++ = i;
    }
  //dcache_flush_all();
  PF_LOG(PF_QM_FTRC, "Exiting  qm_build_eth_pkt....\n");
  return(QM_OK);
}
#endif
