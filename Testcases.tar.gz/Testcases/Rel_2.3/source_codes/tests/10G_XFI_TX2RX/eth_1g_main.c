#define uint32_t unsigned int

#include <stdio.h>
#include <common.h>
#include "eth_common.h"
#include "eth_1g_csr.h"
#include "eth_mg_csr.h"
#include "sm_xxx_serdes.h"

#include "qm_drv.h" 
#include "qm_misc.h"
#include "qm_vfw.h"

// Base addresses
extern int enet_base_addr;

extern fwd_uc_tbl_t fwd_ges_tbl; 
extern fwd_uc_tbl_t fwd_ge1_tbl; 
extern fwd_uc_tbl_t fwd_xge1_tbl;

///// Operating modes for Enet //////
static int clk_mode_1g = 0;    // 0 = External Clk Mode; 0 = Internal clk mode
static int cle_enable = 0;     // 1 = Real CLE; 0 = CLE bypass mode
static int mac_mode_1g = 2;       // 0 = 10M ; 1 = 100M ; 2 = 1G 
//static int loopback = 0;       // 1 = QM loopback; 0 = RxTxTso buffer loopback
static int loopback = 1;       //md: 1 = QM-level-lpbk-test
static int kc = 0;             // KC = 1 Koolchip virsubmux, KC = 0 enet_sgmii vursub mux

//int gating_bypass_1g = 0;   //0=Yes Gating Enabled
int gating_bypass_1g = 1;     //1=No  Gating Disabled 

int tx2rx_serdes_lb_1g = 1; //0=No  serdes level tx-2-rx lpbk disable
//int tx2rx_serdes_lb_1g = 1;   //1=Yes serdes level tx-2-rx lpbk enable, (Gating should be Disabled with AutoNeg Mode gating_bypass_1g=1)

//int an_en_1g = 0;           //0=Non AutoNegNode Enabled
int an_en_1g = 1;             //1=AutoNegNode Enabled

static int advanced_debug = 1; // 1 = Promt for options with xgenet_main, 0= quit to Menu
///// Operating mode ends here

////// Declarations begin here
static unsigned long long hinfo = 0x0;
static int plc_cir,plc_cbs,plc_eir,plc_ebs,plc_idx,plc_cm,plc_cf;
static int plc_dualbucket;
static int split_boundary;
static int ip_hdr,eth_hdr,ipprot_hdr,ip_ver,ip_prot,ip_frag;
static int cle_bypass,cle_dly,cle_drop,cle_wol,cle_in;
static int dstqid0,dstqid1,fpsel,fpsel1,nxtfpsel,henqnum,hfpsel,dr,hr;
static int plc_en,plc_dbidx,plc_perflow,plc_priority,plc_flowgroup;
static int ptp_en;
static int hinfo_ll,hinfo_lm,hinfo_ml,hinfo_mm;
static int mtype,crc_en,vlan,dt,ts,tso,chksum,mss;
static int rr;
static int mirror = 0;
static int stash = 0;
static int hdr_split = 0;
static int tmp = 0;

static  int indir_addr_reg = 0x00000000;
static  int indir_data_reg = 0x00000008;
static  int indir_cmd_reg  = 0x00000004;
static  int indir_read_reg = 0x0000000c;
static  int indir_stat_reg = 0x00000010;
static  int read_command = 0x40000000;
static  int write_command = 0x80000000;
static int  read_data = 0x00000000;
static int  write_data = 0x00000000;
static int  read_address = 0x00000000;
static int  write_address = 0x00000000;
static int  ind_address = 0x00000000;
static int  pemstat1_addr_reg;
static int  pemstat1_cmd_reg;
static int  pemstat1_read_reg;
static int  pemstat1_stat_reg;
static int  pemstat1_address  = 0x00000020;

static int  pemstat2_addr_reg;
static int  pemstat2_cmd_reg;
static int  pemstat2_read_reg;
static int  pemstat2_stat_reg;
static int  pemstat2_address  = 0x00000020;

int itr_count[4];
u64 buf[16]; //changes to work tx-2-rx md:
u64 buf32[16]; //changes to work tx-2-rx md:
u64 buf33[16]; //changes to work tx-2-rx md:
u64 buf34[16]; //changes to work tx-2-rx md:
int total_err_count[4]={0};

#if 1 //md: for eth_tx2rx

void config_phy_non_auto_neg_mode() {
    int ext_link,speed;
    int link, an_comp, an_done = 0;
    int read_data;
    int display = 0;
    int port=0, data32;

    int phy_addr, phy_reg, ind_address,ind_data;

#if 1   // configured non auto neg mode in PHY register
    for(phy_addr=0x11; phy_addr<0x19; phy_addr++) {
        /*
           phy_reg=22;
           ind_address = ((phy_addr << 8) | phy_reg);
           ind_data = mdio_rd(ind_address,MENET,port,0);
           printf("Before PHY write PHY_Addr:0x%x read_val:0x%x\n",phy_addr,ind_data);
           ind_data = 1;     // set page to 1
           mdio_wr(ind_address,ind_data,MENET,port,0);
           delay(1000);
           ind_data = mdio_rd(ind_address,MENET,port,0);
           printf("After  PHY write PHY_Addr:0x%x read_val:0x%x\n",phy_addr,ind_data);
           */
        phy_reg=0;
        ind_address = ((phy_addr << 8) | phy_reg);
        ind_data = mdio_rd(ind_address,MENET,port,0);
        printf("Before PHY write PHY_Addr:0x%x read_val:0x%x\n",phy_addr,ind_data);
        ind_data = ind_data & 0xEFFF;     // non auto neg mode
        ind_data = ind_data & 0xDFFF;     // 1 gig mode
        ind_data = ind_data | 0x0040;     // 1 gig mode
        ind_data = ind_data | 0x0100;     // full duplex mode
        ind_data = ind_data | 0x8000;     // reset tge PHY
        mdio_wr(ind_address,ind_data,MENET,port,0);
        //delay(1000);
        USDELAY(1000);
        ind_data = mdio_rd(ind_address,MENET,port,0);
        printf("After  PHY write PHY_Addr:0x%x read_val:0x%x\n",phy_addr,ind_data);
        /*
           phy_reg=22;
           ind_address = ((phy_addr << 8) | phy_reg);
           ind_data = mdio_rd(ind_address,MENET,port,0);
           printf("Before PHY write PHY_Addr:0x%x read_val:0x%x\n",phy_addr,ind_data);
           ind_data = 0;     // set page to 1
           mdio_wr(ind_address,ind_data,MENET,port,0);
           delay(1000);
           ind_data = mdio_rd(ind_address,MENET,port,0);
           printf("After  PHY write PHY_Addr:0x%x read_val:0x%x\n",phy_addr,ind_data);
           */
    }
#endif   // configured non auto neg mode in PHY register
}


void set_serdes_lpbk() {
    int intf,port,display=0; 
    uint32_t wr_val, rd_val;
    uint32_t inst, inst_base;

    printf("SATA-SGMII SERDES Tx2Rx Loopback\n");
    for (intf = 0; intf < 3;  intf+=2) {
        port = intf;
        printf("Tx2Rx loopback bit set before write\n");
        for (inst = 0; inst < 2;  inst++) {
            inst_base = 0x0400 + inst*0x0200;
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,ENET,port,display);
            printf("rx2tx_reg4 inst:%d inst_base:0x%xrd_val:0x%x\n",inst,inst_base,rd_val);
        }

        for (inst = 0; inst < 2;  inst++) {
            inst_base = 0x0400 + inst*0x0200;
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,ENET,port,display);
            wr_val = sm_enet_set(rd_val, 1, 6, 6);
            enet_sds_ind_csr_reg_wr("rxtx_reg4",  inst_base + 0x4*2, wr_val,ENET,port,display);

            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,ENET,port,display);
            wr_val = sm_enet_set(rd_val, 1, 14, 14);
            enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,ENET,port,display);
        }

        printf("Tx2Rx loopback bit set after write\n");
        for (inst = 0; inst < 2;  inst++) {
            inst_base = 0x0400 + inst*0x0200;
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,ENET,port,display);
            printf("rx2tx_reg4 inst:%d inst_base:0x%xrd_val:0x%x\n",inst,inst_base,rd_val);
        }
    }
    /*
       printf("XFI-SGMII SERDES Tx2Rx Loopback\n");
       for (port = 0; port < 4; port++) {
       printf("Tx2Rx loopback bit set before write\n");
       for (inst = 0; inst < 1;  inst++) {
       inst_base = 0x0400 + inst*0x0200;
       rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,XGENET,port,display);
       printf("rx2tx_reg4 inst:%d inst_base:0x%xrd_val:0x%x\n",inst,inst_base,rd_val);
       }

       for (inst = 0; inst < 1;  inst++) {
       inst_base = 0x0400 + inst*0x0200;
       rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,XGENET,port,display);
       wr_val = sm_enet_set(rd_val, 1, 6, 6);
       enet_sds_ind_csr_reg_wr("rxtx_reg4",  inst_base + 0x4*2, wr_val,XGENET,port,display);

       rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,XGENET,port,display);
       wr_val = sm_enet_set(rd_val, 1, 14, 14);
       enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,XGENET,port,display);
       }

       printf("Tx2Rx loopback bit set after write\n");
       for (inst = 0; inst < 1;  inst++) {
       inst_base = 0x0400 + inst*0x0200;
       rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,XGENET,port,display);
       printf("rx2tx_reg4 inst:%d inst_base:0x%xrd_val:0x%x\n",inst,inst_base,rd_val);
       }
       }
       */
}

void reset_serdes_lpbk() {
    int intf,port,display=0; 
    uint32_t wr_val, rd_val;
    uint32_t inst, inst_base;

    printf("SATA-SGMII SERDES Tx2Rx Loopback\n");
    for (intf = 0; intf < 3;  intf+=2) {
        port = intf;
        printf("Tx2Rx loopback bit set before write\n");
        for (inst = 0; inst < 2;  inst++) {
            inst_base = 0x0400 + inst*0x0200;
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,ENET,port,display);
            printf("rx2tx_reg4 inst:%d inst_base:0x%xrd_val:0x%x\n",inst,inst_base,rd_val);
        }

        for (inst = 0; inst < 2;  inst++) {
            inst_base = 0x0400 + inst*0x0200;
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,ENET,port,display);
            wr_val = sm_enet_set(rd_val, 0, 6, 6);
            enet_sds_ind_csr_reg_wr("rxtx_reg4",  inst_base + 0x4*2, wr_val,ENET,port,display);

            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,ENET,port,display);
            wr_val = sm_enet_set(rd_val, 0, 14, 14);
            enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,ENET,port,display);
        }

        printf("Tx2Rx loopback bit set after write\n");
        for (inst = 0; inst < 2;  inst++) {
            inst_base = 0x0400 + inst*0x0200;
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,ENET,port,display);
            printf("rx2tx_reg4 inst:%d inst_base:0x%xrd_val:0x%x\n",inst,inst_base,rd_val);
        }
    }
    /*
       printf("XFI-SGMII SERDES Tx2Rx Loopback\n");
       for (port = 0; port < 4; port++) {
       printf("Tx2Rx loopback bit set before write\n");
       for (inst = 0; inst < 1;  inst++) {
       inst_base = 0x0400 + inst*0x0200;
       rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,XGENET,port,display);
       printf("rx2tx_reg4 inst:%d inst_base:0x%xrd_val:0x%x\n",inst,inst_base,rd_val);
       }

       for (inst = 0; inst < 1;  inst++) {
       inst_base = 0x0400 + inst*0x0200;
       rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,XGENET,port,display);
       wr_val = sm_enet_set(rd_val, 0, 6, 6);
       enet_sds_ind_csr_reg_wr("rxtx_reg4",  inst_base + 0x4*2, wr_val,XGENET,port,display);

       rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,XGENET,port,display);
       wr_val = sm_enet_set(rd_val, 0, 14, 14);
       enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,XGENET,port,display);
       }

       printf("Tx2Rx loopback bit set after write\n");
       for (inst = 0; inst < 1;  inst++) {
       inst_base = 0x0400 + inst*0x0200;
       rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,XGENET,port,display);
       printf("rx2tx_reg4 inst:%d inst_base:0x%xrd_val:0x%x\n",inst,inst_base,rd_val);
       }
       }
       */
}

void eth_tx2rx_lpbk_test_sata_1g() {

    unsigned int mn,qmid,ps,pn,temp;
    u64 *guess;
    qm_ret_t ret;
    enq_req_t *per;
    enq_req_t *per32;
    enq_req_t *per33;
    enq_req_t *per34;    
    qm_buf_t qm_buf;
    qm_buf_t qm_buf32;
    qm_buf_t qm_buf33;
    qm_buf_t qm_buf34;    
    enq_cfg_t enq_cfg;
    q_state_t cfg;
    int port_num_calc=0; 
    int port,i;

    //lprintf(8, "\r\n ++++++++++++ SATA-SGMII Tx-2-Rx loopback test +++++++++++++\r\n");
    qm_buf.bp = buf;
    qm_buf32.bp = buf32;
    qm_buf33.bp = buf33;
    qm_buf34.bp = buf34; 
    memset ((char *)msgbuf, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    memset ((char *)msgbuf32, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    memset ((char *)msgbuf33, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    memset ((char *)msgbuf34, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    /* 
       printf("\nEnter Packet Size (in hex): \n");
       ps = get_val();
       printf("Packet Size:0x%x\n",ps);

       printf("\r\nEnter Number of Packets (in hex): \r\n");
       pn = get_val();
       printf("Number of Packets: 0x%x\r\n",pn);
       */
    //ps=64; //256;
    ps=256; //256;
    pn=10000; //10; //10000; //100;
    //printf("\r\nEnter Number of Packets (in hex): \r\n");
    //pn = get_val();
    //printf("Number of Packets: 0x%x\r\n",pn);

    //ps = 128; //PKT_SIZE; //packet size
    //printf("\r\nPacket Size:0x%x\r\n",ps);

    //pn = 1; //PKT_NUM; // Number of PAckets to send
    pn = pn*4;
    //lprintf(8, "Number of Packets: 0x%x\n",pn);

    qmid = 1;
    mn = QM_TEST_MSG_NUM; //1
    ret = sys_alloc_enet_buf(1, mn, &qm_buf); //// Allocate the FPQ Buffer
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf Fail qmid:%d\r\n",qmid);
        return ret;
    }
    //printf("\nQM sys_alloc_enet_buf done....  qmid:%d\r\n",qmid);
    ret = sys_alloc_enet_buf(1, mn, &qm_buf32); //// Allocate the FPQ Buffer
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf_32 Fail qmid:%d\r\n",qmid);
        return ret;
    }
    //printf("\nQM sys_alloc_enet_buf_32 done....  qmid:%d\r\n",qmid);    
    ret = sys_alloc_enet_buf(1, mn, &qm_buf33); //// Allocate the FPQ Buffer
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf_33 Fail qmid:%d\r\n",qmid);
        return ret;
    }
    //printf("\nQM sys_alloc_enet_buf_33 done....  qmid:%d\r\n",qmid);    
    ret = sys_alloc_enet_buf(1, mn, &qm_buf34); //// Allocate the FPQ Buffer
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf_34 Fail qmid:%d\r\n",qmid);
        return ret;
    }
    //printf("\nQM sys_alloc_enet_buf_34 done....  qmid:%d\r\n",qmid);

    ret = qm_build_eth_pkt((unsigned char *)buf[0], ps);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt Fail qmid:%d\r\n",qmid);
        return ret;

    }    
    ret = qm_build_eth_pkt((unsigned char *)buf32[0], ps);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt buf32 Fail qmid:%d\r\n",qmid);
        return ret;

    }    
    ret = qm_build_eth_pkt((unsigned char *)buf33[0], ps);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt buf33 Fail qmid:%d\r\n",qmid);
        return ret;

    }    
    ret = qm_build_eth_pkt((unsigned char *)buf34[0], ps);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt buf34 Fail qmid:%d\r\n",qmid);
        return ret;

    }
    //printf("QM qm_build_eth_pkt done....    qmid:%d\r\n",qmid);


    per = sys_enet_enq_cfg(buf[0], ps);
    extern enq_req_t er;
    per = &er;
    if (!per) {
        printf("QM qm_proc_bld_enq_req failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }

    //printf("QM qm_proc_bld_enq_req buf32 done.... qmid:%d\r\n",qmid);
    per32 = sys_enet_enq_cfg32(buf32[0], ps);
    extern enq_req_t er32;
    per32 = &er32;
    if (!per32) {
        printf("QM qm_proc_bld_enq_req buf32 failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }

    per33 = sys_enet_enq_cfg33(buf33[0], ps);
    extern enq_req_t er33;
    per33 = &er33;
    if (!per33) {
        printf("QM qm_proc_bld_enq_req buf33 failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }

    per34 = sys_enet_enq_cfg34(buf34[0], ps);
    extern enq_req_t er34;
    per34 = &er34;
    if (!per34) {
        printf("QM qm_proc_bld_enq_req buf34 failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }
    q_state_t q_state_pq_32[20];
    u64 hd_ptr_32;
    u64 hd_ptr_33;
    u64 hd_ptr_34;
    u64 hd_ptr_35;
    //u64 wn1[] ={1,1,1,1,1};// Old code - wrong wn1
    u8 wn1[] ={1,1,1,1,1};

    QM_CHK_RET(qm_get_q_state_dir(1,32,1,wn1,&q_state_pq_32[0]));
    hd_ptr_32 = (q_state_pq_32[0].pqfp.hd_ptr);
    QM_CHK_RET(qm_get_q_state_dir(1,33,1,wn1,&q_state_pq_32[0]));
    hd_ptr_33 = (q_state_pq_32[0].pqfp.hd_ptr);
    QM_CHK_RET(qm_get_q_state_dir(1,34,1,wn1,&q_state_pq_32[0]));
    hd_ptr_34 = (q_state_pq_32[0].pqfp.hd_ptr);
    QM_CHK_RET(qm_get_q_state_dir(1,35,1,wn1,&q_state_pq_32[0]));
    hd_ptr_35 = (q_state_pq_32[0].pqfp.hd_ptr);

    for(i=0; i<pn; i++) {
        if((i%4) == 0) {
            port_num_calc=0;	
            per->qid = QID32;    // port-0
            ret = qm_proc_enq_dir(1,per);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count[0]++;
                total_err_count[1]++;
                total_err_count[2]++;
                total_err_count[3]++;
                return ret;
            }
            pkt_compare(port_num_calc, hd_ptr_32);


            //printf("per->qid = QID32\n");
        }
        else if((i%4) == 1)  {
            port_num_calc=1;	
            per32->qid = QID33;    // port-1
            ret = qm_proc_enq_dir(1,per32);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count[1]++;
                total_err_count[2]++;
                total_err_count[3]++;
                return ret;
            }            
            pkt_compare(port_num_calc, hd_ptr_33);
            //printf("per->qid = QID33\n");
        }
        else if((i%4) == 2)  {
            port_num_calc=2;	
            per33->qid = QID34;    // port-1
            ret = qm_proc_enq_dir(1,per33);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count[2]++;
                total_err_count[3]++;
                return ret;
            }             
            pkt_compare(port_num_calc, hd_ptr_34);
            //printf("per->qid = QID34\n");
        }
        else if((i%4) == 3)  {
            port_num_calc=3;	
            per34->qid = QID35;    // port-1
            ret = qm_proc_enq_dir(1,per34);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count[3]++;
                return ret;
            }             
            pkt_compare(port_num_calc, hd_ptr_35);
            //printf("per->qid = QID35\n");
        }
        //printf("QM qm_proc_enq_dir done....     qmid:%d per->qid:%d PortNo:%d\n",qmid,per->qid,(i%4));
        //        pkt_compare(port_num_calc);


#if 0        
        mn = 1;
        while(mn) {
            mn = 1; //QM_TEST_MSG_NUM;
            if((i%4) == 0) { // port-0
                ret = qm_proc_deq_dir(qmid, QID64, QM_MSG_SZ_32B, &mn, msgbuf); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    return ret;
                }
                //printf("\nQM qm_proc_deq_dir done....   qmid=%d mn:%d qid:%d\n",qmid,mn,QID64);  
            }
            else if((i%4) == 1) { // port-1
                ret = qm_proc_deq_dir(qmid, QID65, QM_MSG_SZ_32B, &mn, msgbuf); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    return ret;
                }
                //printf("\nQM qm_proc_deq_dir done.... qmid=%d mn:%d qid:%d\n",qmid,mn,QID65);  
            }
            if((i%4) == 2) { // port-0
                ret = qm_proc_deq_dir(qmid, QID66, QM_MSG_SZ_32B, &mn, msgbuf); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    return ret;
                }
                //printf("\nQM qm_proc_deq_dir done....   qmid=%d mn:%d qid:%d\n",qmid,mn,QID66);  
            }
            else if((i%4) == 3) { // port-1
                ret = qm_proc_deq_dir(qmid, QID67, QM_MSG_SZ_32B, &mn, msgbuf); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    return ret;
                }
                //printf("\nQM qm_proc_deq_dir done.... qmid=%d mn:%d qid:%d\n",qmid,mn,QID67);  
            }
            if (mn == QM_TEST_MSG_NUM) {
                ret = qm_check_msgs(mn, QM_MSG_SZ_32B, msgbuf);
                if (ret != QM_OK) {
                    printf("QM qm_check_msgs failed: msgbuf=0x%x, ret = %d, mn = %d.... qmid:%d\n", (u32)msgbuf, ret, mn,qmid);
                    //return ret;
                }
            }
            /*
               else
               {
               printf("%s Failed: QM deq msg number (mn:%d) doesn't match with enq msg number (%d) msgbuf=0x%x.... qmid:%d\n", 
               __FUNCTION__, mn, QM_TEST_MSG_NUM, (u32)msgbuf,qmid);
            //return QM_FAIL;
            }
            */
            mn=0;
        } // while(mn)

#endif
#if 0        
        printf("\n------------------ PacketNo:%d -----------------\n",(i+1));

        qm_dump_pb_state(1, 0, 0);
        qm_dump_qstate(1, 1, 1);
        qm_dump_qstate(1, 4, 32);
        qm_dump_qstate(1, 4, 64);

        u32 reg,tmp;
        printf("\n------------------ QMI-FPQ-Num-Entries P0/P1 ----------------\n");
        reg = 0x1f219030;
        tmp = read32(reg);
        printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f219034;
        tmp = read32(reg);
        printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f219038;
        tmp = read32(reg);
        printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f21903c;
        tmp = read32(reg);
        printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);

        printf("\n------------------ QMI-WQ-Num-Entries P0/P1 -----------------\n");
        reg = 0x1f219050;
        tmp = read32(reg);
        printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f219054;
        tmp = read32(reg);
        printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f219058;
        tmp = read32(reg);
        printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f21905c;
        tmp = read32(reg);
        printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);

        reg = 0x1f219060;
        tmp = read32(reg);
        printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f219064;
        tmp = read32(reg);
        printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f219068;
        tmp = read32(reg);
        printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f21906c;
        tmp = read32(reg);
        printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);

        printf("\n------------------ QMI-FPQ-Num-Entries P2/P3----------------\n");
        reg = 0x1f229030;
        tmp = read32(reg);
        printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f229034;
        tmp = read32(reg);
        printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f229038;
        tmp = read32(reg);
        printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f22903c;
        tmp = read32(reg);
        printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);

        printf("\n------------------ QMI-WQ-Num-Entries P2/P3 -----------------\n");
        reg = 0x1f229050;
        tmp = read32(reg);
        printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f229054;
        tmp = read32(reg);
        printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f229058;
        tmp = read32(reg);
        printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f22905c;
        tmp = read32(reg);
        printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);

        reg = 0x1f229060;
        tmp = read32(reg);
        printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f229064;
        tmp = read32(reg);
        printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f229068;
        tmp = read32(reg);
        printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
        reg = 0x1f22906c;
        tmp = read32(reg);
        printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);   
#endif

    } // for loop
}


void eth_tx2rx_lpbk_test_sata_1g_dbg() {

    total_err_count[0]=0;
    total_err_count[1]=0;
    total_err_count[2]=0;
    total_err_count[3]=0;
    unsigned int mn,qmid,ps,pn,temp;
    qm_ret_t ret;
    enq_req_t *per;
    enq_req_t *per32;
    enq_req_t *per33;
    enq_req_t *per34;    
    qm_buf_t qm_buf;
    qm_buf_t qm_buf32;
    qm_buf_t qm_buf33;
    qm_buf_t qm_buf34;    
    enq_cfg_t enq_cfg;
    q_state_t cfg;
    int port_num_calc=0; 
    int port,i;

    printf("\r\n ++++++++++++ SATA-SGMII Tx-2-Rx loopback test +++++++++++++\r\n");
    qm_buf.bp = buf;
    qm_buf32.bp = buf32;
    qm_buf33.bp = buf33;
    qm_buf34.bp = buf34; 
    memset ((char *)msgbuf, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    memset ((char *)msgbuf32, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    memset ((char *)msgbuf33, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    memset ((char *)msgbuf34, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);

    ps=64; //256;
    pn=10000; //100;
    //pn=5; //100;

    pn = pn*4;
    printf("Number of Packets: 0x%x\n",pn);

    qmid = 1;
    mn = QM_TEST_MSG_NUM; //1
    ret = sys_alloc_enet_buf(1, mn, &qm_buf); //// Allocate the FPQ Buffer
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf Fail qmid:%d\r\n",qmid);
        return ret;
    }
    //printf("\nQM sys_alloc_enet_buf done....  qmid:%d\r\n",qmid);
    ret = sys_alloc_enet_buf(1, mn, &qm_buf32); //// Allocate the FPQ Buffer
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf_32 Fail qmid:%d\r\n",qmid);
        return ret;
    }
    //printf("\nQM sys_alloc_enet_buf_32 done....  qmid:%d\r\n",qmid);    
    ret = sys_alloc_enet_buf(1, mn, &qm_buf33); //// Allocate the FPQ Buffer
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf_33 Fail qmid:%d\r\n",qmid);
        return ret;
    }
    //printf("\nQM sys_alloc_enet_buf_33 done....  qmid:%d\r\n",qmid);    
    ret = sys_alloc_enet_buf(1, mn, &qm_buf34); //// Allocate the FPQ Buffer
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf_34 Fail qmid:%d\r\n",qmid);
        return ret;
    }
    //printf("\nQM sys_alloc_enet_buf_34 done....  qmid:%d\r\n",qmid);

    ret = qm_build_eth_pkt((unsigned char *)buf[0], ps);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt Fail qmid:%d\r\n",qmid);
        return ret;

    }    
    ret = qm_build_eth_pkt((unsigned char *)buf32[0], ps);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt buf32 Fail qmid:%d\r\n",qmid);
        return ret;

    }    
    ret = qm_build_eth_pkt((unsigned char *)buf33[0], ps);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt buf33 Fail qmid:%d\r\n",qmid);
        return ret;

    }    
    ret = qm_build_eth_pkt((unsigned char *)buf34[0], ps);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt buf34 Fail qmid:%d\r\n",qmid);
        return ret;

    }
    //printf("QM qm_build_eth_pkt done....    qmid:%d\r\n",qmid);

    per = sys_enet_enq_cfg(buf[0], ps);
    extern enq_req_t er;
    per = &er;    
    if (!per) {
        printf("QM qm_proc_bld_enq_req failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }
    //printf("QM qm_proc_bld_enq_req buf32 done.... qmid:%d\r\n",qmid);
    per32 = sys_enet_enq_cfg32(buf32[0], ps);
    extern enq_req_t er32;
    per32 = &er32;    
    if (!per32) {
        printf("QM qm_proc_bld_enq_req buf32 failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }

    per33 = sys_enet_enq_cfg33(buf33[0], ps);
    extern enq_req_t er33;
    per33 = &er33;    
    if (!per33) {
        printf("QM qm_proc_bld_enq_req buf33 failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }

    per34 = sys_enet_enq_cfg34(buf34[0], ps);
    extern enq_req_t er34;
    per34 = &er34;    
    if (!per34) {
        printf("QM qm_proc_bld_enq_req buf34 failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }
    for(i=0; i<pn; i++) {
        if((i%4) == 0) {
            port_num_calc=1;	
            per->qid = QID32;    // port-0
            ret = qm_proc_enq_dir(1,per);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count[0]++;
                total_err_count[1]++;
                total_err_count[2]++;
                total_err_count[3]++;            
                return ret;
            }
            //printf("per->qid = QID32\n");
        }
        else if((i%4) == 1)  {
            port_num_calc=0;	
            per32->qid = QID33;    // port-1
            ret = qm_proc_enq_dir(1,per32);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count[1]++;
                total_err_count[2]++;
                total_err_count[3]++;
                return ret;
            }            
            //printf("per->qid = QID33\n");
        }
        else if((i%4) == 2)  {
            port_num_calc=3;	
            per33->qid = QID34;    // port-1
            ret = qm_proc_enq_dir(1,per33);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count[2]++;
                total_err_count[3]++;
                return ret;
            }             
            //printf("per->qid = QID34\n");
        }
        else if((i%4) == 3)  {
            port_num_calc=2;	
            per34->qid = QID35;    // port-1
            ret = qm_proc_enq_dir(1,per34);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);

                total_err_count[3]++;
                return ret;
            }             
            //printf("per->qid = QID35\n");
        }
        //printf("QM qm_proc_enq_dir done....     qmid:%d per->qid:%d PortNo:%d\n",qmid,per->qid,(i%4));
        pkt_compare_dbg(port_num_calc);

    } // for loop
}
#endif //md: for tx2rx


/////// Declarations end
int myread(int *address, int display){
    int *addr_int;
    addr_int = address;
    int rdata = *addr_int;
    if(display_all|display){ printf("Read32  @ 0x:"); putnum(addr_int); printf(" is 0x");  putnum(rdata);  printf("\n\r");}
    return(rdata);
}

void mywrite(int *address, int data){
    int *addr_int;
    addr_int = address;
    *addr_int = data;
    if(display_all) {printf("Write32 @ 0x:"); putnum(address); printf(" is 0x");  putnum(data);  printf("\n\r");}
}



/////// Including the C file for cle_2inline programming
//#include "sm_cle_2inline.c"
//#include "qm.c"

/////// Function declarations begin here //////////////////////////////////////

int my_get_val(char *str){
    int val;
    printf(str);
    val = get_val();
    printf("\n\r");
    return val;
}

void mac_ind_write_mode (int port, int addr, int data2, int data1, int data0) {
    int display = 0;
    if     (mac_mode_1g==2)  mcxmac_ind_wr(addr,data2,ENET,port,display); 
    else if(mac_mode_1g==1)  mcxmac_ind_wr(addr,data1,ENET,port,display);
    else                  mcxmac_ind_wr(addr,data0,ENET,port,display);
}

void enet_reg_wr_mode (int port, int addr, int data2, int data1, int data0) {
    int display = 0;
    if     (mac_mode_1g==2) eth_wr(addr, data2,ENET,port,display);
    else if(mac_mode_1g==1) eth_wr(addr, data1,ENET,port,display);
    else                 eth_wr(addr, data0,ENET,port,display);
}

//-----------------------------------
// Policer Related Functions
//-----------------------------------

// Policer Read Index
int enet_plc_rd(int index,int all_stat) {
    int counter = 0;
    int cmd_addr = 0x80000000 | index;
    int dropcnt;
    int display = 0;
    int port = 0; //FIXME
    eth_wr(SM_ENET_CSR_RSIF_POLICER_REG0__ADDR,cmd_addr,ENET,port,display); // Address
    do
    {
        // int wt;
        // for(wt = 0; wt < 10000; wt++);
        read_data = eth_rd(SM_ENET_CSR_RSIF_POLICER_REG0__ADDR,ENET,port,display) & 0xC0000000;
        counter++;
    } while (read_data != 0x00000000 && counter != 20);

    if(read_data) { printf("ERROR : Policer Programming timeout");printf("\n\r"); }

    if(all_stat == 1) { // Print all stats
        printf("Policer Programming done for Index : ");putnum(index);printf("\n\r");
        printf("CBS : 0x");
        putnum(eth_rd(SM_ENET_CSR_RSIF_POLICER_REG1__ADDR,ENET,port,display));printf("\n\r"); // CBS
        printf("CIR : 0x");
        putnum(eth_rd(SM_ENET_CSR_RSIF_POLICER_REG2__ADDR,ENET,port,display));printf("\n\r"); // CIR
        printf("CCA : 0x");
        putnum(eth_rd(SM_ENET_CSR_RSIF_POLICER_REG3__ADDR,ENET,port,display));printf("\n\r"); // CCA
        printf("EBS : 0x");
        putnum(eth_rd(SM_ENET_CSR_RSIF_POLICER_REG4__ADDR,ENET,port,display));printf("\n\r"); // EBS
        printf("CM,CF,EIR : 0x");
        putnum(eth_rd(SM_ENET_CSR_RSIF_POLICER_REG5__ADDR,ENET,port,display));printf("\n\r"); // CM,CF,EIR
        printf("ECA : 0x");
        putnum(eth_rd(SM_ENET_CSR_RSIF_POLICER_REG6__ADDR,ENET,port,display));printf("\n\r"); // EIR
        dropcnt = eth_rd(SM_ENET_CSR_RSIF_POLICER_REG8__ADDR,ENET,port,display);
        printf("Drop Count : 0x");
        putnum(dropcnt);printf("\n\r"); // Drop Count
    }
    else if(all_stat == 0){ // Print drop count
        dropcnt = eth_rd(SM_ENET_CSR_RSIF_POLICER_REG8__ADDR,ENET,port,display);
        printf("Policer Programming done for Index : ");putnum(index);printf("\t");
        printf("Drop Count : 0x");
        putnum(dropcnt);printf("\n\r"); // Drop Count
    }
    else { // don't print just read drop count
        dropcnt = eth_rd(SM_ENET_CSR_RSIF_POLICER_REG8__ADDR,ENET,port,display);
    }

    return dropcnt;
}

// Policer Read Write Test
void plc_rd_wr_test(int clean) {
    int counter = 0;
    int loop = 1;
    int display = 0;
    int port = 0; //FIXME
    for(loop = 1; loop < 0xa; loop++) {
        eth_wr(SM_ENET_CSR_RSIF_POLICER_REG1__ADDR,loop,ENET,port,display); // CBS
        eth_wr(SM_ENET_CSR_RSIF_POLICER_REG2__ADDR,loop,ENET,port,display); // CIR
        eth_wr(SM_ENET_CSR_RSIF_POLICER_REG4__ADDR,loop,ENET,port,display); // EBS
        eth_wr(SM_ENET_CSR_RSIF_POLICER_REG5__ADDR,loop,ENET,port,display); // CM[31],CF[30], EIR
        eth_wr(SM_ENET_CSR_RSIF_POLICER_REG0__ADDR,loop|0x40000000|(clean<<9),ENET,port,display); // Address
        do {
            read_data = eth_rd(SM_ENET_CSR_RSIF_POLICER_REG0__ADDR,ENET,port,display) & 0xC0000000;
            counter++;
        } while (read_data != 0x00000000 && counter != 20);

        if(read_data) { printf("ERROR : Policer Programming timeout");printf("\n\r"); }
        else {          printf("Policer Programming done for Index : ");putnum(loop);printf("\n\r");}
    }  

    for(loop = 1; loop < 0xa; loop++) {
        eth_wr(SM_ENET_CSR_RSIF_POLICER_REG0__ADDR,loop|0x80000000,ENET,port,display); // Address
        do
        {
            read_data = eth_rd(SM_ENET_CSR_RSIF_POLICER_REG0__ADDR,ENET,port,display) & 0xC0000000;
            counter++;
        } while (read_data != 0x00000000 && counter != 20);

        if(read_data) { printf("ERROR : Policer Programming timeout");printf("\n\r"); }
        else {          printf("Policer Programming done for Index : ");putnum(loop);printf("\n\r");}
        eth_rd(SM_ENET_CSR_RSIF_POLICER_REG1__ADDR,ENET,port,display);
        eth_rd(SM_ENET_CSR_RSIF_POLICER_REG2__ADDR,ENET,port,display);
        eth_rd(SM_ENET_CSR_RSIF_POLICER_REG3__ADDR,ENET,port,display);
        eth_rd(SM_ENET_CSR_RSIF_POLICER_REG4__ADDR,ENET,port,display);
        eth_rd(SM_ENET_CSR_RSIF_POLICER_REG5__ADDR,ENET,port,display);
        eth_rd(SM_ENET_CSR_RSIF_POLICER_REG6__ADDR,ENET,port,display);
        eth_rd(SM_ENET_CSR_RSIF_POLICER_REG8__ADDR,ENET,port,display);
    }

}

// Policer Write Index
void enet_plc_wr(int index, int CIR, int CBS, int CM_CF_EIR, int EBS, int raw) {
    int counter = 0;
    int cmd_addr = 0x40000000 | index;
    int display = 0;
    int port = 0; //FIXME
    eth_wr(SM_ENET_CSR_RSIF_POLICER_REG1__ADDR,CBS,ENET,port,display); // CBS 
    eth_wr(SM_ENET_CSR_RSIF_POLICER_REG2__ADDR,CIR,ENET,port,display); // CIR
    // eth_wr(SM_ENET_CSR_RSIF_POLICER_REG3__ADDR,CCA,ENET,port,display); // CCA
    eth_wr(SM_ENET_CSR_RSIF_POLICER_REG4__ADDR,EBS,ENET,port,display); // EBS
    eth_wr(SM_ENET_CSR_RSIF_POLICER_REG5__ADDR,CM_CF_EIR,ENET,port,display); // CM[31],CF[30], EIR
    // eth_wr(SM_ENET_CSR_RSIF_POLICER_REG6__ADDR,0x40000000,ENET,port,display); // ECA
    //eth_wr(SM_ENET_CSR_RSIF_POLICER_REG0__ADDR,0x00000000,ENET,port,display); // Drop Count
    eth_wr(SM_ENET_CSR_RSIF_POLICER_REG0__ADDR,cmd_addr,ENET,port,display); // Address
    do
    {
        read_data = eth_rd(SM_ENET_CSR_RSIF_POLICER_REG0__ADDR,ENET,port,display) & 0xC0000000;
        counter++;
    } while (read_data != 0x00000000 && counter != 20);

    if(read_data) { printf("ERROR : Policer Programming timeout");printf("\n\r"); }
    else {          printf("Policer Programming done for Index : ");putnum(index);printf("\n\r");}

    if(raw)enet_plc_rd(index,1);// read all stat
}

// Policer Initialization
void init_enet_plc(int plc_mode) {
    int data = (0x02000F0F | (plc_mode << 28));
    int display = 0;
    int port = 0; //FIXME
    eth_wr(SM_ENET_CSR_RSIF_POLICER_REG7__ADDR, data,ENET,port,display); // Policer Enable - Dualbucket[31]
    printf("\n\r WR32 : [0x");putnum(SM_ENET_CSR_RSIF_POLICER_REG7__ADDR);printf("] <= 0x");putnum(data);printf("\n\r");
    printf("Policer  Enabled in mode : {dualbucket, priority(8), flowgroup(16), perflow(64)}");putnum(plc_mode);printf("\n\r");  
    if(cle_enable == 0){
        eth_wr(SM_ENET_CSR_CLE_BYPASS_REG3_0__ADDR, 0x20000000,ENET,port,display); // Policer
        eth_wr(SM_ENET_CSR_CLE_BYPASS_REG3_1__ADDR, 0x20000000,ENET,port,display); // Policer
    }
}
//------------------------------------------------
// Policer Function End
//------------------------------------------------

//-----------------------------------
// IEEE-1588 Related Functions
//-----------------------------------

void init_enet_ptp() {
    int display = 0;
    int port = 0; //FIXME
    eth_wr(SM_ENET_PTP_CSR_PTP_CONTROL__ADDR,0x20000000,ENET,port,display);         // Accumulator Bypass    : AXI :50Mhz  
    eth_wr(SM_ENET_PTP_CSR_PTP_CONTROL_SYSTIME__ADDR,0x00140000,ENET,port,display); // System Time Increment : 20ns
    eth_rd(SM_ENET_PTP_CSR_PTP_CONTROL__ADDR,ENET,port,display);         // Accumulator Bypass    : AXI :50Mhz  
    eth_rd(SM_ENET_PTP_CSR_PTP_CONTROL_SYSTIME__ADDR,ENET,port,display); // System Time Increment : 20ns

    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR, 0x8810000e,ENET,port,display);  // Bypass enable, Side-band : Header Length
    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_0__ADDR, 0x00000080,ENET,port,display); // Rx timestamp Enable
    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG5_0__ADDR, 0x0000e142,ENET,port,display); // Header Length
    eth_rd(SM_ENET_CSR_CLE_BYPASS_REG5_0__ADDR,ENET,port,display); // 
    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_0__ADDR, 0x00100003,ENET,port,display); // MSG Type, DT TS enable

    eth_wr(SM_ENET_CSR_DEBUG_REG__ADDR,0x003E03E6,ENET,port,display);      //Tx timestamp Enable

}
void ptp_read_stat() {
    int display = 1;
    int port = 0; //FIXME
    eth_rd(SM_ENET_PTP_CSR_PTP_SYSTEMTIME_STAT_LO__ADDR,ENET,port,display);  
    eth_rd(SM_ENET_PTP_CSR_PTP_SYSTEMTIME_STAT_MID__ADDR,ENET,port,display);  
    eth_rd(SM_ENET_PTP_CSR_PTP_SYSTEMTIME_STAT_HI__ADDR,ENET,port,display);  

    eth_rd(SM_ENET_CSR_PTP_TX_TMSTMP0_PRT0__ADDR,ENET,port,display);  
    eth_rd(SM_ENET_CSR_PTP_TX_TMSTMP1_PRT0__ADDR,ENET,port,display);  
}
void ptp_set_time() {
    int display = 0;
    int port = 0; //FIXME
    eth_rd(SM_ENET_PTP_CSR_PTP_SYSTEMTIME_STAT_LO__ADDR,ENET,port,display);  
    eth_rd(SM_ENET_PTP_CSR_PTP_SYSTEMTIME_STAT_MID__ADDR,ENET,port,display);  
    eth_rd(SM_ENET_PTP_CSR_PTP_SYSTEMTIME_STAT_HI__ADDR,ENET,port,display);  

    eth_rd(SM_ENET_CSR_PTP_TX_TMSTMP0_PRT0__ADDR,ENET,port,display);  
    eth_rd(SM_ENET_CSR_PTP_TX_TMSTMP1_PRT0__ADDR,ENET,port,display);  
}
//void ptp_write() {
//  eth_wr(SM_ENET_PTP_CSR_PTP_CONTROL_SYSTIME__ADDR,ENET,port,display); // System Time Increment : 20ns
//  eth_wr(,,ENET,port,display); // 
//  eth_wr(,,ENET,port,display); // 
//  eth_wr(,,ENET,port,display); // 
//
//}

//---------------------------------
// IEEE-1588 (PTP) Function End
//---------------------------------


//-----------------------------------
// CLE-Bypass Configuration Functions
//-----------------------------------
void read_cle_bypass() {
    int display = 1;
    int port = 0; //FIXME
    eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,ENET,port,display);
    eth_rd(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,ENET,port,display);
    eth_rd(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,ENET,port,display);
    eth_rd(SM_ENET_CSR_CLE_BYPASS_REG3_0__ADDR,ENET,port,display);
    eth_rd(SM_ENET_CSR_CLE_BYPASS_REG4_0__ADDR,ENET,port,display);
    eth_rd(SM_ENET_CSR_CLE_BYPASS_REG5_0__ADDR,ENET,port,display);
    eth_rd(SM_ENET_CSR_CLE_BYPASS_REG6_0__ADDR,ENET,port,display);
    eth_rd(SM_ENET_CSR_CLE_BYPASS_REG7_0__ADDR,ENET,port,display);
    eth_rd(SM_ENET_CSR_CLE_BYPASS_REG8_0__ADDR,ENET,port,display);
}
void set_hinfo(){
    int temp = 0;
    if(ip_prot == 0) temp = 1;
    else temp = 0;
    hinfo_ml = 0; hinfo_mm = 0;
    hinfo_lm = (mtype << 12) | (crc_en << 3) | (vlan<<2) | (dt << 1)      | ts;
    hinfo_ll = (ip_ver << 25)| (temp<<24) | (tso<<23) | (chksum<<22) | (mss<<20) | (eth_hdr<<12) | (ip_hdr<<6) | ipprot_hdr;
    hinfo        = ((long long)mtype  << 44) | 
        ((long long)crc_en << 35) | 
        ((long long)vlan   << 34) | 
        ((long long)dt     << 33) | 
        ((long long)ts     << 32) |
        (ip_ver << 25) | 
        (temp   << 24) | 
        (tso    << 23) | 
        (chksum << 22) | 
        (mss    << 20) | 
        (eth_hdr<< 12) | 
        (ip_hdr << 6 ) | 
        ipprot_hdr;
    printf("\n\r hinfo_lsb ");putnum(hinfo);
    printf("\n\r hinfo_msb ");putnum(hinfo>>32);
    // printf("\n\r ip_ver  ");putnum(ip_ver);
    // printf("\n\r temp  ");putnum(temp);
    // printf("\n\r tso  ");putnum(tso);
    // printf("\n\r chksum  ");putnum(chksum);
    // printf("\n\r mss  ");putnum(mss);
    // printf("\n\r eth_hdr  ");putnum(eth_hdr);
    // printf("\n\r ip_hdr  ");putnum(ip_hdr);
    // printf("\n\r ipprot_hdr  ");putnum(ipprot_hdr);
    // printf("\n\r hinfo_ll  ");putnum(hinfo_ll);
    //printf("\n\r   ");putnum();

}
void set_cle_bypass_default() {
    // default Profile
    //-----------------
    // Pkt type:
    eth_hdr = 14; ip_ver =0; ip_prot = 3;  ip_hdr = 0; ipprot_hdr = 0; ip_frag = 0;chksum = 0;tso = 0;mss =0;
    // CLE param:
    cle_bypass = 1; cle_dly = 8; cle_drop = 0; cle_wol = 0; cle_in = 0;
    mirror = 0; stash = 0; hdr_split = 0; split_boundary = 0;
    // QM Loopback:
    dstqid0 = 0xc04; dstqid1 = 0xc05; henqnum = 0xc00; fpsel= 0; fpsel1 = 1; nxtfpsel = 0; hfpsel = 0; dr = 0; hr = 1;
    // Policer :
    plc_en = 0; plc_dbidx = 5; plc_perflow = 0; plc_priority = 0;plc_flowgroup = 0;
    // IEEE-1588(PTP):
    ptp_en = 0;
    // Hop Information :
    //       ----------------------------------------------------------------------------------------------
    // LSB : | 0001  | 0000_0000 | 0 0 0 0 | 00 0 0 | 0 0 0 0 | 0 0 00  | 0000_0000 | 0000_00   | 00_0000 |
    //       | MType | Reserved  | C V D T | SN F D | M I I P | T C MSS | Ethernet  | IP_Header | Prot_hdr|           
    //       |       |           | R L T S |    T T | S S P R | S H     | Header    |           |         |     
    //       |       |           | C A     |      L | E E   O | 0 K     |           |           |         |     
    //       |       |           |   N     |      S | C C V T |         |           |           |         |
    //       ----------------------------------------------------------------------------------------------
    // MSB : | 0000_0000   |                                                        |   00_0000_0000      |
    //       |             |   TimeStamp(30                                         |                     |   
    //       ----------------------------------------------------------------------------------------------
    mtype = 1; crc_en = 1; vlan =0; dt = 0; ts = 0; 
    set_hinfo();
}
void configure_cle_bypass() {
    int wr_data;
    int display = 0;
    int port = 0; //FIXME
    set_hinfo();
    wr_data = 
        FIELD_CLE_BYPASS_REG0_0_CFG_CLE_BYPASS_EN_WR(cle_bypass)		|	// 1
        FIELD_CLE_BYPASS_REG0_0_CFG_CLE_RESULT_DLYCNTR_WR(cle_dly)	        |	// 7
        FIELD_CLE_BYPASS_REG0_0_CFG_CLE_IP_FRAGMENT_WR(ip_frag)		|	// 1
        FIELD_CLE_BYPASS_REG0_0_CFG_CLE_IP_VERSION_WR(ip_ver)		|	// 1
        FIELD_CLE_BYPASS_REG0_0_CFG_CLE_IP_PROTOCOL_WR(ip_prot)		|	// 2
        FIELD_CLE_BYPASS_REG0_0_CFG_CLE_IP_HDR_LEN_WR(ip_hdr)		|	// 5
        FIELD_CLE_BYPASS_REG0_0_CFG_CLE_ETH_HDR_LEN_WR(eth_hdr);			// 7
    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,wr_data,ENET,port,display);
    wr_data = 
        FIELD_CLE_BYPASS_REG0_0_CFG_CLE_BYPASS_EN_WR(cle_bypass)		|	// 1
        FIELD_CLE_BYPASS_REG0_0_CFG_CLE_RESULT_DLYCNTR_WR(cle_dly + 2)	|	// 7
        FIELD_CLE_BYPASS_REG0_0_CFG_CLE_IP_FRAGMENT_WR(ip_frag)		|	// 1
        FIELD_CLE_BYPASS_REG0_0_CFG_CLE_IP_VERSION_WR(ip_ver)		|	// 1
        FIELD_CLE_BYPASS_REG0_0_CFG_CLE_IP_PROTOCOL_WR(ip_prot)		|	// 2
        FIELD_CLE_BYPASS_REG0_0_CFG_CLE_IP_HDR_LEN_WR(ip_hdr)		|	// 5
        FIELD_CLE_BYPASS_REG0_0_CFG_CLE_ETH_HDR_LEN_WR(eth_hdr);			// 7
    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR,wr_data,ENET,port,display);

    wr_data =
        FIELD_CLE_BYPASS_REG1_0_CFG_CLE_NXTFPSEL_WR(nxtfpsel)		|	//  4
        FIELD_CLE_BYPASS_REG1_0_CFG_CLE_FPSEL_WR(fpsel)			|	//  4
        FIELD_CLE_BYPASS_REG1_0_CFG_CLE_DSTQID_WR(dstqid0);		                // 12
    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,wr_data,ENET,port,display);
    wr_data =
        FIELD_CLE_BYPASS_REG1_0_CFG_CLE_NXTFPSEL_WR(nxtfpsel)		|	//  4
        FIELD_CLE_BYPASS_REG1_0_CFG_CLE_FPSEL_WR(fpsel1)			|	//  4
        FIELD_CLE_BYPASS_REG1_0_CFG_CLE_DSTQID_WR(dstqid1);		                // 12
    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,wr_data,ENET,port,display);

    wr_data =
        FIELD_CLE_BYPASS_REG2_0_CFG_CLE_MIRROR_NXTFPSEL_WR(nxtfpsel)	|	// 
        FIELD_CLE_BYPASS_REG2_0_CFG_CLE_MIRROR_FPSEL_WR(fpsel)		|	// 
        FIELD_CLE_BYPASS_REG2_0_CFG_CLE_MIRROR_DSTQID_WR(dstqid0);			// 
    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,wr_data,ENET,port,display);
    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR,wr_data,ENET,port,display);

    wr_data =
        FIELD_CLE_BYPASS_REG3_0_CFG_CLE_DBPOLICER_EN_WR(plc_en)		|	//  1
        FIELD_CLE_BYPASS_REG3_0_CFG_CLE_DBPOLICERID_WR(plc_dbidx)		|	// 10
        FIELD_CLE_BYPASS_REG3_0_CFG_CLE_PERFLOW_WR(plc_perflow)		|	//  6
        FIELD_CLE_BYPASS_REG3_0_CFG_CLE_FLOWGROUP_WR(plc_flowgroup)		|	//  4
        FIELD_CLE_BYPASS_REG3_0_CFG_CLE_PRIORITY_WR(plc_priority);			//  3
    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG3_0__ADDR,wr_data,ENET,port,display);
    wr_data =
        FIELD_CLE_BYPASS_REG3_0_CFG_CLE_DBPOLICER_EN_WR(plc_en)		|	//  1
        FIELD_CLE_BYPASS_REG3_0_CFG_CLE_DBPOLICERID_WR(plc_dbidx+1)		|	// 10
        FIELD_CLE_BYPASS_REG3_0_CFG_CLE_PERFLOW_WR(plc_perflow+1)		|	//  6
        FIELD_CLE_BYPASS_REG3_0_CFG_CLE_FLOWGROUP_WR(plc_flowgroup+1)		|	//  4
        FIELD_CLE_BYPASS_REG3_0_CFG_CLE_PRIORITY_WR(plc_priority+1);			//  3
    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG3_1__ADDR,wr_data,ENET,port,display);
    wr_data =
        FIELD_CLE_BYPASS_REG4_0_CFG_CLE_SPLIT_BOUNDARY_WR(split_boundary)	|	// 
        FIELD_CLE_BYPASS_REG4_0_CFG_CLE_INSERT_TIMESTAMP_WR(ptp_en)	|	// 
        FIELD_CLE_BYPASS_REG4_0_CFG_CLE_MIRROR_WR(mirror)		|	// 
        FIELD_CLE_BYPASS_REG4_0_CFG_CLE_STASH_WR(stash)			|	// 
        FIELD_CLE_BYPASS_REG4_0_CFG_CLE_IN_WR(cle_in)			|	// 
        FIELD_CLE_BYPASS_REG4_0_CFG_CLE_WOL_MODE_WR(cle_wol)		|	// 
        FIELD_CLE_BYPASS_REG4_0_CFG_CLE_HDR_DATA_SPLIT_WR(hdr_split)	|	// 
        FIELD_CLE_BYPASS_REG4_0_CFG_CLE_DROP_WR(cle_drop);				//
    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_0__ADDR,wr_data,ENET,port,display);
    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_1__ADDR,wr_data,ENET,port,display);

    wr_data =
        FIELD_CLE_BYPASS_REG5_0_CFG_CLE_HOPINFOLSBS_LSBS_WR(hinfo_ll) ;		//
    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG5_0__ADDR,wr_data,ENET,port,display);
    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG5_1__ADDR,wr_data,ENET,port,display);
    wr_data =
        FIELD_CLE_BYPASS_REG6_0_CFG_CLE_DR_WR(dr)			|	//
        FIELD_CLE_BYPASS_REG6_0_CFG_CLE_HR_WR(hr)			|	//
        FIELD_CLE_BYPASS_REG6_0_CFG_CLE_HFPSEL_WR(hfpsel)		|	//
        FIELD_CLE_BYPASS_REG6_0_CFG_CLE_HOPINFOLSBS_MSBS_WR(hinfo_lm) ;		//
    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_0__ADDR,wr_data,ENET,port,display);
    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_1__ADDR,wr_data,ENET,port,display);
    wr_data =
        FIELD_CLE_BYPASS_REG7_0_CFG_CLE_HOPINFOMSBS_LSBS_WR(hinfo_ml) ;		//
    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_0__ADDR,wr_data,ENET,port,display);
    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_1__ADDR,wr_data,ENET,port,display);
    wr_data =
        FIELD_CLE_BYPASS_REG8_0_CFG_CLE_HENQNUM_WR(henqnum)		|	//
        FIELD_CLE_BYPASS_REG8_0_CFG_CLE_HOPINFOMSBS_MSBS_WR(hinfo_mm) ;		//
    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_0__ADDR,wr_data,ENET,port,display);
    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_1__ADDR,wr_data,ENET,port,display);

    // Read Registers
    //read_cle_bypass();
}
void compare_cle_bypass() {
    read_cle_bypass();
    set_cle_bypass_default();
    configure_cle_bypass();
    read_cle_bypass();
}
void set_test_profile() {
    int input;
    int display = 0;
    int port = 0; //FIXME
    set_cle_bypass_default();
    printf("\n\r Choose Test Profile  :\n\r");      

    printf("0  : MAC Packet   \n\r");
    printf("1  : IPv4 Packets \n\r");      
    printf("2  : IPv4 TCP     \n\r");      
    printf("3  : IPv4 UDP     \n\r");      
    printf("4  : IPv6 Packets \n\r");      
    printf("5  : IPv6 TCP     \n\r");      
    printf("6  : IPv6 UDP     \n\r");
    printf("7  : IPv4 Fragment\n\r");      
    printf("8  : IPv6 Fragment\n\r");printf("\n\r"); // Advanced MSS

    printf("Choose Pkt Type : ");
    input = get_val();
    switch(input)
    {
        case 0 : eth_hdr = 14; ip_ver =0; ip_prot = 3;  ip_hdr =  0; ipprot_hdr = 0; ip_frag = 0;chksum = 0;break;
        case 1 : eth_hdr = 14; ip_ver =0; ip_prot = 3;  ip_hdr =  5; ipprot_hdr = 0; ip_frag = 0;chksum = 1;break;
        case 2 : eth_hdr = 14; ip_ver =0; ip_prot = 0;  ip_hdr =  5; ipprot_hdr = 5; ip_frag = 0;chksum = 1;break;
        case 3 : eth_hdr = 14; ip_ver =0; ip_prot = 1;  ip_hdr =  5; ipprot_hdr = 2; ip_frag = 0;chksum = 1;break;
        case 4 : eth_hdr = 14; ip_ver =1; ip_prot = 3;  ip_hdr = 10; ipprot_hdr = 0; ip_frag = 0;chksum = 1;break;
        case 5 : eth_hdr = 14; ip_ver =1; ip_prot = 0;  ip_hdr = 10; ipprot_hdr = 5; ip_frag = 0;chksum = 1;break;
        case 6 : eth_hdr = 14; ip_ver =1; ip_prot = 1;  ip_hdr = 10; ipprot_hdr = 2; ip_frag = 0;chksum = 1;break;
        case 7 : eth_hdr = 14; ip_ver =0; ip_prot = 1;  ip_hdr =  5; ipprot_hdr = 5; ip_frag = 1;chksum = 0;break; // Advanced Enable checkumon Tx side
        case 8 : eth_hdr = 14; ip_ver =1; ip_prot = 0;  ip_hdr = 10; ipprot_hdr = 2; ip_frag = 1;chksum = 0;break; // Advanced Enable checkumon Tx side 
    }

    printf("\n\r");
    printf("Choose Feature    \n\r");
    printf("0  : Generic      \n\r");
    if(ip_prot == 0)
        printf("1  : TSO        \n\r");
    printf("2  : Policer      \n\r");
    printf("3  : PTP          \n\r");printf("\n\r");

    input = get_val();
    switch(input)    
    {
        case 0 : break;
        case 1 : tso = 1;mss =0;crc_en = 1;break;// Advanced Choose different MSS
        case 2 : /*DUMMY*/break;
                          // Policer :
                          plc_en = 1; plc_dbidx = 5; plc_perflow = 0; plc_priority = 0;plc_flowgroup = 0;
        case 3 : /*DUMMY*/break;
                          // IEEE-1588(PTP):
                          ptp_en = 1;dt = 1; ts = 1; mtype = 0;
    }
    // CLE param:
    // cle_bypass = 1; cle_dly = 8; cle_drop = 0; cle_wol = 0; cle_in = 0;
    // mirror = 0; stash = 0; hdr_split = 0; split_boundary = 0;
    // crc_en = 0; vlan = 0;

    configure_cle_bypass();
    eth_wr(SM_ENET_MAC_CSR_ICM_CONFIG3_REG_0__ADDR,crc_en,ENET,port,display); // crc_strip for port0
    eth_wr(SM_ENET_MAC_CSR_ICM_CONFIG3_REG_1__ADDR,crc_en,ENET,port,display); // crc_strip for port1
}
// CLE-Bypass Configuration End
//-----------------------------------

void enet_init_ecc(int port, int display) {
    uint32_t rd_data;
    int i;

    eth_wr(SM_GLBL_DIAG_CSR_CFG_MEM_RAM_SHUTDOWN__ADDR, 0x0,ENET,port,display);
    rd_data = eth_rd(SM_GLBL_DIAG_CSR_CFG_MEM_RAM_SHUTDOWN__ADDR,ENET,port,display);
    //printf("SM_GLBL_DIAG_CSR_CFG_MEM_RAM_SHUTDOWN = 0x%x\n", rd_data);

    rd_data = eth_rd(SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY__ADDR,ENET,port,display);
    while (rd_data != 0xFFFFFFFF) {
        rd_data = eth_rd(SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY__ADDR,ENET,port,display);
    }

    for (i = 0; i < 5; i++) {
        rd_data = eth_rd(SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY__ADDR,ENET,port,display);
    }
}

//Storm_ENET_r1.1: section 5, 
//  4: Dessert Serdes reset
//  5: Program Serdes
//  6: Assert Clock enables
//  7: Deassert CSR reset
//  8: Deassert Block reset
void init_enet_serdes(int inst, int refclk) {
    int loop = 30;
    int pll_ready;
    int vco_fail;
    int port;

    do {
        serdes_pdown_force_vco(inst,0); // FIXME

        pll_ready = sm_enet_module_init_enet_serdes(inst, refclk,tx2rx_serdes_lb_1g);
        //delay(10);
        USDELAY(10);
        if(pll_manualcal == 0) {
            vco_fail = vco_status(inst,0x0) >> 3;
            //printf("\nVCO Calibration Result (1=FAIL, 0=PASS): 0x%x :loop:%x\n\r",vco_fail,loop);
        }
        else  
            vco_fail = 0;

        if(loop)loop--; 

        //if(pll_manualcal == 0)
        //    printf("\n\r PLL Config %s : Number of PLL iteration : %d\n\r", vco_fail ? "FAILED":"SUCCESS", 30 - loop);
    } while(vco_fail);

    port = inst;
    gen_avg_val_1g(port);
    // serdes_reset_rxd(port,0);
    port = inst | 0x1;
    gen_avg_val_1g(port);
    // serdes_reset_rxd(port,0);
    //delay(10);
    USDELAY(10);
}


void enet_clkcfg_1(int port, int display){
    eth_wr(SM_ENET_CLKRST_CSR_ENET_CLKEN__ADDR,0x00000000,ENET,port,display); 
    eth_wr(SM_ENET_CLKRST_CSR_ENET_SRST__ADDR ,0xFFFFFFFF,ENET,port,display); 
    //delay(10);
    USDELAY(10);

    eth_wr(SM_ENET_CLKRST_CSR_ENET_CLKEN__ADDR,0xFFFFFFFF,ENET,port,display); 
    //delay(10);
    USDELAY(10);
    eth_wr(SM_ENET_CLKRST_CSR_ENET_SRST__ADDR ,0x00000002,ENET,port,display); 
    //delay(10);
    USDELAY(10);
}
void enet_clkcfg_2(int port, int display){
    //delay(10);
    USDELAY(10);
    eth_wr(SM_ENET_CLKRST_CSR_ENET_SRST__ADDR ,0x00000000,ENET,port,display); 

    enet_init_ecc(port, display);
}

void enet_basic(int intf, int display) {
    int lpbk_dat;
    int port;
    port = intf;
    eth_wr(SM_ENET_CSR_CFG_BYPASS__ADDR,0x00000001,ENET,port,display);

    if (loopback == 0) { eth_wr(SM_ENET_CSR_DEBUG_REG__ADDR,0x003e03fe,ENET,port,display);}    //Rx-Tx buffer loopback
    else               { eth_wr(SM_ENET_CSR_DEBUG_REG__ADDR,0x003E03EE,ENET,port,display);}    //QM Loopback
    lpbk_dat = eth_rd(SM_ENET_CSR_DEBUG_REG__ADDR,ENET,port,display);
    // printf("LOOPBACK REG read back"); printf(" is 0x");  putnum(lpbk_dat);  printf("\n\r");

    //port 0 cfg
    port = intf;
    mcxmac_ind_wr(0x00000000,0x00000035, ENET,port, 0);                              // Mac out of Reset
    // Bring the SGMII core out of reset. It comes out in non-autoneg mode
    mdio_wr(0x00001e11,0,ENET,port,display);
    //  eth_wr(SM_ENET_MAC_CSR_RX_DV_GATE_REG_0__ADDR,0x00000001,ENET,port,1);
    //  eth_wr(SM_ENET_CSR_CFG_LINK_AGGR_RESUME_0__ADDR,0x00000001,ENET,port,1);

    // md: port-0 for Jumbo packet size    
    //mcxmac_ind_wr(0x00000004,0x00007135,ENET,port, 0);            
    mcxmac_ind_wr(0x00000004,0x00005231,ENET,port, 0);            
    //mcxmac_ind_wr(0x00000004,0x00005235,ENET,port, 0);            //pad_crc enable
    mcxmac_ind_wr(0x00000020,0x00002580,ENET,port, 0);           
    // for Jumbo packet size

    //port 1 cfg
    port = intf | 0x1;
    mcxmac_ind_wr(0x00000000,0x00000035,ENET,port, 0);                                  // Mac out of Reset
    // Bring the SGMII core out of reset. It comes out in non-autoneg mode
    mdio_wr(0x00001e11,0,ENET,port,display);
    //  eth_wr(SM_ENET_MAC_CSR_RX_DV_GATE_REG_1__ADDR,0x00000001,ENET,port,1);
    //  eth_wr(SM_ENET_CSR_CFG_LINK_AGGR_RESUME_1__ADDR,0x00000001,ENET,port,1);
    // md: port-1 for Jumbo packet size    
    //mcxmac_ind_wr(0x00000004,0x00007135,ENET,port, 0);            
    mcxmac_ind_wr(0x00000004,0x00005231,ENET,port, 0);            
    //mcxmac_ind_wr(0x00000004,0x00005235,ENET,port, 0);            //pad_crc enable
    mcxmac_ind_wr(0x00000020,0x00002580,ENET,port, 0);           
    // for Jumbo packet size

    port = intf;

    eth_wr(SM_ENET_CSR_RSIF_CONFIG_REG__ADDR,0xff010044,ENET,port,display);

    if (cle_enable == 0) {
        unsigned int read_data;

#if 0 // md: QM level loopback test
        if(port == 0) { //Port-0/1    
            // Port-0  
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR, 0xa000050e,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR, 0xa000000e,ENET,port,display);
            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,ENET,port,display);
            printf("\r\nport:%d SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR, 0x00110420,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR, 0x00110420,ENET,port,display);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,read_data);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,read_data);

            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR, 0x00000c05,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG3_0__ADDR, 0x20000000,ENET,port,display); // Policer
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_0__ADDR, 0x00000040,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG5_0__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_0__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_0__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_0__ADDR, 0x0c000000,ENET,port,display);

            //Port-1  
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR, 0xa000050e,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR, 0xa000000e,ENET,port,display);
            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR,ENET,port,display);
            printf("\r\nport:%d SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR, 0x00110421,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR, 0x00110421,ENET,port,display);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,read_data);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR,read_data);

            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR, 0x00000c05,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG3_1__ADDR, 0x20000000,ENET,port,display); // Policer
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_1__ADDR, 0x00000040,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG5_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_1__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_1__ADDR, 0x0c000000,ENET,port,display);

            eth_wr(SM_ENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,ENET,port,display);
            eth_wr(SM_ENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,ENET,port,display);         
        }
        if(port == 2) { //Port-2/3    
            // Port-2  
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR, 0xa000050e,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR, 0xa000000e,ENET,port,display);
            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,ENET,port,display);
            printf("\r\nport:%d SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR, 0x00110422,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR, 0x00110422,ENET,port,display);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,read_data);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,read_data);

            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR, 0x00000c05,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG3_0__ADDR, 0x20000000,ENET,port,display); // Policer
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_0__ADDR, 0x00000040,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG5_0__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_0__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_0__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_0__ADDR, 0x0c000000,ENET,port,display);

            //Port-3  
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR, 0xa000050e,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR, 0xa000000e,ENET,port,display);
            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR,ENET,port,display);
            printf("\r\nport:%d SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR, 0x00110423,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR, 0x00110423,ENET,port,display);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,read_data);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR,read_data);

            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR, 0x00000c05,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG3_1__ADDR, 0x20000000,ENET,port,display); // Policer
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_1__ADDR, 0x00000040,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG5_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_1__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_1__ADDR, 0x0c000000,ENET,port,display);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_1__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_1__ADDR, 0x0c000000,ENET,port,display);

            eth_wr(SM_ENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,ENET,port,display);
            eth_wr(SM_ENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,ENET,port,display);         
        }
#endif // md: QM-level-lpbk-test

#if 1 // md: CPU level loopback test
        if(port == 0) { //Port-0/1    
            // Port-0  
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR, 0xa000000e,ENET,port,display);
            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,ENET,port,display);
            lprintf(8, "\r\nport:%d SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR, 0x00000440,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR, 0x00000440,ENET,port,display);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,ENET,port,display);
            lprintf(8, "port:%d SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,read_data);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,ENET,port,display);
            lprintf(8, "port:%d SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,read_data);

            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR, 0x00000c05,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG3_0__ADDR, 0x20000000,ENET,port,display); // Policer
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_0__ADDR, 0x00000040,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG5_0__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_0__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_0__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_0__ADDR, 0x0c000000,ENET,port,display);

            //Port-1  
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR, 0xa000000e,ENET,port,display);
            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR,ENET,port,display);
            lprintf(8, "\r\nport:%d SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR, 0x00110441,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR, 0x00110441,ENET,port,display);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,ENET,port,display);
            lprintf(8, "port:%d SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,read_data);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR,ENET,port,display);
            lprintf(8, "port:%d SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR,read_data);

            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR, 0x00000c05,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG3_1__ADDR, 0x20000000,ENET,port,display); // Policer
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_1__ADDR, 0x00000040,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG5_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_1__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_1__ADDR, 0x0c000000,ENET,port,display);

            eth_wr(SM_ENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,ENET,port,display);
            eth_wr(SM_ENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,ENET,port,display);         
        }
        if(port == 2) { //Port-2/3    
            // Port-2  
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR, 0xa000000e,ENET,port,display);
            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,ENET,port,display);
            lprintf(8, "\r\nport:%d SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR, 0x00220442,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR, 0x00220442,ENET,port,display);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,ENET,port,display);
            lprintf(8, "port:%d SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,read_data);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,ENET,port,display);
            lprintf(8, "port:%d SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,read_data);

            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR, 0x00000c05,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG3_0__ADDR, 0x20000000,ENET,port,display); // Policer
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_0__ADDR, 0x00000040,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG5_0__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_0__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_0__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_0__ADDR, 0x0c000000,ENET,port,display);

            //Port-3  
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR, 0xa000000e,ENET,port,display);
            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR,ENET,port,display);
            lprintf(8, "\r\nport:%d SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR, 0x00330443,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR, 0x00330443,ENET,port,display);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,ENET,port,display);
            lprintf(8, "port:%d SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,read_data);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR,ENET,port,display);
            lprintf(8, "port:%d SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR,read_data);

            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR, 0x00000c05,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG3_1__ADDR, 0x20000000,ENET,port,display); // Policer
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_1__ADDR, 0x00000040,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG5_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_1__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_1__ADDR, 0x0c000000,ENET,port,display);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_1__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_1__ADDR, 0x0c000000,ENET,port,display);

            eth_wr(SM_ENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,ENET,port,display);
            eth_wr(SM_ENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,ENET,port,display);         
        }
#endif // CPU-level-lpbk-test

#if 0 // md: Snake-test
        if(port == 0) { //Port-0/1    
            // Port-0  
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR, 0xa000050e,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR, 0xa000000e,ENET,port,display);
            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,ENET,port,display);
            printf("\r\nport:%d SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR, 0x00110421,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR, 0x00110421,ENET,port,display);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,read_data);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,read_data);

            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR, 0x00000c05,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG3_0__ADDR, 0x20000000,ENET,port,display); // Policer
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_0__ADDR, 0x00000040,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG5_0__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_0__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_0__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_0__ADDR, 0x0c000000,ENET,port,display);

            //Port-1  
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR, 0xa000050e,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR, 0xa000000e,ENET,port,display);
            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR,ENET,port,display);
            printf("\r\nport:%d SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR, 0x00110422,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR, 0x00110422,ENET,port,display);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,read_data);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR,read_data);

            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR, 0x00000c05,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG3_1__ADDR, 0x20000000,ENET,port,display); // Policer
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_1__ADDR, 0x00000040,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG5_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_1__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_1__ADDR, 0x0c000000,ENET,port,display);

            eth_wr(SM_ENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,ENET,port,display);
            eth_wr(SM_ENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,ENET,port,display);         
        }
        if(port == 2) { //Port-2/3    
            // Port-2  
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR, 0xa000050e,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR, 0xa000000e,ENET,port,display);
            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,ENET,port,display);
            printf("\r\nport:%d SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR, 0x00110423,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR, 0x00110423,ENET,port,display);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,read_data);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,read_data);

            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR, 0x00000c05,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG3_0__ADDR, 0x20000000,ENET,port,display); // Policer
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_0__ADDR, 0x00000040,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG5_0__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_0__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_0__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_0__ADDR, 0x0c000000,ENET,port,display);

            //Port-3  
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR, 0xa000050e,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR, 0xa000000e,ENET,port,display);
            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR,ENET,port,display);
            printf("\r\nport:%d SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR, 0x00110420,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR, 0x00110420,ENET,port,display);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,read_data);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR,read_data);

            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR, 0x00000c05,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG3_1__ADDR, 0x20000000,ENET,port,display); // Policer
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_1__ADDR, 0x00000040,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG5_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_1__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_1__ADDR, 0x0c000000,ENET,port,display);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_1__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_1__ADDR, 0x0c000000,ENET,port,display);

            eth_wr(SM_ENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,ENET,port,display);
            eth_wr(SM_ENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,ENET,port,display);         
        }
#endif // snake test
    }

    // eth_wr(SM_ENET_CSR_RSIF_CONFIG_REG__ADDR, 0x7f210044,ENET,port,display); // dont wait for wr resp

    // cfg to enable capture of Rx cntrl wd's
    eth_wr(SM_ENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,ENET,port,display);
    eth_wr(SM_ENET_CSR_CFG_CAPTURE_ECM_CTRLWD_0__ADDR, 0x1,ENET,port,display);

    //eth_wr(SM_GLBL_DIAG_CSR_CFG_DIAG_SEL__ADDR, 0x916,ENET,port,display);
    //eth_wr(SM_GLBL_DIAG_CSR_CFG_DIAG_SEL__ADDR, 0x20,ENET,port,display);

    //eth_wr(0x0000d000,0x000008D2,ENET,port,display); // CFG_DIAG_SEL For bringing rx_dv at the i/p of mac on the dbg bus
    //eth_wr(0x0000d000,0x00000902,ENET,port,display); // CFG_DIAG_SEL For bringing dbg_rfn0 of pemcxmac 
    //eth_wr(0x0000d000,0x000008da,ENET,port,display); // CFG_DIAG_SEL For bringing icm_idh of pemcxmac 
    //eth_wr(0x0000d000,0x000008df,ENET,port,display); // CFG_DIAG_SEL For bringing infoctrl of pemcxmac 
    //eth_wr(SM_GLBL_DIAG_CSR_CFG_DIAG_SEL__ADDR,0x00000916,ENET,port,display); // CFG_DIAG_SEL For bringing PEANX of SGMII-Core

    //          eth_wr(SM_ENET_CSR_AVB_PER_Q_CONFIG1_0__ADDR,0x55555555,ENET,port,display);//arb_type  
    //          //eth_wr(SM_ENET_CSR_AVB_PER_Q_CONFIG1_1__ADDR,0x55555555,ENET,port,display);//arb_type
    //          eth_wr(SM_ENET_CSR_AVB_COMMON_CONFIG1_0__ADDR,0x10000000,ENET,port,display);//mac_speed 
    //          //eth_wr(SM_ENET_CSR_AVB_COMMON_CONFIG1_1__ADDR,0x10000000,ENET,port,display);//mac_speed
    //          eth_wr(SM_ENET_CSR_AVB_COMMON_CONFIG2_0__ADDR,0x2000000a,ENET,port,display);//mac_speed 
    //          //eth_wr(SM_ENET_CSR_AVB_COMMON_CONFIG2_1__ADDR,0x2000000a,ENET,port,display);//mac_speed
    //	  eth_wr(SM_ENET_CSR_AVB_PER_Q_IDLE_SLOPE0_0__ADDR,0x00000001,ENET,port,display);
    //	  //eth_wr(SM_ENET_CSR_AVB_PER_Q_IDLE_SLOPE0_1__ADDR,0x00000001,ENET,port,display);


    // Disable Completion messages
    eth_wr(SM_ENET_CSR_TSIF_CONFIG_REG_0__ADDR, 0x00004888,ENET,port,display); 
    eth_wr(SM_ENET_CSR_TSIF_CONFIG_REG_1__ADDR, 0x00004888,ENET,port,display); 

}

void init_enet(int inst) {
    int port;

    enet_clkcfg_1(inst,0); // Common for port0/1
    // refclk = 0 - External differential clk
    // refclk = 1 - Internal single ended (cmos) clk
    // refclk = 2 - Internal differential clk

    if(clk_mode_1g == 0) {
        printf("\nSATA-SGMII Inst-%d is Configured in External Clock Mode.\n",inst);
        init_enet_serdes(inst, 0); 
    }
    else if(clk_mode_1g == 1) { //md: Internal-Single-Ended-Clock-Mode
        printf("\nSATA-SGMII Inst-%d is Configured in Internal Clock Mode.\n",inst);
        init_enet_serdes(inst, 1);  
    }

    //init_enet_serdes(inst, 0); 

    enet_clkcfg_2(inst,0); // Common for port0/1
    enet_basic(inst,0);

    //printf("programming SGMII PCS in autoneg\n\r");
    port = inst + 0x0;
    configure_sgmii(port,0x0, 1); // Single iteration
    port = inst + 0x1;
    configure_sgmii(port,0x0, 1);
}
/*
   void enable_an(){
   int port;
   int display = 0;
   int delay;

   an_en_1g = 1;

   for(port =FIRST_PORT; port <= LAST_PORT ; port++) {
   mdio_wr(0x1e00,0x9140,ENET,port,display);
   }
   for(delay=0;delay<10000;delay++);
   link_status();
   }
   void disable_an(){
   int port;
   int display = 0;
   int delay;

   an_en_1g = 0;

   for(port =FIRST_PORT; port <= LAST_PORT ; port++) {
   mdio_wr(0x1e00,0x8140,ENET,port,display);
   }
   for(delay=0;delay<10000;delay++);
   link_status();
   }
   */


int configure_sgmii(int port, int display, int reconfig_count){
    int link, an_comp, an_done = 0;
    int pass_cnt = 0;
    itr_count[port] = 0;
    if(an_en_1g) 
        mdio_wr(0x1e00,0x9140,ENET,port,display); // AutoNeg Mode
    else
        mdio_wr(0x1e00,0x8140,ENET,port,display); // Non AutoNeg Mode


    // delay(100);
    int loop = 100;
    int ext_link,speed;
    int loop_var = 0;
    link =0;
    an_done = 0;
    do {
        link, an_done = 0;
        read_data = mdio_rd(0x1e01,ENET,port,display);
        link    = (read_data >> 2) & 0x1;
        an_comp = (read_data >> 5) & 0x1;
        loop_var = an_en_1g ? an_comp : link;
        if(loop_var) {
            pass_cnt++;
            if(display) printf("?");
            an_done = (pass_cnt == 1000);
        }
        else {
            pass_cnt = 0;
            loop--;
        }
        //delay(10);
        USDELAY(10);
    }while(((loop != 0) && (an_done == 0) && (pass_cnt == 0)) || ((pass_cnt != 0 ) && (an_done == 0)));

    read_data = mdio_rd(0x1e05,ENET,port,display);
    ext_link = (read_data >> 15) & 0x1;

    if(tx2rx_serdes_lb_1g == 0 && an_en_1g == 1)
        mac_mode_1g = (read_data >> 10) & 0x3;

    if(display) {
        printf("Autonegotiation %s complete %s\n\r", an_done ? "" : "NOT",an_en_1g ? "" : " : NON-AUTONEG MODE");
        printf("Link Status : %s \n\r", link == 1 ? "UP" : "DOWN");
        if(an_en_1g) {
            printf(8, "Link Parameters : 0x%x \n\r", read_data);
            if(link == 1) printf("Speed = %x \n\r", mac_mode_1g);
        }
    }
    itr_count[port]++;

    if(display) {
        printf("\n\r---------------------------------------- \n\r");
        printf("\t Autonegotiation %s complete \n\r", an_done ? "" : "NOT");
        printf("\t Link Status Port%x: %s \n\r", port, link == 1 ? "UP" : "DOWN");
        printf("\t Link Parameters : 0x%x \n\r", read_data);
        printf("\t Speed = %s mbps\n\r", (mac_mode_1g == 2) ? "1000" : ((mac_mode_1g == 1) ? "100" : "10"));
        printf("---------------------------------------- \n\r");
    }
    if((an_en_1g == 1 && ext_link == 1) || // Auto neg - External link up
            (an_en_1g == 0 && link == 1) ||     // Non Auto - Internal link up , Poll for external link(by software not done here)
            (tx2rx_serdes_lb_1g == 1 && link == 1)){ //Tx2Rx loopback - Internal link up
        // printf("Configure MAC/SGMII as per new speed : %s mbps\n\r", (mac_mode_1g == 2) ? "1000" : ((mac_mode_1g == 1) ? "100" : "10"));
        if((port == 0) || (port == 2)) {
            enet_reg_wr_mode(port, 0x00002c00,0x0008503f,0x0004503f,0x0000503f);  //ICM_CONFIG0_REG_0 -- MacMode
            enet_reg_wr_mode(port, 0x00002c10,0x0000000f,0x0000000f,0x00010150);  // ICM_Config2_reg_0 -Async read  //AXI freq 	
            eth_wr(SM_ENET_CSR_CFG_LINK_AGGR_RESUME_0__ADDR,0x00000001,ENET,port,display);
            if(gating_bypass_1g)
                eth_wr(SM_ENET_MAC_CSR_RX_DV_GATE_REG_0__ADDR,0x0,ENET,port,display);
            else  
                eth_wr(SM_ENET_MAC_CSR_RX_DV_GATE_REG_0__ADDR,0x7,ENET,port,display);

        } else {
            enet_reg_wr_mode(port, 0x00002c08,0x0008503f,0x0004503f,0x0000503f);  //ICM_CONFIG0_REG_1 -- MacMode
            enet_reg_wr_mode(port, 0x00002c14,0x0000000f,0x0000000f,0x00010150);  // ICM_Config2_reg_0 -Async read  //AXI freq  => 50MHz
            eth_wr(SM_ENET_CSR_CFG_LINK_AGGR_RESUME_1__ADDR,0x00000001,ENET,port,display);
            if(gating_bypass_1g)
                eth_wr(SM_ENET_MAC_CSR_RX_DV_GATE_REG_1__ADDR,0x0,ENET,port,display);
            else  
                eth_wr(SM_ENET_MAC_CSR_RX_DV_GATE_REG_1__ADDR,0x7,ENET,port,display);
        }
        mac_ind_write_mode(port,0x00000004,0x00005231,0x00006131,0x00007111);   // Interface Mode - Nibble vs Byte
        //mac_ind_write_mode(port,0x00000004,0x00005235,0x00006131,0x00007111);   // Interface Mode - Nibble vs Byte // pad_crc enable 
        mac_ind_write_mode(port,0x00000038,0x04000000,0x02000000,0x00000000); // MAC mode - 1g,100m,10m
        eth_wr(SM_ENET_CSR_LINK_STS_INTR__ADDR,(0x1 << (port & 0x1)),ENET,port,0);
        //int data32;
        //data32 = mcxmac_ind_rd(ind_address,ENET,port,0);
        //data32 = FIELD_MAC_CONFIG_1_TX_EN_SET(data32,1);
        //data32 = FIELD_MAC_CONFIG_1_RX_EN_SET(data32,1);
        //mcxmac_ind_wr(PE_MCXMAC_MAC_CONFIG_1__ADDR,data32,ENET,port,0); 
    }
    return an_done;
}

void read_statistics(int port){
    int i,j;
    int display = 0;
    printf("\n\r MACOUT reg ");putnum(eth_rd(SM_ENET_CSR_MACOUT_ENET_STAT_REG_PORT0__ADDR,ENET,port,display));
    printf("\n\r MACIN reg ");putnum(  eth_rd(SM_ENET_CSR_MACIN_ENET_STAT_REG_PORT0__ADDR,ENET,port,display));
    printf("\n\r RXBIN reg ");putnum(  eth_rd(SM_ENET_CSR_RXBIN_ENET_STAT_REG_PORT0__ADDR,ENET,port,display));
    printf("\n\r Port0: RSIF CNTR reg ");putnum(  eth_rd(SM_ENET_CSR_RSIF_STS_CNTR_REG0__ADDR,ENET,port,display));
    printf("\n\r Port1: RSIF CNTR reg ");putnum(  eth_rd(SM_ENET_CSR_RSIF_STS_CNTR_REG1__ADDR,ENET,port,display));


    printf("\n\r Port0: RSIF STS CLE Drop CNTR reg0 ");putnum(  eth_rd(SM_ENET_CSR_RSIF_STS_CLE_DROP_CNTR_REG0__ADDR,ENET,port,display));
    printf("\n\r {Port1, Port0}: RSIF FP Timeout counter ");putnum(  eth_rd(SM_ENET_CSR_RSIF_FPBUFF_TIMEOUT_STSREG0__ADDR,ENET,port,display));
    printf("\n\r {Port1, Port0}: RSIF FP Partial drop Timeout counter ");putnum(  eth_rd(SM_ENET_CSR_RSIF_FPBUFF_TIMEOUT_PARTIALDROP_STSREG0__ADDR,ENET,port,display));
    printf("\n\r {Port1, Port0}: TSIF CNTR reg ");putnum(  eth_rd(SM_ENET_CSR_TSIF_STS_REG1__ADDR,ENET,port,display));
    printf("\n\r {Port1, Port0}: TSIF Dealloc message cntr reg ");putnum(  eth_rd(SM_ENET_CSR_TSIF_STS_REG2__ADDR,ENET,port,display));
    printf("\n\r {Port1, Port0}: TSIF Bad message cntr reg ");putnum(  eth_rd(SM_ENET_CSR_TSIF_STS_REG3__ADDR,ENET,port,display));

    printf("\n\r RX_TX_BUF_STS reg");putnum(  eth_rd(SM_ENET_CSR_RX_TX_BUF_STS_REG0__ADDR,ENET,port,display));
    printf("\n\r RSIF FIFO STS reg");putnum(  eth_rd(SM_ENET_CSR_RSIF_FIFO_EMPTYSTS0__ADDR,ENET,port,display));
    printf("\n\r TSIF FIFO STS reg");putnum(  eth_rd(SM_ENET_CSR_TSIF_FIFO_EMPTYSTS0__ADDR,ENET,port,display));
    printf("\n\r MAC FIFO STS reg");putnum(  eth_rd(SM_ENET_MAC_CSR_MAC_FIFO_STS_REG0__ADDR,ENET,port,display));
    printf("\n\r RX DV GATE reg0");putnum(  eth_rd(SM_ENET_MAC_CSR_RX_DV_GATE_REG_0__ADDR,ENET,port,display));
    printf("\n\r RX DV GATE reg1");putnum(  eth_rd(SM_ENET_MAC_CSR_RX_DV_GATE_REG_1__ADDR,ENET,port,display));
    printf("\n\r LINK STS SEL reg");putnum(  eth_rd(SM_ENET_CSR_CFG_LINK_STS_SEL__ADDR,ENET,port,display));
    printf("\n\r LINK AGGR RESUMEreg");putnum(  eth_rd(SM_ENET_CSR_CFG_LINK_AGGR_RESUME_0__ADDR,ENET,port,display));
    printf("\n\r LINK AGGR ");putnum(  eth_rd(SM_ENET_CSR_CFG_LINK_AGGR__ADDR,ENET,port,display));
    printf("\n\r LINK STATUS ");putnum(  eth_rd(SM_ENET_CSR_LINK_STATUS__ADDR,ENET,port,display));
    printf("\n\r CLKEN ");putnum(  eth_rd(SM_ENET_CLKRST_CSR_ENET_CLKEN__ADDR,ENET,port,display));
    printf("\n\r SRST ");putnum(  eth_rd(SM_ENET_CLKRST_CSR_ENET_SRST__ADDR,ENET,port,display));
    printf("\n\r CFG_BYPASS ");putnum(  eth_rd(SM_ENET_CSR_CFG_BYPASS__ADDR,ENET,port,display));
    printf("\n\r TXB STAT ");putnum(  eth_rd(SM_ENET_CSR_TXB_ENET_STAT_REG_PORT0__ADDR,ENET,port,display));
    printf("\n\r RGMII REG 0 ");putnum(  eth_rd(SM_ENET_CSR_RGMII_REG_0__ADDR,ENET,port,display));
    printf("\n\r ICM_ECM_DROP_COUNT_REG_0 ");putnum(  eth_rd(SM_ENET_MAC_CSR_ICM_ECM_DROP_COUNT_REG_0__ADDR,ENET,port,display));
    printf("\n\r ICM_ECM_DROP_COUNT_REG_1 ");putnum(  eth_rd(SM_ENET_MAC_CSR_ICM_ECM_DROP_COUNT_REG_1__ADDR,ENET,port,display));
    printf("\nTSIF/RSIF Interrupt Status Register Dumps:\n");
    printf("\n\r SM_ENET_CSR_RSIF_INT_REG0__ADDR ");putnum(  eth_rd(SM_ENET_CSR_RSIF_INT_REG0__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_RSIF_FINT_REG0__ADDR ");putnum(  eth_rd(SM_ENET_CSR_RSIF_FINT_REG0__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_RSIF_INT_REG1__ADDR ");putnum(  eth_rd(SM_ENET_CSR_RSIF_INT_REG1__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_RSIF_FINT_REG1__ADDR ");putnum(  eth_rd(SM_ENET_CSR_RSIF_FINT_REG1__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_RSIF_INT_REG0MASK__ADDR ");putnum(  eth_rd(SM_ENET_CSR_RSIF_INT_REG0MASK__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_RSIF_INT_REG1MASK__ADDR ");putnum(  eth_rd(SM_ENET_CSR_RSIF_INT_REG1MASK__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_RSIF_FINT_REG0MASK__ADDR ");putnum(  eth_rd(SM_ENET_CSR_RSIF_FINT_REG0MASK__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_RSIF_FINT_REG1MASK__ADDR ");putnum(  eth_rd(SM_ENET_CSR_RSIF_FINT_REG1MASK__ADDR,ENET,port,display));

    printf("\n\r SM_ENET_CSR_TSIF_INT_REG0__ADDR ");putnum(  eth_rd(SM_ENET_CSR_TSIF_INT_REG0__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_TSIF_FINT_REG0__ADDR ");putnum(  eth_rd(SM_ENET_CSR_TSIF_FINT_REG0__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_TSIF_INT_REG0MASK__ADDR ");putnum(  eth_rd(SM_ENET_CSR_TSIF_INT_REG0MASK__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_TSIF_INT_REG0__ADDR ");putnum(  eth_rd(SM_ENET_CSR_TSIF_INT_REG0__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_TSIF_FINT_REG0MASK__ADDR ");putnum(  eth_rd(SM_ENET_CSR_TSIF_FINT_REG0MASK__ADDR,ENET,port,display));

    printf("\n\r SM_ENET_CSR_TSIF_STS_REG0__ADDR ");putnum(  eth_rd(SM_ENET_CSR_TSIF_STS_REG0__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_TSIF_STS_REG1__ADDR ");putnum(  eth_rd(SM_ENET_CSR_TSIF_STS_REG1__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_TSIF_STS_REG2__ADDR ");putnum(  eth_rd(SM_ENET_CSR_TSIF_STS_REG2__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_TSIF_STS_REG3__ADDR ");putnum(  eth_rd(SM_ENET_CSR_TSIF_STS_REG3__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_RSIF_STS_REG0__ADDR ");putnum(  eth_rd(SM_ENET_CSR_RSIF_STS_REG0__ADDR,ENET,port,display));
    printf("\n");
    printf("\nQMI Interrupt Status Register Dumps:\n");

    /*
       printf("\n\n =====QM AXI BW monitor======");
       qm_reg_rd(SM_GLBL_DIAG_CSR_STS_AXI_MRD_BW_CLK_CNT__ADDR);//0xd024
       qm_reg_rd(SM_GLBL_DIAG_CSR_STS_AXI_MRD_BW_BYTE_CNT__ADDR);//0xd028
       qm_reg_rd(SM_GLBL_DIAG_CSR_STS_AXI_MWR_BW_CLK_CNT__ADDR);//0xd02c
       qm_reg_rd(SM_GLBL_DIAG_CSR_STS_AXI_MWR_BW_BYTE_CNT__ADDR);//0xd030
       qm_reg_rd(SM_GLBL_DIAG_CSR_STS_AXI_SRD_BW_CLK_CNT__ADDR);//0xd034
       qm_reg_rd(SM_GLBL_DIAG_CSR_STS_AXI_SRD_BW_BYTE_CNT__ADDR);//0xd038
       qm_reg_rd(SM_GLBL_DIAG_CSR_STS_AXI_SWR_BW_CLK_CNT__ADDR);//0xd03c
       */
    printf("\n\r SM_ENET_CSR_STS_ECM_SOF0_CNTRL_WORD_0__ADDR  ");putnum(eth_rd(SM_ENET_CSR_STS_ECM_SOF0_CNTRL_WORD_0__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_STS_ECM_SOF1_CNTRL_WORD_1__ADDR  ");putnum(eth_rd(SM_ENET_CSR_STS_ECM_SOF1_CNTRL_WORD_0__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_STS_ECM_SOF2_CNTRL_WORD_2__ADDR  ");putnum(eth_rd(SM_ENET_CSR_STS_ECM_SOF2_CNTRL_WORD_0__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_STS_ECM_SOF3_CNTRL_WORD_3__ADDR  ");putnum(eth_rd(SM_ENET_CSR_STS_ECM_SOF3_CNTRL_WORD_0__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_STS_ECM_EOF1_CNTRL_WORD_3__ADDR  ");putnum(eth_rd(SM_ENET_CSR_STS_ECM_EOF1_CNTRL_WORD_0__ADDR,ENET,port,display));


    pemstat1_addr_reg = enet_base_addr + SM_ENET_MACIP_IND_CSR_STAT_IND_ADDR_0__ADDR;
    pemstat1_cmd_reg  = enet_base_addr + SM_ENET_MACIP_IND_CSR_STAT_IND_COMMAND_0__ADDR;
    pemstat1_read_reg = enet_base_addr + SM_ENET_MACIP_IND_CSR_STAT_IND_RDATA_0__ADDR;
    pemstat1_stat_reg = enet_base_addr + SM_ENET_MACIP_IND_CSR_STAT_IND_COMMAND_DONE_0__ADDR;
    pemstat1_address  = 0x00000020;

    pemstat2_addr_reg = enet_base_addr + SM_ENET_MACIP_IND_CSR_STAT_IND_ADDR_1__ADDR;
    pemstat2_cmd_reg  =  enet_base_addr + SM_ENET_MACIP_IND_CSR_STAT_IND_COMMAND_1__ADDR;
    pemstat2_read_reg = enet_base_addr + SM_ENET_MACIP_IND_CSR_STAT_IND_RDATA_1__ADDR;
    pemstat2_stat_reg = enet_base_addr + SM_ENET_MACIP_IND_CSR_STAT_IND_COMMAND_DONE_1__ADDR;
    pemstat2_address  = 0x00000020;

    //port0 pemstat
    i = 0;
    printf("\r\nPort-0 Pemstats:\n\r");
    for (j=0; j<48; j++)
    {
        i = i + 1;
        mywrite(pemstat1_addr_reg,pemstat1_address + j);
        mywrite(pemstat1_cmd_reg,read_command);
        //		xil_printf("entered in pemstat 0 loop command written.. waiting for read");
        do
        {
            read_data = myread(pemstat1_stat_reg,0);
        } while (read_data != 0x00000001);
        mywrite(pemstat1_cmd_reg,0x00000000);
        read_data = myread(pemstat1_read_reg,0);
        printf("0x");putnum(pemstat1_address + j);printf(" = 0x");putnum(read_data);printf(" \t");

        if(i==4)
        {
            i = 0;
            printf("\n\r");
        }
    }

    //port1 pemstat
    i = 0;
    printf("\r\n Port-1 Pemstats:\n\r");
    for (j=0; j<48; j++)
    {
        i = i + 1;
        mywrite(pemstat2_addr_reg,pemstat2_address + j);
        mywrite(pemstat2_cmd_reg,read_command);
        //		xil_printf("entered in pemstat 0 loop command written.. waiting for read");
        do
        {
            read_data = myread(pemstat2_stat_reg,0);
        } while (read_data != 0x00000001);
        mywrite(pemstat2_cmd_reg,0x00000000);
        read_data = myread(pemstat2_read_reg,0);
        printf("0x");putnum(pemstat2_address + j);printf(" = 0x");putnum(read_data);printf(" \t");

        if(i==4)
        {
            i = 0;
            printf("\n\r");
        }
    }
}
//int enet_main()
int eth_tx2rx_1g()
{
    int test_dat = 0;
    int val = 0;
    int count = 0;
    int i = 0;
    int j=0;
    int enet_addr, rd_data,quit_r;
    int num_buffers = 1;
    unsigned int size1;
    unsigned int size;
    //msg_16b_t enq_msg[4];
    //msg_16b_t deq_msg[4];
    int fail_cnt = 0;
    int iter = 0;
    int it = 0;
    int drop_data = 0;
    int bypass_en = 0;
    int intr_stat = 0;
    int num_msg = 0;
    int ind_address =0;
    int ind_data = 0;
    int display = 0;
    int reg_1 , reg_2 , reg_3 , reg_4;

    total_err_count[0]=0;
    total_err_count[1]=0;
    total_err_count[2]=0;
    total_err_count[3]=0;


    lprintf(8, "\n*****************************************\n\r");
    lprintf(8, "******** SATA-SGMII Test Start ********\n\r");
    lprintf(8, "*****************************************\n\r");
    //ocm_init();

    lprintf(8, "\n\r\n\r\n\r-------------------------------\n\r");
    lprintf(8, "Configuring ENET ports 0 and 1 \n\r");
    lprintf(8, "-------------------------------\n\r");
    enet_base_addr = ENET_01_BASE_ADDR; // important - do not delete
    init_enet(0); // 0-ENET01
    lprintf(8, "\n\r\n\r\n\r-------------------------------\n\r");
    lprintf(8, "Configuring ENET ports 2 and 3 \n\r");
    lprintf(8,"-------------------------------\n\r");
    enet_base_addr = ENET_23_BASE_ADDR; // important - do not delete
    init_enet(2); // 2-ENET23
    //-----------------------------------
    // Print Final Link Status
    //-----------------------------------
    int port; //fixme
    int intf; //fixme
    link_status();
    vco_status(0x0,0x1);
    vco_status(0x2,0x1);

    menet_clkcfg();
    mgmt_mac_config();



#if 1 // md: QM-level-lpbk-test & CPU-level_lpbk-test
    unsigned int reg,tmp;

    // Debug only; 
    // HAck Disable LError //11/04/2013; Recomendation from Satish
#if 1
    lprintf(8, "\r\nHach HAck SATA Ports for the PAcket Drops!!!!!!! \r\n");
    lprintf(8, "Disable the LErrr from ENET\r\n");
    lprintf(8, "Before write\r\n");
    reg = 0x1f212098;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f222098;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);

    write((unsigned int *)(0x1f212098), 0x0); 
    write((unsigned int *)(0x1f222098), 0x0); 

    lprintf(8, "After write\r\n");
    reg = 0x1f212098;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f222098;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);
#endif

    lprintf(8, "\nUn Mask the RSIF & TSIF Interrupts\r\n");
    write((unsigned int *)(0x1f212058), 0x0); 
    write((unsigned int *)(0x1f212060), 0x0); 
    write((unsigned int *)(0x1f2120a0), 0x0); 
    write((unsigned int *)(0x1f2120a8), 0x0);
    write((unsigned int *)(0x1f212130), 0x0);
    write((unsigned int *)(0x1f212138), 0x0);

    write((unsigned int *)(0x1f222058), 0x0); 
    write((unsigned int *)(0x1f222060), 0x0); 
    write((unsigned int *)(0x1f2220a0), 0x0); 
    write((unsigned int *)(0x1f2220a8), 0x0); 
    write((unsigned int *)(0x1f222130), 0x0); 
    write((unsigned int *)(0x1f222138), 0x0); 

    lprintf(8, "\nUn Mask the QMI Interrupts\r\n");
    write((unsigned int *)(0x1f2190a0), 0x0); 
    write((unsigned int *)(0x1f2190a8), 0x0); 
    write((unsigned int *)(0x1f2190b0), 0x0); 
    write((unsigned int *)(0x1f2190b8), 0x0);
    write((unsigned int *)(0x1f2190c0), 0x0);

    write((unsigned int *)(0x1f2290a0), 0x0); 
    write((unsigned int *)(0x1f2290a8), 0x0); 
    write((unsigned int *)(0x1f2290b0), 0x0); 
    write((unsigned int *)(0x1f2290b8), 0x0);
    write((unsigned int *)(0x1f2290c0), 0x0);

    lprintf(8, "\r\nQMI Configuration for Port-2 & Port-3\r\n");
    lprintf(8, "Before write\r\n");
    reg = 0x1f2190dc;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f2190e0;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);

    reg = 0x1f2290dc;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f2290e0;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);

    reg = 0x1f2290f0;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);

    reg = 0x1f2290f4;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);

    write((unsigned int *)(0x1f2190dc), 0xffffffff); 
    write((unsigned int *)(0x1f2190e0), 0xffffffff); 
    //write((unsigned int *)(0x1f2190f0), 0xffffffff); 
    //write((unsigned int *)(0x1f2190f4), 0xffffffff); 

    write((unsigned int *)(0x1f2290dc), 0xffffffff);  // CfgSsQmiFPQAssoc
    write((unsigned int *)(0x1f2290e0), 0xffffffff);  // CfgSsQmiWQAssoc
    //write((unsigned int *)(0x1f2290f0), 0xffffffff);  // CfgSsQmiQMLiteWQAssoc
    //write((unsigned int *)(0x1f2290f4), 0xffffffff);  // CfgSsQmiQMLiteFPQAssoc

    lprintf(8, "\r\nAfter write\r\n");
    reg = 0x1f2190dc;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f2190e0;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);

    reg = 0x1f2290dc;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f2290e0;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);

    reg = 0x1f2290f0;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);

    reg = 0x1f2290f4;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);

    /*
       qm_enable => QM_QM0=1, QM_QM1=2, QM_QM2=4
       qm_ip => QM_ETH=0, QM_PDMA=1, QM_CTX=2, QM_SEC=3, QM_CLE0=4 QM_COP=5, QM_SLIMPRO=6
       */


    /*	//--ORIGINAL CODE -- 
        reg_1 = read(0x1f60c200); reg_2 = read(0x1f60c208); reg_3 = read(0x1f70c200); reg_4 = read(0x1f70c208);
        if(reg_1==0x3 && reg_2==0 && reg_3==0x3 && reg_4==0) {
        printf(8, "\nQM-0/1/2 Init\r\n");
        printf("\n entering qm_n from enet_main\n ");
        qm_n((QM_QM0 | QM_QM1 | QM_QM2), QM_ETH);//--ORIGINAL CODE --
    //qm_n((QM_QM1), QM_ETH);
    //qm_n_dump((QM_QM0 | QM_QM1 | QM_QM2), QM_ETH);
    }
    */

    qm_n( QM_QM1, QM_ETH);


#if 0 // md: CPU-level-lpbk-test
    /*
       qm_uc_fwder(u32 rpt, u32 batch, fwd_uc_tbl_t *p_uc);
       rpt   -> repeat counter for scanning the input queues
       batch -> batch counter for each input queue
       p_uc -> pointer to the unicast forwarding table

Application: 
This is GE Port CPU level self loopback
GE0_Rx -> GE0_Tx 
GE1_Rx -> GE1_Tx
GE2_Rx -> GE2_Tx
GE3_Rx -> GE3_Tx

fwd_uc_tbl_t fwd_ge4_tbl
*/
    fwd_ctrl_t fc;
    //unsigned int i;

    fc.rpt = 1;
    fc.batch = 1;
    fc.chk_errq = 0;
    fc.fwd_cb = NULL;
    printf("\r\nCPU level loopback, polling for qm_uc_fwder()\r\n");
    i = 0;

    /*
       printf("\ntemp for debug only; disabling work queues\n");
       reg = 0x1f219018;
       tmp = read32(reg);
       printf("\nBefore reg:0x%x tmp:0x%x\n",reg,tmp);
       write((unsigned int *)(0x1f219018), 0xffffffff); //temp for debug only; disabling work queues
       reg = 0x1f219018;
       tmp = read32(reg);
       printf("\nAfter reg:0x%x tmp:0x%x\n",reg,tmp);
       */

    while(1)
    {
        //qm_uc_fwder(&fc, &fwd_xge1_tbl);
        //qm_uc_fwder(&fc, &fwd_ge1_tbl);
        qm_uc_fwder(&fc, &fwd_ges_tbl);

#if 0
        //enqueue related call, no need to do this.
        if ((i & 0x1fffff) == 0)
        {
            //qm_dump_pb_state(2, 0, 0);
            //qm_dump_pb_state(2, 0, 0x21);

            enet_base_addr =  ENET_01_BASE_ADDR; 
            read_statistics(0x1);// Function Call to print all the Statistics

            printf("\r\n ---- QM1 queue statedump:\r\n"); :
                //qm_dump_pb_state(1, 0, 0);
                qm_dump_qstate(1, 4, 32);
            qm_dump_qstate(1, 4, 64);
            qm_dump_qstate(1, 1, 1);
            qm_dump_qstate(1, 1, QM_ERROR_QID);
            qm_dump_qstate(1, 1, QM_E_ERROR_QID);
            qm_dump_qm_errq(1);
            qm_err_dump(1);
            i = 0;

            /*reg = 0x1f219040;
              tmp = read32(reg);
              printf("\nreg:0x%x tmp:0x%x\r\n",reg,tmp);*/

        }
        i++;
#endif
    }
#endif // CPU-level-lpbk-test

#endif // QM-level-lpbk-test & CPU-level_lpbk-test

    write((unsigned int *)(0x17001398), 0x001e1e1e); //MDIO enable config
    //eth_wr(SM_ENET_CSR_DEBUG_REG__ADDR, 0x3e03fe,ENET,port,display); // Rx2Tx loopback

    lprintf(8, "QM initialization begins .... \n\r");

    //initialize_qm();
    lprintf(8, "Initialization for CLE begins .... \n\r");

    if (cle_enable == 1) {
        //cfg_cle();
    }

    lprintf(8,"*****************************************\n\r");
    lprintf(8,"******** SATA-SGMII Test Complete ********\n\r");
    lprintf(8,"*****************************************\n\r");

    eth_tx2rx_lpbk_test_sata_1g();
    total_err_count_result();	

    if(advanced_debug) {
        debug_1g();
    }
    //eth_tx2rx_lpbk_test_sata_1g();
    //	total_err_count_result();	

    return 0;
}


    void cfg_plc_index(int index,int green, int yellow,int raw) {
        switch ( green )
        {
            case 0x88 : plc_cir = 0xFFFFFFFF; // Infinite Credits
                        break; 

            default :
                        plc_cir = green * 0x00271;

        }

        switch ( yellow )
        {
            // case 1 : plc_eir = 0x0F424; // Normalized 100mbps
            //   break; 
            // case 2 : plc_eir = 0x0186a; // Normalized 10mbps
            //   break; 
            // case 3 : plc_eir = 0x00C35; // Normalized 5mbps
            //   break; 
            // case 4 : plc_eir = 0x004E2; // Normalized 2mbps
            //   break; 
            // case 5 : plc_eir = 0x00271; // Normalized 1mbps
            //   break; 
            case 0x88 : plc_eir = 0xFFFFFFFF; // Infinite Credits
                        break; 

            default :
                        plc_eir = 0x00271 * yellow;

        }

        if(plc_cir == 0)
            plc_cbs = 0x0;
        else if(plc_cir > 0x2580)
            plc_cbs = plc_cir;
        else
            plc_cbs = 0x2580;

        if(plc_eir == 0x0)
            plc_ebs = 0x0;
        else if(plc_eir > 0x2580)
            plc_ebs = plc_eir;
        else
            plc_ebs = 0x2580;

        plc_eir = plc_eir | (plc_cm << 31);
        plc_eir = plc_eir | (plc_cf << 30);
        enet_plc_wr(index,plc_cir,plc_cbs,plc_eir,plc_ebs,raw);


    }
/*
   void toggle_adv(){
   advanced_debug = advanced_debug^0x1;
   }

   void set_base(){
   enet_base_addr = my_get_val("select Instance 0-ENET01  2-ENET23") ? ENET_23_BASE_ADDR : ENET_01_BASE_ADDR;
   }

   void clkcfg(){
   int temp, intf, port;
   int display = 0;
   temp = my_get_val("select inst 0/2");
   intf = temp & 0x2;
   port = temp & 0x3;
   enet_base_addr =  intf ? ENET_23_BASE_ADDR : ENET_01_BASE_ADDR; // important - do not delete
   enet_clkcfg_1(intf, display);
   }

   void basic(){
   int temp, intf, port;
   int display = 0;
   temp = my_get_val("select inst 0/2");
   intf = temp & 0x2;
   port = temp & 0x3;
   enet_base_addr =  intf ? ENET_23_BASE_ADDR : ENET_01_BASE_ADDR; // important - do not delete
   enet_clkcfg_2(intf, display);
   enet_basic(intf,0);
   }

   void cfg_serdes(){
   int refclk = 0;
// refclk = 0 - External differential clk
// refclk = 1 - Internal single ended (cmos) clk
// refclk = 2 - Internal differential clk
int temp,port,intf;
printf("\n\renter port whose SGMII to be configured : \n\r");
temp = my_get_val("select Instance 0-ENET01  2-ENET23");
port = temp & 0x3;
intf = temp & 0x2;
enet_base_addr =  intf ? ENET_23_BASE_ADDR : ENET_01_BASE_ADDR; // important - do not delete
sm_enet_module_init_enet_serdes(intf, refclk,0);
}

void cfg_sgmii(){
int temp,port,intf;
printf("\n\renter port whose SGMII to be configured : \n\r");
temp = my_get_val("select port 0/1/2/3");
port = temp & 0x3;
intf = temp & 0x2;
enet_base_addr =  intf ? ENET_23_BASE_ADDR : ENET_01_BASE_ADDR; // important - do not delete
configure_sgmii(port, 0x0, 1);
}

void rst_sds_rxa(){
int port;
for(port = FIRST_PORT; port <=LAST_PORT ; port++) {
printf(" Port%d Serdes analog Reset ...\n",port);

mdio_wr(0x00001e11,0x8000,ENET,port,0);
serdes_reset_rxa(port,0);
mdio_wr(0x00001e11,0,ENET,port,0);
configure_sgmii(port,0x0, 20);
}
}
void rst_sds_rxd(){
int port;
for(port = FIRST_PORT; port <=LAST_PORT ; port++) {
printf(" Port%d Serdes analog Reset ...\n",port);

mdio_wr(0x00001e11,0x8000,ENET,port,0);
serdes_reset_rxd(port,0);
mdio_wr(0x00001e11,0,ENET,port,0);
configure_sgmii(port,0x0, 20);
}
}
void rst_sds_rxda(){
    int port;
    for(port = FIRST_PORT; port <= LAST_PORT ; port++){
        mdio_wr(0x00001e11,0x8000,ENET,port,0);
        serdes_reset_rxd_rxa(port,0);
        mdio_wr(0x00001e11,0x0000,ENET,port,0);
        printf(" Port%d Serdes Digital analog Reset ...\n",port);
        configure_sgmii(port,0x0, 20);
    }
}

void rst_sds_port(int port){
    int display = 0;
    int delay;

    mdio_wr(0x00001e11,0x8000,ENET,port,0);
    serdes_reset_rxa(ENET,port,0x0);
    for(delay=0;delay<10000;delay++);
    configure_sgmii(port,0x0, 5);
}

void rst_sds(){
    int temp, intf, port;
    int display = 0;
    temp = my_get_val("select port 0/1/2/3");
    intf = temp & 0x2;
    port = temp & 0x3;
    enet_base_addr =  intf ? ENET_23_BASE_ADDR : ENET_01_BASE_ADDR; // important - do not delete

    temp = my_get_val("select : 0-Analog Only \t 1-Digital and Analog");

    mdio_wr(0x00001e11,0x8000,ENET,port,0);

    if(temp == 0) 
        serdes_reset_rxa(port,display);
    else 
        serdes_reset_rxd_rxa(port,display);

    mdio_wr(0x00001e11,0x0000,ENET,port,0);
    //configure_sgmii(port,0x0, 20);
}
void fix_crc_internal(){
    int crc_clean;
    int port;
    //set_tx2rx_sdslb();
    //disable_an();

    printf("\n\n==============================\n");
    printf("=====CLEAN CRC ERROR==========\n");
    printf("==============================\n");


    for(port = FIRST_PORT; port <= LAST_PORT ; port++){
        //tx2rx_sdslb_pp(port, 1);
        disable_an_pp(port);
        eth_wr(SM_ENET_MAC_CSR_RX_DV_GATE_REG_0__ADDR,0x0,ENET,port,0);
        eth_wr(SM_ENET_MAC_CSR_RX_DV_GATE_REG_1__ADDR,0x0,ENET,port,0);

        crc_clean = 0;
        while(crc_clean == 0) {

            // Send 100_000 packets from OCM/DDR on Tx on all ports
            //-----------------------------------------------------
            // Call function here
            // send_tx_packet(100000,port);


            crc_clean = cleanup_crc_tx2rx(port,10);
        }
    }

    unset_tx2rx_sdslb();
    enable_an();

    for(port=0;port<=3;port++) {
        printf("\nConfigure Rx-2-Tx Buffer level lpbk port:%d\n",port);   
        eth_wr(SM_ENET_CSR_DEBUG_REG__ADDR,0x3e03e8,ENET,port,0); 
    }
}


void fix_crc(){
    int temp, intf, port;
    int display = 0;
    //temp = my_get_val("select port 0/1/2/3");
    //intf = temp & 0x2;
    //port = temp & 0x3;
    printf("\n\n==============================\n");
    printf("=====CLEAN SATA-SGMII CRC ERROR==========\n");
    printf("==============================\n");

    for(port = FIRST_PORT; port <= LAST_PORT ; port++)
        cleanup_crc(port,50);
}

int cleanup_crc(int port,int loop){
    int num_pkt = 0;
    int fcs_err;
    int an_sts;

    printf("ENET%d CRC Cleanup Link Status Check \n", port);  
    if(((lnk_sts(port,port,0) >> port) & 0x1)  != 0x1)
        rst_sds_port(port);
    if(((lnk_sts(port,port,0) >> port) & 0x1)  != 0x1) {
        printf("AN FAIL Aborting for PORT%d",port);
        return 2;
    }    

    while(loop){
        // Clean Statistics
        //mac_stat_rd(PEMSTAT_RPKT__ADDR,port);
        //mac_stat_rd(PEMSTAT_RFCS__ADDR,port);

        // Accummulate Stats
        printf("Waiting for Packets on Port%d",port);
        while(num_pkt < 100000) {
            num_pkt = num_pkt +  mac_stat_rd(PEMSTAT_RPKT__ADDR,port);
        }
        fcs_err = mac_stat_rd(PEMSTAT_RFCS__ADDR,port);
        printf("PEMSTAT_RFCS%d : %d\n",port,fcs_err);
        if(fcs_err) {
            printf("\nCRC-Check-FAILED-SATA-SGMII-GE-%d\n",port);
            mdio_wr(0x00001e11,0x8000,ENET,port,0);
            serdes_reset_rxd_rxa(port,0);
            configure_sgmii(port,0x0, 20);
            num_pkt = 0;
        }
        else {
            printf("CRC-Check-PASSED-SATA-SGMII-GE-%d\n",port);
            return 1;
        }
        loop--;
    }
    printf("Port%d is NOT CRC clean, TIMEOUT\n",port);
    return 0;
}

void pll_status() {
    int rd_val,pll_ready,pll_lock,vco_calibration,tx_ready,rx_ready;
    int inst;
    for(inst=0; inst < 4 ; inst=inst+2) {
        enet_base_addr = inst ? ENET_23_BASE_ADDR : ENET_01_BASE_ADDR; // important - do not delete

        rd_val = eth_rd(SM_SATA_ENET_SDS_CSR_REGS_SATA_ENET_SDS_CMU_STATUS0__ADDR,ENET,inst,0x1);
        pll_ready = FIELD_SATA_ENET_SDS_CMU_STATUS0_CFG_CMU_O_PLL_READY_RD(rd_val);
        pll_lock = FIELD_SATA_ENET_SDS_CMU_STATUS0_CFG_CMU_O_PLL_LOCK_RD(rd_val);
        vco_calibration = FIELD_SATA_ENET_SDS_CMU_STATUS0_CFG_CMU_O_VCO_CALDONE_RD(rd_val);
        printf("ENET%d%d INIT_SERDES : PLL is %sREADY\n", inst, inst+1, pll_ready ? "" : "not ");
        printf("ENET%d%d INIT_SERDES : PLL %sLOCKed\n", inst, inst+1, pll_lock ? "" : "not ");
        printf("ENET%d%d INIT_SERDES : PLL VCO Calibration %s\n", inst, inst+1, vco_calibration ? "Successful" : "not Successful");

        printf("ENET%d%d INIT_SERDES : Check TX/RX Ready\n", inst, inst+1);
        rd_val = eth_rd(SM_SATA_ENET_SDS_CSR_REGS_SATA_ENET_SDS0_RXTX_STATUS__ADDR,ENET,inst,0x1);
        tx_ready = FIELD_SATA_ENET_SDS0_RXTX_STATUS_CFG_TX_O_TX_READY_RD(rd_val);
        rx_ready = FIELD_SATA_ENET_SDS0_RXTX_STATUS_CFG_RX_O_RX_READY_RD(rd_val);
        printf("ENET%d INIT_SERDES : TX is %sready\n", inst, tx_ready ? "" : "not ");
        printf("ENET%d INIT_SERDES : RX is %sready\n", inst, rx_ready ? "" : "not ");
        rd_val = eth_rd(SM_SATA_ENET_SDS_CSR_REGS_SATA_ENET_SDS1_RXTX_STATUS__ADDR,ENET,inst,0x1);
        tx_ready = FIELD_SATA_ENET_SDS1_RXTX_STATUS_CFG_TX_O_TX_READY_RD(rd_val);
        rx_ready = FIELD_SATA_ENET_SDS1_RXTX_STATUS_CFG_RX_O_RX_READY_RD(rd_val);
        printf("ENET%d INIT_SERDES : TX is %sready\n", inst+1, tx_ready ? "" : "not ");
        printf("ENET%d INIT_SERDES : RX is %sready\n\n", inst+1, rx_ready ? "" : "not ");

        vco_status(inst,0x1);

    }

}
*/
int vco_status(int inst, int display) {
    int rd_val,pll_ready,pll_lock,vco_calibration,tx_ready,rx_ready;
    int pll_det;
    int vco_cal_fail;

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg7", CMU + 2*7,ENET,inst,1);

    //pll_ready = FIELD_SATA_ENET_SDS_CMU_STATUS0_CFG_CMU_O_PLL_READY_RD(rd_val);
    pll_lock        = (rd_val >> 15) & 0x1;
    vco_calibration = (rd_val >> 14) & 0x1;
    pll_det         = (rd_val >> 12) & 0x3;
    vco_cal_fail    = (rd_val >> 10) & 0x3;
    if(display){
        //printf("ENET%d%d  VCO_CALIB: PLL is %sREADY\n", 2*inst, 2*inst+1, pll_ready ? "" : "not ");
        lprintf(8,"ENET%d%d  VCO_CALIB: PLL %sLOCKed\n", inst, inst+1, pll_lock ? "" : "not ");
        lprintf(8,"ENET%d%d  VCO_CALIB: PLL VCO Calibration %s\n", inst, inst+1, vco_calibration ? "DONE" : "not done");
        lprintf(8,"ENET%d%d  VCO_CALIB: PLL VCO Calibration %s : 0x%x\n", inst, inst+1, vco_cal_fail == 0 ? "SUCCESSFUL" : "FAILED",vco_cal_fail);
        lprintf(8,"ENET%d%d  VCO_CALIB: PLL DET : %d\n", inst, inst+1, pll_det);
    }
    // printf("ENET%d%d INIT_SERDES : Check TX/RX Ready\n", 2*inst, 2*inst+1);
    // rd_val = eth_rd(SM_SATA_ENET_SDS_CSR_REGS_SATA_ENET_SDS0_RXTX_STATUS__ADDR,ENET,inst,0x1);
    // tx_ready = FIELD_SATA_ENET_SDS0_RXTX_STATUS_CFG_TX_O_TX_READY_RD(rd_val);
    // rx_ready = FIELD_SATA_ENET_SDS0_RXTX_STATUS_CFG_RX_O_RX_READY_RD(rd_val);
    // 
    // printf("ENET%d%d INIT_SERDES : TX is %sready\n", 2*inst, 2*inst+1, tx_ready ? "" : "not ");
    // printf("ENET%d%d INIT_SERDES : RX is %sready\n\n", 2*inst, 2*inst+1, rx_ready ? "" : "not ");
    int vco_cal_done_n = 0;
    if (vco_calibration == 0) vco_cal_done_n = 1;
    return (((vco_cal_done_n << 5 )|(vco_cal_fail<<3) | (pll_det<<1) | (pll_lock == 0))); 

}

int link_status(){
    int an_sts;
    an_sts = lnk_sts(FIRST_PORT,LAST_PORT,1);
    return an_sts;
}


int lnk_sts(int srt_port, int end_port, int display) {
    int tmp;
    int link = 0;
    int an_done = 0;
    int an_comp = 0;
    int port;
    int intf;
    int an_sts = 0;
    int delay;
    int data32;
    //  for (port = 0; port < 4; port++){
    //    tmp = eth_rd(SM_ENET_CSR_LINK_STS_INTR__ADDR,ENET,port,1);
    //    eth_wr(SM_ENET_CSR_LINK_STS_INTR__ADDR,(0x1 << (port & 0x1)),ENET,port,0);
    //    
    //    if((tmp >> (port & 0x1)) == 1) {
    //      mdio_wr(0x00001e11,0x8000,ENET,port,0);
    //      printf(" Port%d Serdes analog Reset ...\n",port);
    //      serdes_reset_rxa(port,0);
    //      mdio_wr(0x00001e11,0x0000,ENET,port,0);
    //      for(delay=0;delay<10000;delay++);
    //    }
    //  }

    //-----------------------------------
    // Print Final Link Status
    //-----------------------------------
    for (port = srt_port; port <= end_port; port++){
        if(display)lprintf(8,"\n\r\n\r======== Link Status : Port%d ==========\n\r", port);
        link, an_done = 0;
        read_data = mdio_rd(0x1e01,ENET,port,0);
        link    = (read_data >> 2) & 0x1;
        an_comp = (read_data >> 5) & 0x1;
        an_done = an_en_1g ? an_comp : link;
        int my_loop = 1000;
        while((my_loop > 0) && an_done) {
            read_data = mdio_rd(0x1e01,ENET,port,0);
            link    = ((read_data >> 2) & 0x1) && link;
            an_comp = ((read_data >> 5) & 0x1) && an_comp;
            an_done = an_en_1g ? an_comp : link;
            my_loop--;
        }
        an_sts = an_sts | (an_done << port);
        if(display)lprintf(8,"Autonegotiation %s complete %s\n\r", an_comp ? "" : "NOT",an_en_1g ? "" : " : NON-AUTONEG MODE");
        if(display)lprintf(8,"Link Status : %s \n\r", link == 1 ? "UP" : "DOWN");
        if(an_en_1g)
            if(display)lprintf(8,"Link Parameters : 0x%x \n\r\n\r", mdio_rd(0x1e05,ENET,port,0));

        //printf("Link Status after %d iterations \n\r", itr_count[port]);

        tmp =   eth_rd(SM_ENET_CSR_LINK_STATUS__ADDR,ENET,port,0) 
            & ((port == 0 || port == 2) ? 0x1 : 0x2 );
        if(gating_bypass_1g) {
            if(port == 0 || port == 2) {
                eth_wr(SM_ENET_CSR_CFG_LINK_AGGR_RESUME_0__ADDR,0x00000001,ENET,port,0);
                eth_wr(SM_ENET_MAC_CSR_RX_DV_GATE_REG_0__ADDR,0x0,ENET,port,0);
            }
            else{
                eth_wr(SM_ENET_CSR_CFG_LINK_AGGR_RESUME_1__ADDR,0x00000001,ENET,port,0);
                eth_wr(SM_ENET_MAC_CSR_RX_DV_GATE_REG_1__ADDR,0x0,ENET,port,0);
            }
        } else if(tmp != 0) {
            if(port == 0 || port == 2) {
                eth_wr(SM_ENET_CSR_CFG_LINK_AGGR_RESUME_0__ADDR,0x00000001,ENET,port,0);
                eth_wr(SM_ENET_MAC_CSR_RX_DV_GATE_REG_0__ADDR,0x7,ENET,port,0);
            }
            else{
                eth_wr(SM_ENET_CSR_CFG_LINK_AGGR_RESUME_1__ADDR,0x00000001,ENET,port,0);
                eth_wr(SM_ENET_MAC_CSR_RX_DV_GATE_REG_1__ADDR,0x7,ENET,port,0);
            }
        } else {
            lprintf(8,"Port%d : Traffic GATED\n",port);
        }
        eth_rd(SM_ENET_CSR_LINK_STATUS__ADDR,ENET,port,0);
        eth_rd(SM_ENET_CSR_LINK_STS_INTR__ADDR,ENET,port,0);
        eth_wr(SM_ENET_CSR_LINK_STS_INTR__ADDR,(0x1 << (port & 0x1)),ENET,port,0);
    }
    return an_sts;
}
void help( ) {

    printf("\n");
    printf("ONE-STEP: xgenet_main   - Main function for Complete Initialization \n");
    printf("\n");
    printf("Step 1 : set_base       - (OPTIONAL) Set base Address \n");
    printf("Step 2 : clkcfg         - Clock Enable Reset Deassertion and ECC init \n");
    printf("Step 3 : cfg_serdes     - Serdes Configuration \n");
    printf("Step 4 : basic          - Basic ENET configurations \n");
    printf("Step 5 : cfg_sgmii      - SGMII AN configuration \n");
    printf("\n");
    printf("OPTIONAL : set_calib    - Change Calibration Mode  \n");
    printf("OPTIONAL : rst_sds      - Reset Serdes \n");
    printf("OPTIONAL : rst_sds_rxa  - Reset Serdes All 4 port Analog only\n");
    printf("OPTIONAL : rst_sds_rxd  - Reset Serdes All 4 port Digital only\n");
    printf("OPTIONAL : rst_sds_rxda - Reset Serdes All 4 port Digital and Analog\n");
    printf("OPTIONAL : pll_status   - Prints PLL status of both Instances \n");
    printf("OPTIONAL : link_status  - Prints Link Status of four ports\n");
    printf("OPTIONAL : mac_stat     - Prints MAC  Statistics of four ports\n");
    printf("OPTIONAL : print_stat   - Prints Full Statistics \n");
    printf("OPTIONAL : print_calib  - Prints Serdes Calibration settings \n");
    printf("OPTIONAL : fix_crc      - Fixes CRC error by reseting serdes \n");
    printf("\n");
    printf("ADVANCED : toggle_adv   - Toggle Advance Debug Mode. Default disabled.\n");
    printf("ADVANCED : reg_full_config - Runs 200 iterations of init_enet.\n");
    printf("\n");
    printf("\n");


}

/*
   void reg_full_config(){
   int port = 0;
   int iter = 0;
   int delay = 0;
   int an_fail_count[4];
   int momsel_count_sml[4];
   int an_sts;
   int momsel_sts;
   int abrt_cnd;
   int max_itr;
   int i,j;
   int momsel_count[64][4];
   int momsel_count_pass[64][4];
   for(i=0; i < 64; i++){
   for(j=0; j < 64; j++){
   momsel_count[i][j] = 0;
   momsel_count_pass[i][j] = 0;
   }
   }
   for(port = FIRST_PORT; port <= LAST_PORT ; port++){
   an_fail_count[port] = 0;
   momsel_count_sml[port] = 0;
   }
   printf("Select abort condition : 0=any down , Num = that port up\n");
   abrt_cnd = get_val();
   max_itr = my_get_val("\nNumber of iterations: 0x"); 
   for(iter=0; iter < max_itr; iter++){
// Reconfigure XGENET // kchidvil
init_enet(0); // 0-ENET01
init_enet(2); // 2-ENET23
enet_sds_ind_csr_reg_rd("CMU_reg3", CMU + 2*3,ENET,0x0,1);
enet_sds_ind_csr_reg_rd("CMU_reg3", CMU + 2*3,ENET,0x2,1);
an_sts = link_status();
for(port = FIRST_PORT; port <= LAST_PORT ; port++){
if(((an_sts >> port) & 0x1) == 0)
an_fail_count[port]++;
}
momsel_sts = print_calib();
for(port = FIRST_PORT; port <= LAST_PORT ; port++){
int momsel_port = (momsel_sts >> ((port)*8)) & 0x3f;
momsel_count_pass[momsel_port][port]++;
}
if(an_sts != 0xf)  { // kchidvil Any port down
// if((an_sts|0x3) != 0xf) { // P2 P3 down
//if((an_sts|0xc) != 0xf) { // P0 P1 down
//if((an_sts & 0x3) != 0x0) { // P0 P1 up
for(port = FIRST_PORT; port <= LAST_PORT ; port++){
int momsel_port = (momsel_sts >> ((port)*8)) & 0x3f;
if(((an_sts >> port) & 0x1) != 0x1) {
if((((momsel_port & 0x11) != 0x11) && ((momsel_port & 0x12) != 0x12)))
momsel_count_sml[port]++;

momsel_count[momsel_port][port]++;
}
}
vco_status(0x0,0x1);
vco_status(0x2,0x1);
#if 0
if(my_get_val("Press 0=Continue iteration\n\r")) {
while(my_get_val("Press 0=Continue iteration else enter reset sds\n\r")) {
if(my_get_val("Press 0=Continue reset sds else break\n\r"))     
break;
rst_sds();
}
}
#endif
}
if(abrt_cnd == 0 &&  an_sts != 0xf){
return 0;

}
else if((abrt_cnd & an_sts) != 0){
    return 0;
}
}
printf("\n\r\n\r======== AN Regression Status  ==========\n\r");
for(port = FIRST_PORT; port <= LAST_PORT ; port++){
    printf("[PORT%d] : %d/%d   Momsel count: %d\n\r",port,an_fail_count[port],iter,momsel_count_sml[port]);
}

    for(i=0; i < 64; i++) {
        if(max_itr,momsel_count[i][0]||momsel_count[i][1]||momsel_count[i][2]||momsel_count[i][3])
            printf("[MOMSEL FAILED 0x%x:[%d]] : \t %d \t %d \t %d \t%d\n\r",i,max_itr,momsel_count[i][0],momsel_count[i][1],momsel_count[i][2],momsel_count[i][3]);
    }
printf("\n\r\n\r");
    for(i=0; i < 64; i++) {
        if(momsel_count_pass[i][0] || momsel_count_pass[i][1] || momsel_count_pass[i][2] || momsel_count_pass[i][3])
            printf("[MOMSEL Calib 0x%x :[%d]] : \t %d \t %d \t %d \t%d\n\r",i,max_itr,momsel_count_pass[i][0],momsel_count_pass[i][1],momsel_count_pass[i][2],momsel_count_pass[i][3]);
    }

print_calib();

for(delay=0; delay < 10000; delay++);
printf("done\n\r\n\r");

}

void momsel_sweep(){
    int port = 0;
    int iter = 0;
    int delay = 0;
    int an_sts;
    int momsel_sts;
    int abrt_cnd;
    int max_itr;
    int i,j;
    int momsel_count[64][4];
    for(i=0; i < 64; i++){
        for(j=0; j < 64; j++){
            momsel_count[i][j] = 0;
        }
    }

    max_itr = my_get_val("\nNumber of iterations per momsel: 0x"); 
    for(i=0; i < 64; i++) {
        vco_momsel_init = i;

        for(iter=0; iter < max_itr; iter++){
            // Reconfigure XGENET // kchidvil
            init_enet(0); // 0-ENET01
            init_enet(2); // 2-ENET23
            an_sts = link_status();
            for(port = FIRST_PORT; port <= LAST_PORT ; port++){
                if(((an_sts >> port) & 0x1) == 1)
                    momsel_count[vco_momsel_init][port]++;
            }
        }

        for(delay=0; delay < 10000; delay++);
    }
    printf("\n\r\n\r======== MOMSEL SWEEP RESULT  ==========\n\r");
    for(i=0; i < 64; i++) {
        printf("[MOMSEL %x out of %d] : \t %d \t %d \t %d \t%d\n\r",i,max_itr,momsel_count[i][0],momsel_count[i][1],momsel_count[i][2],momsel_count[i][3]);
    }

}
void mac_stat(){
    int port = 0;
    for(port = FIRST_PORT; port <= LAST_PORT ; port++){
        printf("-------Port%d----------\n",port);
        // printf(" : %d \n",mac_stat_rd(,port));
        printf("PEMSTAT_RPKT__ADDR : %d \n",mac_stat_rd(PEMSTAT_RPKT__ADDR,port));
        printf("PEMSTAT_TPKT__ADDR : %d \n",mac_stat_rd(PEMSTAT_TPKT__ADDR,port));
        printf("PEMSTAT_RFCS__ADDR : %d \n",mac_stat_rd(PEMSTAT_RFCS__ADDR,port));
        printf("PEMSTAT_TFCS__ADDR : %d \n",mac_stat_rd(PEMSTAT_TFCS__ADDR,port));
        printf("\n");
    }
}

void print_stat(){
    int i,j;
    int temp, intf, port;
    int display = 0;
    temp = my_get_val("select Inst 0/2");
    intf = temp & 0x2;
    // port = temp & 0x3; 
    port = intf;
    enet_base_addr =  intf ? ENET_23_BASE_ADDR : ENET_01_BASE_ADDR; // important - do not delete
    printf("\n\r MACOUT reg ");putnum(eth_rd(SM_ENET_CSR_MACOUT_ENET_STAT_REG_PORT0__ADDR,ENET,port,display));
    printf("\n\r MACIN reg ");putnum(  eth_rd(SM_ENET_CSR_MACIN_ENET_STAT_REG_PORT0__ADDR,ENET,port,display));
    printf("\n\r RXBIN reg ");putnum(  eth_rd(SM_ENET_CSR_RXBIN_ENET_STAT_REG_PORT0__ADDR,ENET,port,display));
    printf("\n\r MACOUT reg ");putnum(eth_rd(SM_ENET_CSR_MACOUT_ENET_STAT_REG_PORT1__ADDR,ENET,port,display));
    printf("\n\r MACIN reg ");putnum(  eth_rd(SM_ENET_CSR_MACIN_ENET_STAT_REG_PORT1__ADDR,ENET,port,display));
    printf("\n\r RXBIN reg ");putnum(  eth_rd(SM_ENET_CSR_RXBIN_ENET_STAT_REG_PORT1__ADDR,ENET,port,display));
    printf("\n\r Port0: RSIF CNTR reg");putnum(  eth_rd(SM_ENET_CSR_RSIF_STS_CNTR_REG0__ADDR,ENET,port,display));
    printf("\n\r Port1: RSIF CNTR reg");putnum(  eth_rd(SM_ENET_CSR_RSIF_STS_CNTR_REG1__ADDR,ENET,port,display));
    printf("\n\r {Port1, Port0}: RSIF FP Timeout counter ");putnum(  eth_rd(SM_ENET_CSR_RSIF_FPBUFF_TIMEOUT_STSREG0__ADDR,ENET,port,display));
    printf("\n\r {Port1, Port0}: RSIF FP Partial drop Timeout counter ");putnum(  eth_rd(SM_ENET_CSR_RSIF_FPBUFF_TIMEOUT_PARTIALDROP_STSREG0__ADDR,ENET,port,display));
    printf("\n\r {Port1, Port0}: TSIF CNTR reg ");putnum(  eth_rd(SM_ENET_CSR_TSIF_STS_REG1__ADDR,ENET,port,display));
    printf("\n\r {Port1, Port0}: TSIF Dealloc message cntr reg ");putnum(  eth_rd(SM_ENET_CSR_TSIF_STS_REG2__ADDR,ENET,port,display));
    printf("\n\r {Port1, Port0}: TSIF Bad message cntr reg ");putnum(  eth_rd(SM_ENET_CSR_TSIF_STS_REG3__ADDR,ENET,port,display));

    printf("\n\r RX_TX_BUF_STS reg");putnum(  eth_rd(SM_ENET_CSR_RX_TX_BUF_STS_REG0__ADDR,ENET,port,display));
    printf("\n\r RSIF FIFO STS reg");putnum(  eth_rd(SM_ENET_CSR_RSIF_FIFO_EMPTYSTS0__ADDR,ENET,port,display));
    printf("\n\r TSIF FIFO STS reg");putnum(  eth_rd(SM_ENET_CSR_TSIF_FIFO_EMPTYSTS0__ADDR,ENET,port,display));
    printf("\n\r MAC FIFO STS reg");putnum(  eth_rd(SM_ENET_MAC_CSR_MAC_FIFO_STS_REG0__ADDR,ENET,port,display));
    printf("\n\r RX DV GATE reg");putnum(  eth_rd(SM_ENET_MAC_CSR_RX_DV_GATE_REG_0__ADDR,ENET,port,display));
    printf("\n\r LINK STS SEL reg");putnum(  eth_rd(SM_ENET_CSR_CFG_LINK_STS_SEL__ADDR,ENET,port,display));
    printf("\n\r LINK AGGR RESUMEreg");putnum(  eth_rd(SM_ENET_CSR_CFG_LINK_AGGR_RESUME_0__ADDR,ENET,port,display));
    printf("\n\r LINK AGGR ");putnum(  eth_rd(SM_ENET_CSR_CFG_LINK_AGGR__ADDR,ENET,port,display));
    printf("\n\r LINK STATUS ");putnum(  eth_rd(SM_ENET_CSR_LINK_STATUS__ADDR,ENET,port,display));
    printf("\n\r CLKEN ");putnum(  eth_rd(SM_ENET_CLKRST_CSR_ENET_CLKEN__ADDR,ENET,port,display));
    printf("\n\r SRST ");putnum(  eth_rd(SM_ENET_CLKRST_CSR_ENET_SRST__ADDR,ENET,port,display));
    printf("\n\r CFG_BYPASS ");putnum(  eth_rd(SM_ENET_CSR_CFG_BYPASS__ADDR,ENET,port,display));
    printf("\n\r TXB STAT ");putnum(  eth_rd(SM_ENET_CSR_TXB_ENET_STAT_REG_PORT0__ADDR,ENET,port,display));
    printf("\n\r RGMII REG 0 ");putnum(  eth_rd(SM_ENET_CSR_RGMII_REG_0__ADDR,ENET,port,display));

    //  printf("\n\n =====QM AXI BW monitor======");
    //  qm_reg_rd(SM_GLBL_DIAG_CSR_STS_AXI_MRD_BW_CLK_CNT__ADDR);//0xd024
    //  qm_reg_rd(SM_GLBL_DIAG_CSR_STS_AXI_MRD_BW_BYTE_CNT__ADDR);//0xd028
    //  qm_reg_rd(SM_GLBL_DIAG_CSR_STS_AXI_MWR_BW_CLK_CNT__ADDR);//0xd02c
    //  qm_reg_rd(SM_GLBL_DIAG_CSR_STS_AXI_MWR_BW_BYTE_CNT__ADDR);//0xd030
    //  qm_reg_rd(SM_GLBL_DIAG_CSR_STS_AXI_SRD_BW_CLK_CNT__ADDR);//0xd034
    //  qm_reg_rd(SM_GLBL_DIAG_CSR_STS_AXI_SRD_BW_BYTE_CNT__ADDR);//0xd038
    //  qm_reg_rd(SM_GLBL_DIAG_CSR_STS_AXI_SWR_BW_CLK_CNT__ADDR);//0xd03c

    printf("\n\r SM_ENET_CSR_STS_ECM_SOF0_CNTRL_WORD_0__ADDR  ");putnum(eth_rd(SM_ENET_CSR_STS_ECM_SOF0_CNTRL_WORD_0__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_STS_ECM_SOF1_CNTRL_WORD_1__ADDR  ");putnum(eth_rd(SM_ENET_CSR_STS_ECM_SOF1_CNTRL_WORD_0__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_STS_ECM_SOF2_CNTRL_WORD_2__ADDR  ");putnum(eth_rd(SM_ENET_CSR_STS_ECM_SOF2_CNTRL_WORD_0__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_STS_ECM_SOF3_CNTRL_WORD_3__ADDR  ");putnum(eth_rd(SM_ENET_CSR_STS_ECM_SOF3_CNTRL_WORD_0__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_STS_ECM_EOF1_CNTRL_WORD_3__ADDR  ");putnum(eth_rd(SM_ENET_CSR_STS_ECM_EOF1_CNTRL_WORD_0__ADDR,ENET,port,display));

    //port0 pemstat
    i = 0;
    printf("Pemstats Port%d\n\r",port);
    for (j=0x20; j<0x50; j++)
    {
        i++;
        printf("0x");putnum(j);printf(" = 0x");putnum(mac_stat_rd(j,port));printf(" \t");
        if(i==4) { i = 0; printf("\n\r");}
    }
    //port1 pemstat
    i = 0;
    port = intf | 0x1;
    printf("Pemstats Port%d\n\r",port);
    for (j=0x20; j<0x50; j++)
    {
        i++;
        printf("0x");putnum(j);printf(" = 0x");putnum(mac_stat_rd(j,port));printf(" \t");
        if(i==4) { i = 0; printf("\n\r");}
    }
}

void set_tx2rx_sdslb(){
    int port;
    int it,drop_data,bypass_en;

    if (loopback == 0) {
        eth_wr(SM_ENET_CSR_DEBUG_REG__ADDR,0x3e03ee,ENET,port,0); 
    }
    bypass_en = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,ENET,port,0);
    bypass_en = bypass_en | 0x80000000;
    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,bypass_en,ENET,port,0); 
    drop_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG4_0__ADDR,ENET,port,0);
    drop_data = drop_data | 0x00000001;
    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_0__ADDR,drop_data,ENET,port,0); 


    printf("INIT_SERDES : SERDES Tx2Rx Loopback Set\n");

    tx2rx_sdslb(1);

}

void unset_tx2rx_sdslb(){
    int port;
    int it,drop_data,bypass_en;

    printf("INIT_SERDES : SERDES Tx2Rx Loopback Cleared\n");
    tx2rx_sdslb(0);


    bypass_en = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,ENET,port,0);
    bypass_en = bypass_en & 0x7fffffff;
    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,bypass_en,ENET,port,0); 
    drop_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG4_0__ADDR,ENET,port,0);
    drop_data = drop_data & 0xfffffffe;
    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_0__ADDR,drop_data,ENET,port,0); 

    if (loopback == 0) {
        eth_wr(SM_ENET_CSR_DEBUG_REG__ADDR,0x3e03fe,ENET,port,0); 
    }
}

void tx2rx_sdslb(int val){
    int rd_val,wr_val,inst_base;
    int port,inst;
    int display =0;
    int delay;

    for (port=0 ; port<4; port=port+2) {
        for (inst = 0; inst < 2;  inst++) {
            printf("INIT_SERDES : RXTX Inst %x\n", inst);
            inst_base = 0x0400 + inst*0x0200;
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,ENET,port,display);
            wr_val = sm_enet_set(rd_val, val, 6, 6);
            enet_sds_ind_csr_reg_wr("rxtx_reg4",  inst_base + 0x4*2, wr_val,ENET,port,display);

            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,ENET,port,display);
            wr_val = sm_enet_set(rd_val, val, 14, 14);
            enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,ENET,port,display);
        }
    }
    for(delay=0;delay<10000;delay++);
}

void send_pause_frame( int port) {
    int display = 0;
    int it,drop_data,bypass_en;
    int pkt_cnt;

    if (loopback == 0) {
        eth_wr(SM_ENET_CSR_DEBUG_REG__ADDR,0x3e03ee,ENET,port,display); 
    }
    bypass_en = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,ENET,port,display);
    bypass_en = bypass_en | 0x80000000;
    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,bypass_en,ENET,port,display); 
    drop_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG4_0__ADDR,ENET,port,display);
    drop_data = drop_data | 0x00000001;
    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_0__ADDR,drop_data,ENET,port,display); 


    for(pkt_cnt=0;pkt_cnt <32;pkt_cnt++){
        if(port & 0x1 )
            eth_wr(SM_ENET_MAC_CSR_CSR_ECM_CFG_1__ADDR, 0x08000005,ENET,port,display);
        else
            eth_wr(SM_ENET_MAC_CSR_CSR_ECM_CFG_0__ADDR, 0x08000005,ENET,port,display);

        for (it = 0 ; it < 10000000; it++);
    }
    bypass_en = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,ENET,port,display);
    bypass_en = bypass_en & 0x7fffffff;
    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,bypass_en,ENET,port,display); 
    drop_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG4_0__ADDR,ENET,port,display);
    drop_data = drop_data & 0xfffffffe;
    eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_0__ADDR,drop_data,ENET,port,display); 

    if (loopback == 0) {
        eth_wr(SM_ENET_CSR_DEBUG_REG__ADDR,0x3e03fe,ENET,port,display); 
    }

}
void set_calib(){
    pll_manualcal = my_get_val("Select Calibration Mode (0:AutoCalib 1:Manual) : ");
    man_pvt_cal = my_get_val("Select PVT Calibration Mode (0:AutoCalib 1:Manual) : ");
    // vco_momsel_init = my_get_val("Select Momsel init value : 0x");
    printf("\nCalibration mode changed to %s \n", pll_manualcal ? "MANUAL" : "AUTOMATIC");
    printf("\nPVT Calibration mode changed to %s \n", man_pvt_cal ? "MANUAL" : "AUTOMATIC");
    printf("Please Reconfigure Serdes .....\n");
}

int print_calib(){
    int port=0;
    int rd_val;
    int ret_val = 0;
    for(port = 0 ; port <4 ; port=port+2) {
        rd_val = enet_sds_ind_csr_reg_rd("CMU_reg3", CMU + 2*3,ENET,port,1);
        rd_val = (rd_val & 0x3f0 ) >> 4;
        printf("Inst%d MAN Momsel init = 0x%x\n",port,rd_val);
        rd_val = enet_sds_ind_csr_reg_rd("CMU_reg19", CMU + 2*19,ENET,port,1);
        rd_val = ((rd_val & 0xfc00 ) >> 10) & 0x3f;
        printf("Inst%d Momsel Calib = 0x%x\n",port,rd_val);
        ret_val = ret_val | (rd_val << port*8);
        ret_val = ret_val | (rd_val << (port+1)*8);

    }

    return ret_val; // kchidvil : 18 June 2013
}
*/

void debug_1g(){
    int val,quit_r,intf,port,i,j,fail_cnt,ind_data,it,iter;
    int phy_addr=0,phy_reg=0;
    int ind_address;
    do
    {
        printf("\n\r\n\r");
        printf("99. BLOCK RESET\n\r");
        // printf("98. REINITIALIZE ENET (Warning : Fix Memory Leak)\n\r");
        printf("97. Select ENET01 or ENET23\n\r");
        printf("\n\r");
        printf("90. Reconfigure Serdes : both ports of the selected instance\n\r");
        printf("95. Assert Deasssert Analog Reset\n\r");
        printf("96. Assert Deasssert Digital & Analog Reset\n\r");

        printf("\n\r");
        printf("100. Print PLL Status\n\r");
        // printf("91. Serdes   Digital Reset\n\r");
        // printf("92. Serdes   Analog  Reset\n\r");
        // printf("93. Deassert Analog  Reset\n\r");
        // printf("94. Deassert Digital Reset\n\r\n\r");


        printf("\n\r");
        // printf(" 1. Read Register \n\r");
        // printf(" 2. Write Register \n\r");
        printf(" 3. Read port stats\n\r");
        // printf(" 4. Indirect Read  \t");
        // printf(" 5. Indirect Write \n\r");
        // printf(" 6. MDIO Read  \t");
        // printf(" 7. MDIO Write \n\r");
        printf("\n\r");
        printf(" 8. Switch phy to autoneg\n\r");
        printf(" 9. Switch phy to autoneg + Reconfigure Serdes loop\n\r");
        // printf("10. Link resume testing\n\r");
        // printf("11. Policer Read\t");
        // printf("12. Policer Write\t");
        // printf("13. Policer Index reconfig\t");
        // printf("14. Policer Enable\t");
        // printf("15. Policer Profile \t");
        // printf("16. Policer CSR Test \t");
        // printf("17. Policer Drop Counter \t");
        // printf("18. Policer Disable \n\r");
        // printf("20. PTP Enable  \t");
        // printf("21. PTP Statistics  \n\r");
        // printf("30. TEST Profile  \n\r");
        // printf("36. Enq Workmessage  \n\r");
        // printf("37. MDIO link read test  \n\r");
        // printf("38. Send pause frame  \n\r");
        // printf("40. AVB-CBSA config \n\r");
        // printf("41. ENTER PPC loopback config \n\r");
        printf("\n\r");
        printf("42. SERDES indirect Read \n\r");
        printf("43. SERDES indirect Write \n\r");
        printf("\n\rq. to quit.. \n\r");

        printf("\n\r");
        val = get_val();
        quit_r = val + 0x57;

        // command interpretation
        if (val == 0x99) // read loop
        {
            display_serdes = 0x1;
            //           printf("\n\r Asserting Reset ...\n\r");      
            // 	  eth_wr(SM_ENET_CLKRST_CSR_ENET_SRST__ADDR ,0x0000000a,ENET,port,display); 
            //           printf("\n\r Deasserting Reset ...\n\r");      
            // 	  eth_wr(SM_ENET_CLKRST_CSR_ENET_SRST__ADDR ,0x00000000,ENET,port,display); 
        } // ended read loop
        else if (val == 0x98) // read loop
        {
            int temp;
            temp = my_get_val("select port 0/2 : ");
            intf = temp & 0x2;
            port = temp & 0x3;
            enet_base_addr =  intf ? ENET_23_BASE_ADDR : ENET_01_BASE_ADDR; // important           printf("\n\r Asserting Reset ...\n\r");      
            eth_wr(SM_ENET_CLKRST_CSR_ENET_SRST__ADDR ,0x0000001f,ENET,port,0x1);
            init_enet(intf);
        } // ended read loop
        else if (val == 0x97 ){
            enet_base_addr = my_get_val("select port 0/2") ? ENET_23_BASE_ADDR : ENET_01_BASE_ADDR; // important - do not delete

        }
        else if (val == 0x100 ){
            //	pll_status();
        }
        else if (val == 0x90 ) 
        {
            int temp;
            temp = my_get_val("select port 0/2 : ");
            intf = temp & 0x2;
            port = temp & 0x3;
            enet_base_addr =  intf ? ENET_23_BASE_ADDR : ENET_01_BASE_ADDR; // important - do not delete
            temp = my_get_val("select Refclock mode 0-Ext 1- Internal Single ended 2-Internal Differential : ");
            init_enet_serdes(intf,temp); 
        }
        else if (val == 0x96 )
        {
            int temp;
            temp = my_get_val("select port 0/1/2/3");
            intf = temp & 0x2;
            port = temp & 0x3;
            enet_base_addr =  intf ? ENET_23_BASE_ADDR : ENET_01_BASE_ADDR; // important - do not delete
            serdes_reset_rxd_rxa(port,0);
        } 
        else if (val == 0x95 )
        {
            int temp;
            temp = my_get_val("select port 0/1/2/3");
            intf = temp & 0x2;
            port = temp & 0x3;
            enet_base_addr =  intf ? ENET_23_BASE_ADDR : ENET_01_BASE_ADDR; // important - do not delete
            serdes_reset_rxa(port,0x0);
        } 
        else if (val == 0x91 ) 
        {
            int inst_base,rd_val,wr_val;
            inst_base = 0x0400;
            printf (" CH0 RX Reset Digital ...\n\r");
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2);
            wr_val = sm_enet_set(rd_val, 0, 8, 8); // digital reset == 1'b0
            enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val);
            inst_base = 0x0600;
            printf (" CH1 RX Reset Digital ...\n\r");
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2);
            wr_val = sm_enet_set(rd_val, 0, 8, 8); // digital reset == 1'b0
            enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val);

        }
        else if (val == 0x92 ) 
        {
            unsigned int  wr_val, rd_val;
            int timeout;
            int inst_base;
            int port = 0;
            int display = 0;
            for(port =0;port <4; port++) {
                if(port == 0 || port == 2) {
                    inst_base = 0x0400;
                    // printf (" CH0 RX Reset Digital ...\n\r");
                    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,ENET,port,display);
                    wr_val = sm_enet_set(rd_val, 0, 8, 8); // digital reset == 1'b0
                    enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,ENET,port,display);

                    inst_base = 0x0400;
                    // printf (" CH0 RX Reset Analog ...\n\r");
                    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,ENET,port,display);
                    wr_val = sm_enet_set(rd_val, 0, 7, 7); // analog reset == 1'b0
                    enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,ENET,port,display);
                } else {
                    inst_base = 0x0600;
                    // printf (" CH1 RX Reset Digital ...\n\r");
                    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,ENET,port,display);
                    wr_val = sm_enet_set(rd_val, 0, 8, 8); // digital reset == 1'b0
                    enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,ENET,port,display);

                    inst_base = 0x0600;
                    // printf (" CH1 RX Reset Analog ...\n\r");
                    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,ENET,port,display);
                    wr_val = sm_enet_set(rd_val, 0, 7, 7); // analog reset == 1'b0
                    enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,ENET,port,display);
                }
            }
        }
        else if (val == 0x93 ) 
        {
            int inst_base,rd_val,wr_val;
            inst_base = 0x0400;
            printf (" CH0 RX Remove Reset Analog ...\n\r");
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2);
            wr_val = sm_enet_set(rd_val, 1, 7, 7); // analog reset == 1'b1
            enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val);

            inst_base = 0x0600;
            printf (" CH1 RX Remove Reset Analog ...\n\r");
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2);
            wr_val = sm_enet_set(rd_val, 1, 7, 7); // analog reset == 1'b1
            enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val);

        }
        else if (val == 0x94 ) 
        {
            int inst_base,rd_val,wr_val;
            //if(port == 0) {
            inst_base = 0x0400;
            printf (" CH0 RX Remove Reset Digital ...\n\r");
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2);
            wr_val = sm_enet_set(rd_val, 1, 8, 8); // digital reset == 1'b1
            enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val);
            //} else {
            inst_base = 0x0600;
            printf (" CH1 RX Remove Reset Digital ...\n\r");
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2);
            wr_val = sm_enet_set(rd_val, 1, 8, 8); // digital reset == 1'b1
            enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val);
            //}
        }
        else if (val == 0x01) // read loop
        {
            printf("\n\rread address offset (hex)=?\n\r");
            val = get_val();
            read_address = val;
            read_data = myread(read_address,1);
            //	  printf("\n\rread data = 0x");putnum(read_data);printf(" from address = 0x");putnum(read_address);printf("\n\r");
        } // ended read loop

        else if (val == 0x02)    //// Write command
        {
            printf("\n\rwrite address (hex)=?\n\r");      
            val = get_val();
            write_address = val;
            printf("\n\rwrite data=?\n\r");
            // input write data
            val = get_val();
            write_data = val;
            //	  eth_wr(write_address,write_data,ENET,port,display);
            write(write_address,write_data);
            //	  printf("\n\rwritten data = 0x");putnum(write_data);printf(" at address = 0x");putnum(write_address);printf("\n\r");  
        } // ended write loop

        else if (val == 0x03)    //// status command
        {
            int temp,port,intf;
            printf("\n\renter port whose mdio to be used \n\r");
            // mdio_wr(0x716,1,ENET,0x0,display);
            // mdio_wr(0x700,0x8140,ENET,0x0,display);
            // mdio_wr(0x716,0,ENET,0x0,display);
            temp = my_get_val("select port 0/1/2/3");
            port = temp & 0x3;
            intf = temp & 0x2;
            enet_base_addr =  intf ? ENET_23_BASE_ADDR : ENET_01_BASE_ADDR; // important - do not delete
            read_statistics(port);// Function Call to print all the Statistics
        } // ended status read loop

        else if (val == 0x04)    //// mac ind rd command
        {
            printf("\n\renter port whose mac is to be read \n\r");
            port = get_val();
            printf("\n\rRead address (hex)=?\n\r");
            ind_address = get_val();
            read_data = mcxmac_ind_rd(ind_address,ENET,port, 1);
            printf("\n\rdata read is = 0x");putnum(read_data);printf("\n\r");
        } // ended status read loop

        else if (val == 0x05)    //// mac ind wr command
        {
            printf("\n\renter port whose mac is to be written \n\r");
            port = get_val();
            printf("\n\renter write address \n\r");
            val = get_val();
            ind_address = val;
            printf("\n\r enter write data=?\n\r");
            // input write data
            val = get_val();
            write_data = val;
            printf("\n\rwriting....\n\r");
            mcxmac_ind_wr(ind_address,write_data,ENET,port, 1);
            printf("\n\rwritten data = 0x");putnum(write_data);printf(" at address = 0x");putnum(ind_address);printf("\n\r");
        } // ended status read loop
        else if (val == 0x06)    //// mac ind rd command
        {
            printf("\n\renter port whose mdio to be used \n\r");
            port = get_val();
            printf("\n\r Phy addr and reg address combined.in [0:31] format,[0:18] = 19'b0, [19:23]= Phyaddress, [24:26] = 3'b0, [27:31] = reg address in (hex)=?\n\r");
            ind_address = get_val();
            read_data = mdio_rd(ind_address,ENET,port,1);
            printf("\n\rdata read is = 0x");putnum(read_data);printf("\n\r");
        } // ended status read loop

        else if (val == 0x07)    //// mac ind wr command
        {
            printf("\n\renter port whose mdio to be used \n\r");
            port = get_val();
            printf("\n\r Phy addr and reg address combined.in [0:31] format,[0:18] = 19'b0, [19:23]= Phyaddress, [24:26] = 3'b0, [27:31] = reg address in (hex)=?\n\r");
            val = get_val();
            ind_address = val;
            printf("\n\r enter write data=?\n\r");
            // input write data
            val = get_val();
            write_data = val;
            printf("\n\rwriting....\n\r");
            mdio_wr(ind_address,write_data,ENET,port,1);
            printf("\n\rwritten data = 0x");putnum(write_data);printf(" at address = 0x");putnum(ind_address);printf("\n\r");
        } // ended status read loop

        else if (val == 0x08)    //// mac ind wr command
        {
            int temp,port,intf;
            printf("\n\renter port whose mdio to be used \n\r");
            // mdio_wr(0x716,1,ENET,0x0,display);
            // mdio_wr(0x700,0x8140,ENET,0x0,display);
            // mdio_wr(0x716,0,ENET,0x0,display);
            temp = my_get_val("select port 0/1/2/3");
            port = temp & 0x3;
            intf = temp & 0x2;
            enet_base_addr =  intf ? ENET_23_BASE_ADDR : ENET_01_BASE_ADDR; // important - do not delete
            mdio_wr(0x1e00,0x9140,ENET,port,1);
            int loop = 20;
            int link, an_done = 0;
            while((loop != 0) && (an_done == 0)){
                link, an_done = 0;
                read_data = mdio_rd(0x1e01,ENET,port,0);

                link    = (read_data >> 2) & 0x1;
                an_done = (read_data >> 5) & 0x1;
                loop--;
            }
            printf("Autonegotiation %s complete \n\r", an_done ? "" : "NOT");
            printf("Link Status : %s \n\r", link ? "UP" : "DOWN");
            printf("Link Parameters : 0x%x \n\r", mdio_rd(0x1e05,ENET,port,0));
        }  
        else if (val == 0x09)    //// mac ind wr command
        {
            int temp,port,intf;
            printf("\n\renter port whose mdio to be used \n\r");
            temp = my_get_val("select port 0/1/2/3");
            port = temp & 0x3;
            intf = temp & 0x2;
            enet_base_addr =  intf ? ENET_23_BASE_ADDR : ENET_01_BASE_ADDR; // important - do not delete
            configure_sgmii(port, 0x0, 20);
        } 
        else if (val == 0x10)    //// mac ind wr command
        {
            int display = 1;
            // Port 0 
            eth_wr(SM_ENET_CSR_CFG_BYPASS__ADDR,0x0,ENET,port,display);
            eth_wr(SM_ENET_MAC_CSR_RX_DV_GATE_REG_0__ADDR,0x7,ENET,port,display);
            tmp = eth_rd(SM_ENET_CSR_LINK_STS_INTR__ADDR,ENET,port,display);
            eth_wr(SM_ENET_CSR_LINK_STS_INTR__ADDR,0xffffffff,ENET,port,display);
            tmp = eth_rd(SM_ENET_CSR_LINK_STATUS__ADDR,ENET,port,display);
            tmp = eth_rd(SM_ENET_CSR_CFG_LINK_AGGR_RESUME_0__ADDR,ENET,port,display);
            eth_wr(SM_ENET_CSR_CFG_LINK_AGGR_RESUME_0__ADDR,0x00000001,ENET,port,display);
            // Port 1 
            eth_wr(SM_ENET_CSR_CFG_LINK_STS_SEL__ADDR,0x00000002,ENET,port,display); 
            eth_wr(SM_ENET_CSR_CFG_FORCE_LINK_STATUS_EN__ADDR,0x00000002,ENET,port,display); 
            eth_wr(SM_ENET_CSR_FORCE_LINK_STATUS__ADDR,0x00000002,ENET,port,display); 
            eth_wr(SM_ENET_MAC_CSR_RX_DV_GATE_REG_1__ADDR,0x7,ENET,port,display);
            tmp = eth_rd(SM_ENET_CSR_CFG_LINK_AGGR_RESUME_1__ADDR,ENET,port,display);
            eth_wr(SM_ENET_CSR_CFG_LINK_AGGR_RESUME_1__ADDR,0x00000001,ENET,port,display);

            printf("\n\r waiting for link down \n\r");
            tmp = 0;
            do {
                //tmp = eth_rd(SM_ENET_CSR_LINK_STS_INTR__ADDR,ENET,port,display);
                tmp = myread(enet_base_addr + SM_ENET_CSR_LINK_STS_INTR__ADDR,0);
            } while ((tmp & 0x00000001) == 0);
            tmp = eth_rd(SM_ENET_CSR_LINK_STATUS__ADDR,ENET,port,display);
            tmp = eth_rd(SM_ENET_CSR_CFG_LINK_AGGR_RESUME_0__ADDR,ENET,port,display);
            printf("\n\r clearing the link down intr \n\r");
            eth_wr(SM_ENET_CSR_LINK_STS_INTR__ADDR,0xffffffff,ENET,port,display);
            printf("\n\r waiting for link to come up \n\r");
            tmp = 0;
            do {
                //tmp = eth_rd(SM_ENET_CSR_LINK_STS_INTR__ADDR,ENET,port,display);
                tmp = myread(enet_base_addr + SM_ENET_CSR_LINK_STS_INTR__ADDR,0);
            } while ((tmp & 0x00000001) == 0);
            tmp = eth_rd(SM_ENET_CSR_LINK_STATUS__ADDR,ENET,port,display);
            printf("\n\r link up intr rcvd, press 1 for setting resume bit , 0 to exit \n\r");
            val = get_val();
            if (val == 1) {
                eth_wr(SM_ENET_CSR_CFG_LINK_AGGR_RESUME_0__ADDR,0x00000001,ENET,port,display);
                eth_wr(SM_ENET_MAC_CSR_RX_DV_GATE_REG_0__ADDR,0x7,ENET,port,display);
                printf("\n\r resume traffic\n\r");
            }
            else
                printf("\n\r traffic should not resume as resume bit not set\n\r");
        }  
        else if (val == 0x11)    //// mac ind wr command
        {
            val = my_get_val("\n\r Read Policer Index : 0x");
            enet_plc_rd(val,1);
        } // ended status read loop
        else if (val == 0x12)    //// mac ind wr command
        {
            plc_idx = my_get_val("\n\r Write Policer Index : 0x");
            plc_cir = my_get_val("CIR : 0x");
            plc_cbs = my_get_val("CBS : 0x");
            plc_eir = my_get_val("EIR : 0x");
            plc_ebs = my_get_val("EBS : 0x");
            plc_eir = plc_eir | my_get_val("CM  : 0x")<< 31;
            plc_eir = plc_eir | my_get_val("CF  : 0x")<< 30;
            enet_plc_wr(plc_idx,plc_cir,plc_cbs,plc_eir,plc_ebs,1);
        } // ended status read loop
        else if (val == 0x13)
        {
            cfg_plc_index(my_get_val("\n\r Reconfigure Policer Index : 0x"),
                    my_get_val("Commited : 0x"),
                    my_get_val("Excess : 0x")
                    ,1);
        } // ended status read loop
        else if (val == 0x14)
        { val = my_get_val("\n\r Policer Mode {dualbucket, priority(8), flowgroup(16), perflow(64)} : ");
            plc_dualbucket = (val>>3) && 0x1;
            if(plc_dualbucket) {
                printf("\n\r Policer Mode : Dualbucket");
                plc_cm = my_get_val("Color Mode(0= Blind, 1= Color Aware)  : ");
                plc_cf = my_get_val("Coupling Factor(0= Disabled, 1= Enabled)  : ");

                // Disable check due to DHCP override.
                eth_wr(SM_ENET_CSR_CHECKSUM_CONFIG_REG__ADDR,0x0000000c,ENET,port,0);
            }
            else               printf("\n\r Policer Mode : Legacy");
            init_enet_plc(val);
        } // ended status read loop
        else if (val == 0x15)
        { printf("\n\r 88. Infinite Credits(excess)");
            printf("\n\r ");
            if(plc_dualbucket) {
                int green,yellow;
                green  = my_get_val("Enter bandwidth Green(mbps)  : 0x");
                yellow = my_get_val("Enter bandwidth Yellow(mbps) : 0x");
                cfg_plc_index(0x10, green, yellow, 1);
                cfg_plc_index(0x21, green, yellow, 1);
                cfg_plc_index(0x31, green, yellow, 1);
                cfg_plc_index(0x41, green, yellow, 1);
                cfg_plc_index(0x52, green, yellow, 1);
                cfg_plc_index(0x62, green, yellow, 1);
                cfg_plc_index(0x72, green, yellow, 1);
                cfg_plc_index(0x94, green, yellow, 1);
                cfg_plc_index(0xa5, green, yellow, 1);
                cfg_plc_index(0xb5, green, yellow, 1);
                cfg_plc_index(0xc5, green, yellow, 1);
                cfg_plc_index(0xd6, green, yellow, 1);
                cfg_plc_index(0xe6, green, yellow, 1);
                cfg_plc_index(0xf6, green, yellow, 1);
            }
            else{
                printf("Choose Policer Priority  Profile :\n\r");
                cfg_plc_index(0x0, my_get_val("Port 0 Max bandwidth : "), 0x0, 1); // Port 0
                cfg_plc_index(0x1, my_get_val("Port 1 Max bandwidth : "), 0x0, 1); // Port 1

                printf("Choose Policer Flowgroup  Profile :\n\r");
                cfg_plc_index(8 + 0x00, my_get_val("Enter MAC  bandwidth(mbps) : 0x"), 0,  1);
                cfg_plc_index(8 + 0x01, my_get_val("Enter IPv4 bandwidth(mbps) : 0x"), 0,  1);
                cfg_plc_index(8 + 0x02, my_get_val("Enter IPv6 bandwidth(mbps) : 0x"), 0,  1);

                cfg_plc_index(8 + 0x04, 10, 0x0, 1); // Port 1
                cfg_plc_index(8 + 0x05, 30, 0x0, 1);
                cfg_plc_index(8 + 0x06, 10, 0x0, 1);

                val = my_get_val("Enter Bandwidth perflow(mbps) : 0x");
                cfg_plc_index(24 + 0x1, val, 0x0, 1); // MAC
                cfg_plc_index(24 + 0x2, val, 0x0, 1); // IPv4-TCP
                cfg_plc_index(24 + 0x3, val, 0x0, 1); // IPv4-UDP
                cfg_plc_index(24 + 0x4, val, 0x0, 1); // IPv4
                cfg_plc_index(24 + 0x5, val, 0x0, 1); // IPv6-TCP
                cfg_plc_index(24 + 0x6, val, 0x0, 1); // IPv6-UDP
                cfg_plc_index(24 + 0x7, val, 0x0, 1); // IPv6    

                cfg_plc_index(24 + 0x9, val, 0x0, 1); // MAC
                cfg_plc_index(24 + 0xa, val, 0x0, 1); // IPv4-TCP
                cfg_plc_index(24 + 0xb, val, 0x0, 1); // IPv4-UDP
                cfg_plc_index(24 + 0xc, val, 0x0, 1); // IPv4
                cfg_plc_index(24 + 0xd, val, 0x0, 1); // IPv6-TCP
                cfg_plc_index(24 + 0xe, val, 0x0, 1); // IPv6-UDP
                cfg_plc_index(24 + 0xf, val, 0x0, 1); // IPv6    

            }

        } // ended status read loop
        else if (val == 0x16)
        {
            val = get_val();
            plc_rd_wr_test(val);
        }
        else if (val == 0x17)
        {
            int index = 0;
            int dropcnt = 0;
            int display = 1;
            printf("SM_ENET_CSR_RSIF_FINT_REG1__ADDR -> ");putnum(eth_rd(SM_ENET_CSR_RSIF_FINT_REG1__ADDR,ENET,port,display));  printf("\n\r");
            printf("SM_ENET_CSR_RSIF_POLICER_STSREG0__ADDR -> ");putnum(eth_rd(SM_ENET_CSR_RSIF_POLICER_STSREG0__ADDR,ENET,port,display));  printf("\n\r");
            printf("SM_ENET_CSR_RSIF_POLICER_STSREG1__ADDR -> ");putnum(eth_rd(SM_ENET_CSR_RSIF_POLICER_STSREG1__ADDR,ENET,port,display));  printf("\n\r");
            // printf(" -> ");putnum(eth_rd(,ENET,port,display));  printf("\n\r");

            for(index = 0; index < 400 ;index++) {
                dropcnt = enet_plc_rd(index, 2); // dont print : Read drop count
                if(dropcnt != 0) {
                    printf("Policer Index : 0x");putnum(index);printf(" -> ");putnum(dropcnt);printf("\n\r");
                }
            }
        }
        else if (val == 0x18)
        {
            // Disable policer
            eth_wr(SM_ENET_CSR_RSIF_POLICER_REG7__ADDR,0x0,ENET,port,0);
            int index;
            for(index = 0; index < 399 ;index++) {
                cfg_plc_index(index, 0, 0, 0); // Print drop counts only
            }
        }
        else if (val == 0x20)
        {
            init_enet_ptp();
        }
        else if (val == 0x21)
        {
            ptp_read_stat();
        }
        else if (val == 0x30)
        {
            set_test_profile();
        }
        else if (val == 0x31)
        {
            printf("\n\r Memory read address : ");
            read_address = 0x9d000000 + get_val();
            printf("\n\r # Dwords : ");
            val = get_val();
            for(j=0;j<val;j++){
                read_address = read_address + 16;
                printf("\n\r read_address ");putnum(read_address);printf(" : ");
                for(i=0;i<4;i++){
                    putnum(myread(read_address+i*4,0));
                    printf("_");
                }
            }
        }
        /*      else if (val == 0x36) // read loop
                {
                printf("\n\rEnter the number of packets to be enqueued\n\r");
                iter = get_val();
                for (it=0;it<iter;it++) {
                size1 = msg_gen(0, &size, &enq_msg[0], 0, 0, num_buffers);
        //if (iter == 1) {print_msg(&enq_msg[0]);}
        enq_message(WQID4, size1, &enq_msg[0]);
        }
        read(enet_base_addr + SM_QMI_SLAVE_STSSSQMIWQNUMENTRIES0__ADDR); // STSSSQMIWQNUMENTRIES for WQPBID0,1,2,3
        } // ended read loop
        */
        else if (val == 0x37) // read loop
        {
            fail_cnt = 0;
            it = 0;
            printf("\n\renter port whose mdio to be used \n\r");
            port = get_val();
            printf("\n\r Phy addr and reg address combined.in [0:31] format,[0:18] = 19'b0, [19:23]= Phyaddress, [24:26] = 3'b0, [27:31] = reg address in (hex)=?\n\r");
            ind_address = get_val();
            printf("\n\rEnter the number of iterations\n\r");
            iter = get_val();
            for (it=0;it<iter;it++) {
                read_data = mdio_rd(ind_address,ENET,port,0);
                if ((read_data && 0x00000002) == 0) {fail_cnt++;printf("\n\rvalue read is");putnum(read_data);printf("\n\r");break;}
            }
            if (fail_cnt == 0) { printf("\n\rTest Pass\n\r");}
            else               { printf("\n\rTest Fail\n\r");}
        } // ended read loop

        else if (val == 0x38) // send pause frame in TX
        {
            //	  send_pause_frame(0);
        }
        else if (val == 40){ // avb config
            int display = 0;
            eth_wr(SM_ENET_CSR_AVB_PER_Q_CONFIG1_0__ADDR,0x55555555,ENET,port,display);//arb_type  
            //eth_wr(SM_ENET_CSR_AVB_PER_Q_CONFIG1_1__ADDR,0x55555555,ENET,port,display);//arb_type
            eth_wr(SM_ENET_CSR_AVB_COMMON_CONFIG1_0__ADDR,0x10000000,ENET,port,display);//mac_speed 
            //eth_wr(SM_ENET_CSR_AVB_COMMON_CONFIG1_1__ADDR,0x10000000,ENET,port,display);//mac_speed
            eth_wr(SM_ENET_CSR_AVB_COMMON_CONFIG2_0__ADDR,0x2000000a,ENET,port,display);//mac_speed 
            //eth_wr(SM_ENET_CSR_AVB_COMMON_CONFIG2_1__ADDR,0x2000000a,ENET,port,display);//mac_speed
            eth_wr(SM_ENET_CSR_AVB_PER_Q_IDLE_SLOPE0_0__ADDR,0x00000001,ENET,port,display);
            //eth_wr(SM_ENET_CSR_AVB_PER_Q_IDLE_SLOPE0_1__ADDR,0x00000001,ENET,port,display);
        }

        /*        else if (val == 0x41) // read loop
                  {
        // dstqid0 = 0xc00; dstqid1 = 0xc00;
        // configure_cle_bypass();
        eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,0x00000c00,ENET,port,display); 
        eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,0x00000c00,ENET,port,display); 
        val = my_get_val("\n\r # ENTER 0 for num interation");
        do {
        // Poll Interrupt.
        intr_stat = qm_poll_deq_intr();
        num_msg = read32(0x90000004) & 0x0000FFFF;
        num_msg = num_msg/2;
        if(display_en) {printf("\n\r num_msg =");putnum(num_msg);printf("\n\r");}
        //printf("\n\r # ENTER 1 to enque to ENET, 0 to exit ");
        if(1 || my_get_val("\n\r # ENTER 1 to enque to ENET, 0 to exit ")){
        for (i = 0; i < num_msg; i++) {
        read_dequeue_msg(WQID0, &size1, &deq_msg[0]);
        //enqueue_msg_ctm(WQID4, size1, &deq_msg[0]);
        write_enqueue_msg(WQID4, size1, &deq_msg[0]);
        }
        }
        if(val != 0x88)val--;// Infinite loop  for 88
        }while (val); 
        set_cle_bypass_default();
        configure_cle_bypass();
        }
        */

        else if (val == 0x42)    //// SerDes read
        {
            printf("\n\rwhat port do you like to access (port 0,1,2,3)?\n\r");
            port = get_val();

            printf("\n\rNote: PHY SerDes has two base addres for rxtx_reg (0x400 and 0x600), one base address for CMU (0x0)\n\r");
            printf("\n\rFor each configuration, you must write one for 0x400 and one for 0x600\n\r");
            printf("\n\rPHY SerDes read address in (hex)=?\n\r");
            ind_address = get_val();
            ind_data = enet_sds_ind_csr_reg_rd("SerDes_reg", ind_address,ENET,port,0);
            printf("\n\rdata read is = 0x");putnum(ind_data);printf("\n\r");
        } 

        else if (val == 0x43)    //// SerDes write
        {
            printf("\n\rwhat port do you like to access (port 0,1,2,3)?\n\r");
            port = get_val();

            printf("\n\rNote: PHY SerDes has two base addres for rxtx_reg (0x400 and 0x600), one base address for CMU (0x0)\n\r");
            printf("\n\rFor each configuration, you must write one for 0x400 and one for 0x600\n\r");
            printf("\n\r Phy Write address in (hex)=?\n\r");
            ind_address = get_val();
            printf("\n\r enter write data=?\n\r");
            ind_data = get_val();
            printf("\n\rwriting....\n\r");
            enet_sds_ind_csr_reg_wr("sedes_reg",ind_address,ind_data,ENET,port,0);
            printf("\n\rwritten data = 0x");putnum(ind_data);printf(" at address = 0x");putnum(ind_address);printf("\n\r");
        } 
        else if (val == 0x88) {
            printf("Enter Debug bus : 0x");
            val = get_val();
            printf("\n\r");
            eth_wr(SM_GLBL_DIAG_CSR_CFG_DIAG_SEL__ADDR,val,ENET,port,0);
            eth_rd(SM_GLBL_DIAG_CSR_DBG_BLOCK_AXI__ADDR,ENET,port,1);
            eth_rd(SM_GLBL_DIAG_CSR_DBG_BLOCK_NON_AXI__ADDR,ENET,port,1);

        }

        else if (val == 0x89) {
            int loop = get_val();
            eth_rd(SM_GLBL_DIAG_CSR_DBG_BLOCK_AXI__ADDR,ENET,port,1);

            do {
                eth_rd(SM_GLBL_DIAG_CSR_DBG_BLOCK_NON_AXI__ADDR,ENET,port,1);
                loop --;
            }while(loop != 0);
        }
        /*
           else if (val == 0x101)  //md:  
           {
           printf("Set MAC loopback mode:\n");
        //          set_mac_level_lpbk();
        }
        else if (val == 0x102)    
        {
        printf("ReSet MAC loopback mode:\n"); 
        //         reset_mac_level_lpbk();
        }
        */
        else if (val == 0x103)    
        {
            //printf("Set PHY loopback mode:\n"); 
            //set_phy_level_lpbk();          

            printf("Set serdes level tx2rx loopback mode\n"); 
            set_serdes_lpbk();
        }
        else if (val == 0x104)   
        {
            int tmp;
            printf("\n0->Set_MAC_lpbk 1->Set_PHY_lpbk 2->Reset_MAC_lpbk 3->Reset_PHY_lpbk\n");
            printf(" 4->Set_SERDES_Tx-2-Rx_lpbk 5->ReSet_SERDES_Tx-2-Rx_lpbk\n");
            tmp = get_val();
            if(tmp == 0) {
                printf("Set MAC loopback mode\n"); 
                set_mac_level_lpbk();
            }
            else if(tmp == 1) {
                printf("Set PHY loopback mode\n"); 
                set_phy_level_lpbk();
            }
            else if(tmp == 2) {
                printf("ReSet MAC loopback mode\n"); 
                reset_mac_level_lpbk();
            }    
            else if(tmp == 3) {
                printf("ReSet PHY loopback mode\n"); 
                reset_phy_level_lpbk();
            }  
            else if(tmp == 4) {
                printf("Set SERDES Level Tx-2-Rx loopback mode\n"); 
                set_serdes_lpbk();
            }
            else if(tmp == 5) {
                printf("ReSet SERDES Level Tx-2-Rx loopback mode\n"); 
                reset_serdes_lpbk();
            } 

        }
        else if (val == 0x105)    
        {
            int tmp;
            printf("\n0->XFI-SGMII 1->SATA-SGMII 2->Both\n");
            tmp = get_val();
            if(tmp == 0) {
                printf("\nSend Packets to XFI-SGMII\n");
                eth_tx2rx_lpbk_test_xfi_1g();
            }
            else if(tmp == 1) {
                printf("\nSend Packets to SATA-SGMII\n");
                eth_tx2rx_lpbk_test_sata_1g_dbg();
                total_err_count_result();
            }
            else if(tmp == 2) {
                printf("\nSend Packets to both SATA/XFI SGMII ports\n");
                eth_tx2rx_lpbk_test_xfi_1g();
                eth_tx2rx_lpbk_test_sata_1g();
            }
        }
#if 1      
        else if (val == 0x106)    
        {
            printf("Read From PHY\n"); 
            printf("\nEnter PHY Address (hex): \n");
            phy_addr = get_val();
            printf("\nEnter Reg Address (hex): \n");
            phy_reg = get_val();

            ind_address = ((phy_addr << 8) | phy_reg);

            ind_data = mdio_rd(ind_address,MENET,0,0);
            printf("\nphy_addr:0x%x phy_reg:0x%x ind_address:0x%x ind_data:0x%x \n",phy_addr,phy_reg,ind_address,ind_data);

        }
        else if (val == 0x107)    
        {
            printf("\nEnter PHY Address (hex): \n");
            phy_addr = get_val();
            printf("\nEnter Reg Address (hex): \n");
            phy_reg = get_val();
            printf("\nEnter Write Value (hex): \n");
            ind_data = get_val();

            ind_address = ((phy_addr << 8) | phy_reg);
            mdio_wr(ind_address,ind_data,MENET,0,0);
            printf("\nphy_addr:0x%x phy_reg:0x%x ind_address:0x%x ind_data:0x%x \n",phy_addr,phy_reg,ind_address,ind_data);
        }
        else if (val == 0x108)    
        {

            int count=0;
            printf("MDIO Regress Test\n");
            printf("\nEnter IterationNo: (hex): ");
            count = get_val();
            //mdio_rgmii_phyId_regression_test(0x2, 2, count);
            mdio_sgmii_phyId_regression_test(0x11, 2, count);
            mdio_sgmii_phyId_regression_test(0x12, 2, count);
            mdio_sgmii_phyId_regression_test(0x13, 2, count);
            mdio_sgmii_phyId_regression_test(0x14, 2, count);
            mdio_sgmii_phyId_regression_test(0x15, 2, count);
            mdio_sgmii_phyId_regression_test(0x16, 2, count);
            mdio_sgmii_phyId_regression_test(0x17, 2, count);
            mdio_sgmii_phyId_regression_test(0x18, 2, count);
        }
        else if (val == 0x109)    
        {
            //printf("Disbale MDIO NegEdge\n");
            //disable_mgmt_neg_edge(); 
            //reg_full_config();
            config_phy_non_auto_neg_mode();
        }
        else if (val == 0x307)    
        {print_stat_xg();
        }      
        else if (val == 0x110) 
        {
            /*
            ///
            printf("\nEnter PHY Address (hex): \n");
            phy_reg = get_val();
            for(phy_addr=0x11; phy_addr<0x19; phy_addr++) {
            ind_address = ((phy_addr << 8) | phy_reg);
            ind_data = mdio_rd(ind_address,MENET,0,0);
            printf("\nphy_addr:0x%x phy_reg:0x%x ind_address:0x%x ind_data:0x%x \n",phy_addr,phy_reg,ind_address,ind_data);
            }
            ///
            */
            int count=0;
            printf("Auto-Neg Regress Test\n");
            printf("\nEnter IterationNo: (hex): ");
            count = get_val();          
            phy_addr= 0x2; 
            while (count) {
                phy_reg = 17;
                ind_address = ((phy_addr << 8) | phy_reg);
                ind_data = mdio_rd(ind_address,MENET,0,0);
                if((ind_data & 0x8000) && (ind_data & 0x2000))
                    printf("Speed:1G FD ");
                else if((ind_data & 0x4000) && (ind_data & 0x2000))
                    printf("Speed:100M FD ");
                else if(ind_data & 0x4000) 
                    printf("Speed:100M HD ");                  
                else if(ind_data & 0x2000) 
                    printf("Speed:10M FD ");
                else 
                    printf("Speed:10M HD ");
                phy_reg = 0x1;
                ind_address = ((phy_addr << 8) | phy_reg);
                ind_data = mdio_rd(ind_address,MENET,0,0);
                if(ind_data & 0x0020) 
                    printf("PhyAddr:%x,AutoNegCompleteDone,RD:0x%x CNT:%d,PASS \n",phy_addr,ind_data,count);
                else
                    printf("PhyAddr:%x,AutoNegCompleteNotDone,RD:0x%x CNT:%d,FAIL\n",phy_addr,ind_data,count);
                count--;
            }
            /*
            // SATA Port
            phy_reg = 0x1;
            for(phy_addr=0x11; phy_addr<0x15; phy_addr++) {
            ind_address = ((phy_addr << 8) | phy_reg);
            ind_data = mdio_rd(ind_address,MENET,0,0);
            if(ind_data & 0x0020) {
            printf("SATA-SGMII-PhyAddr:%x,Auto-Neg-Complete-Done,ReadData:0x%x,PASS \n",phy_addr,ind_data);
            }
            else {
            printf("SATA-SGMII-PhyAddr:%x,Auto-Neg-Complete-NotDone,ReadData:0x%x,FAIL\n",phy_addr,ind_data);
            }
            }
            printf("\n");
            //XFI Ports
            for(phy_addr=0x15; phy_addr<0x19; phy_addr++) {
            ind_address = ((phy_addr << 8) | phy_reg);
            ind_data = mdio_rd(ind_address,MENET,0,0);
            if(ind_data & 0x0020) {
            printf("XFI-SGMII-PhyAddr:%x,Auto-Neg-Complete-Done,ReadData:0x%x,PASS \n",phy_addr,ind_data);
            }
            else {
            printf("XFI-SGMII-PhyAddr:%x,Auto-Neg-Complete-NotDone,ReadData:0x%x,FAIL\n",phy_addr,ind_data);
            }
            }

            printf("\n");
            for(port=0; port<4;port++) {
            read_data = mdio_rd(0x1e01,XGENET,port,0);
            if(read_data & 0x0020) 
            printf("XFI-SGMII-CORE-PortNo:%d,Auto-Neg-Complete-Done,ReadData:0x%x,PASS\n",port,read_data);
            else 
            printf("XFI-SGMII-CORE-PortNo:%d,Auto-Neg-Complete-NotDone,ReadData:0x%x,FAIL\n",port,read_data);
            }
            printf("\n");
            for(port=0; port<4;port++) {
            read_data = mdio_rd(0x1e01,ENET,port,0);
            if(read_data & 0x0020) 
            printf("SATA-SGMII-CORE-PortNo:%d,Auto-Neg-Complete-Done,ReadData:0x%x,PASS\n",port,read_data);
            else 
            printf("SATA-SGMII-CORE-PortNo:%d,Auto-Neg-Complete-Done,ReadData:0x%x,FAIL\n",port,read_data);
            }
            */
        }
        else if (val == 0x111) //qm_dump pb state
        {
            err_info_t ei;

            qm_dump_pb_state(1, 0, 0);
            qm_dump_qstate(1, 1, 1);
            qm_dump_qstate(1, 4, 32);
            qm_dump_qstate(1, 4, 64);

            // qm_dump_pb_state(0, 0, 0);
            // qm_dump_pb_state(0, 0, 0x21);
            // qm_dump_qstate(0, 2, 32);
            // qm_dump_qstate(0, 1, 1);
            /*
               printf("\r\n ---- QM-0 queue state dump:\r\n"); 
               qm_dump_qstate(0, 4, 32);
               qm_dump_qstate(0, 1, 1);
               printf("\r\n ---- QM-2 queue state dump:\r\n"); 
               qm_dump_qstate(2, 4, 32);
               qm_dump_qstate(2, 1, 1);
               */
            // printf("\r\n ---- QM1 queue statedump:\r\n"); 
            // qm_dump_pb_state(1, 0, 0);
            // qm_dump_pb_state(1, 0, 8);
            // qm_dump_pb_state(1, 1, 0);
            // qm_dump_pb_state(1, 1, 8);
            // qm_dump_qstate(1, 4, 32);
            // qm_dump_qstate(1, 1, 1);

            //qm_chk_errq(0, &ei);
            //qm_dump_qstate(0, 1, QM_ERROR_QID);
            //qm_dump_qstate(0, 1, QM_E_ERROR_QID);
            //qm_dump_qm_errq(1);
            //qm_err_dump(1);
        }
#endif

        /*
           else if (val == 0x200)    
           {
           printf("OPTIONAL : 201 rst_sds      - Reset Serdes \n");
           printf("OPTIONAL : 202 rst_sds_rxa  - Reset Serdes All 4 port Analog only\n");
           printf("OPTIONAL : 203 rst_sds_rxda - Reset Serdes All 4 port Digital and Analog\n");
           printf("OPTIONAL : 204 pll_status   - Prints PLL status of both Instances \n");
           printf("OPTIONAL : 205 link_status  - Prints Link Status of four ports\n");
           printf("OPTIONAL : 206 mac_stat     - Prints MAC  Statistics of four ports\n");
           printf("OPTIONAL : 207 print_stat   - Prints Full Statistics \n");
           printf("OPTIONAL : 208 print_calib  - Prints Serdes Calibration settings \n");
           printf("OPTIONAL : 209 fix_crc      - Fixes CRC error by reseting serdes \n");
           }
           else if (val == 0x201)    
           {rst_sds();
           }
           else if (val == 0x202)    
           {rst_sds_rxa();
           }
           else if (val == 0x203)    
           {rst_sds_rxda();
           }
           else if (val == 0x204)    
           {pll_status();
           }
           else if (val == 0x205)    
           {link_status();
           }
           else if (val == 0x206)    
           {mac_stat();
           }
           else if (val == 0x207)    
           {print_stat();
           }
           else if (val == 0x208)    
           {print_calib();
           }
           else if (val == 0x209)    
           { //fix_crc();
           }
           else if (val == 0x300)    
           {
           printf("OPTIONAL : 301 rst_sds_xg      - Reset Serdes \n");
           printf("OPTIONAL : 302 rst_sds_rxa_xg  - Reset Serdes All 4 port Analog only\n");
           printf("OPTIONAL : 303 rst_sds_rxda_xg - Reset Serdes All 4 port Digital and Analog\n");
           printf("OPTIONAL : 304 pll_status_xg   - Prints PLL status of both Instances \n");
           printf("OPTIONAL : 305 link_status_xg  - Prints Link Status of four ports\n");
           printf("OPTIONAL : 306 mac_stat_xg     - Prints MAC  Statistics of four ports\n");
           printf("OPTIONAL : 307 print_stat_xg   - Prints Full Statistics \n");
           printf("OPTIONAL : 308 print_calib_xg  - Prints Serdes Calibration settings \n");
           printf("OPTIONAL : 309 fix_crc_xg      - Fixes CRC error by reseting serdes \n");
           }
           else if (val == 0x301)    
           {rst_sds_xg();
           }
           else if (val == 0x302)    
           {rst_sds_rxa_xg();
           }
           else if (val == 0x303)    
           {rst_sds_rxda_xg();
           }
           else if (val == 0x304)    
           {pll_status_xg();
           }
           else if (val == 0x305)    
           {link_status_xg();
           }
           else if (val == 0x306)    
           {mac_stat_xg();
           }
           else if (val == 0x307)    
        {print_stat_xg();
        }
        else if (val == 0x308)    
        {print_calib_xg();
        }
        else if (val == 0x309)    
        {fix_crc_xg();
        } */

    }while (quit_r != 0x71);//end while
}
void diagmod_sgmii () {
    int port;
    int data;
    int itr =my_get_val("Select ITR :");
    int last_val,rd_data;
    // port = my_get_val("Select Port :");
    port = 0;
    data = my_get_val("Select MUX :");
    eth_wr(SM_GLBL_DIAG_CSR_CFG_DIAG_SEL__ADDR,data,ENET,port,1); // CFG_DIAG_SEL For bringing rx_dv at the i/p of mac on the dbg bus
    last_val = eth_rd(SM_GLBL_DIAG_CSR_DBG_BLOCK_NON_AXI__ADDR,ENET,port,1); // CFG_DIAG_SEL For bringing rx_dv at the i/p of mac on the dbg bus
    while(itr){
        rd_data =  eth_rd(SM_GLBL_DIAG_CSR_DBG_BLOCK_NON_AXI__ADDR,ENET,port,1);
        if((((last_val& 0xFFFF    ) != (rd_data & 0xFFFF    )) && (data&0x1 == 0)) ||
                (((last_val& 0xFFFF0000) != (rd_data & 0xFFFF0000)) && (data&0x1 == 1))
          ){
            printf("[%x] : %x\n",data,rd_data);
            last_val = rd_data;
        }
        itr--;
    }
}
void mac_txen () {
    int data32;
    int port;
    for(port=FIRST_PORT;port<=LAST_PORT;port++){
        data32 = mcxmac_ind_rd(ind_address,ENET,port,0);
        data32 = FIELD_MAC_CONFIG_1_TX_EN_SET(data32,0);
        mcxmac_ind_wr(PE_MCXMAC_MAC_CONFIG_1__ADDR,data32,ENET,port,0); 

        //delay(100);
        USDELAY(100);
        data32 = FIELD_MAC_CONFIG_1_TX_EN_SET(data32,1);
        mcxmac_ind_wr(PE_MCXMAC_MAC_CONFIG_1__ADDR,data32,ENET,port,0); 
    }
}
void sweep_full() {
    int itr = my_get_val("Num of iterations:");
    sweep_port(0,itr); // IDLE from IXIA - PRBS DISABLED
    sweep_port(1,itr); // IDLE from IXIA - PRBS DISABLED
    sweep_port(2,itr); // IDLE from IXIA - PRBS DISABLED
    sweep_port(3,itr); // IDLE from IXIA - PRBS DISABLED
}
void sweep_sel() {
    int itr = my_get_val("Num of iterations:");
    int port = my_get_val("Sel Port:");
    sweep_port(port,itr); // IDLE from IXIA - PRBS DISABLED
    sweep_port(port,itr); // IDLE from IXIA - PRBS DISABLED
    sweep_port(port,itr); // IDLE from IXIA - PRBS DISABLED
}

void sweep_port(int port,int itr) {
    // PQ REG
    int START_VAL0 = 4;
    int END_VAL0 = 24;
    int STEP0 = 2;
    int swp_var0;
    // CTLE
    int START_VAL1 = 4;
    int END_VAL1 = 28;
    int STEP1 = 4;
    int swp_var1;
    int data32;
    int NUM_SAMPLE = 2;
    //int result[END_VAL0][END_VAL1];
    //int result[24][28];
    int result[11][7];
    int channel_offset = (port & 0x1) * 0x200;


    printf("\n====================\n");
    printf("--  CTLE-PQ REG Sweep test : Port%d",port);
    printf("\n====================\n");

    // Enable PRBS
    //if(prbs) pcs_prbs_en(port);

    for(swp_var1=START_VAL1;swp_var1<=END_VAL1;swp_var1+=STEP1){
        // Update Sweep Val
        data32 = enet_sds_ind_csr_reg_rd("RXTX_REG1", KC_SERDES_RXTX_REGS_RXTX_REG1__ADDR + channel_offset,ENET,port,0);
        data32 = FIELD_RXTX_REG1_CTLE_EQ_SET(data32,swp_var1);
        enet_sds_ind_csr_reg_wr("RXTX_REG1", KC_SERDES_RXTX_REGS_RXTX_REG1__ADDR + channel_offset,data32,ENET,port,0);

        swp_var0=START_VAL0;
        for(swp_var0=START_VAL0;swp_var0<=END_VAL0;swp_var0+=STEP0){
            // Update Sweep Val
            data32 = enet_sds_ind_csr_reg_rd("RXTX_REG125", KC_SERDES_RXTX_REGS_RXTX_REG125__ADDR+ channel_offset,ENET,port,0);
            data32 = FIELD_RXTX_REG125_PQ_REG_SET(data32,swp_var0);
            enet_sds_ind_csr_reg_wr("RXTX_REG125", KC_SERDES_RXTX_REGS_RXTX_REG125__ADDR,data32+ channel_offset,ENET,port,0);
            // Wait for  Stability
            //delay(400);
            USDELAY(400);
            result[(swp_var0-START_VAL0)/STEP0][(swp_var1-START_VAL1)/STEP1] = configure_sgmii(port,0x0, 0);
            int i;
            for(i=1;i<itr;i++){
                serdes_reset_rxd(port,0);
                result[(swp_var0-START_VAL0)/STEP0][(swp_var1-START_VAL1)/STEP1] += configure_sgmii(port,0x0, 0);
            }
        }
    }
    // Disable PRBS
    // if(prbs) pcs_prbs_dis(port);

    // Print Stat
    printf("--  PQ(Vertical) CTLE(Horizontal) REG Sweep Result :\n",port);
    for(swp_var0=START_VAL0;swp_var0<=END_VAL0;swp_var0+=STEP0){
        if(swp_var0==START_VAL0) {
            printf("\n CTLE : ",swp_var0);
            for(swp_var1=START_VAL1;swp_var1<=END_VAL1;swp_var1+=STEP1){
                printf("%8x ", swp_var1);
            }
        }
        printf("\n %8x : ",swp_var0);
        for(swp_var1=START_VAL1;swp_var1<=END_VAL1;swp_var1+=STEP1){
            printf("%d ", result[(swp_var0-START_VAL0)/STEP0][(swp_var1-START_VAL1)/STEP1]);
        }
    }
    printf("\n \n done\n\n ");

}
void gen_avg_val_1g(int port){
    int avg_loop;
    int MAX_LOOP = 10;
    int timeout = 20;
    int lat_do,lat_xo,lat_eo,lat_so;
    int lat_de,lat_xe,lat_ee,lat_se;
    int sum_cal = 0;
    int lat_do_itr,lat_xo_itr,lat_eo_itr,lat_so_itr;
    int lat_de_itr,lat_xe_itr,lat_ee_itr,lat_se_itr;
    int sum_cal_itr = 0;
    int data32;
    int display =0;
    int pcs_rxfault = 0;
    int pcs_txfault = 0;
    int fail_even = 0;
    int fail_odd = 0;
    uint32_t inst, inst_base;
    unsigned int  wr_val, rd_val;


    lat_do_itr = 0;lat_de_itr = 0;
    lat_xo_itr = 0;lat_xe_itr = 0;
    lat_eo_itr = 0;lat_ee_itr = 0;
    lat_so_itr = 0;lat_se_itr = 0;
    sum_cal_itr = 0;

    lat_do = 0;lat_de = 0;
    lat_xo = 0;lat_xe = 0;
    lat_eo = 0;lat_ee = 0;
    lat_so = 0;lat_se = 0;

    sum_cal   = 0;
    avg_loop  = MAX_LOOP;
    timeout = 20;


    printf("\nGenerating Average calibration Value for Port %d \n",port);

    inst = port & 0x1;
    inst_base = 0x0400 + inst*0x0200;
    // Enable RX Hi-Z termination enable
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg12", inst_base + 12*2,ENET,port,display);
    wr_val = sm_enet_set(rd_val,1, 1, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg12", inst_base + 12*2, wr_val,ENET,port,display);
    // Turn off DFE 
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg28", inst_base + 28*2,ENET,port,display);
    wr_val = sm_enet_set(rd_val, 0x0, 15, display); 
    enet_sds_ind_csr_reg_wr("rxtx_reg28", inst_base + 28*2, wr_val,ENET,port,display);
    // DFE Presets to zero 
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg31", inst_base + 31*2,ENET,port,display);
    wr_val = sm_enet_set(rd_val, 0x0, 15, display); 
    enet_sds_ind_csr_reg_wr("rxtx_reg31", inst_base + 31*2, wr_val,ENET,port,display);


    while (avg_loop > 0) {
        force_lat_summer_cal(ENET,port,0);
        //delay(4000);
        USDELAY(8000);
        data32 = enet_sds_ind_csr_reg_rd("RXTX_REG21", KC_SERDES_RXTX_REGS_RXTX_REG21__ADDR+ inst*0x0200,ENET,port,display);
        lat_do_itr = FIELD_RXTX_REG21_DO_LATCH_CALOUT_RD(data32);
        lat_xo_itr = FIELD_RXTX_REG21_XO_LATCH_CALOUT_RD(data32);
        fail_odd   = FIELD_RXTX_REG21_LATCH_CAL_FAIL_ODD_RD(data32);

        data32 = enet_sds_ind_csr_reg_rd("RXTX_REG22", KC_SERDES_RXTX_REGS_RXTX_REG22__ADDR+ inst*0x0200,ENET,port,display);
        lat_eo_itr = FIELD_RXTX_REG22_EO_LATCH_CALOUT_RD(data32);
        lat_so_itr = FIELD_RXTX_REG22_SO_LATCH_CALOUT_RD(data32);
        fail_even  = FIELD_RXTX_REG22_LATCH_CAL_FAIL_EVEN_RD(data32);

        data32 = enet_sds_ind_csr_reg_rd("RXTX_REG23", KC_SERDES_RXTX_REGS_RXTX_REG23__ADDR+ inst*0x0200,ENET,port,display);
        lat_de_itr = FIELD_RXTX_REG23_DE_LATCH_CALOUT_RD(data32);
        lat_xe_itr = FIELD_RXTX_REG23_XE_LATCH_CALOUT_RD(data32);

        data32 = enet_sds_ind_csr_reg_rd("RXTX_REG24", KC_SERDES_RXTX_REGS_RXTX_REG24__ADDR+ inst*0x0200,ENET,port,display);
        lat_ee_itr = FIELD_RXTX_REG24_EE_LATCH_CALOUT_RD(data32);
        lat_se_itr = FIELD_RXTX_REG24_SE_LATCH_CALOUT_RD(data32);

        data32  = enet_sds_ind_csr_reg_rd("RXTX_REG121", KC_SERDES_RXTX_REGS_RXTX_REG121__ADDR+ inst*0x0200,ENET,port,display);
        sum_cal_itr = FIELD_RXTX_REG121_SUMOS_CAL_CODE_RD(data32);


        if ((fail_even == 0 || fail_even ==1) && (fail_odd == 0 || fail_odd ==1)) {
            lat_do += lat_do_itr;
            lat_xo += lat_xo_itr;
            lat_eo += lat_eo_itr;
            lat_so += lat_so_itr;
            lat_de += lat_de_itr;
            lat_xe += lat_xe_itr;
            lat_ee += lat_ee_itr;
            lat_se += lat_se_itr;
            sum_cal += sum_cal_itr;
            // printf("\n Iteration Value : %d\n",avg_loop);
            // printf("DO=0x%x  XO=0x%x  EO=0x%x  SO=0x%x  \n",lat_do_itr,lat_xo_itr,lat_eo_itr,lat_so_itr);
            // printf("DE=0x%x  XE=0x%x  EE=0x%x  SE=0x%x  \n",lat_de_itr,lat_xe_itr,lat_ee_itr,lat_se_itr);
            // printf("sum_cal = 0x%x\n",sum_cal_itr);
            avg_loop--;
        }
        else { 
            lprintf(8, "\n Iteration Failed : %d\n",avg_loop);
            avg_loop--;
            timeout--;
        }
        if(timeout == 0) {
            lprintf(8, "FAILED for port %",port);
            break; 
        }

        serdes_reset_rxd(port,0);
    }

    // Update with Average Value
    //--------------------------------------------------
    // Latch Calibration Value
    data32 = enet_sds_ind_csr_reg_rd("RXTX_REG127", KC_SERDES_RXTX_REGS_RXTX_REG127__ADDR+ inst*0x0200,ENET,port,display);
    data32 = FIELD_RXTX_REG127_DO_LATCH_MANCAL_SET(data32,get_avg_1g(lat_do,MAX_LOOP));
    data32 = FIELD_RXTX_REG127_XO_LATCH_MANCAL_SET(data32,get_avg_1g(lat_xo,MAX_LOOP));
    enet_sds_ind_csr_reg_wr("RXTX_REG127", KC_SERDES_RXTX_REGS_RXTX_REG127__ADDR+ inst*0x0200, data32,ENET,port,display);

    data32 = enet_sds_ind_csr_reg_rd("RXTX_REG128", KC_SERDES_RXTX_REGS_RXTX_REG128__ADDR+ inst*0x0200,ENET,port,display);
    data32 = FIELD_RXTX_REG128_EO_LATCH_MANCAL_SET(data32,get_avg_1g(lat_eo,MAX_LOOP));
    data32 = FIELD_RXTX_REG128_SO_LATCH_MANCAL_SET(data32,get_avg_1g(lat_so,MAX_LOOP));
    enet_sds_ind_csr_reg_wr("RXTX_REG128", KC_SERDES_RXTX_REGS_RXTX_REG128__ADDR+ inst*0x0200, data32,ENET,port,display);

    data32 = enet_sds_ind_csr_reg_rd("RXTX_REG129", KC_SERDES_RXTX_REGS_RXTX_REG129__ADDR+ inst*0x0200,ENET,port,display);
    data32 = FIELD_RXTX_REG129_DE_LATCH_MANCAL_SET(data32,get_avg_1g(lat_de,MAX_LOOP));
    data32 = FIELD_RXTX_REG129_XE_LATCH_MANCAL_SET(data32,get_avg_1g(lat_xe,MAX_LOOP));
    enet_sds_ind_csr_reg_wr("RXTX_REG129", KC_SERDES_RXTX_REGS_RXTX_REG129__ADDR+ inst*0x0200, data32,ENET,port,display);

    data32 = enet_sds_ind_csr_reg_rd("RXTX_REG130", KC_SERDES_RXTX_REGS_RXTX_REG130__ADDR+ inst*0x0200,ENET,port,display);
    data32 = FIELD_RXTX_REG130_EE_LATCH_MANCAL_SET(data32,get_avg_1g(lat_ee,MAX_LOOP));
    data32 = FIELD_RXTX_REG130_SE_LATCH_MANCAL_SET(data32,get_avg_1g(lat_se,MAX_LOOP));
    enet_sds_ind_csr_reg_wr("RXTX_REG130", KC_SERDES_RXTX_REGS_RXTX_REG130__ADDR+ inst*0x0200, data32,ENET,port,display);

    // Summer Calibration Value
    data32 = enet_sds_ind_csr_reg_rd("RXTX_REG14", KC_SERDES_RXTX_REGS_RXTX_REG14__ADDR+ inst*0x0200,ENET,port,display);
    data32 = FIELD_RXTX_REG14_CLTE_LATCAL_MAN_PROG_SET(data32,get_avg_1g(sum_cal,MAX_LOOP));
    enet_sds_ind_csr_reg_wr("RXTX_REG14", KC_SERDES_RXTX_REGS_RXTX_REG14__ADDR+ inst*0x0200, data32,ENET,port,display);

    printf("\nAverage Value : \n");
    printf("DO=0x%x  XO=0x%x  EO=0x%x  SO=0x%x  \n",get_avg_1g(lat_do,MAX_LOOP),get_avg_1g(lat_xo,MAX_LOOP),get_avg_1g(lat_eo,MAX_LOOP),get_avg_1g(lat_so,MAX_LOOP));
    printf("DE=0x%x  XE=0x%x  EE=0x%x  SE=0x%x  \n",get_avg_1g(lat_de,MAX_LOOP),get_avg_1g(lat_xe,MAX_LOOP),get_avg_1g(lat_ee,MAX_LOOP),get_avg_1g(lat_se,MAX_LOOP));
    //printf("sum_cal = 0x%x\n",get_avg_1g(sum_cal,MAX_LOOP));
    USDELAY(8000);
    // Manual Summer Calibration
    data32 = enet_sds_ind_csr_reg_rd("RXTX_REG14", KC_SERDES_RXTX_REGS_RXTX_REG14__ADDR+ inst*0x0200,ENET,port,display);
    data32 = FIELD_RXTX_REG14_CTLE_LATCAL_MAN_ENA_SET(data32,0x1);
    enet_sds_ind_csr_reg_wr("RXTX_REG14", KC_SERDES_RXTX_REGS_RXTX_REG14__ADDR+ inst*0x0200, data32,ENET,port,display);
    //printf("Manual Summer Calibration Enabled\n");


    //delay(4000);
    USDELAY(8000);
    // Manual Latch Calibration
    data32 = enet_sds_ind_csr_reg_rd("RXTX_REG127", KC_SERDES_RXTX_REGS_RXTX_REG127__ADDR+ inst*0x0200,ENET,port,display);
    data32 = FIELD_RXTX_REG127_LATCH_MAN_CAL_ENA_SET(data32,0x1);
    enet_sds_ind_csr_reg_wr("RXTX_REG127", KC_SERDES_RXTX_REGS_RXTX_REG127__ADDR+ inst*0x0200, data32,ENET,port,display);
    //printf("Manual Latch Calibration Enabled\n");

    //delay(4000);
    USDELAY(8000);

    // Turn on DFE 
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg28", inst_base + 28*2,ENET,port,display);
    wr_val = sm_enet_set(rd_val,0x7, 15, display); 
    enet_sds_ind_csr_reg_wr("rxtx_reg28", inst_base + 28*2, wr_val,ENET,port,display);
    // DFE Presets to 0x2a00(default)
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg31", inst_base + 31*2,ENET,port,display);
    wr_val = sm_enet_set(rd_val, 0x2a00, 15, display); 
    enet_sds_ind_csr_reg_wr("rxtx_reg31", inst_base + 31*2, wr_val,ENET,port,display);
    // Disable RX Hi-Z termination enable
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg12", inst_base + 12*2,ENET,port,display);
    wr_val = sm_enet_set(rd_val,0, 1, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg12", inst_base + 12*2, wr_val,ENET,port,display);
    //delay(4000);
    USDELAY(8000);

    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg121", inst_base + 121*2, ENET, port, display);


}


int get_avg_1g(int accum,int samples){
    return ((accum + (samples/2))/samples);
}



//void pkt_compare(int port_num_calc, int hd_ptr) // Old code - wrong int hd_ptr
void pkt_compare(int port_num_calc, u64 hd_ptr)
{
    u64 st_address1; 	
    u64 st_address2; 	
    u64 st_address3; 	
    u64 st_address4; 	
    u64 addr_1,addr_2;
    u64 addr_3,addr_4;
    u8 wn1[] = {1, 1, 1, 1, 1};
    u64 crc_data_tx_0,crc_data_rx_0;
    u64 crc_data_tx_1,crc_data_rx_1;
    u64 crc_data_tx_2,crc_data_rx_2;
    u64 crc_data_tx_3,crc_data_rx_3;
    u64 ddr_base_tx_pkt[4]={0};
    u64 ddr_base_rx_pkt[4]={0};
    u64 k,number_errors[4]={0};
    u64 temp_tx,temp_rx;
    int read_rpkt_as[4]={0}; 
    int i;
    q_state_t q_state_pq_32_1[50];
    q_state_t q_state_pq_33_1[50];
    q_state_t q_state_pq_34_1[50];
    q_state_t q_state_pq_35_1[50];

    q_state_t q_state_pq_64_1[50];
    q_state_t q_state_pq_65_1[50];
    q_state_t q_state_pq_66_1[50];
    q_state_t q_state_pq_67_1[50];

    QM_CHK_RET(qm_get_q_state_dir(1,32,1,wn1,&q_state_pq_32_1[0]));
    QM_CHK_RET(qm_get_q_state_dir(1,33,1,wn1,&q_state_pq_33_1[0]));
    QM_CHK_RET(qm_get_q_state_dir(1,34,1,wn1,&q_state_pq_34_1[0]));
    QM_CHK_RET(qm_get_q_state_dir(1,35,1,wn1,&q_state_pq_35_1[0]));

    QM_CHK_RET(qm_get_q_state_dir(1,64,1,wn1,&q_state_pq_64_1[0]));
    QM_CHK_RET(qm_get_q_state_dir(1,65,1,wn1,&q_state_pq_65_1[0]));
    QM_CHK_RET(qm_get_q_state_dir(1,66,1,wn1,&q_state_pq_66_1[0]));
    QM_CHK_RET(qm_get_q_state_dir(1,67,1,wn1,&q_state_pq_67_1[0]));

    switch(port_num_calc)
    {
        case 0:
            //ddr_base_tx_pkt[0]
            st_address1 = (q_state_pq_32_1[0].pqfp.st_addr);
            st_address2 = (st_address1<<8);
            st_address1 = (hd_ptr);
            st_address2 += (st_address1<<4);
            st_address2+=8;
#if 1 //_tp
	//printf("\n[0] st_address2 : PA : 0x%x",st_address2);
	st_address2 = qm_get_va(st_address2);
	//printf("\n[0] st_address2 : VA : 0x%x",st_address2);
#endif //_tp		            
            addr_1 = read(st_address2);
            addr_1 = addr_1 & 0x00000000ffffffff;   //masking uppar 32 bits

            addr_2 = read(st_address2+4);
            addr_2 = addr_2 & 0x00000000000003ff;   //keeping only last 10 bits
            addr_3 = addr_2 << 32;

            addr_4 = addr_3 + addr_1;               //getting 42 bits DATA ADDRESS field
            ddr_base_tx_pkt[0] = addr_4;
#if 1 //_tp
	//printf("\nddr_base_tx_pkt[0] : PA : 0x%x\n",ddr_base_tx_pkt[0]);
	ddr_base_tx_pkt[0] = qm_get_va(addr_4);
	//printf("\nddr_base_tx_pkt[0] : VA : 0x%x\n",ddr_base_tx_pkt[0]);
#endif //_tp			            
            break;
        case 1:

            // ddr_base_tx_pkt[1]
            st_address1 = (q_state_pq_33_1[0].pqfp.st_addr);
            st_address2 = (st_address1<<8);
            st_address1 = (hd_ptr);
            st_address2 += (st_address1<<4);
            st_address2+=8;
#if 1 //_tp
	//printf("\n[1] st_address2 : PA : 0x%x",st_address2);
	st_address2 = qm_get_va(st_address2);
	//printf("\n[1] st_address2 : VA : 0x%x",st_address2);
#endif //_tp			
    
            addr_1 = read(st_address2);
            addr_1 = addr_1 & 0x00000000ffffffff;   //masking uppar 32 bits

            addr_2 = read(st_address2+4);
            addr_2 = addr_2 & 0x00000000000003ff;   //keeping only last 10 bits
            addr_3 = addr_2 << 32;

            addr_4 = addr_3 + addr_1;               //getting 42 bits DATA ADDRESS field
            ddr_base_tx_pkt[1]= addr_4;
#if 1 //_tp
	//printf("\nddr_base_tx_pkt[1] : PA : 0x%x\n",ddr_base_tx_pkt[1]);
	ddr_base_tx_pkt[1] = qm_get_va(addr_4);
	//printf("\nddr_base_tx_pkt[1] : VA : 0x%x\n",ddr_base_tx_pkt[1]);
#endif //_tp			            
            break;
        case 2:

            // ddr_base_tx_pkt[2]
            st_address1 = (q_state_pq_34_1[0].pqfp.st_addr);
            st_address2 = (st_address1<<8);
            st_address1 = (hd_ptr);
            st_address2 += (st_address1<<4);
            st_address2+=8;
#if 1 //_tp
	//printf("\n[2] st_address2 : PA : 0x%x",st_address2);
	st_address2 = qm_get_va(st_address2);
	//printf("\n[2] st_address2 : VA : 0x%x",st_address2);
#endif //_tp		
    	
            addr_1 = read(st_address2);
            addr_1 = addr_1 & 0x00000000ffffffff;    //masking uppar 32 bits

            addr_2 = read(st_address2+4);
            addr_2 = addr_2 & 0x00000000000003ff;    //keeping only last 10 bits
            addr_3 = addr_2 << 32;

            addr_4 = addr_3 + addr_1;                //getting 42 bits DATA ADDRESS field
            ddr_base_tx_pkt[2]= addr_4;
#if 1 //_tp
	//printf("\nddr_base_tx_pkt[2] : PA : 0x%x\n",ddr_base_tx_pkt[2]);
	ddr_base_tx_pkt[2] = qm_get_va(addr_4);
	//printf("\nddr_base_tx_pkt[2] : VA : 0x%x\n",ddr_base_tx_pkt[2]);
#endif //_tp			            
            break;
        case 3:
            // ddr_base_tx_pkt[3]
            st_address1 = (q_state_pq_35_1[0].pqfp.st_addr);
            st_address2 = (st_address1<<8);
            st_address2+=8;
#if 1 //_tp
	//printf("\n[3] st_address2 : PA : 0x%x",st_address2);
	st_address2 = qm_get_va(st_address2);
	//printf("\n[3] st_address2 : VA : 0x%x",st_address2);
#endif //_tp		
    	
            addr_1 = read(st_address2);
            addr_1 = addr_1 & 0x00000000ffffffff;    //masking uppar 32 bits

            addr_2 = read(st_address2+4);
            addr_2 = addr_2 & 0x00000000000003ff;    //keeping only last 10 bits
            addr_3 = addr_2 << 32;

            addr_4 = addr_3 + addr_1;                //getting 42 bits DATA ADDRESS field
            ddr_base_tx_pkt[3]= addr_4;
#if 1 //_tp
	//printf("\nddr_base_tx_pkt[3] : PA : 0x%x\n",ddr_base_tx_pkt[3]);
	ddr_base_tx_pkt[3] = qm_get_va(addr_4);
	//printf("\nddr_base_tx_pkt[3] : VA : 0x%x\n",ddr_base_tx_pkt[3]);
#endif //_tp	            
            break;
        default:
            printf("Enter correct port");
    }
    switch(port_num_calc)
    {
        case 0:

            // ddr_base_rx_pkt[0] 
            st_address1 = (q_state_pq_64_1[0].pqfp.st_addr);
            st_address2 = (st_address1<<8);
            st_address1 = (hd_ptr);
            st_address2 += (st_address1<<4);
            st_address2+=8;
#if 1 //_tp
	//printf("\n[0] st_address2 : PA : 0x%x",st_address2);
	st_address2 = qm_get_va(st_address2);
	//printf("\n[0] st_address2 : VA : 0x%x",st_address2);
#endif //_tp		
    	
            addr_1 = read(st_address2);
            addr_1 = addr_1 & 0x00000000ffffffff;    //masking uppar 32 bits

            addr_2 = read(st_address2+4);
            addr_2 = addr_2 & 0x00000000000003ff;    //keeping only last 10 bits
            addr_3 = addr_2 << 32;

            addr_4 = addr_3 + addr_1;                //getting 42 bits DATA ADDRESS field
            ddr_base_rx_pkt[0]= addr_4;
#if 1 //_tp
	//printf("\nddr_base_rx_pkt[0] : PA : 0x%x\n",ddr_base_rx_pkt[0]);
	ddr_base_rx_pkt[0] = qm_get_va(addr_4);
	//printf("\nddr_base_rx_pkt[0] : VA : 0x%x\n",ddr_base_rx_pkt[0]);
#endif //_tp			            
            break;
        case 1:
            // ddr_base_rx_pkt[1]
            st_address1 = (q_state_pq_65_1[0].pqfp.st_addr);
            st_address2 = (st_address1<<8);
            st_address1 = (hd_ptr);
            st_address2 += (st_address1<<4);
            st_address2+=8;
#if 1 //_tp
	//printf("\n[1] st_address2 : PA : 0x%x",st_address2);
	st_address2 = qm_get_va(st_address2);
	//printf("\n[1] st_address2 : VA : 0x%x",st_address2);
#endif //_tp		
    	
            addr_1 = read(st_address2);
            addr_1 = addr_1 & 0x00000000ffffffff;    //masking uppar 32 bits

            addr_2 = read(st_address2+4);
            addr_2 = addr_2 & 0x00000000000003ff;    //keeping only last 10 bits
            addr_3 = addr_2 << 32;

            addr_4 = addr_3 + addr_1;                //getting 42 bits DATA ADDRESS field
            ddr_base_rx_pkt[1]= addr_4;
#if 1 //_tp
			//printf("\nddr_base_rx_pkt[1] : PA : 0x%x\n",ddr_base_rx_pkt[1]);
			ddr_base_rx_pkt[1] = qm_get_va(addr_4);
			//printf("\nddr_base_rx_pkt[1] : VA : 0x%x\n",ddr_base_rx_pkt[1]);
#endif //_tp			
            break;
        case 2:
            // ddr_base_rx_pkt[2] 
            st_address1 = (q_state_pq_66_1[0].pqfp.st_addr);
            st_address2 = (st_address1<<8);
            st_address1 = (hd_ptr);
            st_address2 += (st_address1<<4);
            st_address2+=8;
#if 1 //_tp
	//printf("\n[2] st_address2 : PA : 0x%x",st_address2);
	st_address2 = qm_get_va(st_address2);
	//printf("\n[2] st_address2 : VA : 0x%x",st_address2);
#endif //_tp			

            addr_1 = read(st_address2);
            addr_1 = addr_1 & 0x00000000ffffffff;    //masking uppar 32 bits

            addr_2 = read(st_address2+4);
            addr_2 = addr_2 & 0x00000000000003ff;    //keeping only last 10 bits
            addr_3 = addr_2 << 32;

            addr_4 = addr_3 + addr_1;                //getting 42 bits DATA ADDRESS field
            ddr_base_rx_pkt[2]= addr_4;
#if 1 //_tp
	//printf("\nddr_base_rx_pkt[2] : PA : 0x%x\n",ddr_base_rx_pkt[2]);
	ddr_base_rx_pkt[2] = qm_get_va(addr_4);
	//printf("\nddr_base_rx_pkt[2] : VA : 0x%x\n",ddr_base_rx_pkt[2]);
#endif //_tp			            
            break;
        case 3:
            // ddr_base_rx_pkt[3] 
            st_address1 = (q_state_pq_67_1[0].pqfp.st_addr);
            st_address2 = (st_address1<<8);
            st_address1 = (hd_ptr);
            st_address2 += (st_address1<<4);
            st_address2+=8;
#if 1 //_tp
	//printf("\n[3] st_address2 : PA : 0x%x",st_address2);
	st_address2 = qm_get_va(st_address2);
	//printf("\n[3] st_address2 : VA : 0x%x",st_address2);
#endif //_tp		
    	
            addr_1 = read(st_address2);
            addr_1 = addr_1 & 0x00000000ffffffff;    //masking uppar 32 bits

            addr_2 = read(st_address2+4);
            addr_2 = addr_2 & 0x00000000000003ff;    //keeping only last 10 bits
            addr_3 = addr_2 << 32;

            addr_4 = addr_3 + addr_1;                //getting 42 bits DATA ADDRESS field
            ddr_base_rx_pkt[3]= addr_4;
#if 1 //_tp
	//printf("\nddr_base_rx_pkt[3] : PA : 0x%x\n",ddr_base_rx_pkt[3]);
	ddr_base_rx_pkt[3] = qm_get_va(addr_4);
	//printf("\nddr_base_rx_pkt[3] : VA : 0x%x\n",ddr_base_rx_pkt[3]);
#endif //_tp			            
            break;
        default:
            printf("Enter valid port\n");
    }

    read_rpkt_as[port_num_calc] = mac_stat_rd(PEMSTAT_RPKT__ADDR , port_num_calc);

    switch(port_num_calc) {
        case 0 :
            if(read_rpkt_as[0]){

                //printf("\n************** Comapring for port 0 ***************\n");
                //printf(".");

                //for(k=0;k<16;k++){
                for(k=0;k<64;k++){

                    //	crc_data_tx_0=read_as_32(temp_tx);
                    crc_data_tx_0=read_64(ddr_base_tx_pkt[0]+k*4);
                    crc_data_rx_0=read_64(ddr_base_rx_pkt[0]+k*4);


                    if(crc_data_tx_0!=crc_data_rx_0)
                    {	
                        printf("^^^^^^^^^^^^^^^^^^^FAIL : Port 0 ( CRC ERROR)  ^^^^^^^^^^^^^^^^^ \n");
                        printf("############ Mismatch at address 0x%x and 0x%x###############\n",ddr_base_tx_pkt[0]+k*4,ddr_base_rx_pkt[0]+k*4);
                        printf("\n");
                        printf("############ Mismatch data 0x%x and 0x%x###############\n",crc_data_tx_0,crc_data_rx_0);
                        printf("\n");
                        number_errors[0]++;
                    }

                }
            }
            else
            {
                printf("^^^^^^^^^^^^^^^^^^^FAIL : Port 0 (didn't receive a packet) ^^^^^^^^^^^^^^^^^ \n");
                number_errors[0]++;
            }
            break;


                case 1 :
            if(read_rpkt_as[1]){

                //printf("\n************** Comapring for port 1 ***************\n");
                //printf(".");

                //for(k=0;k<16;k++){
                for(k=0;k<64;k++){

                    crc_data_tx_1=read_64(ddr_base_tx_pkt[1]+k*4);
                    crc_data_rx_1=read_64(ddr_base_rx_pkt[1]+k*4);

                    if(crc_data_tx_1!=crc_data_rx_1)
                    {
                        printf("^^^^^^^^^^^^^^^^^^^FAIL : Port 1 ( CRC ERROR)  ^^^^^^^^^^^^^^^^^ \n");
                        printf("############ Mismatch at 0x%x and 0x%x###############\n",ddr_base_tx_pkt[1]+k*4,ddr_base_rx_pkt[1]+k*4);
                        printf("\n");
                        printf("############ Mismatch data 0x%x and 0x%x###############\n",crc_data_tx_1,crc_data_rx_1);
                        printf("\n");
                        number_errors[1]++;
                    }
                }
            }
            else
            {
                printf("^^^^^^^^^^^^^^^^^^^FAIL : Port 1 (didn't receive a packet) ^^^^^^^^^^^^^^^^^ \n");
                number_errors[1]++;
            }
            break;



                case 2 :
            if(read_rpkt_as[2]){

                //printf("\n************** Comapring for port 2 ***************\n");
                //printf(".");

                //for(k=0;k<16;k++){
                for(k=0;k<64;k++){

                    crc_data_tx_2=read_64(ddr_base_tx_pkt[2]+k*4);
                    crc_data_rx_2=read_64(ddr_base_rx_pkt[2]+k*4);

                    if(crc_data_tx_2!=crc_data_rx_2)
                    {				
                        printf("^^^^^^^^^^^^^^^^^^^FAIL : Port 2 ( CRC ERROR)  ^^^^^^^^^^^^^^^^^ \n");
                        printf("############ Mismatch at 0x%x and 0x%x###############\n",ddr_base_tx_pkt[2]+k*4,ddr_base_rx_pkt[2]+k*4);
                        printf("\n");
                        printf("############ Mismatch data 0x%x and 0x%x###############\n",crc_data_tx_2,crc_data_rx_2);
                        printf("\n");
                        number_errors[2]++;
                    }
                }
            }
            else
            {printf("^^^^^^^^^^^^^^^^^^^FAIL : Port 2 (didn't receive a packet) ^^^^^^^^^^^^^^^^^ \n");
                number_errors[2]++;
            }
            break;



                case 3 :
            if(read_rpkt_as[3]){

                //printf("\n************** Comapring for port 3 ***************\n");
                //printf(".");

                //for(k=0;k<16;k++){
                for(k=0;k<64;k++){
                    crc_data_tx_3=read_64(ddr_base_tx_pkt[3]+k*4);
                    crc_data_rx_3=read_64(ddr_base_rx_pkt[3]+k*4);

                    if(crc_data_tx_3!=crc_data_rx_3)
                    {	
                        printf("^^^^^^^^^^^^^^^^^^^FAIL : Port 3 ( CRC ERROR)  ^^^^^^^^^^^^^^^^^ \n");
                        printf("############ Mismatch at 0x%x and 0x%x###############\n",ddr_base_tx_pkt[3]+k*4,ddr_base_rx_pkt[3]+k*4);
                        printf("\n");
                        printf("############ Mismatch data 0x%x and 0x%x###############\n",crc_data_tx_3,crc_data_rx_3);
                        printf("\n");
                        number_errors[3]++;
                    }
                }
            }
            else
            {printf("^^^^^^^^^^^^^^^^^^^FAIL : Port 3 (didn't receive a packet) ^^^^^^^^^^^^^^^^^ \n");
                number_errors[3]++;
            }
            break;

                default :
            printf("\nOops !! Invalid port number passed\n");


            }




            /*
               switch(port_num_calc) {
               case 0 :
               if(number_errors[0])
               {printf("^^^^^^^^^^^^^^^^^^^FAIL for PORT 0^^^^^^^^^^^^^^^^^^^^^^\n");}
               else
               {printf("^^^^^^^^^^^^^^^^^^^PASS for PORT 0^^^^^^^^^^^^^^^^^^^^^^\n");}

               printf("\n");	
               printf("\n");	
               break;

               case 1 :
               if(number_errors[1])
               {printf("^^^^^^^^^^^^^^^^^^^FAIL for PORT 1^^^^^^^^^^^^^^^^^^^^^^\n");}
               else
               {printf("^^^^^^^^^^^^^^^^^^^PASS for PORT 1^^^^^^^^^^^^^^^^^^^^^^\n");}

               printf("\n");
               printf("\n");
               break;

               case 2 :
               if(number_errors[2])
               {printf("^^^^^^^^^^^^^^^^^^^FAIL for PORT 2^^^^^^^^^^^^^^^^^^^^^^\n");}
               else
               {printf("^^^^^^^^^^^^^^^^^^^PASS for PORT 2^^^^^^^^^^^^^^^^^^^^^^\n");}

               printf("\n");
               printf("\n");
               break;

               case 3 :
               if(number_errors[3])
               {printf("^^^^^^^^^^^^^^^^^^^FAIL for PORT 3^^^^^^^^^^^^^^^^^^^^^^\n");}
               else
               {printf("^^^^^^^^^^^^^^^^^^^PASS for PORT 3^^^^^^^^^^^^^^^^^^^^^^\n");}

               printf("\n");
               printf("\n");
               break;

               default :
               printf("\nOops !! Invalid port number passed\n");

               }
               */

            total_err_count[port_num_calc] = total_err_count[port_num_calc] + number_errors[port_num_calc];


            }


            void pkt_compare_dbg(int port_num_calc)
            {
                u64 st_address1; 	
                u64 st_address2; 	
                u64 st_address3; 	
                u64 st_address4; 	
                u64 addr_1,addr_2;
                u64 addr_3,addr_4;    
                u8 wn1[] = {1, 1, 1, 1, 1};
                u64 crc_data_tx_0,crc_data_rx_0;
                u64 crc_data_tx_1,crc_data_rx_1;
                u64 crc_data_tx_2,crc_data_rx_2;
                u64 crc_data_tx_3,crc_data_rx_3;
                u64 ddr_base_tx_pkt[4]={0};
                u64 ddr_base_rx_pkt[4]={0};
                u64 k,number_errors[4]={0};
                u64 temp_tx,temp_rx;
                int read_rpkt_as[4]={0}; 
                int i;
                q_state_t q_state_pq_32_1[50];
                q_state_t q_state_pq_33_1[50];
                q_state_t q_state_pq_34_1[50];
                q_state_t q_state_pq_35_1[50];

                q_state_t q_state_pq_64_1[50];
                q_state_t q_state_pq_65_1[50];
                q_state_t q_state_pq_66_1[50];
                q_state_t q_state_pq_67_1[50];

                QM_CHK_RET(qm_get_q_state_dir(1,32,1,wn1,&q_state_pq_32_1[0]));
                QM_CHK_RET(qm_get_q_state_dir(1,33,1,wn1,&q_state_pq_33_1[0]));
                QM_CHK_RET(qm_get_q_state_dir(1,34,1,wn1,&q_state_pq_34_1[0]));
                QM_CHK_RET(qm_get_q_state_dir(1,35,1,wn1,&q_state_pq_35_1[0]));

                QM_CHK_RET(qm_get_q_state_dir(1,64,1,wn1,&q_state_pq_64_1[0]));
                QM_CHK_RET(qm_get_q_state_dir(1,65,1,wn1,&q_state_pq_65_1[0]));
                QM_CHK_RET(qm_get_q_state_dir(1,66,1,wn1,&q_state_pq_66_1[0]));
                QM_CHK_RET(qm_get_q_state_dir(1,67,1,wn1,&q_state_pq_67_1[0]));

                //ddr_base_tx_pkt[0]
                st_address1 = (q_state_pq_32_1[0].pqfp.st_addr);
                st_address2 = (st_address1<<8);
                st_address2+=8;

#if 1 //_tp
	//printf("\n[0] st_address2 : PA : 0x%x",st_address2);
	st_address2 = qm_get_va(st_address2);
	//printf("\n[0] st_address2 : VA : 0x%x",st_address2);
#endif //_tp	

                addr_1 = read(st_address2);
                addr_1 = addr_1 & 0x00000000ffffffff;   //masking uppar 32 bits

                addr_2 = read(st_address2+4);
                addr_2 = addr_2 & 0x00000000000003ff;   //keeping only last 10 bits
                addr_3 = addr_2 << 32;
                addr_4 = addr_3 + addr_1;               //getting 42 bits DATA ADDRESS field
                ddr_base_tx_pkt[0] = addr_4;
#if 1 //_tp
	//printf("\nddr_base_tx_pkt[0] : PA : 0x%x\n",ddr_base_tx_pkt[0]);
	ddr_base_tx_pkt[0] = qm_get_va(addr_4);
	//printf("\nddr_base_tx_pkt[0] : VA : 0x%x\n",ddr_base_tx_pkt[0]);
#endif //_tp	
                // ddr_base_tx_pkt[1]
                st_address1 = (q_state_pq_33_1[0].pqfp.st_addr);
                st_address2 = (st_address1<<8);
                st_address2+=8;
#if 1 //_tp
	//printf("\n[1] st_address2 : PA : 0x%x",st_address2);
	st_address2 = qm_get_va(st_address2);
	//printf("\n[1] st_address2 : VA : 0x%x",st_address2);
#endif //_tp	
                addr_1 = read(st_address2);
                addr_1 = addr_1 & 0x00000000ffffffff;   //masking uppar 32 bits

                addr_2 = read(st_address2+4);
                addr_2 = addr_2 & 0x00000000000003ff;   //keeping only last 10 bits
                addr_3 = addr_2 << 32;

                addr_4 = addr_3 + addr_1;               //getting 42 bits DATA ADDRESS field
                ddr_base_tx_pkt[1]= addr_4;    
#if 1 //_tp
	//printf("\nddr_base_tx_pkt[1] : PA : 0x%x\n",ddr_base_tx_pkt[1]);
	ddr_base_tx_pkt[1] = qm_get_va(addr_4);
	//printf("\nddr_base_tx_pkt[1] : VA : 0x%x\n",ddr_base_tx_pkt[1]);
#endif //_tp
                // ddr_base_tx_pkt[2]
                st_address1 = (q_state_pq_34_1[0].pqfp.st_addr);
                st_address2 = (st_address1<<8);
                st_address2+=8;
#if 1 //_tp
	//printf("\n[2] st_address2 : PA : 0x%x",st_address2);
	st_address2 = qm_get_va(st_address2);
	//printf("\n[2] st_address2 : VA : 0x%x",st_address2);
#endif //_tp
                addr_1 = read(st_address2);
                addr_1 = addr_1 & 0x00000000ffffffff;    //masking uppar 32 bits

                addr_2 = read(st_address2+4);
                addr_2 = addr_2 & 0x00000000000003ff;    //keeping only last 10 bits
                addr_3 = addr_2 << 32;

                addr_4 = addr_3 + addr_1;                //getting 42 bits DATA ADDRESS field
                ddr_base_tx_pkt[2]= addr_4;
#if 1 //_tp
	//printf("\nddr_base_tx_pkt[2] : PA : 0x%x\n",ddr_base_tx_pkt[2]);
	ddr_base_tx_pkt[2] = qm_get_va(addr_4);
	//printf("\nddr_base_tx_pkt[2] : VA : 0x%x\n",ddr_base_tx_pkt[2]);
#endif //_tp	
                // ddr_base_tx_pkt[3]
                st_address1 = (q_state_pq_35_1[0].pqfp.st_addr);
                st_address2 = (st_address1<<8);
                st_address2+=8;
#if 1 //_tp
	//printf("\n[3] st_address2 : PA : 0x%x",st_address2);
	st_address2 = qm_get_va(st_address2);
	//printf("\n[3] st_address2 : VA : 0x%x",st_address2);
#endif //_tp	
                addr_1 = read(st_address2);
                addr_1 = addr_1 & 0x00000000ffffffff;    //masking uppar 32 bits

                addr_2 = read(st_address2+4);
                addr_2 = addr_2 & 0x00000000000003ff;    //keeping only last 10 bits
                addr_3 = addr_2 << 32;

                addr_4 = addr_3 + addr_1;                //getting 42 bits DATA ADDRESS field
                ddr_base_tx_pkt[3]= addr_4;
#if 1 //_tp
	//printf("\nddr_base_tx_pkt[3] : PA : 0x%x\n",ddr_base_tx_pkt[3]);
	ddr_base_tx_pkt[3] = qm_get_va(addr_4);
	//printf("\nddr_base_tx_pkt[3] : VA : 0x%x\n",ddr_base_tx_pkt[3]);
#endif //_tp	
                // ddr_base_rx_pkt[0] 
                st_address1 = (q_state_pq_64_1[0].pqfp.st_addr);
                st_address2 = (st_address1<<8);
                st_address2+=8;
#if 1 //_tp
	//printf("\n[0] st_address2 : PA : 0x%x",st_address2);
	st_address2 = qm_get_va(st_address2);
	//printf("\n[0] st_address2 : VA : 0x%x",st_address2);
#endif //_tp	
                addr_1 = read(st_address2);
                addr_1 = addr_1 & 0x00000000ffffffff;    //masking uppar 32 bits

                addr_2 = read(st_address2+4);
                addr_2 = addr_2 & 0x00000000000003ff;    //keeping only last 10 bits
                addr_3 = addr_2 << 32;

                addr_4 = addr_3 + addr_1;                //getting 42 bits DATA ADDRESS field
                ddr_base_rx_pkt[0]= addr_4;
#if 1 //_tp
	//printf("\nddr_base_rx_pkt[0] : PA : 0x%x\n",ddr_base_rx_pkt[0]);
	ddr_base_rx_pkt[0] = qm_get_va(addr_4);
	//printf("\nddr_base_rx_pkt[0] : VA : 0x%x\n",ddr_base_rx_pkt[0]);
#endif //_tp
                // ddr_base_rx_pkt[1]
                st_address1 = (q_state_pq_65_1[0].pqfp.st_addr);
                st_address2 = (st_address1<<8);
                st_address2+=8;
#if 1 //_tp
	//printf("\n[1] st_address2 : PA : 0x%x",st_address2);
	st_address2 = qm_get_va(st_address2);
	//printf("\n[1] st_address2 : VA : 0x%x",st_address2);
#endif //_tp	
                addr_1 = read(st_address2);
                addr_1 = addr_1 & 0x00000000ffffffff;    //masking uppar 32 bits

                addr_2 = read(st_address2+4);
                addr_2 = addr_2 & 0x00000000000003ff;    //keeping only last 10 bits
                addr_3 = addr_2 << 32;

                addr_4 = addr_3 + addr_1;                //getting 42 bits DATA ADDRESS field
                ddr_base_rx_pkt[1]= addr_4;
#if 1 //_tp
			//printf("\nddr_base_rx_pkt[1] : PA : 0x%x\n",ddr_base_rx_pkt[1]);
			ddr_base_rx_pkt[1] = qm_get_va(addr_4);
			//printf("\nddr_base_rx_pkt[1] : VA : 0x%x\n",ddr_base_rx_pkt[1]);
#endif //_tp	
                // ddr_base_rx_pkt[2] 
                st_address1 = (q_state_pq_66_1[0].pqfp.st_addr);
                st_address2 = (st_address1<<8);
                st_address2+=8;
#if 1 //_tp
	//printf("\n[2] st_address2 : PA : 0x%x",st_address2);
	st_address2 = qm_get_va(st_address2);
	//printf("\n[2] st_address2 : VA : 0x%x",st_address2);
#endif //_tp	
                addr_1 = read(st_address2);
                addr_1 = addr_1 & 0x00000000ffffffff;    //masking uppar 32 bits

                addr_2 = read(st_address2+4);
                addr_2 = addr_2 & 0x00000000000003ff;    //keeping only last 10 bits
                addr_3 = addr_2 << 32;

                addr_4 = addr_3 + addr_1;                //getting 42 bits DATA ADDRESS field
                ddr_base_rx_pkt[2]= addr_4;
#if 1 //_tp
	//printf("\nddr_base_rx_pkt[2] : PA : 0x%x\n",ddr_base_rx_pkt[2]);
	ddr_base_rx_pkt[2] = qm_get_va(addr_4);
	//printf("\nddr_base_rx_pkt[2] : VA : 0x%x\n",ddr_base_rx_pkt[2]);
#endif //_tp	
                // ddr_base_rx_pkt[3] 
                st_address1 = (q_state_pq_67_1[0].pqfp.st_addr);
                st_address2 = (st_address1<<8);
                st_address2+=8;
#if 1 //_tp
	//printf("\n[3] st_address2 : PA : 0x%x",st_address2);
	st_address2 = qm_get_va(st_address2);
	//printf("\n[3] st_address2 : VA : 0x%x",st_address2);
#endif //_tp	
                addr_1 = read(st_address2);
                addr_1 = addr_1 & 0x00000000ffffffff;    //masking uppar 32 bits

                addr_2 = read(st_address2+4);
                addr_2 = addr_2 & 0x00000000000003ff;    //keeping only last 10 bits
                addr_3 = addr_2 << 32;

                addr_4 = addr_3 + addr_1;                //getting 42 bits DATA ADDRESS field
                ddr_base_rx_pkt[3]= addr_4;
#if 1 //_tp
	//printf("\nddr_base_rx_pkt[3] : PA : 0x%x\n",ddr_base_rx_pkt[3]);
	ddr_base_rx_pkt[3] = qm_get_va(addr_4);
	//printf("\nddr_base_rx_pkt[3] : VA : 0x%x\n",ddr_base_rx_pkt[3]);
#endif //_tp
                read_rpkt_as[port_num_calc] = mac_stat_rd(PEMSTAT_RPKT__ADDR , port_num_calc);

                switch(port_num_calc) {
                    case 0 :
                        if(read_rpkt_as[0]){

                            //printf("\n************** Comapring for port 0 ***************\n");
                            //printf(".");

                            for(k=0;k<16;k++){

                                //	crc_data_tx_0=read_as_32(temp_tx);
                                crc_data_tx_0=read_64(ddr_base_tx_pkt[1]+k*4);
                                crc_data_rx_0=read_64(ddr_base_rx_pkt[0]+k*4);


                                if(crc_data_tx_0!=crc_data_rx_0)
                                {	
                                    printf("^^^^^^^^^^^^^^^^^^^FAIL : Port 0 ( CRC ERROR)  ^^^^^^^^^^^^^^^^^ \n");
                                    printf("############ Mismatch at address 0x%x and 0x%x###############\n",ddr_base_tx_pkt[0]+k*4,ddr_base_rx_pkt[0]+k*4);
                                    printf("\n");
                                    printf("############ Mismatch data 0x%x and 0x%x###############\n",crc_data_tx_0,crc_data_rx_0);
                                    printf("\n");
                                    number_errors[0]++;
                                }

                            }
                        }
                        else
                        {
                            printf("^^^^^^^^^^^^^^^^^^^FAIL : Port 0 (didn't receive a packet) ^^^^^^^^^^^^^^^^^ \n");
                            number_errors[0]++;
                        }
                        break;

                    case 1 :
                        if(read_rpkt_as[1]){

                            //printf("\n************** Comapring for port 1 ***************\n");
                            //printf(".");

                            for(k=0;k<16;k++){

                                crc_data_tx_1=read_64(ddr_base_tx_pkt[0]+k*4);
                                crc_data_rx_1=read_64(ddr_base_rx_pkt[1]+k*4);

                                if(crc_data_tx_1!=crc_data_rx_1)
                                {
                                    printf("^^^^^^^^^^^^^^^^^^^FAIL : Port 1 ( CRC ERROR)  ^^^^^^^^^^^^^^^^^ \n");
                                    printf("############ Mismatch at 0x%x and 0x%x###############\n",ddr_base_tx_pkt[1]+k*4,ddr_base_rx_pkt[1]+k*4);
                                    printf("\n");
                                    printf("############ Mismatch data 0x%x and 0x%x###############\n",crc_data_tx_1,crc_data_rx_1);
                                    printf("\n");
                                    number_errors[1]++;
                                }
                            }
                        }
                        else
                        {
                            printf("^^^^^^^^^^^^^^^^^^^FAIL : Port 1 (didn't receive a packet) ^^^^^^^^^^^^^^^^^ \n");
                            number_errors[1]++;
                        }
                        break;

                    case 2 :
                        if(read_rpkt_as[2]){

                            //printf("\n************** Comapring for port 2 ***************\n");
                            //printf(".");

                            for(k=0;k<16;k++){

                                crc_data_tx_2=read_64(ddr_base_tx_pkt[3]+k*4);
                                crc_data_rx_2=read_64(ddr_base_rx_pkt[2]+k*4);

                                if(crc_data_tx_2!=crc_data_rx_2)
                                {				
                                    printf("^^^^^^^^^^^^^^^^^^^FAIL : Port 2 ( CRC ERROR)  ^^^^^^^^^^^^^^^^^ \n");
                                    printf("############ Mismatch at 0x%x and 0x%x###############\n",ddr_base_tx_pkt[2]+k*4,ddr_base_rx_pkt[2]+k*4);
                                    printf("\n");
                                    printf("############ Mismatch data 0x%x and 0x%x###############\n",crc_data_tx_2,crc_data_rx_2);
                                    printf("\n");
                                    number_errors[2]++;
                                }
                            }
                        }
                        else
                        {printf("^^^^^^^^^^^^^^^^^^^FAIL : Port 2 (didn't receive a packet) ^^^^^^^^^^^^^^^^^ \n");
                            number_errors[2]++;
                        }
                        break;

                    case 3 :
                        if(read_rpkt_as[3]){

                            //printf("\n************** Comapring for port 3 ***************\n");
                            //printf(".");

                            for(k=0;k<16;k++){
                                crc_data_tx_3=read_64(ddr_base_tx_pkt[2]+k*4);
                                crc_data_rx_3=read_64(ddr_base_rx_pkt[3]+k*4);

                                if(crc_data_tx_3!=crc_data_rx_3)
                                {	
                                    printf("^^^^^^^^^^^^^^^^^^^FAIL : Port 3 ( CRC ERROR)  ^^^^^^^^^^^^^^^^^ \n");
                                    printf("############ Mismatch at 0x%x and 0x%x###############\n",ddr_base_tx_pkt[3]+k*4,ddr_base_rx_pkt[3]+k*4);
                                    printf("\n");
                                    printf("############ Mismatch data 0x%x and 0x%x###############\n",crc_data_tx_3,crc_data_rx_3);
                                    printf("\n");
                                    number_errors[3]++;
                                }
                            }
                        }
                        else
                        {printf("^^^^^^^^^^^^^^^^^^^FAIL : Port 3 (didn't receive a packet) ^^^^^^^^^^^^^^^^^ \n");
                            number_errors[3]++;
                        }
                        break;

                    default :
                        printf("\nOops !! Invalid port number passed\n");


                }
                total_err_count[port_num_calc] = total_err_count[port_num_calc] + number_errors[port_num_calc];
            }



            void total_err_count_result() {

                printf("\n");	
                printf("\n");	

                if(total_err_count[0])
                {printf("^^^^^^^^^^^^^^^^^^^FAIL for PORT 0^^^^^^^^^^^^^^^^^^^^^^\n");}
                else
                {printf("^^^^^^^^^^^^^^^^^^^PASS for PORT 0^^^^^^^^^^^^^^^^^^^^^^\n");}

                printf("\n");	

                if(total_err_count[1])
                {printf("^^^^^^^^^^^^^^^^^^^FAIL for PORT 1^^^^^^^^^^^^^^^^^^^^^^\n");}
                else
                {printf("^^^^^^^^^^^^^^^^^^^PASS for PORT 1^^^^^^^^^^^^^^^^^^^^^^\n");}

                printf("\n");

                if(total_err_count[2])
                {printf("^^^^^^^^^^^^^^^^^^^FAIL for PORT 2^^^^^^^^^^^^^^^^^^^^^^\n");}
                else
                {printf("^^^^^^^^^^^^^^^^^^^PASS for PORT 2^^^^^^^^^^^^^^^^^^^^^^\n");}

                printf("\n");

                if(total_err_count[3])
                {printf("^^^^^^^^^^^^^^^^^^^FAIL for PORT 3^^^^^^^^^^^^^^^^^^^^^^\n");}
                else
                {printf("^^^^^^^^^^^^^^^^^^^PASS for PORT 3^^^^^^^^^^^^^^^^^^^^^^\n");}

                printf("\n");



	if(total_err_count[0] || total_err_count[1] || total_err_count[2] || total_err_count[3])
		printf("\nTest Result : FAIL\n");
	else
		printf("\nTest Result : PASS\n");

}


