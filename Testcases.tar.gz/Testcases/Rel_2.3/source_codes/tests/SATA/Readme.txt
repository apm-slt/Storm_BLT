#########################################################################
####### The readme file for SATA build  #################################
#########################################################################


Edit file setup.csh to specify your toolchain to build the code : 
Ex: 
	export TOOLCHAIN_PATH=/tools/arm/armv8/Theobroma/2013-04-19/apm-aarch64/5.0.3/bin
	export CROSS_COMPILE=$TOOLCHAIN_PATH/aarch64-apm-linux-gnu-

Edit the Makefile to the vbios source code that your code test wiil be refered
to 
Ex: 
	VBIOS_PATH      ?=/projects/hcm/storm/validation/lxpham/storm_b0/vbios_SLT_B0

Compile the code test : 
	1 . Go to the tests directory 
	2 . command to build test code: ./compile.sh $buildtype  {buildtype = "ddr" or "ocm" }
		ex: compile with Nor DDR :   ./compile.sh ddr 

After compile finish , cd to directory bin  and copy the file bin to your /tftpboot
