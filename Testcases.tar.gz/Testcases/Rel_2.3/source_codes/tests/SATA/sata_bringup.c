/*
 * Author: kqngo@apm.com
 * Company: Applied Micro Circuits Corporation (AMCC)
 */

#ifndef _SATA_BRINGUP_C__
#define _SATA_BRINGUP_C__

#include <iolib/arch_timer.h>	// included for performance measurement
//#include "../include/sata_driver.h"
//Tinh-SLT
//give a full path to include the header files
#include "../../SATA/include/sata_driver.h"
#define read32 read32_sata
#define write32 write32_sata
#define printPASS printPASS_sata
#define printFAIL printFAIL_sata
#define sds_dump sds_dump_sata
//End of Tinh-SLT

extern int fix_gen_avg_val;

extern int SDS_DUMP;
extern int RX_INV;
extern int SSC_EN;
extern int SSC1_EN;
extern int PLL_SSC_MOD;
extern int PLL_SSC_VSTEP;
extern int CLK_REF;
extern int CLK_TYPE;
extern int CLK_FREQ;
extern int PLL_GEN;
extern int LINK_GEN;
extern int PVT_MAN;
extern int WATERMARK;


extern int PQ_REG;
extern int CTLE_EQ;
extern int CTLE_EQ_0;
extern int CTLE_EQ_1;
extern int CTLE_EQ_2;
extern int CTLE_EQ_3;
extern int CTLE_EQ_4;
extern int CTLE_EQ_5;

extern int FBS;
extern u64 STA_SECTOR;
extern int NUM_SECTOR;
extern int PRD_SIZE;

int ALL_XDATA = 0;

void printPASS(void) {
	printf("\n\n");
	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
	printf ("$$$$ RESULT: TEST PASS $$$$\n");
	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
	printf("\n\n");
}

void printFAIL(void) {
	printf("\n\n");
	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
	printf ("$$$$ RESULT: TEST FAILED $$$$\n"); 
	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
	printf("\n\n");
}

int zzzmain(void){
	//time_t current_time;
    //char* c_time_string;
	int error = 0;
	int i, data;
	u32 sata_csr_base;

	//current_time = time(100);
	if (error == 0) 
		printPASS();
	else
		printFAIL();

	return 0;
}

void fix_gen_avg(void){
	printf("\n\t fix_gen_avg_val = %d \n", fix_gen_avg_val);
}
void fix_gen_avg_en(void){
	fix_gen_avg_val = 1;
	printf("\n\t fix_gen_avg_val = %d \n", fix_gen_avg_val);
}
void fix_gen_avg_dis(void){
	fix_gen_avg_val = 0;
	printf("\n\t fix_gen_avg_val = %d \n", fix_gen_avg_val);
}

void all_xdata(void){
	printf("\n\t ALL_XDATA = %d \n", ALL_XDATA);
}
void all_xdata_en(void){
	ALL_XDATA = 1;
	printf("\n\t ALL_XDATA = %d \n", ALL_XDATA);
}
void all_xdata_dis(void){
	ALL_XDATA = 0;
	printf("\n\t ALL_XDATA = %d \n", ALL_XDATA);
}

#if 0
void sata6_scan(void){
	int i, j, rc;
	int pll_sta, lnk_sta, spd_sta, dis_sta, rid_sta, pio_sta, dma_sta, fpdma_sta, bist_sta;
	int sata_port_pm, pmp_sta, pmp_id_sta, pmp_dma_sta;
	int pmp_total[6];
	u32 sata_ahci_port_base;
	pll_sta = 0;
	int failure = 0;
	int verbose = g_verbose_level;
	//g_verbose_level = 3;
	for(i=0; i<3; ++i){
		printf("\n SATA Controller%d - PLL init . .", i);
		j = 3;
		do{
			rc = sm_sata_init(i*2); //Changed from i to i*2 in svn rev-685
		}while((rc != 0) && (--j));
		if(rc == 0){
			pll_sta |= 3 << i*2;
		}
	}
	printf("\n");
	lnk_sta = 0;
	sata_port_pm = 0;
	pmp_id_sta = 0;
	pmp_dma_sta = 0;
	for(i=0; i<6; ++i){
		if(pll_sta & (1 << i)){
			printf("\n\n SATA Port%d - Link up . .", i);
			g_verbose_level = 2;
			j = 3;
			do{
				rc = sm_sata_linkup(i);
			}while((rc != 0) && (--j));
			g_verbose_level = verbose;
			if(rc == 0){
				sm_sata_pxssts(i);
				lprintf(3, "\n\t SATA Port%d - Link up was GOOD", i);
				lnk_sta |= 1 << i;
			}else
				lprintf(3, "\n\t [ERROR]: SATA Port%d - Link up was FAILED", i);
		}
	}
	printf("\n");
	rid_sta = 0;
	for(i=0; i<6; ++i){
		if(lnk_sta & (1 << i)){
			printf("\n SATA Port%d - Read ID . . .", i);
			rc = sm_sata_readid(i, 0);
			//pmp_total[i] = PM_discovery(i);
			pmp_total[i] = 0;			// skip scanning for PM card
			if(pmp_total[i]){
				sata_port_pm |= 1 << i;
				pmp_sta = Device_enum(i);
				for(j=0; j<pmp_total[i]; j++){
					if(pmp_sta & (1 << j)){
						if(sm_sata_readid(i, j) == 0) pmp_id_sta |= 1 << j;
						if(sm_sata_dma_test(i, j) == 0) pmp_dma_sta |= 1 << j;
					}
				}
			}
			if(rc == 0){
				rid_sta |= 1 << i;
			}
		}
	}
	if(1) {
		printf("\n");
		pio_sta = 0;
		STA_SECTOR = 10;
		NUM_SECTOR = 100;
		for(i=0; i<6; ++i){
			if((lnk_sta & (1 << i)) && ((pmp_total[i]) == 0)){
				printf("\n SATA Port%d - PIO Transfer . . .", i);
				rc = sm_sata_pio_test(i, 0);
				if(rc == 0){
					pio_sta |= 1 << i;
				}
			}
		}
	}
	printf("\n");
	dma_sta = 0;
	STA_SECTOR = 100;
	NUM_SECTOR = 10000;
	for(i=0; i<6; ++i){
		if((lnk_sta & (1 << i)) && ((pmp_total[i]) == 0)){
			printf("\n SATA Port%d - DMA Transfer . . .", i);
			rc = sm_sata_dma_test(i, 0);
			if(rc == 0){
				dma_sta |= 1 << i;
			}
		}
	}
	if(ALL_XDATA) {
		printf("\n");
		fpdma_sta = 0;
		STA_SECTOR = 100;
		NUM_SECTOR = 50000;
		for(i=0; i<6; ++i){
			if((lnk_sta & (1 << i)) && ((pmp_total[i]) == 0)){
				printf("\n SATA Port%d - FPDMA Transfer . . .", i);
				rc = sm_sata_fpdma_test(i, 0);
				if(rc == 0){
					fpdma_sta |= 1 << i;
				}
			}
		}
	}
#if BIST_SCR	
	printf("\n");
	bist_sta = 0;
	for(i=0; i<6; ++i){
		if( lnk_sta & (1<<i) ){
			printf("\n SATA Port%d - BIST . . .",i);
			//rc = sm_sata_bist_L_test(i);
			if(rc == 0){
				bist_sta |= 1 << i;
			}
		}
	}
#endif
	printf("\n\n Reference Clock:");
	if(CLK_REF)
		printf(" INTERNAL");
	else
		printf(" EXTERNAL");
	if(CLK_TYPE)
		printf(" CMOS");
	else
		printf(" CML \n");
	// display Results
	printf("\n Results of Scanning SATA 6 Ports: \n");

	printf("\n Test Name \\ Port    Port0     Port1     Port2     Port3     Port4     Port5");
	printf("\n\n PLL Locking         ");
	for(i=0; i<6; ++i){
		if(pll_sta & (1 << i))
			printf("LOCKED    ");
		else{
			printf("Failed    ");
			failure++;
		}
	}
	printf("\n\n Link Up             ");
	for(i=0; i<6; ++i){
		if(lnk_sta & (1 << i)){
			sata_ahci_port_base = sm_sata_get_ahci_port_base(i);
			spd_sta = sm_sata_read32(sata_ahci_port_base + SSTS0__ADDR);
			dis_sta = sm_sata_read32(sata_ahci_port_base + SERR0__ADDR);
			printf("GEN%d", (spd_sta >> 4) & 0xF);
			((dis_sta >> 20) & 1) ? printf(".D    ") : printf("      ");
		}
		else{
			printf("Failed    ");
			failure++;
		}
	}
	printf("\n\n Read ID             ");
	for(i=0; i<6; ++i){
		if(lnk_sta & (1 << i)){
			if(pmp_total[i])
				printf("PM card   ");
			else{
				if(rid_sta & (1 << i))
					printf("Passed    ");
				else{
					printf("Failed    ");
					failure++;
				}
			}
		}
		else
			printf("N/A       ");
	}
	if(1) {
		STA_SECTOR = 100;
		NUM_SECTOR = 100;
		printf("\n\n PIO (100 sectors)   ");
		for(i=0; i<6; ++i){
			if(lnk_sta & (1 << i)){
				if(pmp_total[i])
					printf("PM card   ");
				else{
					if(pio_sta & (1 << i))
						printf("Passed    ");
					else{
						printf("Failed    ");
						failure++;
					}
				}
			}
				else
					printf("N/A       ");
		}
	}
	STA_SECTOR = 10000;
	NUM_SECTOR = 10000;
	printf("\n\n DMA (10K sectors)   ");
	for(i=0; i<6; ++i){
		if(lnk_sta & (1 << i)){
			if(pmp_total[i])
				printf("PM card   ");
			else{
				if(dma_sta & (1 << i))
					printf("Passed    ");
				else{
					printf("Failed    ");
					failure++;
				}
			}
		}
			else
				printf("N/A       ");
	}
	if(ALL_XDATA) {
		STA_SECTOR = 50000;
		NUM_SECTOR = 50000;
		printf("\n\n FPDMA (50K sectors) ");
		for(i=0; i<6; ++i){
			if(lnk_sta & (1 << i)){
				if(pmp_total[i])
					printf("PM card   ");
				else{
					if(fpdma_sta & (1 << i))
						printf("Passed    ");
					else{
						printf("Failed    ");
						failure++;
					}
				}
			}
				else
					printf("N/A       ");
		}
	}
	printf("\n\n Disparity check     ");
	for(i=0; i<6; ++i){
		if(lnk_sta & (1 << i)){
			sata_ahci_port_base = sm_sata_get_ahci_port_base(i);
			dis_sta = sm_sata_read32(sata_ahci_port_base + SERR0__ADDR);
			if(((dis_sta >> 20) & 1) == 0)
				printf("Passed    ");
			else{
				printf("Failed    ");
				failure++;
			}
		}
		else
			printf("N/A       ");
	}
#if BIST_SCR	
	printf("\n\n BIST-L Result       ");
	for(i=0; i<6; ++i){
		if(lnk_sta & (1 << i)){
			if(pmp_total[i])
				printf("PM card   ");
			else{
				if(bist_sta & (1 << i))
					printf("Passed    ");
				else{
					printf("Failed    ");
					failure++;
				}
			}
		}
		else
			printf("N/A       ");
	}
#endif

#if 0
	/***************** PMP ************/
	if(sata_port_pm) printf("\n\n PM Port \\ Test Name    ReadID     DMA");
	for(i=0; i<6; i++){
		if(sata_port_pm & (1 << i)){
			for(j=0; j<pmp_total[i]; j++){
				printf("\n PMP%d_%02d                ", i, j);
				if(pmp_sta & (1 << j)){
					if(pmp_id_sta & (1 << j))
						printf("PASSED     ");
					else{
						printf("FAILED     ");
						failure++;
					}
					if(pmp_dma_sta & (1 << j))
						printf("PASSED     ");
					else{
						printf("FAILED     ");
						failure++;
					}
				}
				else
					printf("N/A        N/A");
			}
		}
	}
#endif

	printf("\n\nSATA SCAN Completed\n");
	if(!failure)
		printf("\n ****** SATA Screening - Pass ******");
	else
		printf("\n ****** SATA Screening - Fail ******");
}
#else		// for SLT
void sata6_scan(void){
	int i, j, rc, trial;
	int pll_sta, lnk_sta, spd_sta, dis_sta, rid_sta, pio_sta, dma_sta, fpdma_sta;
	int sata_port_pm, pmp_sta, pmp_id_sta, pmp_dma_sta;
	int pmp_total[6];
	u32 sata_ahci_port_base;
	pll_sta = 0x3F;		// each bit is a status of a port, 0 is fail and 1 is pass, default is all pass
	lnk_sta = 0x3F;
	spd_sta = 0;
	dis_sta = 0;
	rid_sta = 0;
	pio_sta = 0;
	dma_sta = 0;
	fpdma_sta = 0;
	int failure = 0;
	int verbose = g_verbose_level;

	for(trial=0; trial<3; ++trial) {
		printf("\n\n TRIAL #%d", trial);
		g_verbose_level = 2;
		// PLL Init
		for(i=0; i<3; ++i) {		// SATA controller 0, 1, and 2
			printf("\n SATA Controller %d - PLL initiating . . . ", i);
			if(pll_sta & (3 << i*2)) {
				j = 3;				// try PLL init maximum 3 times
				do {
					rc = sm_sata_init(i*2); 	// changed from i to i*2 in svn rev-685
				}while((rc != 0) && (--j));
				if(rc == 0)
					printf("PASSED");
				else {
					pll_sta &= ~(3 << i*2);
					printf("FAILED");
				}
			} else
				printf("SKIPPED");
		}
		// Link up
		for(i=0; i<6; ++i){
			printf("\n\n SATA Port %d - Link up . . . ", i);
			if(pll_sta & lnk_sta & (1 << i)){
				j = 3;
				do {
					rc = sm_sata_linkup(i);
				}while((rc != 0) && (--j));
				if(rc == 0) {
					sata_ahci_port_base = sm_sata_get_ahci_port_base(i);
					dis_sta = sm_sata_read32(sata_ahci_port_base + SERR0__ADDR);
					if((dis_sta >> 20) & 1) {
						lnk_sta &= ~(1 << i);
						printf(" FAILED because of Disparity");
					} else
						printf("PASSED");
				} else {
					lnk_sta &= ~(1 << i);
					printf("FAILED");
				}
			} else
				printf("SKIPPED");
		}
	}
	if(1) {
		printf("\n");
		for(i=0; i<6; ++i){
			if(lnk_sta & (1 << i)){
				printf("\n SATA Port %d - Read ID . . . ", i);
				g_verbose_level = verbose;
				rc = sm_sata_readid(i, 0);
				g_verbose_level = 2;
				//pmp_total[i] = PM_discovery(i);
				pmp_total[i] = 0;			// skip scanning for PM card
				if(pmp_total[i]){
					sata_port_pm |= 1 << i;
					pmp_sta = Device_enum(i);
					for(j=0; j<pmp_total[i]; j++){
						if(pmp_sta & (1 << j)){
							if(sm_sata_readid(i, j) == 0) pmp_id_sta |= 1 << j;
							if(sm_sata_dma_test(i, j) == 0) pmp_dma_sta |= 1 << j;
						}
					}
				}
				if(rc == 0){
					rid_sta |= 1 << i;
				}
			}
		}
	}
	if(1) {
		printf("\n");
		STA_SECTOR = 10;
		NUM_SECTOR = 100;
		for(i=0; i<6; ++i){
			if((lnk_sta & (1 << i)) && ((pmp_total[i]) == 0)){
				printf("\n SATA Port%d - PIO Transfer . . . ", i);
				rc = sm_sata_pio_test(i, 0);
				if(rc == 0){
					pio_sta |= 1 << i;
					printf("PASSED");
				} else
					printf("FAILED");
			}
		}
	}
	if(1) {
		printf("\n");
		dma_sta = 0;
		STA_SECTOR = 100;
		NUM_SECTOR = 10000;
		for(i=0; i<6; ++i){
			if((lnk_sta & (1 << i)) && ((pmp_total[i]) == 0)){
				printf("\n SATA Port%d - DMA Transfer . . . ", i);
				rc = sm_sata_dma_test(i, 0);
				if(rc == 0){
					dma_sta |= 1 << i;
					printf("PASSED");
				} else
					printf("FAILED");
			}
		}
	}
	if(0) {
		printf("\n");
		fpdma_sta = 0;
		STA_SECTOR = 100;
		NUM_SECTOR = 50000;
		for(i=0; i<6; ++i){
			if((lnk_sta & (1 << i)) && ((pmp_total[i]) == 0)){
				printf("\n SATA Port%d - FPDMA Transfer . . . ", i);
				rc = sm_sata_fpdma_test(i, 0);
				if(rc == 0){
					fpdma_sta |= 1 << i;
					printf("PASSED");
				} else
					printf("FAILED");
			}
		}
	}
	printf("\n\n Reference Clock:");
	if(CLK_REF)
		printf(" INTERNAL");
	else
		printf(" EXTERNAL");
	if(CLK_TYPE)
		printf(" CMOS");
	else
		printf(" CML");
	if(CLK_FREQ == 2)
		printf(" 25MHz\n");
	else if(CLK_FREQ == 1)
		printf(" 50MHz\n");
	else
		printf(" 100MHz\n");
	// display Results
	printf("\n Results of Scanning SATA 6 Ports: \n");

	printf("\n Test Name \\ Port    Port0     Port1     Port2     Port3     Port4     Port5");
	printf("\n\n PLL Locking         ");
	for(i=0; i<6; ++i){
		if(pll_sta & (1 << i))
			printf("LOCKED    ");
		else{
			printf("Failed    ");
			failure++;
		}
	}
	printf("\n\n Link Up             ");
	for(i=0; i<6; ++i){
		if(lnk_sta & (1 << i)){
			sata_ahci_port_base = sm_sata_get_ahci_port_base(i);
			spd_sta = sm_sata_read32(sata_ahci_port_base + SSTS0__ADDR);
			dis_sta = sm_sata_read32(sata_ahci_port_base + SERR0__ADDR);
			printf("GEN%d", (spd_sta >> 4) & 0xF);
			((dis_sta >> 20) & 1) ? printf(".D    ") : printf("      ");
		}
		else{
			printf("Failed    ");
			failure++;
		}
	}
	printf("\n\n Read ID             ");
	for(i=0; i<6; ++i){
		if(lnk_sta & (1 << i)){
			if(pmp_total[i])
				printf("PM card   ");
			else{
				if(rid_sta & (1 << i))
					printf("Passed    ");
				else{
					printf("Failed    ");
					failure++;
				}
			}
		}
		else
			printf("N/A       ");
	}
	if(1) {
		printf("\n\n PIO (100 sectors)   ");
		for(i=0; i<6; ++i){
			if(lnk_sta & (1 << i)){
				if(pmp_total[i])
					printf("PM card   ");
				else{
					if(pio_sta & (1 << i))
						printf("Passed    ");
					else{
						printf("Failed    ");
						failure++;
					}
				}
			} else
				printf("N/A       ");
		}
	}
	if(1) {
		printf("\n\n DMA (10K sectors)   ");
		for(i=0; i<6; ++i){
			if(lnk_sta & (1 << i)){
				if(pmp_total[i])
					printf("PM card   ");
				else{
					if(dma_sta & (1 << i))
						printf("Passed    ");
					else{
						printf("Failed    ");
						failure++;
					}
				}
			} else
				printf("N/A       ");
		}
	}
	if(0) {
		printf("\n\n FPDMA (50K sectors) ");
		for(i=0; i<6; ++i){
			if(lnk_sta & (1 << i)){
				if(pmp_total[i])
					printf("PM card   ");
				else{
					if(fpdma_sta & (1 << i))
						printf("Passed    ");
					else{
						printf("Failed    ");
						failure++;
					}
				}
			} else
				printf("N/A       ");
		}
	}
	printf("\n\n Disparity check     ");
	for(i=0; i<6; ++i){
		if(lnk_sta & (1 << i)){
			sata_ahci_port_base = sm_sata_get_ahci_port_base(i);
			dis_sta = sm_sata_read32(sata_ahci_port_base + SERR0__ADDR);
			if(((dis_sta >> 20) & 1) == 0)
				printf("Passed    ");
			else{
				printf("Failed    ");
				failure++;
			}
		}
		else
			printf("N/A       ");
	}

#if 0
	/***************** PMP ************/
	if(sata_port_pm) printf("\n\n PM Port \\ Test Name    ReadID     DMA");
	for(i=0; i<6; i++){
		if(sata_port_pm & (1 << i)){
			for(j=0; j<pmp_total[i]; j++){
				printf("\n PMP%d_%02d                ", i, j);
				if(pmp_sta & (1 << j)){
					if(pmp_id_sta & (1 << j))
						printf("PASSED     ");
					else{
						printf("FAILED     ");
						failure++;
					}
					if(pmp_dma_sta & (1 << j))
						printf("PASSED     ");
					else{
						printf("FAILED     ");
						failure++;
					}
				}
				else
					printf("N/A        N/A");
			}
		}
	}
#endif

	printf("\n\nSATA SCAN Completed\n");
	if(!failure)
		printf("\n ****** SATA Screening - Pass ******");
	else
		printf("\n ****** SATA Screening - Fail ******");
}
#endif

void sata_scan(int argc, char *argv[]){
	int clkref  = atoi(argv[0]);
	int clktype = atoi(argv[1]);
#if 1
	if(argc != 0){
		printf("\n Syntax: sata_scan");
	}else{
		sata6_scan();
	}
#else
	if(argc != 2){
		printf("\n Syntax: sata_scan [CLKREF] [CLKTYPE]");
		printf("\n\t [CLKREF] : 0 - External Clock, 1 - Internal Clock");
		printf("\n\t [CLKTYPE]: 0 - CML,            1 - CMOS \n");
	}else{
		sata6_scan(clkref, clktype);
	}
#endif
}

/****************************** DEBUG FUNCTIONS ***************************/
void mdio_en(void){
	sm_sata_mdio_debug_en();
}
void sds_dump_en(void){
	SDS_DUMP = 1;
	printf("\n\t SDS_DUMP = %d \n", SDS_DUMP);
}
void sds_dump_dis(void){
	SDS_DUMP = 0;
	printf("\n\t SDS_DUMP = %d \n", SDS_DUMP);
}
void sds_dump(int argc, char *argv[]){
	int port;
	if(argc != 1){
		printf("\n Syntax: sds_dump [PORT]");
	}else{
		port = atoi(argv[0]);
		sm_sata_sds_dump(port);
	}
}
void ssc(void){
	printf("\n\t SSC_EN = %d \n", SSC_EN);
}
void ssc_en(void){
	SSC_EN = 1;
	printf("\n\t SSC_EN = %d \n", SSC_EN);
}
void ssc_dis(void){
	SSC_EN = 0;
	printf("\n\t SSC_EN = %d \n", SSC_EN);
}
void ssc1(void){
	printf("\n\t SSC1_EN = %d \n", SSC1_EN);
}
void ssc1_en(void){
	SSC1_EN = 1;
	printf("\n\t SSC1_EN = %d \n", SSC1_EN);
}
void ssc1_dis(void){
	SSC1_EN = 0;
	printf("\n\t SSC1_EN = %d \n", SSC1_EN);
}
void ssc_tune(int argc, char *argv[]){
	if(argc != 2){
		printf("\n Syntax: ssc_tune [PLL_SSC_MOD] [PLL_SSC_VSTEP]");
	}else{
		PLL_SSC_MOD   = atoi(argv[0]);
		PLL_SSC_VSTEP = atoi(argv[1]);
		printf("\n\t PLL_SSC_MOD   = %d ", PLL_SSC_MOD);
		printf("\n\t PLL_SSC_VSTEP = %d \n", PLL_SSC_VSTEP);
	}
}
void cmos(void){
	CLK_REF	 = 1;
	CLK_TYPE = 1;
	CLK_FREQ = 0;
	printf("\n\t Reference Clock: Internal CMOS \n");
}
void cml(void){
	CLK_REF  = 0;
	CLK_TYPE = 0;
	CLK_FREQ = 1;
	printf("\n\t Reference Clock: External CML \n");
}
void refclk_100(void){
	CLK_FREQ = 0;
	printf("\n\t Reference Clock: 100 MHz \n");
}
void refclk_50(void){
	CLK_FREQ = 1;
	printf("\n\t Reference Clock: 50 MHz \n");
}
void refclk_25(void){
	CLK_FREQ = 2;
	printf("\n\t Reference Clock: 25 MHz \n");
}
void pllgen1(void){
	PLL_GEN = 1;
	printf("\n\t Configure SERDES as GEN 1 \n");
}
void pllgen2(void){
	PLL_GEN = 2;
	printf("\n\t Configure SERDES as GEN 2 \n");
}
void pllgen3(void){
	PLL_GEN = 3;
	printf("\n\t Configure SERDES as GEN 3 \n");
}
void linkgen0(void){
	LINK_GEN = 0;
	printf("\n\t Speed Negotiation: Auto \n");
}
void linkgen1(void){
	LINK_GEN = 1;
	printf("\n\t Speed Negotiation: GEN 1 \n");
}
void linkgen2(void){
	LINK_GEN = 2;
	printf("\n\t Speed Negotiation: GEN 2 \n");
}
void linkgen3(void){
	LINK_GEN = 3;
	printf("\n\t Speed Negotiation: GEN 3 \n");
}
void pvt_man(void){
	PVT_MAN = 1;
	printf("\n\t Manual PVT Calibration is SET \n");
}
void pvt_auto(void){
	PVT_MAN = 0;
	printf("\n\t Auto PVT Calibration is SET \n");
}
void watermark(void){
	printf("\n\t WATERMARK = %d", WATERMARK);
}
void watermark_en(void){
	WATERMARK = 1;
	printf("\n\t WATERMARK is Enabled");
}
void watermark_dis(void){
	WATERMARK = 0;
	printf("\n\t WATERMARK is Disabled");
}
void fbs(void){
	printf("\n\t FIS-based switching = %d", FBS);
}
void fbs_en(void){
	FBS = 1;
	printf("\n\t FIS-based switching is Enabled");
}
void fbs_dis(void){
	FBS = 0;
	printf("\n\t FIS-based switching is Disabled");
}
void sec_sta(int argc, char *argv[]){
	if(argc != 1){
		printf("\n Syntax: sec_sta [HEX 64-bit number]");
	}else{
		STA_SECTOR = strtol(argv[0],NULL,0);
		printf("\n Start Sector = %d \n", STA_SECTOR);
	}
}
void sec_cnt(int argc, char *argv[]){
	if(argc != 1){
		printf("\n Syntax: sec_cnt [HEX 32-bit number]");
	}else{
		NUM_SECTOR = strtol(argv[0],NULL,0);
		printf("\n Number of Sectors = %d \n", NUM_SECTOR);
	}
}
void prd_size(int argc, char *argv[]){
	if(argc != 1){
		printf("\n Syntax: prd_size [HEX 32-bit number]");
	}else{
		PRD_SIZE = strtol(argv[0],NULL,0);
		printf("\n PRD Size = %d KB \n", PRD_SIZE);
	}
}

void kc_read32(int argc, char *argv[]){
	u32 csr_base, ctrl, addr;
	if(argc != 2){
		printf("\n Syntax: kc_read32 [CONTROLLER NUMBER] [HEX ADDRESS]");
	}else{
		ctrl = atoi(argv[0]);
		addr = strtol(argv[1],NULL,0);
		csr_base = sm_sata_get_csr_base(ctrl*2);
		printf("\n [0x%08x] = 0x%08x", addr, kc_sds_rd(csr_base, addr));
	}
}
void read32(int argc, char *argv[]){
	u32 addr;
	if(argc != 1){
		printf("\n Syntax: read32 [HEX ADDRESS]");
	}else{
		addr = strtol(argv[0],NULL,0);
		printf("\n [0x%08x] = 0x%08x", addr, sm_sata_read32(addr));
	}
}

void write32(int argc, char *argv[]){
	u32 addr, val;
	if(argc != 2){
		printf("\n Syntax: write32 [HEX 32-bit ADDRESS] [HEX 32-bit VALUE");
	}else{
		addr = strtol(argv[0],NULL,0);
		val  = strtol(argv[1],NULL,0);
		sm_host_write32(addr, val);
	}
}
void ctle_set(int argc, char *argv[]){
	u32 port, val;
	if(argc != 2){
		printf("\n Syntax: ctle_set [PORT NUMBER] [HEX 5-bit VALUE");
	}else{
		port = atoi(argv[0]);
		val  = strtol(argv[1],NULL,0);
#ifdef TUNING
		switch(port){
		case 0:
			CTLE_EQ_0 = val;
			break;
		case 1:
			CTLE_EQ_1 = val;
			break;
		case 2:
			CTLE_EQ_2 = val;
			break;
		case 3:
			CTLE_EQ_3 = val;
			break;
		case 4:
			CTLE_EQ_4 = val;
			break;
		case 5:
			CTLE_EQ_5 = val;
			break;
		default:
			break;
		}
		printf("\n CTLE_EQ_%d = 0x%02X", port, val);
#else
		CTLE_EQ = val;
		printf("\n CTLE_EQ = 0x%02X", port, val);
#endif
	}
}
void ctle_rd(int argc, char *argv[]){
	u32 port;
	if(argc != 1){
		printf("\n Syntax: ctle_wr [PORT NUMBER]");
	}else{
		port = atoi(argv[0]);
		sm_sata_ctle_rd(port);
	}
}
void ctle_wr(int argc, char *argv[]){
	u32 port, val;
	if(argc != 2){
		printf("\n Syntax: ctle_wr [PORT NUMBER] [HEX 5-bit VALUE");
	}else{
		port = atoi(argv[0]);
		val  = strtol(argv[1],NULL,0);
#ifdef TUNING
		switch(port){
		case 0:
			CTLE_EQ_0 = val;
			break;
		case 1:
			CTLE_EQ_1 = val;
			break;
		case 2:
			CTLE_EQ_2 = val;
			break;
		case 3:
			CTLE_EQ_3 = val;
			break;
		case 4:
			CTLE_EQ_4 = val;
			break;
		case 5:
			CTLE_EQ_5 = val;
			break;
		default:
			break;
		}
#else
		CTLE_EQ = val;
#endif
		sm_sata_ctle_wr(port, val);
	}
}

void pq_set(int argc, char *argv[]){
	u32 port, val;
	if(argc != 2){
		printf("\n Syntax: pq_set [PORT NUMBER] [HEX 7-bit VALUE");
	}else{
		port = atoi(argv[0]);
		val  = strtol(argv[1],NULL,0);
		PQ_REG = val;
		printf("\n PQ_REG = 0x%02X", port, val);
	}
}
void pq_rd(int argc, char *argv[]){
	u32 port;
	if(argc != 1){
		printf("\n Syntax: pq_wr [PORT NUMBER]");
	}else{
		port = atoi(argv[0]);
		sm_sata_pq_rd(port);
	}
}
void pq_wr(int argc, char *argv[]){
	u32 port, val;
	if(argc != 2){
		printf("\n Syntax: pq_wr [PORT NUMBER] [HEX 7-bit VALUE");
	}else{
		port = atoi(argv[0]);
		val  = strtol(argv[1],NULL,0);
		PQ_REG = val;
		sm_sata_pq_wr(port, val);
	}
}

void set_feature(int argc, char *argv[]){
/* Set Device Features */
	int i;
	int port    = atoi(argv[0]);
	int feature = atoi(argv[1]);
	if((argc != 2) || (port > 5) || (feature > 7)){
		printf("\n Syntax: set_feature [PORTS] [FEATURE_ID]");
		printf("\n\t where [PORTS]      = 0 .. 5");
		printf("\n\t where [FEATURE_ID] = 1 .. 7\n");
		printf("\n\t\t 1: Non-zero buffer offset in DMA Setup FIS");
		printf("\n\t\t 2: DMA Setup FIS Auto-Activate optimization");
		printf("\n\t\t 3: Device-initiated interface power state transitions");
		printf("\n\t\t 4: Guaranteed In-Order Data Delivery");
		printf("\n\t\t 5: Asynchronous Notification");
		printf("\n\t\t 6: Software Settings Preservation");
		printf("\n\t\t 7: Device Automatic Partial to Slumber transitions\n");
	}else{
		sm_sata_ata_feature_en(port, feature);
	}
}

void pxis(int argc, char *argv[]){
	int i, port;
	if((argc == 0) || (argc > 6)){
		printf("\n Syntax: pxis [PORTS]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
	}else{
		for(i=0; i<argc; ++i){
			port = atoi(argv[i]);
			sm_sata_pxis(port);
		}
	}
}
void pxssts(int argc, char *argv[]){
	int i, port;
	if((argc == 0) || (argc > 6)){
		printf("\n Syntax: pxssts [PORTS]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
	}else{
		for(i=0; i<argc; ++i){
			port = atoi(argv[i]);
			sm_sata_pxssts(port);
		}
	}
}
void pxserr(int argc, char *argv[]){
	int i, port;
	if((argc == 0) || (argc > 6)){
		printf("\n Syntax: pxserr [PORTS]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
	}else{
		for(i=0; i<argc; ++i){
			port = atoi(argv[i]);
			sm_sata_pxserr(port);
		}
	}
}

void status(int argc, char *argv[]){
	int i, port;
	if(argc > 6){
		printf("\n Syntax: status [PORTS]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
	}
	else if(argc == 0){
		printf("\n Global Status:");
		printf("\n\t Reference Clock    ");
		(CLK_REF) ? printf("Internal ") : printf("External ");
		(CLK_TYPE) ? printf("CMOS ") : printf("CML ");
		(CLK_FREQ) ? printf("(50MHz)") : printf("(100MHz)");
		printf("\n\t SSC                ");
		if(SSC_EN){
			printf("Enable ");
			printf("\n\t\t PLL_SSC_MOD   = 0x%02X = %d", PLL_SSC_MOD, PLL_SSC_MOD);
			printf("\n\t\t PLL_SSC_VSTEP = 0x%02X = %d", PLL_SSC_VSTEP, PLL_SSC_VSTEP);
		}else
			printf("Disable ");
		printf("\n\t SSC1               ");
		(SSC1_EN) ? printf("Enable ") : printf("Disable ");
		printf("\n\t WATERMARK          ");
		(WATERMARK) ? printf("Enable ") : printf("Disable ");
		printf("\n\t PVT Calibration    ");
		(PVT_MAN) ? printf("Manual ") : printf("Auto ");
		printf("\n\t PLL Locking set at ");
		if(PLL_GEN == 3)
			printf("GEN3");
		else if(PLL_GEN == 2)
			printf("GEN2");
		else if(PLL_GEN == 1)
			printf("GEN1");
		else
			printf("UNKNOWN");
		printf("\n\t Speed Negotiation  ");
		if(LINK_GEN == 3)
			printf("GEN3");
		else if(LINK_GEN == 2)
			printf("GEN2");
		else if(LINK_GEN == 1)
			printf("GEN1");
		else if(LINK_GEN == 0)
			printf("AUTO");
		else
			printf("UNKNOWN");
		printf("\n");
		printf("\n\t FIS-based switching ");
		(FBS) ? printf("Enable ") : printf("Disable ");
		printf("\n\t Start Sector       %d", STA_SECTOR);
		printf("\n\t Number of Sector   %d", NUM_SECTOR);
		printf("\n\t PRD Size (KB)      %d", PRD_SIZE);
	}
	else{
		for(i=0; i<argc; ++i){
			port = atoi(argv[i]);
			sm_sata_port_status(port);
		}
	}
}

void irq_en(int argc, char *argv[]){
	int port, eb;
	if(argc != 2){
		printf("\n Syntax: irq_en [PORTS] [EB]");
		printf("\n\t where [PORTS] = 0 .. 5");
		printf("\n\t where [EB]    = Enabling bits\n");
	}else{
		port = atoi(argv[0]);
		eb   = atoi(argv[1]);
		sm_sata_port_irq(port, eb);
	}
}

void fix_clr(int argc, char *argv[]){
	int i, port;
	if((argc == 0) || (argc > 6)){
		printf("\n Syntax: fix_clr [PORTS]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
	}else{
		for(i=0; i<argc; ++i){
			port = atoi(argv[i]);
			printf("\n\n Flushing Pending Commands on SATA Port%d ...", port);
			sm_sata_fix_clr(port);
		}
	}
}

void pll(int argc, char *argv[]){
	int i, port;
	if((argc == 0) || (argc > 6)){
		printf("\n Syntax: pll [PORTS]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
	}else{
		if(atoi(argv[0]) == 6){
			for(i=0; i<3; ++i){
				printf("\n\n PLL Locking on SATA Controller %d is running ...", i);
				sm_sata_init(i*2);
			}
		}else{
			for(i=0; i<argc; ++i){
				port = atoi(argv[i]);
				printf("\n\n PLL Locking on SATA Controller %d is running ...", port/2);
				sm_sata_init(port);
			}
		}
	}
}

void linkup(int argc, char *argv[]){
	int i, port;
	if((argc == 0) || (argc > 6)){
		printf("\n Syntax: linkup [PORTS]");
		printf("\n\t where [PORTS] = 0 .. 5, or 6 for all SATA ports\n");
	}else{
		if(atoi(argv[0]) == 6){
			for(i=0; i<6; ++i){
				printf("\n\n Linking Up on SATA Port%d is running ...", i);
				sm_sata_linkup(i);
			}
		}else{
			for(i=0; i<argc; ++i){
				port = atoi(argv[i]);
				printf("\n\n Linking Up on SATA Port%d is running ...", port);
				sm_sata_linkup(port);
			}
		}
	}
}
void linkup_reset(int argc, char *argv[]){
	int loop, fail_stop;
	if(argc != 2){
		printf("\n Syntax: linkup_reset [NUMBER OF LOOPS] [FAIL STOP]");
		printf("\n\t where [NUMBER OF LOOPS] = 0 is infinite");
		printf("\n\t where [FAIL STOP] = 0 or 1");
	}else{
		loop = atoi(argv[0]);
		fail_stop = atoi(argv[1]);
		sm_sata_linkup_reset(loop, fail_stop);
	}
}

void id(int argc, char *argv[]){
	int i, port;
	if((argc == 0) || (argc > 6)){
		printf("\n Syntax: id [PORTS]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
	}else{
		for(i=0; i<argc; ++i){
			port = atoi(argv[i]);
			printf("\n\n Reading ID on SATA Port%d ...", port);
			sm_sata_readid(port, 0);
		}
	}
}

void ssc_measure(int argc, char *argv[]){
	int port = atoi(argv[0]);
	if((argc != 1) || (port > 5)){
		printf("\n Syntax: ssc_measure [port_number]");
		printf("\n\t where port_number  = 0 .. 5");
	}
	else
		sm_sata_ssc_measure(port);
}

void pio_rd(int argc, char *argv[]){
	int port = atoi(argv[0]);
	int ss   = atoi(argv[1]);
	int sc   = atoi(argv[2]);
	if((argc != 3) || (port > 5)){
		printf("\n Syntax: pio_rd [port_number] [start_sector] [sector_count]");
		printf("\n\t where port_number  = 0 .. 5");
		printf("\n\t       start_sector > 0");
		printf("\n\t       sector_count > 0\n");
	}else
		sm_sata_pio_read(port, 0, ss, sc);
}
void pio_wr(int argc, char *argv[]){
	int port = atoi(argv[0]);
	int ss   = atoi(argv[1]);
	int sc   = atoi(argv[2]);
	if((argc != 3) || (port > 5)){
		printf("\n Syntax: pio_wr [port_number] [start_sector] [sector_count]");
		printf("\n\t where port_number  = 0 .. 5");
		printf("\n\t       start_sector > 0");
		printf("\n\t       sector_count > 0\n");
	}else
		sm_sata_pio_write(port, ss, sc);
}
void pio(int argc, char *argv[]){
	int i, port;
	if((argc == 0) || (argc > 6)){
		printf("\n Syntax: pio [PORTS]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
	}else{
		for(i=0; i<argc; ++i){
			port = atoi(argv[i]);
			printf("\n\n PIO R/W Test on SATA Port%d is running ...", port);
			sm_sata_pio_test(port, 0);
		}
	}
}
void pio_stress(int argc, char *argv[]){
	int i, port;
	if((argc == 0) || (argc > 6)){
		printf("\n Syntax: pio_stress [PORTS]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
	}else{
		for(i=0; i<argc; ++i){
			port = atoi(argv[i]);
			printf("\n\n PIO Stress Test on SATA Port%d is running ...", port);
			sm_sata_xdata_stress(port, 0, 2, ATA_CMD_PIO_WR_EXT, ATA_CMD_PIO_RD_EXT, 5, 20000, 10000);
		}
	}
}
void pio_stress_rd(int argc, char *argv[]){
	int i, port;
	if((argc == 0) || (argc > 6)){
		printf("\n Syntax: pio_stress_rd [PORTS]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
	}else{
		for(i=0; i<argc; ++i){
			port = atoi(argv[i]);
			printf("\n\n PIO READ Stress Test on SATA Port%d is running ...", port);
			sm_sata_xdata_stress(port, 0, 0, ATA_CMD_PIO_WR_EXT, ATA_CMD_PIO_RD_EXT, 5, 20000, 10000);
		}
	}
}
void pio_stress_wr(int argc, char *argv[]){
	int i, port;
	if((argc == 0) || (argc > 6)){
		printf("\n Syntax: pio_stress_wr [PORTS]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
	}else{
		for(i=0; i<argc; ++i){
			port = atoi(argv[i]);
			printf("\n\n PIO WRITE Stress Test on SATA Port%d is running ...", port);
			sm_sata_xdata_stress(port, 0, 1, ATA_CMD_PIO_WR_EXT, ATA_CMD_PIO_RD_EXT, 5, 20000, 10000);
		}
	}
}

void dma_rd(int argc, char *argv[]){
	int port = atoi(argv[0]);
	if((argc != 1) || (port > 5)){
		printf("\n Syntax: dma_rd [port_number]");
		printf("\n\t where port_number  = 0 .. 5");
	}else
		sm_sata_dma_read(port);
}
void dma_wr(int argc, char *argv[]){
	int port = atoi(argv[0]);
	if((argc != 1) || (port > 5)){
		printf("\n Syntax: dma_wr [port_number]");
		printf("\n\t where port_number  = 0 .. 5");
	}else
		sm_sata_dma_write(port);
}
void dma(int argc, char *argv[]){
	int i, port;
	if((argc == 0) || (argc > 6)){
		printf("\n Syntax: dma [PORTS]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
	}else{
		for(i=0; i<argc; ++i){
			port = atoi(argv[i]);
			printf("\n\n DMA R/W Test on SATA Port%d is running ...", port);
			sm_sata_dma_test(port, 0);
		}
	}
}
void dma_stress(int argc, char *argv[]){
	int i, port;
	if((argc == 0) || (argc > 6)){
		printf("\n Syntax: dma_stress [PORTS]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
	}else{
		for(i=0; i<argc; ++i){
			port = atoi(argv[i]);
			printf("\n\n DMA Stress Test on SATA Port%d is running ...", port);
			sm_sata_xdata_stress(port, 0, 2, ATA_CMD_DMA_WR_EXT, ATA_CMD_DMA_RD_EXT, 5, 20000, 10000);
		}
	}
}
void dma_stress_rd(int argc, char *argv[]){
	int i, port;
	if((argc == 0) || (argc > 6)){
		printf("\n Syntax: dma_stress_rd [PORTS]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
	}else{
		for(i=0; i<argc; ++i){
			port = atoi(argv[i]);
			printf("\n\n DMA READ Stress Test on SATA Port%d is running ...", port);
			sm_sata_xdata_stress(port, 0, 0, ATA_CMD_DMA_WR_EXT, ATA_CMD_DMA_RD_EXT, 5, 20000, 10000);
		}
	}
}
void dma_stress_wr(int argc, char *argv[]){
	int i, port;
	if((argc == 0) || (argc > 6)){
		printf("\n Syntax: dma_stress_wr [PORTS]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
	}else{
		for(i=0; i<argc; ++i){
			port = atoi(argv[i]);
			printf("\n\n DMA WRITE Stress Test on SATA Port%d is running ...", port);
			sm_sata_xdata_stress(port, 0, 1, ATA_CMD_DMA_WR_EXT, ATA_CMD_DMA_RD_EXT, 5, 20000, 10000);
		}
	}
}


void fpdma_rd(int argc, char *argv[]){
	int port = atoi(argv[0]);
	int ss   = atoi(argv[1]);
	int sc   = atoi(argv[2]);
	if((argc != 3) || (port > 5)){
		printf("\n Syntax: fpdma_rd [port_number] [start_sector] [sector_count]");
		printf("\n\t where port_number  = 0 .. 5");
		printf("\n\t       start_sector > 0");
		printf("\n\t       sector_count > 0\n");
	}else
		sm_sata_fpdma_read(port, ss, sc);
}
void fpdma_wr(int argc, char *argv[]){
	int port = atoi(argv[0]);
	int ss   = atoi(argv[1]);
	int sc   = atoi(argv[2]);
	if((argc != 3) || (port > 5)){
		printf("\n Syntax: fpdma_wr [port_number] [start_sector] [sector_count]");
		printf("\n\t where port_number  = 0 .. 5");
		printf("\n\t       start_sector > 0");
		printf("\n\t       sector_count > 0\n");
	}else
		sm_sata_fpdma_write(port, ss, sc);
}
void fpdma(int argc, char *argv[]){
	int i, port;
	if((argc == 0) || (argc > 6)){
		printf("\n Syntax: fpdma [PORTS]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
	}else{
		for(i=0; i<argc; ++i){
			port = atoi(argv[i]);
			printf("\n\n FPDMA R/W Test on SATA Port%d is running ...", port);
			sm_sata_fpdma_test(port, 0);
		}
	}
}
void fpdma_stress(int argc, char *argv[]){
	int i, port;
	if((argc == 0) || (argc > 6)){
		printf("\n Syntax: fpdma_stress [PORTS]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
	}else{
		for(i=0; i<argc; ++i){
			port = atoi(argv[i]);
			printf("\n\n FPDMA Stress Test on SATA Port%d is running ...", port);
			sm_sata_xdata_stress(port, 0, 2, ATA_CMD_FPDMA_WR, ATA_CMD_FPDMA_RD, 5, 20000, 10000);
		}
	}
}
void fpdma_stress_rd(int argc, char *argv[]){
	int i, port;
	if((argc == 0) || (argc > 6)){
		printf("\n Syntax: fpdma_stress_rd [PORTS]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
	}else{
		for(i=0; i<argc; ++i){
			port = atoi(argv[i]);
			printf("\n\n FPDMA READ Stress Test on SATA Port%d is running ...", port);
			sm_sata_xdata_stress(port, 0, 0, ATA_CMD_FPDMA_WR, ATA_CMD_FPDMA_RD, 5, 20000, 10000);
		}
	}
}
void fpdma_stress_wr(int argc, char *argv[]){
	int i, port;
	if((argc == 0) || (argc > 6)){
		printf("\n Syntax: fpdma_stress_wr [PORTS]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
	}else{
		for(i=0; i<argc; ++i){
			port = atoi(argv[i]);
			printf("\n\n FPDMA WRITE Stress Test on SATA Port%d is running ...", port);
			sm_sata_xdata_stress(port, 0, 1, ATA_CMD_FPDMA_WR, ATA_CMD_FPDMA_RD, 5, 20000, 10000);
		}
	}
}


void pwr_test(int argc, char *argv[]){
	int i, port;
	if((argc == 0) || (argc > 6)){
		printf("\n Syntax: pwr_test [PORTS]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
	}else{
		for(i=0; i<argc; ++i){
			port = atoi(argv[i]);
			printf("\n\n Power Mode Test on SATA Port%d is running ...", port);
			sm_sata_pwr_test(port, 0);
		}
	}
}

void ncq(int argc, char *argv[]){
	int i, port;
	if((argc == 0) || (argc > 6)){
		printf("\n Syntax: ncq [PORTS]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
	}else{
		for(i=0; i<argc; ++i){
			port = atoi(argv[i]);
			printf("\n\n Native Command Queuing Test on SATA Port%d is running ...", port);
			sm_sata_ncq_test(port, 0);
		}
	}
}

void ccc_en(int argc, char *argv[]){
	int port, tv, cc;
	if(argc != 3){
		printf("\n Syntax: ccc_en [PORTS] [TV] [CC]");
		printf("\n\t where [PORTS] = 0 .. 5");
		printf("\n\t where [TV]    = The HBA will signal a CCC interrupt when TIMEOUT has decremented to 0");
		printf("\n\t where [CC]    = Specifies the number of command completions that are necessary to cause a CCC interrupt\n");
	}else{
		port = atoi(argv[0]);
		tv   = atoi(argv[1]);
		cc   = atoi(argv[2]);
		sm_sata_irq_ccc_en(port, tv, cc);
	}
}

void ccc_dis(int argc, char *argv[]){
	int i, port;
	if((argc == 0) || (argc > 6)){
		printf("\n Syntax: ccc_dis [PORTS]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
	}else{
		for(i=0; i<argc; ++i){
			port = atoi(argv[i]);
			sm_sata_irq_ccc_dis(port);
		}
	}
}

void irq(int argc, char *argv[]){
	int port, pmp, irq_id;
	if(argc != 3){
		printf("\n Syntax: irq [PORTS] [PMP] [IRQ_ID]");
		printf("\n\t where [PORTS]  = 0 .. 5 ");
		printf("\n\t where [PMP]    = PM Ports ");
		printf("\n\t where [IRQ_ID] = IRQ ID \n");
	}else{
		port = atoi(argv[0]);
		pmp = atoi(argv[1]);
		irq_id = atoi(argv[2]);
		printf("\n\n IRQ Test on SATA Port%d is running ...", port);
		sm_sata_irq_test(port, pmp, irq_id);
	}
}

void hotplug(int argc, char *argv[]){
	int port, pmp, irq_id;
	if(argc != 1){
		printf("\n Syntax: hotplug [PORTS]");
		printf("\n\t where [PORTS]  = 0 .. 5 ");
	}else{
		port = atoi(argv[0]);
		printf("\n\n HotPlug Test on SATA Port%d is running ...", port);
		sm_sata_hotplug_test(port, 0);
	}
}

void asr(int argc, char *argv[]){
	int port, pmp, irq_id;
	if(argc != 2){
		printf("\n Syntax: asr [PORTS] [PMP]");
		printf("\n\t where [PORTS]  = 0 .. 5 ");
		printf("\n\t where [PMP]    = PM Ports ");
	}else{
		port = atoi(argv[0]);
		pmp = atoi(argv[1]);
		printf("\n\n Asynchronous Signal Recovery Test on SATA Port%d is running ...", port);
		sm_sata_asr_test(port, pmp);
	}
}

void ccc(int argc, char *argv[]){
	int i, port;
	if((argc == 0) || (argc > 6)){
		printf("\n Syntax: ccc [PORTS]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
	}else{
		for(i=0; i<argc; ++i){
			port = atoi(argv[i]);
			printf("\n\n Command Completion Coalescing Test on SATA Port%d is running ...", port);
			sm_sata_ccc_test(port, 0);
		}
	}
}

void bw_cal(int argc, char *argv[])
{
	int i, port;
	int sector_count = 1024;
	if((argc == 0) || (argc > 6)){
		printf("\n Syntax: bw_cal [PORTS]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
	}else{
		if(atoi(argv[0]) == 6) argc = 6;
		for(i=0; i<argc; ++i){
			port = (atoi(argv[0]) == 6) ? i : atoi(argv[i]);
			printf("\n\n Bandwidth Calculation Test on SATA Port%d is running ...", port);
			printf("\n FPDMA ...");
			sm_sata_bw_monitor(port, sector_count, FPDMA);
			printf("\n DMA ...");
			sm_sata_bw_monitor(port, sector_count, DMA);
			printf("\n PIO ...");
			sm_sata_bw_monitor(port, sector_count, PIO);
		}
	}
}
void bw_cal1(int argc, char *argv[]){
	int port, sc, md;
	if(argc != 3){
		printf("\n Syntax: bw_cal [PORTS] [NUM_SEC] [MODE]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
	}else{
		port = atoi(argv[0]);
		sc = atoi(argv[1]);
		md = atoi(argv[2]);
		//printf("\n\n Bandwidth Calculation Test on SATA Port%d is running ...", port);
		sm_sata_bw_monitor(port, sc, md);
	}
}
void an_test(int argc, char *argv[]){
	int i, port;
	if((argc == 0) || (argc > 6)){
		printf("\n Syntax: an_test [PORTS]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
	}else{
		for(i=0; i<argc; ++i){
			port = atoi(argv[i]);
			printf("\n\n Asynchronous Notification Test on SATA Port%d is running ...", port);
			sm_sata_asyn_note(port);
		}
	}
}

void dtychk(int argc, char *argv[])
{
	int port;
	if(argc != 1){
		printf("\n Syntax: sata_dtychk [PORT]");
		printf("\n\t where [PORT] = 0 .. 5\n");
	}else{
		port = atoi(argv[0]);
		(sm_sata_dty_chk(port)) ? printf("\n ===> Disparity Error") : printf("\n ===> NO Disparity Error");
	}
}

void dtyfix(int argc, char *argv[])
{
	int port;
	if(argc != 1){
		printf("\n Syntax: sata_dtyfix [PORT]");
		printf("\n\t where [PORT] = 0 .. 5\n");
	}else{
		port = atoi(argv[0]);
		if(sm_sata_dty_chk(port))
			sm_sata_dty_fix(port);
		else printf("\n\t NOTE: Disparity fix not required");
	}
}

void bist(int argc, char *argv[])
{
	int port;
	if(argc != 1){
		printf("\n Syntax: sata_bist_test [PORT]");
		printf("\n\t where [PORT] = 0 .. 5\n");
	}else{
		port = atoi(argv[0]);
		sm_sata_bist_L_test(port);
	}
}

/*********** for PM ************/
void pmp_read32(int argc, char *argv[]){
	int port, pmp, reg;
	if(argc != 3){
		printf("\n Syntax: pmp_read32 [PORTS] [PMP] [REG_NUM]");
		printf("\n\t where [PORTS]   = 0 .. 5\n");
		printf("\n\t where [PMP]     = PM Port\n");
		printf("\n\t where [REG_NUM] = Register id\n");
	}else{
		port = atoi(argv[0]);
		pmp  = atoi(argv[1]);
		reg  = atoi(argv[2]);
		printf("\n\n Reading PMP%d_%d reg_%d = 0x%08X\n", port, pmp, reg, sm_sata_pmp_read32(port, pmp, reg));
	}
}
void pmp_write32(int argc, char *argv[]){
	int port, pmp, reg, data32;
	if(argc != 4){
		printf("\n Syntax: pmp_write32 [PORTS] [PMP] [REG_NUM] [VALUE]");
		printf("\n\t where [PORTS]   = 0 .. 5\n");
		printf("\n\t where [PMP]     = PM Port\n");
		printf("\n\t where [REG_NUM] = Register id\n");
		printf("\n\t where [VALUE]   = 32-bit HEX Data\n");
	}else{
		port   = atoi(argv[0]);
		pmp    = atoi(argv[1]);
		reg    = atoi(argv[2]);
		data32 = strtol(argv[3],NULL,0);
		sm_sata_pmp_write32(port, pmp, reg, data32);
	}
}

void pmp_id(int argc, char *argv[]){
	int port, pmp;
	if(argc != 2){
		printf("\n Syntax: pmp_id [PORTS] [PMP]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
		printf("\n\t where [PMP]   = PM Port\n");
	}else{
		port = atoi(argv[0]);
		pmp  = atoi(argv[1]);
		printf("\n\n Reading ID on PMP%d_%d ...", port, pmp);
		sm_sata_readid(port, pmp);
	}
}

void pmp_pio(int argc, char *argv[]){
	int port, pmp;
	if(argc != 2){
		printf("\n Syntax: pmp_pio [PORTS] [PMP]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
		printf("\n\t where [PMP]   = PM Port\n");
	}else{
		port = atoi(argv[0]);
		pmp  = atoi(argv[1]);
		printf("\n\n PIO R/W Test on PMP%d_%d is running ...", port, pmp);
		sm_sata_pio_test(port, pmp);
	}
}

void pmp_dma(int argc, char *argv[]){
	int port, pmp;
	if(argc != 2){
		printf("\n Syntax: pmp_dma [PORTS] [PMP]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
		printf("\n\t where [PMP]   = PM Port\n");
	}else{
		port = atoi(argv[0]);
		pmp  = atoi(argv[1]);
		printf("\n\n DMA R/W Test on PMP%d_%d is running ...", port, pmp);
		sm_sata_dma_test(port, pmp);
	}
}

void pmp_fpdma(int argc, char *argv[]){
	int port, pmp;
	if(argc != 2){
		printf("\n Syntax: pmp_fpdma [PORTS] [PMP]");
		printf("\n\t where [PORTS] = 0 .. 5\n");
		printf("\n\t where [PMP]   = PM Port\n");
	}else{
		port = atoi(argv[0]);
		pmp  = atoi(argv[1]);
		printf("\n\n FPDMA R/W Test on PMP%d_%d is running ...", port, pmp);
		sm_sata_fpdma_test(port, pmp);
	}
}

void mem_compare(int argc, char *argv[]){
	int mem1, mem2, sectors;
	if(argc != 3){
		printf("\n Syntax: mem_compare [MEM1] [MEM2] [SECTORS]");
		printf("\n\t where [MEM1] = Start address of Memory 1 (Hex address)");
		printf("\n\t where [MEM2] = Start address of Memory 2 (Hex address)");
		printf("\n\t where [SECTORS] = Number of sectors (Decimal number)");
	}else{
		mem1 = strtol(argv[0],NULL,0);;
		mem2 = strtol(argv[1],NULL,0);;
		sectors = atoi(argv[2]);
		memory_compare(0, mem1, mem2, sectors);
	}
}


#if 1	/* for Automation */
void sata_enet_mux(int argc, char *argv[]){
	int i, ctrl;
	if(argc != 1){
		printf("\n Syntax: sata_enet_mux [CONTROLLER]");
		printf("\n\t where [CONTROLLER] = 0, 1, 2 or 3 for all SATA controllers");
	}else{
		printf("\n L0_SATA_CONTROLLER_X_SATAENET_SEL\n", ctrl);
		if(atoi(argv[0]) == 3){
			for(i=0; i<atoi(argv[0]); ++i) sm_sata_enet_muxing_test(i);
		}else{
			ctrl = atoi(argv[0]);
			sm_sata_enet_muxing_test(ctrl);
		}
	}
}
void bit_AHB_clock_test(int argc, char *argv[]){
	int i, ctrl;
	if(argc != 1){
		printf("\n Syntax: bit_AHB_clock_test [CONTROLLER]");
		printf("\n\t where [CONTROLLER] = 0, 1, 2, or 3 for all SATA controllers.\n");
	}else{
		printf("\n L0_SATA_CONTROLLER_X_AHB_CLOCK_ENABLE", ctrl);
		if(atoi(argv[0]) == 3){
			for(i=0; i<atoi(argv[0]); ++i) sm_sata_sataclkenreg_bit_test(i, 0x20);
		}else{
			ctrl = atoi(argv[0]);
			sm_sata_sataclkenreg_bit_test(ctrl, 0x20);
		}
	}
}
void bit_AXI_clock_test(int argc, char *argv[]){
	int i, ctrl;
	if(argc != 1){
		printf("\n Syntax: bit_AXI_clock_test [CONTROLLER]");
		printf("\n\t where [CONTROLLER] = 0, 1, 2, or 3 for all SATA controllers.\n");
	}else{
		printf("\n L0_SATA_CONTROLLER_X_AXI_CLOCK_ENABLE", ctrl);
		if(atoi(argv[0]) == 3){
			for(i=0; i<atoi(argv[0]); ++i) sm_sata_sataclkenreg_bit_test(i, 0x10);
		}else{
			ctrl = atoi(argv[0]);
			sm_sata_sataclkenreg_bit_test(ctrl, 0x10);
		}
	}
}
void bit_PMCLK_clock_test(int argc, char *argv[]){
	int i, ctrl;
	if(argc != 1){
		printf("\n Syntax: bit_PMCLK_clock_test [CONTROLLER]");
		printf("\n\t where [CONTROLLER] = 0, 1, 2, or 3 for all SATA controllers.\n");
	}else{
		printf("\n L0_SATA_CONTROLLER_X_PMCLK_CLOCK_ENABLE", ctrl);
		if(atoi(argv[0]) == 3){
			for(i=0; i<atoi(argv[0]); ++i) sm_sata_sataclkenreg_bit_test(i, 0x08);
		}else{
			ctrl = atoi(argv[0]);
			sm_sata_sataclkenreg_bit_test(ctrl, 0x08);
		}
	}
}
void bit_CORE1_clock_test(int argc, char *argv[]){
	int i, ctrl;
	if(argc != 1){
		printf("\n Syntax: bit_CORE1_clock_test [CONTROLLER]");
		printf("\n\t where [CONTROLLER] = 0, 1, 2, or 3 for all SATA controllers.\n");
	}else{
		printf("\n L0_SATA_CONTROLLER_X_CORE1_CLOCK_ENABLE", ctrl);
		if(atoi(argv[0]) == 3){
			for(i=0; i<atoi(argv[0]); ++i) sm_sata_sataclkenreg_bit_test(i, 0x04);
		}else{
			ctrl = atoi(argv[0]);
			sm_sata_sataclkenreg_bit_test(ctrl, 0x04);
		}
	}
}
void bit_CORE0_clock_test(int argc, char *argv[]){
	int i, ctrl;
	if(argc != 1){
		printf("\n Syntax: bit_CORE0_clock_test [CONTROLLER]");
		printf("\n\t where [CONTROLLER] = 0, 1, 2, or 3 for all SATA controllers.\n");
	}else{
		printf("\n L0_SATA_CONTROLLER_X_CORE0_CLOCK_ENABLE", ctrl);
		if(atoi(argv[0]) == 3){
			for(i=0; i<atoi(argv[0]); ++i) sm_sata_sataclkenreg_bit_test(i, 0x02);
		}else{
			ctrl = atoi(argv[0]);
			sm_sata_sataclkenreg_bit_test(ctrl, 0x02);
		}
	}
}
void bit_CSR_clock_test(int argc, char *argv[]){
	int i, ctrl;
	if(argc != 1){
		printf("\n Syntax: bit_CSR_clock_test [CONTROLLER]");
		printf("\n\t where [CONTROLLER] = 0, 1, 2, or 3 for all SATA controllers.\n");
	}else{
		printf("\n L0_SATA_CONTROLLER_X_CSR_CLOCK_ENABLE", ctrl);
		if(atoi(argv[0]) == 3){
			for(i=0; i<atoi(argv[0]); ++i) sm_sata_sataclkenreg_bit_test(i, 0x01);
		}else{
			ctrl = atoi(argv[0]);
			sm_sata_sataclkenreg_bit_test(ctrl, 0x01);
		}
	}
}
void bit_MEM_reset_test(int argc, char *argv[]){
	int i, ctrl;
	if(argc != 1){
		printf("\n Syntax: bit_MEM_reset_test [CONTROLLER]");
		printf("\n\t where [CONTROLLER] = 0, 1, 2, or 3 for all SATA controllers.\n");
	}else{
		printf("\n L0_SATA_CONTROLLER_X_MEM_RESET", ctrl);
		if(atoi(argv[0]) == 3){
			for(i=0; i<atoi(argv[0]); ++i) sm_sata_satasresetreg_bit_test(i, 0x20);
		}else{
			ctrl = atoi(argv[0]);
			sm_sata_satasresetreg_bit_test(ctrl, 0x20);
		}
	}
}
void bit_PMCLK_reset_test(int argc, char *argv[]){
	int i, ctrl;
	if(argc != 1){
		printf("\n Syntax: bit_PMCLK_reset_test [CONTROLLER]");
		printf("\n\t where [CONTROLLER] = 0, 1, 2, or 3 for all SATA controllers.\n");
	}else{
		printf("\n L0_SATA_CONTROLLER_X_PMCLK_RESET", ctrl);
		if(atoi(argv[0]) == 3){
			for(i=0; i<atoi(argv[0]); ++i) sm_sata_satasresetreg_bit_test(i, 0x10);
		}else{
			ctrl = atoi(argv[0]);
			sm_sata_satasresetreg_bit_test(ctrl, 0x10);
		}
	}
}
void bit_PCLK_reset_test(int argc, char *argv[]){
	int i, ctrl;
	if(argc != 1){
		printf("\n Syntax: bit_PCLK_reset_test [CONTROLLER]");
		printf("\n\t where [CONTROLLER] = 0, 1, 2, or 3 for all SATA controllers.\n");
	}else{
		printf("\n L0_SATA_CONTROLLER_X_PCLK_RESET", ctrl);
		if(atoi(argv[0]) == 3){
			for(i=0; i<atoi(argv[0]); ++i) sm_sata_satasresetreg_bit_test(i, 0x08);
		}else{
			ctrl = atoi(argv[0]);
			sm_sata_satasresetreg_bit_test(ctrl, 0x08);
		}
	}
}
void bit_SDS_reset_test(int argc, char *argv[]){
	int i, ctrl;
	if(argc != 1){
		printf("\n Syntax: bit_SDS_reset_test [CONTROLLER]");
		printf("\n\t where [CONTROLLER] = 0, 1, 2, or 3 for all SATA controllers.\n");
	}else{
		printf("\n L0_SATA_CONTROLLER_X_SDS_RESET", ctrl);
		if(atoi(argv[0]) == 3){
			for(i=0; i<atoi(argv[0]); ++i) sm_sata_satasresetreg_bit_test(i, 0x04);
		}else{
			ctrl = atoi(argv[0]);
			sm_sata_satasresetreg_bit_test(ctrl, 0x04);
		}
	}
}
void bit_CORE_reset_test(int argc, char *argv[]){
	int i, ctrl;
	if(argc != 1){
		printf("\n Syntax: bit_CORE_reset_test [CONTROLLER]");
		printf("\n\t where [CONTROLLER] = 0, 1, 2, or 3 for all SATA controllers.\n");
	}else{
		printf("\n L0_SATA_CONTROLLER_X_CORE_RESET", ctrl);
		if(atoi(argv[0]) == 3){
			for(i=0; i<atoi(argv[0]); ++i) sm_sata_satasresetreg_bit_test(i, 0x02);
		}else{
			ctrl = atoi(argv[0]);
			sm_sata_satasresetreg_bit_test(ctrl, 0x02);
		}
	}
}
void bit_CSR_reset_test(int argc, char *argv[]){
	int i, ctrl;
	if(argc != 1){
		printf("\n Syntax: bit_CSR_reset_test [CONTROLLER]");
		printf("\n\t where [CONTROLLER] = 0, 1, 2, or 3 for all SATA controllers.\n");
	}else{
		printf("\n L0_SATA_CONTROLLER_X_CSR_RESET", ctrl);
		if(atoi(argv[0]) == 3){
			for(i=0; i<atoi(argv[0]); ++i) sm_sata_satasresetreg_bit_test(i, 0x01);
		}else{
			ctrl = atoi(argv[0]);
			sm_sata_satasresetreg_bit_test(ctrl, 0x01);
		}
	}
}
void kc_sds_reset_test(int argc, char *argv[]){
	int i, ctrl;
	if(argc != 1){
		printf("\n Syntax: kc_sds_reset_test [CONTROLLER]");
		printf("\n\t where [CONTROLLER] = 0, 1, 2, or 3 for all SATA controllers.\n");
	}else{
		printf("\n L0_SATA_CONTROLLER_X_KOOLCHIP_SERDES_RESET", ctrl);
		if(atoi(argv[0]) == 3){
			for(i=0; i<atoi(argv[0]); ++i) sm_sata_kc_sds_rst(i);
		}else{
			ctrl = atoi(argv[0]);
			sm_sata_kc_sds_rst(ctrl);
		}
	}
}
void kc_sds_enable_test(int argc, char *argv[]){
	int i, ctrl;
	if(argc != 1){
		printf("\n Syntax: kc_sds_enable_test [CONTROLLER]");
		printf("\n\t where [CONTROLLER] = 0, 1, 2, or 3 for all SATA controllers.\n");
	}else{
		printf("\n L0_SATA_CONTROLLER_X_KOOLCHIP_SERDES_ENABLE", ctrl);
		if(atoi(argv[0]) == 3){
			for(i=0; i<atoi(argv[0]); ++i) sm_sata_kc_sds_ena(i);
		}else{
			ctrl = atoi(argv[0]);
			sm_sata_kc_sds_ena(ctrl);
		}
	}
}
void pll_lock_test(int argc, char *argv[]){
	int i, ctrl;
	if(argc != 1){
		printf("\n Syntax: pll_lock_test [CONTROLLER]");
		printf("\n\t where [CONTROLLER] = 0, 1, 2, or 3 for all SATA controllers.\n");
	}else{
		printf("\n L0_SATA_CONTROLLER_X_PLL_LOCK", ctrl);
		if(atoi(argv[0]) == 3){
			for(i=0; i<atoi(argv[0]); ++i) sm_sata_pll_lock(i);
		}else{
			ctrl = atoi(argv[0]);
			sm_sata_pll_lock(ctrl);
		}
	}
}
void linkup_test(int argc, char *argv[]){
	int i, port;
	if(argc != 1){
		printf("\n Syntax: linkup_test [PORT]");
		printf("\n\t where [PORT] = 0, 1, 2, or 3 for all SATA controllers.\n");
	}else{
		printf("\n L0_SATA_CONTROLLER_X_LINKUP", port);
		if(atoi(argv[0]) == 6){
			for(i=0; i<atoi(argv[0]); ++i) sm_sata_link_up(i);
		}else{
			port = atoi(argv[0]);
			sm_sata_link_up(port);
		}
	}
}
#endif /* for Automation */

//========================================================================//
void rx_margin(int argc, char *argv[]){
	int i, port, depth;
	if(argc != 2){
		printf("\n Syntax: rx_margin [PORT] [DEPTH]");
		printf("\n\t where [PORT]  = 0, 1, 2, or 3 for all SATA controllers.");
		printf("\n\t where [DEPTH] = level of corners for scanning.\n");
	}else{
		port = atoi(argv[0]);
		depth = atoi(argv[1]);
		depth += (depth == 0) ? 1 : 0;
		if(atoi(argv[0]) == 6){
			for(i=0; i<atoi(argv[0]); ++i) {
				printf("\n\nSATA RX MARGIN on SATA Port %d", i);
				sm_sata_rx_margin(i, depth);
			}
		}else {
			printf("\nSATA RX MARGIN on SATA Port %d", port);
			sm_sata_rx_margin(port, depth);
		}
	}
}
#endif /* _SATA_BRINGUP_C__ */
