/* Author: your_name@apm.com 
*  Company: Applied Micro Circuits Corporation (AMCC)
* 
* Describe the purpose of your Test here
*
*/
#include "L0_GFC_BASIC_SRAM_TEST.h"
#include <mmu.h>
#define NAND_BUFFER_START_ADDR 	0xC00000
#define NAND_BUFFER_END_ADDR   	0xCF0800
#define SRAM_BUFFER_START_ADDR 	0xC00000
#define SRAM_BUFFER_END_ADDR   	0xCF0800
#define NOR_BUFFER_START_ADDR 	0xC00000
#define NOR_BUFFER_END_ADDR   	0xCF0800
char init = 0;

//Tinh-SLT: change zzzmain to ebus_test
//function call
#define printPASS printPASS_gfc
#define printFAIL printFAIL_gfc
#define read read_gfc
#define write write_gfc


int ebus_test (void) {
	int sram_status = 0;
	int nor_status  = 0;
	int nand_status = 0;
	  int read_data;
	  int write_data;
	char c;

//----- Put your code here -------
//    printf("Storm SOC: GFC\n\r");
//	read_data = read(0x1701C008);
//	printf("GFC_CLKEN =0x%08x \r\n", read_data);
//	write_data = (read_data & 0xffffffFd) | 0x00;
//	printf("GFC_CLKEN =0x%08x \r\n", write_data);
//	write (0x1701C008, write_data);
//
//	read_data = read(0x1701C000);
//    printf("GFC Soft Reset =0x%08x \r\n", read_data);
//    write_data = (read_data & 0xfffffffd) | 0x2;
//    printf("GFC Soft Reset =0x%08x \r\n", write_data);
//    write (0x1701C000, write_data);
//
//	read_data = read(0x1701C008);
//	printf("GFC_CLKEN =0x%08x \r\n", read_data);
//	write_data = (read_data & 0xffffffFd) | 0x02;
//	printf("GFC_CLKEN =0x%08x \r\n", write_data);
//	write (0x1701C008, write_data);

		read_data = read(0x1701C000);
	    printf("GFC Soft Reset =0x%08x \r\n", read_data);
	    write_data = (read_data & 0xfffffff8) | 0x7;
	    printf("GFC Soft Reset =0x%08x \r\n", write_data);
	    write (0x1701C000, write_data);

	    write_data = (read_data & 0xfffffff8);
	    printf("GFC Soft Reset =0x%08x \r\n", write_data);
	    write (0x1701C000, write_data);

    // disabling all banks
    disable_norsram_banks(BANK0);
    disable_norsram_banks(BANK1);
    disable_norsram_banks(BANK2);
    disable_norsram_banks(BANK3);
    disable_norsram_banks(BANK4);
    disable_norsram_banks(BANK5);
    if (init == 0)
    {
        printf("=*=*=*=*=*=*=*=*=*=*= MAP TESTS *=*=*=*=**=*=*=*=*=*=\r\n");
//    	remove_bootmap();
//    	flat_map(0x00000000, 0x02000000, 0); // sram + nor
    	flat_map(0x000C00000, 0x02000000, 0); // sram + nor
    	init = 1 ;
//	flat_map(NAND_BUFFER_START_ADDR, (NAND_BUFFER_END_ADDR - NAND_BUFFER_STARTADD) + 0x2000, 0);
//	flat_map(SRAM_BUFFER_START_ADDR, (SRAM_BUFFER_END_ADDR - SRAM_BUFFER_STARTADD) + 0x2000, 0);
//	flat_map(NOR_BUFFER_START_ADDR, (NOR_BUFFER_END_ADDR - NOR_BUFFER_STARTADD) + 0x2000, 0);
    }


    //Tinh-SLT:
    //Comment out the SRAM test
    //printf("=*=*=*=*=*=*=*=*=*=*= SRAM TESTS *=*=*=*=**=*=*=*=*=*=\r\n");
	//sram_status = sram_test();
    printf("=*=*=*=*=*=*=*=*=*=*= NOR TESTS *=*=*=*=**=*=*=*=*=**=*=*=*=*=\r\n");
    nor_status = nor_test();
    printf("=*=*=*=*=*=*=*=*=*=*= NAND TESTS *=*=*=**=*=*=*=*=**=*=*=*=*=*=\r\n");
	nand_status = nand();

//	gfc_status_check();
	//Tinh-SLT: comment out the SRAM test
	//if (sram_status != 0)
	//{
	 //   printf("=*=*=*=*=*=*=*=*=*=*= SRAM TESTS *=*=*=*=**=*=*=**=*=*=*=*=*=*=\r\n");
	//	printf("=*=*=*=*=*=*=*=*=*=*= RESULT: SRAM TEST FAILED =**=*=*=*=*=*=*=\n");
	//}
	//else
	//{
	 //   printf("=*=*=*=*=*=*=*=*=*=*= SRAM TESTS *=*=*=*=**=*=*=**=*=*=*=*=*=*=\r\n");
	//	printf("=*=*=*=*=*=*=*=*=*=*= RESULT: SRAM TEST PASS =**=*=*=*=*=*=*=\n");
	//}

	if (nor_status != 0)
	{
	    printf("=*=*=*=*=*=*=*=*=*=*= NOR TESTS *=*=*=*=*=*=*=*=***=*=*=*=*=*=*=\r\n");
		printf("=*=*=*=*=*=*=*=*=*=*= RESULT: NOR TEST FAILED =**=*=*=*=*=*=*=*=*=\n");
	}
	else
	{
	    printf("=*=*=*=*=*=*=*=*=*=*= NOR TESTS *=*=*=*=*=*=*=*=***=*=*=*=*=*=\r\n");
		printf("=*=*=*=*=*=*=*=*=*=*= RESULT: NOR TEST PASS =**=*=*=*=*=*=*=*=\n");
	}

	if (nand_status != 0)
	{
	    printf("=*=*=*=*=*=*=*=*=*=*= NAND TESTS *=*=*=*=**=*=*=*=**=*=*=*=*=*=\r\n");
		printf("=*=*=*=*=*=*=*=*=*=*= RESULT: NAND TEST FAILED *=*=*=*=*=*=*=*=*=\n");
	}
	else
	{
	    printf("=*=*=*=*=*=*=*=*=*=*= NAND TESTS *=*=*=*=**=*=*=*=**=*=*=*=*=*=\r\n");
		printf("=*=*=*=*=*=*=*=*=*=*= RESULT: NAND TEST PASS *=*=*=*=*=*=*=*=*=\n");
	}


//	mmu_unmap(0x00C00000, 0x00F00000);

	if ((sram_status == 0)&&(nor_status == 0)&&(nand_status == 0))
		printPASS();
	else
		printFAIL();

	return 0;
}
