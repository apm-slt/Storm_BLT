/* Author: your_name@apm.com 
*  Company: Applied Micro Circuits Corporation (AMCC)
* 
* Describe the purpose of your Test here
*/
//
#include "stdio.h"
//#include "config.h"
#include <string.h>
#include "common.h"

//Tinh-SLT:
//give a full path to include the header files
#include "../../GFC/include/common.h"
#include "../../GFC/include/vGFC_regs.h"
#include "../../GFC/include/vGFC_defines.h"
#include "../../GFC/include/vGFC_macros.h"

#include "../../GFC/driver/gfc_nor.c"
#include "../../GFC/driver/gfc_nand.c"
#include "../../GFC/driver/gfc_sram.c"
#include "../../GFC/driver/gfc_dma.c"
#include "../../GFC/driver/gfc_sram_dma.c"
#include "../../GFC/driver/test_util.c"
#include "../../GFC/driver/gfc_interleave.c"
#include "../../GFC/driver/platform.c"
#include "../../GFC/driver/gfc_common.c"
