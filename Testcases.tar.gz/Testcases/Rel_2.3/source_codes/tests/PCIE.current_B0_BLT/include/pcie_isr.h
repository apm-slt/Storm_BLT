

extern volatile unsigned int g_Int_Status;
extern void en_event_int(unsigned int pcie_core_id);
extern void En_MSI_ISR(unsigned int pcie_core_id);

extern void Isr_MSI0(unsigned int irq_id);
extern void Isr_PCIE_P0(unsigned int irq_id);
extern void Isr_PCIE_P1(unsigned int irq_id);
extern void Isr_PCIE_P2(unsigned int irq_id);
extern void Isr_PCIE_P3(unsigned int irq_id);
extern void Isr_PCIE_P4(unsigned int irq_id);
