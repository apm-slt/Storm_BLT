/*
 */
#ifndef __PCIE_BASE_H_
#define __PCIE_BASE_H_

#if defined(CONFIG_VHP) || defined(CONFIG_BB1) || defined(CONFIG_BB2)
#define VBIOS 1
#define SM_SOC_SIM
#undef SIMULATION
#include <stdio.h>
#endif

#ifndef VBIOS
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#endif
#ifdef SM_SOC_SIM
#include "sm_host_pkg.h"
#else
#include "platform.h"
#ifndef VBIOS
#include "test_util.h"
#endif
#endif
#include "pcie_x8_regs_addrmap.h"
#include <common.h>

//Tinh-SLT
//function defined here
#define putnum putnum_pcie
//End of Tinh-SLT

struct error_log
{
	uint32_t cnt;
	uint32_t link_error;
	uint32_t eq_status;
	uint32_t aer_error_rc;
	uint32_t aer_error_ep;
	uint32_t link_error_rc;
        uint32_t link_error_ep;

	uint32_t ep_dma_wr;
	uint32_t ep_dma_rd;
	uint32_t ep_dma_intx;
	uint32_t rc_dma_wr;
	uint32_t rc_dma_rd;
	uint32_t rc_wr_perf;
	uint32_t ep_wr_perf;
	uint32_t rc_rd_perf;
	uint32_t ep_rd_perf;

} ;

struct s_pcie_serdes_param
{
        uint32_t CTLE;
        uint32_t PQ_REG;
        uint32_t DFE;
        uint32_t PRESET;
} ;


#define RC      1
#define EP      0

#define CORRECT_LINK     1
#define WRONG_LINK       2 
#define NO_LINK          0
#define FLAKY_LINK       3

#define EP_DEV_VEN_ID    0xCAFEBABE
#define RC_DEV_VEN_ID    0xCAFE0DAD

#define RD 0
#define WR 1

#define EXT_REF_CLK 0
#define INT_REF_CLK 1

#define OMR1_SIZE 0x40000000
#define OMR2_SIZE 0x40000000
#define OMR3_SIZE 0x40000000
#define OB_CFG_SIZE 0x00080000

#define PCIE_OMR1_OFFSET 0x0
#define PCIE_OMR2_OFFSET PCIE_OMR1_OFFSET+OMR1_SIZE
#define PCIE_OMR3_OFFSET PCIE_OMR2_OFFSET+OMR2_SIZE
#define PCIE_OB_CFG_OFFSET PCIE_OMR3_OFFSET+OMR3_SIZE
#define PCIE_OB_MSG_OFFSET PCIE_OB_CFG_OFFSET+OB_CFG_SIZE

#define OMR1_MASK 0x3FFC0000000ULL 
#define OMR2_MASK 0x3FFC0000000ULL
#define OMR3_MASK 0x3FFC0000000ULL

#define PREFETCH_MEM_BASE 0x400000000000ULL 
#define MEM_BASE          0x40000000 
#define IO_BASE           0x80000000 

#define RC_BAR0         0x00000000
#define RC_BAR2         0xC0000000
#define RC_BAR4         0x200000000000ULL

#ifdef SM_SOC_SIM
#include "sm_addr_map.h"
#else

#define PCIE_CSR_BASE 0x1f2b0000
#define PCIE_MEM_BASE 0x20000000

#define SM_ADDR_MAP_PCIE0_CSR_BASE PCIE_CSR_BASE
#define SM_ADDR_MAP_PCIE1_CSR_BASE PCIE_CSR_BASE
#define SM_ADDR_MAP_PCIE2_CSR_BASE PCIE_CSR_BASE
#define SM_ADDR_MAP_PCIE3_CSR_BASE PCIE_CSR_BASE
#define SM_ADDR_MAP_PCIE4_CSR_BASE PCIE_CSR_BASE

#define SM_ADDR_MAP_PCIE0_BASE PCIE_MEM_BASE
#define SM_ADDR_MAP_PCIE1_BASE PCIE_MEM_BASE
#define SM_ADDR_MAP_PCIE2_BASE PCIE_MEM_BASE
#define SM_ADDR_MAP_PCIE3_BASE PCIE_MEM_BASE
#define SM_ADDR_MAP_PCIE4_BASE PCIE_MEM_BASE

#endif

#define uint32_t unsigned int
#define uint64_t unsigned long long

#ifdef SM_SOC_SIM
#if defined(SIMULATION) || defined(CONFIG_VHP) || defined(CONFIG_BB1) || defined(CONFIG_BB2)
#define print printf
#define CPU_ACCESS_BASE 0x000000000000
#else
#define CPU_ACCESS_BASE 0x400000000000
#define print sm_host_report_info
#endif
void putnum(uint32_t num);
#else
#define CPU_ACCESS_BASE 0x80000000
#endif

#define TEST_LOC        0x40
#define IB_PTR_LOC      0x80
#define OB_PTR_LOC      0xC0
#define RC_BAR0_LOC     0xF0
#define RC_BAR1_LOC     0xF4
#define INT_ACK_LOC     0xF8

#ifdef PCIE_EXERCISER


extern void prep_diag_mode(uint32_t pcie_core_id,uint32_t len);
extern void print_M_AXI_WR_RD(uint32_t pcie_core_id,uint32_t mode);
extern void print_S_AXI_WR_RD(uint32_t pcie_core_id,uint32_t mode);

#endif
void pcie_reset_mellanox (uint32_t pcie_core_id);
void cpu_write(uint64_t addr, uint32_t data);
uint32_t cpu_read(uint64_t addr);

uint64_t ret_csr_base(uint32_t pcie_core_id);
void pcie_csr_write(uint32_t pcie_core_id, uint32_t offset, uint32_t data);
uint32_t pcie_csr_read(uint32_t pcie_core_id, uint32_t offset);

uint64_t ret_pcie_mem_base(uint32_t pcie_core_id);
uint64_t ret_ob_cfg_base(uint32_t pcie_core_id);
uint64_t ret_ob_msg_base(uint32_t pcie_core_id);
uint64_t ret_omr1_base(uint32_t pcie_core_id);
uint64_t ret_omr2_base(uint32_t pcie_core_id);
uint64_t ret_omr3_base(uint32_t pcie_core_id);

void pcie_ob_cfg_write(uint32_t pcie_core_id, uint32_t offset, uint32_t data);
uint32_t pcie_ob_cfg_read(uint32_t pcie_core_id, uint32_t offset);  

void sm_pcie_init(uint32_t pcie_core_id, uint32_t port_type, uint32_t en_lpbk, uint32_t gen, uint32_t ext_ref, uint32_t link_width, uint32_t poll);
void sm_pcie_init_rc(uint32_t pcie_core_id, uint32_t gen, uint32_t ext_ref, uint32_t link_width);
void sm_pcie_init_ep(uint32_t pcie_core_id, uint32_t gen, uint32_t ext_ref, uint32_t link_width);
void manual_cal(uint32_t pcie_core_id, uint32_t link_width);
uint32_t extract_max_payload_size(uint32_t pcie_core_id);

void serdes_config_tx_control(uint32_t pcie_core_id, uint32_t ch, uint32_t sds2, uint32_t gen);
void serdes_config_rx_control(uint32_t pcie_core_id, uint32_t ch, uint32_t sds2);
void serdes_config_LSPLL(uint32_t pcie_core_id, uint32_t sds2);

void serdes_bist_resync(uint32_t pcie_core_id, uint32_t ch);
void serdes_bert_reset(uint32_t pcie_core_id, uint32_t ch);
void serdes_bert_result(uint32_t pcie_core_id, uint32_t ch);
void serdes_bert_err_cnt(uint32_t pcie_core_id, uint32_t ch);
void pipe_config(uint32_t pcie_core_id);
uint32_t get_momsel(uint32_t pcie_core_id, uint32_t sds, uint32_t pll_8g, uint32_t div2);


void sm_pcie_setup_generic_debug_hooks(uint32_t pcie_core_id, uint32_t axi_shim, uint32_t axi, uint32_t diagsel);
void sm_pcie_setup_cntlr_axi_debug_hooks(uint32_t pcie_core_id, uint32_t master, uint32_t diagsel);
void sm_pcie_setup_cntlr_pcie_debug_hooks(uint32_t pcie_core_id, uint32_t lane, uint32_t diagsel);
void sm_pcie_setup_pipe_debug_hooks(uint32_t pcie_core_id, uint32_t diagsel);
uint32_t ltssm_sub(uint32_t pcie_core_id, uint32_t *status);
#endif

#define BB2

#include "pcie_blt.h"

#ifdef BB2
    #define LOCAL_PRESET        0x7
    #define REMOTE_PRESET       0x2
    #define REMOTE_BCA_PRESET   0x2
    #define CTLE_EQ             0x10
    #define PQ                  0x11 
    #define RXDFE               0x7
#endif

#ifdef BB3
    #define LOCAL_PRESET        0x7
    #define REMOTE_PRESET       0x1
    #define REMOTE_BCA_PRESET   0x1
    #define CTLE_EQ             0x10
    #define PQ                  0x11 
    #define RXDFE               0x7
#endif

#ifdef BB3_CABLE
    #define LOCAL_PRESET        0x7
    #define REMOTE_PRESET       0x7
    #define REMOTE_BCA_PRESET   0x7
    #define CTLE_EQ             0x1c
    #define PQ                  0x11
    #define RXDFE               0x7
#endif

#ifdef MCDIVITT
    #define LOCAL_PRESET        0x7
    #define REMOTE_PRESET       0x4
    #define REMOTE_BCA_PRESET   0x4
    #define CTLE_EQ             0x1
    #define PQ                  0x11 
    #define RXDFE               0x7
#endif

