/*
 */
#ifndef __PCIE_INT_MSI_H_
#define __PCIE_INT_MSI_H_

#include "pcie_base.h"

void disable_msi_support(uint32_t pcie_core_id);
void outbound_intx_msg(uint32_t pcie_core_id, uint32_t msg);
void gen_int(uint32_t pcie_core_id);
void gen_msi(uint32_t pcie_core_id);
#endif
