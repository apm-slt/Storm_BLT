/*
 */
#ifndef __PCIE_OB_TEST_H_
#define __PCIE_OB_TEST_H_

#include "pcie_base.h"

struct bar_info{
  uint64_t bar_size;
  uint32_t bar_id;
};

struct ep_bar{
  uint32_t offset;
  uint32_t type; // type can have three values - 0 => io, 1 => mem, 2 => prefetch.
  uint32_t valid;
};  

void config_pom_regs(uint32_t pcie_core_id, uint64_t pcie_pom1, uint64_t pcie_pom2, uint64_t pcie_pom3);
void sm_pcie_setup_ob_cfg(uint32_t pcie_core_id, uint32_t port_type);
void sm_pcie_setup_ob_space(uint32_t pcie_core_id, uint32_t port_type);
void sm_pcie_enum_ep(uint32_t pcie_core_id, struct ep_bar *ep_bars_ptr);
void send_ob_msg(uint32_t pcie_core_id, uint32_t msg_code, uint32_t msg_routing_code, uint32_t msg_data);
#endif
