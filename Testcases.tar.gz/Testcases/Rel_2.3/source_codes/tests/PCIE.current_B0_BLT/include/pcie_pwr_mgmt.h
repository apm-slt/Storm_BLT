#ifndef __PCIE_PWR_MGMT_H
#define __PCIE_PWR_MGMT_H

#include "pcie_base.h"
#include "pcie_ob_test.h"

void en_l1_pwr_mgmt(uint32_t pcie_core_id);
void send_link_to_l1(uint32_t pcie_core_id);
void poll_link_to_l1(uint32_t pcie_core_id);
void wake_frm_l1(uint32_t pcie_core_id);

void en_l1l2_pwr_mgmt(uint32_t pcie_core_id);
void send_link_to_l2(uint32_t pcie_core_id);
void poll_link_to_l2(uint32_t pcie_core_id);
void wake_frm_l2(uint32_t pcie_core_id, uint32_t gen, uint32_t ext_ref, uint32_t link_width);

#endif
