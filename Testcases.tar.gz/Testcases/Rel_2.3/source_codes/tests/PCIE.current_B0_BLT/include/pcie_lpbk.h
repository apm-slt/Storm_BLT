/*
 */
#ifndef __PCIE_LPBK_H_
#define __PCIE_LPBK_H_
#include "sm_addr_map.h"
#include "pcie_x8_regs_addrmap.h"
#include "pcie_base.h"
#include "pcie_base_test.h"

#define LPBK_DDR_SIZE  0x10000000LL         //256MB=1000_0000 
#define LPBK_8MB_SIZE  0x00800000L          //  8MB=0080_0000
//1. CPU space
#define LPRC_PIM       0x08080000000ULL		//CPU space in DDR

#define LPEP_PIM       (LPRC_PIM+LPRC_PIM3_OFFS+LPRC_PIM3_SIZE)	//CPU space in DDR

int pcie_lpbk_sub(uint32_t rc_slot, uint32_t ep_slot, uint32_t gen, uint32_t link_width, uint32_t test_id, uint32_t length);
/*
  ib_bar1_mask = 0x00000000; ib_bar0_mask = 0xFFFE0000;
  ib_bar3_mask = 0x00000000; ib_bar2_mask = 0xFFF00000;
  ib_bar5_mask = 0x00000000; ib_bar4_mask = 0xFFF00000;
handshake, see "testing scheme for PCIe endpoint"
  TEST_LOC saves test_signature as below:
    b0=valid
	b4-1=test name,0=IB/1=OB/2=Intx-INTA msg/3=MSI-INTA msg//4=Intx MSI data/MSI MSI data/
	     8=single DMA AXI->PCIe/9=PCIe->MAXI/10=multiDMA AXI->PCIe/11=PCIe->AXI/12=interleaved
    b6-5=data patter, 1=all 5s/2=all As/3=all 1s
	b30-7=length of bytes
	b31=address, 0/1=32/64bit

#define TEST_LOC        PCIE_PIM2+0x40
#define IB_PTR_LOC      PCIE_PIM2+0x80
#define OB_PTR_LOC      PCIE_PIM2+0xC0
#define RC_BAR0_LOC     PCIE_PIM2+0xF0
#define RC_BAR1_LOC     PCIE_PIM2+0xF4
#define INT_ACK_LOC     PCIE_PIM2+0xF8
*/
#endif
