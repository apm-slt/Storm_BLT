/*
 */
#ifndef __PCIE_BLT_H_
#define __PCIE_BLT_H_

#ifdef BLT_BB3_CABLE
/*  #define LOCAL_PRESET        0x7
    #define REMOTE_PRESET       0x1
    #define REMOTE_BCA_PRESET   0x1
    #define CTLE_EQ             0x10
    #define PQ                  0x11
    #define RXDFE               0x7	
*/
// New changes for intermediate SLT release 
    
	#define LOCAL_PRESET        0x7  
    #define REMOTE_PRESET       0x2
    #define REMOTE_BCA_PRESET   0x2
	                          
    #define CTLE_EQ             0x15 // AC: 5 and DC =1
    #define PQ                  0x11
    #define RXDFE               0x0
	
#endif

#endif
