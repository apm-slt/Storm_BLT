#ifndef SM_HOST_PKG
#define SM_HOST_PKG

#ifndef CONFIG_BB1
#define CONFIG_BB1
#endif

#define inline 
#if defined(CONFIG_VHP) || defined(CONFIG_BB1) || defined(CONFIG_BB2)
#define noprintf
#else
#include "printf.h"
#endif

typedef unsigned char uint8_t; 
typedef unsigned int  uint32_t; 
typedef unsigned long long uint64_t; 

extern void sm_host_read32(uint64_t addr, unsigned int* data);
extern void sm_host_write32(uint64_t addr, unsigned int data);
extern void sm_host_report_info(const char* message);
extern void sm_host_report_error(const char* message);
extern void memory_barrier(void);
extern void sm_host_delay_ns(unsigned int duration) ;
extern void __cmp_value(unsigned int exp_value, unsigned int rcvd_value);

typedef enum { 
  SM_AHB,
  SM_CLE_0,
  SM_CLE_1,
  SM_CLE_2,
  SM_CLE_3,
  SM_CLE_4,
  SM_COP_0,
  SM_CTM_0,
  SM_DMA,
  SM_OCM,
  SM_PCIE_4,
  SM_PCIE_3,
  SM_PCIE_2,
  SM_PCIE_1,
  SM_PCIE_0,
  SM_QM_1,
  SM_SATA_0,
  SM_ENET_0,
  SM_SATA_1,
  SM_ENET_1,
  SM_SATA_2,
  SM_ENET_2,
  SM_SATA_3,
  SM_ENET_3,
  SM_SATA_4,
  SM_ENET_4,
  SM_SATA_5,
  SM_SEC,
  SM_USB_1,
  SM_GFC,
  SM_QM_0,
  SM_SLIM_PRO,
  SM_USB_0,
  SM_XGENET_0,
  SM_XGENET_1,
  SM_IOB_0,
  SM_IOB_1,
  SM_QMLITE, 
  SM_QM_2,
  SM_XGENET_2,
  SM_XGENET_3,
  SM_DBG,
  SM_AXI_DEVICE_MAX
} sm_func_block_e; 

typedef void (*host_task_ptr_t)(const unsigned int *data, const unsigned int *ctrl);

//-------------------------------------------------------------------------
// host_isr_prt_t - pointer to interrupt service routine developed for
//                  block level simulation environment and intended for
//                  reuse in full chip environment
//-------------------------------------------------------------------------
typedef void (*host_isr_ptr_t) (void);
extern host_isr_ptr_t host_isr;
int sm_host_isr(void);
//-------------------------------------------------------------------------
// host_task_descriptor_t - struct used as entry in the host task table
//                          Maps a string to a function pointer.
//-------------------------------------------------------------------------
typedef struct {
  const int task_id_num;
  const char *task_id;
  const host_task_ptr_t task_ptr;
} host_task_descriptor_t;

//-------------------------------------------------------------------------
// host_block_descriptor_t - struct used as entry in the host block table
//                           Maps a string to a task table.
//-------------------------------------------------------------------------
typedef struct {
  const sm_func_block_e block_id;
  const host_task_descriptor_t *block_ptr;
  const int num_of_tasks;
} host_block_descriptor_t;

//DDR Shared Memory Locations to pass Block_Id, Task_Id, Data_Array and
//Ctrl_Array from SV Host Adapter to C
//Address Map is divided as :
//  --------- Shared Mem Base Addr ----------------------------------------------------------
//     ---- Device 0 Block Mem Size = 128K bytes (offset from base = 0 Bytes) ----
//        ---- Block Id = 252 Bytes (offset 0 to 251)  -------
//        ---- Block Id Numeric = 4 Bytes (offset 252 to 255)-
//        ---- Task Id  = 252 Bytes (offset 256 to 507) -------
//        ---- Task Id Numeric = 4 Bytes (offset 508 to 511) --
//        ---- Ctrl Array = 60K Bytes (offset 512 to 61951)---
//        ---- Data Array = 60K Bytes (offset 61952 to 123391)----
//        ---- Job Set/Done Bit = 1 Byte (offset 123392) -------
//        ---- Reserved   = 7679 Bytes (offset 123393 to 131071)---
//     ---- Device 1 Block Mem Size = 128K bytes (offset from base = 131072 * 1 Bytes) ----
//        ---- Block Id = 252 Bytes (offset 0 to 251)  -------
//        ---- Block Id Numeric = 4 Bytes (offset 252 to 255)-
//        ---- Task Id  = 252 Bytes (offset 256 to 507) -------
//        ---- Task Id Numeric = 4 Bytes (offset 508 to 511) --
//        ---- Ctrl Array = 60K Bytes (offset 512 to 61951)---
//        ---- Data Array = 60K Bytes (offset 61952 to 123391)----
//        ---- Job Set/Done Bit = 1 Byte (offset 123392) -------
//        ---- Reserved   = 7679 Bytes (offset 123393 to 131071)---
//         .
//         .
//         .
//         .
//         .
//         .
//     ---- Device n Block Mem Size = 128K bytes (offset from base = 131072 * n Bytes) ----
//        ---- Block Id = 252 Bytes (offset 0 to 251)  -------
//        ---- Block Id Numeric = 4 Bytes (offset 252 to 255)-
//        ---- Task Id  = 252 Bytes (offset 256 to 507) -------
//        ---- Task Id Numeric = 4 Bytes (offset 508 to 511) --
//        ---- Ctrl Array = 60K Bytes (offset 512 to 61951)---
//        ---- Data Array = 60K Bytes (offset 61952 to 123391)----
//        ---- Job Set/Done Bit = 1 Byte (offset 123392) -------
//        ---- Reserved   = 7679 Bytes (offset 123393 to 131071)---
// ---------- Shared Memory Ends// ----------------------------------------------------------

#define SHARED_MEM_BASE_ADDR 0x80100000
#define DEVICE_BLOCK_MEM_SIZE 131072
#define BLOCK_ID_OFFSET 0
#define BLOCK_ID_NUM_OFFSET 252
#define TASK_ID_OFFSET  256
#define TASK_ID_NUM_OFFSET 508
#define CTRL_ARRAY_OFFSET 512
#define DATA_ARRAY_OFFSET 61952
#define JOB_SET_AND_DONE_OFFSET 123392


#define SHARED_MEM_DELAY_DURATION_ADDR (SHARED_MEM_BASE_ADDR - 4)
#define SHARED_MEM_DELAY_SET_DONE_ADDR (SHARED_MEM_BASE_ADDR - 5)

#endif // SM_HOST_PKG
