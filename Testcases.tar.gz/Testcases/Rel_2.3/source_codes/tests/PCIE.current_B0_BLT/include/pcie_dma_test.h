/*
 */
#ifndef __PCIE_DMA_TEST_H_
#define __PCIE_DMA_TEST_H_

#include "pcie_base.h"
#include "pcie_ib_test.h"
#include "pcie_base_test.h"

#if defined(CONFIG_VHP) || defined(CONFIG_BB1) || defined(CONFIG_BB2) || !defined(SM_SOC_SIM)
#define RANDOM rand
#else
#define RANDOM random
#endif

#define SRC 1
#define DST 0

#ifdef DMA_INT_ENABLE
volatile unsigned int g_Int_Status;
#define  WAIT_DMA_INT(x)  ( g_Int_Status &  ( 0x1 << x  ) )
#endif

#ifndef MORE_DESCRIPTORS
#define MAX_DMA_MEM     0x4000000              // 64MB Enable this with correct DDR settins
#else
#define MAX_DMA_MEM     0x4000000
//#define MAX_DMA_MEM ( (MAX_DESCRIPTORS) * (MAX_DESC_SIZE) )
#endif

//#define MAX_DMA_MEM 0x400000                     // FOR RC DMA TESTs with exerciser.

#define DMA_SRC_AXI     0
#define DMA_DST_AXI     DMA_SRC_AXI+MAX_DMA_MEM
#define DMA_SRC2_AXI    DMA_SRC_AXI+MAX_DMA_MEM+MAX_DMA_MEM
#define DMA_DST2_AXI    DMA_SRC2_AXI+MAX_DMA_MEM

#define DMA_SRC_PCIE    0
#define DMA_DST_PCIE    DMA_SRC_PCIE+MAX_DMA_MEM
#define DMA_SRC2_PCIE   DMA_SRC_PCIE+MAX_DMA_MEM+MAX_DMA_MEM
#define DMA_DST2_PCIE   DMA_SRC2_PCIE+MAX_DMA_MEM

#define DMA_SRC_ELE     0
#define DMA_DST_ELE     DMA_SRC_ELE+MAX_DMA_MEM
#define DMA_SRC2_ELE    DMA_SRC_ELE+MAX_DMA_MEM+MAX_DMA_MEM
#define DMA_DST2_ELE    DMA_SRC2_ELE+MAX_DMA_MEM

#define DMA_SRC_Q_PTR   0
#define DMA_DST_Q_PTR   0x10
#define DMA_SRC2_Q_PTR  0x20
#define DMA_DST2_Q_PTR  0x30

#define DMA_STA         0x100000
#define DMA_STA2        0x200000

#define NUM_DMA_CH      4

void setup_src_dst_elements(uint64_t addr, uint32_t axi, uint64_t element_ptr, uint32_t length, uint64_t q_param_loc);
void init_dma_src_dst_elements(uint32_t pcie_core_id, uint64_t addr, uint64_t addr2, uint32_t axi, uint32_t axi2, uint32_t src_dst, uint32_t length);
void init_dma_sta_elements(uint32_t pcie_core_id, uint32_t mult_ch, uint32_t length);
void sm_pcie_setup_dma(uint32_t pcie_core_id, uint32_t src_axi, uint32_t dst_axi, uint32_t mult_ch, uint32_t intlv);
uint32_t poll_dma_cmpl(uint32_t pcie_core_id, uint32_t mult_ch);

#ifdef DMA_INT_ENABLE
uint32_t evt_dma_cmpl (uint32_t pcie_core_id, uint32_t mult_ch);
#endif

#endif
