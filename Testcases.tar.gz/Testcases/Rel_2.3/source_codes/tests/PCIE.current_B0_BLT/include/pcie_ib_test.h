/*
 */
#ifndef __PCIE_IB_TEST_H_
#define __PCIE_IB_TEST_H_

#include "pcie_base.h"

// PLEASE ENABLE ONLY CORRESPONDNIG DDR_SIZE_XX SWITCH AS PER DDR USED ON YOUR BOARD.

#define DDR_SIZE_2GB     0
#define DDR_SIZE_8GB     0 
#define DDR_SIZE_16GB    0
#define DDR_SIZE_32GB    1

#ifdef SM_SOC_SIM
#ifdef VBIOS

#if DDR_SIZE_2GB

#define PCIE_0_PIM  0x0000000080000000ULL
#define PCIE_1_PIM  0x0000000088000000ULL
#define PCIE_2_PIM  0x0000000090000000ULL
#define PCIE_3_PIM  0x0000000098000000ULL
#define PCIE_4_PIM  0x00000000A0000000ULL

#elif DDR_SIZE_8GB

#define PCIE_0_PIM  0x0000000100000000ULL   // 4GB  // Port :1
#define PCIE_3_PIM  0x0000000140000000ULL   // 5GB  // Port :2
#define PCIE_2_PIM  0x0000000180000000ULL   // 6Gb  // Port :3

#define PCIE_1_PIM  0x00000001C0000000ULL
#define PCIE_4_PIM  0x00000001E0000000ULL

#elif DDR_SIZE_16GB

#define PCIE_0_PIM  0x0000000200000000ULL   // 4GB  // Port :1
#define PCIE_3_PIM  0x0000000240000000ULL   // 5GB  // Port :2
#define PCIE_2_PIM  0x0000000280000000ULL   // 6Gb  // Port :3

#define PCIE_1_PIM  0x00000002C0000000ULL
#define PCIE_4_PIM  0x00000002E0000000ULL

#elif DDR_SIZE_32GB
/*
#define PCIE_0_PIM  0x0000000400000000ULL   // 4GB  // Port :1
#define PCIE_3_PIM  0x0000000440000000ULL   // 5GB  // Port :2
#define PCIE_2_PIM  0x0000000480000000ULL   // 6Gb  // Port :3
#define PCIE_1_PIM  0x00000004C0000000ULL
#define PCIE_4_PIM  0x00000004E0000000ULL
*/
/*
#define PCIE_0_PIM  0x0000004044000000ULL   // 4GB  // Port :1
//#define PCIE_0_PIM  0x00000040C4000000ULL  
#define PCIE_3_PIM  0x0000004084000000ULL   // 5GB  // Port :2
#define PCIE_2_PIM  0x00000040C4000000ULL   // 6Gb  // Port :3
//#define PCIE_2_PIM  0x0000004044000000ULL   // 6Gb  // Port :3
#define PCIE_1_PIM  0x0000004104000000ULL
#define PCIE_4_PIM  0x0000004144000000ULL
*/

//#define PCIE_0_PIM  0x0000004040000000ULL   // 4GB  // Port :1
//#define PCIE_3_PIM  0x0000004080000000ULL   // 5GB  // Port :2
//#define PCIE_2_PIM  0x00000040C0000000ULL   // 6Gb  // Port :3
//#define PCIE_1_PIM  0x0000004100000000ULL
//#define PCIE_4_PIM  0x0000004140000000ULL

//#define PCIE_0_PIM_PA (ddr_va_to_pa(PCIE_0_PIM))
//#define PCIE_3_PIM_PA (ddr_va_to_pa(PCIE_3_PIM))
//#define PCIE_2_PIM_PA (ddr_va_to_pa(PCIE_2_PIM))
//#define PCIE_1_PIM_PA (ddr_va_to_pa(PCIE_1_PIM))
//#define PCIE_4_PIM_PA (ddr_va_to_pa(PCIE_4_PIM))

#define PCIE_DDR_TEST_PA (get_ddr_sys_test_base())
#define PCIE_DDR_TEST_VA (get_ddr_cpu_test_base()) 

#define PCIE_0_PIM_PA  (PCIE_DDR_TEST_PA + 0x40000000)
#define PCIE_0_PIM  (PCIE_DDR_TEST_VA + 0x40000000)

#define PCIE_3_PIM_PA  (PCIE_0_PIM_PA + 0x40000000)
#define PCIE_3_PIM  (PCIE_0_PIM + 0x40000000)

#define PCIE_2_PIM_PA  (PCIE_3_PIM_PA + 0x40000000)
#define PCIE_2_PIM  (PCIE_3_PIM + 0x40000000)

#define PCIE_1_PIM_PA  (PCIE_2_PIM_PA + 0x40000000)
#define PCIE_1_PIM  (PCIE_2_PIM + 0x40000000)

#define PCIE_4_PIM_PA  (PCIE_1_PIM_PA + 0x40000000)
#define PCIE_4_PIM  (PCIE_1_PIM + 0x40000000)
#endif     // DDR SIZE ENDS HERE

#else
#define PCIE_0_PIM  0x0000000080000000ULL
#define PCIE_1_PIM  0x00000000c0000000ULL
#define PCIE_2_PIM  0x000000001d0c0000ULL
#define PCIE_3_PIM  0x000000001d0c0000ULL
#define PCIE_4_PIM  0x000000001d0c0000ULL

#endif     // VBIOS ENDS Here

#else
#define PCIE_0_PIM  0x000000001d000000ULL
#define PCIE_1_PIM  0x000000001d000000ULL
#define PCIE_2_PIM  0x000000001d000000ULL
#define PCIE_3_PIM  0x000000001d000000ULL
#define PCIE_4_PIM  0x000000001d000000ULL
#endif    // SM_SOC_SIM ends here

#ifdef SM_SOC_SIM
#define PCIE_PIM1_SIZE 0xFFFFFFFFF0000000ULL // Corresponds to 256MB i.e. (~256MB) + 1
#define PCIE_PIM2_SIZE 0xFFFFFFFFFF800000ULL // Corresponds to 8MB i.e. (~8MB) + 1
#define PCIE_PIM3_SIZE 0xFFFFFFFFF0000000ULL // Corresponds to 256MB i.e. (~256MB) + 1
#else
#define PCIE_PIM1_SIZE 0xFFFFFFFFFFFF8000ULL
#define PCIE_PIM2_SIZE 0xFFFFFFFFFFFF8000ULL
#define PCIE_PIM3_SIZE 0xFFFFFFFFFFFF8000ULL
#endif

// Arange these correctly aligned with your PIM/BAR settings.
// Ref.bug :[Bug 38228]
#define PCIE_PIM1_OFFSET 0x0ULL
#define PCIE_PIM3_OFFSET PCIE_PIM1_OFFSET + (~PCIE_PIM1_SIZE) + 1
#define PCIE_PIM2_OFFSET PCIE_PIM3_OFFSET + (~PCIE_PIM2_SIZE) + 1

uint64_t ret_pim1_base(uint32_t pcie_core_id);
uint64_t ret_pim2_base(uint32_t pcie_core_id);
uint64_t ret_pim3_base(uint32_t pcie_core_id);
uint64_t ret_pim1_base_pa(uint32_t pcie_core_id);
uint64_t ret_pim2_base_pa(uint32_t pcie_core_id);
uint64_t ret_pim3_base_pa(uint32_t pcie_core_id);

void config_ib_regs(uint32_t pcie_core_id, uint32_t port_type);
void sm_pcie_setup_rc_bars(uint32_t pcie_core_id);
#endif
