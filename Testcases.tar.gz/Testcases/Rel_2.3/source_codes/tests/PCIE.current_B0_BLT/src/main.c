/*
 * Copyright (c) 2009 Xilinx, Inc.  All rights reserved.
 *
 * Xilinx, Inc.
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS" AS A
 * COURTESY TO YOU.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION AS
 * ONE POSSIBLE   IMPLEMENTATION OF THIS FEATURE, APPLICATION OR
 * STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS IMPLEMENTATION
 * IS FREE FROM ANY CLAIMS OF INFRINGEMENT, AND YOU ARE RESPONSIBLE
 * FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE FOR YOUR IMPLEMENTATION.
 * XILINX EXPRESSLY DISCLAIMS ANY WARRANTY WHATSOEVER WITH RESPECT TO
 * THE ADEQUACY OF THE IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO
 * ANY WARRANTIES OR REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE
 * FROM CLAIMS OF INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

/*
 * helloworld.c: simple test application
 */
#include <stdio.h>
#include "platform.h"
#include "common.h"
#include "ocm_main.h"
#include "vlib.h"

int main()
{
  //init_platform();
  //ocm_init();
  //ddr_init();
  cmain();
  //cleanup_platform();
  
  return 0;

}; // main



int cop_init(void) {

    print("Storm SOC FPGA: COP \n\r\n\r");

    print("Configuring COP CSR ...\n\r");

    // CFG_COP_CLKEN
    // 2 R/W clken_cpu 1'h0 Clock Enable - Cortex-A5 CPU core
    // 1 R/W clken_cop 1'h0 Clock Enable - COP module
    // 0 R/W clken_csr 1'h0 Clock Enable - COP CSRs

    // Enable COP module clock and COP CSR clock (CFG_COP_CLKEN)
    write (0x9f40c008, 0x7);

    // CFG_COP_SRST (active high)
    // 32:24 RO  RESERVED           8'h0 RESERVED
    // 23:20 R/W reset_cpu_etm      4'hf Soft reset - Cortex-A5 Embedded Trace Macrocell (ETM) per core
    // 19:16 R/W reset_cpu_dbg_core 4'hf Soft reset - Cortex-A5 processor debug logic per core
    // 15    RO  RESERVED           1'h0 RESERVED
    // 14    R/W reset_cpu_dbg_soc  1'h1 Soft reset - Cortex-A5 SOC debug logic, including ETM, ATB, async intf,
    // but not cores' debug logic
    // 13    R/W reset_cpu_scu      1'h1 Soft reset - Cortex-A5 Snoop Control Unit (SCU)
    // 12    R/W reset_cpu_periph   1'h1 Soft reset - Cortex-A5 peripherals, such as timer and interrupt controller
    // 11:8  R/W reset_cpu_wd       4'hf Soft reset - Cortex-A5 CPU watchdog per core
    // 7:4   R/W reset_cpu_core     4'hf Soft reset - Cortex-A5 CPU per core
    // 3     RO  RESERVED           1'h0 RESERVED
    // 2     RO  RESERVED           1'h0 RESERVED
    // 1     R/W reset_cop          1'h1 Soft reset - COP module
    // 0     R/W reset_csr          1'h1 Soft reset - COP block CSRs
    // Default Value: 32'hff7ff3   

    // 3       2 2  2 1  1 1  1 1   
    // 1       4 3  0 9  6 5  2 1  8 7  4 3  0
    // 0000_0000_0000_0000_0000_0000_0000_0000
    // = 32'h0
    
    // Release reset_cop and reset_csr (CFG_COP_SRST)
    write (0x9f40c000, 0xff7ff0);

    // Release COP RAMs from shutdown mode (CFG_MEM_RAM_SHUTDOWN)
    write (0x9f40d070, 0x0);

    // Enable address mapper (CFG_COP_CTL)
    write (0x9f400004, 0x1);


    //### Configure address mapper to define boot vector to point to OCM upper half

    // Define OCM space reserved for Cortex-A5 use to be the upper half 512KByte.
    // The bottom 512KByte is reserved for VBIOS use.
    // CFG_AMAP_BOOT_CPU_ADDR_MASK = 512KByte 
    write (0x9f400100, 0x7FFFF);

    // CFG_AMAP_BOOT_IOF_BASE_ADDR_LO = 0x000_9D00_0000 + 512KB = 0x000_9D08_0000
    write (0x9f400104, 0x9D080000);


    // Now release all COP soft resets, including Cortex-A5 cores (CFG_COP_SRST)
    write (0x9f40c000, 0x0);


    print("Reading COP ID CSR\n\r");
    read  (0x9f400000);


    print("Config FPGA Misc1 CSR to select DAP JTAG signals for ChipScope\n\r");
    write (0x97040000, 0x1A120000);
    //write (0x97040000, 0x80000000);
    //read  (0x97040000);


    print("*****************************************\n\r");
    print("************** Test Complete ************\n\r");
    print("*****************************************\n\r");


}; // cop_init
