#include "../tests/pcie2_rc_gen1_ob_test.c"
#include "../tests/pcie2_rc_gen1_ib_test.c"
#include "../tests/pcie_rc_test.c"
#include "../tests/pciex8_prbs.c"
#include "../tests/pcie_ep_test.c"
#include "../tests/pciex8_crosslink.c"
#include "../tests/pcie_force_comp.c"
#include "../tests/pcie_preset_test.c"
#include "../tests/pcie_rx_prbs.c"
#include "../tests/pcie_slt_prbs.c"

void pcie_test_package (){
  //  pcie0_ep_gen1_test();
  //  pcie0_ep_gen2_test();
  //  pcie0_ep_gen3_test();
  //  pcie1_ep_gen1_test();
  //  pcie1_ep_gen2_test();
  //  pcie1_ep_gen3_test();
  //  pcie2_ep_gen1_test();
  //  pcie2_ep_gen2_test();
  //  pcie2_ep_gen3_test();
    pcie2_rc_gen1_ob_test();
    pcie2_rc_gen1_ib_test();
}
