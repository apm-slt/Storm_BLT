

/* Intrrupt sequnce for PCIE ISR
#
# Author: Vaibhav Vaidya (vvaidya@apm.com )   // Crated new
*/

#include "pcie_base.h"
#include "pcie_base_test.h"
#include "pcie_isr.h"
#include "pcie_x8_regs_addrmap.h"

extern struct error_log itr_summ;
#ifdef DMA_INT_ENABLE

#define ENABLE_INT_P0     { \
                            gic_irq_enable(226, Isr_PCIE0_INT_A);  \
                            gic_irq_enable(227, Isr_PCIE0_INT_A);  \
                            gic_irq_enable(228, Isr_PCIE0_INT_A);  \
                            gic_irq_enable(229, Isr_PCIE0_INT_A);  \
                            gic_irq_enable(230, Isr_PCIE_P0);  \
                            gic_irq_enable(231, Isr_PCIE_P0);  \
                          }

#define ENABLE_INT_P1     { \
                            gic_irq_enable(232, Isr_PCIE1_INT_A);   \
                            gic_irq_enable(233, Isr_PCIE1_INT_A);   \
                            gic_irq_enable(234, Isr_PCIE1_INT_A);   \
                            gic_irq_enable(235, Isr_PCIE1_INT_A);   \
                            gic_irq_enable(236, Isr_PCIE_P1);   \
                            gic_irq_enable(237, Isr_PCIE_P1);   \
                          }

#define ENABLE_INT_P2     { \
	                        gic_irq_enable(238, Isr_PCIE2_INT_A);   \
                            gic_irq_enable(239, Isr_PCIE2_INT_A);   \
                            gic_irq_enable(240, Isr_PCIE2_INT_A);   \
                            gic_irq_enable(241, Isr_PCIE2_INT_A);   \
                            gic_irq_enable(242, Isr_PCIE_P2);   \
                            gic_irq_enable(243, Isr_PCIE_P2);   \
                          }
#define ENABLE_INT_P3     { \
                            gic_irq_enable(244, Isr_PCIE3_INT_A);   \
                            gic_irq_enable(245, Isr_PCIE3_INT_A);   \
                            gic_irq_enable(246, Isr_PCIE3_INT_A);   \
                            gic_irq_enable(247, Isr_PCIE3_INT_A);   \
                            gic_irq_enable(248, Isr_PCIE_P3);   \
                            gic_irq_enable(249, Isr_PCIE_P3);   \
                          }


#define ENABLE_INT_P4     { \
                            gic_irq_enable(250, Isr_PCIE4_INT_A);  \
                            gic_irq_enable(251, Isr_PCIE4_INT_A);  \
                            gic_irq_enable(252, Isr_PCIE4_INT_A);  \
                            gic_irq_enable(253, Isr_PCIE4_INT_A);  \
                            gic_irq_enable(254, Isr_PCIE_P4);  \
                            gic_irq_enable(255, Isr_PCIE_P4);  \
                          }

#define ENABLE_EXT_INT_DS12  {\
                               gic_irq_enable(76, Isr_PERST_01);  \
                             }
#define ENABLE_EXT_INT_DS13  {\
                               gic_irq_enable(77, Isr_PERST_34);  \
                             }


#define ENABLE_MSI_INT       { \
								 gic_irq_enable(48,Isr_MSI0);\
								 gic_irq_enable(49,Isr_MSI0);\
								 gic_irq_enable(50,Isr_MSI0);\
								 gic_irq_enable(51,Isr_MSI0);\
								 gic_irq_enable(52,Isr_MSI0);\
								 gic_irq_enable(53,Isr_MSI0);\
								 gic_irq_enable(54,Isr_MSI0);\
								 gic_irq_enable(55,Isr_MSI0);\
								 gic_irq_enable(56,Isr_MSI0);\
								 gic_irq_enable(57,Isr_MSI0);\
								 gic_irq_enable(58,Isr_MSI0);\
								 gic_irq_enable(59,Isr_MSI0);\
								 gic_irq_enable(60,Isr_MSI0);\
								 gic_irq_enable(61,Isr_MSI0);\
								 gic_irq_enable(62,Isr_MSI0);\
								 gic_irq_enable(63,Isr_MSI0);\
                             }


void InitPERST_EP(unsigned int pcie_core_id)
{
	uint32_t data=0;

	if( (pcie_core_id == 0) ||  (pcie_core_id == 1))
	{
	    data = cpu_read(0x17001294);  // GPIO_DS12_SEL as GPIO
	                                  // 00: GPIO_DS12 / WAKE_5 / PS_I2C_SLV_ADR1
	    data &= ~(0x03<<24);
	    cpu_write(0x17001294, data);

	    data = cpu_read(0x1700129c);  // GPIO_DS12_SEL As Inputs
	    data &= ~(1 <<12);
	    cpu_write(0x1700129c, data);

	    data = cpu_read(0x78010c10);  //GICD_ICFGR4 (SPI Interrupt Configuration Registers) Level triggered
	    data &= 0xffff0000 ;
	    data |= 0xFFFF5555 ;          // Is 1 is level triggerd to 0 is level triggered
	    cpu_write(0x78010c10, data);

	    data=cpu_read(0x50001290);    // MPA_GPIO_INT_LVL (SLIMpro ARM GPIO_DS Interrupt Level Register)
	    data |= 0x3F;
	    cpu_write(0x50001290, data);

	    data=cpu_read(0x50001294);    // MPA_GPIO_SEL_LO (SLIMpro ARM GPIO_DS Function Select Low Register)
	    data &= ~ (0x3000000 ) ;       // set for IRQ_IN_4
	    data |= 0x1000000;
	    cpu_write(0x50001294, data);

	    lprintf(5,"PCIe slot 0/1 Configured for INT : 0x%x, cpu_read(0x78010c10) \n\r");

	}
	else{

	    data = cpu_read(0x17001294);  // GPIO_DS13_SEL as GPIO
	                                  // 00: GPIO_DS12 / WAKE_5 / PS_I2C_SLV_ADR1
	    data &= ~(0x0C<<24);
	    cpu_write(0x17001294, data);

	    data = cpu_read(0x1700129c);  // GPIO_DS13_SEL As Inputs
	    data &= ~(2 <<12);
	    cpu_write(0x1700129c, data);

	    data = cpu_read(0x78010c10);  //GICD_ICFGR4 (SPI Interrupt Configuration Registers) Level triggered
	    data &= 0xffff0000 ;
	    data |= 0xFFFF5555 ;          // Is 1 is level triggerd to 0 is level triggered
	    cpu_write(0x78010c10, data);

	    data=cpu_read(0x50001290);    // MPA_GPIO_INT_LVL (SLIMpro ARM GPIO_DS Interrupt Level Register)
	    data |= 0x3F;
	    cpu_write(0x50001290, data);

	    data=cpu_read(0x50001294);    // MPA_GPIO_SEL_LO (SLIMpro ARM GPIO_DS Function Select Low Register)
	    data &= ~ (0xC000000 ) ;       // set for IRQ_IN_4
	    data |=    0x4000000;
	    cpu_write(0x50001294, data);

	    lprintf(5,"PCIe slot 3/4 Configured for INT : 0x%x, cpu_read(0x78010c10) \n\r");


	    }
}

void Isr_PCIE0_INT_A (unsigned int irq_id )
{
	uint32_t data=0;

	g_Int_Status|=0x8;    // for loopbcak mode it comes on RC side.
//	g_Int_Status|=0x1;   // Ugly fix for RC DMA
	gic_irq_disable(irq_id);

    data=pcie_ob_cfg_read(0, (NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (0 * 0x40)));
    pcie_ob_cfg_write(0,(NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (0 * 0x40)),data);

    pcie_ob_cfg_write(0,(NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (0 * 0x40)),0x4);
    pcie_ob_cfg_read(0, (NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (0 * 0x40)));

	lprintf(5,"PCIE-0 INT-A = %d \n\r",irq_id);
}
void Isr_PCIE1_INT_A (unsigned int irq_id )
{
	lprintf(5,"PCIE-1 INT-A = %d \n\r",irq_id);
}
void Isr_PCIE2_INT_A (unsigned int irq_id )
{
	lprintf(5,"PCIE-2 INT-A = %d \n\r",irq_id);
}
void Isr_PCIE3_INT_A (unsigned int irq_id )
{
	lprintf(5,"PCIE-3 INT-A = %d \n\r",irq_id);
}
void Isr_PCIE4_INT_A (unsigned int irq_id )
{
	lprintf(5,"PCIE-4 INT-A = %d \n\r",irq_id);
}

void Isr_PERST_01(unsigned int irq_id )
{
	lprintf(5,"Reset Request from Port01 = %d \n\r",irq_id);
}

void Isr_PERST_34(unsigned int irq_id )
{
	lprintf(5,"Reset Request from Port34 = %d \n\r",irq_id);
}

void En_MSI_ISR(unsigned int pcie_core_id)
{
	lprintf(5," Enabling MSI for = %d \n\r",pcie_core_id);
	ENABLE_MSI_INT;
}

void Isr_MSI0(unsigned int irq_id)
{
	lprintf(5,"MSInIRx (MSI Index Registers): 0x%x \n\r", cpu_read(0x79000000) );
	lprintf(5,"MSI ISR Triggered = %d \n\r",irq_id);
}

void en_intx_int(unsigned int pcie_core_id)
{
  uint32_t data=0;

 lprintf(5,"INTX_STATUS-Default = 0x%x \n\r",pcie_csr_read(pcie_core_id,SM_PCIE_CSR_REGS_INTXSTATUSMASK__ADDR) );
  lprintf(5,"INTxStatus = 0x%x \n\r",pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_INTXSTATUS__ADDR) );

  data = 0xFFFFFFF0;
  pcie_csr_write(pcie_core_id,SM_PCIE_CSR_REGS_INTXSTATUSMASK__ADDR,data);
  lprintf(5,"INTX_STATUS-Set     = 0x%x \n\r",pcie_csr_read(pcie_core_id,SM_PCIE_CSR_REGS_INTXSTATUSMASK__ADDR) );


}
void en_event_int(unsigned int pcie_core_id)
{
	uint32_t data=0;

	lprintf(5,"Enabling Interrupt for pcie port : = %d \n\r",pcie_core_id);
	lprintf(5,"Int Status : =0x%x \n\r",pcie_csr_read(pcie_core_id,SM_PCIE_CSR_REGS_EVENTINTERRUPTSTATUS__ADDR) );


	pcie_csr_write( pcie_core_id, SM_PCIE_CSR_REGS_EVENTINTERRUPTSTATUS__ADDR ,
	                              pcie_csr_read(pcie_core_id,SM_PCIE_CSR_REGS_EVENTINTERRUPTSTATUS__ADDR)
	              );



	pcie_csr_write( pcie_core_id, SM_PCIE_CSR_REGS_EVENTINTERRUPTSTATUS__ADDR ,
	    				          pcie_csr_read(pcie_core_id,SM_PCIE_CSR_REGS_EVENTINTERRUPTSTATUS__ADDR)
	              );


	data=pcie_csr_read(pcie_core_id,SM_PCIE_CSR_REGS_EVENTINTERRUPTSTATUSMASK__ADDR);
	lprintf(5,"PCIE-Evt-Mask-Default = 0x%x \n\r",data );
//	 data = ~ (0xFFFFFDFF);
	data = 0xFFFFFDFF;
	pcie_csr_write(pcie_core_id,SM_PCIE_CSR_REGS_EVENTINTERRUPTSTATUSMASK__ADDR,data);
	lprintf(5,"PCIE-Evt-Mask-Set = 0x%x \n\r",pcie_csr_read(pcie_core_id,SM_PCIE_CSR_REGS_EVENTINTERRUPTSTATUSMASK__ADDR) );

    data=pcie_csr_read(pcie_core_id,SM_PCIE_CSR_REGS_PCIECORE_CTLANDSTATUS__ADDR);
    data|=0x400000;      // To make core interrupt Edge triggered, to clear in ISR, in order to prevent multiple isr trig.
    pcie_csr_write(pcie_core_id,SM_PCIE_CSR_REGS_PCIECORE_CTLANDSTATUS__ADDR,data);


    // DMA specific to int on AXI side
    data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_PCIE_INT_AXI_PCIE_N__ADDR);
	data |=0x0;            // To genrate on AXI : 1 
	                       // To Genrare on PCIE : 0
	pcie_csr_write(pcie_core_id,NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_PCIE_INT_AXI_PCIE_N__ADDR,data);

    switch (pcie_core_id)
    {
      case 0 :ENABLE_INT_P0;break;
      case 1: ENABLE_INT_P1;break;
      case 2 :ENABLE_INT_P2;break;
      case 3: ENABLE_INT_P3;break;
      case 4: ENABLE_INT_P4;break;
    }
}

extern uint64_t EP_BAR_AXI_ADDR[6];
void Isr_PCIE_P0(unsigned int irq_id )
{
	unsigned int data=0;

//	data = pcie_ob_cfg_read(0, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (0 * 0x40));

	lprintf(5,"Int Status : =0x%x \n\r",pcie_csr_read(0,SM_PCIE_CSR_REGS_EVENTINTERRUPTSTATUS__ADDR) );

	if(irq_id==226){
	lprintf(5,"INTxStatus = 0x%x \n\r",pcie_csr_read(0, SM_PCIE_CSR_REGS_INTXSTATUS__ADDR) );
	gic_irq_disable(irq_id);
        }

        else  pcie_csr_write (0,SM_PCIE_CSR_REGS_EVENTINTERRUPTSTATUS__ADDR,
			          pcie_csr_read(0,SM_PCIE_CSR_REGS_EVENTINTERRUPTSTATUS__ADDR));

//	pcie_csr_write (0,SM_PCIE_CSR_REGS_EVENTINTERRUPTSTATUS__ADDR,0x134);



	g_Int_Status=0x1;
//	gic_irq_disable(irq_id);

	lprintf(3,"DMA-Completion Interrupt from Port-0 IRQ :=  %d , DMA: %d\n\r",irq_id,g_Int_Status);

#ifdef STRESS_TEST
	lprintf(5,"Uncorrectable Error Status Register  : 0x%x \n\r",pcie_ob_cfg_read(0, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+4)));
	itr_summ.aer_error_rc=pcie_ob_cfg_read(0, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+4));

	lprintf(5,"Correctable Error Status Register  : 0x%x \n\r",pcie_ob_cfg_read(0, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x10)));
	itr_summ.link_error=pcie_ob_cfg_read(0, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x10));

	itr_summ.link_error_rc=pcie_ob_cfg_read(0, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x30));
	lprintf(5,"Root Error Status  : 0x%x \n\r",pcie_ob_cfg_read(0, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x30)) );

    pcie_ob_cfg_write ( 0,
          		            (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+4) ,
          		             pcie_ob_cfg_read(0, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+4))
          		          );

     pcie_ob_cfg_write ( 0,
          		            (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x10) ,
          		             pcie_ob_cfg_read(0, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x10))
          		          );


     pcie_ob_cfg_write ( 0,
          		            (SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+4) ,
          		             pcie_ob_cfg_read(0, (SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+4))
          		          );
      pcie_ob_cfg_write ( 0,
          		            (SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+0x10) ,
          		             pcie_ob_cfg_read(0, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x10))
          		          );

          pcie_ob_cfg_write ( 0,
                  		            (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x30) ,
                  		             pcie_ob_cfg_read(0, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x30))
                  		          );

          pcie_ob_cfg_write ( 0,(SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+0x30),
        		               pcie_ob_cfg_read(0, (SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+0x30)));


          lprintf(5,"Uncorrectable Error Status Register  : 0x%x \n\r",pcie_ob_cfg_read(0, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+4)));
          	itr_summ.aer_error_rc=pcie_ob_cfg_read(0, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+4));
          lprintf(5,"Correctable Error Status Register  : 0x%x \n\r",pcie_ob_cfg_read(0, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x10)));
          	itr_summ.link_error=pcie_ob_cfg_read(0, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x10));
          itr_summ.link_error_rc=pcie_ob_cfg_read(0, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x30));
          	lprintf(5,"Root Error Status  : 0x%x \n\r",pcie_ob_cfg_read(0, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x30)) );

#elif defined (EN_AER) 
	lprintf(5,"Uncorrectable Error Status Register  : 0x%x \n\r",pcie_ob_cfg_read(0, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+4)));
	lprintf(5,"Uncorrectable Error Mask Register  : 0x%x \n\r",pcie_ob_cfg_read(0, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR + 8)));
	lprintf(5,"Uncorrectable Error Severity Register  : 0x%x \n\r",pcie_ob_cfg_read(0, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR + 0x0C)));
	lprintf(5,"Correctable Error Status Register  : 0x%x \n\r",pcie_ob_cfg_read(0, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x10)));
	lprintf(5,"Correctable Error Mask Register  : 0x%x \n\r",pcie_ob_cfg_read(0, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x14)));

	lprintf(5,"Correctable Error Status Register  : 0x%x \n\r",pcie_ob_cfg_read(0, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x10)));

	lprintf(5,"Error Source Identification Register : 0x%x \n\r",pcie_ob_cfg_read(0, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x34)) );

	lprintf(5,"Header log Register1  : 0x%x \n\r",pcie_ob_cfg_read(0, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x1C)));
	lprintf(5,"Header log Register2  : 0x%x \n\r",pcie_ob_cfg_read(0, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x20)));
	lprintf(5,"Header log Register3  : 0x%x \n\r",pcie_ob_cfg_read(0, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x24)));
	lprintf(5,"Header log Register4  : 0x%x \n\r",pcie_ob_cfg_read(0, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x28)));
	lprintf(5,"Root Error Command : 0x%x \n\r",pcie_ob_cfg_read(0, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x2C)));
	lprintf(5,"Root Error Status  : 0x%x \n\r",pcie_ob_cfg_read(0, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x30)) );
#endif
}
void Isr_PCIE_P1(unsigned int irq_id)
{


	pcie_csr_write (1,SM_PCIE_CSR_REGS_EVENTINTERRUPTSTATUS__ADDR,
				          pcie_csr_read(1,SM_PCIE_CSR_REGS_EVENTINTERRUPTSTATUS__ADDR));

	g_Int_Status|=0x2;
	gic_irq_disable(irq_id);
	lprintf(5,"Interrupt from Port-1 IRQ :irq=  %d \n\r",irq_id);

}
 void Isr_PCIE_P2(unsigned int irq_id)
{


	pcie_csr_write (2,SM_PCIE_CSR_REGS_EVENTINTERRUPTSTATUS__ADDR,
					  pcie_csr_read(2,SM_PCIE_CSR_REGS_EVENTINTERRUPTSTATUS__ADDR));

	g_Int_Status|=0x4;
	gic_irq_disable(irq_id);

	lprintf(5,"Interrupt from Port-2 IRQ :irq=  %d \n\r",irq_id);

}

extern uint32_t isr_cnt;
void Isr_PCIE_P3(unsigned int irq_id)
{

	g_Int_Status=0x8;
	pcie_csr_write (3,SM_PCIE_CSR_REGS_EVENTINTERRUPTSTATUS__ADDR,
					  pcie_csr_read(3,SM_PCIE_CSR_REGS_EVENTINTERRUPTSTATUS__ADDR));

	isr_cnt++;
	// gic_irq_disable(irq_id);

#ifdef EN_AER_EP_DIS
	lprintf(5,"Uncorrectable Error Status Register  : 0x%x \n\r",pcie_ob_cfg_read(3, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+4)));
	lprintf(5,"Uncorrectable Error Mask Register  : 0x%x \n\r",pcie_ob_cfg_read(3, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR + 8)));
	lprintf(5,"Uncorrectable Error Severity Register  : 0x%x \n\r",pcie_ob_cfg_read(3, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR + 0x0C)));

	lprintf(5,"Error Source Identification Register : 0x%x \n\r",pcie_ob_cfg_read(3, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x34)) );

	lprintf(5,"Header log Register1  : 0x%x \n\r",pcie_ob_cfg_read(3, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x1C)));
	lprintf(5,"Header log Register2  : 0x%x \n\r",pcie_ob_cfg_read(3, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x20)));
	lprintf(5,"Header log Register3  : 0x%x \n\r",pcie_ob_cfg_read(3, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x24)));
	lprintf(5,"Header log Register4  : 0x%x \n\r",pcie_ob_cfg_read(3, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x28)));
	lprintf(5,"Root Error Command : 0x%x \n\r",pcie_ob_cfg_read(3, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x2C)));
	lprintf(5,"Root Error Status  : 0x%x \n\r",pcie_ob_cfg_read(3, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x30)) );
#endif


	lprintf(5,"Interrupt from Port-3 IRQ :irq=  %d  DMA: %d \n\r",irq_id,g_Int_Status);
}
 void Isr_PCIE_P4(unsigned int irq_id)
{


	pcie_csr_write (4,SM_PCIE_CSR_REGS_EVENTINTERRUPTSTATUS__ADDR,
					  pcie_csr_read(0,SM_PCIE_CSR_REGS_EVENTINTERRUPTSTATUS__ADDR));

	g_Int_Status|=0x10;
	gic_irq_disable(irq_id);
	lprintf(5,"Interrupt from Port-4 IRQ :irq=  %d \n\r",irq_id);
}

#endif


