
#include <stdio.h>
#include <vbios_vsyms.h>

#undef DEBUG

#ifdef DEBUG
#define DBG_PRINT printf
#else
#define DBG_PRINT(...)
#endif

extern struct vsymbols vsym[];
extern int vsym_count;
unsigned int vsym_addr = &vsym;

void find_symbol(unsigned long address, char**name)
{
        int start=0, end=vsym_count, mid=0;
        while((end-start) > 1) {
                mid = (start+end)/2;
                if(vsym[mid].addr > address)
                        end = mid;
                else if(vsym[mid].addr < address)
                        start = mid;
                else {
                        *name = vsym[mid].name;
                       // printf("%s", *name);
                        return;
                }
        }
        *name = vsym[start].name;
 //       printf("%s", *name);
}

int find_symbol_addr(char *name, unsigned long *address)
{
	int result = -1, i;
	for(i=0;i<vsym_count; i++)
		if(!strcmp(vsym[i].name, name)) {
			*address = vsym[i].addr;
			result = 0;
			break;
		}
	return(result);
}



