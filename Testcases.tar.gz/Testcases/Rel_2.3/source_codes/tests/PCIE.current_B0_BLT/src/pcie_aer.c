#include "pcie_base.h"
#include "pcie_base_test.h"
#include "pcie_aer.h"
#include "pcie_x8_regs_addrmap.h"


#ifdef EN_AER

void Config_AER(uint32_t rc_slot)
{

   uint32_t data,test_pattern=1,length=0x2048,extended_addr=0;
   uint64_t EP_BAR0, EP_BAR2, EP_BAR4,start_addr,fail=0;

     lprintf(5,"---------------------------------------------------------------------------------------------------------------\n\r");
     lprintf(5,"---------------------------------------------------------------------------------------------------------------\n\r");
     lprintf(5,"BEFORE TEST AER CAP.ON RC: : 0x%x \n\r",pcie_ob_cfg_read(rc_slot, SM_PCIE_CFG1_PCIE_CFG1_DEV_ID__ADDR) );
     lprintf(5,"---------------------------------------------------------------------------------------------------------------\n\r");
     lprintf(5,"---------------------------------------------------------------------------------------------------------------\n\r");

	 lprintf(5,"PCI Express Extended Capability Header  : 0x%x \n\r",pcie_ob_cfg_read(rc_slot, SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR));
     lprintf(5,"Uncorrectable Error Status Register  : 0x%x \n\r",pcie_ob_cfg_read(rc_slot, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+4)));

     pcie_ob_cfg_write ( rc_slot,
    		             (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+4) ,
    		              pcie_ob_cfg_read(rc_slot, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+4))
    		           );

     lprintf(5,"Uncorrectable Error Status Register  : 0x%x \n\r",pcie_ob_cfg_read(rc_slot, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+4)));
     lprintf(5,"Uncorrectable Error Mask Register  : 0x%x \n\r",pcie_ob_cfg_read(rc_slot, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR + 8)));
     lprintf(5,"Uncorrectable Error Severity Register  : 0x%x \n\r",pcie_ob_cfg_read(rc_slot, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR + 0x0C)));

     lprintf(5,"Correctable Error Status Register  : 0x%x \n\r",pcie_ob_cfg_read(rc_slot, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x10)));
     lprintf(5,"Correctable Error Mask Register  : 0x%x \n\r",pcie_ob_cfg_read(rc_slot, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x14)));
     lprintf(5,"Advanced Error Capabilities and Control Register  : 0x%x \n\r",
	        pcie_ob_cfg_read(rc_slot,(SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x18)));

     lprintf(5,"Header Log Register1  : 0x%x \n\r",pcie_ob_cfg_read(rc_slot, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x1C)) );
     lprintf(5,"Header Log Register2  : 0x%x \n\r",pcie_ob_cfg_read(rc_slot, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x20)) );
     lprintf(5,"Header Log Register3  : 0x%x \n\r",pcie_ob_cfg_read(rc_slot, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x24)) );
     lprintf(5,"Header Log Register4  : 0x%x \n\r",pcie_ob_cfg_read(rc_slot, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x28)) );

     lprintf(5,"Root Error Command  : 0x%x \n\r",pcie_ob_cfg_read(rc_slot, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x2C)) );
    
     pcie_ob_cfg_write(rc_slot,(SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x2C),0x7); 

     lprintf(5,"Device Control Reg.:  : 0x%x \n\r",pcie_ob_cfg_read(rc_slot, SM_PCIE_CFG1_PCIE_CFG1_DEV_CTRL__ADDR));
     pcie_ob_cfg_write(rc_slot,(SM_PCIE_CFG1_PCIE_CFG1_DEV_CTRL__ADDR),
    		                   (pcie_ob_cfg_read(rc_slot, SM_PCIE_CFG1_PCIE_CFG1_DEV_CTRL__ADDR) | 0x8));

     lprintf(5,"Root Error Status  : 0x%x \n\r",pcie_ob_cfg_read(rc_slot, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x30)) );
     pcie_ob_cfg_write(rc_slot,(SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR + 0x30),
        		               pcie_ob_cfg_read(rc_slot, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR + 0x30) )
        		      );

     lprintf(5,"Error Source Identification Register : 0x%x \n\r",pcie_ob_cfg_read(rc_slot, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x34)) );

}

void Config_AER_EP(uint32_t ep_slot)
{

   uint32_t data,test_pattern=1,length=0x2048,extended_addr=0;
   uint64_t EP_BAR0, EP_BAR2, EP_BAR4,start_addr,fail=0;

     lprintf(5,"---------------------------------------------------------------------------------------------------------------\n\r");
     lprintf(5,"---------------------------------------------------------------------------------------------------------------\n\r");
     lprintf(5,"BEFORE TEST AER CAP.ON RC: : 0x%x \n\r",pcie_ob_cfg_read(ep_slot, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR) );
     lprintf(5,"---------------------------------------------------------------------------------------------------------------\n\r");
     lprintf(5,"---------------------------------------------------------------------------------------------------------------\n\r");

	 lprintf(5,"PCI Express Extended Capability Header  : 0x%x \n\r",pcie_ob_cfg_read(ep_slot, SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR));
     lprintf(5,"Uncorrectable Error Status Register  : 0x%x \n\r",pcie_ob_cfg_read(ep_slot, (SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+4)));
     pcie_ob_cfg_write ( ep_slot,
    		             (SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+4) ,
    		              pcie_ob_cfg_read(ep_slot, (SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+4))
    		           );

     lprintf(5,"Uncorrectable Error Status Register  : 0x%x \n\r",pcie_ob_cfg_read(ep_slot, (SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+4)));
     lprintf(5,"Uncorrectable Error Mask Register  : 0x%x \n\r",pcie_ob_cfg_read(ep_slot, (SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR + 8)));
     lprintf(5,"Uncorrectable Error Severity Register  : 0x%x \n\r",pcie_ob_cfg_read(ep_slot, (SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR + 0x0C)));

     lprintf(5,"Correctable Error Status Register  : 0x%x \n\r",pcie_ob_cfg_read(ep_slot, (SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+0x10)));
     lprintf(5,"Correctable Error Mask Register  : 0x%x \n\r",pcie_ob_cfg_read(ep_slot, (SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+0x14)));
     lprintf(5,"Advanced Error Capabilities and Control Register  : 0x%x \n\r",
    		 pcie_ob_cfg_read(ep_slot,(SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+0x18)));


     lprintf(5,"Header Log Register1  : 0x%x \n\r",pcie_ob_cfg_read(ep_slot, (SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+0x1C)) );
     lprintf(5,"Header Log Register2  : 0x%x \n\r",pcie_ob_cfg_read(ep_slot, (SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+0x20)) );
     lprintf(5,"Header Log Register3  : 0x%x \n\r",pcie_ob_cfg_read(ep_slot, (SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+0x24)) );
     lprintf(5,"Header Log Register4  : 0x%x \n\r",pcie_ob_cfg_read(ep_slot, (SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+0x28)) );

    lprintf(5,"Root Error Command  : 0x%x \n\r",pcie_ob_cfg_read(ep_slot, (SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+ 0x2C)) );
    pcie_ob_cfg_write(ep_slot,(SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+0x2C),0x7);

    lprintf(5,"Device Control Reg.:  : 0x%x \n\r",pcie_ob_cfg_read(ep_slot, SM_PCIE_CFG0_PCIE_CFG0_DEV_CTRL__ADDR));
     pcie_ob_cfg_write(ep_slot,(SM_PCIE_CFG0_PCIE_CFG0_DEV_CTRL__ADDR),
    		                   (pcie_ob_cfg_read(ep_slot, SM_PCIE_CFG0_PCIE_CFG0_DEV_CTRL__ADDR) | 0x8));


     lprintf(5,"Root Error Status  : 0x%x \n\r",pcie_ob_cfg_read(ep_slot, (SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+0x30)) );
     lprintf(5,"Error Source Identification Register : 0x%x \n\r",pcie_ob_cfg_read(ep_slot, (SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+0x34)) );


}
#endif

void EnECRCGen(uint32_t pcie_core_id, uint32_t role)
{

  if(role==RC)
  {
	 lprintf(5,"Enabling Genration/Check of ECRC on RC side \n\r");
	 pcie_ob_cfg_write(pcie_core_id,(SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x18),0x1E0);
      lprintf(5,"Advanced Error Capabilities and Control Register  : 0x%x \n\r",
	  pcie_ob_cfg_read(pcie_core_id,(SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+0x18)));


  }else{
	 lprintf(5,"Enabling Genration/Check of ECRC on EP side \n\r");
         pcie_ob_cfg_write(pcie_core_id,(SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+0x18),0x1E0);
          lprintf(5,"Advanced Error Capabilities and Control Register  : 0x%x \n\r",
		  pcie_ob_cfg_read(pcie_core_id,(SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+0x18)));

  }

}
