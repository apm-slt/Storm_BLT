#include <stdio.h>
#include "platform.h"
#include "common.h"
#include "ocm_main.h"
void ocm_main()
{
    unsigned int i, *ptr;
    
    printf("Sushant- This print is due to code executed from 'OCM main' space\n");
    printf("Done!\n");
}

