/*
This file is meant for tunnig serdes receiver parameter taken from src/pcie_base.c file, 
for making seperate initilization code for margning tool on recevier side.
Release 1: Targeted only for following RX serdes parameters 

RXDFE
CTLE
PQREG
MU_PHASE

*/
#include "margin.h"

char *Rx_serdes_param[] = {
	"",												
	"CTLE_AC", 		         // 1	
	"CTLE_DC",				 // 2	
	"CTLE_EQ_FR",			 // 3	 
	"CTLE_EQ_QR",	   		 // 4		
	"CTLE_EQ_HR",			 // 5 
	"CTLE_EQ",			     // 6
	"DFE",                   // 7
	"PQSign",				 // 8	
	"PQ-SK",				 // 9	
	"PRESET",			     // 10			
	"MU_PHASE1",					
	"MU_PHASE2",							
	"MU_PHASE3",						
	"MU_PHASE4",							
	"MU_PHASE5",
	"MU_PHASE6",					
	"MU_PHASE7", 
	"MU_PHASE8",
	"MU_PHASE9"
};

uint32_t Ch_RxTxParam[CH_TX_RX_REG][RANGE]={
   
    0,0,0,    //0 is empty
    1,1,7,    // 1
	0,0,3,    // 2
	7,1,7,    // 3
	7,1,7,    // 4
	7,1,7,    // 5
	7,1,7,    // 6
	7,0,7,    // 7
	0,0,1,    // PQ: Sign
	0x11,0xA,0x18,    // 9
	2,2,7,    // 10
	0,0,0,
	0,0,0,
	0,0,0,
	0,0,0,
	0,0,0,
	0,0,0,
	0,0,0,
    0,0,0,
    0,0,0 
};

void tune_rx_control(uint32_t pcie_core_id, uint32_t ch, uint32_t sds2) {

  uint32_t data, sds2_offset,ctle_ac_gain=0;
  uint32_t ctle_fr_gain=0,ctle_qr_gain=0,ctle_hr_gain=0;

  //lprintf(5,"Serdes RX config, core 0x%x, channel# 0x%x, serdes# 0x%x \n\r", pcie_core_id, ch, sds2);
  if (sds2){
    sds2_offset = 0x30000;
  } else {
    sds2_offset = 0x0;
  }
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG147__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG147_STMC_OVERRIDE_SET(data, 0x6);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG147__ADDR + (0x200 * ch) + sds2_offset, data);

  //important: this is workaound for lack of reset after power state change bug
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG27__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG27_RXPD_CONFIG_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG27__ADDR + (0x200 * ch) + sds2_offset, data);


  //RX control
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG2_RESETB_TERM_SET(data, 0x0);  // is this correct ???
  data = FIELD_CH0_RXTX_REG2_VTT_ENA_SET(data, 0x1);
  data = FIELD_CH0_RXTX_REG2_VTT_SEL_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG1__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG1_RXACVCM_SET(data, 0x7);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG1__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG12_RX_DET_TERM_ENABLE_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG148__ADDR + (0x200 * ch) + sds2_offset);
  data = 0xffff; //rx bist word count 0 
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG148__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG149__ADDR + (0x200 * ch) + sds2_offset);
  data = 0xffff; //rx bist word count 1 
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG149__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG150__ADDR + (0x200 * ch) + sds2_offset);
  data = 0xffff; //rx bist word count 2 
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG150__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG151__ADDR + (0x200 * ch) + sds2_offset);
  data = 0xffff; //rx bist word count 3 
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG151__ADDR + (0x200 * ch) + sds2_offset, data);


  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG1__ADDR + (0x200 * ch) + sds2_offset);
  ctle_ac_gain=Ch_RxTxParam[CTLE_EQ_IDX][0];
  data = FIELD_CH0_RXTX_REG1_CTLE_EQ_SET(data, (ctle_ac_gain << 2) );
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG1__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG0__ADDR + (0x200 * ch) + sds2_offset);
  
  ctle_fr_gain=Ch_RxTxParam[CTLE_EQ_FR_IDX][0];
  data = FIELD_CH0_RXTX_REG0_CTLE_EQ_FR_SET(data, ctle_fr_gain<<2);
  ctle_qr_gain=Ch_RxTxParam[CTLE_EQ_QR_IDX][0];
  data = FIELD_CH0_RXTX_REG0_CTLE_EQ_QR_SET(data, ctle_qr_gain<<2);
  ctle_hr_gain=Ch_RxTxParam[CTLE_EQ_HR_IDX][0];
  data = FIELD_CH0_RXTX_REG0_CTLE_EQ_HR_SET(data, ctle_hr_gain<<2);
  
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG0__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG12_LATCH_OFF_ENA_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG128__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG128_LATCH_CAL_WAIT_SEL_SET(data, 0x3);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG128__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG8__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG8_CDR_LOOP_ENA_SET(data, 0x1);
  data = FIELD_CH0_RXTX_REG8_CDR_BYPASS_RXLOS_SET(data, 0x0);
  data = FIELD_CH0_RXTX_REG8_SD_VREF_SET(data, 0x4); //130830, added to remove SD glitch
pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG8__ADDR + (0x200 * ch) + sds2_offset, data);

//controlled by PIPE
//data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset);
//data = FIELD_CH0_RXTX_REG61_SPD_SEL_CDR_SET(data, 0x7);
//pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG125__ADDR + (0x200 * ch) + sds2_offset);
  //data = FIELD_CH0_RXTX_REG125_PQ_REG_SET(data, 0xa);
  data = FIELD_CH0_RXTX_REG125_PQ_REG_SET(data, Ch_RxTxParam[PQ_VALUE_IDX]);  //140624: bertscope receiver test shows 0x11 is best result
  data = FIELD_CH0_RXTX_REG125_PHZ_MANUAL_SET(data, 0x1);
pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG125__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG11__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG11_PHASE_ADJUST_LIMIT_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG11__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset);
  #ifdef RX_SSC_ENB
    data = FIELD_CH0_RXTX_REG61_LOADFREQ_SHIFT_SET(data, 0x0);
  #else 
    data = FIELD_CH0_RXTX_REG61_LOADFREQ_SHIFT_SET(data, 0x1);
  #endif
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG102__ADDR + (0x200 * ch) + sds2_offset);
  #ifdef RX_SSC_ENB
    data = FIELD_CH0_RXTX_REG102_FREQLOOP_LIMIT_SET(data, 0x0);
  #else
    data = FIELD_CH0_RXTX_REG102_FREQLOOP_LIMIT_SET(data, 0x3);
  #endif
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG102__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG8__ADDR + (0x200 * ch) + sds2_offset);
  #ifdef RX_SSC_ENB
    data = FIELD_CH0_RXTX_REG8_SSC_ENABLE_SET(data, 0x1);
  #else
    data = FIELD_CH0_RXTX_REG8_SSC_ENABLE_SET(data, 0x0);
  #endif
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG8__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG96__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG96_MU_FREQ1_SET(data, 0x10);
  data = FIELD_CH0_RXTX_REG96_MU_FREQ2_SET(data, 0x10);
  data = FIELD_CH0_RXTX_REG96_MU_FREQ3_SET(data, 0x10);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG96__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG97__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG97_MU_FREQ4_SET(data, 0x10);
  data = FIELD_CH0_RXTX_REG97_MU_FREQ5_SET(data, 0x10);
  data = FIELD_CH0_RXTX_REG97_MU_FREQ6_SET(data, 0x10);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG97__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG98__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG98_MU_FREQ7_SET(data, 0x10);
  data = FIELD_CH0_RXTX_REG98_MU_FREQ8_SET(data, 0x10);
  data = FIELD_CH0_RXTX_REG98_MU_FREQ9_SET(data, 0x10);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG98__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG99__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG99_MU_PHASE1_SET(data, Ch_RxTxParam[MU_PHASE1_IDX][0]); 
  data = FIELD_CH0_RXTX_REG99_MU_PHASE2_SET(data, Ch_RxTxParam[MU_PHASE2_IDX][0]); 
  data = FIELD_CH0_RXTX_REG99_MU_PHASE3_SET(data, Ch_RxTxParam[MU_PHASE3_IDX][0]);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG99__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG100__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG100_MU_PHASE4_SET(data, Ch_RxTxParam[MU_PHASE4_IDX][0]);
  data = FIELD_CH0_RXTX_REG100_MU_PHASE5_SET(data, Ch_RxTxParam[MU_PHASE5_IDX][0]);
  data = FIELD_CH0_RXTX_REG100_MU_PHASE6_SET(data, Ch_RxTxParam[MU_PHASE6_IDX][0]);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG100__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG101__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG101_MU_PHASE7_SET(data, Ch_RxTxParam[MU_PHASE7_IDX][0]);
  data = FIELD_CH0_RXTX_REG101_MU_PHASE8_SET(data, Ch_RxTxParam[MU_PHASE8_IDX][0]);
  data = FIELD_CH0_RXTX_REG101_MU_PHASE9_SET(data, Ch_RxTxParam[MU_PHASE9_IDX][0]);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG101__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG8__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG8_SD_DISABLE_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG8__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG26__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG26_BLWC_ENA_SET(data, 0x1); 
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG26__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG81__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG81_MU_DFE1_SET(data, 0xe);  //these are 0x6 for gen3
  data = FIELD_CH0_RXTX_REG81_MU_DFE2_SET(data, 0xe);
  data = FIELD_CH0_RXTX_REG81_MU_DFE3_SET(data, 0xe);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG81__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG82__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG82_MU_DFE4_SET(data, 0xe);  //these are 0x6 for gen3
  data = FIELD_CH0_RXTX_REG82_MU_DFE5_SET(data, 0xe);
  data = FIELD_CH0_RXTX_REG82_MU_DFE6_SET(data, 0xe);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG82__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG83__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG83_MU_DFE7_SET(data, 0xe); //these are 0x6 for gen3
  data = FIELD_CH0_RXTX_REG83_MU_DFE8_SET(data, 0xe);
  data = FIELD_CH0_RXTX_REG83_MU_DFE9_SET(data, 0xe);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG83__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG84__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG84_MU_PH1_SET(data, 0xe); //these are 0x6 for gen3
  data = FIELD_CH0_RXTX_REG84_MU_PH2_SET(data, 0xe);
  data = FIELD_CH0_RXTX_REG84_MU_PH3_SET(data, 0xe);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG84__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG85__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG85_MU_PH4_SET(data, 0xe);//these are 0x6 for gen3
  data = FIELD_CH0_RXTX_REG85_MU_PH5_SET(data, 0xe);
  data = FIELD_CH0_RXTX_REG85_MU_PH6_SET(data, 0xe);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG85__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG86__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG86_MU_PH7_SET(data, 0xe);//these are 0x6 for gen3
  data = FIELD_CH0_RXTX_REG86_MU_PH8_SET(data, 0xe);
  data = FIELD_CH0_RXTX_REG86_MU_PH9_SET(data, 0xe);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG86__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG87__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG87_MU_TH1_SET(data, 0xe);//these are 0x6 for gen3
  data = FIELD_CH0_RXTX_REG87_MU_TH2_SET(data, 0xe);
  data = FIELD_CH0_RXTX_REG87_MU_TH3_SET(data, 0xe);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG87__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG88__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG88_MU_TH4_SET(data, 0xe);//these are 0x6 for gen3
  data = FIELD_CH0_RXTX_REG88_MU_TH5_SET(data, 0xe);
  data = FIELD_CH0_RXTX_REG88_MU_TH6_SET(data, 0xe);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG88__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG89__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG89_MU_TH7_SET(data, 0xe);//these are 0x6 for gen3
  data = FIELD_CH0_RXTX_REG89_MU_TH8_SET(data, 0xe);
  data = FIELD_CH0_RXTX_REG89_MU_TH9_SET(data, 0xe);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG89__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG92__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG92_MU_BCA9_SET(data, 0xa); //140624: set BCA adoptation loop
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG92__ADDR + (0x200 * ch) + sds2_offset, data);


  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG145__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG145_RXDFE_CONFIG_SET(data, 0x3);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG145__ADDR + (0x200 * ch) + sds2_offset, data);

  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG28__ADDR + (0x200 * ch) + sds2_offset, Ch_RxTxParam[DFE_IDX]);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG7_RESETB_RXD_SET(data, 0x1);
  data = FIELD_CH0_RXTX_REG7_LOOP_BACK_ENA_CTLE_SET(data, 0x0);
  data = FIELD_CH0_RXTX_REG7_BIST_ENA_RX_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG12_RX_INV_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + sds2_offset, data);
 }

void print_rx_data(pcie_core_id)
{
 
}