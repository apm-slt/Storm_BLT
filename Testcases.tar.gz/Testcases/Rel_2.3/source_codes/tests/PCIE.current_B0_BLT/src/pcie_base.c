/*
 */
#include <types.h>
#include <stdio.h>
#include <common.h>
#include "pcie_base.h"
#include "pcie_ib_test.h"

//Tinh-SLT
#define linkup linkup_pcie
#define read read_pcie
#define write write_pcie
#define sm_host_write32 sm_host_write32_pcie
#define sm_host_read32 sm_host_read32_pcie
//End of Tinh-SLT

//#define Change4
#define Change5

//#define STRESS_TEST
//#define BUG_44393

extern void InitPERST_EP(unsigned int pcie_core_id);
extern uint32_t WR_BW_g,RD_BW_g;


#define SEC_2_NS_CONST 1000000000
#define KB_2_MB_CONST  1024

#define SKIP_BCA

//set to program PVT cal value manually
//#define manual_PVT

//set to bypass receiver detect
#define RCV_DET_BYPASS

//set to allow serdes control TX amplitude and pre/post cursor
//if not set, PIPE controls TX amplitude and pre/post cursor
//#define SDS_TX_CTRL

//set to use reference clock / 2 for serdes workaround on gen1/2
//#define REF_DIVIDE2

//set to use reference clock / 2 for serdes workaround on gen3
#define REF_DIVIDE2_GEN3

//set to use MOMSEL auto calibration
#define MOMSEL_AUTO

//use hot reset for linkup
//#define ENB_HOTRESET

//set to enable debug hook. 
//#define ENB_DEBUG_HOOK


#ifdef SM_SOC_SIM
void putnum(uint32_t num) {
  char str[32];

  sprintf(str, " 0x%x", num);
  lprintf(5,str);
}  
#endif

// **********************************************************************************
// function used to do basic read-write 
// **********************************************************************************
void cpu_write(uint64_t addr, uint32_t data) {
  uint64_t cpu_addr;

  cpu_addr = CPU_ACCESS_BASE | addr;
#ifdef SM_SOC_SIM
  sm_host_write32(cpu_addr, data);
#else  
  uint32_t cpu_addr32 = (uint32_t)cpu_addr;
  write(cpu_addr32, data); 
#endif
  lprintf(6, "CPU Write addr 0x%x, data 0x%x \n\r", addr, data);
}

uint32_t cpu_read(uint64_t addr) {
  uint64_t cpu_addr;
  uint32_t data;

  cpu_addr = CPU_ACCESS_BASE | addr;
#ifdef SM_SOC_SIM
  sm_host_read32(cpu_addr, &data);
#else  
  uint32_t cpu_addr32 = (uint32_t)cpu_addr;
  data = read(cpu_addr32); 
#endif

  lprintf(6, "CPU Read addr 0x%x, data 0x%x \n\r", addr, data);
  return data;
}

// **********************************************************************************
// function used to read-write registers inside the PCIE CSR space.
// **********************************************************************************
uint64_t ret_csr_base(uint32_t pcie_core_id) {
  uint64_t SM_ADDR_MAP_PCIE_CSR_BASE;

  switch(pcie_core_id) {
    case 0: SM_ADDR_MAP_PCIE_CSR_BASE = SM_ADDR_MAP_PCIE0_CSR_BASE; 
            break;
    case 1: SM_ADDR_MAP_PCIE_CSR_BASE = SM_ADDR_MAP_PCIE1_CSR_BASE; 
            break;
    case 3: SM_ADDR_MAP_PCIE_CSR_BASE = SM_ADDR_MAP_PCIE3_CSR_BASE; 
            break;
    case 4: SM_ADDR_MAP_PCIE_CSR_BASE = SM_ADDR_MAP_PCIE4_CSR_BASE; 
            break;
    default: SM_ADDR_MAP_PCIE_CSR_BASE = SM_ADDR_MAP_PCIE2_CSR_BASE; 
            break;           
  }

  return SM_ADDR_MAP_PCIE_CSR_BASE;
}

void pcie_csr_write(uint32_t pcie_core_id, uint32_t offset, uint32_t data) {
  uint64_t addr; 
  uint64_t SM_ADDR_MAP_PCIE_CSR_BASE;

  SM_ADDR_MAP_PCIE_CSR_BASE = ret_csr_base(pcie_core_id);

  addr = SM_ADDR_MAP_PCIE_CSR_BASE | ((uint64_t ) offset);

  lprintf(6, "pcie_csr_write(addr=0x%x)=0x%x\n",addr, data);
  cpu_write(addr, data);
}  

uint32_t pcie_csr_read(uint32_t pcie_core_id, uint32_t offset) {
  uint64_t addr; 
  uint64_t SM_ADDR_MAP_PCIE_CSR_BASE;
  uint32_t data; 

  SM_ADDR_MAP_PCIE_CSR_BASE = ret_csr_base(pcie_core_id);
  addr = SM_ADDR_MAP_PCIE_CSR_BASE | ((uint64_t ) offset);
  data = cpu_read(addr);
  lprintf(6, "pcie_csr_read(addr=0x%x)=0x%x\n",addr, data);
  return data;
}

// **********************************************************************************
// function used to read-write registers inside the PCIE config space (cfg0/cfg1) 
// or DMA CSR space.
// **********************************************************************************
uint64_t ret_pcie_mem_base(uint32_t pcie_core_id) {
  uint64_t SM_ADDR_MAP_PCIE_BASE;

  switch(pcie_core_id) {
    case 0: SM_ADDR_MAP_PCIE_BASE = SM_ADDR_MAP_PCIE0_BASE; 
            break;

    case 1: SM_ADDR_MAP_PCIE_BASE = SM_ADDR_MAP_PCIE1_BASE; 
            break;

    case 3: SM_ADDR_MAP_PCIE_BASE = SM_ADDR_MAP_PCIE3_BASE; 
            break;

    case 4: SM_ADDR_MAP_PCIE_BASE = SM_ADDR_MAP_PCIE4_BASE; 
            break;

    default: SM_ADDR_MAP_PCIE_BASE = SM_ADDR_MAP_PCIE2_BASE; 
            break;           
  }

  return SM_ADDR_MAP_PCIE_BASE;
}

uint64_t ret_ob_cfg_base(uint32_t pcie_core_id) {
  uint64_t SM_ADDR_MAP_PCIE_BASE;
  uint64_t SM_ADDR_MAP_PCIE_OB_CFG_BASE;

  SM_ADDR_MAP_PCIE_BASE = ret_pcie_mem_base(pcie_core_id);

  SM_ADDR_MAP_PCIE_OB_CFG_BASE = SM_ADDR_MAP_PCIE_BASE + PCIE_OB_CFG_OFFSET;

  return SM_ADDR_MAP_PCIE_OB_CFG_BASE;
}

uint64_t ret_ob_msg_base(uint32_t pcie_core_id) {
  uint64_t SM_ADDR_MAP_PCIE_BASE;
  uint64_t SM_ADDR_MAP_PCIE_OB_MSG_BASE;

  SM_ADDR_MAP_PCIE_BASE = ret_pcie_mem_base(pcie_core_id);

  SM_ADDR_MAP_PCIE_OB_MSG_BASE = SM_ADDR_MAP_PCIE_BASE + PCIE_OB_MSG_OFFSET;

  return SM_ADDR_MAP_PCIE_OB_MSG_BASE;
}

uint64_t ret_omr1_base(uint32_t pcie_core_id) {
  uint64_t SM_ADDR_MAP_PCIE_BASE;
  uint64_t SM_ADDR_MAP_PCIE_OMR1_BASE;

  SM_ADDR_MAP_PCIE_BASE = ret_pcie_mem_base(pcie_core_id);

  SM_ADDR_MAP_PCIE_OMR1_BASE = SM_ADDR_MAP_PCIE_BASE + PCIE_OMR1_OFFSET;

  return SM_ADDR_MAP_PCIE_OMR1_BASE;
}

uint64_t ret_omr2_base(uint32_t pcie_core_id) {
  uint64_t SM_ADDR_MAP_PCIE_BASE;
  uint64_t SM_ADDR_MAP_PCIE_OMR2_BASE;

  SM_ADDR_MAP_PCIE_BASE = ret_pcie_mem_base(pcie_core_id);

  SM_ADDR_MAP_PCIE_OMR2_BASE = SM_ADDR_MAP_PCIE_BASE + PCIE_OMR2_OFFSET;

  return SM_ADDR_MAP_PCIE_OMR2_BASE;
}

uint64_t ret_omr3_base(uint32_t pcie_core_id) {
  uint64_t SM_ADDR_MAP_PCIE_BASE;
  uint64_t SM_ADDR_MAP_PCIE_OMR3_BASE;

  SM_ADDR_MAP_PCIE_BASE = ret_pcie_mem_base(pcie_core_id);

  SM_ADDR_MAP_PCIE_OMR3_BASE = SM_ADDR_MAP_PCIE_BASE + PCIE_OMR3_OFFSET;

  return SM_ADDR_MAP_PCIE_OMR3_BASE;
}

void pcie_ob_cfg_write(uint32_t pcie_core_id, uint32_t offset, uint32_t data) {
  uint64_t addr; 
  uint64_t SM_ADDR_MAP_PCIE_OB_CFG_BASE;

  SM_ADDR_MAP_PCIE_OB_CFG_BASE = ret_ob_cfg_base(pcie_core_id);

  addr = SM_ADDR_MAP_PCIE_OB_CFG_BASE | ((uint64_t ) offset);

  cpu_write(addr, data);
// lprintf(5,"  PCIE OB CFG Write [0x%x] <= 0x%x \n", addr, data);
}  

int read_vendid(int argc, char *argv[]){
  uint32_t data, pcie_core_id, cnt, devid,class;

  if (argc < 1){
    lprintf(5,"not enough argument, pcie_id \n\r");
    return -1;
  } else {
    pcie_core_id = atoi(argv[0]);
  }
  sm_pcie_setup_ob_cfg(pcie_core_id, RC);             
  sm_pcie_setup_ob_space(pcie_core_id, RC); 
 
  //lprintf(5,"256 cfg read \n\r");
  for(cnt = 0; cnt < 256; cnt++) {
  devid = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR);
  class = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_CLASS__ADDR);
  }
  //lprintf(5,"PCI DEV/VEN ID %x \n\r", devid);
  //lprintf(5,"PCI CLASS %x \n\r", class);
}

static uint32_t called=0;
uint32_t pcie_ob_cfg_read(uint32_t pcie_core_id, uint32_t offset) {
  uint64_t addr; 
  uint64_t SM_ADDR_MAP_PCIE_OB_CFG_BASE;
  uint32_t data; 

  SM_ADDR_MAP_PCIE_OB_CFG_BASE = ret_ob_cfg_base(pcie_core_id);

  addr = SM_ADDR_MAP_PCIE_OB_CFG_BASE | ((uint64_t ) offset);
  
  if(!called)
  { 
    USDELAY(1);  // has effect-1
	called=1;
  }
  
  data = cpu_read(addr);

  //lprintf(5,"  PCIE OB CFG Read  [0x%x] => 0x%x, core_id=%d\n", addr, data, pcie_core_id);
  return data;
}

// **********************************************************************************
// function used to read-write registers inside the PCIE PHY
// **********************************************************************************
void pcie_phy_csr_write(uint32_t pcie_core_id, uint32_t addr, uint32_t data) {
  uint32_t cap_value;
  uint32_t ind_addr_cmd;

  ind_addr_cmd =(addr << FIELD_PCIE_SDS_IND_CMD_REG_CFG_IND_ADDR_SHIFT_MASK) | FIELD_PCIE_SDS_IND_CMD_REG_CFG_IND_WR_CMD_MASK; // Setting the wr bit in the ind_cmd register.
  ind_addr_cmd |= FIELD_PCIE_SDS_IND_CMD_REG_CFG_IND_CMD_DONE_MASK; // Clearing cmd_done flag for previous cmd.
   
  pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_IND_WDATA_REG__ADDR, data);
  pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_IND_CMD_REG__ADDR, ind_addr_cmd); // Write CMU_reg0 register

  do {
    cap_value = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_IND_CMD_REG__ADDR);
  } while((cap_value& FIELD_PCIE_SDS_IND_CMD_REG_CFG_IND_CMD_DONE_MASK) != FIELD_PCIE_SDS_IND_CMD_REG_CFG_IND_CMD_DONE_MASK);
  lprintf(6, "PHY CSR WRITE [0x%x] <= 0x%x \n", addr, data);
}  

uint32_t pcie_phy_csr_read(uint32_t pcie_core_id, uint32_t addr) {
  uint32_t cap_value;
  uint32_t ind_addr_cmd;
  uint32_t data;

  ind_addr_cmd =(addr << FIELD_PCIE_SDS_IND_CMD_REG_CFG_IND_ADDR_SHIFT_MASK) | FIELD_PCIE_SDS_IND_CMD_REG_CFG_IND_RD_CMD_MASK; // Setting the rd bit in the ind_cmd register.
  ind_addr_cmd |= FIELD_PCIE_SDS_IND_CMD_REG_CFG_IND_CMD_DONE_MASK; // Clearing cmd_done flag for previous cmd.
   
  pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_IND_CMD_REG__ADDR, ind_addr_cmd); // Write CMU_reg0 register

  do {
    cap_value = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_IND_CMD_REG__ADDR);
  } while((cap_value& FIELD_PCIE_SDS_IND_CMD_REG_CFG_IND_CMD_DONE_MASK) != FIELD_PCIE_SDS_IND_CMD_REG_CFG_IND_CMD_DONE_MASK);

  data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_IND_RDATA_REG__ADDR);
  lprintf(6, "PHY CSR READ [0x%x] => 0x%x \n", addr, data);
  return data;
}  
//

// **********************************************************************************
// function used to init ECC logic. 
// **********************************************************************************
void sm_pcie_init_ecc(uint32_t pcie_core_id) {
  uint32_t data;

  lprintf(5,"Inside function sm_pcie_init_ecc\n\r");

  pcie_csr_write(pcie_core_id, SM_GLBL_DIAG_CSR_CFG_MEM_RAM_SHUTDOWN__ADDR, 0);
  data = pcie_csr_read(pcie_core_id, SM_GLBL_DIAG_CSR_CFG_MEM_RAM_SHUTDOWN__ADDR);

  lprintf(5,"Data read from DIAG_MEM_RAM_SHUTDOWN register is "); putnum(data); lprintf(5,"\n\r");

  data = pcie_csr_read(pcie_core_id, SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY__ADDR);
  while (data != 0xFFFFFFFF) {
    data = pcie_csr_read(pcie_core_id, SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY__ADDR);
  } 
};

void set_ser_refclk(uint32_t pcie_core_id, uint32_t port_type, uint32_t ext_ref, uint32_t link_width) {
  uint32_t data;

  data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_CTL0__ADDR);
  // Reseting bit 12 of customer_pin_mode register.
  data = (data & 0xFFFFEFFF);
  data = data | 0x8;
  pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_CTL0__ADDR, data);

  if(ext_ref) {
    if(link_width == 8) {
      lprintf(5,"Selecting the external refclk for PCIEX8, requires additional programming of register inside SERDES at offset 0x0.\n\r");

      data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG0__ADDR);
      //Setting bit 13 of cmu reg 0 inside the SERDES, to select refclk from serdes 0.
      data = FIELD_CMU_REG0_PLL_REF_SEL_SET(data, 0x1);
      pcie_phy_csr_write(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG0__ADDR, data);
  
    }
  } else {
    clkmacro_cal(pcie_core_id);
    lprintf(5,"PLL lock achieved for CLK MACRO. Now, switching the refclk source.\n\r");
  //customer pin mode bit 12 is cleared due to PIPE bug, select REFCLK_CMOS_SEL using serdes register
   if(link_width == 8) {
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG1__ADDR);
    data = FIELD_CMU_REG1_REFCLK_CMOS_SEL_SET(data, 0x1);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG1__ADDR, data);
  
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG1__ADDR) ;
    data = FIELD_CMU_REG1_REFCLK_CMOS_SEL_SET(data, 0x1);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG1__ADDR, data);
   } else {
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG1__ADDR);
    data = FIELD_CMU_REG1_REFCLK_CMOS_SEL_SET(data, 0x1);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG1__ADDR, data);
   }
  }

/*
    data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_CTL0__ADDR);
    // Setting customer_pin_mode register field's bit 12 and setting bit 17 REFCLK_CMOS_SEL, will switch to internal refclk
    // mode.
    data = (data | FIELD_PCIE_SDS_CTL0_CFG_I_REFCLK_CMOS_SEL_MASK | 0x1000);
    pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_CTL0__ADDR, data);
  
  NOTT: need to check with KC on these
  lprintf(5,"Enabling the SSC for the SERDES\n\r");
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG36__ADDR);
  data |= FIELD_CMU_REG36_PLL_SSC_EN_MASK;
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG36__ADDR, data);

  if(link_width == 8) {
    lprintf(5,"Enabling the SSC for the SERDES2\n\r");
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG36__ADDR);
    data |= FIELD_CMU_REG36_PLL_SSC_EN_MASK;
    pcie_phy_csr_write(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG36__ADDR, data);
  }
*/
};  

void serdes_config_x1_fr_lpbk(uint32_t pcie_core_id) {
  uint32_t data;

  lprintf(5,"Enabling the tx-to-rx fwd loopback for X1 SERDES\n\r");
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG11__ADDR);
  data = FIELD_CH0_RXTX_REG11_PHASE_ADJUST_LIMIT_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG11__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR);
  data = FIELD_CH0_RXTX_REG4_TX_LOOPBACK_BUF_EN_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR);
  data = FIELD_CH0_RXTX_REG7_LOOP_BACK_ENA_CTLE_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR, data);
};  

void serdes_config_x4_fr_lpbk(uint32_t pcie_core_id) {
  uint32_t data;

  lprintf(5,"Enabling the tx-to-rx fwd loopback for X4 SERDES\n\r");
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG11__ADDR);
  data = FIELD_CH0_RXTX_REG11_PHASE_ADJUST_LIMIT_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG11__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR);
  data = FIELD_CH0_RXTX_REG4_TX_LOOPBACK_BUF_EN_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR);
  data = FIELD_CH0_RXTX_REG7_LOOP_BACK_ENA_CTLE_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH1_RXTX_REG11__ADDR);
  data = FIELD_CH1_RXTX_REG11_PHASE_ADJUST_LIMIT_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH1_RXTX_REG11__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH1_RXTX_REG4__ADDR);
  data = FIELD_CH1_RXTX_REG4_TX_LOOPBACK_BUF_EN_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH1_RXTX_REG4__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH1_RXTX_REG7__ADDR);
  data = FIELD_CH1_RXTX_REG7_LOOP_BACK_ENA_CTLE_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH1_RXTX_REG7__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH2_RXTX_REG11__ADDR);
  data = FIELD_CH2_RXTX_REG11_PHASE_ADJUST_LIMIT_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH2_RXTX_REG11__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH2_RXTX_REG4__ADDR);
  data = FIELD_CH2_RXTX_REG4_TX_LOOPBACK_BUF_EN_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH2_RXTX_REG4__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH2_RXTX_REG7__ADDR);
  data = FIELD_CH2_RXTX_REG7_LOOP_BACK_ENA_CTLE_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH2_RXTX_REG7__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH3_RXTX_REG11__ADDR);
  data = FIELD_CH3_RXTX_REG11_PHASE_ADJUST_LIMIT_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH3_RXTX_REG11__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH3_RXTX_REG4__ADDR);
  data = FIELD_CH3_RXTX_REG4_TX_LOOPBACK_BUF_EN_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH3_RXTX_REG4__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH3_RXTX_REG7__ADDR);
  data = FIELD_CH3_RXTX_REG7_LOOP_BACK_ENA_CTLE_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH3_RXTX_REG7__ADDR, data);  
};

void serdes2_config_x4_fr_lpbk(uint32_t pcie_core_id) {
  uint32_t data;

  lprintf(5,"Enabling the tx-to-rx fwd loopback for X4 SERDES2\n\r");
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH0_RXTX_REG11__ADDR);
  data = FIELD_CH0_RXTX_REG11_PHASE_ADJUST_LIMIT_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH0_RXTX_REG11__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR);
  data = FIELD_CH0_RXTX_REG4_TX_LOOPBACK_BUF_EN_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR);
  data = FIELD_CH0_RXTX_REG7_LOOP_BACK_ENA_CTLE_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH1_RXTX_REG11__ADDR);
  data = FIELD_CH1_RXTX_REG11_PHASE_ADJUST_LIMIT_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH1_RXTX_REG11__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH1_RXTX_REG4__ADDR);
  data = FIELD_CH1_RXTX_REG4_TX_LOOPBACK_BUF_EN_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH1_RXTX_REG4__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH1_RXTX_REG7__ADDR);
  data = FIELD_CH1_RXTX_REG7_LOOP_BACK_ENA_CTLE_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH1_RXTX_REG7__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH2_RXTX_REG11__ADDR);
  data = FIELD_CH2_RXTX_REG11_PHASE_ADJUST_LIMIT_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH2_RXTX_REG11__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH2_RXTX_REG4__ADDR);
  data = FIELD_CH2_RXTX_REG4_TX_LOOPBACK_BUF_EN_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH2_RXTX_REG4__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH2_RXTX_REG7__ADDR);
  data = FIELD_CH2_RXTX_REG7_LOOP_BACK_ENA_CTLE_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH2_RXTX_REG7__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH3_RXTX_REG11__ADDR);
  data = FIELD_CH3_RXTX_REG11_PHASE_ADJUST_LIMIT_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH3_RXTX_REG11__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH3_RXTX_REG4__ADDR);
  data = FIELD_CH3_RXTX_REG4_TX_LOOPBACK_BUF_EN_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH3_RXTX_REG4__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH3_RXTX_REG7__ADDR);
  data = FIELD_CH3_RXTX_REG7_LOOP_BACK_ENA_CTLE_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH3_RXTX_REG7__ADDR, data);  
};

void sm_pcie_init_phy(uint32_t pcie_core_id, uint32_t port_type, uint32_t gen, uint32_t ext_ref, uint32_t link_width, uint32_t en_lpbk){
  uint32_t data, i, j, full_width = 0;

  //set IO PAD for MDIO  address 'h17001398, data : 1e1e1e
#ifndef SIMULATION
  cpu_write(0x17001398, 0x1e1e1e);
#endif  

#ifdef SM_SOC_SIM
  set_ser_refclk(pcie_core_id, port_type, ext_ref, link_width);

#ifndef SIMULATION

  // First clear the TX_PARAMS_VALID bit of the PIPECTLREG.
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_PIPECTLREG__ADDR);
  data = FIELD_PIPECTLREG_PHY_EQ_TX_PARAMS_VALID_SET(data, 0);
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIPECTLREG__ADDR, data);

  //FS/LF adjustment from KC
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_PIPECTLREG__ADDR);
  data = FIELD_PIPECTLREG_PHY_EQ_TX_FS_SET(data, 0x36);   
  data = FIELD_PIPECTLREG_PHY_EQ_TX_LF_SET(data, 0x10);   
//   data = FIELD_PIPECTLREG_PHY_EQ_TX_FS_SET(data, 0x1F);  // Mellanix card req 
//  data = FIELD_PIPECTLREG_PHY_EQ_TX_LF_SET(data, 0x15);

  data = FIELD_PIPECTLREG_PHY_EQ_TX_MAX_PRE_SET(data, 0x6); 
  data = FIELD_PIPECTLREG_PHY_EQ_TX_MAX_POST_SET(data, 0xf);
  //data = FIELD_PIPECTLREG_PHY_EQ_TX_MAX_PRE_SET(data, 0x12); 
  //data = FIELD_PIPECTLREG_PHY_EQ_TX_MAX_POST_SET(data, 0xa);
  data = FIELD_PIPECTLREG_PHY_EQ_TX_PARAMS_VALID_SET(data, 1);
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIPECTLREG__ADDR, data);
  
  //customer pin mode setting
  data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_CTL0__ADDR);
  //turn off bit 12 to give control to serdes, to correct pll feedback value
  //turn off bit 2 and 3 to correct tx amplitue and cp1/cn1/cn2  value (130212)
  #ifdef SDS_TX_CTRL
    data = FIELD_PCIE_SDS_CTL0_CFG_I_CUSTOMER_PIN_MODE_SET(data, 0x0d29); 
  #else
    data = FIELD_PCIE_SDS_CTL0_CFG_I_CUSTOMER_PIN_MODE_SET(data, 0x0d2d);
  #endif
  pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_CTL0__ADDR, data);

  pipe_config(pcie_core_id);

  if (pcie_core_id == 2) {
    serdes_config_LSPLL(pcie_core_id, 0);  
    serdes_config_rx_control(pcie_core_id, 0, 0);
    serdes_config_tx_control(pcie_core_id, 0, 0, gen);
  } else {
    if (((pcie_core_id == 0) || (pcie_core_id == 3)) && (link_width == 8))
      full_width = 1;
    for (i=0;i<=full_width;i++) {
      serdes_config_LSPLL(pcie_core_id, i);
      for (j=0;j<=3;j++) {
        serdes_config_rx_control(pcie_core_id, j, i);
        serdes_config_tx_control(pcie_core_id, j, i, gen);
      }
    }
  }

#endif 

  if(en_lpbk) {
    switch (pcie_core_id) {
     case (0):  // X8 port, uses 2 X4 serdes
                serdes_config_x4_fr_lpbk(pcie_core_id);
                
                serdes2_config_x4_fr_lpbk(pcie_core_id);
               break;
     case (1):  // X4 port, uses 1 X4 serdes
                serdes_config_x4_fr_lpbk(pcie_core_id);
               break;
     case (2): // x1 port, use 1 x1 serdes 
                serdes_config_x1_fr_lpbk(pcie_core_id);
               break;
     case (3): // X8 port, uses 2 X4 serdes
                 serdes_config_x4_fr_lpbk(pcie_core_id);
                
                 serdes2_config_x4_fr_lpbk(pcie_core_id);
               break;
     case (4): // X4 port, uses 1 X4 serdes
                serdes_config_x4_fr_lpbk(pcie_core_id);
               break;
    }
  }
  
#endif 

  //vv 
    lprintf(5, "Equalization Control 0x%x \n\r",pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_63_32__ADDR));
   // data=  pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_63_32__ADDR);
   // data=FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_63_32_CFG_8G_CONSTANTS_EQ_PRESET_USE_COEF_SET(data); 
      
 
}

//force complaince pattern on port, used in tests
void force_cp_mode(int pcie_core_id) {
uint32_t data;
  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR);
  data = FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352_CFG_CONSTANTS_FORCE_COMPLIANCE_PATTERN_SET(data, 0x1);
  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR, data);
}

void clr_cp_mode(int pcie_core_id) {
uint32_t data;
  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR);
  data = FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352_CFG_CONSTANTS_FORCE_COMPLIANCE_PATTERN_SET(data, 0x0);
  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR, data);
}

//
int rev_loop(int argc, char *argv[]){
uint32_t data, pcie_core_id, ch, wordmode, rate;

if(argc < 4){
    lprintf(5,"not enugh argument, pcie_core_id, ch, wordmode, rate \n\r");
    return -1;
} else {
    pcie_core_id =  atoi(argv[0]);
    ch           =  atoi(argv[1]);
    wordmode     =  atoi(argv[2]);
    rate         =  atoi(argv[3]);
}
//wordmode 001: 10bit, 010 = 16bit, 011 = 20bit, 100 = 32 bit, 101 = 40bit, 110 = 64 bit 111 = 66bit
//datarate 00: full rate, 01 == half, 10 = quarter, 11 = fifth
//set customer invert to enable wordmode/rate control
data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG33__ADDR);
data = FIELD_CMU_REG33_CUSTOMER_MODE_INV_SET(data, 0x21);
pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG33__ADDR, data);

//customer pin mode setting
data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_CTL0__ADDR);
data = FIELD_PCIE_SDS_CTL0_CFG_I_CUSTOMER_PIN_MODE_SET(data, 0x0d28); 
pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_CTL0__ADDR, data);


//set wordmode and rate
data = pcie_phy_csr_read(pcie_core_id, (KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR + (0x200 * ch)));
data = FIELD_CH0_RXTX_REG4_TX_DATA_RATE_SET(data, rate);
data = FIELD_CH0_RXTX_REG4_TX_WORD_MODE_SET(data, wordmode);
pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR + (0x200 * ch), data);

data = pcie_phy_csr_read(pcie_core_id, (KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch)));
data = FIELD_CH0_RXTX_REG7_RX_DATA_RATE_SET(data, rate);
data = FIELD_CH0_RXTX_REG7_RX_WORD_MODE_SET(data, wordmode);
pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch), data);

data = pcie_phy_csr_read(pcie_core_id, (KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG8__ADDR + (0x200 * ch)));
data = FIELD_CH0_RXTX_REG8_RXTX_REV_PAR_LPBK_SET(data, 0x1);
pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG8__ADDR + (0x200 * ch), data);

}

int wait_pll_lock (uint32_t pcie_core_id, uint32_t full_width) {
  uint32_t data0, data1, pllrdy0, plllock0, vcocal0, vcofail0, vcofail0_bit0;
  uint32_t pllrdy1, plllock1, vcocal1, vcofail1, vcofail1_bit0, lock0, lock1 ;
  uint32_t count = 5;
  if (full_width) {
      do {
        data0 = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG7__ADDR);
        vcocal0 = FIELD_CMU_REG7_PLL_CALIB_DONE_RD(data0);
        vcofail0 = FIELD_CMU_REG7_VCO_CAL_FAIL_RD(data0) & 0x1;
        lock0 = vcocal0 && !vcofail0;
        
        data1 = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG7__ADDR + 0x30000);
        vcocal1 = FIELD_CMU_REG7_PLL_CALIB_DONE_RD(data1);
        vcofail1 = FIELD_CMU_REG7_VCO_CAL_FAIL_RD(data1) & 0x1;
        lock1 = vcocal1 && !vcofail1;
        
        lprintf(5,"Poll PLL lock on core 0x%x, serdes 0x%x, reg read data 0x%x \n\r", pcie_core_id, 0, data0);
        lprintf(5,"Poll PLL lock on core 0x%x, serdes 0x%x, reg read data 0x%x \n\r", pcie_core_id, 1, data1);
      } while (((lock0 && lock1) == 0)&&(--count != 0));
  } else {
      do {
        data0 = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG7__ADDR);
        vcocal0 = FIELD_CMU_REG7_PLL_CALIB_DONE_RD(data0);
        vcofail0 = FIELD_CMU_REG7_VCO_CAL_FAIL_RD(data0) & 0x1;
        lock0 = vcocal0 && !vcofail0;
        /*
        data0 = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS0_CMU_STATUS0__ADDR);
        plllock0 = FIELD_PCIE_SDS0_CMU_STATUS0_CFG_CMU_O_PLL_LOCK_RD(data0);
        pllrdy0  = FIELD_PCIE_SDS0_CMU_STATUS0_CFG_CMU_O_PLL_READY_RD(data0);
        vcocal0  = FIELD_PCIE_SDS0_CMU_STATUS0_CFG_CMU_O_VCO_CALDONE_RD(data0);
        lock0 = plllock0 && pllrdy0 && vcocal0;
        */
        lprintf(5,"Poll PLL lock on core 0x%x, reg read data 0x%x \n\r", pcie_core_id, data0);
      } while ((lock0 == 0)&&(--count != 0));
  }
  return count;
}

void pipe_config(uint32_t pcie_core_id){
uint32_t data, i,CN0,CP1,CN1,CN2;

  //increase receiver detect timeout window between serdes and PIPE
  data = pcie_phy_csr_read(pcie_core_id, KC_PIPE_REGS_RECEIVE_DETECT_CONTROL__ADDR);
  //data = FIELD_RECEIVE_DETECT_CONTROL_RX_PRES_ONE_CNT_TH_SET(data, 0x7d0);//4us max 
  //data = FIELD_RECEIVE_DETECT_CONTROL_RX_PRES_ONE_CNT_TH_SET(data, 0xbb8); //6us max
  data = FIELD_RECEIVE_DETECT_CONTROL_RX_PRES_ONE_CNT_TH_SET(data, 0xffff); //128us max value possible
  //data = FIELD_RECEIVE_DETECT_CONTROL_RX_PRES_ONE_CNT_TH_SET(data, 0x2710); //20us max value possible
  //data = FIELD_RECEIVE_DETECT_CONTROL_RX_PRES_ONE_CNT_TH_SET(data, 0x3e8); //2us max value possible, cause false detect
  pcie_phy_csr_write(pcie_core_id, KC_PIPE_REGS_RECEIVE_DETECT_CONTROL__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_PIPE_REGS_USB_PCIE_CTRL__ADDR);
  //data = FIELD_USB_PCIE_CTRL_RX_PRES_ONE_CNT_CMP_TH_SET(data, 0x10); //32ns min
  data = FIELD_USB_PCIE_CTRL_RX_PRES_ONE_CNT_CMP_TH_SET(data, 0x50); //100ns min
  //data = FIELD_USB_PCIE_CTRL_RX_PRES_ONE_CNT_CMP_TH_SET(data, 0x9); //18ns min, cause false detect
  pcie_phy_csr_write(pcie_core_id, KC_PIPE_REGS_USB_PCIE_CTRL__ADDR, data);

  for (i = 0; i<8; i++){
    //CDR SEL override
    data = pcie_phy_csr_read(pcie_core_id, KC_PIPE_REGS_SERDES_DFE_CONTROL0__ADDR + (i *4));
    data = FIELD_SERDES_DFE_CONTROL0_P2S_I_SPD_SEL_CDR_OVR_LN_SET(data, 0x7);
    pcie_phy_csr_write(pcie_core_id, KC_PIPE_REGS_SERDES_DFE_CONTROL0__ADDR + (i *4), data);
  }

  //increase tx amp, channel 0 bit location is different from rest of channels
  data = pcie_phy_csr_read(pcie_core_id, KC_PIPE_REGS_SERDES_CONTROL3__ADDR);
  data = FIELD_SERDES_CONTROL3_P2S_I_TX_AMP_EN_LN0_SET(data, 0x1);
  data = FIELD_SERDES_CONTROL3_P2S_I_TX_AMP_LN0_SET(data, 0xf);
  pcie_phy_csr_write(pcie_core_id, KC_PIPE_REGS_SERDES_CONTROL3__ADDR, data);

  for (i = 0; i<7; i++){
    //increase tx amp
    data = pcie_phy_csr_read(pcie_core_id, KC_PIPE_REGS_SERDES_CONTROL4__ADDR + (i *4));
    data = FIELD_SERDES_CONTROL4_P2S_I_TX_AMP_EN_LN1_SET(data, 0x1);
    data = FIELD_SERDES_CONTROL4_P2S_I_TX_AMP_LN1_SET(data, 0xf);
    pcie_phy_csr_write(pcie_core_id, KC_PIPE_REGS_SERDES_CONTROL4__ADDR + (i *4) , data);
  }

  //daniel: 130830 added to remove SD glitch
  data = pcie_phy_csr_read(pcie_core_id, KC_PIPE_REGS_LOS_PARAM__ADDR);
  data = FIELD_LOS_PARAM_TH_CNTON_GEN12_SET(data, 0xf);
  data = FIELD_LOS_PARAM_TH_CNTOFF_GEN12_SET(data, 0x8);
  data = FIELD_LOS_PARAM_TH_CNTON_GEN3_SET(data, 0xf);
  data = FIELD_LOS_PARAM_TH_CNTOFF_GEN3_SET(data, 0x8);
  pcie_phy_csr_write(pcie_core_id, KC_PIPE_REGS_LOS_PARAM__ADDR, data);
  
  //A2 specific fix
  //undocumented PIPE register, used for GEN1/GEN2 TX coefficient override
 // pcie_phy_csr_write(pcie_core_id, (0x10000 | 0x0c), 0x2c0); 

  //EBUF setting change
  data = pcie_phy_csr_read(pcie_core_id,  KC_PIPE_REGS_EFIFO_CONTROL0__ADDR);
  if(pcie_core_id == 2)
    data = FIELD_EFIFO_CONTROL0_BUF_DEPTH_PCI_SET(data, 0xf);                       // BUG_41872
  else
    data = FIELD_EFIFO_CONTROL0_BUF_DEPTH_PCI_SET(data, 0x10);                       // BUG_41872
  pcie_phy_csr_write(pcie_core_id, KC_PIPE_REGS_EFIFO_CONTROL0__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_PIPE_REGS_PIPE_CONTROL__ADDR);
  data = FIELD_PIPE_CONTROL_WMSELECT_SET(data, 0x6);
  pcie_phy_csr_write(pcie_core_id, KC_PIPE_REGS_PIPE_CONTROL__ADDR, data);
  
  // Specific to intermediate SLT Release done for Gen1 3.5dB de-emphasis
  pcie_phy_csr_write(pcie_core_id, (0x10000 | 0x0c), 0x0240); //0x0,0x9,0x0  : Gen1 x8 
  data = pcie_phy_csr_read(pcie_core_id, 0x1000c); 
  CN0  = data       & 0x3f;
  CP1  = (data>>6)  & 0x3f;
  CN1  = (data>>12) & 0x3f;

//CN2 setting
  data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_MISC_CTL__ADDR);
  data = FIELD_PCIE_SDS_MISC_CTL_CFG_I_TX_CN2_SET(data, 0x0); 
  pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_MISC_CTL__ADDR, data);
}

void serdes_config_LSPLL(uint32_t pcie_core_id, uint32_t sds2){
  uint32_t data, sds2_offset;
  lprintf(5,"Serdes PLL config, core 0x%x, serdes# 0x%x \n\r", pcie_core_id, sds2);
  if (sds2){
    sds2_offset = 0x30000;
  } else {
    sds2_offset = 0x0;
  }
  
  //pciegen3 control from PIPE is turned Off
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG0__ADDR + sds2_offset);
  data = FIELD_CMU_REG0_PCIEGEN3_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG0__ADDR + sds2_offset, data);
 
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG1__ADDR + sds2_offset);
  data = FIELD_CMU_REG1_PLL_CP_SET(data, 0xf);
  data = FIELD_CMU_REG1_PLL_CP_SEL_SET(data, 0xc);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG1__ADDR + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG3__ADDR + sds2_offset);
  data = FIELD_CMU_REG3_VCOVARSEL_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG3__ADDR + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG2__ADDR + sds2_offset);
  #ifdef REF_DIVIDE2
  data = FIELD_CMU_REG2_PLL_REFDIV_SET(data, 0x1); //divide referenc clock by 2
  data = FIELD_CMU_REG2_PLL_LFRES_SET(data, 0x2);
  data = FIELD_CMU_REG2_PLL_FBDIV_SET(data, 0x63); //adjust feedback to new reference clock
  #else
  data = FIELD_CMU_REG2_PLL_LFRES_SET(data, 0x2);
  data = FIELD_CMU_REG2_PLL_FBDIV_SET(data, 0x31); //control off from PIPE
  #endif
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG2__ADDR + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG5__ADDR + sds2_offset);
  data = FIELD_CMU_REG5_PLL_LFCAP_SET(data, 0);
  data = FIELD_CMU_REG5_PLL_LFSMCAP_SET(data, 0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG5__ADDR + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG4__ADDR + sds2_offset);
  data = FIELD_CMU_REG4_VCOVARSEL_PCIE_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG4__ADDR + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG32__ADDR + sds2_offset);
  data = FIELD_CMU_REG32_IREF_ADJ_SET(data, 0x3);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG32__ADDR + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG1__ADDR + sds2_offset);
  data = FIELD_CMU_REG1_PLL_MANUALCAL_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG1__ADDR + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG3__ADDR + sds2_offset);
  data = FIELD_CMU_REG3_VCO_MOMSEL_INIT_SET(data, 0x10);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG3__ADDR + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG4__ADDR + sds2_offset);
  data = FIELD_CMU_REG4_VCO_MOMSEL_INIT_PCIE_SET(data, 0x10);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG4__ADDR + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG34__ADDR + sds2_offset);
  data = FIELD_CMU_REG34_VCO_CAL_VTH_HI_MIN_SET(data, 0x2);
  data = FIELD_CMU_REG34_VCO_CAL_VTH_HI_MAX_SET(data, 0xa);
  data = FIELD_CMU_REG34_VCO_CAL_VTH_LO_MIN_SET(data, 0x2);
  data = FIELD_CMU_REG34_VCO_CAL_VTH_LO_MAX_SET(data, 0xa);
 /* 131031: Anil suggested this value, but it makes working part not work with these change
  data = FIELD_CMU_REG34_VCO_CAL_VTH_HI_MIN_SET(data, 0x8);
  data = FIELD_CMU_REG34_VCO_CAL_VTH_HI_MAX_SET(data, 0xb);
  data = FIELD_CMU_REG34_VCO_CAL_VTH_LO_MAX_SET(data, 0x7);
  */
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG34__ADDR + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG0__ADDR + sds2_offset);
  data = FIELD_CMU_REG0_CAL_COUNT_RESOL_SET(data, 0x7); //pll lock calibration
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG0__ADDR + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG16__ADDR + sds2_offset);
  data = FIELD_CMU_REG16_VCOCAL_WAIT_BTW_CODE_SET(data, 0x7); //VCO Calb wait time
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG16__ADDR + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG30__ADDR + sds2_offset);
  #ifdef REF_DIVIDE2_GEN3
  data = FIELD_CMU_REG30_PLL_REFDIV_GEN3_SET(data, 0x1); //divide refence clock by 2
  data = FIELD_CMU_REG30_LOCK_COUNT_SET(data, 0x3); //Lock count wait time
  data = FIELD_CMU_REG30_PLL_FBDIV_GEN3_SET(data, 0x4f);  //increase feedback divider for reduced reference clock
  #else
  data = FIELD_CMU_REG30_LOCK_COUNT_SET(data, 0x3); //Lock count wait time
  data = FIELD_CMU_REG30_PLL_FBDIV_GEN3_SET(data, 0x27);  //control turn off from PIPE
  #endif
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG30__ADDR + sds2_offset, data);

  //rate change delay setting
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG12__ADDR + sds2_offset);
  data = FIELD_CMU_REG12_STATE_DELAY9_SET(data, 0x2);  //ready_count top
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG12__ADDR + sds2_offset, data);
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG12__ADDR + sds2_offset);
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG13__ADDR + sds2_offset);
    
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG13__ADDR + sds2_offset);
  data = FIELD_CMU_REG13_STATE_DELAY1_SET(data, 0xf); //calib_start_count_stop
  data = FIELD_CMU_REG13_STATE_DELAY2_SET(data, 0x2);//channel_start_count_stop
  data = FIELD_CMU_REG13_STATE_DELAY3_SET(data, 0xd);//reset_count_stop
  data = FIELD_CMU_REG13_STATE_DELAY4_SET(data, 0xb);//start_ctle_cal_count
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG13__ADDR + sds2_offset, data);
  
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG14__ADDR + sds2_offset);
  data = FIELD_CMU_REG14_STATE_DELAY5_SET(data, 0x2); //float_tap_src_ena_count_stop
  data = FIELD_CMU_REG14_STATE_DELAY6_SET(data, 0x2); //float_tap_src_count_stop
  data = FIELD_CMU_REG14_STATE_DELAY7_SET(data, 0x7); //blwc_ena_count_stop
  data = FIELD_CMU_REG14_STATE_DELAY8_SET(data, 0xa); //ready_count_stop
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG14__ADDR + sds2_offset, data);
  //delay value encoding
  //4'hf:  // 2.56 ms (assume 10ns clock)
  //4'he:  // 1.28 ms
  //4'hd:  // 640us
  //4'hc:  // 320us
  //4'hb:  // 160us
  //4'ha:  // 80us
  //4'h9:  // 40us
  //4'h8:  // 20us
  //4'h7:  // 10us
  //4'h6:  // 5.12us
  //4'h5:  // 2.56us
  //4'h4:  // 1.28us
  //4'h3:  // 640ns
  //4'h2:  // 320ns
  //4'h1:  // 160ns
  //4'h0:  // 80ns
  ////////////////////////////////////////////////////////////////////////////////////
  
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG32__ADDR + sds2_offset);
  data = FIELD_CMU_REG32_PVT_CAL_WAIT_SEL_SET(data, 0x3);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG32__ADDR + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG31__ADDR + sds2_offset);
  data = FIELD_CMU_REG31_LOS_OVERRIDE_CH3_SET(data, 0x1);
  data = FIELD_CMU_REG31_LOS_OVERRIDE_CH2_SET(data, 0x1);
  data = FIELD_CMU_REG31_LOS_OVERRIDE_CH1_SET(data, 0x1);
  data = FIELD_CMU_REG31_LOS_OVERRIDE_CH0_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG31__ADDR + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG37__ADDR + sds2_offset);
  data = FIELD_CMU_REG37_CTLE_CAL_DONE_OVR_SET(data, 0xf);
  data = FIELD_CMU_REG37_FT_SEARCH_DONE_OVR_SET(data, 0xf);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG37__ADDR + sds2_offset, data);

  //PVT reference of 50 Ohm
 data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG27__ADDR + sds2_offset);
 data = FIELD_CMU_REG27_REF_VOLT_SEL_CH0_SET(data, 0x2);
 data = FIELD_CMU_REG27_REF_VOLT_SEL_CH1_SET(data, 0x2);
 data = FIELD_CMU_REG27_REF_VOLT_SEL_CH2_SET(data, 0x2);
 data = FIELD_CMU_REG27_REF_VOLT_SEL_CH3_SET(data, 0x2);
 pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG27__ADDR + sds2_offset, data);
 
}

//set 3 phy parameters to adjust the eye, use 2,15,5 for gen3 else 2,15,0
int set_cp(int argc, char *argv[]){
  uint32_t data, cn2, cp1, cn1, pcie_core_id, ch, sds2, sds2_offset;

  if (argc < 5){
    lprintf(5,"not enough argument, pcie_id, ch, cp1, cn1, cn2 \n\r");
    return -1;
  } else {
    pcie_core_id = atoi(argv[0]);
    ch = atoi(argv[1]);
    cp1  = atoi(argv[2]);
    cn1  = atoi(argv[3]);
    cn2  = atoi(argv[4]);
  }

  if (ch > 4){
    sds2_offset = 0x30000;
  } else {
    sds2_offset = 0x0;
  }

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG5__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG5_TX_CN2_SET(data, cn2);
  data = FIELD_CH0_RXTX_REG5_TX_CP1_SET(data, cp1);
  data = FIELD_CH0_RXTX_REG5_TX_CN1_SET(data, cn1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG5__ADDR + (0x200 * ch) + sds2_offset, data);
}

int set_pipe_cp(int argc, char *argv[]){
  uint32_t data, c0, cp1, cm1, pcie_core_id;

  if (argc < 4){
    lprintf(3,"not enough argument, pcie_id, c0, cp1, cm1 \n\r");
    return -1;
  } else {
    pcie_core_id = atoi(argv[0]);
    c0  = atoi(argv[2]);
    cp1  = atoi(argv[3]);
    cm1  = atoi(argv[4]);
  }

  data = c0;
  data = cp1 << 6 | data;
  data = cm1 << 12 | data;
  pcie_phy_csr_write(pcie_core_id, (0x10000 | 0x0c), data);
  data = pcie_phy_csr_read(pcie_core_id, (0x10000 | 0x0c));
  lprintf(5,"pipe read data addr 0x1000c, data 0x%x \n\r", data);
}


void serdes_config_tx_control(uint32_t pcie_core_id, uint32_t ch, uint32_t sds2, uint32_t gen) {
  int data, sds2_offset;

  //TX control
  //lprintf(5,"Serdes TX config, core 0x%x, channel# 0x%x, serdes# 0x%x \n\r", pcie_core_id, ch, sds2);
  if (sds2){
    sds2_offset = 0x30000;
  } else {
    sds2_offset = 0x0;
  }

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG2_TX_FIFO_ENA_SET(data, 0x1);
  data = FIELD_CH0_RXTX_REG2_RESETB_TXD_SET(data, 0x1);
  data = FIELD_CH0_RXTX_REG2_BIST_ENA_TX_SET(data, 0x0);
  data = FIELD_CH0_RXTX_REG2_TX_INV_SET(data, 0x0);
  data = FIELD_CH0_RXTX_REG2_TX_RCVDET_SEL_SET(data , 3); //20130732: receiver detect change
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset, data);

  //130212
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG6__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG6_TXAMP_ENA_SET(data, 0x1);
  data = FIELD_CH0_RXTX_REG6_TXAMP_CNTL_SET(data, 0xf);
  data = FIELD_CH0_RXTX_REG6_TX_IDLE_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG6__ADDR + (0x200 * ch) + sds2_offset, data);

  //130212
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG5__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG5_TX_CN2_SET(data, 0x2);  //130307, value of 2 better for gen3 and good enough for gen2
  data = FIELD_CH0_RXTX_REG5_TX_CP1_SET(data, 0xf);
  data = FIELD_CH0_RXTX_REG5_TX_CN1_SET(data, 0x2);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG5__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG4_TX_LOOPBACK_BUF_EN_SET(data, 0x0);
  data = FIELD_CH0_RXTX_REG4_COUNTER_TIME_SEL_CP_SET(data, 0x7); //140626: BCA ack timerout counter
  data = FIELD_CH0_RXTX_REG4_COUNTER_TIME_SEL_CN_SET(data, 0x7);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG145__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG145_TX_IDLE_SATA_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG145__ADDR + (0x200 * ch) + sds2_offset, data);

}

void serdes_config_rx_control(uint32_t pcie_core_id, uint32_t ch, uint32_t sds2) {
  uint32_t data, sds2_offset;

  //lprintf(5,"Serdes RX config, core 0x%x, channel# 0x%x, serdes# 0x%x \n\r", pcie_core_id, ch, sds2);
  if (sds2){
    sds2_offset = 0x30000;
  } else {
    sds2_offset = 0x0;
  }
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG147__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG147_STMC_OVERRIDE_SET(data, 0x6);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG147__ADDR + (0x200 * ch) + sds2_offset, data);

  //important: this is workaound for lack of reset after power state change bug
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG27__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG27_RXPD_CONFIG_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG27__ADDR + (0x200 * ch) + sds2_offset, data);

  //enable eye scan latch calibration
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG145__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG145_RXVWES_LATENA_SET(data, 1);
  data = FIELD_CH0_RXTX_REG145_RXES_ENA_SET(data, 1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG145__ADDR + (0x200 * ch) + sds2_offset, data);

  //RX control
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG2_RESETB_TERM_SET(data, 0x0);  // is this correct ???
  data = FIELD_CH0_RXTX_REG2_VTT_ENA_SET(data, 0x1);
  data = FIELD_CH0_RXTX_REG2_VTT_SEL_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG1__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG1_RXACVCM_SET(data, 0x7);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG1__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG12_RX_DET_TERM_ENABLE_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG148__ADDR + (0x200 * ch) + sds2_offset);
  data = 0xffff; //rx bist word count 0 
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG148__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG149__ADDR + (0x200 * ch) + sds2_offset);
  data = 0xffff; //rx bist word count 1 
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG149__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG150__ADDR + (0x200 * ch) + sds2_offset);
  data = 0xffff; //rx bist word count 2 
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG150__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG151__ADDR + (0x200 * ch) + sds2_offset);
  data = 0xffff; //rx bist word count 3 
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG151__ADDR + (0x200 * ch) + sds2_offset, data);


  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG1__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG1_CTLE_EQ_SET(data, CTLE_EQ);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG1__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG0__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG0_CTLE_EQ_FR_SET(data, 0x1c);
  data = FIELD_CH0_RXTX_REG0_CTLE_EQ_QR_SET(data, 0x1c);
  data = FIELD_CH0_RXTX_REG0_CTLE_EQ_HR_SET(data, 0x1c);
pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG0__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG12_LATCH_OFF_ENA_SET(data, 0x1);
pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG128__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG128_LATCH_CAL_WAIT_SEL_SET(data, 0x3);
pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG128__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG8__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG8_CDR_LOOP_ENA_SET(data, 0x1);
  data = FIELD_CH0_RXTX_REG8_CDR_BYPASS_RXLOS_SET(data, 0x0);
  data = FIELD_CH0_RXTX_REG8_SD_VREF_SET(data, 0x4); //130830, added to remove SD glitch
pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG8__ADDR + (0x200 * ch) + sds2_offset, data);

//controlled by PIPE
//data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset);
//data = FIELD_CH0_RXTX_REG61_SPD_SEL_CDR_SET(data, 0x7);
//pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG125__ADDR + (0x200 * ch) + sds2_offset);
  //data = FIELD_CH0_RXTX_REG125_PQ_REG_SET(data, 0xa);
  data = FIELD_CH0_RXTX_REG125_PQ_REG_SET(data, PQ);  //140624: bertscope receiver test shows 0x11 is best result
  data = FIELD_CH0_RXTX_REG125_PHZ_MANUAL_SET(data, 0x1);
pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG125__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG11__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG11_PHASE_ADJUST_LIMIT_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG11__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset);
  #ifdef RX_SSC_ENB
    data = FIELD_CH0_RXTX_REG61_LOADFREQ_SHIFT_SET(data, 0x0);
  #else 
    data = FIELD_CH0_RXTX_REG61_LOADFREQ_SHIFT_SET(data, 0x1);
  #endif
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG102__ADDR + (0x200 * ch) + sds2_offset);
  #ifdef RX_SSC_ENB
    data = FIELD_CH0_RXTX_REG102_FREQLOOP_LIMIT_SET(data, 0x0);
  #else
    data = FIELD_CH0_RXTX_REG102_FREQLOOP_LIMIT_SET(data, 0x3);
  #endif
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG102__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG8__ADDR + (0x200 * ch) + sds2_offset);
  #ifdef RX_SSC_ENB
    data = FIELD_CH0_RXTX_REG8_SSC_ENABLE_SET(data, 0x1);
  #else
    data = FIELD_CH0_RXTX_REG8_SSC_ENABLE_SET(data, 0x0);
  #endif
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG8__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG96__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG96_MU_FREQ1_SET(data, 0x10);
  data = FIELD_CH0_RXTX_REG96_MU_FREQ2_SET(data, 0x10);
  data = FIELD_CH0_RXTX_REG96_MU_FREQ3_SET(data, 0x10);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG96__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG97__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG97_MU_FREQ4_SET(data, 0x10);
  data = FIELD_CH0_RXTX_REG97_MU_FREQ5_SET(data, 0x10);
  data = FIELD_CH0_RXTX_REG97_MU_FREQ6_SET(data, 0x10);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG97__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG98__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG98_MU_FREQ7_SET(data, 0x10);
  data = FIELD_CH0_RXTX_REG98_MU_FREQ8_SET(data, 0x10);
  data = FIELD_CH0_RXTX_REG98_MU_FREQ9_SET(data, 0x10);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG98__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG99__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG99_MU_PHASE1_SET(data, 0x6); 
  data = FIELD_CH0_RXTX_REG99_MU_PHASE2_SET(data, 0x6); 
  data = FIELD_CH0_RXTX_REG99_MU_PHASE3_SET(data, 0x6);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG99__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG100__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG100_MU_PHASE4_SET(data, 0x6);
  data = FIELD_CH0_RXTX_REG100_MU_PHASE5_SET(data, 0x6);
  data = FIELD_CH0_RXTX_REG100_MU_PHASE6_SET(data, 0x6);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG100__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG101__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG101_MU_PHASE7_SET(data, 0x6);
  data = FIELD_CH0_RXTX_REG101_MU_PHASE8_SET(data, 0x6);
  data = FIELD_CH0_RXTX_REG101_MU_PHASE9_SET(data, 0x6);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG101__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG8__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG8_SD_DISABLE_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG8__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG26__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG26_BLWC_ENA_SET(data, 0x1); 
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG26__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG81__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG81_MU_DFE1_SET(data, 0xe);  //these are 0x6 for gen3
  data = FIELD_CH0_RXTX_REG81_MU_DFE2_SET(data, 0xe);
  data = FIELD_CH0_RXTX_REG81_MU_DFE3_SET(data, 0xe);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG81__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG82__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG82_MU_DFE4_SET(data, 0xe);  //these are 0x6 for gen3
  data = FIELD_CH0_RXTX_REG82_MU_DFE5_SET(data, 0xe);
  data = FIELD_CH0_RXTX_REG82_MU_DFE6_SET(data, 0xe);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG82__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG83__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG83_MU_DFE7_SET(data, 0xe); //these are 0x6 for gen3
  data = FIELD_CH0_RXTX_REG83_MU_DFE8_SET(data, 0xe);
  data = FIELD_CH0_RXTX_REG83_MU_DFE9_SET(data, 0xe);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG83__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG84__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG84_MU_PH1_SET(data, 0xe); //these are 0x6 for gen3
  data = FIELD_CH0_RXTX_REG84_MU_PH2_SET(data, 0xe);
  data = FIELD_CH0_RXTX_REG84_MU_PH3_SET(data, 0xe);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG84__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG85__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG85_MU_PH4_SET(data, 0xe);//these are 0x6 for gen3
  data = FIELD_CH0_RXTX_REG85_MU_PH5_SET(data, 0xe);
  data = FIELD_CH0_RXTX_REG85_MU_PH6_SET(data, 0xe);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG85__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG86__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG86_MU_PH7_SET(data, 0xe);//these are 0x6 for gen3
  data = FIELD_CH0_RXTX_REG86_MU_PH8_SET(data, 0xe);
  data = FIELD_CH0_RXTX_REG86_MU_PH9_SET(data, 0xe);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG86__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG87__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG87_MU_TH1_SET(data, 0xe);//these are 0x6 for gen3
  data = FIELD_CH0_RXTX_REG87_MU_TH2_SET(data, 0xe);
  data = FIELD_CH0_RXTX_REG87_MU_TH3_SET(data, 0xe);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG87__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG88__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG88_MU_TH4_SET(data, 0xe);//these are 0x6 for gen3
  data = FIELD_CH0_RXTX_REG88_MU_TH5_SET(data, 0xe);
  data = FIELD_CH0_RXTX_REG88_MU_TH6_SET(data, 0xe);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG88__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG89__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG89_MU_TH7_SET(data, 0xe);//these are 0x6 for gen3
  data = FIELD_CH0_RXTX_REG89_MU_TH8_SET(data, 0xe);
  data = FIELD_CH0_RXTX_REG89_MU_TH9_SET(data, 0xe);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG89__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG90__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG90_MU_BCA1_SET(data, 0xb);
  data = FIELD_CH0_RXTX_REG90_MU_BCA2_SET(data, 0xb);
  data = FIELD_CH0_RXTX_REG90_MU_BCA3_SET(data, 0xb);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG90__ADDR + (0x200 * ch) + sds2_offset, data);
  
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG91__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG91_MU_BCA4_SET(data, 0xb);
  data = FIELD_CH0_RXTX_REG91_MU_BCA5_SET(data, 0xb);
  data = FIELD_CH0_RXTX_REG91_MU_BCA6_SET(data, 0xb);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG91__ADDR + (0x200 * ch) + sds2_offset, data);
  
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG92__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG92_MU_BCA7_SET(data, 0xb);
  data = FIELD_CH0_RXTX_REG92_MU_BCA8_SET(data, 0xb);
  data = FIELD_CH0_RXTX_REG92_MU_BCA9_SET(data, 0xb);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG92__ADDR + (0x200 * ch) + sds2_offset, data);


  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG145__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG145_RXDFE_CONFIG_SET(data, 0x3);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG145__ADDR + (0x200 * ch) + sds2_offset, data);

  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG28__ADDR + (0x200 * ch) + sds2_offset, RXDFE);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG7_RESETB_RXD_SET(data, 0x1);
  data = FIELD_CH0_RXTX_REG7_LOOP_BACK_ENA_CTLE_SET(data, 0x0);
  data = FIELD_CH0_RXTX_REG7_BIST_ENA_RX_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG12_RX_INV_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + sds2_offset, data);
}

void manual_cal(uint32_t pcie_core_id, uint32_t link_width){
uint32_t data, i, momsel_gen3, momsel, ref_2_gen3, ref_2_gen1;
uint64_t temp;
    #ifdef REF_DIVIDE2
     ref_2_gen1 = 1;
    #else
     ref_2_gen1 = 0;
    #endif 

    #ifdef REF_DIVIDE2_GEN3
     ref_2_gen3 = 1;
    #else
     ref_2_gen3 = 0;
    #endif 

    #ifdef MOMSEL_AUTO
    momsel = get_momsel(pcie_core_id, 0, 0, ref_2_gen1);
    momsel_gen3 = get_momsel(pcie_core_id, 0, 1, ref_2_gen3);
    lprintf(5,"MOMSEL 0x%x, MOMSEL_PCIE 0x%x, pcie_core_id 0x%x, serdes 0 \n\r", momsel, momsel_gen3, pcie_core_id);
    #else
    momsel = 0xa;
    //momsel_pcie = 0x1b;
    momsel_gen3 = 0x19;
    #endif

   // lprintf(5,"pcie_core_id 0x%x,PLL manual calibration on serdes 0 \n\r", pcie_core_id);
    //PLL manual calibration
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG4__ADDR);
    data = FIELD_CMU_REG4_VCO_MANMOMSEL_PCIE_SET(data, momsel_gen3);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG4__ADDR, data);

    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG3__ADDR);
    data = FIELD_CMU_REG3_VCO_MANMOMSEL_SET(data, momsel);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG3__ADDR, data);
    
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG1__ADDR);
    data = FIELD_CMU_REG1_PLL_MANUALCAL_SET(data, 0x1);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG1__ADDR, data);
    
    if (link_width == 8){
        #ifdef MOMSEL_AUTO
        momsel = get_momsel(pcie_core_id, 1, 0, ref_2_gen1);
        momsel_gen3 = get_momsel(pcie_core_id, 1, 1, ref_2_gen3);
        lprintf(5,"MOMSEL 0x%x, MOMSEL_8G 0x%x, pcie_core_id 0x%x, serdes 1 \n\r", momsel, momsel_gen3, pcie_core_id);
        #endif
        
       // lprintf(5,"pcie_core_id 0x%x,PLL manual calibration on serdes 1 \n\r", pcie_core_id);
        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG4__ADDR);
        data = FIELD_CMU_REG4_VCO_MANMOMSEL_PCIE_SET(data, momsel_gen3);
        pcie_phy_csr_write(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG4__ADDR, data);

        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG3__ADDR);
        data = FIELD_CMU_REG3_VCO_MANMOMSEL_SET(data, momsel);
        pcie_phy_csr_write(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG3__ADDR, data);
        
        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG1__ADDR);
        data = FIELD_CMU_REG1_PLL_MANUALCAL_SET(data, 0x1);
        pcie_phy_csr_write(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG1__ADDR, data);

    }

#ifdef manual_PVT
    lprintf(5,"pcie_core_id 0x%x, PVT manual calibration on serdes 0 \n\r", pcie_core_id);
    //pvt manual calibration
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG6__ADDR);
    data = FIELD_CMU_REG6_PLL_VREGTRIM_SET(data, 0x0);
    data = FIELD_CMU_REG6_MAN_PVT_CAL_SET(data, 0x1);  //130207
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG6__ADDR, data);
    
    if (link_width == 8) {
        lprintf(5,"pcie_core_id 0x%x, PVT manual calibration on serdes 1 \n\r", pcie_core_id);
        //pvt manual calibration
        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG6__ADDR);
        data = FIELD_CMU_REG6_PLL_VREGTRIM_SET(data, 0x0);
        data = FIELD_CMU_REG6_MAN_PVT_CAL_SET(data, 0x1);  //130207
        pcie_phy_csr_write(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG6__ADDR, data);
    }

    //130207
    for (i = 0; i < 4; i++){
    lprintf(5,"pcie_core_id 0x%x, termination calibration channel select 0x%x, serdes 0  \n\r", pcie_core_id, i);
    //termination calibration
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG17__ADDR);
    data = FIELD_CMU_REG17_RESERVED_7_SET(data, i);  //need to get updated spec from KC
    pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG17__ADDR, data);
 
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG17__ADDR);
    data = FIELD_CMU_REG17_PVT_CODE_R2A_SET(data, 0x12);
    data = FIELD_CMU_REG17_PVT_TERM_MAN_ENA_SET(data, 0x1);
    pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG17__ADDR, data);
 
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG17__ADDR);
    data = FIELD_CMU_REG17_PVT_TERM_MAN_ENA_SET(data, 0x0);
    pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG17__ADDR, data);
   
    //up calibration cause receiver detect problem
    lprintf(5,"pcie_core_id 0x%x, up calibration channel select 0x%x, serdes 0  \n\r", pcie_core_id, i);
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG17__ADDR);
    data = FIELD_CMU_REG17_RESERVED_7_SET(data, i);
    pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG17__ADDR, data);

    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG17__ADDR);
    data = FIELD_CMU_REG17_PVT_CODE_R2A_SET(data, 0x29);   
    //data = FIELD_CMU_REG17_PVT_CODE_R2A_SET(data, 0x1);   
    pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG17__ADDR , data);

    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG16__ADDR );
    data = FIELD_CMU_REG16_PVT_UP_MAN_ENA_SET (data, 0x1);
    pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG16__ADDR , data);

    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG16__ADDR );
    data = FIELD_CMU_REG16_PVT_UP_MAN_ENA_SET (data, 0x0);
    pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG16__ADDR , data);
    
    lprintf(5,"pcie_core_id 0x%x, down calibration channel select 0x%x, serdes 0  \n\r", pcie_core_id, i);
    //down calibration
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG17__ADDR );
    data = FIELD_CMU_REG17_RESERVED_7_SET(data, i);
    pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG17__ADDR , data);
 
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG17__ADDR );
    //data = FIELD_CMU_REG17_PVT_CODE_R2A_SET(data, 0x29);
    data = FIELD_CMU_REG17_PVT_CODE_R2A_SET(data, 0x29);
    pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG17__ADDR , data);
 
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG16__ADDR );
    data = FIELD_CMU_REG16_PVT_DN_MAN_ENA_SET(data, 0x1);
    pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG16__ADDR , data);
 
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG16__ADDR );
    data = FIELD_CMU_REG16_PVT_DN_MAN_ENA_SET(data, 0x0);
    pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG16__ADDR , data);
    }

    if (link_width == 8) {
        for (i = 0; i < 4; i++){
        lprintf(5,"pcie_core_id 0x%x, termination calibration channel select 0x%x, serdes 1  \n\r", pcie_core_id, i);
        //termination calibration
        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG17__ADDR);
        data = FIELD_CMU_REG17_RESERVED_7_SET(data, i);  //need to get updated spec from KC
        pcie_phy_csr_write(pcie_core_id,  KC_SERDES2_CMU_REGS_CMU_REG17__ADDR, data);
 
        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG17__ADDR);
        data = FIELD_CMU_REG17_PVT_CODE_R2A_SET(data, 0x12);
        data = FIELD_CMU_REG17_PVT_TERM_MAN_ENA_SET(data, 0x1);
        pcie_phy_csr_write(pcie_core_id,  KC_SERDES2_CMU_REGS_CMU_REG17__ADDR, data);
 
        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG17__ADDR);
        data = FIELD_CMU_REG17_PVT_TERM_MAN_ENA_SET(data, 0x0);
        pcie_phy_csr_write(pcie_core_id,  KC_SERDES2_CMU_REGS_CMU_REG17__ADDR, data);

        //up calibration cause receiver detect problem
        lprintf(5,"pcie_core_id 0x%x, up calibration channel select 0x%x, serdes 1  \n\r", pcie_core_id, i);
        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG17__ADDR);
        data = FIELD_CMU_REG17_RESERVED_7_SET(data, i);
        pcie_phy_csr_write(pcie_core_id,  KC_SERDES2_CMU_REGS_CMU_REG17__ADDR, data);
 
        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG17__ADDR);
        data = FIELD_CMU_REG17_PVT_CODE_R2A_SET(data, 0x29);
        //data = FIELD_CMU_REG17_PVT_CODE_R2A_SET(data, 0x1);
        pcie_phy_csr_write(pcie_core_id,  KC_SERDES2_CMU_REGS_CMU_REG17__ADDR , data);
 
        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG16__ADDR );
        data = FIELD_CMU_REG16_PVT_UP_MAN_ENA_SET (data, 0x1);
        pcie_phy_csr_write(pcie_core_id,  KC_SERDES2_CMU_REGS_CMU_REG16__ADDR , data);
 
        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG16__ADDR );
        data = FIELD_CMU_REG16_PVT_UP_MAN_ENA_SET (data, 0x0);
        pcie_phy_csr_write(pcie_core_id,  KC_SERDES2_CMU_REGS_CMU_REG16__ADDR , data);

        lprintf(5,"pcie_core_id 0x%x, down calibration channel select 0x%x, serdes 1  \n\r", pcie_core_id, i);
        //down calibration
        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG17__ADDR );
        data = FIELD_CMU_REG17_RESERVED_7_SET(data, i);
        pcie_phy_csr_write(pcie_core_id,  KC_SERDES2_CMU_REGS_CMU_REG17__ADDR , data);
 
        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG17__ADDR );
        data = FIELD_CMU_REG17_PVT_CODE_R2A_SET(data, 0x29);
        pcie_phy_csr_write(pcie_core_id,  KC_SERDES2_CMU_REGS_CMU_REG17__ADDR , data);
 
        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG16__ADDR );
        data = FIELD_CMU_REG16_PVT_DN_MAN_ENA_SET(data, 0x1);
        pcie_phy_csr_write(pcie_core_id,  KC_SERDES2_CMU_REGS_CMU_REG16__ADDR , data);
 
        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG16__ADDR );
        data = FIELD_CMU_REG16_PVT_DN_MAN_ENA_SET(data, 0x0);
        pcie_phy_csr_write(pcie_core_id,  KC_SERDES2_CMU_REGS_CMU_REG16__ADDR , data);
        }
    }
#endif
}


uint32_t get_momsel(uint32_t pcie_core_id, uint32_t sds, uint32_t pll_8g, uint32_t div2){
  int sds_offset, data, cal_done=0;
  int pll_refdiv, pll_fbdiv, default_pll_refdiv, default_pll_fbdiv;
  uint32_t momsel;

  if (sds){
    sds_offset = 0x30000;
  } else {
    sds_offset = 0x0;
  }

  //set pll reference clock divider and feedback divider
  // div2 is reference clock divide by 2 option
  if (pll_8g){
      if (div2) {pll_refdiv = 0x1; pll_fbdiv  = 0x4f;}
      else      {pll_refdiv = 0x0; pll_fbdiv  = 0x27;}
  } else {
     if (div2) {pll_refdiv = 0x1; pll_fbdiv = 0x63;}
     else      {pll_refdiv = 0x0; pll_fbdiv = 0x31;}
  }
  
  //reset PLL to clear any previous status flag
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG5__ADDR + sds_offset);
  data = FIELD_CMU_REG5_PLL_RESETB_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG5__ADDR + sds_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG5__ADDR + sds_offset);
  data = FIELD_CMU_REG5_PLL_RESETB_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG5__ADDR + sds_offset, data);

  //lprintf(5,"Getting MOMSEL on pcie_core 0x%x, serdes 0x%x, 8G_PLL 0x%x, REF/2 0x%x \n\r", pcie_core_id, sds, pll_8g, div2);
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG33__ADDR + sds_offset);
  data = FIELD_CMU_REG33_CUSTOMER_MODE_INV_SET(data, 0xffff);
  pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG33__ADDR + sds_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG30__ADDR + sds_offset);
  data = FIELD_CMU_REG30_PCIE_MODE_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG30__ADDR + sds_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG1__ADDR + sds_offset);
  data = FIELD_CMU_REG1_PLL_MANUALCAL_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG1__ADDR + sds_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG2__ADDR + sds_offset);
  default_pll_refdiv = FIELD_CMU_REG2_PLL_REFDIV_RD(data);
  default_pll_fbdiv  = FIELD_CMU_REG2_PLL_FBDIV_RD(data);
  data = FIELD_CMU_REG2_PLL_REFDIV_SET(data, pll_refdiv);
  data = FIELD_CMU_REG2_PLL_FBDIV_SET(data, pll_fbdiv);
  pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG2__ADDR + sds_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG9__ADDR + sds_offset);
  data = FIELD_CMU_REG9_PLL_POST_DIVBY2_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG9__ADDR + sds_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG34__ADDR + sds_offset);
  data = FIELD_CMU_REG34_VCO_CAL_VTH_LO_MAX_SET(data, 0x8);
  data = FIELD_CMU_REG34_VCO_CAL_VTH_HI_MAX_SET(data, 0x8);
  data = FIELD_CMU_REG34_VCO_CAL_VTH_LO_MIN_SET(data, 0x5);
  data = FIELD_CMU_REG34_VCO_CAL_VTH_HI_MIN_SET(data, 0x5);
  pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG34__ADDR + sds_offset, data);

data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG0__ADDR + sds_offset);
data = FIELD_CMU_REG0_CAL_COUNT_RESOL_SET(data, 0x7);
pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG0__ADDR + sds_offset, data);

//do VCO Calibration until calibration is successsful
while (1) {
data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG32__ADDR + sds_offset);
data = FIELD_CMU_REG32_FORCE_VCOCAL_START_SET(data, 0x1);
pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG32__ADDR + sds_offset, data);

data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG32__ADDR + sds_offset);
data = FIELD_CMU_REG32_FORCE_VCOCAL_START_SET(data, 0x0);
pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG32__ADDR + sds_offset, data);

do {
data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG7__ADDR + sds_offset);
cal_done = FIELD_CMU_REG7_PLL_CALIB_DONE_RD(data); 
} while (!cal_done);

if (FIELD_CMU_REG7_VCO_CAL_FAIL_RD(data) == 0x0){
    //calibration successful, record momsel value and reset PLL to clear VCO calibration status
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG19__ADDR + sds_offset);
    momsel = FIELD_CMU_REG19_PLL_VCOMOMSEL_RD(data);
    
    break;
} else {
    //if calibration failed, power down and reset PLL. do calibration again
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG0__ADDR + sds_offset);
    data = FIELD_CMU_REG0_PDOWN_SET(data, 0x1);
    pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG0__ADDR + sds_offset, data);

    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG0__ADDR + sds_offset);
    data = FIELD_CMU_REG0_PDOWN_SET(data, 0x0);
    pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG0__ADDR + sds_offset, data);
    
    USDELAY(1);
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG5__ADDR + sds_offset);
    data = FIELD_CMU_REG5_PLL_RESETB_SET(data, 0x0);
    pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG5__ADDR + sds_offset, data);

    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG5__ADDR + sds_offset);
    data = FIELD_CMU_REG5_PLL_RESETB_SET(data, 0x1);
    pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG5__ADDR + sds_offset, data);
}
}


//restore GEN1/GEN2 pll div setting
data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG2__ADDR + sds_offset);
data = FIELD_CMU_REG2_PLL_REFDIV_SET(data, default_pll_refdiv);
data = FIELD_CMU_REG2_PLL_FBDIV_SET(data, default_pll_fbdiv);
pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG2__ADDR + sds_offset, data);

data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG9__ADDR + sds_offset);
data = FIELD_CMU_REG9_PLL_POST_DIVBY2_SET(data, 0x1);
pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG9__ADDR + sds_offset, data);

data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG33__ADDR + sds_offset);
data = FIELD_CMU_REG33_CUSTOMER_MODE_INV_SET(data, 0x0);
pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG33__ADDR + sds_offset, data);

return momsel;
}


int bert_check(int argc, char *argv[]){
  uint32_t data, pcie_core_id, ch, pass, fail;

  if (argc < 2) {
    lprintf(5,"Usage: core_id, channel\n");
    return -1;
  }
  pcie_core_id = atoi(argv[0]);
  ch = atoi(argv[1]);
  
  bert_check_sub(pcie_core_id, ch, 1);
}

int bert_check_sub (int pcie_core_id, int ch, int dbg){
  uint32_t data, pass, fail, sds_offset;
  
  pass = 0;
  fail = 0;

  if (ch >= 4){ sds_offset = 0x30000; ch = ch - 4;}
  else sds_offset = 0;
  
  if (dbg) lprintf(5,"Digital RX reset \n\r");
  //toggle 0-1
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds_offset);
  data = FIELD_CH0_RXTX_REG7_RESETB_RXD_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds_offset, data);

  MSDELAY(100);
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds_offset);
  data = FIELD_CH0_RXTX_REG7_RESETB_RXD_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds_offset, data);

  if (dbg) lprintf(5,"BERT RESYNC \n\r");
  //toggle 1-0
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG6__ADDR + (0x200 * ch) + sds_offset);
  data = FIELD_CH0_RXTX_REG6_RX_BIST_RESYNC_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG6__ADDR + (0x200 * ch) + sds_offset, data);

  MSDELAY(100);
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG6__ADDR + (0x200 * ch) + sds_offset);
  data = FIELD_CH0_RXTX_REG6_RX_BIST_RESYNC_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG6__ADDR + (0x200 * ch) + sds_offset, data);

  if (dbg) lprintf(5,"BERT RESET \n\r");
  //toggle 0-1
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds_offset);
  data = FIELD_CH0_RXTX_REG61_BERT_RESETB_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds_offset, data);

  MSDELAY(100);
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds_offset);
  data = FIELD_CH0_RXTX_REG61_BERT_RESETB_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds_offset, data);

  MSDELAY(100);
  if (dbg) lprintf(5,"BERT check result \n\r");
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG158__ADDR + (0x200 * ch) + sds_offset);
  pass = (data & 0x0080) >> 7;
  fail = (data & 0x0040) >> 6;
  
  if(dbg) {
      if (pass & fail)
        lprintf(3,"PASS and FAIL\n\r");
      else if (pass) 
        lprintf(3,"BIST PASS.\n\r");
      else if (fail)
        lprintf(3,"BIST FAIL.\n\r");
      else
        lprintf(3,"no PASS or FAIL\n\r");
  }
  if(fail) return 1;
  else if (pass) return 0;
}

int bert_cnt(int argc, char *argv[]){
  uint32_t data, lsb_cnt, msb_cnt;
  uint32_t pcie_core_id, ch;

  if (argc < 2) {
    lprintf(3,"Usage: core_id, channel\n");
    return -1;
  }
  pcie_core_id = atoi(argv[0]);
  ch = atoi(argv[1]);

  //toggle 1 to 0
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG6__ADDR+ (0x200 * ch));
  data = FIELD_CH0_RXTX_REG6_RX_BIST_ERRCNT_RD_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG6__ADDR+ (0x200 * ch), data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG6__ADDR + (0x200 * ch));
  data = FIELD_CH0_RXTX_REG6_RX_BIST_ERRCNT_RD_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG6__ADDR + (0x200 * ch), data);

  lsb_cnt = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG153__ADDR + (0x200 * ch));
  msb_cnt = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG152__ADDR + (0x200 * ch));

  lprintf(4,"MSB ERR Count "); putnum(msb_cnt); lprintf(4,".\n\r");
  lprintf(4,"LSB ERR Count "); putnum(lsb_cnt); lprintf(4,".\n\r");
}

int rx_pattern(int argc, char *argv[]){
  uint32_t data0, data1, data2, data3, data4;
  uint32_t pcie_core_id, ch;

  if (argc < 2) {
    lprintf(3,"Usage: ip_port\n");
    return -1;
  }
  pcie_core_id = atoi(argv[0]);
  ch = atoi(argv[1]);

  data0 = pcie_phy_csr_read(pcie_core_id, (KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG60__ADDR + (0x200 * ch)));
  data1 = pcie_phy_csr_read(pcie_core_id, (KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG59__ADDR + (0x200 * ch)));
  data2 = pcie_phy_csr_read(pcie_core_id, (KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG58__ADDR + (0x200 * ch)));
  data3 = pcie_phy_csr_read(pcie_core_id, (KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG57__ADDR + (0x200 * ch)));
  data4 = pcie_phy_csr_read(pcie_core_id, (KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG56__ADDR + (0x200 * ch)));

  lprintf(5,"rx pattern 0 0x%x \n\r", data0);
  lprintf(5,"rx pattern 1 0x%x \n\r", data1);
  lprintf(5,"rx pattern 2 0x%x \n\r", data2);
  lprintf(5,"rx pattern 3 0x%x \n\r", data3);
  lprintf(5,"rx pattern 4 0x%x \n\r", data4);
}

void sm_pcie_release_phy_reset(uint32_t pcie_core_id){
  uint32_t data;

  lprintf(5,"Deasserting the PHY reset now.\n\r");
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_SRST__ADDR);
  data = data & ~FIELD_PCIE_SRST_PHY_SDS_RESET_MASK;
  pcie_csr_write(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_SRST__ADDR, data);
}  

void sm_pcie_wait_phy_rdy(uint32_t pcie_core_id){
  uint32_t data;

  lprintf(5,"Waiting for the PHY to be ready\n\r");
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_PCIECORE_CTLANDSTATUS__ADDR);
  data = data & FIELD_PCIECORE_CTLANDSTATUS_PIPE_PHY_STATUS_MASK;
  while(data != 0) {
    data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS0_CMU_STATUS0__ADDR);
    lprintf(5,"PLL lock status is "); putnum(data); lprintf(5,"\n\r");

    data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_PCIECORE_CTLANDSTATUS__ADDR);
    data = data & FIELD_PCIECORE_CTLANDSTATUS_PIPE_PHY_STATUS_MASK;
    lprintf(5," Inside while--- polling for PHY_STATUS to be deasserted\n\r");
  }

  lprintf(5," PHY_STATUS deasserted. PHY is ready now. \n\r");
};  

void sm_pcie_init_csr_clkrst(uint32_t pcie_core_id) {
  uint32_t data;
  uint32_t i;
 
  lprintf(5,"First putting everything in reset\n\r");
  data = 0xFFFFFFFF;
  pcie_csr_write(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_SRST__ADDR, data);
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_SRST__ADDR);

  lprintf(5,"Now, disabling the clks\n\r");
  data = 0;
  pcie_csr_write(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_CLKEN__ADDR, data);
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_CLKEN__ADDR);

  for(i = 0; i < 0xfffff; i++); //some delay for reset

  lprintf(5,"Enabling the CSR, axi_core and apb_core clocks, to enable PCIE controller as well as subsystem register access.\n\r");
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_CLKEN__ADDR);
  data = data | FIELD_PCIE_CLKEN_CSR_CLKEN_MASK | FIELD_PCIE_CLKEN_AXI_CORE_CLKEN_MASK | FIELD_PCIE_CLKEN_APB_CORE_CLKEN_MASK;
  pcie_csr_write(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_CLKEN__ADDR, data);

  lprintf(5,"Deasserting the corresponding resets now.\n\r");
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_SRST__ADDR);
  data = (data & ~FIELD_PCIE_SRST_CSR_RESET_MASK & ~FIELD_PCIE_SRST_AXI_CORE_RESET_MASK & ~FIELD_PCIE_SRST_APB_CORE_RESET_MASK); 
  //data = (data & ~FIELD_PCIE_SRST_PHY_SDS_RESET_MASK & ~FIELD_PCIE_SRST_CSR_RESET_MASK & ~FIELD_PCIE_SRST_AXI_CORE_RESET_MASK & ~FIELD_PCIE_SRST_APB_CORE_RESET_MASK); 
  pcie_csr_write(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_SRST__ADDR, data);
};

void sm_pcie_init_core_clkrst(uint32_t pcie_core_id) {
  uint32_t data;
  
  lprintf(5,"Enabling the core clock, to enable the link up.\n\r");
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_CLKEN__ADDR);
  data = data | FIELD_PCIE_CLKEN_CORE_CLKEN_MASK;
  pcie_csr_write(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_CLKEN__ADDR, data);

  data = pcie_csr_read(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_CLKEN__ADDR);

  lprintf(5,"Deasserting the core reset.Now, will poll for link up.\n\r");
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_SRST__ADDR);
  data = (data & ~FIELD_PCIE_SRST_PHY_SDS_RESET_MASK & ~FIELD_PCIE_SRST_CSR_RESET_MASK & ~FIELD_PCIE_SRST_CORE_RESET_MASK & ~FIELD_PCIE_SRST_AXI_CORE_RESET_MASK & ~FIELD_PCIE_SRST_APB_CORE_RESET_MASK); 
  pcie_csr_write(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_SRST__ADDR, data);
};  

void sm_pcie_assert_core_reset(uint32_t pcie_core_id) {
  uint32_t data;

  lprintf(5,"Asserting the core reset.\n\r");
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_SRST__ADDR);
  data = FIELD_PCIE_SRST_CORE_RESET_SET(data, 0x1); 
  pcie_csr_write(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_SRST__ADDR, data);
};  

void sm_pcie_disable_core_clk(uint32_t pcie_core_id) {
  uint32_t data;

  lprintf(5,"Disabling the core clock.\n\r");
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_CLKEN__ADDR);
  data = data & ~FIELD_PCIE_CLKEN_CORE_CLKEN_MASK;
  pcie_csr_write(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_CLKEN__ADDR, data);
};

void sm_pcie_assert_phy_reset(uint32_t pcie_core_id) {
  uint32_t data;

  lprintf(5,"Asserting the Serdes reset.\n\r");
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_SRST__ADDR);
  data |= FIELD_PCIE_SRST_PHY_SDS_RESET_MASK; 
  pcie_csr_write(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_SRST__ADDR, data);
};


int pcie_core_reset(int argc, char *argv[]) {
  uint32_t data, pcie_core_id;
  
  if(argc < 1){
    lprintf(3,"not enough argument, pcie_core_id.\n\r");
    return -1;
  } else {
    pcie_core_id = atoi(argv[0]);
  }
  lprintf(5,"asserting the core resets.\n\r");
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_SRST__ADDR);
  data = (FIELD_PCIE_SRST_PHY_SDS_RESET_MASK | FIELD_PCIE_SRST_CSR_RESET_MASK | FIELD_PCIE_SRST_CORE_RESET_MASK |
  FIELD_PCIE_SRST_AXI_CORE_RESET_MASK | FIELD_PCIE_SRST_APB_CORE_RESET_MASK);
  pcie_csr_write(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_SRST__ADDR, data);
}

uint32_t extract_max_payload_size(uint32_t pcie_core_id) {
// max payload size 128B(core2) or 512B
  return (pcie_core_id == 2 ? 1 : 2);
}

void sm_pcie_hack_for_kc(uint32_t pcie_core_id) {
//#ifndef SM_SOC_SIM
  uint32_t data;

  lprintf(5,"Bypassing the receiver detection and disabling L2 power mgmt, due to bug in KC testchip.\n\r");
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR));
  data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352_CFG_CONSTANTS_BYPASS_RECEIVER_DETECTION_MASK;
  data = data & ~FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352_CFG_CONSTANTS_ENABLE_L2_POWER_MGMT_MASK;
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR), data);
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR));
//#endif  
}  

void sm_pcie_hack_for_sim(uint32_t pcie_core_id, uint32_t gen) {
  uint32_t data;

  lprintf(5,"Enabling the reduced timeout and reduced TS1 for simulation\n\r");
  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR);
  data |= FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352_CFG_CONSTANTS_QUICK_SIMULATION_REDUCE_TIMEOUTS_MASK;
  data |= FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352_CFG_CONSTANTS_QUICK_SIMULATION_REDUCE_TS1_MASK;
  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR, data);
  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR);

  lprintf(5,"Reducing the EQ_TS1_ACK_DELAY\n\r");
  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_63_32__ADDR);
  data = data & ~FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_63_32_CFG_8G_CONSTANTS_EQ_TS1_ACK_DELAY_MASK;
  data |= 0x100;

  if(gen == 2)
    data |= 0x3F00;

  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_63_32__ADDR, data);
  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_63_32__ADDR);
}  

void rxdetect_mask(uint32_t pcie_core_id, uint32_t width) {
uint32_t data, mask;
  switch (width)
  {
    case (1): mask = 0x1; break;
    case (2): mask = 0x3; break;
    case (4): mask = 0xf; break;
    case (8): mask = 0xff; break;
    default: mask = 0xffff; break;
  }

  data = pcie_csr_read(pcie_core_id,  NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_543_512__ADDR);
  data = FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_543_512_CFG_CONSTANTS_RX_DETECT_OVERRIDE_SET(data, 0x1);
  pcie_csr_write(pcie_core_id,  NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_543_512__ADDR, data);

  data = pcie_csr_read(pcie_core_id,  NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_575_544__ADDR);
  data = FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_575_544_CFG_CONSTANTS_RX_DETECT_MASK_SET(data, mask);
  pcie_csr_write(pcie_core_id,  NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_575_544__ADDR, data);
}

void sm_pcie_en_self_crslink(uint32_t pcie_core_id) {
  uint32_t data;

  lprintf(5,"Enabling self crosslink in the controller.\n\r");

  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_543_512__ADDR));
  data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_543_512_CFG_CONSTANTS_SELF_CROSSLINK_MASK;
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_543_512__ADDR), data);

  lprintf(5,"Bypassing the receiver detection .\n\r");
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR));
  data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352_CFG_CONSTANTS_BYPASS_RECEIVER_DETECTION_MASK;
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR), data);

  //daniel: not sure if this is needed
  //lprintf(5,"force PIPE into loopback mode .\n\r");
  //data = pcie_phy_csr_read(pcie_core_id, KC_PIPE_REGS_PIPE_CONTROL__ADDR);
  //data = FIELD_PIPE_CONTROL_PIPE_LOOPBACK_FORCE_SET(data, 0x1);
  //pcie_phy_csr_write(pcie_core_id, KC_PIPE_REGS_PIPE_CONTROL__ADDR, data);
}  

void sm_pcie_init_ctrl_rc(uint32_t pcie_core_id, uint32_t gen) {
  uint32_t data;

  //Writing Class Code for Host Bridge [31:9] = 24'h06_0000
  lprintf(5," Configuring class code \n\r");
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_63_32__ADDR)); //Default 0x00001104 from .h
  data = data & ~FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_63_32_CFG_CONSTANTS_CLASS_CODE_MASK; //Clearing [31:9]
  data = data | 0x06000000; //Class Code for Host Bridge [31:9] = 24'h06_0000
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_63_32__ADDR), data);
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_63_32__ADDR));


// force link to loopbcak only
#if 0 
     data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR);
      data &= ~(0xFFF7FFFF);    // Get value of 19th bit

      if(data)
         data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR) & 0xFFF7FFFF;
      else
    	 data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR) | ~(0xFFF7FFFF);

      pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR, data);

      data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR);
      data &= ~(0xFFF7FFFF);    // Get value of 20th bit
      lprintf(5,"Direct to Loopback LTSSM state Bit 0x%x \n\r",data);

#endif

  //NWL core RP config
  //mgmt_sw_mode[459]=1; mgmt_rp_mode[456]=0;
  //Def value of NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR is 0x00014000
  lprintf(5," Configuring switch mode[459]=1 and RP mode [456]=0\n\r");
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR));
  data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_SWITCH_PORT_MODE_MASK;
  data = data & ~FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_PM_FORCE_RP_MODE_MASK;
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR), data);
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR));

  lprintf(5," Programming cfg 479_448 for rc GEN%1d\n\r", gen+1);
  if(gen == 0) {
    data = data & ~FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_SUPPORT_5GTS_MASK;
    data = data & ~FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_SUPPORT_8GTS_MASK;
  } else if (gen == 1) {
    data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_SUPPORT_5GTS_MASK;
    data = data & ~FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_SUPPORT_8GTS_MASK;
    data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_DIRECT_TO_5GTS_MASK;
    data = data & ~FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_DIRECT_TO_8GTS_MASK;
  } else {
    data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_SUPPORT_5GTS_MASK;
    data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_SUPPORT_8GTS_MASK;
    data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_DIRECT_TO_5GTS_MASK;
    data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_DIRECT_TO_8GTS_MASK;

}
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR), data);

  lprintf(5," Advertising actual credits as its RP, Bit[457]=0, bit 9 of this reg \n\r");
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR));
  
//Vv: Advertise infinite credits from RC
// Needs to check with DV team, since this is not reflecting in InitFC state of link 
// initlization  
  //  data = data & ~FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_ADVERTISE_INFINITE_CH_CD_CREDITS_AS_ROOT_PORT_MASK;
  //data = data | 0x80000000;
  data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_ADVERTISE_INFINITE_CH_CD_CREDITS_AS_ROOT_PORT_MASK;

  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR), data);
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR));
   
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0__ADDR));
  data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0_CFG_8G_CONSTANTS_MGMT_DS_PORT_TX_PRESET_SET(data, LOCAL_PRESET);
  data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0_CFG_8G_CONSTANTS_MGMT_US_PORT_TX_PRESET_SET(data, REMOTE_PRESET);
 /*  
  data=FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0_CFG_8G_CONSTANTS_MGMT_US_PORT_RX_PRESET_HINT_WR(data) ;      // Vv
  data=FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0_CFG_8G_CONSTANTS_MGMT_US_PORT_RX_PRESET_HINT_SET(data,0x2) ; //vv 
  

  data=FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0_CFG_8G_CONSTANTS_MGMT_DS_PORT_RX_PRESET_HINT_WR(data) ; //vv
  data=FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0_CFG_8G_CONSTANTS_MGMT_DS_PORT_RX_PRESET_HINT_SET(data,0x2) ; //vv
*/
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0__ADDR), data);
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0__ADDR));
   
  #ifdef SKIP_BCA
    lprintf(5,"Skipping equalization phase 2-3 through 8g constants Bit[16] =1\n\r");
    data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0__ADDR));
    data = data | FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0_CFG_8G_CONSTANTS_DOWNSTREAM_EQ_SKIP_PHASE_2_3_MASK;
    pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0__ADDR), data);
    data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0__ADDR));
  #endif

    lprintf(5,"Equalization Status in Gen3 Link : 0x%x \n\r",
    	  pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0__ADDR)));

    //RC mode phase 3 and endpoint mode phase 2, USE_PRESET bit is set by default. select PRESET 7 for remote transmitter
    data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_287_256__ADDR);
    data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_287_256_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE0_SET(data, REMOTE_BCA_PRESET);
    data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_287_256_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE1_SET(data, REMOTE_BCA_PRESET);
    pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_287_256__ADDR, data);
   
    data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_319_288__ADDR);
    data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_319_288_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE2_SET(data, REMOTE_BCA_PRESET);
    data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_319_288_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE3_SET(data, REMOTE_BCA_PRESET);
    pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_319_288__ADDR, data);
    
    data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_351_320__ADDR);
    data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_351_320_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE4_SET(data, REMOTE_BCA_PRESET);
    data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_351_320_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE5_SET(data, REMOTE_BCA_PRESET);
    pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_351_320__ADDR, data);

    data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_383_352__ADDR);
    data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_383_352_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE6_SET(data, REMOTE_BCA_PRESET);
    data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_383_352_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE7_SET(data, REMOTE_BCA_PRESET);
    pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_383_352__ADDR, data);

    //change UP/DN step size to 2 (encoding 0 --> 1, 1--> 2, 2--> 4, 3--> 8)
    data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_159_128__ADDR);
    data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_159_128_CFG_8G_CONSTANTS_EQ_UPDN_POST_STEP_SET(data, 0x0);
    data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_159_128_CFG_8G_CONSTANTS_EQ_UPDN_PRE_STEP_SET(data, 0x0);
    pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_159_128__ADDR, data);
    

  lprintf(5,"Setting Device port type [185:182] = 4'h4 and SLOT_IMPLEMENTED [186]=1  through CFG_CONTROL\n\r");
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_191_160__ADDR));
  data = data & ~FIELD_EXPRESSO_CFG_CONTROL_CFG_CONTROL_191_160_CFG_CONTROL_PCIE_CAP_DEVICE_PORT_TYPE_MASK;
  data = data | 0x05000000; //Device port type [185:182] = 4'h4, SLOT_IMPLEMENTED [186]=1
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_191_160__ADDR), data);
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_191_160__ADDR));

// Add initlization specific to functional validation here
// Following configuraiton is not  related to PCIE link
// this is specific to initilization required for PCIE validation

  lprintf(5,"Enabling ASPM L0s and L1 support\n\r");
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_95_64__ADDR));
  data |= 2 << 26;

  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_95_64__ADDR,data);
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_95_64__ADDR));

  lprintf(5,"Enabling ASPM L1 power management\n\r");
  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_415_384__ADDR);
  data |= FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_415_384_CFG_CONSTANTS_ENABLE_L1S_POWER_MGMT_MASK;
  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_415_384__ADDR, data);

  lprintf(5,"Make ignore_poison bit to 0 to test AER \n\r");

  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_511_480__ADDR);
  data &= ~FIELD_NWL_PCIE_DMA_CFG_CONSTANTS_511_480_IGNORE_POISON_MASK;
  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_511_480__ADDR, data);

#ifdef Change4
//#ifdef PERF_MEASURMENT
  // Enable Cut through mode

  lprintf(5,"Enabling cut through settings \n\r");
  data=pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_PCIE_TX_CUT_THROUGH__ADDR));
  data = data | 0x1;
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_PCIE_TX_CUT_THROUGH__ADDR), data);

  data=pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_PCIE_TX_CUT_THROUGH__ADDR));
  lprintf(5,"CUT THROUGH");putnum(data);lprintf(5,"\n\r");

  data=pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_M_MAX__ADDR));
  data=0x00;
  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_M_MAX__ADDR, data);

  data=pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_M_MAX__ADDR));
  lprintf(5,"CFG_M_MAX");putnum(data);lprintf(5,"\n\r");

#ifdef Change5

  data=pcie_csr_read(pcie_core_id, (SM_PCIE_CSR_REGS_PCIECORE_LTSSM__ADDR));
//  data = data | (0x5<<24);
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PCIECORE_LTSSM__ADDR,data);
#endif

  data=pcie_csr_read(pcie_core_id, (SM_PCIE_CSR_REGS_PCIECORE_LTSSM__ADDR));
  lprintf(5,"LTSSM");putnum(data);lprintf(5,"\n\r");

#endif




 // pcie_csr_write(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_63_32__ADDR,3);

  config_ib_regs(pcie_core_id, RC);
};

void sm_pcie_init_ctrl_ep(uint32_t pcie_core_id, uint32_t gen){
  uint32_t data;

//NWL core EP config
//mgmt_sw_mode[459]=0; mgmt_rp_mode[456]=0;
//Def value of NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR is 0x00014000

//  pcie_csr_write(pcie_core_id,  NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_31_0__ADDR, EP_DEV_VEN_ID);

  lprintf(5," Configuring switch mode[459]=0 and RP mode [456]=0\n\r");
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR));
  data = data & ~FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_SWITCH_PORT_MODE_MASK;
  data = data & ~FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_PM_FORCE_RP_MODE_MASK;
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR), data);
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR));

  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR));
  lprintf(5," Programming cfg 479_448 for ep GEN%1d\n\r", gen+1);
  if(gen == 0) {
    data = data & ~FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_SUPPORT_5GTS_MASK;
    data = data & ~FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_SUPPORT_8GTS_MASK;
  } else if (gen == 1) {
    data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_SUPPORT_5GTS_MASK;
    data = data & ~FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_SUPPORT_8GTS_MASK;
  } else {
    data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_SUPPORT_5GTS_MASK;
    data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_SUPPORT_8GTS_MASK;
  }
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR), data);
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR));
   
  lprintf(5," Advertising Infinite credits as its EP, Bit[457]=1, bit 9 of this reg \n\r");
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR));
  data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_ADVERTISE_INFINITE_CH_CD_CREDITS_AS_ROOT_PORT_MASK;
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR), data);
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR));

  if(gen != 2) {
    lprintf(5,"Skipping Downstream equalization phase 2-3 through 8g constants Bit[16] =1\n\r");
    data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0__ADDR));
    data = data | FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0_CFG_8G_CONSTANTS_DOWNSTREAM_EQ_SKIP_PHASE_2_3_MASK;
    pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0__ADDR), data);
    data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0__ADDR));
  }

  lprintf(5,"Equalization Status in Gen3 Link : 0x%x \n\r",
    	  pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0__ADDR)));

  lprintf(5," For EP Setting Device port type [185:182] = 4'h0 and SLOT_IMPLEMENTED [186]=0  through CFG_CONTROL\n\r");
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_191_160__ADDR));
  data = data & ~FIELD_EXPRESSO_CFG_CONTROL_CFG_CONTROL_191_160_CFG_CONTROL_PCIE_CAP_DEVICE_PORT_TYPE_MASK;
  data = data & ~FIELD_EXPRESSO_CFG_CONTROL_CFG_CONTROL_191_160_CFG_CONTROL_PCIE_CAP_SLOT_IMPLEMENTED_MASK; 
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_191_160__ADDR), data);
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_191_160__ADDR));


  // Enable this and program for genrating  INTx supprt interrupts.

  lprintf(5,"Programming for Int Support :  EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_159_128 \n\r");

  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_159_128__ADDR));
  data = data | 0x00000001;         // Currently supported only INTx

  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_159_128__ADDR), data);
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_159_128__ADDR));

#ifdef Change4
//#ifdef PERF_MEASURMENT
  // Enable Cut through mode

  lprintf(5,"Enabling cut through settings \n\r");
  data=pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_PCIE_TX_CUT_THROUGH__ADDR));
  data = data | 0x1;
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_PCIE_TX_CUT_THROUGH__ADDR), data);

  data=pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_PCIE_TX_CUT_THROUGH__ADDR));
  lprintf(5,"CUT THROUGH");putnum(data);lprintf(5,"\n\r");

  data=pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_M_MAX__ADDR));
  data=0x00;
  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_M_MAX__ADDR, data);

  data=pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_M_MAX__ADDR));
  lprintf(5,"CFG_M_MAX");putnum(data);lprintf(5,"\n\r");


#ifdef Change5

  data=pcie_csr_read(pcie_core_id, (SM_PCIE_CSR_REGS_PCIECORE_LTSSM__ADDR));
//  data = data | (0x5<<24);
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PCIECORE_LTSSM__ADDR,data);
#endif

#endif

  lprintf(5,"Enabling ASPM L0s and L1 support\n\r");
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_95_64__ADDR));
  data |= 2 << 26;

  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_95_64__ADDR,data);
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_95_64__ADDR));

  lprintf(5,"Enabling L1 power management\n\r");
  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_415_384__ADDR);
  data |= FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_415_384_CFG_CONSTANTS_ENABLE_L1S_POWER_MGMT_MASK;
  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_415_384__ADDR, data);
  lprintf(5,"Enabling D3_Cold power management\n\r");
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_POWERMANAGEMENTREG__ADDR);
   data |= 0x1000000;
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_POWERMANAGEMENTREG__ADDR, data);


  lprintf(5,"Make ignore_poison bit to 0 to test AER \n\r");

  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_511_480__ADDR);
  data &= ~FIELD_NWL_PCIE_DMA_CFG_CONSTANTS_511_480_IGNORE_POISON_MASK;
  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_511_480__ADDR, data);

 // lprintf(5," Enabling #PERST for GPIO as Interrupt \n\r");
 // InitPERST_EP(pcie_core_id);

//  pcie_csr_write(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_63_32__ADDR,3);
  config_ib_regs(pcie_core_id, EP);
};  

void sds_rx_invert(int pcie_core_id, int link_width){
int data, i;

  lprintf(5,"Invert serdes rx clock ..... \n\r");
  if (link_width < 4) {
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG13__ADDR);
    data = data | 0x2000;
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG13__ADDR, data);
  } else if (link_width == 4){
    for (i = 0 ; i < 4; i++) {
        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG13__ADDR + (0x200 * i));
        data = data | 0x2000;
        pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG13__ADDR + (0x200 * i), data);
    }
  } else if (link_width == 8) {
    for (i = 0 ; i < 4; i++) {
        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG13__ADDR + (0x200 * i));
        data = data | 0x2000;
        pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG13__ADDR + (0x200 * i), data);
    }
    for (i = 0 ; i < 4; i++) {
        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG13__ADDR + (0x200 * i) + 0x30000);
        data = data | 0x2000;
        pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG13__ADDR + (0x200 * i) + 0x30000, data);
    }
  }
}

unsigned int sm_pcie_poll_linkup(uint32_t pcie_core_id, uint32_t gen, uint32_t link_width, uint32_t print_state){
  uint32_t data, fire_rate, gen_match=0, olddata=1;
  uint32_t status = 0;
  uint32_t linkup, oldlinkup=1;
  uint32_t link_is=0,width=0;
  uint32_t printGEN[4] = {1,1,1,1};
  int cnt=90000;    // Safe delay for SLT test case for chip screening.
  
#ifndef ENB_HOTRESET
  do {
      //polling for DL LinkUp
      data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_PCIECORE_CTLANDSTATUS__ADDR);
      linkup = FIELD_PCIECORE_CTLANDSTATUS_S_LINK_UP_RD(data);        
      fire_rate = FIELD_PCIECORE_CTLANDSTATUS_PIPE_PHY_RATE_RD(data);

      if (print_state){
          data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_PCIECORE_LTSSM__ADDR);
          lprintf(5,"POLLUP STATUS: lts_state = "); putnum(FIELD_PCIECORE_LTSSM_S_LTS_STATE_RD(data)); lprintf(5," and lts_substate = ");
          putnum(FIELD_PCIECORE_LTSSM_S_LTS_SUB_STATE_RD(data)); lprintf(5,"\n\r");
      }
      data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_31_0__ADDR) >> 24;
      if ((data != olddata)||(linkup != oldlinkup)) {
          olddata = data; width=(data & 0xfc)>>2; oldlinkup = linkup;
          lprintf(5,"\nCurrent LINK UP %1d rate Gen%1d Width x%1d\n\r", linkup, (data & 0x3)+1, width); 
      } else
          lprintf(5,".");

      if (linkup) {  
          if (printGEN[fire_rate]) {
              lprintf(5,"\nPCIe LINK UP fire rate Gen%1d Width x%1d\n\r", fire_rate+1, link_width); 
              printGEN[fire_rate]= 0;
          }
          gen_match = linkup & (fire_rate == gen) & (width == link_width);
      }
  } while ( !gen_match && cnt-- );
//  MSDELAY(1000);
  if(linkup)
  {
    if (gen_match)
    {
	  lprintf(5,"LINK UP is successful \n\r");
	  return(CORRECT_LINK);                                       // Return 1 to indicate successful link up is achieved
    }
    else if ( (width != link_width) || (fire_rate != gen) ){
	  return(WRONG_LINK);                             // Return 2 to indicate Link up is there but with incorrect negotiation.
    }
  }	
  else {
	  lprintf(5,"LINK UP is failed \n\r");
	  return (NO_LINK);                               // Return 0 to indicate linkup Fail and make exit from here
  }

#else
  data = ltssm_sub(pcie_core_id, &status);
  if ((((data & 0xfc000000)>>26)!=link_width)||(((data & 0x03000000)>>24)!=gen))
    data = pcie_relink_sub(pcie_core_id, (link_width<<8)|gen, 10);
#endif
  // lprintf(5,"sm_pcie_poll_linkup() exit\n\r");
};

void sm_pcie_init_ven_msg_capture(uint32_t pcie_core_id) {
  uint32_t data;

  lprintf(5,"Programming the message capture and mask registers for vendor defined messages\n\r");
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_MESSAGECODEREG__ADDR);
  data = (0x7e & FIELD_MESSAGECODEREG_MESSAGECODECAPTREG_MASK);
  data = FIELD_MESSAGECODEREG_MESSAGECODEMASKREG_SET(data, 0x1);

  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_MESSAGECODEREG__ADDR, data);

  lprintf(5,"Enabling the support for vendor defined messages as well as capture of them.\n\r");
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_RXMESSAGESTATUSREG__ADDR);

  data |= FIELD_RXMESSAGESTATUSREG_MESSAGECAPTURE_ENABLE_MASK;
  data |= FIELD_RXMESSAGESTATUSREG_SUPPORTVENDORDEFINEDMESSAGES_MASK;

  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_RXMESSAGESTATUSREG__ADDR, data);
};  

void pcie_ddr_remap(void)
{
#define DDR_SIZE    0x200000000   //8GB
  static int ddr_remap = 0;
  int i;

#ifdef VBIOS    //temp fix for DDR
  if(ddr_remap == 0) {
//    mmu_unmap(0xe000000000, DDR_SIZE);           //to remove existing direct VA->PA mapping during boot
//    mmu_map(0xe000000000, 0xe00000000, DDR_SIZE); //to remap PA to new 36 bit virtual addr 0xe00000000, 
    flat_map(0xA000000000,DDR_SIZE, 0);           //0x500000,0);  //PCIe 3 5MB
    ddr_remap = 3;
  }
#endif
}


void sm_pcie_init(uint32_t pcie_core_id, uint32_t port_type, uint32_t en_lpbk, uint32_t gen, uint32_t ext_ref, uint32_t link_width, uint32_t poll) {
uint32_t data, full_width, i, print_state;
uint32_t act_link_width, exp_link_width;
uint32_t act_link_speed, exp_link_speed;
uint32_t  pllnoerr = 1, count = 0;

  act_link_width = 0;
  exp_link_width = link_width;
  act_link_speed = 0;
  exp_link_speed = gen;

#ifndef SM_SOC_SIM
  lprintf(5,"Initializing the Chipscope Pro to bring out PCLK and TC signals on chipscope bus\n\r");
  cpu_write(0x17040000, 0x03000000);
  cpu_read(0x17040000);
#endif  

//  pcie_ddr_remap();   //DDR remap, not used as 40bit DDR map works now
  if (((pcie_core_id == 0) || (pcie_core_id == 3)) && (link_width == 8))
    full_width = 1;
  else
    full_width = 0;

  do {
    lprintf(5,"Initializing the clkrst module to enable the csr clks and deassert the csr resets.\n\r");
    sm_pcie_init_csr_clkrst(pcie_core_id);
  
  #ifdef ENB_DEBUG_HOOK
    sm_pcie_setup_cntlr_pcie_debug_hooks(pcie_core_id, 0, 4);
    //sm_pcie_setup_generic_debug_hooks(pcie_core_id, 0, 0, 2);
    sm_pcie_setup_generic_debug_hooks(pcie_core_id, 0, 0, 1);  //NWL core diagbus
  #endif  
  
    if((pcie_core_id == 0) || (pcie_core_id == 3)){
      if (full_width) {
        lprintf(5,"setting PCIEX8 full width\n\r");
        //setting this bit will allow reset from core 0 to reset serdes of core 1
        data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_MUX__ADDR);
        data = FIELD_PCIE_SDS_MUX_SEL_PCIE_FULL_WIDTH_SET(data, 0x1);
        pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_MUX__ADDR, data);
      }
      else {
        lprintf(5,"Clearing PCIEX8 full width\n\r");
        //setting this bit will allow reset from core 0 to reset serdes of core 1
        data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_MUX__ADDR);
        data = FIELD_PCIE_SDS_MUX_SEL_PCIE_FULL_WIDTH_SET(data, 0x0);
        pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_MUX__ADDR, data);      
      }
    }
  
    sm_pcie_init_phy(pcie_core_id, port_type, gen, ext_ref, link_width, en_lpbk);

    sm_pcie_init_ecc(pcie_core_id);
    lprintf(5,"ECC init done\n\r");
  
  #ifdef SIMULATION  
    sm_pcie_hack_for_sim(pcie_core_id, gen);
  #endif
  
    if(en_lpbk == 1)
      sm_pcie_en_self_crslink(pcie_core_id);
  
    sm_pcie_release_phy_reset(pcie_core_id);
    #ifdef REF_DIVIDE2
      //reference clock divide by 2 doesn't have pll lock set
    #else
      pllnoerr = wait_pll_lock(pcie_core_id, full_width);
    #endif
  } while ((!pllnoerr)&&(++count < 5));
  if (!pllnoerr)
    lprintf(5,"PLL lock failed\n");
  else
    lprintf(5,"PLL lock ok at %d try\n", count);

  sm_pcie_wait_phy_rdy(pcie_core_id);
#ifndef SIMULATION  
  manual_cal(pcie_core_id, link_width);
  force_pvt_cal(pcie_core_id, link_width);
  lat_summer_average_cal(pcie_core_id, link_width);
#endif


#ifdef RCV_DET_BYPASS
  lprintf(5,"Bypassing the receiver detection.\n\r");
  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR);
  data = FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352_CFG_CONSTANTS_BYPASS_RECEIVER_DETECTION_SET(data, 0x1);
  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR, data);
#endif

  if(port_type == EP) {
	  lprintf(5,"Initializing the controller for EP mode\n\r");
	  sm_pcie_init_ctrl_ep(pcie_core_id, gen);
  } else {
	  lprintf(5,"Initializing the controller for RC mode\n\r");
	  sm_pcie_init_ctrl_rc(pcie_core_id, gen);
	  sm_pcie_init_ven_msg_capture(pcie_core_id);
  }
  sm_pcie_init_core_clkrst(pcie_core_id);


#ifdef BUG_44393


  data=pcie_csr_read(pcie_core_id,SM_GLBL_ERR_CSR_GLBL_TRANS_ERR__ADDR);
  if(data)
  {
	  lprintf(5,"Transaction Error =  0x%x \n\r",data);
	  pcie_csr_write(pcie_core_id,SM_GLBL_ERR_CSR_GLBL_TRANS_ERR__ADDR,data); 
  } 

  data=pcie_csr_read(pcie_core_id, SM_SLAVE_SHIM_CSR_INT_SLV_TMO__ADDR );
  if(data)
  {
	  lprintf(5,"Slave Error =  0x%x \n\r",data);
	  pcie_csr_write(pcie_core_id,SM_SLAVE_SHIM_CSR_INT_SLV_TMO__ADDR,data); 
  } 

  data=pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_SLVRDERRATTRIBUTES__ADDR );
    if(data)
    {
  	  lprintf(5,"SlaveReadAtt =  0x%x \n\r",data);
  	  pcie_csr_write(pcie_core_id,SM_PCIE_CSR_REGS_SLVRDERRATTRIBUTES__ADDR,data);
    }

//	pcie_csr_write(pcie_core_id,SM_SLAVE_SHIM_CSR_CFG_SLV_RESP_TMO_CNTR__ADDR,1);    // to timeout Pcie
	
#endif

  if (poll) {
	  sm_pcie_poll_linkup(pcie_core_id, gen, link_width, 1);

	  MSDELAY(1000);
	  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_31_0__ADDR);
	  act_link_width = data >> 26;
	  act_link_speed = (data >> 24) & 0x3;
	  printf("Actual link width : %d Actual link speed Gen : %d",act_link_width,act_link_speed+1); lprintf(3,"\n\r");
  }
  }




void sm_pcie_setup_generic_debug_hooks(uint32_t pcie_core_id, uint32_t axi_shim, uint32_t axi, uint32_t diagsel){
  uint32_t data;

  lprintf(5,"Setting the generic controls to bring the debug bus out on GPIOs\n\r");
  // Program GPIO_DS15 ~ GPIO_DS0 pins to select Diagnostics Data Alternate Output Function.
  data = cpu_read(0x17001294);
  //data = (data & 0xC0003000) | 0x2AAA8AAA;  //leave bit15/6 untouched, BB1 used for reset/I2C
  data = (data & 0xC3000000) | 0x28AAAAAA;  //leave bit15/12 untouched, BB1 used for reset, PCIE reset
  cpu_write(0x17001294, data);
  data = cpu_read(0x17001294);
  lprintf(5,"Value of register @0x17001294 is "); putnum(data); lprintf(5,"\n\r");

  // Program GPIO_DS15 ~ GPIO_DS0 as outputs.
  data = cpu_read(0x1700129c);
  //data |= 0x7FBF;                           //leave bit15/6 untouched
  data |= 0x6FFF;                           //leave bit15/12 untouched
  cpu_write(0x1700129c, data);
  data = cpu_read(0x1700129c);
  lprintf(5,"Value of register @0x1700129c is "); putnum(data); lprintf(5,"\n\r");

  // Write to 0x000_1700_1320 (MPA_DIAG ) to select the module to observe
  switch(pcie_core_id) {
    case 0: data = 0x00000010;
            break;
    case 1: data = 0x00000410;
            break;
    case 2: data = 0x00003022;
            break;
    case 3: data = 0x00000810;
            break;
    case 4: data = 0x00000C10;
            break;
    default: data = 0x00003022;
            break;            
  }
  cpu_write(0x17001320, data);

  data = pcie_csr_read(pcie_core_id, SM_GLBL_DIAG_CSR_CFG_DIAG_SEL__ADDR);
  if(axi_shim) {
    lprintf(5,"Selecting the AXI shim over the PCIE for diag bus\n\r");
    data |= FIELD_CFG_DIAG_SEL_CFG_SHIM_BLK_DBUS_MUX_SELECT_MASK;
  } else {
    lprintf(5,"Selecting the PCIE over the AXI shim for diag bus\n\r");
    data &= ~FIELD_CFG_DIAG_SEL_CFG_SHIM_BLK_DBUS_MUX_SELECT_MASK;
  }
  if(axi) {
    lprintf(5,"Selecting AXI parameters for diag bus\n\r");
    data &= ~FIELD_CFG_DIAG_SEL_CFG_AXI_NON_AXI_MUX_SELECT_MASK;
  } else {
    lprintf(5,"Selecting PCIE parameters for diag bus\n\r");
    data |= FIELD_CFG_DIAG_SEL_CFG_AXI_NON_AXI_MUX_SELECT_MASK;
  }
  data = FIELD_CFG_DIAG_SEL_CFG_MUX_SELECTOR_SET(data, diagsel<<1);;
  pcie_csr_write(pcie_core_id, SM_GLBL_DIAG_CSR_CFG_DIAG_SEL__ADDR, data);

  lprintf(5,"Completed setting the generic controls to bring the debug bus out on GPIOs\n\r");
}  

void sm_pcie_setup_cntlr_axi_debug_hooks(uint32_t pcie_core_id, uint32_t master, uint32_t diagsel) {
  uint32_t data;

  lprintf(5,"Setting the controller AXI debug bus to capture ");
  if(master)
    lprintf(5,"master ");
  else
    lprintf(5,"slave ");
  lprintf(5,"request attributes.\n\r");

  switch(diagsel) {
    case 0: lprintf(5,"Selecting write request attributes\n\r");
            break;
    case 1: lprintf(5,"Selecting write response attributes\n\r");
            break;
    case 2: lprintf(5,"Selecting read request attributes\n\r");
            break;
    default: lprintf(5,"Invalid option.0 will be returned on the controller AXI debug bus.\n\r");
            break;
  }

  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_I_DEBUG__ADDR);
  data |= diagsel;
  data |= (master << 4);
  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_I_DEBUG__ADDR, data);
}  

void sm_pcie_setup_cntlr_pcie_debug_hooks(uint32_t pcie_core_id, uint32_t lane, uint32_t diagsel) {
  uint32_t data;

  lprintf(5,"Setting the controller PCIE debug bus.\n\r");

  if(lane > 7)
    lprintf(5,"Caution: Setting the controller PCIE debug bus to nonexistent lane\n\r");
  if(diagsel > 7)
    lprintf(5,"Caution: Setting the diagsel to invalid option. Valid values are 0-7. 0 will be returned on controller PCIE debug bus\n\r");
// p_debug[15:12]=phy_rx_data
// p_debug[11]=phy_rx_data_valid
// p_debug[10]=phy_rx_start_block
// p_debug[9] = phy_rx_status[2] // phy-reported error
// p_debug[8] = phy_rcv_det // i.e. phy_rx_status[1:0] == 2'b11.
// p_debug[7] = phy_rx_valid
// p_debug[6] = phy_rx_elec_idle
// p_debug[5] = phy_phy_status
// p_debug[4] = phy_tx_detect_rx_loopback
// p_debug[3:2] = phy_rate
// p_debug[1:0] = phy_power_down

  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_P_DEBUG__ADDR);
  data |= lane;
  data |= (diagsel << 4);
  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_P_DEBUG__ADDR, data);
}

void sm_pcie_setup_pipe_debug_hooks(uint32_t pcie_core_id, uint32_t diagsel) {
  uint32_t data;

  lprintf(5,"Setting the PIPE debug bus.\n\r");

  if(diagsel > 5)
    lprintf(5,"Caution: Setting invalid option for PIPE debug bus mux sel. Valid values are 0-5.\n\r.");

  data = pcie_phy_csr_read(pcie_core_id, KC_PIPE_REGS_PIPE_CONTROL__ADDR);
  data = ((data & ~FIELD_PIPE_CONTROL_DEBUG_MUX_SEL_MASK) | (diagsel << FIELD_PIPE_CONTROL_DEBUG_MUX_SEL_SHIFT_MASK));
  pcie_phy_csr_write(pcie_core_id, KC_PIPE_REGS_PIPE_CONTROL__ADDR, data);

}  

void sm_pcie_init_rc(uint32_t pcie_core_id, uint32_t gen, uint32_t ext_ref, uint32_t link_width) {

  sm_pcie_init_ecc(pcie_core_id);
  lprintf(3,"ECC init done\n\r");

  lprintf(5,"Initializing the clkrst module to enable the csr clks and deassert the csr resets.\n\r");
  sm_pcie_init_csr_clkrst(pcie_core_id);

  sm_pcie_init_phy(pcie_core_id, RC, gen, ext_ref, link_width, 0);

  sm_pcie_hack_for_kc(pcie_core_id);

#ifdef SIMULATION  
  sm_pcie_hack_for_sim(pcie_core_id, gen);
#endif

  sm_pcie_release_phy_reset(pcie_core_id);

  sm_pcie_wait_phy_rdy(pcie_core_id);

  lprintf(5,"Initializing the controller for RC mode\n\r");
  sm_pcie_init_ctrl_rc(pcie_core_id, gen);
  sm_pcie_init_ven_msg_capture(pcie_core_id);
};
  
void sm_pcie_init_ep(uint32_t pcie_core_id, uint32_t gen, uint32_t ext_ref, uint32_t link_width) {

  sm_pcie_init_ecc(pcie_core_id);
  lprintf(3,"ECC init done\n\r");

  lprintf(5,"Initializing the clkrst module to enable the csr clks and deassert the csr resets.\n\r");
  sm_pcie_init_csr_clkrst(pcie_core_id);

  sm_pcie_init_phy(pcie_core_id, EP, gen, ext_ref, link_width, 0);

  sm_pcie_hack_for_kc(pcie_core_id);

#ifdef SIMULATION  
  sm_pcie_hack_for_sim(pcie_core_id, gen);
#endif

  sm_pcie_release_phy_reset(pcie_core_id);

  sm_pcie_wait_phy_rdy(pcie_core_id);

  lprintf(5,"Initializing the controller for EP mode\n\r");
  sm_pcie_init_ctrl_ep(pcie_core_id, gen);
};

#ifndef VBIOS
#define MSDELAY(val)    {do sm_host_delay_ns(100000); while(val--);}
#endif

uint32_t ltssm_sub(uint32_t pcie_core_id, uint32_t *status) {
  uint32_t i=*status, j=*status;
  uint32_t data,data2;
  
  do {
      *status = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_PCIECORE_LTSSM__ADDR);
      data2 = *status & FIELD_PCIECORE_LTSSM_S_LTS_STATE_MASK;
      data  = (*status & FIELD_PCIECORE_LTSSM_S_LTS_SUB_STATE_MASK) >> FIELD_PCIECORE_LTSSM_S_LTS_SUB_STATE_SHIFT_MASK;
      if ((data2 == 3)&&(data == 2)) 
        break;
      if (j > 0) 
        MSDELAY(10);
  } while (i-- > 0);
 // data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_31_0__ADDR);
 // lprintf(5,"LTSSM_STATUS: lts_state = "); putnum(*status & FIELD_PCIECORE_LTSSM_S_LTS_STATE_MASK); lprintf(5," and lts_substate = "); putnum((*status & FIELD_PCIECORE_LTSSM_S_LTS_SUB_STATE_MASK) >> FIELD_PCIECORE_LTSSM_S_LTS_SUB_STATE_SHIFT_MASK); lprintf(5,"\n\r");
//  lprintf(5,"LINK Width: "); putnum((data & 0xfc000000)>>26); lprintf(5," current link speed = "); putnum((data & 0x03000000) >> 24); lprintf(5,"\n\r");
//  sm_pcie_chk_eq_result(pcie_core_id);
  return data;
}

int ltssm(int argc, char *argv[]) {
  uint32_t status, pcie_core_id;
  uint32_t loop, data;

  if (argc < 2){
    lprintf(3,"not enough argument. port, loop \n\r");
  }
  pcie_core_id = atoi(argv[0]);
  loop = atoi(argv[1]);
  if (pcie_core_id>4) {
      lprintf(3,"wrong argument. port=0~4\n\r");
  }


  do {
	  status = 0;
	  data = ltssm_sub(pcie_core_id, &status);

	  status = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_PCIECORE_LTSSM__ADDR);
	  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_31_0__ADDR);
	  printf("LTSSM_STATUS: lts_state = %d and lts_substate = %d",status & FIELD_PCIECORE_LTSSM_S_LTS_STATE_MASK,(status & FIELD_PCIECORE_LTSSM_S_LTS_SUB_STATE_MASK) >> FIELD_PCIECORE_LTSSM_S_LTS_SUB_STATE_SHIFT_MASK);
	  printf("\n\r");
	  printf("Link Status Gen%dx%d \n\r",((data & 0x03000000) >> 24)+1,((data & 0xfc000000)>>26) );

  } while (loop--);
  return data;
}

int pcie_ltssm(int argc, char *argv[]) {
  uint32_t status, pcie_core_id;
  uint32_t loop, data;

  if (argc < 2){
    lprintf(3,"not enough argument. port, loop \n\r");
  }
  pcie_core_id = atoi(argv[0]);
  loop = atoi(argv[1]);

  do {
      status = 400;
      data = ltssm_sub(pcie_core_id, &status); 
  } while (loop--);
  return data;
}

int pcie_relink_sub(uint32_t pcie_core_id, uint32_t gen_match, uint32_t cnt)
{
    int i,j, k, devid, class, linkerr;
    uint32_t data, gen, width, status, link_width, link_speed, expected_width, expected_speed;
	uint32_t timeout=30000;
    static uint32_t counter=0; 
    expected_width = gen_match >> 8;
    expected_speed = gen_match & 0x0f;
    sm_pcie_setup_ob_cfg(pcie_core_id, RC);             
    sm_pcie_setup_ob_space(pcie_core_id, RC); 
    for (i=0;i<cnt;i++) {
        //set hot reset to retrain the link
        lprintf(5,"HOT RESET of relink %d\n\r", i);
        data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_INT__ADDR);
        data = data | 0x400000;
        pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_INT__ADDR, data);
                           
        //clear hot reset
        MSDELAY(10);
        data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_INT__ADDR);
        data = data & ~(0x400000);
        pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_INT__ADDR, data);

        //check linkup status
        status = 400;
        data = ltssm_sub(pcie_core_id, &status); 
        
        data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_31_0__ADDR);
        link_width = (data & 0xfc000000) >> 26;
        link_speed = (data & 0x03000000)>>24 ;
        if(link_width != expected_width) {
            lprintf(4,"link width missmatch \n\r");
            break;
        }
        if(link_speed != expected_speed) {
            lprintf(4,"link speed missmatch \n\r");
            break;
        }
        MSDELAY(400);
        //clear error status
        pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_CORR_ERR_STAT__ADDR, 0xffff);
        
        //do a outbound cfg read to check link is stable
        data = 0xffffffff;
        do{
        data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR);
		timeout--;
        }while ( timeout &&(data == 0xffffffff));
		if(!timeout){
		//  lprintf(5,"Bug - > BUG_44393 \n\r ");
		  return(data);
		}
     //   lprintf(5,"PCI DEV/VEN ID %x \n\r", data);
        data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_CLASS__ADDR);
        //lprintf(5,"PCI CLASS %x \n\r", data);
        
        data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_CORR_ERR_STAT__ADDR);
        linkerr = ((data & 0x10FF) != 0);
        if(linkerr) lprintf(5,"link error 0x%x \n\r", data);


        lprintf(5,"256 cfg read request \n\r");
        for (k=0; k<256; k++) {
        devid = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR);
        class = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_CLASS__ADDR);
        }

        lprintf(5,"PCI DEV/VEN ID %x \n\r", devid);
        lprintf(5,"PCI CLASS %x \n\r", class);
        data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_CORR_ERR_STAT__ADDR);
        linkerr = ((data & 0x10FF) != 0);
        if(linkerr) lprintf(5,"link error 0x%x \n\r", data);
      //  lprintf(5,"\n");
    }
    return data;
}

int pcie_relink(int argc, char *argv[])
{
    uint32_t gen_match = 0;     // width-gen
    uint32_t pcie_core_id;
    uint32_t cnt, data, width, gen,link_width;

    if (argc < 4){
       lprintf(3,"not enough argument portid, count, gen(0, 1, 2), width\n\r");
       return -1;
    } else {
        pcie_core_id = atoi(argv[0]);
        cnt = atoi(argv[1]);
        gen = atoi(argv[2]);
        width = atoi(argv[3]);
    }
    gen_match = (width << 8) | gen;
    data = pcie_relink_sub(pcie_core_id, gen_match, cnt);

    return(data);
}


int gpiods_set(int argc, char *argv[]){
u32 val, pin;
    
if (argc < 1){
    lprintf(3,"argument: pin# \n\r");
    return -1;
}
else
    pin = atoi(argv[0]);

val = cpu_read(0x17001294);
//lprintf(5,"GPIO sel 0x%x \n\r", val);
val &= ~(0x0f<<pin);
cpu_write(0x17001294, val);

val = cpu_read(0x1700129c);
//lprintf(5,"GPIO OE 0x%x \n\r", val);
val |= 1<<pin;
cpu_write(0x1700129c, val);

val = cpu_read(0x170012a0);
//lprintf(5,"GPIO 0x%x \n\r", val);
cpu_write(0x170012a0, val|(1<<pin));
}

int gpiods_clr(int argc, char *argv[]){
u32 val, pin;

if (argc < 1){
    lprintf(5,"argument: pin# \n\r");
    return -1;
}
else
    pin = atoi(argv[0]);

val = cpu_read(0x17001294);
//lprintf(5,"GPIO sel 0x%x \n\r", val);
val &= ~(0x0f<<pin);
cpu_write(0x17001294, val);

val = cpu_read(0x1700129c);
//lprintf(5,"GPIO OE 0x%x \n\r", val);
val |= 1<<pin;
cpu_write(0x1700129c, val);

val = cpu_read(0x170012a0);
//lprintf(5,"GPIO 0x%x \n\r", val);
cpu_write(0x170012a0, val & ~(1<<pin));
}

void pcie_reset(int argc, char *argv[])
{
    uint32_t data, slots = 7, toggle=3; 

    if (argc > 0) {
        slots = atoi(argv[0]); toggle = 0;
        if (slots==0) 
          toggle |= 1;
        else if (slots == 2) 
          toggle |= 2; 
    }
 
    pcie_reset_sub(toggle);
    lprintf(5,"PCIe slot reset done, argu=0/2/none for slot 0/2/0+2\n");
}

void pcie_reset_sub(uint32_t toggle)
{
    uint32_t data; 

#ifndef BOARD_MUSTANG2

    data = cpu_read(0x17001294);  //as GPIO
    data &= ~(0x0f<<24);
    cpu_write(0x17001294, data);

    data = cpu_read(0x1700129c);  //as outputs
    data |= 3<<12;
    cpu_write(0x1700129c, data);

    data = cpu_read(0x170012a0);
    cpu_write(0x170012a0, data | (toggle<<12));

    MSDELAY(500);
    data &= ~(toggle<<12);
    cpu_write(0x170012a0, data);
    MSDELAY(10);
#else
    // cfg_pin_mux_sel_2   Alternatate funation as GPIO
    data=cpu_read(0x1f2a0170);
    lprintf(5, "CFG_PIN_MUX_SEL_2 : 0x%x \n\r ",data) ;  //as GPIO  0x1f2a0170;
    data |= 0xC;
    cpu_write(0x1f2a0170, data);
    lprintf(5, "CFG_PIN_MUX_SEL_2 : 0x%x\n\r ",cpu_read(0x1f2a0170)) ;  //as GPIO  0x1f2a0170;

   // GPIO_SWPORTA_DDR
    data=cpu_read(0x1c024004);
    lprintf(5, "GPIO_SWPORTA_DDR : 0x%x \n\r ",data) ;  //as GPIO  0x1f2a0170;
    data |= 0x2000000;
    cpu_write(0x1c024004, data);
    lprintf(5, "GPIO_SWPORTA_DDR : 0x%x\n\r ",cpu_read(0x1c024004)) ;  //as GPIO  0x1f2a0170;

    data=cpu_read(0x1c024008);
    lprintf(5, "GPIO_PORTA_CTL_HW/SW : 0x%x \n\r ",data) ;  //as GPIO  0x1f2a0170;
 //   data |= 0x1;
 //   cpu_write(0x1c024008, data);

    // GPIO_SWPORTA_DR  TURN TO ZERO
      data=cpu_read(0x1c024000);
      lprintf(5, "GPIO_SWPORTA_DR : 0x%x \n\r ",data) ;  //as GPIO  0x1f2a0170;
      data &= ~0x2000000;
      cpu_write(0x1c024000, data);

      MSDELAY(10);


    // GPIO_SWPORTA_DDR
     data=cpu_read(0x1c024000);
     lprintf(5, "GPIO_SWPORTA_DR : 0x%x \n\r ",data) ;  //as GPIO  0x1f2a0170;
     data |= 0x2000000;
     cpu_write(0x1c024000, data);
     lprintf(5, "GPIO_SWPORTA_DR : 0x%x \n\r ",cpu_read(0x1c024000)) ;  //as GPIO  0x1f2a0170;

#endif

    lprintf(5,"PCIe slot reset done, argu=0/2/none for slot 0/2/0+2\n");
}
void prep_diag_mode(uint32_t pcie_core_id,uint32_t len)
{

  uint32_t data=0;

  lprintf(5,"ENABLING DIAG MODE MEASUREMENT  \n\r");

   data= pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR));
   data = 0x00000000;
   pcie_csr_write(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR),data); // Disable any running calculation

   data= pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_BW_MSTR_STOP_CNT__ADDR)); // Configure length
   data = ( (   (len/1024) << 16  ) | (len/1024) )  ; // Same Len for READ & WRITE

   pcie_csr_write(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_BW_MSTR_STOP_CNT__ADDR),data) ; // Configure RD length

 /* data= pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_BW_SLV_STOP_CNT__ADDR)); // Configure length
  data =0x2000200; // 512k RD

  pcie_csr_write(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_BW_SLV_STOP_CNT__ADDR),data) ; // Configure RD length
*/
   data= pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_BW_MSTR_STOP_CNT__ADDR)); // Configure length
   lprintf(5,"Total SIZE configured : = 0x%x \n\r",data);

   data=0x000000f;
   pcie_csr_write(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR),data) ; // Start

  lprintf(5, "CFG START_STOP_STATUS := 0x%x \n\r",
     	    pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR)));

  lprintf(5, "Clock Count  := 0x%x \n\r",
  pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_STS_AXI_MRD_BW_CLK_CNT__ADDR)));

  lprintf(5, "Byte Count := 0x%x \n\r",
  pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_STS_AXI_MRD_BW_BYTE_CNT__ADDR)));

}


extern uint32_t perf_number[100];

void print_M_AXI_WR_RD(uint32_t pcie_core_id,uint32_t mode)
{

  uint32_t data=0,data_rd=0,data_wr=0,
		   rd_bw=0,rd_time=0,
		   wr_bw=0,wr_time=0;

static uint32_t cnt =0;

if(cnt==100)
cnt=0;

// To know AXI CLOCK Freq.,

  lprintf(5,"SCU_SOCIOBAXIDIV = 0x%x \n\r", cpu_read(0x17000150));
  lprintf(5,"SCU_SOCAXIDIV = 0x%x \n\r", cpu_read(0x17000160));

  if(mode==RD)
  {
	  // to know how many bytes were observed
    data_rd=pcie_csr_read( pcie_core_id, (SM_GLBL_DIAG_CSR_STS_AXI_MRD_BW_BYTE_CNT__ADDR) );
    rd_time=pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_STS_AXI_MRD_BW_CLK_CNT__ADDR))<<2; //*4 to get ns

    lprintf(5," ******************************************************** \n\r") ;
    lprintf(5," *** Total AXI Read BW  (AXI to PCIE OB-WRITE)  ***      \n\r");
    lprintf(5," ******************************************************** \n\r") ;
    lprintf(5,"\n\r");

    lprintf(5,"Total Bytes Read from AXI:  0x%lx \n\r", data_rd);
    lprintf(5,"Total READ time: %d ns (%d AXI cycles)\n\r", rd_time, rd_time>>2);

    rd_bw = (SEC_2_NS_CONST/rd_time) * (data_rd >>10) ;   //KB/s
    rd_bw=( 8 * rd_bw ) >> 10;             // Mb/s


#ifdef CONFIG_ARCH_TIMER
 //   data_rd
 //   rd_time
 //   rd_bw
#endif


  //  lprintf(5," * Total Read-time: %d ns (%d AXI cycles) \n\r * For Reading Bytes : 0x%lx = \n\r", rd_bw>>2,rd_bw,data_rd);
    lprintf(5,"Total Data Throughput: %d Mb/s = %d MB/s\n\n", rd_bw, rd_bw>>3);

    RD_BW_g=rd_bw;

    cnt++;
    perf_number[cnt]=rd_bw;

    pcie_csr_write(pcie_core_id,SM_GLBL_DIAG_CSR_STS_AXI_MRD_BW_CLK_CNT__ADDR,0);
    pcie_csr_write(pcie_core_id,SM_GLBL_DIAG_CSR_STS_AXI_MRD_BW_BYTE_CNT__ADDR,0);

    lprintf(5," *********************************************** \n\r");

  }

  // Calculation Part in terms of MB/s for write
  else
  {
    data_wr=pcie_csr_read( pcie_core_id, (SM_GLBL_DIAG_CSR_STS_AXI_MWR_BW_BYTE_CNT__ADDR) );
    wr_time=pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_STS_AXI_MWR_BW_CLK_CNT__ADDR)) <<2 ; //*4 to get ns

    lprintf(5," ******************************************************** \n\r") ;
    lprintf(5," *** Total AXI Write BW  (PCIE to AXI OB-READ)  ***       \n\r");
    lprintf(5," ******************************************************** \n\r") ;
    lprintf(5,"\n\r");


   lprintf(5,"Total Bytes Written to AXI = 0x%lx \n\r",
 		  pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_STS_AXI_MWR_BW_BYTE_CNT__ADDR)));

    lprintf(5,"Total AXI Cycles used to Write= 0x%lx\n\r",
   		  pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_STS_AXI_MWR_BW_CLK_CNT__ADDR)));


   lprintf(5,"Total Bytes WRITE from AXI: %d\n\r", data_wr);
   lprintf(5,"Total WRITE time: %d ns (%d AXI cycles)\n", wr_time, wr_time>>2);

    wr_bw = (SEC_2_NS_CONST/wr_time) * (data_wr >>10) ;   //KB/s
    wr_bw= (8 * wr_bw) >> 10;             // Mb/s
    lprintf(5,"Total Data Throughput: %d Mb/s = %d MB/s\n\r", wr_bw, wr_bw>>3);


#ifdef CONFIG_ARCH_TIMER

#endif


    WR_BW_g=wr_bw;

    cnt++;
    perf_number[cnt]=wr_bw;

    pcie_csr_write(pcie_core_id,SM_GLBL_DIAG_CSR_STS_AXI_MWR_BW_CLK_CNT__ADDR,0);
    pcie_csr_write(pcie_core_id,SM_GLBL_DIAG_CSR_STS_AXI_MWR_BW_BYTE_CNT__ADDR,0);
    lprintf(5," *********************************************** \n\r");
  }
}

void print_S_AXI_WR_RD(uint32_t pcie_core_id,uint32_t mode)
{
	// to know how many bytes were observed
	lprintf(5,"SLAVE AXI \n\r");
    lprintf(5,"Total Bytes Writeen to AXI = %d \n\r",
			  pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_STS_AXI_SWR_BW_BYTE_CNT__ADDR)));
    lprintf(5,"Total AXI Cycles used to Write= %d \n\r",
	  		  pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_STS_AXI_SWR_BW_CLK_CNT__ADDR)));
    lprintf(5,"Total Bytes READ from AXI = %d\n\r",
			  pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_STS_AXI_SRD_BW_BYTE_CNT__ADDR)));
    lprintf(5,"Total AXI Cycles used to READ = %d \n\r",
	  		  pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_STS_AXI_SRD_BW_CLK_CNT__ADDR)));
}

//support x8 mode slot 0/2 only
int linkup(int argc, char *argv[]) {
  uint32_t gen, port0rc = 0;
  uint32_t i = 0, status;

  if (argc < 1) i = 1;
  gen = atoi(argv[0]);
  if (gen>2) i = 2;
  if (argc > 1) {
    port0rc = atoi(argv[1]);
    if (port0rc !=0) 
        port0rc = 1;
  }
  if (i) {
    lprintf(3,"not enough argument: gen [reverse] \n\r");
    return i;
  } 
  sm_pcie_init(0, port0rc, 0, gen, 1, 8, 0);
  sm_pcie_init(3, (port0rc?0:1), 0, gen, 1, 8, 0);
  status = 400;
  i = ltssm_sub(0, &status); 
  return i;
}

int gpio_uart(int argc, char *argv[]){
  uint32_t i = 0, data, gpio;
  if (argc < 2) {
    lprintf(3,"not enough argument: gpio#, wrdata \n\r");
    return i;
  } 

  gpio = atoi(argv[0]);
  i = atoi(argv[1]) ? 1: 0;

  lprintf(5,"GPIO # %d, value %d \n\r", gpio, i);
  
  data = cpu_read(0x1f2ac008);
  data |= 0x4;   //enable gpio clk
  cpu_write(0x1f2ac008, data);

  data = cpu_read(0x1f2ac000);
  data = data & ~0x4;   //clear gpio rst
  cpu_write(0x1f2ac000, data);

  data = cpu_read(0x1c024000);
  if(i)
    data = data | (1<<gpio);   //write GPIO value 
  else
    data = data & ~(1<<gpio);
  cpu_write(0x1c024000, data);
  
  if(gpio<=7) {
    data = cpu_read(0x1f2a0168);
    data |= 3<<(gpio*2);              //cfg pin mux select for gpio 0 ~ 7
    cpu_write(0x1f2a0168, data);
  } else if (gpio >7 && gpio <= 23) {
    data = cpu_read(0x1f2a016c);
    data |= 3<<((gpio-8)*2);         //cfg pin mux select for gpio 8 ~ 23
    cpu_write(0x1f2a016c, data);
  } else {
    data = cpu_read(0x1f2a0170);
    data |= 3<<((gpio-24)*2);         //cfg pin mux select for gpio 24 ~ 31
    cpu_write(0x1f2a0170, data);
  }

  data = cpu_read(0x1c024004);
  data |= 1<<gpio;              //set GPIO direction
  cpu_write(0x1c024004, data);

}

int sds_pd(int argc, char *argv[]){
  uint32_t pcie_core_id, sds, sds2_offset, data, i=0, ch;
  if (argc < 2) {
    lprintf(3,"not enough argument: ip core#, serdes# \n\r");
    return i;
  } 

  pcie_core_id = atoi(argv[0]);
  sds = atoi(argv[1]);
  
  if (sds){
    sds2_offset = 0x30000;
  } else {
    sds2_offset = 0x0;
  }
   
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG0__ADDR + sds2_offset);
  data = FIELD_CMU_REG0_PDOWN_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG0__ADDR + sds2_offset, data);
  
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG1__ADDR + sds2_offset);
  data = FIELD_CMU_REG1_PLL_PDOWN_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG1__ADDR + sds2_offset, data);

  for (ch = 0; ch<4; ch++) {
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG2_TX_PDOWN_SET(data, 0x1);
  data = FIELD_CH0_RXTX_REG2_RXPDBIAS_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG12_RX_PDOWN_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + sds2_offset, data);
  }
}

void clkmacro_cal(uint32_t pcie_core_id) {
 uint32_t data, pvt_done;

 data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_CLK_MACRO_REG__ADDR); //Hardcoding address as Define needs change
 data = FIELD_PCIE_CLK_MACRO_REG_I_RESET_B_SET(data, 0x0);
 data = FIELD_PCIE_CLK_MACRO_REG_I_PLL_FBDIV_SET(data, 0x27);
 data = FIELD_PCIE_CLK_MACRO_REG_I_CUSTOMEROV_SET(data, 0x0);
 data = FIELD_PCIE_CLK_MACRO_REG_I_OE_SET(data, 0x3);
 pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_CLK_MACRO_REG__ADDR, data);
 

 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG34__ADDR );
 data = FIELD_CMU_REG34_VCO_CAL_VTH_LO_MAX_SET(data, 0x7);
 data = FIELD_CMU_REG34_VCO_CAL_VTH_HI_MAX_SET(data, 0xd);
 data = FIELD_CMU_REG34_VCO_CAL_VTH_LO_MIN_SET(data, 0x2);
 data = FIELD_CMU_REG34_VCO_CAL_VTH_HI_MIN_SET(data, 0x8);
 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG34__ADDR , data);

 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG0__ADDR);
 data =  FIELD_CMU_REG0_CAL_COUNT_RESOL_SET(data, 0x6);
 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG0__ADDR, data);

 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG1__ADDR);
 data =  FIELD_CMU_REG1_PLL_CP_SET(data, 0x1);     
 data =  FIELD_CMU_REG1_PLL_CP_SEL_SET(data, 0x1);
 data = FIELD_CMU_REG1_PLL_MANUALCAL_SET(data, 0x0);
 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG1__ADDR, data);

 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG2__ADDR);
 data =  FIELD_CMU_REG2_PLL_LFRES_SET(data, 0x1);
 data = FIELD_CMU_REG2_PLL_REFDIV_SET(data, 0x1);
 data = FIELD_CMU_REG2_PLL_FBDIV_SET(data, 0x4f);
 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG2__ADDR, data); 

 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG3__ADDR);
 data = FIELD_CMU_REG3_VCOVARSEL_SET(data,0xf);
 data = FIELD_CMU_REG3_VCO_MOMSEL_INIT_SET(data,0x10); 
 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG3__ADDR, data);

 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG26__ADDR);
 data = FIELD_CMU_REG26_FORCE_PLL_LOCK_SET(data,0x0);
 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG26__ADDR, data);


 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG5__ADDR);
 data = FIELD_CMU_REG5_PLL_LFSMCAP_SET(data,0x0); 
 data = FIELD_CMU_REG5_PLL_LFCAP_SET(data,0x3); 
 data = FIELD_CMU_REG5_PLL_LOCK_RESOLUTION_SET(data,0x7);
 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG5__ADDR, data);

 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG6__ADDR);
 data = FIELD_CMU_REG6_PLL_VREGTRIM_SET(data,0x0); 
 data = FIELD_CMU_REG6_MAN_PVT_CAL_SET(data,0x1); 
 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG6__ADDR, data);

 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR);
 data = FIELD_CMU_REG16_CALIBRATION_DONE_OVERRIDE_SET(data,0x1);
 data = FIELD_CMU_REG16_BYPASS_PLL_LOCK_SET(data,0x1); 
 data = FIELD_CMU_REG16_VCOCAL_WAIT_BTW_CODE_SET(data,0x6);
 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR, data);

 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG30__ADDR);
 data = FIELD_CMU_REG30_PCIE_MODE_SET(data,0x0); 
 data = FIELD_CMU_REG30_LOCK_COUNT_SET(data,0x3); 
 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG30__ADDR, data);

 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG31__ADDR, 0xF);

 data = pcie_phy_csr_read(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG32__ADDR);
 data |= 0x0006 | 0x0180;
 data = FIELD_CMU_REG32_PVT_CAL_WAIT_SEL_SET(data,0x3);
 data = FIELD_CMU_REG32_IREF_ADJ_SET(data,0x0); 
 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG32__ADDR, data);

 pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG34__ADDR, 0x8d27);

 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG37__ADDR);
 pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG37__ADDR, 0xF00F);

  data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG12__ADDR);
  data = FIELD_CMU_REG12_STATE_DELAY9_SET(data, 0x0);  //ready_count top
  pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG12__ADDR, data);
    
  data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG13__ADDR);
  data = FIELD_CMU_REG13_STATE_DELAY1_SET(data, 0xf); //calib_start_count_stop
  data = FIELD_CMU_REG13_STATE_DELAY2_SET(data, 0x0);//channel_start_count_stop
  data = FIELD_CMU_REG13_STATE_DELAY3_SET(data, 0x0);//reset_count_stop
  data = FIELD_CMU_REG13_STATE_DELAY4_SET(data, 0x0);//start_ctle_cal_count
  pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG13__ADDR, data);
  
  data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG14__ADDR);
  data = FIELD_CMU_REG14_STATE_DELAY5_SET(data, 0x0); //float_tap_src_ena_count_stop
  data = FIELD_CMU_REG14_STATE_DELAY6_SET(data, 0x0); //float_tap_src_count_stop
  data = FIELD_CMU_REG14_STATE_DELAY7_SET(data, 0x0); //blwc_ena_count_stop
  data = FIELD_CMU_REG14_STATE_DELAY8_SET(data, 0x0); //ready_count_stop
  pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG14__ADDR, data);
 
 data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_CLK_MACRO_REG__ADDR); //Hardcoding address as Define needs change
 data = FIELD_PCIE_CLK_MACRO_REG_I_RESET_B_SET(data, 0x1);
 pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_CLK_MACRO_REG__ADDR, data);
 
 MSDELAY(100);
 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG0__ADDR); //Hardcoding address as Define needs change
 data = FIELD_CMU_REG0_RESETB_SET(data, 0x0);
 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG0__ADDR , data);

 MSDELAY(50);
 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG0__ADDR); //Hardcoding address as Define needs change
 data = FIELD_CMU_REG0_RESETB_SET(data, 0x1);
 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG0__ADDR, data);
 
 /* NOTE: not sure where to insert this when we need it
   lprintf(5,"Enabling the SSC for the CLKMACRO\n\r");
    data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG36__ADDR);
    data |= FIELD_CMU_REG36_PLL_SSC_EN_MASK;
    pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG36__ADDR, data);
   */

pvt_done = 0;
//do {
//pvt_cal(pcie_core_id);
    lprintf(5,"wait for CMU CALIB done \n\r");
    data = 0;
    do {
    data = pcie_phy_csr_read(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG7__ADDR);
    } while(!FIELD_CMU_REG7_PLL_CALIB_DONE_RD(data));

    pvt_done = !FIELD_CMU_REG7_VCO_CAL_FAIL_RD(data);
    if(!pvt_done) {
        lprintf(5,"CMU VCO CALIB FAIL \n\r");
        
        data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_CLK_MACRO_REG__ADDR); //Hardcoding address as Define needs change
        data = FIELD_PCIE_CLK_MACRO_REG_I_RESET_B_SET(data, 0x0);
        pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_CLK_MACRO_REG__ADDR, data);
 
        data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_CLK_MACRO_REG__ADDR); //Hardcoding address as Define needs change
        data = FIELD_PCIE_CLK_MACRO_REG_I_RESET_B_SET(data, 0x1);
        pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_CLK_MACRO_REG__ADDR, data);
        vco_restart(pcie_core_id);
        
    }
//} while(!pvt_done);
lprintf(5,"clkmacro calibration done \n\r");
/*
 lprintf(5,"clkmacro waiting PLL lock.... \n\r");
    do {
        data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_CLK_MACRO_REG__ADDR);
       // lprintf(5,"Read data is"); putnum(data); lprintf(5,"Polling pll lock for CLK MACRO\n\r");
    } while (!(FIELD_PCIE_CLK_MACRO_REG_O_PLL_LOCK_RD(data) && FIELD_PCIE_CLK_MACRO_REG_O_PLL_READY_RD(data)));
*/
    MSDELAY(800);
}


int vco_pd(int argc, char *argv[]){
  uint32_t core, i=0;
  if (argc < 1) {
    lprintf(3,"not enough argument: core_id \n\r");
    return i;
  } 

  core = atoi(argv[0]);
  vco_restart(core);
}

void  vco_restart (uint32_t pcie_core_id) {
    unsigned int data;
  
     data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG0__ADDR);
     data = FIELD_CMU_REG0_PDOWN_SET(data, 1);
     pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG0__ADDR, data);

    data = pcie_phy_csr_read (pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG5__ADDR);
    data = FIELD_CMU_REG5_PLL_RESETB_SET(data,0);
    pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG5__ADDR, data);
 
    MSDELAY(800);
    data = pcie_phy_csr_read (pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG5__ADDR);
    data = FIELD_CMU_REG5_PLL_RESETB_SET(data,1);
    pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG5__ADDR, data);
 
     data = pcie_phy_csr_read (pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG0__ADDR);
     data = FIELD_CMU_REG0_PDOWN_SET(data, 0);
     pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG0__ADDR, data);

     data = pcie_phy_csr_read (pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG32__ADDR);
     data = FIELD_CMU_REG32_FORCE_VCOCAL_START_SET(data, 1);
     pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG32__ADDR, data);
    MSDELAY(800);
     
     data = pcie_phy_csr_read (pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG32__ADDR);
     data =  FIELD_CMU_REG32_FORCE_VCOCAL_START_SET(data, 0);
     pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG32__ADDR, data);
}

void pvt_cal(uint32_t pcie_core_id){
uint32_t data;

// ********************
// TERM CALIBRATION 
// ********************
 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR);
 data = FIELD_CMU_REG17_PVT_CODE_R2A_SET(data,0x0d);
 data = FIELD_CMU_REG17_RESERVED_7_SET(data,0x0); 
 pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR, data);

 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR);
 data = FIELD_CMU_REG17_PVT_TERM_MAN_ENA_SET(data,0x1);
 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR, data);
 
 data = pcie_phy_csr_read(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR);
 data = FIELD_CMU_REG17_PVT_TERM_MAN_ENA_SET(data,0x0);
 pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR, data);

// *********************
// DOWN CALIBRATION
// *********************
    data = pcie_phy_csr_read(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR);
    data = FIELD_CMU_REG17_PVT_CODE_R2A_SET(data,0x26);
    data = FIELD_CMU_REG17_RESERVED_7_SET(data,0x0); 
    pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR, data);

    data = pcie_phy_csr_read(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR);
    data = FIELD_CMU_REG16_PVT_DN_MAN_ENA_SET(data,0x1);
    pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR, data);

    data = pcie_phy_csr_read(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR);
    data = FIELD_CMU_REG16_PVT_DN_MAN_ENA_SET(data,0x0);
    pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR, data);

 // *********************
// UP CALIBRATION
// *********************
    data = pcie_phy_csr_read(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR);
    data = FIELD_CMU_REG17_PVT_CODE_R2A_SET(data,0x28);
    data = FIELD_CMU_REG17_RESERVED_7_SET(data,0x0); 
    pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR, data);

    data = pcie_phy_csr_read(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR);
    data = FIELD_CMU_REG16_PVT_UP_MAN_ENA_SET(data,0x1);
    pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR, data);

    data = pcie_phy_csr_read(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR);
    data = FIELD_CMU_REG16_PVT_UP_MAN_ENA_SET(data,0x0);
    pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR, data);
}

void set_preset(int pcie_core_id, int preset_num) {
int tx_coef, data;

data = pcie_csr_read(pcie_core_id,  NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_543_512__ADDR);
data = FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_543_512_CFG_CONSTANTS_EQ_COEF_HARDCODED_SET(data, 0x1);
pcie_csr_write(pcie_core_id,  NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_543_512__ADDR, data);

switch (preset_num)
{
case (0):  tx_coef = 0x0000ea00; break;
case (1):  tx_coef = 0x00009b40; break;
case (2):  tx_coef = 0x0000bac0; break;
case (3):  tx_coef = 0x00007bc0; break;
case (4):  tx_coef = 0x00000d80; break;
case (5):  tx_coef = 0x00000c45; break;
case (6):  tx_coef = 0x00000bc7; break;
case (7):  tx_coef = 0x0000b985; break;
case (8):  tx_coef = 0x00007a07; break;
case (9):  tx_coef = 0x00000b49; break;
case (10): tx_coef = 0x000138c0; break;
default: tx_coef = 0x0; break;
}

data = pcie_csr_read(pcie_core_id,  NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_543_512__ADDR);
data = FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_543_512_CFG_CONSTANTS_TX_COEF_SET(data, tx_coef);
pcie_csr_write(pcie_core_id,  NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_543_512__ADDR, data);
}

void set_sds_rxd_reset(int pcie_core_id, int ch, int sds2) {
int sds2_offset, data, timeout;

  if (sds2){
    sds2_offset = 0x30000;
  } else {
    sds2_offset = 0x0;
  }
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG7_RESETB_RXD_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset, data);
  MSDELAY(10);
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG7_RESETB_RXD_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset, data);

}

void short_sds_rxa_reset(int pcie_core_id, int ch, int sds2) {
int sds2_offset, data, timeout;

  if (sds2){
    sds2_offset = 0x30000;
  } else {
    sds2_offset = 0x0;
  }
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG7_RESETB_RXA_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset, data);
 for(timeout=0; timeout<0x4000; ++timeout);
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG7_RESETB_RXA_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset, data);

}

void set_tx_prbs(int pcie_core_id, int prbs_num){
int sds2_offset, ch, data, prbs;

lprintf(5,"enable TX PRBS,  core # 0x%x, prbs# %d \n\r", pcie_core_id, prbs_num);
switch (prbs_num){
case (7): prbs = 0; break;
case (9): prbs = 1; break;
case (11): prbs = 2; break;
case (23): prbs = 3; break;
case (31): prbs = 4; break;
default: prbs = 4; break;
}

if(pcie_core_id == 0 || pcie_core_id == 1 ||
   pcie_core_id == 3 || pcie_core_id == 4){  
  
  sds2_offset = 0;
  for(ch = 0; ch<4; ch++){
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG2_BIST_ENA_TX_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset, data);
  
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG4_TX_PRBS_SEL_SET(data, prbs);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR + (0x200 * ch) + sds2_offset, data);
  
  //reset TX digital logic
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG2_RESETB_TXD_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset, data);
  MSDELAY(10);
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG2_RESETB_TXD_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset, data);
  }
  
  if(pcie_core_id == 0 || pcie_core_id == 3){
      sds2_offset = 0x30000;
      for(ch = 0; ch<4; ch++){
      data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset);
      data = FIELD_CH0_RXTX_REG2_BIST_ENA_TX_SET(data, 0x1);
      pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset, data);
      
      data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR + (0x200 * ch) + sds2_offset);
      data = FIELD_CH0_RXTX_REG4_TX_PRBS_SEL_SET(data, prbs);
      pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR + (0x200 * ch) + sds2_offset, data);
      
      //reset TX digital logic
      data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset);
      data = FIELD_CH0_RXTX_REG2_RESETB_TXD_SET(data, 0x0);
      pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset, data);
      MSDELAY(10);
      data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset);
      data = FIELD_CH0_RXTX_REG2_RESETB_TXD_SET(data, 0x1);
      pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset, data);
      }
  }
} else if (pcie_core_id == 2) {
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR);
  data = FIELD_CH0_RXTX_REG2_BIST_ENA_TX_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR, data);
  
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR);
  data = FIELD_CH0_RXTX_REG4_TX_PRBS_SEL_SET(data, prbs);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR, data);
      
  //reset TX digital logic
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG2_RESETB_TXD_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset, data);
  MSDELAY(10);
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG2_RESETB_TXD_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset, data);
  }
}


void set_rx_prbs(int pcie_core_id, int prbs_num){
int sds2_offset, ch, data, prbs;

lprintf(5,"enable RX PRBS check, core # 0x%x, prbs# %d \n\r", pcie_core_id, prbs_num);
switch (prbs_num){
case (7): prbs = 0; break;
case (9): prbs = 1; break;
case (11): prbs = 2; break;
case (23): prbs = 3; break;
case (31): prbs = 4; break;
default: prbs = 4; break;
}

if(pcie_core_id == 0 || pcie_core_id == 3){  
  sds2_offset = 0;
  for(ch = 0; ch<4; ch++){
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG7_BIST_ENA_RX_SET(data, 0x1);
  data = FIELD_CH0_RXTX_REG7_RX_PRBS_SEL_SET(data, prbs);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset, data);
  }
  sds2_offset = 0x30000;
  for(ch = 0; ch<4; ch++){
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG7_BIST_ENA_RX_SET(data, 0x1);
  data = FIELD_CH0_RXTX_REG7_RX_PRBS_SEL_SET(data, prbs);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset, data);
  }
} else if (pcie_core_id == 2) {
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR);
  data = FIELD_CH0_RXTX_REG7_BIST_ENA_RX_SET(data, 0x1);
  data = FIELD_CH0_RXTX_REG7_RX_PRBS_SEL_SET(data, prbs);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR, data);
} else if (pcie_core_id == 1 || pcie_core_id == 4) {
  sds2_offset = 0;
  for(ch = 0; ch<4; ch++){
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG7_BIST_ENA_RX_SET(data, 0x1);
  data = FIELD_CH0_RXTX_REG7_RX_PRBS_SEL_SET(data, prbs);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset, data);
  }
}

}

void lat_summer_average_cal (int pcie_core_id, int link_width){

  lprintf(5,"Force LATCH/SUMER calibration\n\r");
if (pcie_core_id == 2) {
    lat_summer_cal(pcie_core_id, 0, 0);
} else {
    //core 0, 1, 3, 4 will use serder 0 all the time
    //core 0, 3 has option of programing second serdes if link_width is 8
    lat_summer_cal(pcie_core_id, 0, 0);
    lat_summer_cal(pcie_core_id, 1, 0);
    lat_summer_cal(pcie_core_id, 2, 0);
    lat_summer_cal(pcie_core_id, 3, 0);
    if(link_width == 8) {
        lat_summer_cal(pcie_core_id, 0, 1);
        lat_summer_cal(pcie_core_id, 1, 1);
        lat_summer_cal(pcie_core_id, 2, 1);
        lat_summer_cal(pcie_core_id, 3, 1);
    }
}
}

void lat_summer_cal (int pcie_core_id, int ch, int sds2) {

    int data, dfe_preset, dfe;
    int sum_cal_done, lat_cal_done, sum_cal_err;
    int timeout = 0;
    int loop = 10;
    int try = 10;
    int sds2_offset = 0;
    int fail_odd = 0;
    int fail_even = 0;
    int lat_do  = 0;
    int lat_xo  = 0;
    int lat_eo  = 0;
    int lat_so  = 0;
    int lat_de  = 0;
    int lat_xe  = 0;
    int lat_ee  = 0;
    int lat_se  = 0;
    int sum_cal = 0;
    int lat_do_tmp;
    int lat_xo_tmp;
    int lat_eo_tmp;
    int lat_so_tmp;
    int lat_de_tmp;
    int lat_xe_tmp;
    int lat_ee_tmp;
    int lat_se_tmp;
    int sum_cal_tmp;
    if(sds2)
        sds2_offset = 0x30000;
    else 
        sds2_offset = 0;
    
   //lprintf(5,"Manual latch/summer calibration core # 0x%x, ch #0x%x...\n\r", pcie_core_id, ch);
    
    //enable RX Hi-Z termination enable
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + sds2_offset);
    data = FIELD_CH0_RXTX_REG12_RX_DET_TERM_ENABLE_SET(data,0x1);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + sds2_offset, data);
    
    //clear CDR loop enable
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG8__ADDR + (0x200 * ch) + sds2_offset);
    data = FIELD_CH0_RXTX_REG8_CDR_LOOP_ENA_SET(data,0x0);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG8__ADDR + (0x200 * ch) + sds2_offset, data);

    //turn off DFE
    dfe = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG28__ADDR + (0x200 * ch) + sds2_offset);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG28__ADDR + (0x200 * ch) + sds2_offset, 0);

    //DFE presets to zero
    dfe_preset = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG31__ADDR + (0x200 * ch) + sds2_offset);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG31__ADDR + (0x200 * ch) + sds2_offset, 0);

    while (loop > 0){
        for(timeout=0; timeout<0x40000; ++timeout);
        //toggle summer cal 
        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * ch) + sds2_offset);
        data = FIELD_CH0_RXTX_REG127_FORCE_SUM_CAL_START_SET(data,0x1);
        pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * ch) + sds2_offset, data);

        for(timeout=0; timeout<0x40000; ++timeout);
        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * ch) + sds2_offset);
        data = FIELD_CH0_RXTX_REG127_FORCE_SUM_CAL_START_SET(data,0x0);
        pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * ch) + sds2_offset, data);

        do {
            data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG158__ADDR + (0x200 * ch) + sds2_offset);
            sum_cal_done =  FIELD_CH0_RXTX_REG158_SUM_CALIB_DONE_RD(data);
            sum_cal_err = FIELD_CH0_RXTX_REG158_SUM_CALIB_ERR_RD(data);
            MSDELAY(1);
        }while(!sum_cal_done && try--);
        
        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG121__ADDR + (0x200 * ch) + sds2_offset);
        sum_cal_tmp = FIELD_CH0_RXTX_REG121_SUMOS_CAL_CODE_RD(data);

        if(sum_cal_done && !sum_cal_err){
          //  lprintf(5,"summer cal 0x%x \n\r", sum_cal_tmp);
            sum_cal += sum_cal_tmp;
            loop--;
        } else{lprintf(5,"summer cal error  done 0x%x err 0x%x \n\r", sum_cal_done, sum_cal_err);}
        set_sds_rxd_reset(pcie_core_id, ch, sds2); //digital reset only
    }

    //update SUMMER CAL value
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG14__ADDR + (0x200 * ch) + sds2_offset);
    data = FIELD_CH0_RXTX_REG14_CLTE_LATCAL_MAN_PROG_SET(data, (sum_cal/10));
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG14__ADDR + (0x200 * ch) + sds2_offset, data);

    //manual summer cal enable
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG14__ADDR + (0x200 * ch) + sds2_offset);
    data = FIELD_CH0_RXTX_REG14_CTLE_LATCAL_MAN_ENA_SET(data, 1);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG14__ADDR + (0x200 * ch) + sds2_offset, data);

    loop = 10;
    while (loop > 0){
     //toggle latch cal
     for(timeout=0; timeout<0x40000; ++timeout);
     data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * ch) + sds2_offset);
     data = FIELD_CH0_RXTX_REG127_FORCE_LAT_CAL_START_SET(data,0x1);
     pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * ch) + sds2_offset, data);

     for(timeout=0; timeout<0x40000; ++timeout);
     data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * ch) + sds2_offset);
     data = FIELD_CH0_RXTX_REG127_FORCE_LAT_CAL_START_SET(data,0x0);
     pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * ch) + sds2_offset, data);
     
     try = 200;  //this gives 200ms, should be enough for latch cal to be done
     do {
         data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG158__ADDR + (0x200 * ch) + sds2_offset);
         lat_cal_done =  FIELD_CH0_RXTX_REG158_LAT_CALIB_DONE_RD(data);
         MSDELAY(1);
     }while(!lat_cal_done && try--);
     
     //read cal value
     data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG21__ADDR + (0x200 * ch) + sds2_offset);
     lat_do_tmp = FIELD_CH0_RXTX_REG21_DO_LATCH_CALOUT_RD(data);
     lat_xo_tmp = FIELD_CH0_RXTX_REG21_XO_LATCH_CALOUT_RD(data);
     fail_odd = FIELD_CH0_RXTX_REG21_LATCH_CAL_FAIL_ODD_RD(data);

     data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG22__ADDR + (0x200 * ch) + sds2_offset);
     lat_eo_tmp = FIELD_CH0_RXTX_REG22_EO_LATCH_CALOUT_RD(data);
     lat_so_tmp = FIELD_CH0_RXTX_REG22_SO_LATCH_CALOUT_RD(data);
     fail_even = FIELD_CH0_RXTX_REG22_LATCH_CAL_FAIL_EVEN_RD(data);
     
     data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG23__ADDR + (0x200 * ch) + sds2_offset);
     lat_de_tmp = FIELD_CH0_RXTX_REG23_DE_LATCH_CALOUT_RD(data);
     lat_xe_tmp = FIELD_CH0_RXTX_REG23_XE_LATCH_CALOUT_RD(data);
     
     data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG24__ADDR + (0x200 * ch) + sds2_offset);
     lat_ee_tmp = FIELD_CH0_RXTX_REG24_EE_LATCH_CALOUT_RD(data);
     lat_se_tmp = FIELD_CH0_RXTX_REG24_SE_LATCH_CALOUT_RD(data);

     if((fail_even ==0) && (fail_odd == 0)){
        //lprintf(5,"ch 0x%x sds 0x%x ...\n\r", ch, sds2);
        //lprintf(5,"do = 0x%x de = 0x%x...\n\r", lat_do_tmp, lat_de_tmp);
        //lprintf(5,"eo = 0x%x ee = 0x%x...\n\r", lat_eo_tmp, lat_ee_tmp);
        //lprintf(5,"xo = 0x%x xe = 0x%x...\n\r", lat_xo_tmp, lat_xe_tmp);
        //lprintf(5,"so = 0x%x se = 0x%x...\n\r", lat_so_tmp, lat_se_tmp);
         lat_do += lat_do_tmp;
         lat_xo += lat_xo_tmp;
         lat_eo += lat_eo_tmp;
         lat_so += lat_so_tmp;
         lat_de += lat_de_tmp;
         lat_xe += lat_xe_tmp;
         lat_ee += lat_ee_tmp;
         lat_se += lat_se_tmp;
         loop--;
     } //else {lprintf(5,"\n iteration failed fail_even 0x%x, fail_odd 0x%x\r\n", fail_even, fail_odd);}

    set_sds_rxd_reset(pcie_core_id, ch, sds2); //digital reset only
    }

    //update LATCH
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * ch) + sds2_offset);
    data = FIELD_CH0_RXTX_REG127_DO_LATCH_MANCAL_SET(data, (lat_do/10));
    data = FIELD_CH0_RXTX_REG127_XO_LATCH_MANCAL_SET(data, (lat_xo/10));
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * ch) + sds2_offset, data);

    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG128__ADDR + (0x200 * ch) + sds2_offset);
    data = FIELD_CH0_RXTX_REG128_EO_LATCH_MANCAL_SET(data, (lat_eo/10));
    data = FIELD_CH0_RXTX_REG128_SO_LATCH_MANCAL_SET(data, (lat_so/10));
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG128__ADDR + (0x200 * ch) + sds2_offset, data);

    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG129__ADDR + (0x200 * ch) + sds2_offset);
    data = FIELD_CH0_RXTX_REG129_DE_LATCH_MANCAL_SET(data, (lat_de/10));
    data = FIELD_CH0_RXTX_REG129_XE_LATCH_MANCAL_SET(data, (lat_xe/10));
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG129__ADDR + (0x200 * ch) + sds2_offset, data);
    
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG130__ADDR + (0x200 * ch) + sds2_offset);
    data = FIELD_CH0_RXTX_REG130_EE_LATCH_MANCAL_SET(data, (lat_ee/10));
    data = FIELD_CH0_RXTX_REG130_SE_LATCH_MANCAL_SET(data, (lat_se/10));
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG130__ADDR + (0x200 * ch) + sds2_offset, data);

    //manual latch cal enable
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * ch) + sds2_offset);
    data = FIELD_CH0_RXTX_REG127_LATCH_MAN_CAL_ENA_SET(data, 1);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * ch) + sds2_offset, data);

    //restore settings
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + sds2_offset);
    data = FIELD_CH0_RXTX_REG12_RX_DET_TERM_ENABLE_SET(data,0x0);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + sds2_offset, data);
     
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG28__ADDR + (0x200 * ch) + sds2_offset, dfe);

    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG8__ADDR + (0x200 * ch) + sds2_offset);
    data = FIELD_CH0_RXTX_REG8_CDR_LOOP_ENA_SET(data,0x1);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG8__ADDR + (0x200 * ch) + sds2_offset, data);

    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG31__ADDR + (0x200 * ch) + sds2_offset, dfe_preset);
    //lprintf(5,"Manual latch/summer calibration done...\n\r");
}

int set_rxa(int argc, char *argv[]){
  uint32_t data, pcie_core_id;

  if (argc < 1){
    lprintf(3,"not enough argument, pcie_id \n\r");
    return -1;
  } else {
    pcie_core_id = atoi(argv[0]);
  }
  set_rxa_sub(pcie_core_id);
}

void set_rxa_sub(int pcie_core_id){
  if(pcie_core_id == 0 || pcie_core_id == 3) {
  short_sds_rxa_reset(pcie_core_id, 0, 0);
  short_sds_rxa_reset(pcie_core_id, 1, 0);
  short_sds_rxa_reset(pcie_core_id, 2, 0);
  short_sds_rxa_reset(pcie_core_id, 3, 0);
  short_sds_rxa_reset(pcie_core_id, 0, 1);
  short_sds_rxa_reset(pcie_core_id, 1, 1);
  short_sds_rxa_reset(pcie_core_id, 2, 1);
  short_sds_rxa_reset(pcie_core_id, 3, 1);
  } else if (pcie_core_id == 1 || pcie_core_id == 4){
  short_sds_rxa_reset(pcie_core_id, 0, 0);
  short_sds_rxa_reset(pcie_core_id, 1, 0);
  short_sds_rxa_reset(pcie_core_id, 2, 0);
  short_sds_rxa_reset(pcie_core_id, 3, 0);
  } else {
  short_sds_rxa_reset(pcie_core_id, 0, 0);
  }
}

void sm_force_sds_rxa(int pcie_core_id) {
int data, link_state, link_sub_state, timeout;

set_rxa_sub(pcie_core_id);
lprintf(5,"force SDS RXA done\n\r"); //do not print before reading status register
}


void force_pvt_cal(int pcie_core_id, int link_width){
int sds2_offset, data;

 if(pcie_core_id == 2) {
  set_pvt_cal(pcie_core_id, 0);
 } else {
    if (link_width == 8){
      set_pvt_cal(pcie_core_id, 0);
      set_pvt_cal(pcie_core_id, 1);
    } else {
      set_pvt_cal(pcie_core_id, 0);
    }
 }
}

void set_pvt_cal(int pcie_core_id, int sds2){
int sds2_offset, data;

  if (sds2){
    sds2_offset = 0x30000;
  } else {
    sds2_offset = 0x0;
  }
  
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG32__ADDR + sds2_offset);
  data = FIELD_CMU_REG32_FORCE_PVT_CAL_START_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG32__ADDR + sds2_offset, data);
  
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG32__ADDR + sds2_offset);
  data = FIELD_CMU_REG32_FORCE_PVT_CAL_START_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG32__ADDR + sds2_offset, data);
}

void pcie_reset_mellanox (uint32_t pcie_core_id) {

	uint32_t data;
	data = cpu_read(0x17001294);  //as GPIO
    data &= ~(0x0f<<24);
    cpu_write(0x17001294, data);

    data = cpu_read(0x1700129c);  //as outputs
    data |= 3 <<12;
    cpu_write(0x1700129c, data);

	if (pcie_core_id == 0 || pcie_core_id == 1) {
		data = cpu_read(0x170012a0);
		cpu_write(0x170012a0, data & ~(1<<12));      // Put Card in Reset
		MSDELAY(1);
	    data = cpu_read(0x170012a0);
		data |= (1<<12);
		cpu_write(0x170012a0, data);                                  // Release Reset here
	} else if(pcie_core_id == 3 || pcie_core_id == 4) {
		data = cpu_read(0x170012a0);
		cpu_write(0x170012a0, data & ~(1<<13));      // Put Card in Reset
		MSDELAY(1);
	    data = cpu_read(0x170012a0);
		data |= (1<<13);
		cpu_write(0x170012a0, data);                                  // Release Reset here
	}	
};
