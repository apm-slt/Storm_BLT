/*
 * Copyright (c) 2013 AppliedMicro.  All rights reserved.
 *
 * program brief: pcie_lpbk.c: external loop back test of pcie g3 for Storm
 * Author : Vaibhav Vaidya 
 * history: v0.1 2013.2
 */

#include <stdio.h>
#include <common.h>

#include "pcie_lpbk.h"
#include "pcie_isr.h"
#include "pcie_base.h"
#include "pcie_base_test.h"

//#define MSDELAY(val)    {do sm_host_delay_ns(100000); while(val--);}

void program_pipe_dbgmux(uint32_t pcie_core_id, uint32_t mux_val_sel)
{
	uint32_t data;

	data = pcie_phy_csr_read(pcie_core_id, KC_PIPE_REGS_PIPE_CONTROL__ADDR);
	data = FIELD_PIPE_CONTROL_DEBUG_MUX_SEL_SET(data, mux_val_sel);

	pcie_phy_csr_write(pcie_core_id, KC_PIPE_REGS_PIPE_CONTROL__ADDR, data);
	data = pcie_phy_csr_read(pcie_core_id, KC_PIPE_REGS_PIPE_CONTROL__ADDR);
}

int ctrl_ltssm(int argc, char *argv[])
{

	int i=argc, j=0,res=0,itr=0;
	uint32_t data, current_rate, gen_match,addr=0,ltssm_state=0;
	uint32_t status = 0,success=0;
	uint32_t linkup;
	uint32_t printGEN[4] = {0,1,2};
	signed int cnt=1000;
	int error=0;
	uint32_t rc_slot,pcie_core_id,gen,link_width,lnk_state;
	uint32_t ext_ref = 1,length=0x3fffffc,test_id=2;

	uint32_t test_pattern = 1;
	uint32_t extended_addr = 0;


	if (i<2)
		error=1;
	else
	{
		pcie_core_id = atoi(argv[j]);
		lnk_state = atoi(argv[j+1]);
	}

	//    if(test_id>12)
	//  	 error=5;
	if (error) {
		printf("Usage : Command to *TOGGLE* LTSSM state after link in L0 : <Port no> <ltssm_state - >  \n");
		printf("0 : link Loopback \n"), 
			printf("1 : Hot Reset \n"), 
			printf("2 : Link Disabled \n"), 
			printf("3 : Reset Error Counter \n", error, i);
		return error;
	}

	program_pipe_dbgmux(pcie_core_id, 3);	

        change_ltssm_state(pcie_core_id,lnk_state);
}

void change_ltssm_state(uint32_t pcie_port,uint32_t state)
{
    uint32_t lnk_state=0,data=0;
    uint32_t pcie_core_id=0;
    
    lnk_state=state;
    pcie_core_id= pcie_port;
	switch(lnk_state)
	{
		case 0 : 
			printf("Direct to Loopback LTSSM \n\r");

			data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR);
			data &= ~(0xFFF7FFFF);    // Get value of 19th bit

			if(data)
				data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR) & 0xFFF7FFFF;
			else
				data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR) | ~(0xFFF7FFFF);

			pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR, data);

			data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR);
			data &= ~(0xFFF7FFFF);    // Get value of 20th bit

			printf("Direct to Loopback LTSSM state Bit 0x%x \n\r",data);

			break;

		case 1 : printf("Issue Hot reset \n\r" );
			 sm_pcie_setup_ob_cfg(pcie_core_id, RC);             
			 sm_pcie_setup_ob_space(pcie_core_id, RC); 
			 data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_INT__ADDR);
			 data &= ~ (0xFFBFFFFF);
			 if(data)
			 { 
				 data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_INT__ADDR);
				 data = data & ~(0x400000);
				 pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_INT__ADDR, data);
				 printf(" Secondary bridge reg.: = 0x%x \n\r",pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_INT__ADDR));
			 }
			 else                 
			 {
				 data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_INT__ADDR);
				 data = data |(0x400000);
				 pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_INT__ADDR, data);
				 printf(" Secondary bridge reg.: = 0x%x \n\r",pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_INT__ADDR));
			 }
			 break;

		case 2 : printf("Direct LTSSM to disabled\n\r"); 
			
			 data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR);
			 data &= ~(0xFFEFFFFF);    // Get value of 20th bit

			 if(data)
				 data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR) & 0xFFEFFFFF;
			 else
				 data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR) | ~(0xFFEFFFFF);

			 pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR, data);

			 data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR);
			 data &= ~(0xFFEFFFFF);    // Get value of 20th bit

			 printf("Direct LTSSM to disabled 0x%x \n\r",data);  
			 break;

		case 3: data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR);
			data |=0x1000;
			pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR,data);
			printf(" Error Counter Reset-1 : 0x%x\n\r", pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR));
			MSDELAY(10);
                        data &= ~(0x1000);
			pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR,data);
			printf(" Error Counter Reset-0 : 0x%x\n\r", pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR));
			break;
		default: printf(" Invalid Option \n\r");
			 break;
	}
}

int err_cnt(int args,char* argv[])
{
	uint32_t i=args,error=0,delay,hrs=0,intrvl=0;
        uint32_t temp=0,printf_en=0,test_time=0,test_time_in=0;
        uint32_t min=0;
	unsigned int pcie_core_id=0;
	if(i<3)
	{
		error=1;
		printf(" error send port no. \n\r");   
		return;
	}

	pcie_core_id = atoi(argv[0]);
        printf_en = atoi(argv[1]);
        test_time_in=atoi(argv[2]);

        change_ltssm_state(pcie_core_id,3);   // Reset error counter

	if(test_time_in>=60)
	{
	   hrs = test_time_in/60;
	   for(delay=1;delay<=hrs;delay++)
	   {
              test_time = 1 * 60; 
              print_err_cnt(pcie_core_id,printf_en,test_time);      
	   }
	}
        else{
	     // for(i=0;i<=100;i++)
	      {
                 change_ltssm_state(pcie_core_id,3);   // Reset error counter
		 print_err_cnt(pcie_core_id,printf_en,test_time_in);  
	      }
        }
         
}
uint32_t lane[60][8];
uint32_t hrs=0;

void print_err_cnt(uint32_t pcie_core_id,uint32_t printf_en,uint32_t intrvl)
{

   uint32_t temp=0,data=0, speed =0 ,width=0,i=0,Tscale=0,delay=0,a=0 ;//

        for(i=0;i<=7;i++)                     // reset array
        {
          for(Tscale=0;Tscale<=60;Tscale++)
          lane[Tscale][i]=0xFF; 
        }   
	temp = (unsigned char )(pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_1023_992__ADDR) >> 4 );
	
        if(( (pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_31_0__ADDR) & 0xFC) >> 2) == 0x6 )
	{
		printf("lts_state = %d \n\r", (pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_31_0__ADDR) & 0xFC) >> 2);
		printf("Link Entered into Loopback \n\r" );

               	printf(" 0x%x Active 8-1 lanes in loopback 1: Active 0 : Not Active  = %7b \n\r",
			pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_1023_992__ADDR ),temp);

	}
	else
	{
		printf("lts_state = %d \n\r", (pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_31_0__ADDR) & 0xFC) >> 2);
		printf("FAILED TO ENTER IN LOOPBACK \n\r" );
         	printf(" 0x%x Active 8-1 lanes in loopback 1: Active 0 : Not Active  = %7b \n\r",
			pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_1023_992__ADDR ),temp);

	}  

	if(printf_en)
	{
		printf("Observing Error Count for %d Minute \n",intrvl);

		for(Tscale=0;Tscale<=intrvl;Tscale++)    // Read on every minute
		{
			lane[Tscale][0] = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_1311_1280__ADDR) & 0xFFFF;
			lane[Tscale][1] =(pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_1311_1280__ADDR) & 0xFFFF0000) >> 16;

			lane[Tscale][2]=  pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_1343_1312__ADDR) & 0xFFFF;
			lane[Tscale][3]= (pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_1343_1312__ADDR) & 0xFFFF0000) >> 16 ;

			lane[Tscale][4]= pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_1375_1344__ADDR) & 0xFFFF;
			lane[Tscale][5]=(pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_1375_1344__ADDR) & 0xFFFF0000) >> 16 ;

			lane[Tscale][6]= pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_1407_1376__ADDR) & 0xFFFF;
			lane[Tscale][7]=(pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_1407_1376__ADDR) & 0xFFFF0000) >> 16 ;

			for(delay=0;delay<=60;delay++)    // 1 Minute Resolution  
			{ 
				MSDELAY(1000) ;           // 1 sec   
			}

		}
		Tscale=100; 
		//  change_ltssm_state(pcie_core_id,3);

	}
	else{
		printf(" 0x%x Active 8-1 lanes in loopback 1: Active 0 : Not Active  = %7b \n\r",
				pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_1023_992__ADDR ),temp);
		printf("Loopback error count on Active Lanes \n");
		printf("Lane 0 = %d \n Lane 1 = %d \n",
				(pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_1311_1280__ADDR) & 0xFFFF),
				(pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_1311_1280__ADDR) & 0xFFFF0000) >> 16 );

		printf("Lane 2 = %d \n Lane 3 = %d \n",
				(pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_1343_1312__ADDR) & 0xFFFF),
				(pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_1343_1312__ADDR) & 0xFFFF0000) >> 16 );

		printf("Lane 4 = %d \n Lane 5 = %d \n",
				(pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_1375_1344__ADDR) & 0xFFFF),
				(pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_1375_1344__ADDR) & 0xFFFF0000) >> 16 );

		printf("Lane 6 = %d \n Lane 7 = %d \n",
				(pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_1407_1376__ADDR) & 0xFFFF),
				(pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_1407_1376__ADDR) & 0xFFFF0000) >> 16 );

		printf(" DIRECT TO LOOPBCAK CONST MASTER = 0x%x \n \r",
				pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR));
		printf(" DIRECT TO LOOPBCAK COEFF.SLAVE = 0x%x\n\r",
				pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_703_672__ADDR));

	}

	data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_PCIECORE_CTLANDSTATUS__ADDR);
	speed=FIELD_PCIECORE_CTLANDSTATUS_PIPE_PHY_RATE_RD(data);

	data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_31_0__ADDR);
	width=(data & 0xfc000000)>>26;
	printf("Link Width : 0x%d \n and Speed : 0x%d \n", width,speed);

	if(Tscale==100)
	{
		for(a=0;a<=7;a++)
		{   
			printf("Lane-%d Err/min = ",a);
			for(i=0;i<=intrvl;i++)
			{
				printf("%d ", lane[i][a]);

			}
			printf("\n\r");
			Tscale=0;      
		}
	}


        program_pipe_dbgmux(pcie_core_id, 3);
	data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_PIPE0_DEBUG_REG__ADDR);
	printf("PHY BLOCK LOCK STATUS for lane 0 is %d\n\r", (((data >> 5) & 4)>>2));
	if(pcie_core_id != 2){
		data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_PIPE1_DEBUG_REG__ADDR);
		printf("PHY BLOCK LOCK STATUS for lane 1 is %d\n\r", (((data >> 5) & 4)>>2));
		data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_PIPE2_DEBUG_REG__ADDR);
		printf("PHY BLOCK LOCK STATUS for lane 2 is %d\n\r", (((data >> 5) & 4)>>2));
		data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_PIPE3_DEBUG_REG__ADDR);
		printf("PHY BLOCK LOCK STATUS for lane 3 is %d\n\r", (((data >> 5) & 4)>>2));
		
		if((pcie_core_id == 0) || (pcie_core_id == 3)) {
			data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_PIPE4_DEBUG_REG__ADDR);
			printf("PHY BLOCK LOCK STATUS for lane 4 is %d\n\r", (((data >> 5) & 4)>>2));
			data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_PIPE5_DEBUG_REG__ADDR);
			printf("PHY BLOCK LOCK STATUS for lane 5 is %d\n\r", (((data >> 5) & 4)>>2));
			data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_PIPE6_DEBUG_REG__ADDR);
			printf("PHY BLOCK LOCK STATUS for lane 6 is %d\n\r", (((data >> 5) & 4)>>2));
			data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_PIPE7_DEBUG_REG__ADDR);
			printf("PHY BLOCK LOCK STATUS for lane 7 is %d\n\r", (((data >> 5) & 4)>>2));
		}	

	}

}


int cfg_lpbk (int args,char* argv[])
{
	uint32_t i=args,error=0,reg_ms=0,val=0,value=0;
        uint32_t temp=0,j=0,delay=0;
	unsigned int pcie_core_id=0;

	if (i<3)
	{
		error=1;
		printf( "Error in Argument usage : core_id,field,value\n");
		printf(" 0 : SLAVE_5G_DEEMPH \n");
		printf(" 1 : MASTER_5G_DEEMPH \n");
		printf(" 2 : LOOPBACK PATTERN \n");  
		printf(" 3 : SLAVE_8G_HINT \n");
		printf(" 4 : SLAVE_8G_PRESET_EN \n");  
		printf(" 5 : SLAVE_8G_COEFF_EN \n");
		printf(" 6 : SLAVE_8G_PRESET \n");  
		printf(" 7 : SLAVE_8G_COEFF_R0 \n");
		printf(" 8 : SLAVE_8G_COEFF_R1 \n");
		printf(" 9:  MASTER_8G_PRESET_EN \n");  
		printf(" 10: MASTER_8G_COEFF_EN \n");
		printf(" 11: MASTER_8G_PRESET \n");  
		printf(" 12: MASTER_8G_COEF \n");
                printf(" 13: Inject Error\n");   

		return;
	}
	else
	{
		pcie_core_id = atoi(argv[0]);
		reg_ms = atoi(argv[1]);
		value = atoi(argv[2]);
	}

        printf("programming value  = 0x%x \n\r", value);
	printf("Default DIRECT TO LOOPBCAK CONST MASTER = 0x%x \n \r",
			pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR));
        printf("Defalut DIRECT TO LOOPBCAK COEFF.SLAVE = 0x%x\n\r",
			pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_703_672__ADDR));
 
	switch(reg_ms)
	{
		// Program SLAVE 5G deemph,1=-3.5 dB 0 : -6.0dB

		case 0:	temp = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR);
			temp |= FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640_CFG_CONSTANTS_DIRECT_TO_LOOPBACK_SLAVE_5G_DEEMPH_SET(temp,value);
			pcie_csr_write(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR,temp); 
			temp = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR); 

			break;

		// Program MASTER 5G deemph,1=-3.5 dB 0 : -6.0dB

		case 1: temp = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR);
			temp=FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640_CFG_CONSTANTS_DIRECT_TO_LOOPBACK_MASTER_5G_DEEMPH_SET(temp,value);
			pcie_csr_write(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR,temp); 
			temp = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR);

			//printf("LOOPBACK_MASTER_5G_DEEMPH Programmed %d\n\r",temp);
			break;

		// Program complinace pattern 0  PRBS32
		case 2 :temp = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR);
			temp = FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640_CFG_CONSTANTS_DIRECT_TO_LOOPBACK_PATTERN_SET(temp,value); 
			pcie_csr_write(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR,temp); 
			temp = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR);

		//	printf("LOOPBACK PATTERN Programmed %d\n\r",temp);
			break;
		
                // Program slave 8G hint

		case 3: temp = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR); 
			temp=FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640_CFG_CONSTANTS_DIRECT_TO_LOOPBACK_SLAVE_8G_HINT_SET(temp,value);
                        pcie_csr_write(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR,temp); 
			temp = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR);

		//	printf("SLAVE_8G_HINT Programmed %d\n\r",temp);
			break;
		// Program slave 8G preset enable
		
                case 4: temp = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR);
			temp=FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640_CFG_CONSTANTS_DIRECT_TO_LOOPBACK_SLAVE_8G_PRESET_EN_SET(temp,value);                       
			pcie_csr_write(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR,temp); 
			temp = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR);
                        //	printf("SLAVE_8G_PRESET_EN Programmed %d\n\r",temp);
                        break;
			// Program slave 8G coeff enable
		case 5: temp = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR);
                        temp=FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640_CFG_CONSTANTS_DIRECT_TO_LOOPBACK_SLAVE_8G_COEF_EN_SET(temp,value);
                        pcie_csr_write(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR,temp); 
			temp = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR);
                    //    printf("SLAVE_8G_COEFF_EN Programmed %d\n\r",value);
			break;
			// Program slave 8G preset
		case 6: temp = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR);
			temp=FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640_CFG_CONSTANTS_DIRECT_TO_LOOPBACK_SLAVE_8G_PRESET_SET(temp,value);
			pcie_csr_write(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR,temp); 
			temp = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR);    
		//	printf("SLAVE_8G_PRESET Programmed %d\n\r",temp);
			break;
			// Program slave 8G coeff R0
		case 7: temp = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR);
			temp=FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640_CFG_CONSTANTS_DIRECT_TO_LOOPBACK_SLAVE_8G_COEF_R0_SET(temp,value);
			pcie_csr_write(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR,temp); 
			temp = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR);
			printf("SLAVE_8G_COEFF_R0 Programmed %d\n\r",temp);
			break;
			// Program 8G_COEFF_R1
		case 8: temp = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_703_672__ADDR); 
			temp=FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_703_672_CFG_CONSTANTS_DIRECT_TO_LOOPBACK_SLAVE_8G_COEF_R1_SET(temp,value);
			pcie_csr_write(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_703_672__ADDR,temp);
			temp = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_703_672__ADDR);
		//	printf("SLAVE_8G_COEFF_R1: Programmed %d\n\r",temp);
			break;
			// Program MASTER_8G_PRESET_EN
		case 9: temp = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_703_672__ADDR);
			temp=FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_703_672_CFG_CONSTANTS_DIRECT_TO_LOOPBACK_MASTER_8G_PRESET_EN_SET(temp,value);
			pcie_csr_write(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_703_672__ADDR,temp);
         	        temp = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_703_672__ADDR);
			printf("MASTER 8G_PRESET_EN Programmed %d\n\r",temp);

			// Program caliberation value

		//	for(i=3;i<=10;i++)                                                      
			{
		//	    value=i;
                            printf("MASTER 8G_PRESET_EN Programmed %d\n\r",value); 
			    temp = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_703_672__ADDR);
			    temp=FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_703_672_CFG_CONSTANTS_DIRECT_TO_LOOPBACK_MASTER_8G_PRESET_SET(temp,value);   
			    pcie_csr_write(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_703_672__ADDR,temp);
		            temp = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_703_672__ADDR);

			  /*  for(delay=0;delay<=2000;delay++)
			    {
				    MSDELAY(7000);
	                    } */
			    change_ltssm_state(pcie_core_id,3);  // Rest counter
			    change_ltssm_state(pcie_core_id,0);  // put link in loopback
			    print_err_cnt(pcie_core_id,0,10);         // print error count   
	 //		    change_ltssm_state(pcie_core_id,0);  // come out of loopback

		//	    printf("Initilizaing RC mode on core %1d\n", pcie_core_id);  
		//	    sm_pcie_init(pcie_core_id, 1, 0, 2, 1,8, 0); 
                             
			} 

			break;
			// MASTER_8G_COEF_EN
		case 10:temp = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_703_672__ADDR);
                        temp=FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_703_672_CFG_CONSTANTS_DIRECT_TO_LOOPBACK_MASTER_8G_COEF_EN_SET(temp,value);
                        pcie_csr_write(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_703_672__ADDR,temp);
         	        temp = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_703_672__ADDR); 
                   //     printf("MASTER 8G COEFF EN Programmed %d\n\r",temp);
			break;

			// MASTER_8G_PRESET
		case 11: temp = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_703_672__ADDR);
			 temp=FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_703_672_CFG_CONSTANTS_DIRECT_TO_LOOPBACK_MASTER_8G_PRESET_SET(temp,value);   
			 pcie_csr_write(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_703_672__ADDR,temp);
			 temp = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_703_672__ADDR);
		//	 printf("MASTER_8G_PRESET Programmed %d\n\r",temp);
                         break;
			// MASTER_8G_COEF
		case 12: temp = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_703_672__ADDR);
			 temp=FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_703_672_CFG_CONSTANTS_DIRECT_TO_LOOPBACK_MASTER_8G_COEF_SET(temp,value);
			 pcie_csr_write(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_703_672__ADDR,temp);
			 temp = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_703_672__ADDR); 
		//	 printf("MASTER 8G_COEFF_SET Programmed 0x%x\n\r",temp);

			 break;
		case 13: set_tx_prbs(pcie_core_id,11);      // PRBS11  
                                                            // 3rd argument 1: Reset Tx 0 : Dont reset   
		         print_err_cnt(pcie_core_id,0,1);  
                         printf("PRBS Enabled \n");  	
			 break;

		default :printf(" Invalid option \n\r");
			 break;

	}

   
	printf(" DIRECT TO LOOPBCAK CONST MASTER = 0x%x \n \r",
			pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_671_640__ADDR));
        printf(" DIRECT TO LOOPBCAK COEFF.SLAVE = 0x%x\n\r",
			pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_703_672__ADDR));

   //      change_ltssm_state(pcie_core_id,0);

}




