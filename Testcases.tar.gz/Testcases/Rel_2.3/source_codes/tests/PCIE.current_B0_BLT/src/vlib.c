/*
 * AppliedMicro
 * Storm-PreSi
 *
 * Filename: vlib.c
 * Comments: vbios init functions
 *
 */
#include "common.h"
#include "vlib.h"
#include "mb_interface.h"
#include "vbios_vsyms.h"

#define ULONG_MAX            4294967295UL
#define MAIN_VBIOS_START_OCM     0x9D000000U //OCM
#define MAIN_VBIOS_START_DDR     0xC0000000U //DDR

extern struct vsymbols vsym[];
extern int vsym_count;
extern unsigned int vsym_addr;

unsigned int uVBIOS_SP __attribute__ ((section(".uVBIOS.resume")));
unsigned int uVBIOS_PC __attribute__ ((section(".uVBIOS.resume")));

unsigned int vbios_ocm_enable_code_key __attribute__ ((section(".ocm.key"))) = 0xC0019D00;
unsigned int vbios_ddr_enable_code_key __attribute__ ((section(".ddr.key"))) = 0xC001C000;
unsigned int vbios_version; //0: uVBIOS, 1: DDR-VBIOS, 2: OCM-VBIOS

void (*CmdFunArg)();

unsigned long vstrtoul(const char *fp,
              char **tpp, int base);

void read_svn_id () {
    unsigned int read_data;
    read_data = read(0x97040008);
    printf("SVN Rev = %08x\n", read_data);
}

void ocm_init() {
    WRITE32(0x9f41c004,3);  // OCM clken
    WRITE32(0x9f41c000,0);  // OCM rst deassertion
};
void ddr_init(void)
{
  int rdata;
  WRITE32(0xc200c03c, 0x0);         //kumar: 
  WRITE32(0xc200c040, 0x200D0000);
  WRITE32(0xc200c060, 0x04403000);  // changed read latency here changing LSB nibble from 6 to 7
  WRITE32(0xc200c02c, 0xe4a48361);  // changed Write latency here changing LSB nibble from 4 to 5
  WRITE32(0xc200c010, 0x01421109);  // remove ddrc reset
  WRITE32(0xc200c0b0, 0x00000010); 

  rdata = READ32(0xc200c3A8);
  while(!((rdata & 0x07000000) == 0x01000000))
    rdata = READ32(0xc200c3A8);
  
//  write(0xc0000000, 0x12345678); 
//  read (0xc0000000);
};  
void vbios_msg_header (void)
{
   if ((((u32)&vbios_version) >> 24) == 0xC0)
       vbios_version = 1;
   else if((((u32)&vbios_version) >> 24) == 0x9D)
       vbios_version = 2;
   else
       vbios_version = 0;

    printf ("################################################\r\n");
    printf ("####            AppliedMicro                ####\r\n");
    printf ("####   Project          : Storm             ####\r\n");
    printf ("####   Phase            : Validation        ####\r\n");
    printf ("####   Platform         : Xilinx-FPGA       ####\r\n"); //%s      ####\r\n", VAL_PLATFORM);
    printf ("####   Build Time       : %s ####\r\n", BUILD_TIMESTAMP);
    printf ("####   SVN Revision     : %08x          ####\r\n", CODE_SVN_REV);
    if (vbios_version == 1)
    printf ("####   VBIOS make       : VBIOS: DDR        ####\r\n");
    else if (vbios_version == 2)
    printf ("####   VBIOS make       : VBIOS: OCM        ####\r\n");
    else
    printf ("####   VBIOS make       : VBIOS: unknown    ####\r\n");
    printf ("####   Available OCM    :  1MB @0x9D000000  ####\r\n");
    printf ("####   Available DDR    : 64MB @0xC0000000  ####\r\n");
    printf ("################################################\r\n");
    printf ("\nVBIOS=>\r\n");
}
//extern const struct cmd _cmd_tbl_[];

void reset (int argc, char *argv[])
{
	u32 *addr, opt;
	if (argc > 1)
        opt = (u32)vstrtoul(argv[1], NULL, 0);
    else 
        opt = 0;

    if (opt == 0) {
        addr = 0x0;
    } else if (opt == 1) {
        if (vbios_version == 1)
            addr = MAIN_VBIOS_START_DDR;
        else if (vbios_version == 2)
            addr = MAIN_VBIOS_START_OCM;
        else
            addr = 0x0;
    }
    if (opt < 2) {
        CmdFunArg = (void (*)(void))addr;   // Go Function Address 
        //Stack not pushed - no referance to previous code
        CmdFunArg();        // Call C func
        //should never return here...
        while(1);
    } 

#if 0
    else if (opt == 1)
        //core-reset - TBD
    else if (opt == 2)
        //soc-reset - TBD
    else if (opt == 3)
        //expternal-reset - TBD
#endif
}

void md (int argc, char *argv[])
{
	u32 *addr;
	int i;
	int cnt = 1;
	addr = (u32)vstrtoul(argv[1], NULL, 0);
	if ( argc > 2 ){
		cnt = (u32 )vstrtoul(argv[2], NULL, 0);
	}
	printf("Memory dump:");
	for (i=0; i<cnt ; i++){
        if (i%4 == 0) {
		    printf("\n\t@ 0x%08X:", (u32)addr);
        }
        printf(" 0x%08X",*addr++);
	}
    printf("\n");
} 

void mm (int argc, char *argv[])
{
	u32 *addr,data;
	int i;
	int cnt = 1;
	if ( argc > 3 ){
		cnt = (u32 )vstrtoul(argv[3], NULL, 0);
	}
	addr = (u32)vstrtoul(argv[1], NULL, 0);
	data = (u32)vstrtoul(argv[2], NULL, 0);
	printf("Memory modify:");
    for (i=0; i<cnt ; i++){
        *addr = data;
        if (i%4 == 0) {
		    printf("\n\t@ 0x%08X:", (u32)addr);
        }
        printf(" 0x%08X",*addr++);
	}
    printf("\n");
} 

void getfile (int argc, char *argv[])
{
   unsigned char *Addr;
   unsigned int Size ;
	if(argc < 2) {
		printf("usage: getfile [<addr in hex or dec>] <file size>\n");
		return -1;
	}
	/* base = 0 ensures that both hex and dec are taken care */
        Addr = (unsigned char*)vstrtoul(argv[1], NULL, 0);
        Size = (unsigned int)vstrtoul(argv[2], NULL, 0);
    return(xgetfile(Addr, Size));
}
void sendfile (int argc, char *argv[])
{
   unsigned char *Addr;
   unsigned int Size ;
	if(argc < 2) {
		printf("usage: sendfile [<addr in hex or dec>] <file size>\n");
		return -1;
	}
	/* base = 0 ensures that both hex and dec are taken care */
        Addr = (unsigned char*)vstrtoul(argv[1], NULL, 0);
        Size = (unsigned int)vstrtoul(argv[2], NULL, 0);
    return(xsendfile(Addr, Size));
}
void getvbios (int argc, char *argv[])
{
    printf("*ERROR*: Run this command from 'uVBIOS'\n");
    printf("         Type 'exit' to go back to 'uVBIOS'\n");
}
void jump2ocm (int argc, char *argv[])
{
    unsigned int ocm_key;
    ocm_key = vbios_ocm_enable_code_key;
    if ((ocm_key == 0xC0019D00) && (vbios_version == 1)) {
        printf("Jumping to main VBIOS...\n");
        CmdFunArg = (void (*)(void))MAIN_VBIOS_START_OCM;   // Go Function Address 
        //Stack not pushed - no referance to previous code
        CmdFunArg();        // Call C func
        //Stack not poped - no clean retrival -
    	return 0;
    } else {
        printf("\nOCM code is not good... [KEY:0x%08X]\n", ocm_key);
        printf("Download new VBIOS from uVBIOS\n");
        printf("use 'exit' command to go back to uVBIOS\n");
    }
} 
void jump2ddr (int argc, char *argv[])
{
    unsigned int ddr_key;
    ddr_key = vbios_ddr_enable_code_key;
    if ((ddr_key == 0xC001C000) && (vbios_version == 2)) {
        printf("Jumping to main VBIOS...\n");
        CmdFunArg = (void (*)(void))MAIN_VBIOS_START_DDR;   // Go Function Address 
        //Stack not pushed - no referance to previous code
        CmdFunArg();        // Call C func
        //Stack not poped - no clean retrival -
    	return 0;
    } else {
        printf("\nDDR code is not good... [KEY:0x%08X]\n", ddr_key);
        printf("Download new VBIOS from uVBIOS\n");
        printf("use 'exit' command to go back to uVBIOS\n");
    }
} 
void list (int argc, char *argv[])
{
    u32 i, c;
    char *xyz;
    c = 0;
    if(argc < 2) {
	    printf("usage: list <sub-string>\n");
    	return -1;
	}

	if(isdigit(argv[1][0])) {
        printf(" '%s' not a valid string [Func Name Array: @0x%08x]\n", argv[1], vsym_addr);
        return (-1);        // Invalid symbol name
    }
    printf("\nListing \'%s\' matching symbols in VBIOS...\n", argv[1]);    
    xyz = argv[1];
	for(i=0;i<vsym_count; i++) {
        if(strstr(vsym[i].name, xyz) != NULL) {
            printf("<0x%08x> %s\n", (u32)(vsym[i].addr), vsym[i].name);
            c++;
        }
    }
    
    printf ("\nFound %d matching symbols.\n\n", c);
    
    return 0;    
}

//parameters not supported

void go (int argc, char *argv[])
{
    unsigned int vbios_go_adr;
    if (argc == 1) {
		printf("usage: go [<addr in hex or dec> / <symbol name>] <args>\n");
        return;
    }
	if(isdigit(argv[1][0])) {
	/* base = 0 ensures that both hex and dec are taken care */
        vbios_go_adr = (unsigned int)strtoul(argv[1], NULL, 0);
    } else {
		if(find_symbol_addr(argv[1], &vbios_go_adr) == -1) {
			printf(" '%s' not a valid symbol\n", argv[1]);
			return (-1);
		}
    }
    //vbios_go_adr = (unsigned int*)vstrtoul(argv[1], NULL, 0);

    CmdFunArg = (void (*)(void))vbios_go_adr;   // Go Function Address 
    
    //Stack not pushed - no referance to previous code
    CmdFunArg();        // Call C func
    //Stack not poped - no clean retrival -
    
    return;
}
void resume_uVBIOS(void) {
    mtslr(uVBIOS_SP);
    CmdFunArg = (void (*)(void))uVBIOS_PC;
    //Stack not pushed - no referance to previous code
    CmdFunArg();        // Call C func
    //Stack not poped - no clean retrival -
    while(1);
}
//-------------------------------------------------------------------
unsigned long vstrtoul(const char *fp,
              char **tpp, int base)
{

   unsigned long 	value;
   unsigned long	pvalue;
   int 			flag;

   value=0;
   pvalue=0;
   flag=0;
//   errno=ESUCCESS;
   if ((base<0) || (base>36)) {
//      errno=EINVAL;
      if (tpp!=NULL) {
         *tpp=(char *)fp;
      }
      return(value);
   }
   while((*fp) == ' ') {
      fp++;
   }
   switch(*fp) {
      case '-':
         flag=1;
      case '+':
         fp++;
   }
   if (base==0) {
      base=10;
      if (*fp=='0') {
         if((*(fp+ 1)=='x') || (*(fp+ 1)=='X')) {
            base=16;
         } else {
            base=8;
            fp++;
         }
      }
   }
   if ((base==16) && (*fp=='0') && ((*(fp+ 1)=='x') || (*(fp+ 1)=='X'))) {
      fp+=2;
   }
   if ((base>=11) && (base<=36)) {
      while(((*fp>='0') && (*fp<='9')) ||
            ((*fp>='A') && (*fp<('A'+ (base- 10)))) ||
            ((*fp>='a') && (*fp<('a'+ (base- 10))))) {
         value*=base;
         if ((*fp>='0') && (*fp<='9')) {
            value+=(*fp- '0');
         }
         if ((*fp>='A') && (*fp<('A'+ (base- 10)))) {
            value+=(*fp- '7');
         }
         if ((*fp>='a') && (*fp<('a'+ (base- 10)))) {
            value+=(*fp- 'W');
         }
         if (value<pvalue) {
            value=ULONG_MAX;
//            errno=ERANGE;
            break;
         }
         pvalue=value;
         fp++;
      }
   } else {
      while((*fp>='0') && (*fp<('0'+ base))) {
         value*=base;
         value+=(*fp- '0');
         if (value<pvalue) {
            value=ULONG_MAX;
//            errno=ERANGE;
            break;
         }
         pvalue=value;
         fp++;
      }
   }
   if (tpp!=NULL) {
      *tpp=(char *)fp;
   }
   if (flag!=0) {
      value=(unsigned long)-value;
   }
   return(value);
}
