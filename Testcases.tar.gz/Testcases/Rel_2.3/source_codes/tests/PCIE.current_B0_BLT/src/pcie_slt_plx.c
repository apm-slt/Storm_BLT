#include "pcie_base_test.h"
#include "armv8.h"
#include <common.h>

#define MAX_BUS_NUM 3
#define MAX_DEV_NUM 32
#define MAX_FUN_NUM 1
#define PCI_CLASS_BRIDGE_PCI 0x0604

struct ep_bar tgt_bars[6];
extern uint64_t EP_BAR_AXI_ADDR[6];

static void pci_bus_scan(uint32_t pcie_core_id);
int scan_pcie (int argc, char *argv[])
{
	int i=argc, j=0,res=0;
	uint32_t data, current_rate, gen_match,addr=0;
	uint32_t status = 0,success=0;
	uint32_t linkup;
	uint32_t printGEN[4] = {0,1,2};
	signed int cnt=1000;
	int error=0;
    uint32_t rc_slot,pcie_core_id,gen,link_width;
    uint32_t ext_ref = 1,length=0x3fffffc,test_id=0;
    uint32_t data32=0;

    uint32_t test_pattern = 1;
    uint32_t extended_addr = 0;

    if (i<4)
	    error=1;
    else {
      rc_slot = atoi(argv[j]);
      gen = atoi(argv[j+1]);
      link_width = atoi(argv[j+2]);
      test_id = atoi(argv[j+3]);
    }

    lprintf(5," TEST CASE FOR EXECUTION : %d \n\r",test_id);
    sm_pcie_init(rc_slot, 1, 0, gen, ext_ref, link_width, 0);
    pci_bus_scan(rc_slot);

    lprintf(5,"Programming the bus number register\n\r");
    data32 = 0x40060100;
    pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_BUS_NUMBER__ADDR, data32);

    error = sm_pcie_test_rc(0,test_id,1,0x800000, 0);   //EP DMA OB-WR
    sm_pcie_test_ep(3);
}

uint32_t pcie_fabric[6];
uint32_t dev_idx=0;
uint32_t ep_detected=0,g_bdf=0;
static void pci_bus_scan(uint32_t pcie_core_id)
{

  uint32_t bus,dev,func,dev_nu,devid,RTDID_val,i=0;
  uint32_t dev_class,pri_bus,sec_bus,sub_bus=0,sec_bs_lat;
  uint32_t bdf =0,temp=0,rtdid,cfg_bus_reg,j,k,l;
  volatile uint32_t data32 =0;
  static bus_no=0x100;

    sm_pcie_setup_ob_cfg(pcie_core_id, RC);
    sm_pcie_setup_ob_space(pcie_core_id, RC);
 
    lprintf(5,"Programming the bus number register\n\r");
    data32 = 0x40FF0100;
    pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_BUS_NUMBER__ADDR, data32);

    /* Update Device ID of RC port to distinugush EP port */

    pcie_csr_write(pcie_core_id,  NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_31_0__ADDR, RC_DEV_VEN_ID);
    pcie_fabric[0]=pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_DEV_ID__ADDR);   // Read Upstream Port

    pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_DEV_ID__ADDR);   // Read Upstream Port

      /*Read class of device in case it is PCI-Bridge */

    dev_class=pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_CLASS__ADDR) >> 16;
	
    if(dev_class==PCI_CLASS_BRIDGE_PCI)                                                    // If this is PLX switch found here.
    {

    	/* Configure bus number registers */
        //  pri_bus = 1
        //  sec_bus = 2
        //  sub_bus = 0xFE
    	pcie_ob_cfg_read(pcie_core_id, (SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR+0x18));
    	pcie_ob_cfg_write(pcie_core_id, (SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR+0x18),0x40FE0201);
    	MSDELAY(100);
    	sub_bus=0xFE;
    	sec_bus=2;
    	sec_bs_lat=0x40;
    	dev_idx=0;

    	lprintf(5," Switch On Bus-1 | Dev Class 0x%x | BusConfSet : 0x%x \n\r",
    			dev_class,pcie_ob_cfg_read(pcie_core_id, (SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR+0x18))
    		  );

    	/* Start Scanning all Downstream Port of Bridge which may be at secondary bus of 2 */

    	for (bus = 2; bus < MAX_BUS_NUM; bus++)
        {
          for (dev = 0; dev < MAX_DEV_NUM; dev++)
    	  {
    	    for (func = 0; func < MAX_FUN_NUM; func++)
    	      {
        /* Program Corresponding BUS|DEV and | Func No */
                bdf= ((bus << 8)|(dev<<3)| func );
                pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_RTDID__ADDR,bdf);
                MSDELAY(100);
    	    	data32=pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR);
    	    	MSDELAY(100);

    	        if (data32 == 0xffffffff ||
         	    data32 == 0x00000000 ||
    		    data32 == 0x0000ffff ||
    		    data32 == 0xffff0000)
    		   continue;
    	        else
    	        {

    	             rtdid=pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_RTDID__ADDR);
    	             dev_class=pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_CLASS__ADDR) >> 16;
                //    lprintf(5,"Device Found Class 0x%x of Dev. ID  0x%x: \n\r",dev_class,data32);

    	        	if(dev_class==PCI_CLASS_BRIDGE_PCI)
    	        	{
                     // lprintf(5," Bridge Found  \n\r");
                       data32=pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR);
                       cfg_bus_reg = (sub_bus<<16)|(sec_bus<<8)|(pri_bus);
                       pcie_ob_cfg_read(pcie_core_id, (SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR+0x18));

                    // pcie_ob_cfg_write(pcie_core_id, (SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR+0x18),cfg_bus_reg);

                       lprintf(5,"[Bus No: 0X%x][Device No: 0x%x][Device Class: 0x%x][Fcn.No= %d][RTDID= 0x%x][Device. ID=  0x%x][Bus Reg.=0x%x] \n\r",
                       	       bus,dev,dev_class,func,rtdid,data32,
                       	       pcie_ob_cfg_read(pcie_core_id, (SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR+0x18))
                       	     );

                        pcie_fabric[dev_idx]=rtdid;
                        dev_idx++;
    	                }
    	        }
    	      }  /*Scan for func*/
    	   }     /*Scan for devices ends here*/
	}        /*for bus - Scanning bus-1 for all PCI Downstream switches ends here */

		
		  
          /* Issue Hot reset here */
          //set hot reset to retrain the link
#if 0 
              lprintf(5,"HOT RESET to All DS %d\n\r", i);
              data32 = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_INT__ADDR);
              data32 = data32 | 0x00400000;
              pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_INT__ADDR, data32);

              //clear hot reset
              for (j= 0; j<0xffff; j++);

              data32 = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_INT__ADDR);
              data32 = data32 & ~(0x00400000);
              pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_INT__ADDR, data32);
#endif

        
	/*We scanned bus 1 where secondary beirdges are connected now proceed for P2P DS bridges on Bus=2*/
        /*Confgure these devicess to find siblings of Each-P2P bridge in fabric.*/
        /*these all are connected on Bus-2 with diff. device no so anopther depth starts with Bus-3*/
		
         	pri_bus=1;
        	sec_bus=2;
        	sub_bus=0xFF;

          for(j=0;j<4;j++)
          {
            rtdid= pcie_fabric[j];
        	func=0;

        	pri_bus=( (rtdid & 0xFF00) >> 8 );
        	dev_nu=( (rtdid & 0xF8) >> 3 );

        	pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_RTDID__ADDR,rtdid);

           /* Now configure P2P bridge for scanning required on bus-3 */
        	sec_bus +=1;
        	sub_bus = sec_bus;
        	cfg_bus_reg=0x40000000;

        	cfg_bus_reg |= (sub_bus<<16)|(sec_bus<<8)|(pri_bus);
        	pcie_ob_cfg_read(pcie_core_id, (SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR+0x18));
        	pcie_ob_cfg_write(pcie_core_id, (SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR+0x18),cfg_bus_reg);

        	 /* Issue Hot reset here */
        	//set hot reset to retrain the link
#if 0 
        	lprintf(5,"HOT RESET to All DS %d\n\r", i);
        	data32 = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_INT__ADDR);
        	data32 = data32 | 0x00400000;
            pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_INT__ADDR, data32);

        	  //clear hot reset
        	for (l= 0; l<0xffff; l++);
        	data32 = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_INT__ADDR);
        	data32 = data32 & ~(0x00400000);
        	pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_INT__ADDR, data32);

#endif
        	lprintf(5," Programmed Switch No.: %d On Bus 0x%x Dev 0x%x RTDID = 0x%x Bus_Number= 0x%x\n\r",
        			j,
        			pri_bus,
        			dev_nu,
        			pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_RTDID__ADDR),
                    pcie_ob_cfg_read(pcie_core_id, (SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR+0x18))
        	      );

        
		  }
        	/* Scan Downstream buses On Bus-3 starts here */
        	for (dev = 0; dev < MAX_DEV_NUM; dev++)
        	{
        	   for (func = 0; func < MAX_FUN_NUM; func++)
        	    {
        	      /* Program Corresponding BUS|DEV and | Func No */
        	      bdf= ((sec_bus << 8)|(dev<<3)| func );
        	      //lprintf(5,"BDF Programmed = 0x%x \n\r",bdf);
        	      pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_RTDID__ADDR,bdf);
        	      MSDELAY(100);
        	      data32=pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR);
        	      MSDELAY(100);

        	      if(data32 !=0xFFFFFFFF)
        	      {
        	        lprintf(5," Device Connected to Bus 0x%x : 0x%x \n\r",
        			      pcie_ob_cfg_read(pcie_core_id, (SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR)),
        			      pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_RTDID__ADDR));

        	        dev_class=pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_CLASS__ADDR) >> 16;
        	        if(dev_class==PCI_CLASS_BRIDGE_PCI)
        	        {

        	          sub_bus=7;                              // Hardcoded value
        	          sec_bus=7;
        	          pri_bus=6;
        	          cfg_bus_reg = (sub_bus<<16)|(sec_bus<<8)|(pri_bus);
        	          pcie_ob_cfg_write(pcie_core_id, (SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR+0x18),cfg_bus_reg);

/*
        	        lprintf(5," Device Connected to Bus 0x%x : 0x%x \n\r",
        	                 pcie_ob_cfg_read(pcie_core_id, (SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR+0x18)),
        	                 pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_RTDID__ADDR));
*/
          	          for (dev = 0; dev < MAX_DEV_NUM; dev++)
        	          {
        	            bdf= ((sec_bus << 8)|(dev<<3)| func );
        	            pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_RTDID__ADDR,bdf);
        	            MSDELAY(100);
        	            data32=pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR);
        	            MSDELAY(100);

        	            if(data32 != 0xffffffff)
        	            {
        	               dev_class=pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_CLASS__ADDR) >> 16;
        	               lprintf(5," Dev Class : 0x%x\n\r",dev_class);
        	               lprintf(5," Device Connected to Port 0x%x : 0x%x @ RTDID = 0x%x\n\r",
        	                   pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_RTDID__ADDR),
        	                   pcie_ob_cfg_read(pcie_core_id, (SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR)),
        	                   pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_RTDID__ADDR)
        	                );
        	            }
        	           }
        	        }	
			   else{
        	              if(data32 == EP_DEV_VEN_ID )
        	              {

        	                lprintf(5," Device ID Connected on RTDID => 0x%x is 0x%x \n\r",
        	               	          pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_RTDID__ADDR),
        	               	          pcie_ob_cfg_read(pcie_core_id, (SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR))
        	               	       );
        	               	        		//  enmuerate_bridge(pcie_core_id);
                            ep_detected=1;
                            g_bdf=pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_RTDID__ADDR);
        	                break;
        	              }
					    }
        	     }
         //   lprintf (5,"Bus_No_Progarmmed : 0x%x \n\r",
         //   		pcie_ob_cfg_read(pcie_core_id, (SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR+0x18)) );
             }
            }  
    }

 if(ep_detected)
 {
	 ep_detected=0;
	 enmuerate_bridge(pcie_core_id,g_bdf);

 }
}// End of function here.


extern uint32_t mem_base_np;
extern uint32_t mem_limit_np;
extern uint32_t mem_base_p,mem_limit_p;
extern uint32_t io_base,io_limit;
extern uint32_t run_with_plx;
uint64_t EP_BAR0, EP_BAR2, EP_BAR4;

#define SM_PCIE_CFG0_PCIE_CFG0_MEM_BASE__ADDR 0x10020
void enmuerate_bridge (uint32_t pcie_core_id,uint32_t g_bdf)
{
	uint32_t bar_info,i=0,data=0,offset,error;
      //  uint64_t EP_BAR0, EP_BAR2, EP_BAR4;
	uint32_t rtdid,pri_bus,dev_nu,bdf,temp,func;

	pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_RTDID__ADDR,g_bdf);

	lprintf(5,"Enumeration With @ RTDID 0x%x for Device 0x%x \n\r",
			pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_RTDID__ADDR),
			pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR));

	sm_pcie_enum_ep(pcie_core_id, tgt_bars);
	sm_pcie_setup_rc_bars(pcie_core_id);

	for(i = 0; i < 6; i++){
	    EP_BAR_AXI_ADDR[i] = 0;

	    if(tgt_bars[i].valid == 0)
	      continue;

	    switch(tgt_bars[i].type){
	      case 0:
	        EP_BAR_AXI_ADDR[i] = ret_omr3_base(pcie_core_id);
	        offset = (uint64_t ) tgt_bars[i].offset;
	        break;

	      case 1:
	        EP_BAR_AXI_ADDR[i] = ret_omr2_base(pcie_core_id);
	        offset = (uint64_t ) tgt_bars[i].offset;
	        break;

	      case 2:
	        EP_BAR_AXI_ADDR[i] = ret_omr1_base(pcie_core_id);
	        offset = (uint64_t ) tgt_bars[i].offset;
	        offset |= ((uint64_t ) tgt_bars[i+1].offset << 32);
	        break;
	    }

	    EP_BAR_AXI_ADDR[i] += offset;
	  }

	  EP_BAR0 = EP_BAR_AXI_ADDR[0];
	  EP_BAR2 = EP_BAR_AXI_ADDR[2];
	  EP_BAR4 = EP_BAR_AXI_ADDR[4];

 	  lprintf(5,"EP BAR0 0x%x \n\r EP BAR2 0x%x \n\r EP BAR4 0x%x \n\r ",EP_BAR0,EP_BAR2,EP_BAR4);
	  lprintf(5,"Mem.Range Base => Base Address : 0x%x : Limit 0x%x \n\r",mem_base_np,mem_limit_np);

	  // Program Base and limit register in Type1 headers, which are programmed
      // with range of address live beneath to bridge.

	  mem_base_np =  mem_base_np & 0xFFF00000;
	  mem_base_np = mem_base_np >> 0x14;

	  mem_limit_np =  mem_limit_np & 0xFFF00000;
	  mem_limit_np = mem_limit_np >> 0x14;

	  lprintf(5," MEM_BASE = : 0x%x : Mem Limit 0x%x \n\r",mem_base_np,mem_limit_np);

      // Program Upstream  port
	  pri_bus=1;
	  dev_nu=0;
	  func=0;
	  bdf= ((pri_bus << 8)|(dev_nu<<3)| func );
	  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_RTDID__ADDR,bdf);
          MSDELAY(10);
	  temp = ( mem_limit_np << 20) | mem_base_np ;

	  pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_MEM_BASE__ADDR, temp);
          pcie_ob_cfg_read(pcie_core_id,SM_PCIE_CFG0_PCIE_CFG0_MEM_BASE__ADDR);
          pcie_ob_cfg_write(pcie_core_id,SM_PCIE_CFG0_PCIE_CFG0_CMD__ADDR, 0x7);
          pcie_ob_cfg_read(pcie_core_id,SM_PCIE_CFG0_PCIE_CFG0_CMD__ADDR);
         
         // Disable IO and prefetchable bars

          temp=0x10;
          pcie_ob_cfg_write(pcie_core_id, (SM_PCIE_CFG0_PCIE_CFG0_MEM_BASE__ADDR-4), temp);
          pcie_ob_cfg_read(pcie_core_id,(SM_PCIE_CFG0_PCIE_CFG0_MEM_BASE__ADDR-4));
	 

          temp=0x10;
          pcie_ob_cfg_write(pcie_core_id, (SM_PCIE_CFG0_PCIE_CFG0_MEM_BASE__ADDR+4), temp);
          pcie_ob_cfg_read(pcie_core_id,(SM_PCIE_CFG0_PCIE_CFG0_MEM_BASE__ADDR+4));

 
          lprintf(5," Mem_Limit : Mem_Base 0x%x RTDID 0x%x\n\r",
			  pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_MEM_BASE__ADDR),
			  pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_RTDID__ADDR));


	  pri_bus=2;
	  dev_nu=9;
	  bdf= ((pri_bus << 8)|(dev_nu<<3)| func );

	  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_RTDID__ADDR,bdf);
          MSDELAY(10);

	  temp = ( mem_limit_np << 20) | mem_base_np ;
          
          pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_MEM_BASE__ADDR, temp);
          pcie_ob_cfg_write(pcie_core_id,SM_PCIE_CFG0_PCIE_CFG0_CMD__ADDR, 0x7);
          pcie_ob_cfg_read(pcie_core_id,SM_PCIE_CFG0_PCIE_CFG0_CMD__ADDR);
          pcie_ob_cfg_read(pcie_core_id,SM_PCIE_CFG0_PCIE_CFG0_MEM_BASE__ADDR);

	  temp=0x10;
          pcie_ob_cfg_write(pcie_core_id, (SM_PCIE_CFG0_PCIE_CFG0_MEM_BASE__ADDR-4), temp);
          pcie_ob_cfg_read(pcie_core_id,(SM_PCIE_CFG0_PCIE_CFG0_MEM_BASE__ADDR-4));
	  
          temp=0x10;
          pcie_ob_cfg_write(pcie_core_id, (SM_PCIE_CFG0_PCIE_CFG0_MEM_BASE__ADDR+4), temp);
          pcie_ob_cfg_read(pcie_core_id,(SM_PCIE_CFG0_PCIE_CFG0_MEM_BASE__ADDR+4));

	  lprintf(5," Mem_Limit : Mem_Base 0x%x RTDID 0x%x\n\r",
	  			  pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_MEM_BASE__ADDR),
	  			  pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_RTDID__ADDR));
/*
	  rtdid=pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_RTDID__ADDR);
  	  pri_bus=( (rtdid & 0xFF00) >> 8 ) -1 ;
  	  dev_nu=( (rtdid & 0xF8) >> 3 );
  	  bdf =
      bdf= ((bus << 8)|(dev<<3)| func );

 */
      // Program same value in RC  
          temp=0x10;
          pcie_ob_cfg_write(pcie_core_id, (SM_PCIE_CFG1_PCIE_CFG1_MEM_BASE__ADDR-4), temp);
          pcie_ob_cfg_read(pcie_core_id,(SM_PCIE_CFG1_PCIE_CFG1_MEM_BASE__ADDR-4));
	  
          temp=0x10;
          pcie_ob_cfg_write(pcie_core_id, (SM_PCIE_CFG1_PCIE_CFG1_MEM_BASE__ADDR+4), temp);
          pcie_ob_cfg_read(pcie_core_id,(SM_PCIE_CFG1_PCIE_CFG1_MEM_BASE__ADDR+4));

          temp=0x00; 
          pcie_ob_cfg_write(pcie_core_id, (SM_PCIE_CFG1_PCIE_CFG1_MEM_BASE__ADDR+8), temp);
          pcie_ob_cfg_read(pcie_core_id,(SM_PCIE_CFG1_PCIE_CFG1_MEM_BASE__ADDR+8));
 
          pcie_ob_cfg_write(pcie_core_id, (SM_PCIE_CFG1_PCIE_CFG1_MEM_BASE__ADDR+0x0C), temp);
          pcie_ob_cfg_read(pcie_core_id,(SM_PCIE_CFG1_PCIE_CFG1_MEM_BASE__ADDR+0x0C));

          pcie_ob_cfg_write(pcie_core_id, (SM_PCIE_CFG1_PCIE_CFG1_MEM_BASE__ADDR+0x10), temp);
          pcie_ob_cfg_read(pcie_core_id,(SM_PCIE_CFG1_PCIE_CFG1_MEM_BASE__ADDR+0x10));



          for(i=0;i<=30;i++)
          { 
            lprintf(5,"Config. Value of RC offset  %d = 0x%x \n\r", i ,pcie_ob_cfg_read(pcie_core_id, (SM_PCIE_CFG1_PCIE_CFG1_DEV_ID__ADDR+i*4)) );
          }

	  pri_bus=6;
	  dev_nu=0;
	  bdf= ((pri_bus << 8)|(dev_nu<<3)| func );
	  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_RTDID__ADDR,bdf);
          MSDELAY(10);
          
	  //do cfg0 write 0x4 and set memory enable bit to indicate config process is complete to endpoint
	  pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_CMD__ADDR, 0x7);
	  data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_CMD__ADDR);
	 
         
	  lprintf(5," Config. Process Stat: 0x%x RTDID 0x%x\n\r",
	 	  			  pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR),
	 	  			  pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_RTDID__ADDR));

          run_with_plx=1;
	  pri_bus=1;
          dev_nu=0;
	  bdf= ((pri_bus << 8)|(dev_nu<<3)| func );
	  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_RTDID__ADDR,bdf);
          MSDELAY(10);
          lprintf(5," Bus No.: 0x%x\n\r",pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_RTDID__ADDR));
//do cfg0 write 0x4 and set memory enable bit to indicate config process is complete to endpoint
//	  error |= sm_pcie_chk_results(0, 8, 1, 0x800000);// Check result at RC side

 }

int printf_cfg (int argc, char *argv[])
{
	int i,j,k,error=0,pcie_core_id=0;
	uint32_t bdf,bus,dev,depth,func=0;

	i=argc;

	 if (i<4)
	 {
		 error=1;
	     lprintf(5," Error in Arguments : Use : Port:BUS:dev:func:depth-\n\r");
	 }
	 else {
	      pcie_core_id=atoi(argv[j]);
		  bus = atoi(argv[j+1]);
		  dev = atoi(argv[j+2]);
		  func=atoi(argv[j+3]);
	      depth=atoi(argv[j+4]);
	    }

	// Program Bus | dev | fcn no.
	 bdf= ((bus << 8)|(dev<<3)| func );
	 {
	   pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_RTDID__ADDR,bdf);
	   MSDELAY(100);
	   lprintf(5,"Value @ RTDID 0x%x \n\r",pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_RTDID__ADDR));
	 }
	 // print Config Space
	for(i=0;i<=depth;i++)
	{
	  lprintf(5,"Config. Value offset 0x%x = 0x%x \n\r", i*4 ,pcie_ob_cfg_read(pcie_core_id, (SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR+i*4)) );
	}
}


