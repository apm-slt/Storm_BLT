/*
 * PCIE TEST
 *
 * Copyright 2012 AMCC
 *
 * This program is free software; you can redistribute  it and/or modify it
 * under  the terms of  the GNU General  Public License as published by the
 * Free Software Foundation;  either version 2 of the  License, or (at your
 * option) any later version.
 */

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/init.h>
#include <asm/io.h>
#include <linux/interrupt.h>
#include <linux/pci.h>
#include <linux/of_device.h>

#define NUM_PCI_RES		3
#define PCIE_TEST		"pcie_test"
#define PCIE_TEST_VERSION	"0.1"

#define PATTERN 0x12344321
#define OFFSET	0x100

struct bar_info {
	int	enabled;
	void	*vaddr;
	void	*paddr;
	u32	len;
};

struct pci_ep_info {
	struct pci_dev	*dev;
	int		irq;
	struct bar_info	bars[NUM_PCI_RES];
	int		num_bars;
};

static irqreturn_t pcie_test_isr(int irq, void *data)
{
	int i;
	struct pci_ep_info *ep_info = (struct pci_ep_info *) data;

	printk("%s: ENTER",__func__);
	for(i = 1; i < ep_info->num_bars; i++) {
		if(ep_info->bars[i].enabled) {
			writel(PATTERN, ep_info->bars[i].vaddr + OFFSET);
			printk("BAR%d: Written 0x%08x at offset 0x%08x\n",
				i, PATTERN, OFFSET);
			break;
		}
	}
	printk("%s: EXIT",__func__);
	return IRQ_HANDLED;	
}

static void do_outbound_test(struct pci_ep_info *ep_info)
{
	int i, rc;
	int flag = 0;

	for(i = 1; i < NUM_PCI_RES; i++) {
		if(ep_info->bars[i].enabled) {
			int j;
			for(j = 0; j < 0x10; j++) {
				void *addr = ep_info->bars[i].vaddr;
				printk("0x%llx: Write 0x%08x ",
					((long long unsigned int)addr + (j << 2)), ~i);

				writel(~j, (addr + (j << 2)));
				rc = readl(addr + (j << 2));
				printk("READ 0x%08x\n", rc);
				if (rc != ~j)
					flag = 1;
			}
			break;
		}
	}

	printk("BAR%d: OUTBOUND TEST %s\n",i,(!flag)?"PASS":"FAIL");
}

static int set_dma_mask(struct pci_dev *pdev)
{
	int rc;
	if (!pci_set_dma_mask(pdev, DMA_BIT_MASK(64))) {
		rc = pci_set_consistent_dma_mask(pdev, DMA_BIT_MASK(64));
		if (rc) {
			rc = pci_set_consistent_dma_mask(pdev, DMA_BIT_MASK(32));
			if (rc) {
				dev_err(&pdev->dev,
						"64-bit DMA enable failed\n");
				return rc;
			}
		}
	} else {
		rc = pci_set_dma_mask(pdev, DMA_BIT_MASK(32));
		if (rc) {
			dev_err(&pdev->dev, "32-bit DMA enable failed\n");
			return rc;
		}
		rc = pci_set_consistent_dma_mask(pdev, DMA_BIT_MASK(32));
		if (rc) {
			dev_err(&pdev->dev,
					"32-bit consistent DMA enable failed\n");
			return rc;
		}
	}
	return 0;
}

static int __devinit endpoint_probe(struct pci_dev *pdev,
				    const struct pci_device_id *ent)
{
	struct pci_ep_info *ep_info;
	int rc = 1;
	int i;

	printk("Probing PCIe endpoint\n");

	ep_info = (struct pci_ep_info *) kmalloc(sizeof(struct pci_ep_info), GFP_KERNEL);
	if(!ep_info)
		return rc;
	memset(ep_info, 0, sizeof(struct pci_ep_info));

	ep_info->irq = pdev->irq;
	ep_info->dev = pdev;

	rc = pcim_enable_device(pdev);
        if (rc) {
		printk("unable to enable pci device\n");
                goto cleanup;
	}

	if (pci_request_regions(pdev, PCIE_TEST))
	{
		printk("Unable to request memory regions\n");
		goto cleanup;
	}

	/* configure and activate the device */
	if(set_dma_mask(pdev))
		goto cleanup;

        /* Set max read request size to 4096.  This slightly increases
         * write throughput for pci-e variants.
         */
        pcie_set_readrq(pdev, 4096);
	pci_set_master(pdev);

	for(i = 0; i < NUM_PCI_RES; i++) {
		if (!pci_resource_len(pdev, i))
			continue;

		if (pci_resource_flags(pdev, i) & IORESOURCE_IO) {
			printk("**** Not handling PCI I/O resource\n");
			continue;
		}

		ep_info->bars[i].vaddr = ioremap(pci_resource_start(pdev, i),
						 pci_resource_len(pdev, i));
		if (!ep_info->bars[i].vaddr) {
			printk("Unable to map memory region %d\n", i);
			goto cleanup;
		}

		ep_info->bars[i].paddr   = (void *)pci_resource_start(pdev, i);
		ep_info->bars[i].len     = pci_resource_len(pdev, i);
		ep_info->bars[i].enabled = 1;
		ep_info->num_bars++;
		printk("res[%d].start : 0x%08llx\n", i, pdev->resource[i].start);
		printk("res[%d].end   : 0x%08llx\n", i, pdev->resource[i].end);
	}

	do_outbound_test(ep_info);

	printk("Registering ISR for pci irq %d\n", pdev->irq);
	rc = request_irq(pdev->irq, pcie_test_isr, IRQF_SHARED, PCIE_TEST, ep_info);
	if(rc) {
		printk("Request IRQ failed!\n");
		goto cleanup;
	}

	for(i = 1; i < ep_info->num_bars; i++) {
		if(ep_info->bars[i].enabled) {
			writel(PATTERN, ep_info->bars[i].vaddr + OFFSET);
			printk("BAR%d: Written 0x%08x at offset 0x%08x\n",
				i, PATTERN, OFFSET);
			break;
		}
	}

	return 0;

cleanup:
	kfree(ep_info);
	printk("Error gathering resource info\n");
	return -1;

}

static struct pci_device_id endpoint_pci_tbl[] = {
		{0x19AA, 0xE008},
		{0,}
};
MODULE_DEVICE_TABLE(pci, endpoint_pci_tbl);

static struct pci_driver test_driver = {
        .name     = PCIE_TEST,
        .id_table = endpoint_pci_tbl,
        .probe    = endpoint_probe,
        .remove   = NULL ,
};


/*
 *  pcie_test_init - Initializes the PCIE_TEST interface
 */

static int __init  pcie_test_init(void)
{
	int ret;

	printk(KERN_INFO "AMCC PCIE ENDPOINT TEST DRIVER\n");
	ret = pci_register_driver(&test_driver);
	return ret;
}
module_init(pcie_test_init);


/*
 *  pcie_test_exit - Releases the PCIE_TEST interface
 */
static void __exit  pcie_test_exit(void)
{
        printk("cleaning up\n");
	pci_unregister_driver(&test_driver);

}

module_exit( pcie_test_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("AMCC");
MODULE_VERSION(PCIE_TEST_VERSION);
MODULE_DESCRIPTION("PCIE_TEST Interface");

