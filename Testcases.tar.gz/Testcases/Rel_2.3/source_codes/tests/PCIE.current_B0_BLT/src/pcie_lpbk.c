/*
 * Copyright (c) 2013 AppliedMicro.  All rights reserved.
 *
 * program brief: pcie_lpbk.c: external loop back test of pcie g3 for Storm 
 * history: v0.1 2013.2
 */

#include <stdio.h>
#include "pcie_lpbk.h"
#include "pcie_isr.h"
#include "pcie_base_test.h"
#include "pcie_base.h"
#include "pcie_ib_test.h"
#include <common.h>
/* loopback test via ext PCIe short cable, no Lecroy used.
 * rc_slot,ep_slot: PCIe slot to be tested, slot #=0~2 see PCB. #1=x1 else x8x4
 * test_id: or testname, follows existing id 0~12
 */
 
 
 
#define DONE 0
#define WAIT 1
#define TICK_IN_MIN 60000000
//#define TICK_IN_MIN 2000000   // 2sec
// #define TICK_IN_MIN 1000000ULL
#define GC_FREQ 50000000ULL

#define THRES_ERR_CNT 15
extern uint32_t g_link_up;
uint32_t speed=0;width=0;
static uint32_t pass_cnt=0,fail_cnt=0;
uint32_t per_no[10];
uint32_t test_running=0;

//#ifdef STRESS_TEST


extern uint32_t RD_BW_g ;
struct error_log itr_summ;
void print_summary(struct error_log *itr_summ);
uint32_t aer_base_addr=0;
uint32_t sec_cap_addr=0;

uint32_t aer_err=0,eq_err=0,link_err=0,data_int=0,neg_err=0,
		 ep_dma_rd_err,ep_dma_wr_err,rc_dma_wr_err,rc_dma_rd_err,
         total_itr,pass_itr,fail_itr,curr_itr;
		 
uint32_t Stress_TestOnGng=0;

uint32_t err_aer=0,lnk_err=0,root_err=0;
void pcie_cfg_dump (uint32_t pcie_core_id);
int wait_min(uint64_t duration,uint64_t start_time);
uint32_t config_read(uint32_t rc_slot, uint32_t test_pattern, uint32_t length, uint32_t extended_addr);

//#endif

char *pcie_ext_cap_id[] = {
	"",												// 0 - empty
	"Advanced Error Reporting Capability", 			// 1
	"Virtual Channel Capability",					// 2
	"Device Serial Number Capability",				// 3
	"Power Budgeting Capability",					// 4
	"PCIE RC Link Declaration Capability",			// 5
	"PCIE RC Internal Link Control Capability",			// 6
	"PCIE RC Event Collector EP Association Capability",// 7
	"Multi-Function VC Capability",					// 8
	"Virtual Channel Capability",					// 9
	"RCRB Header Capability",						// 10
	"Vendor Specific Capability",					// 11
	"",												// 12 - empty
	"ACS Extended Capability",						// 13
	"ARI Capability",								// 14
	"","","",										// 15,16,17 - empty
	"Multicast Capability",							// 18 
	"", "", 										// 19, 20 - empty
	"Resizable BAR Capability",						// 21
	"Dynaic Power Allocation Capability",			// 22
	"TPH Requester Capability",						// 23
	"Latency Tolerance Reporting Capability",		// 24
	"Secondary PCIE Extended Capability"			// 25
};

uint32_t pcie_ext_cap_size[] = {
	0,		// 0 - empty
	0x40, 	// 1
	0x1C, 	// 2
	0x0C, 	// 3
	0x10, 	// 4
	0x14, 	// 5
	0x0C, 	// 6
	0x08, 	// 7
	0x1C, 	// 8
	0x1C, 	// 9
	0x10, 	// 10
	0x08, 	// 11
	0, 		// 12 - empty
	0x0C, 	// 13
	0x08, 	// 14
	0, 0, 0,// 15,16,17 - empty
	0x30, 	// 18 
	0, 0,  	// 19, 20 - empty
	0x0C, 	// 21
	0x10, 	// 22
	0x0C, 	// 23
	0x08,	// 24
	0x10,	// 25
};
uint32_t thresh_per[3]={
12500,
25000,
30000,
};

int pcie_lpbk_sub(uint32_t rc_slot, uint32_t ep_slot, uint32_t gen, uint32_t link_width, uint32_t test_id, uint32_t length)
{
    int error = 0,res=0,data=0;
    uint32_t ext_ref = 1, rc_id = rc_slot, ep_id = ep_slot;
       uint32_t extended_addr = 0;
    uint32_t itr=0,lnk_status=0;
    uint32_t test_pattern = 0;

    if (rc_slot!=0)
      rc_id++; 
    if (ep_slot!=0)
      ep_id++; 

	lprintf(5,"RC Initialization on core%1d \n", rc_id);  	
    sm_pcie_init(rc_id, 1, 0, gen, ext_ref, link_width, 0);
	MSDELAY(2000);
    lprintf(5," EP Initialization on core%1d \n", ep_id); 
    sm_pcie_init(ep_id, 0, 0, gen, ext_ref, link_width, 0);
   
    lprintf(5,"Polling for linkup through RC side\n");

    res=sm_pcie_poll_linkup(rc_id, gen, link_width, 0);
     
switch(res)
    {
    case NO_LINK:
    	printf(" >> Link up Fail<<  \n\r");
		fail_cnt+=1;
    	return(0);
    	break;
    case CORRECT_LINK:
    	//printf("  >> Link up PASS  <<  \n\r");
		print_link(rc_id);
    	break;
    case WRONG_LINK:
        print_link(rc_id);
    	printf(" >> LINK ALIVE with Incorrect Negotiation ** << \n\r",itr);
		fail_cnt+=1;
        return;
    	break;

    }

    sm_pcie_clear_ep_test_sig(ep_id);
      
    if (test_id==0) {
        error = sm_pcie_test_rc(rc_id, test_id, test_pattern, length, extended_addr);  //RC inbound
        sm_pcie_test_ep(ep_id);
    } else if (test_id==1) {  
      error = sm_pcie_test_rc(rc_id, test_id, test_pattern, length, extended_addr);   //RC outbound  
      return error;
    } else if ((test_id>=2)&&(test_id<=6)) {

#ifdef STRESS_TEST
    Stress_TestOnGng=0;
    for(itr=1;itr<=STRESS_ITR_CNT;itr++)
    {
      length=STRESS_TEST_LEN;
      lprintf(3,"**********************************************************************************************\n\r");
      lprintf(3,"                      ***    RUNNING PCIE ITERATION = %d ***                                  \n\r ",itr);
      lprintf(3,"----------------------------------------------------------------------------------------------\n\r");
      lprintf(3,"\n\r");
      lprintf(3,"FAILED COUNT =%d %d  \n\r",fail_cnt,rc_id);
      lprintf(3,"\n\r");
      lprintf(3,"\n\r");
    //  ltssm_sub(rc_id,lnk_status);  // Ugly fix
      lprintf(3,"\n\r");
      lprintf(3," ***********************************************************************************************\n\r");

     test_pattern=0;
#endif
      
      error = sm_pcie_test_rc(rc_id, test_id, test_pattern, length, extended_addr);   //RC DMA
      res=sm_pcie_poll_linkup(rc_id, gen, link_width, 0);

    switch(res)
    {
      case NO_LINK:
    	printf(" >> Link up Fail  <<  \n\r");
		fail_cnt+=1;
		print_link(rc_id);
    	return(0);
    	break;
    case CORRECT_LINK:
	    
    	//printf("  >> Link PASS  <<  \n\r");
		print_link(rc_id);
    	break;
    case WRONG_LINK:
	    fail_cnt+=1;
	    print_link(rc_id);
    	printf(" >> LINK ALIVE with Incorrect Negotiation ** << \n\r",itr);
    	break;

    }
     data = pcie_csr_read(rc_id, SM_PCIE_CSR_REGS_PCIECORE_CTLANDSTATUS__ADDR);
     speed=FIELD_PCIECORE_CTLANDSTATUS_PIPE_PHY_RATE_RD(data);
     data = pcie_csr_read(rc_id, NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_31_0__ADDR);
     width=(data & 0xfc000000)>>26;

 if( (error==0) && (res==1) )
     {
	   if(itr_summ.rc_wr_perf > thresh_per[gen])
	   {
    //    printf( " >> Data Transfer PASS << %d Mb/s\n\r",itr_summ.rc_wr_perf);
		pass_cnt+=1;
       }
	   else{
	     printf( " >> Bad Peformance Value- * BAD CHIP *  %d Mb/s<<  \n\r",itr_summ.rc_wr_perf );
		 fail_cnt+=1;
	   }

     }
     else {
      if(error)
          printf("Data Integrity Fail iteration %d \n\r",itr);
      else printf(" - BAD-CHIP - DATA INTEGRITY PASS- BUT WITH WRONG LINK NEGOTIATION  %d \n\r",itr);

      }
#ifdef STRESS_TEST
      if(error)
      {
    	  fail_cnt++;
      }

      else pass_cnt++;
#ifdef SLT_SCRREN
      print_summary(&itr_summ);   // Not required for slt screenig.
#endif		  
    }
#endif
      return error;

    } else if ((test_id>=8)&&(test_id<=12)) {



#ifdef STRESS_TEST
   for(itr=0;itr<=STRESS_ITR_CNT;itr++)
   {
	 length=STRESS_TEST_LEN;
	 error=0;
#endif

      error = sm_pcie_test_rc(rc_id, test_id, test_pattern, length, extended_addr);   //EP DMA OB-WR
      sm_pcie_test_ep(ep_id);
      error |= sm_pcie_chk_results(rc_id, test_id, test_pattern, length);             // Check result at RC side 

 #ifdef STRESS_TEST
 
  	if(itr_summ.aer_error_rc > 0) 
	   err_aer++;
    if(itr_summ.link_error > 1) 
	   lnk_err++;
  	if(itr_summ.link_error_rc > 0)  
	   root_err++;

    itr_summ.cnt=itr;
    
	if(error)
	   itr_summ.ep_dma_wr=error;

    Stress_TestOnGng=1;



    error=0;
    error = sm_pcie_test_rc(rc_id, 9, test_pattern, length, extended_addr);        //EP DMA OB-RD

    if(itr_summ.aer_error_rc > 0)
	  err_aer++;
    if(itr_summ.link_error > 1)
	  lnk_err++;
    if(itr_summ.link_error_rc > 0)
	  root_err++;

    if(error)
	  itr_summ.ep_dma_rd=error;
     sm_pcie_test_ep(ep_id);



     error=0;
     error |= sm_pcie_chk_results(rc_id, 9, test_pattern, length);                  // Check for INTx at EP side
     if(error)
	   itr_summ.ep_dma_intx=1;

      error=0;
        error = sm_pcie_test_rc(rc_id, 2, test_pattern, length, extended_addr);        //RC DMA OB-WR
    	
	  if(itr_summ.aer_error_rc > 0) err_aer++;
      if(itr_summ.link_error > 1) lnk_err++;
      if(itr_summ.link_error_rc > 0)  root_err++;

        if(error)itr_summ.rc_dma_wr=error;



      error=0;
        error = sm_pcie_test_rc(rc_id, 3, test_pattern, length, extended_addr);         //RC DMA OB-RD
    	if(itr_summ.aer_error_rc > 0) err_aer++;
    	if(itr_summ.link_error > 1) lnk_err++;
    	if(itr_summ.link_error_rc > 0) root_err++;

        if(error)itr_summ.rc_dma_rd=error;

       // ltssm_sub(rc_id,lnk_status); Ugly fix

    	data = pcie_csr_read(rc_id, SM_PCIE_CSR_REGS_PCIECORE_CTLANDSTATUS__ADDR);
    	speed=FIELD_PCIECORE_CTLANDSTATUS_PIPE_PHY_RATE_RD(data);

    	data = pcie_csr_read(rc_id, NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_31_0__ADDR);
    	width=(data & 0xfc000000)>>26;

    	print_summary(&itr_summ);

  }     // for loop ends here
#endif
}  // if(test_id == )  // Ends here
 else if(test_id==13)
 {
    	error = sm_pcie_test_rc(rc_id, test_id, test_pattern, length, extended_addr);   // RC PM
 }
 else {
      lprintf(5,"pcie_lpbk: unimplemented test_id %d\n", test_id);
      error = 1;
      return error;
    }

    return error;
}
//execute init routines before running this test, e.g pcie_cfg()
#if defined(CONFIG_VHP) | defined(CONFIG_BB1) | defined(CONFIG_BB2) //Storm test
int pcie_lpbk_test(int argc, char *argv[])
{
  int i=argc+1, j=0;
#else
int main(int argc, char *argv[])
{
  int i=argc, j=1;
#endif
  int error=0;
  uint32_t rc_slot,ep_slot,gen,link_width,test_id,len= TEST_LEN,ex_cnt=0,max_cnt=5,data=0 ; 
if ((i<7)||(i>8)) 
    error=1;  
  else {
    rc_slot = atoi(argv[j]);
    ep_slot = atoi(argv[j+1]);
    gen = atoi(argv[j+2]);
    link_width = atoi(argv[j+3]);
    test_id = atoi(argv[j+4]);
	if(argc==6)
	max_cnt =atoi(argv[j+5]);
	
    if (i==8) {
      if (strncmp(argv[j+5],"0x",2)!=0) 
        len = strtol(argv[j+5], NULL, 16);
      else
        len = strtol(argv[j+5], NULL, 0);
    }
    if (len<16)
      len = 2048;
    if (len>(1<<28))
      len = 1<<28;
    if ((gen>2)||((link_width!=1)&&(link_width!=2)&&(link_width!=4)&&(link_width!=8)))
      error=2;
    if ((rc_slot>2)||(ep_slot>2)||(rc_slot==ep_slot))
      error = 3;
  }
  if (error) {
    lprintf(3,"pcie_lpbk: argument error %1d-%d. Usage: rc_slot ep_slot gen link_width test_id [len]\n", error, i);
    lprintf(3,"           gen=0~2, link=1/2/4/8,Loop cnt,default len=32MB.\n");
    lprintf(3," test_id = 0 => RC inbound\n");
    lprintf(3,"           1 => RC outbound\n");
    lprintf(3,"           2 => Single Channel RC DMA AXI-to-PCIE\n");
    lprintf(3,"           3 => Single Channel RC DMA PCIE-to-AXI\n");
    lprintf(3,"           4 => Multi Channel RC DMA AXI-to-PCIE\n");
    lprintf(3,"           5 => Multi Channel RC DMA PCIE-to-AXI\n");
    lprintf(3,"           6 => Multi Channel RC DMA interleaved\n");
    lprintf(3,"           8 => Single Channel EP DMA AXI-to-PCIE\n");
    lprintf(3,"           9 => Single Channel EP DMA PCIE-to-AXI\n");
    lprintf(3,"           10=> Multi Channel EP DMA AXI-to-PCIE\n");
    lprintf(3,"           11=> Multi Channel EP DMA PCIE-to-AXI\n");
    lprintf(3,"           12=> Multi Channel EP DMA interleaved\n");
    return error;
  }

  fail_cnt=0;
  pass_cnt=0;
  for(ex_cnt=0;ex_cnt<max_cnt;ex_cnt++)
  {
	error = pcie_lpbk_sub(rc_slot, ep_slot, gen, link_width, test_id, len);
	per_no[ex_cnt]=itr_summ.rc_wr_perf;
	itr_summ.rc_wr_perf=0;
	data = pcie_csr_read(rc_slot, NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_31_0__ADDR);
	width = (data & 0xfc000000) >> 26;
	speed = ((data & 0x03000000)>>24) + 1;
	
   if(fail_cnt)
   { 
    printf("Iteration %d < FAIL > Gen%d x%d Throughput %d Mb/s \n\r",ex_cnt,speed,width,per_no[ex_cnt]);
    break;   
   }
   else printf("Iteration %d < PASS > Gen%d x%d Throughput %d Mb/s \n\r",ex_cnt,speed,width,per_no[ex_cnt]);
  
   printf("\n");
   printf("\n");	
  }

  return error;
}

// Following is added to verify link, with third party card mainly for SLT
int link_pcie(int argc, char *argv[])
{

	int i=argc, j=0,res=0,itr=0;
	uint32_t data, current_rate, gen_match,addr=0,err_cnt=0,speed=0,width=0;
	uint32_t status = 0,success=0;
	uint32_t linkup=0;
	uint32_t printGEN[4] = {0,1,2};
	signed int cnt=1000;
	int error=0;
    uint32_t rc_slot,pcie_core_id,gen,link_width;
    uint32_t ext_ref = 1,length=0x3fffffc,test_id=2,iteration=1,itr_cnt =0 ;

    struct ep_bar ep_bars[6];



    uint32_t test_pattern = 0;
    uint32_t extended_addr = 0;



    if (i<3)
	    error=1;
   else
   {
      rc_slot = atoi(argv[j]);
	  gen = atoi(argv[j+1]);
	  link_width = atoi(argv[j+2]);
      if(i==4) iteration=atoi(argv[j+3]);
	  if(i==5) test_id=atoi(argv[j+3]);
	  if(i==6) length=atoi(argv[j+4]);
   }

 //    if(test_id>12)
  //  	 error=5;
	  if (error) {
	    lprintf(3,"pcie_link: argument error %1d-%d. Usage: rc_slot gen link_width \n", error, i);
	    lprintf(3,"           gen=0~2, link=1/2/4/8, TID : 0/1/2/3  default len=32MB & TID : 2(RC DMA OB WR).\n");

	    return error;
	  }
	  gen_match = (link_width << 8) | gen;
	  pcie_core_id=rc_slot;

      //    pcie_reset_sub();
for(itr_cnt=1;itr_cnt<=iteration;itr_cnt++)
{
      printf("\n");      
	  lprintf(5,"INITLIZING PCIE IN RC MODE %1d\n", rc_slot);
	  //Tinh-SLT: commented out the pcie_reset_mellanox, because it causes the test to hang when running linkup test
	  pcie_reset_mellanox(rc_slot);
	  //End of Tinh-SLT
	  sm_pcie_init(rc_slot, 1, 0, gen, ext_ref, link_width, 0);
	  res=sm_pcie_poll_linkup(rc_slot, gen, link_width, 0);
	  
	  data = pcie_csr_read(rc_slot, SM_PCIE_CSR_REGS_PCIECORE_CTLANDSTATUS__ADDR);
      speed=(FIELD_PCIECORE_CTLANDSTATUS_PIPE_PHY_RATE_RD(data)+1);
	  
      data = pcie_csr_read(rc_slot, NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_31_0__ADDR);
      width=(data & 0xfc000000)>>26;
	  
    switch(res)
    {
    case NO_LINK:	  
		print_link(rc_slot);
		data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_PCIECORE_CTLANDSTATUS__ADDR);
        linkup = FIELD_PCIECORE_CTLANDSTATUS_S_LINK_UP_RD(data);  
    	lprintf(3," >> FAIL as <Data Link Layer Status : Down > RD Value= PCIeCore_CtlAndStatus[s_link_up]= %d \n\r",linkup);
		lprintf(3," >> PCIeCore_CtlAndStatus = 0x%x \n\r",data);
    	return(0);
    	break;
    case CORRECT_LINK:
    	print_link(rc_slot);
		err_cnt=config_read(rc_slot, test_pattern, length, extended_addr);
		if(err_cnt>=THRES_ERR_CNT) {
		    lprintf(3," >> Link up Fail due to high receiver error %d <<  \n\r",err_cnt);
		    return(0);
		}
		else 
			lprintf(3," >> Link PASS Gen%dx%d @ Iteration No. =  %d Recovery Cnt=%d <<\n", speed,width,itr_cnt,err_cnt);
    	break;
    case WRONG_LINK:
		print_link(rc_slot);
    	lprintf(3," >> LINK ALIVE with Incorrect Negotiation ** << \n\r",itr);
		return(0);
    	break;
    default :
	    print_link(rc_slot);
	    lprintf(3," >> Uncknown Ret Type %d ** << \n\r",res);
		return(0);
	   break;
    }
}
}


#if 0	
#ifdef PERF_2_PORTS
	  if(rc_slot==3)
	  {
		  lprintf(3,"INITLIZING PCIE IN RC MODE %1d\n", 0);
		  sm_pcie_init(0, 1, 0, gen, ext_ref, link_width, 0);
		  res=sm_pcie_poll_linkup(0, gen, link_width, 0);
	  }
	  else
	  {
		  lprintf(3,"INITLIZING PCIE IN RC MODE %1d\n", 3);
		  sm_pcie_init(3, 1, 0, gen, ext_ref, link_width, 0);
		  res=sm_pcie_poll_linkup(3, gen, link_width, 0);
	  }
#endif

/*
	  if(res == 1)                   // Link up is achieved check for link health now.
	  {
		  error = sm_pcie_test_rc(rc_slot, 51, test_pattern, length, extended_addr);    // To initlize outbound config
		  data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR) & 0xffff ;

		  lprintf(3,"  READING DEVICE ID OF DUT \n\r");
		  switch(data)
		  {
		     case 0x15b3: lprintf(3,"  * Mellanox Technology Vendor ID 0x%x \n\r",data ); break;
		 	 case 0x8086: lprintf(3,"  * Intel Corporation Vendor ID 0x%x\n\r",data); break;
		 	 case 0x8087: lprintf(3,"  * Intel Vendor ID 0x%x\n\r",data); break;
		 	 case 0x1095: lprintf(3,"  * SiI, Vendor ID 0x%x\n\r",data); break;
		 	 case 0x1000: lprintf(3,"  * LSI Logic Vendor ID 0x%x\n\r",data); break;
		 	 case 0x19aa :lprintf(3,"  * Storm APM Vendor ID 0x%x\n\r",data); break;
		 	 default : lprintf(3,"     * Uncknown Vendor ID 0x%x \n\r",data); break;

		  }

		  data = pcie_ob_cfg_read(pcie_core_id, 0x10184) ;

          for(i=0;i<=100;i++)                                    // Read few CS reg.
          {
             addr= SM_PCIE_CFG0_PCIE_CFG0_CAP__ADDR + i*4 ;
             data = pcie_ob_cfg_read(pcie_core_id, addr) ;
             if(data != 0xffffffff )
             {
            	 res=1;                                         // In case link goes into recovery

             }
             else{

            	res=0;                                          // Everything is fine and link looks good

             }
          }

	 }
	 else{                                                   // If link up is not achied correctly

	     if(res!=2)
	     {
		   lprintf(3,"Test Case FAIL \n\r ");
                   return(0);
	     }
	 }

	  if(res==1){
                  lprintf(3," **************************************************** \n");  
		  lprintf(3," Test Case PASS %d : Iteration Count %d \n\r ",itr_cnt);
                  lprintf(3," **************************************************** \n");  
                  pcie_relink_sub(pcie_core_id, gen_match, 1);
                

#ifdef PERF_2_PORTS               // Vv :Code Optimization is pending.

//	 sm_pcie_test_rc(pcie_core_id, test_name, test_pattern, length, extended_addr);

if( (test_id != 23) && (test_id != 32))
{
	 sm_pcie_test_rc(0, test_id, 1, length, 0);            // test pattern =1 Slot-0
	 sm_pcie_test_rc(3, test_id, 1, length, 0);            // Slot-2

	 data = pcie_ob_cfg_read(0, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (0 * 0x40));
	  data = data | 0x1;
	 pcie_ob_cfg_write(0, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (0 * 0x40), data);

	 data = pcie_ob_cfg_read(3, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (0 * 0x40));
	  data = data | 0x1;
	 pcie_ob_cfg_write(3, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (0 * 0x40), data);


	 do{
	 	data = pcie_ob_cfg_read(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (0 * 0x40));


	   }  while((g_Int_Status!=9) );



if((test_id==2) || (test_id == 8))
{
	lprintf(5,"Polling for All data to be received for OB_WRITE \n\r");
	while( ( pcie_csr_read(0,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR) ) & 0x4 ));
     lprintf(5,"CFG START_STOP_STATUS := 0x%x \n\r",
    	    pcie_csr_read(0,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR)));

     print_M_AXI_WR_RD(0,RD);

     while( ( pcie_csr_read(3,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR) ) & 0x4 ));
      lprintf(5," %d \n\r",g_Int_Status);
      lprintf(5,"CFG START_STOP_STATUS := 0x%x \n\r",
     	    pcie_csr_read(3,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR)));

      print_M_AXI_WR_RD(3,RD);
}
 else if((test_id==3) || (test_id == 9))
 {

    lprintf(5,"Polling for All data to be received for OB_READ \n\r");

    while( ( pcie_csr_read(0,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR) ) & 0x1 ));
    lprintf( "CFG START_STOP_STATUS := 0x%x \n\r",
   	    pcie_csr_read(0,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR)));

    print_M_AXI_WR_RD(0,WR);

    while( ( pcie_csr_read(3,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR) ) & 0x1 ));
     lprintf(5," %d \n\r",g_Int_Status);
     lprintf(5,"CFG START_STOP_STATUS := 0x%x \n\r",
    	    pcie_csr_read(3,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR)));

     print_M_AXI_WR_RD(3,WR);

 }

}
else if(test_id == 23)
{
  sm_pcie_test_rc(0, 2, 1, length, 0);            // Slot-0 WR
  sm_pcie_test_rc(3, 3, 1, length, 0);            // Slot-2-RD

  data = pcie_ob_cfg_read(0, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (0 * 0x40));
  data = data | 0x1;
  pcie_ob_cfg_write(0, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (0 * 0x40), data);

  data = pcie_ob_cfg_read(3, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (0 * 0x40));
  data = data | 0x1;
  pcie_ob_cfg_write(3, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (0 * 0x40), data);

  do{
	  data = pcie_ob_cfg_read(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (0 * 0x40));
  }while((g_Int_Status!=9));

  while( ( pcie_csr_read(0,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR) ) & 0x4 ));
     lprintf(5," %d \n\r",g_Int_Status);
     lprintf(5,"CFG START_STOP_STATUS := 0x%x \n\r",
    	    pcie_csr_read(0,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR)));

     print_M_AXI_WR_RD(0,RD);

  while( ( pcie_csr_read(3,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR) ) & 0x1 ));
    lprintf(5," %d \n\r",g_Int_Status);
    lprintf(5,"CFG START_STOP_STATUS := 0x%x \n\r",
    pcie_csr_read(3,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR)));

    print_M_AXI_WR_RD(3,WR);

}

else if(test_id == 32)
{
	sm_pcie_test_rc(0, 3, 1, length, 0);            // Slot-0 RD
    sm_pcie_test_rc(3, 2, 1, length, 0);            // Slot-2 WR

    data = pcie_ob_cfg_read(0, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (0 * 0x40));
    data = data | 0x1;
    pcie_ob_cfg_write(0, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (0 * 0x40), data);

    data = pcie_ob_cfg_read(3, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (0 * 0x40));
    data = data | 0x1;
    pcie_ob_cfg_write(3, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (0 * 0x40), data);

    do{
  	  data = pcie_ob_cfg_read(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (0 * 0x40));
    }while((g_Int_Status!=9));

    while( ( pcie_csr_read(0,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR) ) & 0x1 ));
       lprintf(5," %d \n\r",g_Int_Status);
       lprintf(5,"CFG START_STOP_STATUS := 0x%x \n\r",
      	    pcie_csr_read(0,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR)));

       print_M_AXI_WR_RD(0,WR);

    while( ( pcie_csr_read(3,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR) ) & 0x4 ));
      lprintf(5," %d \n\r",g_Int_Status);
      lprintf(5,"CFG START_STOP_STATUS := 0x%x \n\r",
      pcie_csr_read(3,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR)));


      print_M_AXI_WR_RD(3,RD);
}
else
{
	lprintf(5," Invalid Test Case ID \n\r");
}



 #endif

	  }
      else{          
	      data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_PCIECORE_CTLANDSTATUS__ADDR);
		      if(FIELD_PCIECORE_CTLANDSTATUS_S_LINK_UP_RD(data))
		      {
			      for(itr=0;itr<=10;itr++)
			      {

				      data = pcie_relink_sub(pcie_core_id, gen_match, 1);
				      if ((((data & 0xfc000000)>>26)==link_width) && (((data & 0x03000000)>>24)==gen))
				      {
					      lprintf(3,"Test Case PASS with Relink %d \n\r",itr_cnt);
					      break;
				      }
				      else
				      {

					      if(itr==10) lprintf(3,"Test Case FAIL Due to ****  BAD LINK **** %d \n\r",itr_cnt);
				      }

			      }
		      }
                      else{
                            lprintf(3,"Test Case FAIL NO LINK %d \n\r",itr_cnt);       
                          }
         }

 
 MSDELAY(1000);

} // end of multiple PCIE initlization routine

//#define EP_TD_1_58
#ifdef EP_TD_1_58
	  lprintf(5,"TD_1_58_SecondaryPCIExpressExtendedCapabilityStructureTest : \n\r"
			  " Testing Register: Link Control 3 Register  : 0x%x \n\r ",
			    pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR | 0x184)
		    );
/*
	  addr= SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR | 0x184 ;
	  data= (pcie_ob_cfg_read(pcie_core_id, (SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR | 0x184) ) ) | 0x1 ;
	  pcie_ob_cfg_write(pcie_core_id,addr,data);
*/
	  addr= SM_PCIE_CFG1_PCIE_CFG1_DEV_ID__ADDR | 0x184 ;
	  data= (pcie_ob_cfg_read(pcie_core_id, (SM_PCIE_CFG1_PCIE_CFG1_DEV_ID__ADDR | 0x184) ) ) | 0x1 ;


	  pcie_ob_cfg_write(pcie_core_id,addr,data);



	  /*
	  pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR | 0x184) ;
	  lprintf(5," Link Capabilities - Register  : 0x%x \n\r ",
	  				 pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR | 0x4C)
	  			    );
	  */
	  lprintf(5," Link Control- Register  : 0x%x \n\r ",
				 pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_DEV_ID__ADDR | 0x50)
			    );

	  addr= SM_PCIE_CFG1_PCIE_CFG1_DEV_ID__ADDR | 0x50 ;
	  data = pcie_ob_cfg_read(pcie_core_id,addr);
	  data |= (1 << 5);
	  pcie_ob_cfg_write(pcie_core_id,addr,data);

	  lprintf(5," Link Control- Register  : 0x%x \n\r ",
	 				 pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_DEV_ID__ADDR | 0x50)
	 			    );

	  pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_DEV_ID__ADDR | 0x184) ;

	  success = sm_pcie_chk_eq_result(pcie_core_id);
	  if(success)
	    lprintf(5,"Equalization successful\n\r");
	  else
	    lprintf(5,"Equalization failed\n\r");

	//  lprintf(5,"Link Staus " pcie_csr_read(pcie_core_id, (EXPRESSO_PCIE_STATUS_PCIE_STATUS_1023_992));




	  return(0);
}
#endif

uint32_t config_read(uint32_t rc_slot, uint32_t test_pattern, uint32_t length, uint32_t extended_addr) {
	uint32_t error,data,addr=0;
	uint32_t i, rcv_err=0, recovery_cnt=0,res=0;
	sm_pcie_setup_ob_cfg(rc_slot, RC);             
	sm_pcie_setup_ob_space(rc_slot, RC); 
	//error = sm_pcie_test_rc(rc_slot, 51, test_pattern, length, extended_addr);    // To initlize outbound config
	//data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR) & 0xffff ;
	data = pcie_ob_cfg_read(rc_slot, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR) & 0xffff ;
    lprintf(5,"  READING DEVICE ID OF DUT \n\r");
	switch(data)
	{
	    case 0x15b3: lprintf(3,"  * Mellanox Technology Vendor ID 0x%x\r",data ); break;
	    case 0x8086: lprintf(3,"  * Intel Corporation Vendor ID 0x%x\r",data); break;
		case 0x8087: lprintf(3,"  * Intel Vendor ID 0x%x\r",data); break;
	 	case 0x1095: lprintf(3,"  * SiI, Vendor ID 0x%x\r",data); break;
	 	case 0x1000: lprintf(3,"  * LSI Logic Vendor ID 0x%x\r",data); break;
	 	case 0x19aa :lprintf(3,"  * Storm APM Vendor ID 0x%x\r",data); break;
	 	default : lprintf(3,"     * Uncknown Vendor ID 0x%x\r",data); break;
    }



	for(i=0;i<=1000;i++)                                    // Read few CS reg.
    {
        data=pcie_ob_cfg_read(rc_slot, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR);
        if(data != 0xffffffff ) {
		    data=0;
			pcie_ob_cfg_read(rc_slot, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR);
			data = pcie_ob_cfg_read(rc_slot, 0x110); //read correctable error status register
			rcv_err = data & 0x1; //bit 0 is receiver error
            if (rcv_err)
            { 
		     pcie_ob_cfg_write(rc_slot,0x110, data);  //clear correctable error status register
			 recovery_cnt += rcv_err;
		    }
		}
        else 
          	res = 99;                                         // In case link goes into recovery 
    }
	 return(recovery_cnt);
}

#ifdef STRESS_TEST 

void print_summary(struct error_log *itr_summ)
{


  
	lprintf(3,"*************************************************************\n\r");
	lprintf(3,"*********************   CURRENT ITERATION  NO. %d : *********\n\r",itr_summ->cnt );
	lprintf(3,"*********************   PASS: %d : **************************\n\r",pass_itr);
	lprintf(3,"*********************   FAIL. %d : **************************\n\r",fail_itr);
	lprintf(3,"*************************************************************\n\r");

	total_itr++;

        lprintf(3,"\n\r");
	lprintf(3,"Iteration No.: 0%d \n\r",itr_summ->cnt);
	lprintf(3,"Link Status: Gen%dX%d \n\r",(speed+1),width);
	lprintf(3,"Link Eq. Status:  %d \n\r",itr_summ->eq_status);
/*
	lprintf(3,"Root Error :  0x%x \n\r",itr_summ->link_error_rc);
	lprintf(3,"Link Error On RC :  0x%x \n\r",itr_summ->link_error);
	lprintf(3,"AER Status On RC :  0x%x \n\r",itr_summ->aer_error_rc);
*/
	lprintf(4,"Root Error :  0x%x \n\r",root_err);
        lprintf(4,"Link Error On RC :  0x%x \n\r",lnk_err);
        lprintf(4,"AER Status On RC :  0x%x \n\r",err_aer);

	lprintf(4,"Error_cnt_EP-DMA-OB-WR: %d \n\r",itr_summ->ep_dma_wr);
	lprintf(4,"Error_cnt_EP-DMA-OB-RD: %d \n\r",itr_summ->ep_dma_rd);
	lprintf(4,"Error_cnt_RC-DMA-OB-WR: %d \n\r",itr_summ->rc_dma_wr);
	lprintf(4,"Error_cnt_RC-DMA-OB-RD: %d \n\r",itr_summ->rc_dma_rd);

    lprintf(4,"RC-RD-Perf: %d Gb/s %d \n\r",itr_summ->rc_rd_perf);
    lprintf(4,"RC-WR-Perf: %d Gb/s %d \n\r",itr_summ->rc_wr_perf );
    lprintf(4,"EP-RD-Perf: %d Gb/s %d\n\r",itr_summ->ep_rd_perf );
    lprintf(4,"EP-WR-Perf: %d Gb/s %d \n\r",itr_summ->ep_wr_perf);

    if( (speed !=2) || (width != 8) )
    {
    	neg_err++;
    }
    	if(itr_summ->eq_status==1)
    	eq_err++;
    if(itr_summ->link_error > 1)
        link_err++;

#if 0
    if((itr_summ->link_error_rc > 0)||
       (itr_summ->link_error > 0)||
       (itr_summ->link_error_ep > 1) )
    	aer_err++;

#endif

    if( (root_err)||
        (lnk_err)||
        (err_aer) )

    aer_err++;



    if(itr_summ->ep_dma_wr != 0)
        ep_dma_wr_err++;
    if(itr_summ->ep_dma_rd !=0 )
    	ep_dma_rd_err++;
    if(itr_summ->rc_dma_wr !=0)
        rc_dma_wr_err++;
    if(itr_summ->rc_dma_rd !=0)
        rc_dma_rd_err++;

    curr_itr = ( neg_err || link_err || aer_err || ep_dma_wr_err || ep_dma_rd_err|| rc_dma_wr_err || rc_dma_rd_err);
    
    if(curr_itr)
     fail_itr++;
    else pass_itr++;


    curr_itr=0;

    if( (itr_summ->cnt)  >= STRESS_ITR_CNT)
    {

    	lprintf(3,"*********************************************\n\r");
    	lprintf(3,"***    STRESS TEST SUMMARY          ***\n\r");
    	lprintf(3,"*********************************************\n\r");

    	lprintf(3,"TOTAL Iteration : %d  \n\r",total_itr);
    	lprintf(3,"Fail : %d  \n\r",fail_itr);
    	lprintf(3,"Pass : %d  \n\r",pass_itr);

        lprintf(4,"Link Neg. Error : %d  \n\r",neg_err);
        lprintf(4,"Link Equ. Error : %d  \n\r",eq_err);

        lprintf(4,"RC DMA RD. Error : %d \n\r",rc_dma_rd_err);
        lprintf(4,"RC DMA WR. Error : %d \n\r",rc_dma_wr_err);
        lprintf(4,"EP DMA WR. Error : %d \n\r",ep_dma_wr_err);
        lprintf(4,"EP DMA RD. Error : %d \n\r",ep_dma_rd_err);

        lprintf(4,"Link Error %d : \n\r",link_err);
        lprintf(4,"AER Error %d : \n\r",aer_err);

        pass_itr=0;
        fail_itr=0;
        Stress_TestOnGng=1;

        lprintf(5,"RC AER Uncorrectable Error Status Register  : 0x%x \n\r",pcie_ob_cfg_read(0, (SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+4)));
        itr_summ->aer_error_rc=pcie_ob_cfg_read(0, (SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+4));

      	lprintf(5,"RC AER Correctable Error Status Register  : 0x%x \n\r",pcie_ob_cfg_read(0, (SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+0x10)));
      	itr_summ->link_error=pcie_ob_cfg_read(0, (SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+0x10));

      	itr_summ->link_error_rc=pcie_ob_cfg_read(0, (SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+0x30));
      	lprintf(5,"RC AER Root Error Status  : 0x%x \n\r",pcie_ob_cfg_read(0, (SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+0x30)) );


        lprintf(5,"EP AER Uncorrectable Error Status Register  : 0x%x \n\r",pcie_ob_cfg_read(0, (aer_base_addr+4)));
        itr_summ->aer_error_rc=pcie_ob_cfg_read(0, (aer_base_addr+4));

      	lprintf(5,"EP AER Correctable Error Status Register  : 0x%x \n\r",pcie_ob_cfg_read(0, (aer_base_addr+0x10)));
      	itr_summ->link_error=pcie_ob_cfg_read(0, (aer_base_addr+0x10));

      	itr_summ->link_error_rc=pcie_ob_cfg_read(0, (aer_base_addr+0x30));
      	lprintf(5,"EP AER Root Error Status  : 0x%x \n\r",pcie_ob_cfg_read(0, (aer_base_addr+0x30)) );
    }


	itr_summ->cnt=0;
	itr_summ->link_error=0;
	itr_summ->eq_status=0;
	itr_summ->ep_dma_wr=0;
	itr_summ->ep_dma_rd=0;
	itr_summ->rc_dma_wr=0;
	itr_summ->rc_dma_rd=0;

	itr_summ->rc_wr_perf=0;
	itr_summ->rc_rd_perf=0;
	itr_summ->ep_wr_perf=0;
	itr_summ->ep_rd_perf=0;

	lprintf(3,"**********************************************************************************************\n\r");
}
#endif

#define CNT_PER_MIN 3500000
#define MIN_HR      60

int run_cfg(int argc, char *argv[])
{
	int i,j=0, k, devid, class, linkerr;
	uint32_t data, gen, width, status, link_width, link_speed, expected_width,pcie_core_id ;
	static uint32_t counter=0; 
	uint32_t duration=0,recovery_cnt=0,cnt;
	uint32_t min,hour=0;
    int rcv_err;

	if (argc < 2){
		lprintf(5,"not enough argument portid, count \n\r");
		return -1;
	} 
	else {
		pcie_core_id = atoi(argv[0]);
		duration = atoi(argv[1]);
	}
	
	sm_pcie_setup_ob_cfg(pcie_core_id, RC);             
	sm_pcie_setup_ob_space(pcie_core_id, RC);  

	//cnt = duration*30000;
	cnt = duration*CNT_PER_MIN;
	status=0x400; 

	data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_31_0__ADDR);
	link_width = (data & 0xfc000000) >> 26;
	link_speed = (data & 0x03000000)>>24 ;
	lprintf(5,"Current Link @ Gen%dx%d \n",(link_speed+1),link_width);
	lprintf(5,"New Summer cal - Running with Preset %d \n", 
			FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0_CFG_8G_CONSTANTS_MGMT_US_PORT_TX_PRESET_RD(
				pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0__ADDR))));

	lprintf(5,"Will print error count only when error is detected \n\r");
	if(duration==0)
	{
		while(1)
		{
			lprintf(5,"In forever loop \n\r");
            cnt++;
			min=cnt/CNT_PER_MIN;
			//		    hour+=min/MIN_HR;
			if(min>59)
			{
				min=0;
				cnt=0;
				hour++;
			}
			pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR);
			data = pcie_ob_cfg_read(pcie_core_id, 0x110); //read correctable error status register
			rcv_err = data & 0x1; //bit 0 is receiver error
            if (rcv_err) pcie_ob_cfg_write(pcie_core_id,0x110, data);  //clear correctable error status register
			//data = pcie_ob_cfg_read(pcie_core_id,SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+0x10)&0x1;
			//if (data) pcie_ob_cfg_write(pcie_core_id,SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+0x10,data);
			recovery_cnt += rcv_err;
			//recovery_cnt += pcie_ob_cfg_read(pcie_core_id, (aer_base_addr+0x10)) & (0x1);
			//pcie_ob_cfg_write ( pcie_core_id, (aer_base_addr+0x10) ,
			//	    pcie_ob_cfg_read(pcie_core_id, (aer_base_addr+0x10))
			//	    );   
			if(rcv_err)
                lprintf(5,"Hour = %d : Minutes = %d : CorrErrCnt = %d (AER rd val 0x%x) \r",hour,min,recovery_cnt,data);  

		}
	}
	else{
		for (i=1;i<=cnt;i++) {
			j++;
			min=j/CNT_PER_MIN;
			//		     hour+=min/MIN_HR;
			if(min>59)
			{
				min=0;
				hour++;
				j=0;
			}
			pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR);
			//data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+0x10)&0x1;
			data = pcie_ob_cfg_read(pcie_core_id, 0x110); //read correctable error status register
			rcv_err = data & 0x1; //bit 0 is receiver error
            if (rcv_err) pcie_ob_cfg_write(pcie_core_id,0x110,1); //clear correctable error status register
			recovery_cnt += rcv_err;
			//recovery_cnt += pcie_ob_cfg_read(pcie_core_id, (aer_base_addr+0x10)) & (0x1);
			//pcie_ob_cfg_write ( pcie_core_id, (aer_base_addr+0x10) ,
			//                    pcie_ob_cfg_read(pcie_core_id, (aer_base_addr+0x10))
			//                  ); 
			if(rcv_err)
                lprintf(5,"Hour = %d : Minutes = %d : CorrErrCnt = %d (AER rd val 0x%x) \r",hour,min,recovery_cnt,data);  
		}
	}
	lprintf(5,"\n");
	lprintf(5,"Test Ran Successfully with recovery cnt %d \n",recovery_cnt);
	return data;
}

int rerun_eq(int argc, char *argv[])
{
	int i,j, k, devid, class, linkerr;
	uint32_t data, gen, width, status, link_width, link_speed, expected_width,pcie_core_id ;
	static uint32_t counter=0; 
	uint32_t duration=0,recovery_cnt=0,cnt;
	uint32_t phase,tx_prest,coeff,success,addr;



	if (argc < 1){
		lprintf(5,"not enough argument portid, count \n\r");
		return -1;
	} else {
		pcie_core_id = atoi(argv[0]);
		phase = atoi(argv[1]);
		tx_prest = atoi(argv[2]);
		coeff = atoi(argv[3]);

	}

	lprintf(5,"TD_1_58_SecondaryPCIExpressExtendedCapabilityStructureTest : \n\r"
			" Testing Register: Link Control 3 Register  : 0x%x \n\r ",
			pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR | 0x184)
	      );
	/*
	   addr= SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR | 0x184 ;
	   data= (pcie_ob_cfg_read(pcie_core_id, (SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR | 0x184) ) ) | 0x1 ;
	   pcie_ob_cfg_write(pcie_core_id,addr,data);
	 */
	addr= SM_PCIE_CFG1_PCIE_CFG1_DEV_ID__ADDR | 0x184 ;
	data= (pcie_ob_cfg_read(pcie_core_id, (SM_PCIE_CFG1_PCIE_CFG1_DEV_ID__ADDR | 0x184) ) ) | 0x1 ;

	pcie_ob_cfg_write(pcie_core_id,addr,data);


	/*
	   pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR | 0x184) ;
	   lprintf(5," Link Capabilities - Register  : 0x%x \n\r ",
	   pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR | 0x4C)
	   );
	 */
	lprintf(5," Link Control- Register  : 0x%x \n\r ",
			pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_DEV_ID__ADDR | 0x50)
	      );

	addr= SM_PCIE_CFG1_PCIE_CFG1_DEV_ID__ADDR | 0x50 ;
	data = pcie_ob_cfg_read(pcie_core_id,addr);
	data |= (1 << 5);
	pcie_ob_cfg_write(pcie_core_id,addr,data);

	lprintf(5," Link Control- Register  : 0x%x \n\r ",
			pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_DEV_ID__ADDR | 0x50)
	      );

	pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_DEV_ID__ADDR | 0x184) ;

	success = sm_pcie_chk_eq_result(pcie_core_id);
	if(success)
		lprintf(5,"Equalization successful\n\r");
	else
		lprintf(5,"Equalization failed\n\r");

	//  lprintf(5,"Link Staus " pcie_csr_read(pcie_core_id, (EXPRESSO_PCIE_STATUS_PCIE_STATUS_1023_992));

}
int cfg_eq(int argc, char *argv[])
{


  int i,j, k, devid, class, linkerr;
    uint32_t data, gen, width, status, link_width, link_speed, expected_width,pcie_core_id ;
    static uint32_t counter=0; 
    uint32_t duration=0,recovery_cnt=0,cnt;
    uint32_t phase,tx_prest,coeff,success,addr;

   if (argc < 3){
       lprintf(5,"not enough argument portid, count \n\r");
       return -1;
    } else {
	    pcie_core_id = atoi(argv[0]);
	    phase = atoi(argv[1]);
	    tx_prest = atoi(argv[2]);
	    if(argc==4) coeff = atoi(argv[3]);
    }
  
   switch(phase)
   {
	    case 1:lprintf(5,"Setting the preset values for PCIE\n\r");
		   data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0__ADDR));
		   data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0_CFG_8G_CONSTANTS_MGMT_DS_PORT_TX_PRESET_SET(data, 0x7);
		   data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0_CFG_8G_CONSTANTS_MGMT_US_PORT_TX_PRESET_SET(data, tx_prest);

		 
		   pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0__ADDR), data);
		   data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0__ADDR));

		   lprintf(5,"Equalization Status in Gen3 Link : 0x%x \n\r",
				   pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0__ADDR)));

		   //RC mode phase 3 and endpoint mode phase 2, USE_PRESET bit is set by default. select PRESET 7 for remote transmitter
		   data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_287_256__ADDR);
		   data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_287_256_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE0_SET(data, tx_prest);
		   data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_287_256_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE1_SET(data, tx_prest);
		   pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_287_256__ADDR, data);

		   data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_319_288__ADDR);
		   data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_319_288_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE2_SET(data, tx_prest);
		   data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_319_288_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE3_SET(data, tx_prest);
		   pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_319_288__ADDR, data);

		   data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_351_320__ADDR);
		   data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_351_320_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE4_SET(data, tx_prest);
		   data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_351_320_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE5_SET(data, tx_prest);
		   pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_351_320__ADDR, data);

		   data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_383_352__ADDR);
		   data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_383_352_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE6_SET(data, tx_prest);
		   data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_383_352_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE7_SET(data, tx_prest);
		   pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_383_352__ADDR, data);

		   break;
	    case 2:
		   // First clear the TX_PARAMS_VALID bit of the PIPECTLREG.
		   data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_PIPECTLREG__ADDR);
		   data = FIELD_PIPECTLREG_PHY_EQ_TX_PARAMS_VALID_SET(data, 0);
		   pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIPECTLREG__ADDR, data);

		   //FS/LF adjustment from KC
		   data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_PIPECTLREG__ADDR);
		   data = FIELD_PIPECTLREG_PHY_EQ_TX_FS_SET(data, 0x36);   
		   data = FIELD_PIPECTLREG_PHY_EQ_TX_LF_SET(data, 0x10);   
		   data = FIELD_PIPECTLREG_PHY_EQ_TX_MAX_PRE_SET(data, 0x6); 
		   data = FIELD_PIPECTLREG_PHY_EQ_TX_MAX_POST_SET(data, 0xf);
		   //data = FIELD_PIPECTLREG_PHY_EQ_TX_MAX_PRE_SET(data, 0x12); 
		   //data = FIELD_PIPECTLREG_PHY_EQ_TX_MAX_POST_SET(data, 0xa);
		   data = FIELD_PIPECTLREG_PHY_EQ_TX_PARAMS_VALID_SET(data, 1);
		   pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIPECTLREG__ADDR, data);

		   break;
	   case 3:
		   break;
           default:
                   break;  
   }
    
}  

/* Serdes Tuning Code Here  - Added by Shripad */

int pcie_serdes_tuning(uint32_t pcie_core_id, uint32_t CTLE,uint32_t PQ_REG,uint32_t DFE, uint32_t PRESET){
/*
    This Function is used for changing the PCIE SERDES Parameters 
    1) pcie_core_id = 0,1,2 (Slot on the board)
    2) CTLE_EQ
      =========
        Description  : CTLE Boost control,  [4:2] = AC Gain [1:0] = DC Gain
        Values        : We leave DC Gain at 2'd0
                         AC gain should be varied from 3'd0 to 3'd7
    3) PQ_REG
        =======
        Description :   Programmable PQ (data sampling) skew. Larger the value, farther away from 
                      nominal sampling position (midpoint between crossings). 
        Values       :   7'd8  to  7'd18
        NOTE: Need to check if the PQ_SIGN needs to be -ve or +ve
    4) DFE
        ======
        Description : The purpose of DFE block is to cancel inter-symbol interference present in high speed backplane data communication. 
                    It has adaptive structure to adjust to different backplane channels and noise conditions. 
        Values       : 2 tap and 3 tap

    5)Presets
        ======
        Desc.      : Refer PCIe-SIG
        Values      : 0,1,2,3,6,7

*/    
	uint32_t data ; 
	uint32_t ch=0; 
	uint32_t sds2_offset_1=0; 
	uint32_t sds2_offset_2=0x30000; 
	int i;
	uint32_t gen_match=0;
	uint32_t gen=2,link_width=8;


	//----- Preset  ----- ///
	data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0__ADDR));
	data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0_CFG_8G_CONSTANTS_MGMT_US_PORT_TX_PRESET_SET(data, PRESET); // 01,2,3 -- Value BB3
	pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0__ADDR), data);
	data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0__ADDR));
	// After the Preset is Changed PCIe need to relink //      
	gen_match = (link_width << 8) | gen;
	pcie_relink_sub(pcie_core_id, gen_match, 1);

	for(ch=0;ch<4;ch++){
		// ---------------------------------
		// ----- Lane 0 to 3 ---------------
		// ---------------------------------
		//----- CTLE  ----- ///
		// Port-0 (Lane-0 to 3)
		data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG1__ADDR + (0x200 * ch) + sds2_offset_1); 
		data = FIELD_CH0_RXTX_REG1_CTLE_EQ_SET(data, CTLE); // Shripad Added
		pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG1__ADDR + (0x200 * ch) + sds2_offset_1, data); // Shripad Added


		//----- PQ_REG  ----- ///
		// Port-0 (Lane-0 to 3)
		data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG125__ADDR + (0x200 * ch) + sds2_offset_1);
		data = FIELD_CH0_RXTX_REG125_PQ_REG_SET(data, PQ_REG);  // 0x11 or 0x12 (Go Downward)
		data = FIELD_CH0_RXTX_REG125_PHZ_MANUAL_SET(data, 0x1);
		pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG125__ADDR + (0x200 * ch) + sds2_offset_1, data);

		//----- DFE  ----- ///
		// Port-0 (Lane-0 to 3)
		data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG28__ADDR + (0x200 * ch) + sds2_offset_1);
		data = DFE; //DFE tab enables // 7 or 3 (Go downward) 
		pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG28__ADDR + (0x200 * ch) + sds2_offset_1, data);

		// ---------------------------------
		// ----- Lane 4 to 7 ---------------
		// ---------------------------------
		//----- CTLE  ----- ///
		// Port-0 (Lane-4 to 7)
		data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG1__ADDR + (0x200 * ch) + sds2_offset_2); // Shripad Added
		data = FIELD_CH0_RXTX_REG1_CTLE_EQ_SET(data, CTLE); // Shripad Added
		pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG1__ADDR + (0x200 * ch) + sds2_offset_2, data); // Shripad Added



		//----- PQ_REG  ----- ///
		// Port-0 (Lane-4 to 7)
		data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG125__ADDR + (0x200 * ch) + sds2_offset_2);
		data = FIELD_CH0_RXTX_REG125_PQ_REG_SET(data, PQ_REG);  // 0x11 or 0x12 (Go Downward)
		data = FIELD_CH0_RXTX_REG125_PHZ_MANUAL_SET(data, 0x1);
		pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG125__ADDR + (0x200 * ch) + sds2_offset_2, data);

		//----- DFE  ----- ///
		// Port-0 (Lane-4 to 7)
		data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG28__ADDR + (0x200 * ch) + sds2_offset_2);
		data = DFE; //DFE tab enables // 7 or 3 (Go downward) 
		pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG28__ADDR + (0x200 * ch) + sds2_offset_2, data);

	}

/*
  //increase tx amp, channel 0 bit location is different from rest of channels
      data = pcie_phy_csr_read(pcie_core_id, KC_PIPE_REGS_SERDES_CONTROL3__ADDR);
      data = FIELD_SERDES_CONTROL3_P2S_I_TX_AMP_EN_LN0_SET(data, 0x1); // Default = 1
      data = FIELD_SERDES_CONTROL3_P2S_I_TX_AMP_LN0_SET(data, 0xf);
      pcie_phy_csr_write(pcie_core_id, KC_PIPE_REGS_SERDES_CONTROL3__ADDR, data);

  for (i = 0; i<7; i++){
    //increase tx amp
    data = pcie_phy_csr_read(pcie_core_id, KC_PIPE_REGS_SERDES_CONTROL4__ADDR + (i *4));
    data = FIELD_SERDES_CONTROL4_P2S_I_TX_AMP_EN_LN1_SET(data, 0x0); // Default = 1
    data = FIELD_SERDES_CONTROL4_P2S_I_TX_AMP_LN1_SET(data, 0xf);
    pcie_phy_csr_write(pcie_core_id, KC_PIPE_REGS_SERDES_CONTROL4__ADDR + (i *4) , data);
  }
*/

//    lprintf("**** CURRENT TUNING VALUES **** \n\r");
//    lprintf(5,"CTLE = 0x%x : PQ_REG = 0x%x : DFE = 0x%x : PRESET = 0x%x  \n\n\r", CTLE, PQ_REG, DFE, PRESET);
}

int pcie_config_read(uint32_t pcie_core_id, uint32_t duration)
{
/*
    This Function will read the Config Space of the PCIe Card connected on the Slot 
    pcie_core_id = 0,1,2 (This is actually Slot on the board)
    duration = Number of minutes to run (It is derived from the read count and not by actual time)

*/    
    int i,j=0, k, devid, class, linkerr;
    uint32_t data, gen, width, status, link_width, link_speed, expected_width;
    static uint64_t counter=0,stime=0; 
    uint32_t recovery_cnt=0,cnt;
    uint32_t min,hour=0;

    sm_pcie_setup_ob_cfg(pcie_core_id, RC);             
    sm_pcie_setup_ob_space(pcie_core_id, RC);  

    cnt = 5 * CNT_PER_MIN;
    status=0x400; 

	
    data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_31_0__ADDR);
    link_width = (data & 0xfc000000) >> 26;
    link_speed = (data & 0x03000000)>>24 ;
    //    lprintf(5,"Current Link @ Gen%dx%d \n",(link_speed+1),link_width);
    //    lprintf(5,"New Summer cal - Running with Preset %d \n", 
    FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0_CFG_8G_CONSTANTS_MGMT_US_PORT_TX_PRESET_RD(
		    pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0__ADDR)));

    // Read it for the 1st time to clear it 
    pcie_ob_cfg_write( pcie_core_id, 0x110, pcie_ob_cfg_read(pcie_core_id, 0x110)&0x1);   
    pcie_ob_cfg_write( pcie_core_id, (aer_base_addr+0x10) , pcie_ob_cfg_read(pcie_core_id, (aer_base_addr+0x10)));   

    if(duration==0)
    {
	    while(1)
	    {
		    cnt++;
		    min=cnt/CNT_PER_MIN;
		    if(min>59)
		    {
			    min=0;
			    cnt=0;
			    hour++;
		    }
		
		    pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR);
		    data = pcie_ob_cfg_read(pcie_core_id,SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+0x10)&0x1;   
		    if (data) pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_AER_ENH_CAP__ADDR+0x10, data);   
		    recovery_cnt += data;
		    //recovery_cnt += pcie_ob_cfg_read(pcie_core_id, (aer_base_addr+0x10)) & (0x1);
		    //pcie_ob_cfg_write ( pcie_core_id, (aer_base_addr+0x10) ,
		    //	    pcie_ob_cfg_read(pcie_core_id, (aer_base_addr+0x10))
		    //	    );   
		    //lprintf(5,"Hour = %d : Minutes = %d : CorrErrCnt = %d \r",hour,min,recovery_cnt);   
	    }
    }
    else{
    SYNC();
	__asm__ volatile ("mrs %0, cntpct_el0": "=r"(stime));
		  
	//  for (i=1;i<=cnt;i++)                  // is 5 min over ?
	do {
		    devid = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR);
		    data = pcie_ob_cfg_read(pcie_core_id,0x110)&0x1;   
		    if (data) pcie_ob_cfg_write(pcie_core_id,0x110,1);   
		    recovery_cnt += data;
		    if (devid == 0xFFFFFFFF) { // link is broken
			    recovery_cnt = 99; 
			    break;
		    }
		    if (recovery_cnt > 32) { // too many errors
			    recovery_cnt = 33; 
			    break;
		    }
             //recovery_cnt += pcie_ob_cfg_read(pcie_core_id, (aer_base_addr+0x10)) & (0x1);
             //pcie_ob_cfg_write ( pcie_core_id, (aer_base_addr+0x10) ,
             //                    pcie_ob_cfg_read(pcie_core_id, (aer_base_addr+0x10))
             //                  ); 
             //lprintf(5,"Hour = %d : Minutes = %d : CorrErrCnt = %d (%d)\r",hour,min,recovery_cnt, data);  
			 SYNC();
	    } while(wait_min(duration,stime));
    }
    //lprintf(3,"\n");
    //lprintf(3,"Test Ran Successfully with recovery cnt %d \n",recovery_cnt);
    return recovery_cnt;
}//  pcie_config_read

int pcie_margin(int argc, char *argv[])
{
	/* This is a Top Level function used from the command prompt 
	   parameters passed are portid and read Count (in minutes) 
	 */    
	uint32_t pcie_core_id,port_type,en_lpbk,gen,ext_ref,link_width;
	uint32_t duration=0,recovery_cnt=0;
	uint32_t min,hour=0;
	uint32_t data= 0;
	struct s_pcie_serdes_param serdes;
	int i;

	serdes.CTLE=0x10; //Mask with 0x1C to get 4:2 AC Gain (Boost) variable and DC Gain (1:0)=0x0 - Default for BB3 Socket and BB2C 
	//	serdes.CTLE=0x8; //Mask with 0x1C to get 4:2 AC Gain (Boost) variable and DC Gain (1:0)=0x0
	serdes.PQ_REG=0x11; // Good for BB3 Socket and BB2RevC
	serdes.DFE=0x7;
	serdes.PRESET=0x2;  // Default
	//	serdes.PRESET=0x7;  // Default

	uint32_t CTLE_AC_GAIN = (serdes.CTLE & 0x1C) ;// 4:2
	uint32_t CTLE_DC_GAIN = serdes.CTLE & 0x3 ;// 1:0

	if (argc < 2){
		lprintf(5,"not enough argument portid, count \n\r");
		return -1;
	} else {
		pcie_core_id = atoi(argv[0]);
		duration = atoi(argv[1]);
	}

	// Call PCIE INIT
	port_type = 1;  // RC
	en_lpbk = 0; 	// Port-to-Port LB disabled
	gen = 2;		// Gen3 fixed; need to be changed to support GEN2
	ext_ref = 1;	// Always external refclk
	link_width= 8;	// Fixed as 8 lane, need to be changed to support x4
	data= 0; 		// ? 
	sm_pcie_init(pcie_core_id, port_type, en_lpbk, gen, ext_ref, link_width, data);

	// Check EP config space
	pcie_cfg_dump(pcie_core_id);

	lprintf(5,"\n");
	lprintf(5,"---------------------------------------------------------------------------\n");
	lprintf(5,"\n");
	lprintf(5,"############################################################\n");
	lprintf(5,"###     New Serdes Values Running With                   ###\n");
	lprintf(5,"############################################################\n");
	for (serdes.PRESET=3; serdes.PRESET< 8; serdes.PRESET++)  // Range 1 to 8 
	{ 
		lprintf(5,"PRESET = 0x%x, DFE = 0x%x : \n", serdes.PRESET, serdes.DFE);
		lprintf(5,"  PQ_REG :", serdes.PQ_REG);
		for (serdes.PQ_REG=0x9; serdes.PQ_REG< 0x12; serdes.PQ_REG++) lprintf(3," %02d", serdes.PQ_REG);
		lprintf(5,"\n");
		for(serdes.CTLE=1;serdes.CTLE < 7; serdes.CTLE++) // CTLE AC GAIN is changed only  - Range 1 to 7 
		{
			lprintf(5,"CTLE = %02d:", (serdes.CTLE <<2));
			for (serdes.PQ_REG=0x9; serdes.PQ_REG< 0x12; serdes.PQ_REG++)
			{
				pcie_serdes_tuning(pcie_core_id,(serdes.CTLE<<2),serdes.PQ_REG,serdes.DFE,serdes.PRESET);
				recovery_cnt = pcie_config_read(pcie_core_id,duration);
				lprintf(5," %02d", recovery_cnt);
				if (recovery_cnt == 99) { 
					// going back to default config

					// Default parameters: CTLE=0x10, PQ_REG=0x11, DEF=0x7, PRESET=0x2; //Mask with 0x1C to get 4:2 AC Gain (Boost) variable and DC Gain (1:0)=0x0 - Default for BB3 Socket and BB2C 

					data = pcie_csr_read(pcie_core_id,SM_PCIE_CSR_REGS_BUSCTLREG__ADDR);
					data|=0x20000; 
					pcie_csr_write(pcie_core_id,SM_PCIE_CSR_REGS_BUSCTLREG__ADDR,data);
					lprintf(5," BUSCTRL__REG := 0x%x \n\r",pcie_csr_read(pcie_core_id,SM_PCIE_CSR_REGS_BUSCTLREG__ADDR));
					//lprintf(5,"Finished inbound registers configuration\n\r");

					pcie_serdes_tuning(pcie_core_id,(0x10<<2),0x11,0x7,0x2);
				}
			} // PQ_REG Change
			lprintf(5,"\n");
		} // CTLE Change 
	} // Preset = Change 

#if 0
	lprintf(3,"********************************************************************\n");
	lprintf(3,"**** :--    RESULT   :-- *  \n");
	lprintf(3,"********************************************************************\n");
	lprintf(3,"** PRESET = 0x%x : ", serdes.PRESET);
	lprintf(3,"CTLE = 0x%x : ", (serdes.CTLE <<2));
	lprintf(3,"PQ_REG = 0x%x : ", serdes.PQ_REG);
	lprintf(3,"DFE = 0x%x : ", serdes.DFE);
	lprintf(3,"Runtime = %d Minutes : ",duration);
	lprintf(3,"RxErr = %d  **\n", recovery_cnt);
	lprintf(3,"********************************************************************\n");
#endif

} //pcie_margin

void pcie_cfg_dump (uint32_t pcie_core_id)
{
	/*
	   This Function will dump the Config Space of the PCIe Card connected on the Slot 
	   pcie_core_id = 0,1,2 (This is actually Slot on the board)

	 */    
	int i;
	uint32_t addr, next_ptr, data, cap_id, cap_ver, gen, width, status, link_width, link_speed, expected_width;

	data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_31_0__ADDR);
	link_width = (data & 0xfc000000) >> 26;
	link_speed = (data & 0x03000000)>>24 ;
	lprintf(3,"Current Link @ Gen%dx%d \n",(link_speed+1),link_width);

	sm_pcie_setup_ob_cfg(pcie_core_id, RC);             
	sm_pcie_setup_ob_space(pcie_core_id, RC);  

	// PCI Common Configuration Space Header
	lprintf(5,"PCI Common Configuration Space Header: \n");
	addr = 0;
	for (i=0;i<0x40;i+=4) {
		data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR | addr + i);
		if (i==0x34) next_ptr = data;
		lprintf(5,"0x%02x : %02x %02x %02x %02x\n", addr+i, (data>>24)&0xff, (data>>16)&0xff, (data>>8)&0xff, data&0xff); 
	}

	// PCI Express Capabilities 
	lprintf(5,"PCI Express Capabilities Registers: \n");
	addr = next_ptr;
	for (i=0;i<0x40;i+=4) {
		data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR | addr + i);
		if (i==0) next_ptr = (data >> 8) & 0xff;
		lprintf(5,"0x%02x : %02x %02x %02x %02x\n", next_ptr+i, (data>>24)&0xff, (data>>16)&0xff, (data>>8)&0xff, data&0xff); 
	}

	// PCI Express Extended Capabilities 
	lprintf(5,"PCI Express Capabilities Registers\n");
	addr = 0x100;
	do {
		data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR | addr);
		next_ptr = (data >> 20) & 0xffff;
		cap_ver = (data>>16) & 0xf;
		cap_id = data & 0xffff;
		if (cap_id == 1) aer_base_addr = addr;
		if (cap_id == 25) sec_cap_addr = addr;
		lprintf(5,"%s: \n", pcie_ext_cap_id[cap_id]);
		lprintf(5,"0x%02x : %02x %02x %02x %02x\n", addr, (data>>24)&0xff, (data>>16)&0xff, (data>>8)&0xff, data&0xff); 

		for (i=4;i<pcie_ext_cap_size[cap_id];i+=4) {
			data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR | addr + i);
			lprintf(5,"0x%02x : %02x %02x %02x %02x\n", addr+i, (data>>24)&0xff, (data>>16)&0xff, (data>>8)&0xff, data&0xff); 
		}

		addr = next_ptr;
	} while (next_ptr != 0);
}

int pcie_config_dump (int argc, char *argv[])
{ 
	/*
	   This Function will dump the Config Space of the PCIe Card connected on the Slot 
	   pcie_core_id = 0,1,2 (This is actually Slot on the board)
	 */
	int i;
	uint32_t pcie_core_id;
	uint32_t addr, next_ptr, data, cap_id, cap_ver, gen, width, status, link_width, link_speed, expected_width;

	if (argc != 1) {
		lprintf(5,"not enough argument portid \n\r");
		return -1;
	} else {
		pcie_core_id = atoi(argv[0]);
	}
	pcie_cfg_dump (pcie_core_id);

	return 0;
}



int wait_min(uint64_t usec_duration, uint64_t start_time)
{
   volatile uint64_t time_us =0,etime=0,total,delta;
   static uint64_t sec=0,mssec=0,min=0, count = 0;
  

	 delta = usec_duration*(GC_FREQ/1000LU)*TICK_IN_MIN;
	 delta = delta >> 10;
	 delta = delta + ((delta * 3) >> 7) + ((delta * 9) >> 14);
	 total = delta + start_time;
	 
	 SYNC();
	  __asm__ volatile ("mrs %0, cntpct_el0": "=r"(etime));
	  if(etime >= total)
	  {
		 return(DONE);
         		 
	  }
	  else{
	    return(WAIT);
	  }
}	
 
void print_link(uint32_t pcie_core_id) {
uint32_t link_width,link_speed,data;
 data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_31_0__ADDR);
	   link_width = (data & 0xfc000000) >> 26;
	   link_speed = (data & 0x03000000)>>24 ;
 
lprintf(3,"Link Status : Gen%dx%d \n",(link_speed+1),link_width);
}

