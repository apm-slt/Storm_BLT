

#include "margin.h"


// In Phase-0 DS communicates tx_preset and rx_hint to US port

typedef struct {
   uint32_t tx_preset;
   uint32_t rx_hint;
} ctrl_phase0 ;

// In phase-1 link operational and fine tune Tx and Rx
// this phase, DS port communicates TX preset,LS-FS and Post Coeff value to US port 
typedef struct {
   uint32_t tx_preset;
   uint32_t fsv;
   uint32_t lsv;
   uint32_t post_coeff;
} ctrl_phase1;

typedef struct {
   
   uint32_t tx_preset;
   uint32_t eq_coeff[3];
   uint32_t pre_coeff_ctrl;

} ctrl_phase2;

typedef struct {

   uint32_t tx_preset;
   uint32_t eq_coeff[3];
   uint32_t pre_coeff_ctrl;
} ctrl_phase3;

typedef struct {
   uint32_t tx_amp;
} ctrl_tx;

typedef struct {
  uint32_t PRESET;  
  uint32_t PQ_REG;
  uint32_t CTLE;
  uint32_t DFE; 
} ctrl_rx;

typedef struct {
  ctrl_phase2 p2;
  ctrl_phase3 p3;
} eq_ctrl;

uint32_t tune_tx(uint32_t tx);
uint32_t tune_rx(uint32_t rx);
uint32_t fine_tune_bca(uint32_t phase);

extern int pcie_serdes_tuning(uint32_t pcie_core_id, uint32_t CTLE,uint32_t PQ_REG,uint32_t DFE, uint32_t PRESET);
extern int wait_min(uint64_t usec_duration, uint64_t start_time);
	
ctrl_rx serdes;
get_margin_t get_margin[3]= {
                               tune_tx,       // tune TX  
                               tune_rx,       // tune RX  
                               fine_tune_bca  // BCA param tuning  
                             };


uint32_t tune_tx(uint32_t tx)
{
  printf(" NOT-SUPPORTED YET \n\r") ;
}


uint32_t tune_rx(uint32_t rx)
{

	uint32_t pcie_core_id=rx,res=0,rc_id=0,stime,ms=0;
	uint32_t recovery_cnt=0,duration=2,data=0,link_width,link_speed;
    uint32_t Xlimit,Ylimit,st_value=0,Yst_value=0;
	
	data = pcie_csr_read(pcie_core_id,SM_PCIE_CSR_REGS_BUSCTLREG__ADDR);
	data|=0x28080; 
	pcie_csr_write(pcie_core_id,SM_PCIE_CSR_REGS_BUSCTLREG__ADDR,data);
//	printf( " BUSCTRL__REG := 0x%x \n\r",pcie_csr_read(pcie_core_id,SM_PCIE_CSR_REGS_BUSCTLREG__ADDR));

	printf("\n");
	printf("\n");
	print_rx_data(pcie_core_id);
	printf("X-Axis %s Range : %d to %d V/S Y-Axis %s Range : %d to %d \n",
	        Rx_serdes_param[X_AXIS],Ch_RxTxParam[X_AXIS][1],Ch_RxTxParam[X_AXIS][2],
	        Rx_serdes_param[Y_AXIS],Ch_RxTxParam[Y_AXIS][1],Ch_RxTxParam[Y_AXIS][2]);
    
    printf("\n");
	printf("\n");
	Xlimit= Ch_RxTxParam[X_AXIS][2];
	Ylimit= Ch_RxTxParam[Y_AXIS][2];
	
	// Print X-Axis here
	printf("%s   ",Rx_serdes_param[X_AXIS]);
    for ( st_value=Ch_RxTxParam[X_AXIS][1]; st_value <= Xlimit; st_value++) printf(" %02d ", st_value);
	printf("\n");
	for ( Yst_value=Ch_RxTxParam[Y_AXIS][1]; Yst_value <= Ylimit; Yst_value++)
	{
	// Y- Axis	
		printf("%s = %02d:",Rx_serdes_param[Y_AXIS],Yst_value);   
		for ( st_value=Ch_RxTxParam[X_AXIS][1]; st_value <= Xlimit; ++st_value)
		{
		   pcie_reset_mellanox(pcie_core_id); 
		   sm_tune_pcie(pcie_core_id,1, 0,2, 1, 8, 0);                    // to be changed	 
           MSDELAY(2000);
	       recovery_cnt = pcie_config_read(pcie_core_id,duration);	
		   lprintf(5," %02d", recovery_cnt);
		   if(recovery_cnt == 99) 
		   {
			 res=sm_pcie_poll_linkup(rc_id,2,8, 0); 	
			 if((res==0) || (res==2)){
						// printf("Link lost Now Margining Stopped \n\r ");	 
                        // pcie_serdes_tuning(pcie_core_id,(0x10<<2),0x11,0x7,0x2);     
			 printf("NL");
	   
		      }
		     else printf(" %02d" , recovery_cnt);	

		   }
		   else{
  				  printf(" %02d" , recovery_cnt);	
				}	
			
		 }
	   	 printf("\n");	
	  } // PQ_REG Change		   
	} // CTLE Change 
	
uint32_t fine_tune_bca(uint32_t phase)
{

  printf("BCA NOT-SUPPORTED-YET \n\r ");
}



