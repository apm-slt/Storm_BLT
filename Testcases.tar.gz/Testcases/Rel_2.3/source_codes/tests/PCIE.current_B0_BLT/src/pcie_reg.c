/*
 * Copyright (c) 2013 AppliedMicro.  All rights reserved.
 *
 * program brief: pcireg.c: pcie register access for Storm 
 * history: v0.1 2013.1 jodai@apm.com
 */

#include <stdio.h>
#include "sm_addr_map.h"
#include "pcie_x8_regs_addrmap.h"
#include "pcie_base.h"

//Tinh-SLT
#define read read_pcie
#define write write_pcie
//End of Tinh-SLT

#define uint32_t unsigned int
#define uint64_t unsigned long long
//#define SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_IND_CMD_REG__ADDR 0xa014

#define SHOWRW  1
#define REALRW	2
#define PARAMS  4
#if defined(CONFIG_VHP) | defined(CONFIG_BB1) | defined(CONFIG_BB2)
#define DEBUG 	(REALRW | PARAMS)
#else
#define DEBUG 	(SHOWRW | PARAMS)
#endif

uint32_t err=0,iport,r_w,count=8,data[128];
uint32_t offset;
//char * rws[]={"r","w","rphy","wphy", "rcfg", "wcfg"};
uint32_t csr_base_addr[5]={(SM_ADDR_MAP_PCIE0_CSR_BASE), \
                          (SM_ADDR_MAP_PCIE1_CSR_BASE), \
                          (SM_ADDR_MAP_PCIE2_CSR_BASE), \
                          (SM_ADDR_MAP_PCIE3_CSR_BASE), \
                          (SM_ADDR_MAP_PCIE4_CSR_BASE)};
uint32_t sds_ind_reg3[]={SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_IND_RDATA_REG__ADDR, \
			 SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_IND_WDATA_REG__ADDR, \
			 SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_IND_CMD_REG__ADDR};

//#if 0
//uint32_t read(uint64_t address) {
//  uint32_t data = 0;
//
//  data = *((volatile unsigned long long *) address);
//#else
uint32_t read(uint32_t address) {
  uint32_t data = 0;

  data = *((volatile unsigned int *) address);
//#endif
#if DEBUG & SHOWRW
  printf("  read(0x%x)=>0x%x\n", address, data);
#endif
  return data;
}

//#if 0
//void write(uint64_t address, unsigned int data) {
//  *((volatile unsigned long long *) address) = data;
//#else
void write(uint32_t address, unsigned int data) { 
  *((volatile unsigned int *) address) = data;
//#endif
#if DEBUG & SHOWRW
  printf("  write(0x%x)<=0x%x\n", address, data);
#endif
}

uint32_t read_csr(int iport, uint32_t offset){
  return read((csr_base_addr[iport] + offset));
}

void write_csr(int iport, uint32_t offset, uint32_t data){
  write((csr_base_addr[iport] + offset), data);
}

//indirect read 
uint32_t read_phy(int iport, uint32_t offset){
  int loopdly = 10;
  uint32_t cmdw = 0x0E | (offset<<4);	//clear err|done, read
  uint32_t cmdr = 0;

#if DEBUG & SHOWRW
  printf("read_phy(iport=%d,base=0x%x,offs=0x%x)\n", iport,csr_base_addr[iport],offset);
#endif
  write_csr(iport,sds_ind_reg3[2],cmdw);  //IND_CMD
  do
    cmdr = (uint32_t)read_csr(iport,sds_ind_reg3[2]);
  while ((cmdr & 4 != 4)&&(loopdly-- >0));
  if ((cmdr & 8)||(loopdly<=0)) {
    printf("read_phy(0x%x) error at retry %d!\n", offset, 10-loopdly);
    err++;
  }
  return read_csr(iport,sds_ind_reg3[0]); //IND_RDATA
}

//indirect write
void write_phy(int iport, uint32_t offset, uint32_t data){
  int loopdly = 10;
  uint32_t cmdw = 0x0D | (offset<<4);     //clear err|done, write
  uint32_t cmdr = 0;

#if DEBUG & SHOWRW
  printf("write_phy(iport=%d,base=0x%x,offs=0x%x,data=0x%x)\n", iport,csr_base_addr[iport],offset,data);
#endif
  write_csr(iport,sds_ind_reg3[1],data);  //IND_WDATA
  write_csr(iport,sds_ind_reg3[2],cmdw);  //IND_CMD
  do
    cmdr = (uint32_t)read_csr(iport,sds_ind_reg3[2]);
  while ((cmdr & 4 != 4)&&(loopdly-- >0));
  if ((cmdr & 8)||(loopdly<=0)) {
    printf("write_phy(0x%x,0x%x) error at retry %d!\n", offset, data, 10-loopdly);
    err++;
  }
}

void usage_pcie(void)
{
  printf("Usage_pcie: ip# offset cmd [w_data]|[r_count]\n");
  printf("       ip=0~4 for x8x4,x4,x1,x8x4,x4; cmd=r|w|rphy|wphy)\n");
}

void param(void)
{
  int i = 0;

  printf("pcireg: iport=%2d, offs=0x%x, cmd=%d, count=%d", iport,offset,r_w,count);
  if (r_w & 1) {
    printf(", data=");
    while (i<count) {
      printf("0x%08x ", data[i++]);
      if (((i & 0x7)==0)||(i>=count)) printf("\n");
    }
  } else
    printf("\n");
}

#if defined(CONFIG_VHP) | defined(CONFIG_BB1) | defined(CONFIG_BB2) //Storm test
int pcireg(int argc, char *argv[])
{
  int i, j;
  uint32_t cfgl,cfgh,cfgctl;
#if 0
  for (i=0;i<argc;i++)
    printf("%s ", argv[i]);
  i=argc+1;
  printf(", argc=%d, i=%d, j=%d\n", argc,i,j);
#endif
  i = argc+1; j= 0; err = 0;
#else
int main(int argc, char *argv[])
{
  int i=argc, j=1;
  uint32_t cfgl,cfgh;
#endif

  if (i<4) err=1;
  else {
    iport = atoi(argv[j]);
    if (iport>4) err=2;
    if (strncmp(argv[j+1],"0x",2)!=0) 
      offset = strtol(argv[j+1], NULL, 16);
    else
      offset = strtol(argv[j+1], NULL, 0);
//    if (offset & 3)
//      printf("pcireg warning: 32bit reg offset must be multiple of 4\n");
    if (strncmp(argv[j+2],"rphy",4)==0) r_w=2;
    else if (strncmp(argv[j+2],"wphy",4)==0) r_w=3;
    else if (strncmp(argv[j+2],"rcfg",4)==0) r_w=4;
    else if (strncmp(argv[j+2],"wcfg",4)==0) r_w=5;
    else if (strcmp(argv[j+2],"r")==0) r_w=0;
    else if (strcmp(argv[j+2],"w")==0) r_w=1;
    else err=3;

    if (r_w & 4) {
      write_csr(iport, SM_PCIE_CSR_REGS_CFGCTL__ADDR, 1);  
      cfgl = read_csr(iport, SM_PCIE_CSR_REGS_CFGBARL__ADDR);
      cfgh = read_csr(iport, SM_PCIE_CSR_REGS_CFGBARH__ADDR);
#if DEBUG & PARAMS
      printf("CFGBARL=0x%x, CFGBARH=0x%x, write CFGCZTL<=1\n", cfgl, cfgh);
#endif
    } 
    if (r_w & 1) {	//write
      count = i - 4; i = 0;
      if ((count==0)||(count>128)) err = 4;
      while ((!err)&&(i<count)) {
        if (strncmp(argv[3+j+i],"0x",2)!=0) 
          data[i] = (uint32_t)strtol(argv[3+j+i], NULL, 16);
        else
          data[i] = (uint32_t)strtol(argv[3+j+i], NULL, 0);
        i++;
      };
    } else if (i>4)
      count=atoi(argv[3+j]);
  }  
  if (err) {
    printf("pcireg argument error = %d\n", err);
    param();
    usage_pcie();
    return err;
  } 
#if DEBUG | PARAMS
  else param();
#endif
 
  i = j = 0;
  if (r_w & 1) {	//write
    do {
      if (r_w & 2) {	//phy
        write_phy(iport, offset, data[i]);
      } else if (r_w & 4) {	//cfg
#if DEBUG & SHOWRW
        printf("write_cfg(iport=%d,base=0x%x,offs=0x%x,data=0x%x)\n", iport,cfgl,(offset+i),data[i]);
#endif
        write(cfgl+offset+i, data[i]);
      } else {
#if DEBUG & SHOWRW
        printf("write_csr(iport=%d,base=0x%x,offs=0x%x,data=0x%x)\n", iport,csr_base_addr[iport],(offset+i),data[i]);
#endif
        write_csr(iport, (offset+i), data[i]);
      }
      i += 2;
    } while (i<count);
  } else {
    do {
      if (r_w & 2) {
        data[i] = read_phy(iport, (offset+i));
      } else if (r_w & 4) {
#if DEBUG & SHOWRW
        printf("read_cfg(iport=%d,base=0x%x,offs=0x%x)\n", iport,cfgl,(offset+i));
#endif
        data[i] = read(cfgl+offset+i);
      } else {
#if DEBUG & SHOWRW
        printf("read_csr(iport=%d,base=0x%x,offs=0x%x)\n", iport,csr_base_addr[iport],(offset+i));
#endif
        data[i] = read_csr(iport, (offset+i));
      }
      printf("0x%08x ", data[j++]);
      if (((j & 0x7)==0)||(j>=count)) printf("\n");
      i += 2;
    } while (i<count);
  }  
 
  return 0;
}
