/*
 * Copyright (c) 2009 Xilinx, Inc.  All rights reserved.
 *
 * Xilinx, Inc.
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS" AS A
 * COURTESY TO YOU.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION AS
 * ONE POSSIBLE   IMPLEMENTATION OF THIS FEATURE, APPLICATION OR
 * STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS IMPLEMENTATION
 * IS FREE FROM ANY CLAIMS OF INFRINGEMENT, AND YOU ARE RESPONSIBLE
 * FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE FOR YOUR IMPLEMENTATION.
 * XILINX EXPRESSLY DISCLAIMS ANY WARRANTY WHATSOEVER WITH RESPECT TO
 * THE ADEQUACY OF THE IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO
 * ANY WARRANTIES OR REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE
 * FROM CLAIMS OF INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

/*
 * helloworld.c: simple test application
 */
#include <types.h>
#include <stdio.h>
#include <common.h>
#include "pcie_main.h"
#include "pcie_test_package.h"
//#define PRINT(format, args...) print(format, args)

//Tinh-SLT
#define putnum putnum_pcie
//End of Tinh-SLT

#if defined(CONFIG_VHP) || defined(CONFIG_BB1) || defined(CONFIG_BB2)
int pcitst(int argc, char *argv[])
{
    uint32_t port_type;    // 0 => EP mode, 1 => RC mode.
    uint32_t en_lpbk = 0;       // 1 => self crosslink mode is enabled.
    uint32_t gen;           // 0 => gen1, 1 => gen2, 2 => gen3.
    uint32_t pcie_core_id;
    uint32_t ext_ref;
    uint32_t link_width;
    int i;
    uint32_t test_name = 1;
    uint32_t test_pattern = 1;
    uint32_t length = 16;
    uint32_t extended_addr = 0;
    uint32_t max_payload_size;
    uint32_t poll = 0;

    if (argc<7) {
       printf("Usage: pcitst ep_rc=0/1 phy_lpbk=0/1 gen=0~2 core_id=0~4 ext_ref=1 link_width<=8 test_name=\n");
       printf("       0/1=IB/OB, 2-3=sDMA AXI-PCIe/PCIe-AXI, 4-6=mDMA AXI-PCIe/PCIe-AXI/Interleaved\n");
       printf("       8-9=EP sDMA AXI-PCIe/PCIe-AXI, 10-12=EP mDMA AXI-PCIe/PCIe-AXI/Interleaved\n");
       printf("       13-14=L1/L2 pwr ctrl\n");
       return 1;
    }
    port_type = atoi(argv[0]);  
    en_lpbk = atoi(argv[1]);
    gen = atoi(argv[2]);
    pcie_core_id = atoi(argv[3]);
    ext_ref = atoi(argv[4]);
    link_width = atoi(argv[5]);
    if (test_name >0)
        length = 256;
    if ((port_type>1)||(gen>2)||(pcie_core_id>4)||(ext_ref>2)||((link_width!=1)&&(link_width!=2)&&(link_width!=4)&&(link_width!=8))) {
       printf("Usage: pcitst ep_rc int_lpbk gen core_id ext_ref link_width test_name\n");
       return 2;
    }
    
#ifndef SM_SOC_SIM   
    init_platform();
    ocm_init();
#endif    

    max_payload_size = (pcie_core_id == 2) ? 256 : 512;
    sm_pcie_init(pcie_core_id, port_type, en_lpbk, gen, ext_ref, link_width, poll);

    printf("PCIe init'd: core=%1d, %2s, int_lpbk=%1d, gen%1d, clk=%3s, x%1d, testing now.\n\r",
           pcie_core_id, (port_type?"rc":"ep"), en_lpbk, gen+1, (ext_ref?"int":"ext"), link_width);
    if (port_type) {
        sm_pcie_test_rc(pcie_core_id, test_name, test_pattern, length, extended_addr);
    } else {
        sm_pcie_test_ep(pcie_core_id);
    }

    printf("*****************************************\n\r");
    printf("************** Test Complete ************\n\r");
    printf("*****************************************\n\r");

#ifndef SM_SOC_SIM
    cleanup_platform();
#endif    

    return 0;
}
#endif

#ifndef VBIOS
int get_val(){
  int i = 0;
  char s[100];
  int j,val;
  do
    {
      s[i++] = inbyte();
    } while ((s[i-1] != '\n') && (s[i-1] != '\r'));
  // end first do.. command input
  s[i] = '\0';
         
  val = 0x00000000;
  for (j=0; j<(i-1); j++) {
      if (s[j] > 0x40)
        {val = (val<<4) + s[j] - 0x57;}
      else
        {val = (val<<4) + s[j] - 0x30;}
  }
  return val;
}

int main()
{
    uint32_t port_type;     // 0 => EP mode, 1 => RC mode.
    uint32_t en_lpbk;       // 1 => self crosslink mode is enabled.
    uint32_t gen;           // 0 => gen1, 1 => gen2, 2 => gen3.
    uint32_t test_mode;     // 0 => DMA, 1 => OB/INTx/MSI testing, 2 => NWL DMA driver.
    uint32_t pcie_core_id;
    uint32_t ext_ref = 0;
    uint32_t link_width = 1;
    uint32_t poll = 0;
    
    init_platform();
    ocm_init();
    pcie_core_id = 2;
    
    print("Storm SOC FPGA: \n\r\n\r");

    print("Testing for PCIE: \n\r\n\r");
    print("Choose the port type for PCIE (0 - EP; 1 - RC): ");
    port_type = get_val();
    print("\n\r");
    if(port_type) {
      print("Enter the linkup mode for RC (0 - normal mode; 1 - self crosslink mode): ");
      en_lpbk = get_val();
      print("\n\r");
    }
    else
      en_lpbk = 0;

    print("Enter the PCIE gen, which you want to test (0 - gen1, 1 - gen2, 2 - gen3):");
    gen = get_val();
    print("\n\r");

    sm_pcie_init(pcie_core_id, port_type, en_lpbk, gen, ext_ref, link_width, poll);

    print("Linkup achieved in gen"); putnum(gen+1); print(" for "); 
    if(port_type)
      print("RC");
    else
      print("EP");

    print(" DUT in ");
    if(en_lpbk)
      print("self crosslink");
    else
      print("normal");

    print(" mode. Now, will do some testing.\n\r");

    if(port_type) {
      uint32_t test_name = 1;
      uint32_t test_pattern = 0;
      uint32_t length = 16;
      uint32_t extended_addr = 0;
      sm_pcie_test_rc(pcie_core_id, test_name, test_pattern, length, extended_addr);
    }
    else {
      print("The test mode for EP DUT, will be conveyed by external RC\n\r");
      sm_pcie_test_ep(pcie_core_id);
    }

    print("*****************************************\n\r");
    print("************** Test Complete ************\n\r");
    print("*****************************************\n\r");
    
    cleanup_platform();

    return 0;
}
#else
int pcie_main() {
#if 0
    uint32_t port_type = 0; // 0 => EP mode, 1 => RC mode.
    uint32_t en_lpbk = 0;   // 1 => self crosslink mode is enabled.
    uint32_t gen = 0;       // 0 => gen1, 1 => gen2, 2 => gen3.
    uint32_t test_mode;     // 0 => DMA, 1 => OB/INTx/MSI testing, 2 => NWL DMA driver.
    uint32_t pcie_core_id;
    uint32_t ext_ref = 0;
    uint32_t link_width = 1;
    uint32_t poll = 0;
    
//    init_platform();
//    ocm_init();
    pcie_core_id = 2;
    
    print("Storm SOC FPGA: \n\r\n\r");

    print("Testing for PCIE: \n\r\n\r");
    sm_pcie_init(pcie_core_id, port_type, en_lpbk, gen, ext_ref, link_width, poll);

    print("Linkup achieved in gen"); putnum(gen+1); print(" for EP DUT in normal mode. Now, will do some testing.\n\r"); 
    print("The test mode for EP DUT, will be conveyed by external RC\n\r");
    sm_pcie_test_ep(pcie_core_id, 0);

    pcie_test_package();    //load all the test for VBIOS
    print("**************************\n\r");
    print("** pcie_main() complete **\n\r");
    print("**************************\n\r");
    
//    cleanup_platform();
#endif
    return 0;
}  


#endif
