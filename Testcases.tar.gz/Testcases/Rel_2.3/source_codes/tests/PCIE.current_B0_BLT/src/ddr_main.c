#include <stdio.h>
#include "platform.h"
#include "common.h"
#include "ddr_main.h"
void ddr_main()
{
    unsigned int i, *ptr;
    
    printf("Sushant- This print is due to code executed from 'DDR main' space\n");
    printf("Done!\n");
}

