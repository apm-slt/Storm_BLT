/*
 * AppliedMicro
 * Storm-PreSi
 *
 * Filename: vbios.c
 * Comments: vbios-cmain
 *
 */
#include "common.h"
#include "xmodem_utils.h"
#include "vlib.h"

#include "pcie_main.h"
 
//#define BEFORE_PROMPT

void cmain(void) {

#ifdef BEFORE_PROMPT
    test_xmodem();
#endif

    vbios_msg_header();
    prompt();

//// dummy calls for avoiding gcc optimization
    pcie_main();
}

