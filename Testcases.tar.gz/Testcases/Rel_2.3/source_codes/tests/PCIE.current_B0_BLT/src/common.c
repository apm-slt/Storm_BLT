/*
 * AppliedMicro
 * Storm-PreSi
 *
 * Filename: common.c
 * Comments: vbios common functions
 *
 */
 
 //Tinh-SLT
#define putnum putnum_pcie
#define read read_pcie
#define write write_pcie
//End of Tinh-SLT

unsigned int read(unsigned int *address){
  int *addr_int;
  addr_int = address;
	int rdata = *addr_int;
	print("Read32  @ 0x:"); putnum(addr_int); print(" is 0x");  putnum(rdata);  print("\n\r");
	return(rdata);
}

void write(unsigned int *address, int data){
  int *addr_int;
  addr_int = address;
	*addr_int = data;
	print("Write32 @ 0x:"); putnum(address); print(" is 0x");  putnum(data);  print("\n\r");
}

