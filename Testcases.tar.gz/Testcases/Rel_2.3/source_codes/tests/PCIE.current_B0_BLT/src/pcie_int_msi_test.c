#include "pcie_ib_test.h"
#include "pcie_ob_test.h"
#include "pcie_int_msi_test.h"

//Tinh-SLT:
#define putnum putnum_pcie
//End of Tinh-SLT

void disable_msi_support(uint32_t pcie_core_id){
  uint32_t data;
  
  lprintf(5,"Specifically disabling the MSI-x & MSI capability\n\r");
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_447_416__ADDR));
  data = data | FIELD_EXPRESSO_CFG_CONTROL_CFG_CONTROL_447_416_CFG_CONTROL_MSI_CAPABILITY_DISABLE_MASK;
  data = data | FIELD_EXPRESSO_CFG_CONTROL_CFG_CONTROL_447_416_CFG_CONTROL_MSI_X_CAPABILITY_DISABLE_MASK;
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_447_416__ADDR), data);
};

void outbound_intx_msg(uint32_t pcie_core_id, uint32_t msg) {
  uint32_t msg_routing_code = 4;
  uint32_t msg_code;
  uint32_t msg_data = 0;

#if 0                          // When INTx to be used dont enable this unless you have
                               // seperate process to send Deassert  
  disable_msi_support(pcie_core_id);
  gen_int(pcie_core_id);

#else
  if(msg == 0) {
    lprintf(5,"Sending ASSERT_INTA message, marking the SUCCESS of the TEST\n\r");
    msg_code = 0x20; 
  }
  else {
    lprintf(5,"Sending ASSERT_INTB message, marking the FAILURE of the TEST\n\r");
    msg_code = 0x21; 
  }

  send_ob_msg(pcie_core_id, msg_code, msg_routing_code, msg_data);
//  send_ob_msg(pcie_core_id, msg_code | 2, msg_routing_code, msg_data);  //add INTC/D msg
#endif

};  

uint32_t poll_int_ack(uint32_t pcie_core_id) {
  uint32_t data;
  uint64_t addr;
  uint64_t PCIE_PIM2;

  PCIE_PIM2= ret_pim2_base(pcie_core_id);

  data = 0;
  while(data == 0) {
    lprintf(5,"Polling for the ack from RC device that it received the MSI (converted to legacy interrupt).\n\r");
    addr = PCIE_PIM2 | 0x10;
    data = cpu_read(addr);
  }

  return data;
};

void gen_int(uint32_t pcie_core_id){
  uint32_t data;
  uint64_t addr;
  uint64_t PCIE_PIM2;

  PCIE_PIM2= ret_pim2_base(pcie_core_id);

#ifdef SM_SOC_SIM
  // 0 -INTx, 1-MSI
  // INTXMSICFG0 (INTx/MSI Configuration Registers (where p=PCIe port (0 to 4)))
  addr = 0x79e00000 + (pcie_core_id << 16);
  data = 0;
  cpu_write(addr, data);//0 -INTx,

  //INTXMSIIM2 - All interrupt sources enabled(0)/masked(f)
  addr = 0x79e00004 + (pcie_core_id << 16);
  cpu_write(addr, data);

  //INTXSR2 - Reading Interrupt status
  addr = 0x79f00000 + (pcie_core_id << 16);
  data = cpu_read(addr);

  //MSG2SET0[0] = 1 to signal message interrupt pending
  addr = 0x7A000000 + (pcie_core_id << 20);
  data = 1;
  cpu_write(addr, data);

#else  
  data = cpu_read(0x17040018);

  data = data | 0x40;

  cpu_write(0x17040018, data);

  data = cpu_read(0x17040018);
#endif
  lprintf(5,"Generated legacy ASSERT_INTA interrupt\n\r");

  data = poll_int_ack(pcie_core_id);
  lprintf(5,"Received data = "); putnum(data); lprintf(5,". RC received INTA interrupt.\n\r");

  lprintf(5,"Clearing the flag in memory\n\r");
  addr = PCIE_PIM2 | 0x10;
  cpu_write(addr, 0);

#ifdef SM_SOC_SIM
  //MSG2CLR0[0] = 1 to clear message interrupt
  addr = 0x7A800000 + (pcie_core_id << 20);
  data = 1;
  cpu_write(addr, data);
#else  
  data = cpu_read(0x17040018);

  data = data & ~0x40;

  cpu_write(0x17040018, data);

  data = cpu_read(0x17040018);
#endif

  lprintf(5,"Generated legacy DEASSERT_INTA interrupt\n\r");



};

void gen_msi(uint32_t pcie_core_id){
  uint32_t data,temp1,temp2,i;
  uint64_t addr;
  uint64_t PCIE_PIM2;

  PCIE_PIM2= ret_pim2_base(pcie_core_id);

  lprintf(5,"Generating MSI\n\r");

  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_447_416__ADDR));
  lprintf(5,"MSI IN CFG_CTROL_447_416 : " );putnum(data);lprintf(5,"\n\r");

  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_159_128__ADDR));
  lprintf(5," CFG_CONSTANTS_159_128 : " );putnum(data);lprintf(5,"\n\r");

#ifdef SM_SOC_SIM  

  // 0 -INTx, 1-MSI
  addr = 0x79e00000 + (pcie_core_id << 16);
  data = 1;
  cpu_write(addr, data);//0 -INTx,
  data=cpu_read(addr);
  lprintf(5,"INTXMSICFG0"); putnum(data);lprintf(5,"\n\r");

  //INTXMSIIM - All interrupt sources enabled(0)/masked(f)
  addr = 0x79e00004 + (pcie_core_id << 16);
  data = 0;
  cpu_write(addr, data);
  data=cpu_read(addr);
  lprintf(5,"INTXMSIIM0"); putnum(data);lprintf(5,"\n\r");


  //INTXSR0 - Reading Interrupt status
  addr = 0x79f00000 + (pcie_core_id << 16);
  data = cpu_read(addr);
  lprintf(5,"INTXSR0 "); putnum(data);lprintf(5,"\n\r");

  //MSG2SET0[0] = 1 to signal message interrupt pending
  addr = 0x7A000000 + (pcie_core_id << 20);
  data = 1;
  cpu_write(addr, data); 
  data=cpu_read(addr);
  lprintf(5,"MSG0SET0"); putnum(data);lprintf(5,"\n\r");

  // MSCLR0
  addr=0x7a800000 + (pcie_core_id << 20);
  data = 1;
  cpu_write(addr, data);
  data=cpu_read(addr);
  lprintf(5,"MSG0CLR1"); putnum(data);lprintf(5,"\n\r");

 
  // Vv: Enable this when to validate all MSI supported
  // According to value programmed in config space.
  // Code to test multiple messages starts here

for(i=0;i<=15;i++)
{
  temp1= ( 0x7a000000 | (i * 0x10000));
  temp2= ( 0x7A800000 | (i * 0x10000));

  addr = temp1 + (pcie_core_id << 20);
  data = 1;
  cpu_write(addr, data);
  data=cpu_read(addr);
  lprintf(5,"MSG0SET");putnum(temp1); putnum(data);lprintf(5,"\n\r");

  //MSG2CLR0[0] = 1 to clear message interrupt
  addr = temp2 + (pcie_core_id << 20);
  data = 1;
  cpu_write(addr, data);
  data=cpu_read(addr);
  lprintf(5,"MSG0CLR");putnum(temp2); putnum(data);lprintf(5,"\n\r");
}

#else  
  data = cpu_read(0x17040018);
  data = data | 0x21;

  cpu_write(0x17040018, data);

  data = cpu_read(0x17040018);
#endif

  lprintf(5,"Generated MSI\n\r");

  data = poll_int_ack(pcie_core_id);
  lprintf(5,"Received data = "); putnum(data); lprintf(5,". RC received the MSI (converted to legacy interrupt).\n\r");

  lprintf(5,"Clearing the flag in memory\n\r");
  
  addr = PCIE_PIM2 | 0x10;
  cpu_write(addr, 0);

  lprintf(5,"Writing to the clr_interrupt bit, as this is level triggered system\n\r");
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_PCIECORE_CTLANDSTATUS__ADDR);
  data = data | FIELD_PCIECORE_CTLANDSTATUS_CLR_S_INT_TX_EDGE_LEVEL_MASK;

  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PCIECORE_CTLANDSTATUS__ADDR, data);
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_PCIECORE_CTLANDSTATUS__ADDR);

  lprintf(5,"Done MSI generation testing\n\r");
};
