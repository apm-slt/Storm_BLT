#include <stdio.h> 
#include <stdlib.h> 
#include "sm_addr_map.h"
#include "sm_host_pkg.h"

//Tinh-SLT:
//function defined here
#define sm_host_read32 sm_host_read32_pcie
#define sm_host_write32 sm_host_write32_pcie
//End of Tinh-SLT

void sm_host_read32(uint64_t addr, unsigned int* data) {
  *data = *((volatile unsigned int *) addr);
}

void sm_host_write32(uint64_t addr, unsigned int data) { 
  *((volatile unsigned int *) addr) = data;
}

void sm_host_read16(uint64_t addr, unsigned short int* data) {
  *data = *((volatile unsigned short int *) addr);
}

void sm_host_write16(uint64_t addr, unsigned short int data) { 
  *((volatile unsigned short int *) addr) = data;
}

void sm_host_read8(uint64_t addr, unsigned char* data) {
  *data = *((volatile unsigned char *) addr);
}

void sm_host_write8(uint64_t addr, unsigned char data) { 
  *((volatile unsigned char *) addr) = data;
}

void sm_host_report_info(const char* message) {
#ifdef PRINT_C_MSGS
  printf("PPC_INFO::\n", message);
#endif
}

void sm_host_report_warning(const char* message) {
#ifdef PRINT_C_MSGS
   printf("PPC_WARNING::\n", message);
#endif   
}

void sm_host_report_error(const char* message) {
#ifdef PRINT_C_MSGS
  printf("PPC_ERROR::\n", message);
#endif   
}

void sm_host_report_fatal(const char* message) {
#ifdef PRINT_C_MSGS
  printf("PPC_FATAL::\n", message);
#endif   
}

void memory_barrier(void) { }

void sm_host_delay_ns(unsigned int duration) {
}

int sm_host_delay(unsigned int data) { }

void __cmp_value(unsigned int exp_value, unsigned int rcvd_value) {
  char str[200];
  if (exp_value != rcvd_value) { 
    sprintf(str, "value mismatch (exp = %0x rcvd = %0x)", exp_value, rcvd_value);
    sm_host_report_error(str);
  } 
}

//int sm_host_isr (void) {
//  host_isr();
//  return 0; // An 1 indicates the task is disabled
//}

void soc_disable_MDIO_powerdown () {
   uint32_t rdata32;                                               
   
   sm_host_read32(0x17001398, &rdata32); // Read MPA_MDIO_IOCTL (SLIMpro MDIO IO Control Register)
   sm_host_write32(0x17001398, rdata32 | 0x60000); 
}

void soc_setup_for_PMU_mon () {
   uint32_t rdata32;                                               
  
   //1.  Look at PMCEID0-1 to identify which event(s) you want to monitor.  
   //    Note that there are a clock cycle and one every 64 clock cycle events that can be used for reference.
   sm_host_read32(0x7e940e20, &rdata32);
   sm_host_read32(0x7e940e24, &rdata32);

   //2.  Configure PMEVTYPER0-3 for the selected events.  Note that latency events must use PMEVCNTR2-3.
   //    -> PMEVYPE*[5:0] = Table 1-3 of SoC PMU Arch
   sm_host_write32(0x7e940400, 0x03); // AXI read partial – lane 0
   sm_host_write32(0x7e940404, 0x05); // AXI Read partial – lane 1
   sm_host_write32(0x7e940408, 0x11); // AXI Write partial – Lane 0
   sm_host_write32(0x7e94040c, 0x14); // AXI Write partial – Lane 1
   
   //3.  Configure PMAMR0-1 for selecting which bus agents that you want to monitor.
   //-> Set 1 for bit appropreated with block (AXI agent) you want to measure.
   //This setting affect to all 4 counters
   sm_host_write32(0x7e940a00, 0x00);  
   sm_host_write32(0x7e940a04, 0x1ffffff);  // Open MASK for all blocks

   //4.  Configure PMCNTENSET/PMCNTENCLR to enable/disable the active counters.
   sm_host_write32(0x7e940c00, 0x0f);  

   //5.  Use PMCR to clear, arm, and trigger the counters.
   sm_host_write32(0x7e940e04, 0x01);  

   //6.  Check PMOVSR status at the end of test to make sure counter did not overflow   
   //sm_host_read32(0x7e940c80, &rdata32);
   //sm_host_read32(0x7e940000, &rdata32); // PMEVCNTR0
   //sm_host_read32(0x7e940004, &rdata32); // PMEVCNTR1
   //sm_host_read32(0x7e940008, &rdata32); // PMEVCNTR2
   //sm_host_read32(0x7e94000c, &rdata32); // PMEVCNTR3
 
}

void soc_enable_Ring () {
  
          // Token Ring Enable
          sm_host_write32(0x17001200, 0x00000000);
 
          // MPA
          sm_host_write32(0x1700f004, 0x00000000);
          // COP
 //         if(seq_cfg.power_down_cop_en == 0)  
             sm_host_write32(0x1f40f004, 0x00000000);
          
 /*        end  
         else begin
           sm_host_write32(0x1f40f004, 0x00000000);
           sm_host_write32(0x1700f004, 0x00000000);     
         end
*/
         // DMA
         sm_host_write32(0x1f27f004, 0x00000000);
         // SEC
         sm_host_write32(0x1f25f004, 0x00000000);

   //      if (seq_cfg.power_down_xge_en == 0) begin 
           // XGENET_0
           sm_host_write32(0x1f62f004, 0x00000000);
           // XGENET_1
           sm_host_write32(0x1f61f004, 0x00000000);
           // XGENET_2
           sm_host_write32(0x1f71f004, 0x00000000);
           // XGENET_3
           sm_host_write32(0x1f72f004, 0x00000000);
   //      end
       
         // CLE
         sm_host_write32(0x1f24f004, 0x00000000);
         // OCM
         // SATA01/ENET01
         sm_host_write32(0x1f21f004, 0x00000000);
         // SATA23
         sm_host_write32(0x1f22f004, 0x00000000);
         // SATA45
         sm_host_write32(0x1f23f004, 0x00000000);
         // ENET4
         sm_host_write32(0x1702f004, 0x00000000);
         // CTM
         sm_host_write32(0x1f26f004, 0x00000000);
         // QM1
         sm_host_write32(0x1f20f004, 0x00000000);

  //       if (seq_cfg.power_down_xge_en == 0) begin 
           // QM0
           sm_host_write32(0x1f60f004, 0x00000000);
           // QM2
           sm_host_write32(0x1f70f004, 0x00000000);  
 //        end

         // QMLITE
         sm_host_write32(0x1703f004, 0x00000000);
         // GFC
         sm_host_write32(0x1701f004, 0x00000000);
         // PCIE0;
         sm_host_write32(0x1f2bf004, 0x00000000);
         // PCIE1
         sm_host_write32(0x1f2cf004, 0x00000000);
         // PCIE2
         sm_host_write32(0x1f2df004, 0x00000000);

//         if (seq_cfg.power_down_pci_en == 0) begin
           // PCIE3
           sm_host_write32(0x1f50f004, 0x00000000);
           // PCIE4
           sm_host_write32(0x1f51f004, 0x00000000);
//         end

         // USB0
         sm_host_write32(0x1f28f004, 0x00000000);
         // USB1
         sm_host_write32(0x1f29f004, 0x00000000);
         // AHB
         sm_host_write32(0x1f2af004, 0x00000000); 
}

