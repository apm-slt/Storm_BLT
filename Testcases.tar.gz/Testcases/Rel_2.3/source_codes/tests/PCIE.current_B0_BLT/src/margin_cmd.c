/*
 * Copyright (c) 2014 AppliedMicro.  All rights reserved.
 * Author : Vaibhav Vaidya 
 * program brief: margin_cmd.c: User commands for margin tool
 * Lists out all command used in marginig.
 * history: v0.1 2014.11.8 <Supports only RX characteristics from RC mode>
 */
 
#include "margin.h"

 
uint32_t X_AXIS, Y_AXIS;
extern char *Rx_serdes_param[];

/*
Fcn description : This command takes four argument from user to run pcie margin tool, arguments are
1st: PCIE core id
2nd : Gen
3rd : Link width
4th argument is serdes characteristics argumnet
0: Transmitter tuning
1: Recevier tunning
2: BCA parameter tunning

Release v 0.1 supports only receiver parameter tunning.
Dependecy : Call config_rx_data
            call config_x_y			
*/ 
int opt_pcie(int argc, char *argv[])
{
	int i=argc, j=0,res=0,itr=0;
	uint32_t data, current_rate, gen_match,addr=0,coeff_cursr=0;
	uint32_t status = 0,success=0;
	uint32_t linkup;
	uint32_t printGEN[4] = {0,1,2};
	signed int cnt=1000;
	int error=0;
	uint32_t rc_slot,pcie_core_id,gen,link_width,link_speed;
	uint32_t ext_ref = 1,length=0x3fffffc,test_id=2,phase=1,itr_cnt =0,param=0,count=1 ;


	if (i<3)
		error=1;
	else
	{
		rc_slot = atoi(argv[j]);
		gen = atoi(argv[j+1]);
		link_width = atoi(argv[j+2]);
		param =atoi(argv[j+3]);
	}

	if (error) {
		printf("pcie_margin: argument error %1d-%d. Usage: rc_slot gen link_width param tx-rx\n", error, i);
		printf("usage:       pcie_core_id=0~2, gen=0-1-2, width, param : 0 - Tx 1 : - Rx and 2 : BCA \n");

		return error;
	}
 
       sm_pcie_init(rc_slot,1, 0, gen,1, link_width, 0);
       MSDELAY(1000);
       data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_31_0__ADDR);
       link_width = (data & 0xfc000000) >> 26;
       link_speed = (data & 0x03000000)>>24 ;
	   
       printf("Current Link @ Gen%dx%d \n",(link_speed+1),link_width);
       get_margin[param](rc_slot);  // Call function here
	          	
}

/*
Fcn description : This command takes constant argument which is not varying during tuninig
1st: PCIE core id
2nd : Gen
3rd : Link width
4th argument is serdes characteristics argumnet
0: Transmitter tuning
1: Recevier tunning
2: BCA parameter tunning

Release v 0.1 supports only receiver parameter tunning.
Dependecy : Call config_rx_data
            call config_x_y			
*/ 

int config_rx_data(int argc, char *argv[])
{

	int i=argc, j=0,res=0,itr=0;
	uint32_t data, current_rate, gen_match,addr=0,coeff_cursr=0;
	uint32_t status = 0,success=0;
	uint32_t linkup;
	uint32_t printGEN[4] = {0,1,2};
	signed int cnt=1000;
	int error=0;
	uint32_t rc_slot,pcie_core_id,gen,link_width,link_speed;
	uint32_t ext_ref = 1,length=0x3fffffc,test_id=2,phase=1,itr_cnt =0,param=0,count=1 ;


	if (i<MAX_SUPPRTED_RX_PARAM)
		error=1;
	else
	{
		rc_slot = atoi(argv[j]);
		
		Ch_RxTxParam[CTLE_AC_IDX][0]=atoi(argv[1]);
		Ch_RxTxParam[CTLE_DC_IDX][0]=atoi(argv[2]);
		Ch_RxTxParam[CTLE_EQ_FR_IDX][0] = atoi(argv[3]);
		Ch_RxTxParam[CTLE_EQ_QR_IDX][0] = atoi(argv[4]);
		Ch_RxTxParam[CTLE_EQ_HR_IDX][0]=atoi(argv[5]);
		Ch_RxTxParam[CTLE_EQ_IDX][0]=atoi(argv[6]);
		
		Ch_RxTxParam[DFE_IDX][0]=atoi(argv[7]);
		
		Ch_RxTxParam[PQ_SIGN_IDX][0]=atoi(argv[8]);
		Ch_RxTxParam[PQ_VALUE_IDX][0]=atoi(argv[9]);

		Ch_RxTxParam[PRESET_EP_IDX][0]=atoi(argv[10]);
		Ch_RxTxParam[MU_PHASE1_IDX][0]=atoi(argv[11]);
		Ch_RxTxParam[MU_PHASE2_IDX][0]=atoi(argv[12]);
		Ch_RxTxParam[MU_PHASE3_IDX][0]=atoi(argv[13]);
	}

	if (error) {
		printf("config_rx_data: argument error %1d-%d. Usage: rc_slot serdes receiver parameter \n", error, i);
		printf("parameters programmed to be constant Please refer configuration command doc. \n");

		return error;
	   }
 
}         	


/*
Fcn description : This command takes X-Axis and Y-Axis parameter and plot shmoo
1st: X-AXIS PARAM
2nd :Y-AXIS PARAM

Release v 0.1 supports only receiver parameter tunning.
Dependecy : Call config_rx_data
           		
*/ 

int config_x_y(int argc, char *argv[])
{

	int i=argc,error,j=0;
	
	if (i<2)
	{
		error=1;
		printf("config_x_y: argument error %1d-%d. Usage: X & Y-Axis Patam Index\n", error, i);
	    return 0;
	}
	else
	{
		X_AXIS = atoi(argv[0]);
		Y_AXIS =atoi(argv[1]);
		
    }
	
    printf("X-Axis %s Default %d range %d to %d \n",Rx_serdes_param[X_AXIS],Ch_RxTxParam[X_AXIS][0],Ch_RxTxParam[X_AXIS][1],Ch_RxTxParam[X_AXIS][2]);
	printf("Y-Axis %s Default %d range %d to %d \n",Rx_serdes_param[Y_AXIS],Ch_RxTxParam[Y_AXIS][0],Ch_RxTxParam[Y_AXIS][1],Ch_RxTxParam[Y_AXIS][2]);
}



