/*
 * AppliedMicro
 * Storm-PreSi
 *
 * Filename : command.c
 * Comments : vbios command handler
 *
 */
#include "common.h"
#include "vlib.h"
#include "command.h"
#include "xmodem_utils.h"
#include "vbios_vsyms.h"

char vbios_cmd_buf[50];
int  vbios_cmd_len = 0;
int g_quit;
int g_core_allow;
//extern const struct cmd _cmd_tbl_[];
#if 1
struct cmd {
	char *str;
	int (*cmd_func)(int , char*[]);
	char *help_msg;
};
const struct cmd _cmd_tbl_[] = {
	{"help", vbios_help , "[help] print this help!"} , 
	{"reset", reset , "[reset <opt>] (only soft/applet-reset suported - jump to 0x0) \n \ 
	\t Optional: <opt> = 0:soft (restart uVBIOS), 1:applet (restart VBIOS) , 2:core, 3:soc, 4:hard; Default:1 "} , 
	{"md", md, "[md <addr> <count>] MemodyDisplay\n \
	\t Optional: <count> words from <addr>; Default:1 "} , 
	{"mm", mm, "[mm <addr> <data> <count>] MemoryModify\n \
	\t Optional: <count> words from <addr>; Default:1 "} , 
	{"getfile", getfile, "[getfile <addr> <size>] XMODEM:receive"}, 
	{"sendfile", sendfile, "[sendfile <addr> <size>] XMODEM:transmit"},
	{"getvbios", getvbios, "[getvbios (fixed ocm addr: 0xC0000000, max size: 8MB] XMODEM:receive"}, 
	{"jump2ocm", jump2ocm, "[jump2ocm] Jump to 'OCM-main' function"},
	{"jump2ddr", jump2ddr, "[jump2ddr] Jump to 'DDR-main' function"},
	{"list" , list , "[list <xyz>]: List symbol (function) names containing <xyz>"} ,
	{"go", go, "[go <addr>] Jump to <addr>"},
	{"clear", clrscr, "[clear] Clear Screen"},
	{"exit", vbios_exit, "[exit] exit VBIOS"} 
    };
#endif

void msg_prompt(void){
   printf("VBIOS=>");
}

int parse_line (char *line, char *argv[], int maxargs){
	int nargs = 0;
	while (nargs < maxargs) { 
		/* skip any white space */
		while ((*line == ' ') || (*line == '\t')) {
			++line;
		}
		if (*line == '\0') {	/* end of line, no more arg */
			argv[nargs] = NULL;
			return (nargs);
		}
		argv[nargs++] = line;	/* begin of argument string */

		/* find end of string */
		while (*line && (*line != ' ') && (*line != '\t')) {
			++line;
		}
		if (*line == '\0') {	/* end of line, no more args */
			argv[nargs] = NULL;
			return (nargs);
		}

		*line++ = '\0';		/* terminate current arg */
	}

	printf ("parse_line(): ** Too many args **\n");
	return (nargs);
}


int command_compare(void){
    int argc;
    char *argv[ARGV_SIZE];
	int i=0, ctr = 0;
    unsigned int match=0, totalcmds;

	argc = parse_line(vbios_cmd_buf, argv, 10);

	totalcmds = (sizeof(_cmd_tbl_)/sizeof(struct cmd));
	for(i=0; i<totalcmds; i++) {
		if (strcmp(_cmd_tbl_[i].str, "NULL"))
			if(!strcmp(_cmd_tbl_[i].str, argv[0])) {
                match = 1;
				_cmd_tbl_[i].cmd_func(argc, argv);
				break;
			}
	}
    
	if ((match == 0) || (i==totalcmds)) {
		printf("VBIOS: *Error* Invalid Command\n");
        return -1;
	}
	
    return 0;
//	printf("Exiting Command compare!\n");
}

void vbios_help(void){
	int i, sz;
	printf("*** Following Commands are supported *** \n"); 
	for(i=0; i<(sizeof(_cmd_tbl_)/sizeof(struct cmd)); i++) {
		printf("%s", _cmd_tbl_[i].str);
		sz = strlen(_cmd_tbl_[i].str);
		if (sz < 8)
			printf("\t\t");
		else if (sz < 16) 
			printf("\t");
		printf(": %s\n", _cmd_tbl_[i].help_msg);
	}
    printf("\n");
}
void vbios_exit (void) {
    printf("Exiting VBIOS...\n\n");
    g_quit = 1;
}
void clrscr (void) {
	outbyte(0x1B);  // Escape
	outbyte(0x5B);  //'['
	outbyte(0x48);  //'H'
	outbyte(0x1B);  // Escape
	outbyte(0x5B);  //'['
	outbyte(0x32);  //'2'
	outbyte(0x4A);  //'J'
}
void prompt(void) {

	g_quit = 0;
	g_core_allow = 0;
	int j = 0, ret = 0;
    unsigned char in_ch;

	/* Flushing out the Receive Buffer */
	for(j=0; j<ARGV_SIZE; j++){
		vbios_cmd_buf[j]  = 0;
	}
	/* Flushing out the Pointer */
	vbios_cmd_len = 0;
	
	/* loop here and wait for UART interrupt, until receive 'E' char  */
	msg_prompt();
	while( !g_quit ) {
		/* blocked here until changed */
		while( g_core_allow != 0 );
	    if (g_quit) break;
		in_ch = inbyte();
		switch( in_ch ) {
			case '\r':
			case '\n':
				printf("\n");
				vbios_cmd_buf[vbios_cmd_len] = '\0'; 
				if (vbios_cmd_len > 2) {
                    ret = command_compare();
                    if (ret < 0) {
		                printf("VBIOS: type 'help' for allowed commands\n");
                    }
                }
				if (g_quit) break;
                for(j=0; j<vbios_cmd_len; j++){
            	    vbios_cmd_buf[j]  = 0;
                }
                vbios_cmd_len = 0;
                msg_prompt();
				break;
			case '\b':
				outbyte(in_ch);
				vbios_cmd_len--;
				break;
			default: 
				outbyte(in_ch);
				vbios_cmd_buf[vbios_cmd_len++] = in_ch;
				break;
		}
	}
    if (g_quit) resume_uVBIOS();
}

