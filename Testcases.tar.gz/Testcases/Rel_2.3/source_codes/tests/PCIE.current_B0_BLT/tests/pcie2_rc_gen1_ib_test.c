/*
 * Copyright (c) 2009 Xilinx, Inc.  All rights reserved.
 *
 * Xilinx, Inc.
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS" AS A
 * COURTESY TO YOU.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION AS
 * ONE POSSIBLE   IMPLEMENTATION OF THIS FEATURE, APPLICATION OR
 * STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS IMPLEMENTATION
 * IS FREE FROM ANY CLAIMS OF INFRINGEMENT, AND YOU ARE RESPONSIBLE
 * FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE FOR YOUR IMPLEMENTATION.
 * XILINX EXPRESSLY DISCLAIMS ANY WARRANTY WHATSOEVER WITH RESPECT TO
 * THE ADEQUACY OF THE IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO
 * ANY WARRANTIES OR REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE
 * FROM CLAIMS OF INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

/*
 * helloworld.c: simple test application
 */
#include "pcie_base.h"
#include "pcie_base_test.h"

int pcie2_rc_gen1_ib_test()
{
    uint32_t port_type;     // 0 => EP mode, 1 => RC mode.
    uint32_t en_lpbk;       // 1 => self crosslink mode is enabled.
    uint32_t gen;           // 0 => gen1, 1 => gen2, 2 => gen3.
    uint32_t pcie_core_id;
    uint32_t ext_ref = 1;
    uint32_t link_width = 1;
    uint32_t test_name = 0;
    uint32_t test_pattern = 1;
    uint32_t length = 16;
    uint32_t extended_addr = 0;
    uint32_t poll = 1;

#ifndef SM_SOC_SIM   
    init_platform();
    ocm_init();
#endif    
    print("Storm SOC FPGA: \n\r\n\r");
    print("Testing for PCIE: \n\r\n\r");

    pcie_core_id = 2;
    port_type = RC;
    en_lpbk = 0;
    gen = 1;

    sm_pcie_init(pcie_core_id, port_type, en_lpbk, gen, ext_ref, link_width, poll);

    print("Linkup achieved in gen1 for RC DUT in normal mode. Now, will do some testing.\n\r");

    sm_pcie_test_rc(pcie_core_id, test_name, test_pattern, length, extended_addr);

    print("*****************************************\n\r");
    print("************** Test Complete ************\n\r");
    print("*****************************************\n\r");

#ifndef SM_SOC_SIM
    cleanup_platform();
#endif    

    return 0;
}
