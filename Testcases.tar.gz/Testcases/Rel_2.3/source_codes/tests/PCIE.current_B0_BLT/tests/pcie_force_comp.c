/*
 * Copyright (c) 2009 Xilinx, Inc.  All rights reserved.
 *
 * Xilinx, Inc.
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS" AS A
 * COURTESY TO YOU.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION AS
 * ONE POSSIBLE   IMPLEMENTATION OF THIS FEATURE, APPLICATION OR
 * STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS IMPLEMENTATION
 * IS FREE FROM ANY CLAIMS OF INFRINGEMENT, AND YOU ARE RESPONSIBLE
 * FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE FOR YOUR IMPLEMENTATION.
 * XILINX EXPRESSLY DISCLAIMS ANY WARRANTY WHATSOEVER WITH RESPECT TO
 * THE ADEQUACY OF THE IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO
 * ANY WARRANTIES OR REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE
 * FROM CLAIMS OF INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

/*
 * helloworld.c: simple test application
 */
#include "pcie_base.h"
#include "pcie_base_test.h"

//#define SDS_DEBUG
//This test force controller to enter compliance mode and generate GEN3 compliance signal
int pcie_force_comp(int argc, char *argv[])
{
    uint32_t port_type;     // 0 => EP mode, 1 => RC mode.
    uint32_t en_lpbk;       // 1 => self crosslink mode is enabled.
    uint32_t gen;           // 0 => gen1, 1 => gen2, 2 => gen3.
    uint32_t pcie_core_id;
    uint32_t ext_ref = 0;
    uint32_t link_width;
    uint32_t test_name = 0;
    uint32_t test_pattern = 1;
    uint32_t length = 16;
    uint32_t extended_addr = 0;
    uint32_t poll = 0;
    
    if (argc < 3){
       print("not enough argument portid, link_width, gen, extref \n\r");
       return -1;
    } else {
        pcie_core_id = atoi(argv[0]);
        link_width   = atoi(argv[1]);
        gen          = atoi(argv[2]);
        ext_ref      = atoi(argv[3]);
    }

    print("Storm SOC : \n\r\n\r");
    print("PCIE compliance mode: \n\r\n\r");

    port_type = RC;
    en_lpbk = 0;

    sm_pcie_init(pcie_core_id, port_type, en_lpbk, gen, ext_ref, link_width, poll);
    force_cp_mode(pcie_core_id);


    print("*****************************************\n\r");
    print("************** Test Complete ************\n\r");
    print("*****************************************\n\r");

#ifndef SM_SOC_SIM
    cleanup_platform();
#endif    

    return 0;
}
