/*
 * Copyright (c) 2009 Xilinx, Inc.  All rights reserved.
 *
 * Xilinx, Inc.
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS" AS A
 * COURTESY TO YOU.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION AS
 * ONE POSSIBLE   IMPLEMENTATION OF THIS FEATURE, APPLICATION OR
 * STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS IMPLEMENTATION
 * IS FREE FROM ANY CLAIMS OF INFRINGEMENT, AND YOU ARE RESPONSIBLE
 * FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE FOR YOUR IMPLEMENTATION.
 * XILINX EXPRESSLY DISCLAIMS ANY WARRANTY WHATSOEVER WITH RESPECT TO
 * THE ADEQUACY OF THE IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO
 * ANY WARRANTIES OR REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE
 * FROM CLAIMS OF INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

/*
 * helloworld.c: simple test application
 */
#include <types.h>
#include <stdio.h>
#include <common.h>
#include "pcie_base.h"
#include "pcie_base_test.h"

//puts controller 0 and 3 into gen3 compliance mode
//port0 serdes generate PRBS31 to port 3, port 3 check PRBS pass/fail on all 8 lanes
//port3 serdes generate PRBS31 to port 0, port 0 check PRBS pass/fail on all 8 lanes
int prbs_chk_loop (int core_id, int ch){
int ii, fail=0;
    for(ii=0; ii < 4; ii++){ 
        fail = bert_check_sub(core_id, ch, 0);
        //if pass, break out of loop
        //if fail, try 3 more times
        if (!fail) {
            print("PRBS PASS port: %0x ch: %0x \n\r", core_id , ch);
            return 0;
            break;
        }
    }
    if (fail){
        print("PRBS FAIL port: %0x ch: %0x \n\r", core_id , ch);
        return 1;
    }
}

int pcie_slt_prbs(int argc, char *argv[])
{
    int p0_ch0_r;
    int p0_ch1_r;
    int p0_ch2_r;
    int p0_ch3_r;
    int p0_ch4_r;
    int p0_ch5_r;
    int p0_ch6_r;
    int p0_ch7_r;
    int p3_ch0_r;
    int p3_ch1_r;
    int p3_ch2_r;
    int p3_ch3_r;
    int p3_ch4_r;
    int p3_ch5_r;
    int p3_ch6_r;
    int p3_ch7_r;
    int p0_pass, p3_pass;
    int ii, gen;
    print("Storm SOC : \n\r\n\r");
    print("PCIE SLT PRBS test: \n\r\n\r");

    if (argc < 1){
       print("not enough argument gen \n\r");
       return -1;
    } else {
        gen = atoi(argv[0]);
    }

    //force port0 to gen3 compliance mode
    //sm_pcie_init(pcie_core_id, port_type, en_lpbk, gen, ext_ref, link_width, poll);
    sm_pcie_init(0, 1, 0, gen, 1, 8, 0);
    force_cp_mode(0);

    //force port3 to gen3 compliance mode
    sm_pcie_init(3, 1, 0, gen, 1, 8, 0);
    force_cp_mode(3);

    //set TX PRBS pattern on both port
    set_tx_prbs(0, 31);
    set_tx_prbs(3, 31);

    //set RX PRBS pattern on both port
    set_rx_prbs(0, 31);
    set_rx_prbs(3, 31);

    MSDELAY(50);
    //checking port 0 result
    p0_ch0_r = prbs_chk_loop(0, 0);
    p0_ch1_r = prbs_chk_loop(0, 1);
    p0_ch2_r = prbs_chk_loop(0, 2);
    p0_ch3_r = prbs_chk_loop(0, 3);
    p0_ch4_r = prbs_chk_loop(0, 4);
    p0_ch5_r = prbs_chk_loop(0, 5);
    p0_ch6_r = prbs_chk_loop(0, 6);
    p0_ch7_r = prbs_chk_loop(0, 7);
        
    //checking port 3 result
    p3_ch0_r = prbs_chk_loop(3, 0);
    p3_ch1_r = prbs_chk_loop(3, 1);
    p3_ch2_r = prbs_chk_loop(3, 2);
    p3_ch3_r = prbs_chk_loop(3, 3);
    p3_ch4_r = prbs_chk_loop(3, 4);
    p3_ch5_r = prbs_chk_loop(3, 5);
    p3_ch6_r = prbs_chk_loop(3, 6);
    p3_ch7_r = prbs_chk_loop(3, 7);
    
    p0_pass = (p0_ch0_r + p0_ch1_r + p0_ch2_r + p0_ch3_r + p0_ch4_r + p0_ch5_r + p0_ch6_r + p0_ch7_r) == 0;
    p3_pass = (p3_ch0_r + p3_ch1_r + p3_ch2_r + p3_ch3_r + p3_ch4_r + p3_ch5_r + p3_ch6_r + p3_ch7_r) == 0;

    if(p0_pass && p3_pass) { print("PRBS PASS\n\r"); }
    else {
      print("PRBS FAIL  port 0 : %0x port 3: %0x \n\r", p0_pass , p3_pass);
    }
    return 0;
}
