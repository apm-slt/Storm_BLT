/* Author: your_name@apm.com 
*  Company: Applied Micro Circuits Corporation (AMCC)
* 
* Describe the purpose of your Test here
*
*/
#include "L1_SPI_1_RW_NAND_DIFF_RATIOS.h"


//Tinh-SLT
//function call
#define str2val str2val_spi
#define printPASS printPASS_spi
#define printFAIL printFAIL_spi

int spi_rw_nand_diff_ratio (int argc, char *argv[]) {
	int speed;

	int error = 0;
//----- Put your code here -------
	int base;
	int i;
	u32 slave_num;
	slave_num = 0;
	char s=0;
choose_speed:
	printf("Please choose speed before running SPI: \n");
	printf("   - For 1Mhz press  0\n");
	printf("   - For 3Mhz press  1\n");
	printf("   - For 5Mhz press  2\n");
	printf("   - For 10Mhz press 3\n");
	printf("   - For 25Mhz press 4\n");
	printf("   - For 50Mhz press 5\n");

	while(1){
		s = getchar();
		if(s !=0)
			break;
	}
	switch(s){
		case '0':
			APM_NOTICE("You have chosen 1MHz\n");
			speed = SPEED_1MHZ;
			break;
		case '1':
			APM_NOTICE("You have chosen 3MHz\n");
			speed = SPEED_3MHZ;
			break;
		case '2':
			APM_NOTICE("You have chosen 5MHz\n");
			speed = SPEED_5MHZ;
			break;
		case '3':
			APM_NOTICE("You have chosen 10MHz\n");
			speed = SPEED_10MHZ;
			break;
		case '4':
			APM_NOTICE("You have chosen 25MHz\n");
			speed = SPEED_25MHZ;
			break;
		case '5':
			APM_NOTICE("You have chosen 50MHz\n");
			speed = SPEED_50MHZ;
			break;
		default:
			APM_NOTICE("Please follow the direction\n");
			goto choose_speed;
	}
	base = SPI1_BASE;
	error = spi_init_h(base);

	/* Initialize controller */
	spi_init_core(base,speed,slave_num);

	if (error != 0)
		goto end;
	v_spi_claim_bus(base,slave_num);
	error = spi_rw_test_nand(base, slave_num) ;
	if (error != 0)
		goto end;

//--------------------------------
end:
	if (error == 0)
		printPASS();
	else
		printFAIL();

	return 0;

}
int spi_init (int argc, char *argv[]) {
	int error = 0;
//----- Put your code here -------
	int base;
	int i;
	u32 slave_num;
	int speed;
	u8_s id_code[4];

	slave_num = 0;

    speed = str2val(argv[0]);

    base = SPI1_BASE;
	error = spi_init_h(base);

	/* Initialize controller */
	spi_init_core(base,100/speed,slave_num);

	v_spi_claim_bus(base,slave_num);

	printf("spi reset ....\n");
	spi_reset(base,slave_num);

	error = spi_read_id_serial_flash_memory (base, 0x4, id_code,slave_num);
}
int wr (int argc, char *argv[]) {
	int error = 0;
//----- Put your code here -------
	int base;
	int i;
	u32 slave_num;
	int byte_num;
	slave_num = 0;
    base = SPI1_BASE;

    byte_num = str2val(argv[0]);

	error = spi_wr(base, slave_num, byte_num) ;
	if (error != 0)
		goto end;

//--------------------------------
end:
	if (error == 0)
		printPASS();
	else
		printFAIL();

	return 0;
}
int rd (int argc, char *argv[]) {
	int error = 0;
//----- Put your code here -------
	int base;
	int i;
	u32 slave_num;
	int byte_num;
	slave_num = 0;
    base = SPI1_BASE;

    byte_num = str2val(argv[0]);

	error = spi_rd(base, slave_num, byte_num) ;
	if (error != 0)
		goto end;


//--------------------------------
end:
	if (error == 0)
		printPASS();
	else
		printFAIL();

	return 0;
}
int era (int argc, char *argv[]) {
	int error = 0;
//----- Put your code here -------
	int base;
	int i;
	u32 slave_num;
	slave_num = 0;
    base = SPI1_BASE;

	error = spi_era(base, slave_num) ;
	if (error != 0)


//--------------------------------
end:
	if (error == 0)
		printPASS();
	else
		printFAIL();

	return 0;
}
