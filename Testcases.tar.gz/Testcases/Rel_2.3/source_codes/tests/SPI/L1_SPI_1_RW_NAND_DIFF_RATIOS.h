/* Author: your_name@apm.com 
*  Company: Applied Micro Circuits Corporation (AMCC)
* 
* Describe the purpose of your Test here
*
*/
#include <stdio.h>
#include <string.h>
#include <common.h>
//#include <config.h>

//Tinh-SLT
//give the full path to include these header files
#include "../../SPI/include/types.h"
#include "../../SPI/include/common.h"
#include "../../SPI/include/common_def.h"

#include "../../SPI/include/vSPI_regs.h"
#include "../../SPI/include/vSPI_defines.h"
#include "../../SPI/driver/vSPI_driver.c"
#include "../../SPI/driver/vSPI_nand.c"
#include "../../SPI/driver/vSPI_eeprom.c"

