/* Author: your_name@apm.com 
*  Company: Applied Micro Circuits Corporation (AMCC)
* 
* Describe the purpose of your Test here
*
*/
#include "L1_SD_4BIT_MODE_WRITE_READ_SDMA.h"


int SDIO_SDMA (u8 sdio_no,u32 capacity) {
	int sdio_status = 0;
	
//----- Put your code here -------

//	printf("\n############################################################\n");
//	printf("## Start    %-40s %8s",__FUNCTION__,"##\n");
//	printf("############################################################\n");
	printf ("$$$$ TEST SDMA PORT %u $$$$\n", sdio_no);
	SDIO_soft_reset();
	sdio_status = sdio_sdma(sdio_no,capacity);
//--------------------------------
	if (sdio_status == 0)
	{
    	printf("\n\n");
    	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
    	printf ("$$$$ RESULT: TEST PASS $$$$\n");
    	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
    	printf("\n\n");
	}
	else
	{
    	printf("\n\n");
    	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
    	printf ("$$$$ RESULT: TEST FAILED $$$$\n");
    	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
    	printf("\n\n");
	}
	return 0;
}

