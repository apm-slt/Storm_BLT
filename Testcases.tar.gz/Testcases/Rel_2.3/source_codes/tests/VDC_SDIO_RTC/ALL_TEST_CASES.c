/* Author: your_name@apm.com
*  Company: Applied Micro Circuits Corporation (AMCC)
*
* Describe the purpose of your Test here
*
*/
#include "ALL_TEST_CASES.h"


#define TEST_NUM 6
//#define TEST_NUM 4
//int zzzmain (void){
int SDIO_test (void){

	typedef struct{
	char *test_name;
	unsigned int test_id;
	}testcase_t;

	testcase_t testcase[TEST_NUM];

	testcase[0].test_name = "SDIO_PIO";
	testcase[0].test_id = 0;


	testcase[1].test_name = "SDIO_SDMA";
	testcase[1].test_id = 1;

	testcase[2].test_name = "SDIO_ADMA";
	testcase[2].test_id = 2;

	testcase[3].test_name = "EMMC_ADMA";
	testcase[3].test_id = 3;
	testcase[4].test_name = "MMC_ADMA";
	testcase[4].test_id = 4;
	testcase[TEST_NUM-1].test_name = "ALL_TEST_CASES";
	testcase[TEST_NUM-1].test_id = TEST_NUM-1;

	printf("####  Regression testcases for Storm B0 ####\n");

    char ch, str[30], str1[30];
    int number;
	while(1){
		printf("************  Instruction  *****************\n");
		printf(" Numbers corresponding to the testcases\n");
			printf("Enter Ctrl+C to exit\n");
			int i;
			for(i=0;i<TEST_NUM;i++){
			printf("%u. %s\n", testcase[i].test_id, testcase[i].test_name);
			}
		printf("\nPlease enter an integer number between 0 and %u\n",TEST_NUM-1);
		gets(str);
		if(str[0]>=0x30 && str[0]<=0x39){
		number =atoi(str);
		}
		else if(str[0]==0x3){  //Enter
			break;
		}
		 switch (number){
		 case 0:
			 while(1)
			 {
				 printf("\n************  Instruction  *****************\n");
				 printf("Please enter sector address from 1 to 10000 or press 'Enter' key to exit\n");
				 gets(str1);
				 if((atoi(str1) > 0 )&&(atoi(str1) <= 10000))
				 {
					 printf("\n Sector Address =  %u\n",atoi(str1));
					 SDIO_PIO(1, atoi(str1));
					 SDIO_PIO(2, atoi(str1));
					 break;
				 }
				 else if(str1[0]== 0){  //Enter
					break;
				 }
			}
			 return 0;
		 case 1:
			 while(1)
			 {
				 printf("\n************  Instruction  *****************\n");
				 printf("Please enter sector address from 1 to 10000 or press 'Enter' key to exit\n");
				 gets(str1);
				 if((atoi(str1) > 0 )&&(atoi(str1) <= 10000))
				 {
					 printf("\n Sector Address =  %u\n",atoi(str1));
					 SDIO_SDMA(1, atoi(str1));
					 SDIO_SDMA(2, atoi(str1));
					 break;
				 }
				 else if(str1[0]== 0){  //Enter
					break;
				 }
			}
			 return 0;
		 case 2:
			 while(1)
			 {
				 printf("\n************  Instruction  *****************\n");
				 printf("Please enter sector address from 1 to 10000 or press 'Enter' key to exit\n");
				 gets(str1);
				 if((atoi(str1) > 0 )&&(atoi(str1) <= 10000))
				 {
					 printf("\n Sector Address =  %u\n",atoi(str1));
					 SDIO_ADMA(1, atoi(str1));
					 SDIO_ADMA(2, atoi(str1));
					 break;
				 }
				 else if(str1[0]== 0){  //Enter
					break;
				 }
			}
			 return 0;
		 case 3:
			 EMMC_ADMA();
			 return 0;
		 case 4:
			 MMC_ADMA();
			 return 0;
		default:
			 ALL_TEST_CASES();
			 return 0;
		 }


	}
	return 0;
}

int ALL_TEST_CASES (void) {
	int error = 0;
	int in_ch;
    char str1[30];
//----- Put your code here -------
int group_tests =TEST_NUM-1; // Some testcases can not be grouped.

printf("\n############################################################\n");
printf("## Start    %-40s %8s",__FUNCTION__,"##\n");
printf("############################################################\n");
while(1)
{
	 printf("\n************  Instruction  *****************\n");
	 printf("Please enter sector address from 1 to 10000 or press 'Enter' key to exit\n");
	 gets(str1);
	 if((atoi(str1) > 0 )&&(atoi(str1) <= 10000))
	 {
		 printf("\n Sector Address =  %u\n",atoi(str1));
		 error += SDIO_PIO(1, atoi(str1));
		 error += SDIO_PIO(2, atoi(str1));
		 error += SDIO_SDMA(1, atoi(str1));
		 error += SDIO_SDMA(2, atoi(str1));
		 error += SDIO_ADMA(1, atoi(str1));
		 error += SDIO_ADMA(2, atoi(str1));
		 break;
	 }
	 else if(str1[0]== 0){  //Enter
		break;
	 }
}
printf("############################################################\n");
printf("##             Number of PASSED Tests: %02u                 ##\n",group_tests-error);
printf("##             Number of FAILED Tests: %02u                 ##\n",error);
printf("############################################################\n");
if(error)
{
printf("fail\n");
}


//--------------------------------

	if (error == 0)
		printPASSSDIO();
	else
		printFAILSDIO();

	return 0;
}
