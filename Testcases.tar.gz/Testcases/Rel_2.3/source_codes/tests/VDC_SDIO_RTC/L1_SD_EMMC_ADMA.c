/* Author: your_name@apm.com 
*  Company: Applied Micro Circuits Corporation (AMCC)
* 
* Describe the purpose of your Test here
*
*/
#include "L1_SD_EMMC_ADMA.h"


int EMMC_ADMA (void) {
	int error = 0;
	
//----- Put your code here -------

	printf("\n############################################################\n");
	printf("## Start    %-40s %8s",__FUNCTION__,"##\n");
	printf("############################################################\n");
    SDIO_soft_reset();
    error = emmc_adma(1);
//    SDIO_soft_reset();
//    error = emmc_adma(2);
//--------------------------------
	if (error == 0)
	{
    	printf("\n\n");
    	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
    	printf ("$$$$ RESULT: TEST PASS $$$$\n");
    	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
    	printf("\n\n");
	}
	else
	{
    	printf("\n\n");
    	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
    	printf ("$$$$ RESULT: TEST FAILED $$$$\n");
    	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
    	printf("\n\n");
	}
	return 0;
}

