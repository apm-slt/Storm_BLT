/*
 * Copyright (C) 2013 AppliedMicro Confidential Information
 * All Rights Reserved.
 *
 * THIS WORK CONTAINS PROPRIETARY INFORMATION WHICH IS THE PROPERTY OF
 * AppliedMicro AND IS SUBJECT TO THE TERMS OF NON-DISCLOSURE AGREEMENT
 * BETWEEN AppliedMicro AND THE COMPANY USING THIS FILE.
 *
 * WARNING !!!
 * This is an auto-generated C header file for register definitions
 * PLEASE DON'T MANUALLY MODIFY IN THIS FILE AS CHANGES WILL BE LOST
 *
 * rtc_driver.c
 *
 *  Created on: Mar 07, 2013
 *      Author: kqngo@apm.com
 */

#ifndef RTC_DRIVER_C_
#define RTC_DRIVER_C_

//Tinh-SLT
//give full path to include header files
#include "../../VDC_SDIO_RTC/include/rtc_driver.h"
#define sm_host_read32 sm_host_read32_rtc
#define sm_host_write32 sm_host_write32_rtc
#define COMPARE_val COMPARE_val_rtc
#define SETBITS_high SETBITS_high_rtc
#define SETBITS_low SETBITS_low_rtc

typedef struct RTC{
	u32	CCVR;		// RTC Current Count Value Register
	u32	CMR;		// RTC Counter Match Register
	u32	CLR;		// RTC Counter Load Register
	// RTC Counter Control Register
	u32	IEN:1;		// RTC IRQ Enable
	u32	MASK:1;		// RTC IRQ Mask
	u32	EN:1;		// RTC Counter Enable
	u32	WEN:1;		// RTC WRAP Enable
	u32	rsv0:28;	// Reserved
	// RTC Interrupt Status Register
	u32	STAT:1;		// RTC Interrupt Status
	u32	rsv1:31;	// Reserved
	// RTC Raw Interrupt Status Register
	u32	RSTAT:1;	// RTC Raw Interrupt Status
	u32	rsv2:31;	// Reserved
	// RTC End-Of-Interrupt Register
	u32	EOI:1;		// RTC End-Of-Interrupt
	u32	rsv3:31;	// Reserved
	u32	COMP_VER;	// RTC Component Version Register
}rtc;
rtc *rtc_reg = (rtc *) ((void *)(RTC_BASE__ADDR));

typedef struct rtc_time{
//typedef struct RTC_TIME{
	int tm_sec;
	int tm_min;
	int tm_hour;
	int tm_mday;
	int tm_mon;
	int tm_year;
};
//}rtc_time;

int irq_cnt;

void sm_host_read32(u64 addr, unsigned int* data){
	*data = *((volatile unsigned int *) addr);
}

void sm_host_write32(u64 addr, unsigned int data){
	*((volatile unsigned int *) addr) = data;
}

void sm_rtc_write32(u32 addr, u32 data){
	u32 rd_data;

	sm_host_write32(addr, data);
	sm_host_read32(addr, &rd_data);
	if(data != rd_data)
		lprintf(7, "\n RTC_WRITE [0x%08x] : [0x%08x] = [0x%08x] --> WARNING", addr, data, rd_data);
	else
		lprintf(8, "\n RTC_WRITE [0x%08x] : [0x%08x] = [0x%08x]", addr, data, rd_data);
}

u32 sm_rtc_read32(u32 addr){
	u32 rd_data;

	sm_host_read32(addr, &rd_data);
	lprintf(8, "\n RTC_READ  [0x%08x] : [0x%08x]", addr, rd_data);
	return rd_data;
}

int COMPARE_val(u32 addr, u32 def_val){
	u32 rd_val;
	//rd_val = sm_sata_read32(addr);
	sm_host_read32(addr, &rd_val);
	lprintf(6, "\n COMPARE [0x%08x] [0x%08x] ", addr, rd_val);
	if (rd_val != def_val){
		lprintf(7, "!= [0x%08x] FAILED", def_val);
		return -1;
	}
	else
		lprintf(8, " = [0x%08x]", def_val);
	return 0;
}

int SETBITS_high(u32 addr, u32 bits){
	int i;
	u32 rd_val, wr_val;

	sm_host_read32(addr, &rd_val);
	wr_val = rd_val | bits;
	sm_host_write32(addr, wr_val);
	for(i=0; i<0x8000; ++i);
	sm_host_read32(addr, &rd_val);
	if((rd_val & bits) != bits){
		lprintf(7, "\n\n [ERROR]: SETBITS_high Addr[0x%08x] Bits[0x%08x] RdBk[0x%08x]\n", addr, bits, rd_val);
		return -1;
	}
	else
		lprintf(8, "\n SETBITS_high Addr[0x%08x] Bits[0x%08x] RdBk[0x%08x]", addr, bits, rd_val);
	return 0;
}

int SETBITS_low(u32 addr, u32 bits){
	int i;
	u32 rd_val, wr_val;

	sm_host_read32(addr, &rd_val);
	wr_val = rd_val & ~bits;
	sm_host_write32(addr, wr_val);
	for(i=0; i<0x8000; ++i);
	sm_host_read32(addr, &rd_val);
	if((rd_val & bits) != 0){
		lprintf(7, "\n\t [ERROR]: SETBITS_low Addr[0x%08x] Bits[0x%08x] RdBk[0x%08x]\n", addr, bits, rd_val);
		return -1;
	}
	else
		lprintf(8, "\n SETBITS_low Addr[0x%08x] Bits[0x%08x] RdBk[0x%08x]", addr, bits, rd_val);

	return 0;
}

int sm_rtc_init(void){
	int rc = 0;

	lprintf(6, "\nsm_rtc_init");
/* Enable and Reset RTC Clock */
	lprintf(6, "\n Disable RTC Clock ...");
	lprintf(7, "\n SCU_CLKEN [1]");
	rc += SETBITS_low(SCU_BASE__ADDR + SCU_CLKEN__ADDR, 0x00000002);

	lprintf(6, "\n\n Put RTC in reset ...");
	lprintf(7, "\n SCU_SRST [1]");
	rc += SETBITS_high(SCU_BASE__ADDR + SCU_SRST__ADDR, 0x00000002);

	lprintf(6, "\n\n Pull RTC out of reset ...");
	lprintf(7, "\n SCU_SRST [1]");
	rc += SETBITS_low(SCU_BASE__ADDR + SCU_SRST__ADDR, 0x00000002);

	lprintf(6, "\n\n Enable RTC Clock ...");
	lprintf(7, "\n SCU_CLKEN [1]");
	rc += SETBITS_high(SCU_BASE__ADDR + SCU_CLKEN__ADDR, 0x00000002);

	rtc_reg->EN = 1;


	printf("\n\n RTC_CCR = 0x%08X\n\n", sm_rtc_read32(RTC_BASE__ADDR + RTC_CCR__ADDR));


	if(rc)
		lprintf(3, "\n\n RTC Initiation ... FAILED\n");
	else
		lprintf(3, "\n\n RTC Initiation ... PASSED\n");
	return rc;
}
void init_rtc(void){
	sm_rtc_init();
}

void cnt_read(void){
	printf("\n RTC_CCVR = 0x%08X", rtc_reg->CCVR);
}

int sm_rtc_set_match(unsigned val){
	lprintf(6, "\nsm_rtc_set_match");
	rtc_reg->CMR = val;
	if(rtc_reg->CMR == val){
		printf("\n RTC_CMR = 0x%08X", val);
		return 0;
	}
	else{
		printf("\n [ERROR]: RTC_CMR = 0x%08X", val);
		return -1;
	}

}
void cnt_match(int argc, char *argv[]){
	int val;
	if(argc != 1){
		printf("\n Syntax: set_match [VAL]");
		printf("\n\t where [VAL] = 32-bit hex value\n");
	}else{
		val = strtol(argv[0],NULL,0);
		sm_rtc_set_match(val);
	}
}

int sm_rtc_load_counter(u32 val){
	int timeout;

	lprintf(6, "\nsm_rtc_load_counter");
	rtc_reg->CLR = val;
	timeout = 20;
	while((rtc_reg->CLR != val) && --timeout){
		MSDELAY(100);
	}
	if(timeout){
		timeout = 10;
		while((rtc_reg->CCVR != val) && --timeout){
			MSDELAY(300);
		}
		if(timeout){
			//printf("\n The counter is successfully set to 0x%08X ", val);
			return 0;
		}
		else{
			printf("\n [ERROR]: Unable to load 0x%08X to the RTC_CCVR \n", val);
			return -1;
		}
	}
	else{
		printf("\n [ERROR]: Unable to load 0x%08X to the RTC_CLR \n", val);
		return -1;
	}
}
void cnt_load(int argc, char *argv[]){
	int val;
	if((argc == 0) || (argc > 6)){
		printf("\n Syntax: set_cnt [VAL]");
		printf("\n\t where [VAL] = 32-bit hex value\n");
	}else{
		val = strtol(argv[0],NULL,0);
		sm_rtc_load_counter(val);
	}
}

int sm_rtc_irq_ena(void){
	lprintf(6, "\nsm_rtc_irq_ena");
	rtc_reg->IEN = 1;
	if(rtc_reg->IEN){
		printf("\n RTC Interrupt is ENABLE");
		return 0;
	}
	else{
		printf("\n [ERROR]: Timeout while enabling RTC Interrupt");
		return -1;
	}
}
void irq_ena(void){
	sm_rtc_irq_ena();
}

int sm_rtc_irq_dis(void){
	lprintf(6, "\nsm_rtc_irq_dis");
	rtc_reg->IEN = 0;
	if(rtc_reg->IEN == 0){
		printf("\n RTC Interrupt is DISABLE");
		return 0;
	}
	else{
		printf("\n [ERROR]: Timeout while disabling RTC Interrupt");
		return -1;
	}
}
void irq_dis(void){
	sm_rtc_irq_dis();
}

int sm_rtc_irq_msk_ena(void){
	lprintf(6, "\nsm_rtc_irq_msk_ena");
	rtc_reg->MASK = 1;
	if(rtc_reg->MASK){
		printf("\n RTC Interrupt Mask is ENABLE");
		return 0;
	}
	else{
		printf("\n [ERROR]: Timeout while enabling RTC Interrupt Mask");
		return -1;
	}
}
void irq_msk_ena(void){
	sm_rtc_irq_msk_ena();
}

int sm_rtc_irq_msk_dis(void){
	lprintf(6, "\nsm_rtc_irq_msk_dis");
	rtc_reg->MASK = 0;
	if(rtc_reg->MASK == 0){
		printf("\n RTC Interrupt Mask is DISABLE");
		return 0;
	}
	else{
		printf("\n [ERROR]: Timeout while disabling RTC Interrupt Mask");
		return -1;
	}
}
void irq_msk_dis(void){
	sm_rtc_irq_msk_dis();
}

int sm_rtc_cnt_ena(void){
	lprintf(6, "\nsm_rtc_cnt_ena");
	rtc_reg->EN = 1;
	if(rtc_reg->EN){
		printf("\n RTC Counter is ENABLE");
		return 0;
	}
	else{
		printf("\n [ERROR]: Timeout while enabling RTC Counter");
		return -1;
	}
}
void cnt_ena(void){
	sm_rtc_cnt_ena();
}

int sm_rtc_cnt_dis(void){
	lprintf(6, "\nsm_rtc_cnt_dis");
	rtc_reg->EN = 0;
	if(rtc_reg->EN == 0){
		printf("\n RTC Counter is DISABLE");
		return 0;
	}
	else{
		printf("\n [ERROR]: Timeout while disabling RTC Counter");
		return -1;
	}
}
void cnt_dis(void){
	sm_rtc_cnt_dis();
}

int sm_rtc_wrap_ena(void){
	lprintf(6, "\nsm_rtc_wrap_ena");
	rtc_reg->WEN = 1;
	if(rtc_reg->WEN){
		printf("\n RTC WRAP is ENABLE");
		return 0;
	}
	else{
		printf("\n [ERROR]: Timeout while enabling RTC WRAP");
		return -1;
	}
}
void wrap_ena(void){
	sm_rtc_wrap_ena();
}

int sm_rtc_wrap_dis(void){
	lprintf(6, "\nsm_rtc_wrap_dis");
	rtc_reg->WEN = 0;
	if(rtc_reg->WEN == 0){
		printf("\n RTC WRAP is DISABLE");
		return 0;
	}
	else{
		printf("\n [ERROR]: Timeout while disabling RTC WRAP");
		return -1;
	}
}
void wrap_dis(void){
	sm_rtc_wrap_dis();
}

void sm_rtc_irq_status(void){
	lprintf(6, "\nsm_rtc_irq_status");
	if(rtc_reg->STAT)
		printf("\n RTC_STAT is SET");
	else
		printf("\n RTC_STAT is UNSET");

	if(rtc_reg->RSTAT)
		printf("\n RTC_RSTAT is SET");
	else
		printf("\n RTC_RSTAT is UNSET");
}
void irq_stat(void){
	sm_rtc_irq_status();
}

void sm_rtc_read_eoi(void){
	lprintf(6, "\nsm_rtc_read_eoi");
	sm_rtc_read32(RTC_BASE__ADDR + RTC_EOI__ADDR);
	printf("\n ... clearing interrupt status registers ...");
	MSDELAY(1000);
}
void eoi(void){
	sm_rtc_read_eoi();
}
void irq_clr(void){
	sm_rtc_read_eoi();
}

/************************ RTC - Tests *********************/
void sm_rtc_show_regs(void){
	printf("\n RTC_CCVR  = %d - Current Counter Value", rtc_reg->CCVR);
	printf("\n RTC_CMR   = %d - Counter Match", rtc_reg->CMR);
	printf("\n RTC_CLR   = %d - Counter Load", rtc_reg->CLR);
	printf("\n RTC_IEN   = %d - Interrupt Enable", rtc_reg->IEN);
	printf("\n RTC_MASK  = %d - Interrupt Mask", rtc_reg->MASK);
	printf("\n RTC_EN    = %d - Counter Enable", rtc_reg->EN);
	printf("\n RTC_WEN   = %d - Wrap Enable", rtc_reg->WEN);
	printf("\n RTC_STAT  = %d - Interrupt Status", rtc_reg->STAT);
	printf("\n RTC_RSTAT = %d - Raw Interrupt Status", rtc_reg->RSTAT);
	printf("\n RTC_EOI   = %d - End of Interrupt", rtc_reg->EOI);
	printf("\n RTC_COMP_VER: 0x%08X", rtc_reg->COMP_VER);
}
void regs(void){
	sm_rtc_show_regs();
}

int sm_rtc_counter_test(void){
	u32 data;

	lprintf(6, "\nsm_rtc_counter_test");
	if(sm_rtc_init() == 0){
		printf("\n Testing RTC Counter ...");
		data = rtc_reg->CCVR;
		printf("\n RTC_CCVR = 0x%08X", data);
		printf("\n ... delaying 5 seconds ...");
		MSDELAY(5000);
		printf("\n RTC_CCVR = 0x%08X \n", rtc_reg->CCVR);
		if((rtc_reg->CCVR - data) == 5){
			printf("\n\t RTC Counter is working \n");
			return 0;
		}
		else{
			printf("\n\t RTC Counter is NOT working \n");
			return -1;
		}
	}
	else{
		printf("\n\t [ERROR]: RTC initiation FAILED\n");
		return -1;
	}
}
void cnt_test(void){
	sm_rtc_counter_test();
}

void sm_rtc_irq(void){
	printf("\n\n =====> RTC INTERRUPT OCCURRED <===== ");
	sm_rtc_show_regs();
	++irq_cnt;
	printf("\n RTC_EOI   = %d", rtc_reg->EOI);
	printf("\n ... delaying for clearing IRQ Status regs... \n");
	MSDELAY(1000);
}

int sm_rtc_irq_test(int sec){
	printf("\nsm_rtc_irq_test");
	irq_cnt = 0;
    // Run irq handler function one time only
	lprintf(7, "\n GICD_ICFGR10");
	sm_host_write32(0x78010c28, 0xFFFFFFFF);
	lprintf(6, "\n\t Registering GIC IRQ for RTC");
	register_irq_handler(102, sm_rtc_irq);

	if(sm_rtc_init() == 0){
		rtc_reg->MASK = 0;
		rtc_reg->IEN = 1;
		rtc_reg->WEN = 0;
		rtc_reg->CMR = rtc_reg->CCVR + sec;
		sm_rtc_show_regs();
		//MSDELAY(1000);
		printf("\n Estimated time for an IRQ occurs: %d seconds", sec);
		printf("\n ... delaying for an IRQ occurs ...");
		MSDELAY((sec + 1) * 1000);
	}
	else{
		printf("\n\t [ERROR]: RTC initiation FAILED \n");
	}
	if(irq_cnt)	printf("\n RTC IRQ Test PASSED \n");
}
void irq_rtc(int argc, char *argv[]){
	u32 sec;
	if(argc != 1){
		printf("\n Syntax: irq_rtc [SEC]");
		printf("\n\t where [SEC] = Number of seconds to check the counter\n");
	}else{
		sec = atoi(argv[0]);
		sm_rtc_irq_test(sec);
	}
}

int sm_rtc_irq_mask_test(int sec){
	int i, rc = 0;
	u32 data;
	u64 addr;

	printf("\nsm_rtc_irq_mask_test");
	irq_cnt = 0;
    // Run irq handler function one time only
	lprintf(7, "\n GICD_ICFGR10");
	sm_host_write32(0x78010c28, 0xFFFFFFFF);
	lprintf(6, "\n\t Registering GIC IRQ for RTC");
	register_irq_handler(102, sm_rtc_irq);

	if(sm_rtc_init() == 0){
		rtc_reg->MASK = 1;
		rtc_reg->IEN = 1;
		rtc_reg->WEN = 0;
		rtc_reg->CMR = rtc_reg->CCVR + sec;
		sm_rtc_show_regs();
		printf("\n Estimated time for an IRQ occurs: %d seconds", sec);
		printf("\n ... delaying for an IRQ occurs ... \n");
		MSDELAY((sec + 1) * 1000);
	}
	else{
		printf("\n\t [ERROR]: RTC initiation FAILED \n");
	}
	sm_rtc_show_regs();
	if((irq_cnt == 0) && (rtc_reg->STAT == 0) && (rtc_reg->RSTAT))
		printf("\n\n RTC IRQ MASK Test PASSED - No IRQ occurred. \n");
	else
		printf("\n\n RTC IRQ MASK Test FAILED \n");
}
void irq_mask(int argc, char *argv[]){
	u32 sec;
	if(argc != 1){
		printf("\n Syntax: irq_mask [SEC]");
		printf("\n\t where [SEC] = Number of seconds to check the counter\n");
	}else{
		sec = atoi(argv[0]);
		sm_rtc_irq_mask_test(sec);
	}
}

int sm_rtc_irq_clear_test(int sec){
	printf("\nsm_rtc_irq_clear_test");
	irq_cnt = 0;
    // Run irq handler function one time only
	lprintf(7, "\n GICD_ICFGR10");
	sm_host_write32(0x78010c28, 0xFFFFFFFF);
	lprintf(6, "\n\t Registering GIC IRQ for RTC");
	register_irq_handler(102, sm_rtc_irq);

	if(sm_rtc_init() == 0){
		rtc_reg->MASK = 0;
		rtc_reg->IEN = 1;
		rtc_reg->WEN = 1;
		rtc_reg->CMR = rtc_reg->CCVR + sec;
		sm_rtc_show_regs();
		printf("\n Estimated time for an IRQ occurs: %d seconds", sec);
		printf("\n ... delaying for an IRQ occurs ...");
		MSDELAY((sec + 1) * 1000);
		if(rtc_reg->STAT || rtc_reg->RSTAT)
			printf("\n\t [ERROR]: Clearing RTC IRQ Status Bits FAILED");
		else
			printf("\n\t Clearing RTC IRQ Status Bits PASSED");
	}
	else{
		printf("\n\t [ERROR]: RTC initiation FAILED \n");
	}
}

int sm_rtc_cnt_ena_test(void){
	if(sm_rtc_cnt_ena() == 0){
		printf("\n Counter Enabled - rtc_reg->EN = %d", rtc_reg->EN);
		printf("\n RTC_CCVR = %d", rtc_reg->CCVR);
		printf("\n ... delaying 5 seconds ...");
		MSDELAY(5000);
		printf("\n RTC_CCVR = %d \n", rtc_reg->CCVR);
	}
	if(sm_rtc_cnt_dis() == 0){
		printf("\n Counter Disabled - rtc_reg->EN = %d", rtc_reg->EN);
		printf("\n RTC_CCVR = %d \n", rtc_reg->CCVR);
		printf("\n ... delaying 5 seconds ...");
		MSDELAY(5000);
		printf("\n RTC_CCVR = %d \n", rtc_reg->CCVR);
	}
}

/*
 * WRAP Feature
 */
int sm_rtc_wrap_test(int sec){
	lprintf(6, "\nsm_rtc_wrap_test");
	if(sm_rtc_init() == 0){
		rtc_reg->WEN = 1;		// Enable WRAP feature
		if(rtc_reg->WEN){
			printf("\n RTC Wrap feature is Enable");
			printf("\n Set Wrapping Point ...");
			rtc_reg->CMR = rtc_reg->CCVR + sec;
			printf("\n RTC_CCVR = %d", rtc_reg->CCVR);
			printf("\n RTC_CMR  = %d", rtc_reg->CMR);
			printf("\n ... waiting for %d seconds ... \n", sec);
			MSDELAY((sec + 1) * 1000);	// need another cycle to reset the counter
			if(rtc_reg->CCVR == 0){
				printf("\n\t WRAP feature is working \n");
				return 0;
			}
			else{
				printf("\n\t [ERROR]: WRAP feature is NOT working");
				printf("\n RTC_CCVR = %d \n", rtc_reg->CCVR);
				return -1;
			}
		}
		else{
			printf("\n\t [ERROR]: Unable to enable WRAP feature\n");
			return -1;
		}
	}
	else{
		printf("\n\t [ERROR]: RTC initiation FAILED\n");
		return -1;
	}
}
void wrap(int argc, char *argv[]){
	u32 sec;
	if(argc != 1){
		printf("\n Syntax: wrap [SEC]");
		printf("\n\t where [SEC] = Number of seconds to wrap the counter\n");
	}else{
		sec = atoi(argv[0]);
		sm_rtc_wrap_test(sec);
	}
}

int sm_rtc_accuracy_test(int sec_chk){
	int off_sec = 0;

	printf("\nsm_rtc_accuracy_test");
	if(sm_rtc_init() == 0){
		while(off_sec == 0){
			sm_rtc_secdate(rtc_reg->CCVR);
			MSDELAY(sec_chk * 1000);	// need another cycle to reset the counter
			//if((rtc_reg->CCVR % sec_chk) != 0) ++off_sec;
		}
		printf("\n\t [ERROR]: Accuracy Test FAILED here\n");
		return -1;
	}
	else{
		printf("\n\t [ERROR]: RTC initiation FAILED\n");
		return -1;
	}
}
void acc_test(int argc, char *argv[]){
	u32 sec;
	if(argc != 1){
		printf("\n Syntax: acc_test [SEC]");
		printf("\n\t where [SEC] = Number of seconds to check the counter\n");
	}else{
		sec = atoi(argv[0]);
		sm_rtc_accuracy_test(sec);
	}
}

/*
 * Check default value of all RTC registers
 */
int sm_rtc_default_value(void){
	int rc = 0;
	int i, data, temp;
	u64 j, delay;
	u64 addr;

	printf("\nsm_rtc_default_value - START");

	if(sm_rtc_init() == 0){
		if(sm_rtc_counter_test() == 0){
			/* Checking default value */
			printf("\n Checking default value of:");
			addr = RTC_BASE__ADDR + RTC_CMR__ADDR;
			printf("\n\t RTC_CMR Register");
			rc += COMPARE_val(addr, RTC_CMR_DEFAULT);

			addr = RTC_BASE__ADDR + RTC_CLR__ADDR;
			printf("\n\t RTC_CLR Register");
			rc += COMPARE_val(addr, RTC_CLR_DEFAULT);

			addr = RTC_BASE__ADDR + RTC_CCR__ADDR;
			printf("\n\t RTC_CCR Register");
			rc += COMPARE_val(addr, RTC_CCR_DEFAULT);

			addr = RTC_BASE__ADDR + RTC_STAT__ADDR;
			printf("\n\t RTC_STAT Register");
			rc += COMPARE_val(addr, RTC_STAT_DEFAULT);

			addr = RTC_BASE__ADDR + RTC_RSTAT__ADDR;
			printf("\n\t RTC_RSTAT Register");
			rc += COMPARE_val(addr, RTC_RSTAT_DEFAULT);

			addr = RTC_BASE__ADDR + RTC_EOI__ADDR;
			printf("\n\t RTC_EOI Register");
			rc += COMPARE_val(addr, RTC_EOI_DEFAULT);

			addr = RTC_BASE__ADDR + RTC_COMP_VER__ADDR;
			printf("\n\t RTC_COMP_VER Register");
			rc += COMPARE_val(addr, RTC_COMP_VER_DEFAULT);
		}
		else{
			printf("\n [ERROR]: Counter is not working \n");
			++rc;
		}
	}
	printf("sm_rtc_default_value - START \n");
	return (rc) ? -1 : 0;
}
void chk_def(void){
	sm_rtc_default_value();
}

void to_tm(int tim, struct rtc_time * tm){
    register int    i;
    register long   hms, day;

    day = tim / SECDAY;
    hms = tim % SECDAY;

    /* Hours, minutes, seconds are easy */
    tm->tm_hour = hms / 3600;
    tm->tm_min = (hms % 3600) / 60;
    tm->tm_sec = (hms % 3600) % 60;

    /* Number of years in days */
    for (i = STARTOFTIME; day >= days_in_year(i); i++) {
         day -= days_in_year(i);
    }
    tm->tm_year = i;

    /* Number of months in days left */
    if(leapyear(tm->tm_year)){
    	days_in_month(FEBRUARY) = 29;
    }
    for(i = 1; day >= days_in_month(i); i++){
    	day -= days_in_month(i);
    }
    days_in_month(FEBRUARY) = 28;
    tm->tm_mon = i;
    /* Days are what is left over (+1) from all that. */
    tm->tm_mday = day + 1;
}
void sm_rtc_secdate(int val){
	struct rtc_time date;
	to_tm(val, &date);
	printf("\n Date: %04d-%02d-%02d %02d:%02d:%02d", date.tm_year, date.tm_mon, date.tm_mday, date.tm_hour , date.tm_min, date.tm_sec);

}
void secdate(int argc, char *argv[]){
	int sec;
	if(argc != 1){
		printf("\n Syntax: secdate [SEC]");
		printf("\n\t where [SEC] = Seconds\n");
	}else{
		sec = atoi(argv[0]);
		sm_rtc_secdate(sec);
	}
}

/* Converts Gregorian date to seconds since 1970-01-01 00:00:00.
* Assumes input in normal date format, i.e. 1980-12-31 23:59:59
* => year=1980, mon=12, day=31, hour=23, min=59, sec=59.
*
* [For the Julian calendar (which was used in Russia before 1917,
* Britain & colonies before 1752, anywhere else before 1582,
* and is still in use by some communities) leave out the
* -year/100+year/400 terms, and add 10.]
*
* This algorithm was first published by Gauss (I think).
*
* WARNING: this function will overflow on 2106-02-07 06:28:16 on
* machines were long is 32-bit! (However, as time_t is signed, we
* will already get problems at other places on 2038-01-19 03:14:08)
*/
unsigned long mktime (unsigned int year, unsigned int mon, unsigned int day, unsigned int hour, unsigned int min, unsigned int sec){
	if(0 >= (int)(mon -= 2)){ /* 1..12 -> 11,12,1..10 */
		mon += 12;         /* Puts Feb last since it has leap day */
		year -= 1;
	}
	return((((unsigned long)(year/4 - year/100 + year/400 + 367*mon/12 + day) + year*365 - 719499)*24 +
			hour)*60 +	/* now have hours */
			min)*60 +	/* now have minutes */
			sec;		/* finally seconds */
}
void datesec(int argc, char *argv[]){
	u32 yr, mo, da, ho, mn, se;
	if(argc != 6){
		printf("\n Syntax: datesec [YYYY] [MM] [DD] [HH] [MM] [SS]");
		printf("\n\t where [YYYY] = Year");
		printf("\n\t where [MO]   = Month");
		printf("\n\t where [DD]   = Day");
		printf("\n\t where [HH]   = Hour");
		printf("\n\t where [MM]   = Minute");
		printf("\n\t where [SS]   = Seconds\n");
	}else{
		yr = atoi(argv[0]);
		mo = atoi(argv[1]);
		da = atoi(argv[2]);
		ho = atoi(argv[3]);
		mn = atoi(argv[4]);
		se = atoi(argv[5]);
		printf("\n Total seconds = %d", mktime(yr, mo, da, ho, mn, se));
	}
}

int sm_rtc_datetime_test(void){
	struct rtc_time * date;
	int i;
	u32 total_sec;

	lprintf(6, "\sm_rtc_datetime_test");
	if(sm_rtc_init() == 0){
		date->tm_year = 1995;
		date->tm_mon  = 12;
		date->tm_mday = 31;
		date->tm_hour = 23;
		date->tm_min  = 59;
		date->tm_sec  = 55;
		for(i=0; i<20; ++i){
			printf("\n");
			total_sec = mktime(date->tm_year + i, date->tm_mon, date->tm_mday, date->tm_hour, date->tm_min, date->tm_sec);
			sm_rtc_load_counter(total_sec);
			sm_rtc_secdate(rtc_reg->CCVR);
			printf("\n ... delaying 10 seconds... ");
			MSDELAY(10000);
			sm_rtc_secdate(rtc_reg->CCVR);
		}
	}
	else{
		printf("\n\t [ERROR]: RTC initiation FAILED\n");
		return -1;
	}
}
void date_test(void){
	sm_rtc_datetime_test();
}

void set_date(int argc, char *argv[]){
	u32 yr, mo, da, ho, mn, se;
	if(argc != 6){
		printf("\n Syntax: datesec [YYYY] [MM] [DD] [HH] [MM] [SS]");
		printf("\n\t where [YYYY] = Year");
		printf("\n\t where [MO]   = Month");
		printf("\n\t where [DD]   = Day");
		printf("\n\t where [HH]   = Hour");
		printf("\n\t where [MM]   = Minute");
		printf("\n\t where [SS]   = Seconds\n");
	}else{
		yr = atoi(argv[0]);
		mo = atoi(argv[1]);
		da = atoi(argv[2]);
		ho = atoi(argv[3]);
		mn = atoi(argv[4]);
		se = atoi(argv[5]);
		rtc_reg->CLR = mktime(yr, mo, da, ho, mn, se);
		MSDELAY(2000);
		sm_rtc_secdate(rtc_reg->CCVR);
		
	}
}

void slt_set_and_get_date(int argc, char *argv[]){
	u32 yr, mo, da, ho, mn, se;
	if(argc != 6){
		printf("\n Syntax: datesec [YYYY] [MM] [DD] [HH] [MM] [SS]");
		printf("\n\t where [YYYY] = Year");
		printf("\n\t where [MO]   = Month");
		printf("\n\t where [DD]   = Day");
		printf("\n\t where [HH]   = Hour");
		printf("\n\t where [MM]   = Minute");
		printf("\n\t where [SS]   = Seconds\n");
	}else{
		yr = atoi(argv[0]);
		mo = atoi(argv[1]);
		da = atoi(argv[2]);
		ho = atoi(argv[3]);
		mn = atoi(argv[4]);
		se = atoi(argv[5]);
		init_rtc();
						/*MSDELAY(30000); */
		printf("\n**********************************\n");
		printf("\n Read the time in 30 seconds later\n");
		printf("\n**********************************\n");
		u32 total_sec = mktime(yr, mo, da, ho, mn, se);
		rtc_reg->CLR = total_sec;
		sm_rtc_load_counter(total_sec);
		sm_rtc_secdate(rtc_reg->CCVR);
		//arch_timer_msdelay(70000);
		arch_timer_msdelay(30000);
		sm_rtc_secdate(rtc_reg->CCVR);
		sm_rtc_show_regs();
	}
}

void get_date(void){
	sm_rtc_secdate(rtc_reg->CCVR);
}

#endif
