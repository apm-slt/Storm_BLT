/* Author: your_name@apm.com 
*  Company: Applied Micro Circuits Corporation (AMCC)
* 
* Describe the purpose of your Test here
*
*/
#include "L1_SD_4BIT_MODE_WRITE_READ_ADMA.h"


int SDIO_ADMA (u8 sdio_no,u32 capacity) {
	int sdio_status = 0;

//----- Put your code here -------

//	printf("\n############################################################\n");
//	printf("## Start    %-40s %8s",__FUNCTION__,"##\n");
//	printf("############################################################\n");

	printf ("$$$$ TEST ADMA PORT %u $$$$\n", sdio_no);
    SDIO_soft_reset();
    sdio_status = sdio_adma(sdio_no,capacity);
   //--------------------------------
	if (sdio_status == 0)
	{
    	printf("\n\n");
    	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
    	printf ("$$$$ RESULT: TEST PASS $$$$\n");
    	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
    	printf("\n\n");
	}
	else
	{
    	printf("\n\n");
    	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
    	printf ("$$$$ RESULT: TEST FAILED $$$$\n");
    	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
    	printf("\n\n");
	}
	return 0;
}

//int SDIO_ADMA2 (void) {
//	int sdio_status0 = 0;
//	int sdio_status1 = 0;
//
////----- Put your code here -------
//
//	printf("\n############################################################\n");
//	printf("## Start    %-40s %8s",__FUNCTION__,"##\n");
//	printf("############################################################\n");
//
////	printf ("$$$$ TEST SDIO PORT 0 $$$$\n");
////    SDIO_soft_reset();
////    sdio_status0 = sdio_adma(1);
//    SDIO_soft_reset();
//    printf ("$$$$ TEST SDIO PORT 1 $$$$\n");
//    sdio_status1 = sdio_adma(2);
//   //--------------------------------
//	if ((sdio_status0 == 0)&&(sdio_status1 == 0))
//	{
//    	printf("\n\n");
//    	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
//    	printf ("$$$$ RESULT: TEST PASS $$$$\n");
//    	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
//    	printf("\n\n");
//	}
//	else
//	{
//    	printf("\n\n");
//    	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
//    	printf ("$$$$ RESULT: TEST FAILED $$$$\n");
//    	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
//    	printf("\n\n");
//	}
//	return 0;
//}
//

