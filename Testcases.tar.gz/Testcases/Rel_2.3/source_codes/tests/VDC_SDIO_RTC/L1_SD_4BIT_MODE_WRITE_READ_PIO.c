/* Author: your_name@apm.com 
*  Company: Applied Micro Circuits Corporation (AMCC)
* 
* Describe the purpose of your Test here
*
*/
#include "L1_SD_4BIT_MODE_WRITE_READ_PIO.h"


int SDIO_PIO (u8 sdio_no,u32 capacity) {
	int sdio_status0 = 0;
	int sdio_status1 = 0;
	
//----- Put your code here -------

	printf("\n############################################################\n");
	printf("## Start    %-40s %8s",__FUNCTION__,"##\n");
	printf("############################################################\n");
	printf ("$$$$ TEST PIO PORT %u $$$$\n", sdio_no);
    SDIO_soft_reset();
	sdio_status0 = sdio_pio(sdio_no,capacity);
//    SDIO_soft_reset();
//	printf ("$$$$ TEST PIO PORT 1 $$$$\n");
//	sdio_status1 = sdio_pio(2);
//--------------------------------
	if ((sdio_status0 == 0)&&(sdio_status1 == 0))
	{
    	printf("\n\n");
    	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
    	printf ("$$$$ RESULT: TEST PASS $$$$\n");
    	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
    	printf("\n\n");
    	return 0;
	}
	else
	{
    	printf("\n\n");
    	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
    	printf ("$$$$ RESULT: TEST FAILED $$$$\n");
    	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
    	printf("\n\n");
    	return 1;
	}

}

