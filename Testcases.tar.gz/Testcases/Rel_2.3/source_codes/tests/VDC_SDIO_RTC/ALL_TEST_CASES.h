/*
 * ALL_TEST_CASES.h
 *
 *  Created on: May 22, 2014
 *      Author: lxpham
 */

#ifndef ALL_TEST_CASES_H_
#define ALL_TEST_CASES_H_


#include <stdio.h>
#include <string.h>
#include <common.h>
//Tinh-BLT
#include <../../VDC_SDIO_RTC/include/common.h>

#include <../../VDC_SDIO_RTC/include/vSDIO_regs.h>
#include <../../VDC_SDIO_RTC/include/vSDIO_defines.h>
#include <../../VDC_SDIO_RTC/include/vSDIO_macros.h>

#include <../../VDC_SDIO_RTC/include/ipp_libc.h>
#include <../../VDC_SDIO_RTC/include/ipp_vfatdev_sdio.h>
#include <../../VDC_SDIO_RTC/include/ipp_vfatdev.h>
#include <../../VDC_SDIO_RTC/include/ipp_bootdev.h>
#include <../../VDC_SDIO_RTC/include/ipp_hardware.h>
//End of Tinh-BLT
#endif /* ALL_TEST_CASES_H_ */
