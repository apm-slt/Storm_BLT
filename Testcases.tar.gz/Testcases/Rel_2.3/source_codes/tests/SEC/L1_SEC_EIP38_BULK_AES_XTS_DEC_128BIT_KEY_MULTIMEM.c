/* Author: ldinh@apm.com
*  Company: Applied Micro Circuits Corporation (AMCC)
* 
* Describe the purpose of your Test here
*
*/
#include "L1_SEC_EIP38_BULK_AES_XTS_DEC_128BIT_KEY_MULTIMEM.h"
//Tinh-SLT
//function call
#define printPASS printPASS_slt_sec
#define printFAIL printFAIL_slt_sec
#define qm_enable qm_enable_slt_sec
#define load_mem load_mem_slt_sec
#define dump_mem dump_mem_slt_sec
//End of Tinh-SLT

extern unsigned long long enq_ptr[MAX_NO_OF_QUEUE];
extern unsigned long long deq_ptr[MAX_NO_OF_QUEUE];

void config_xts_dec_128b_key_multimem(void)
{
	debug_sec("\n *** Start config. SEC CSR for xts_dec_128b_key_multimem test case ***\n");
	// Enable XTS AXI domain logic to process message from QMI
	WR_MEM32(SM_SEC_XTS_AXI_CSR_CSR_SEC_CFG_REG, 0x80000000); //Set bit go

	//Set token read offset size and prefetch size
	WR_MEM32(SM_SEC_XTS_CRYPTO_CSR_CSR_SEC_CRYPTO_CFG_0_REG, 0x44000000);

	//Configure XTS core
	//Stop XTS if error
	WR_MEM32(SM_SEC_XTS_CORE_CSR_CSR_XTS_CONFIGURATION_REG, 0x4);

	debug_sec("*** End config. SEC CSR for xts_dec_128b_key_multimem test case ***\n");
}

void load_mem_xts_dec_128b_key_multimem(buf_header_queue *expt_buf_queue_ptr, buf_header_queue *expt_tkn_queue_ptr,
      unsigned long long* in_tkn_ptr, unsigned long long* in_data_ptr,
      unsigned int* in_data_len, unsigned char* in_data_buf_num,
      unsigned int* out_data_len, unsigned char* out_data_buf_num)
{
	unsigned long long mem_addr;
	int i;

	buf_header expt_buf_header;
	mem_array_header* current_array_header;
	int no_of_array = 0;

	mem_array_header in_tkn_array_header[MAX_MEM_BUF];
	mem_array_header in_ctx_array_header[MAX_MEM_BUF];
	mem_array_header in_data_array_header[MAX_MEM_BUF];
	mem_array_header exp_tkn_array_header[MAX_MEM_BUF];
	mem_array_header exp_data_array_header[MAX_MEM_BUF];

	mem_array_header_queue in_tkn_array_header_queue = {0, 0, 0, 0};
	mem_array_header_queue in_ctx_array_header_queue = {0, 0, 0, 0};
	mem_array_header_queue in_data_array_header_queue = {0, 0, 0, 0};
	mem_array_header_queue exp_tkn_array_header_queue = {0, 0, 0, 0};
	mem_array_header_queue exp_data_array_header_queue = {0, 0, 0, 0};

	//1. Data array initialization
	//1.1 Input
	unsigned int in_tkn_0 [7] = {
		0x00008500, 0x84000000, 0x00000040, 0x41f992ed, 0x70d7a0f9, 0x4590d3ec, 0xf49652e1
	};

	unsigned int in_tkn_1 [7] = {
		0x00008500, 0x84000000, 0x00000040, 0x41f992ed, 0x70d7a0f9, 0x4590d3ec, 0xf49652e1
	};

	unsigned int in_tkn_2 [7] = {
		0x00008500, 0x84000000, 0x00000040, 0x41f992ed, 0x70d7a0f9, 0x4590d3ec, 0xf49652e1
	};

	unsigned int in_tkn_3 [7] = {
		0x00008500, 0x84000000, 0x00000040, 0x41f992ed, 0x70d7a0f9, 0x4590d3ec, 0xf49652e1
	};

	unsigned int in_tkn_4 [7] = {
		0x00008500, 0x84000000, 0x00000040, 0x41f992ed, 0x70d7a0f9, 0x4590d3ec, 0xf49652e1
	};

	unsigned int in_ctx_0 [8] = {
		0x12c3f2a2, 0x99daa277, 0x9098ada6, 0x01bd7c1c, 0x46b13aab, 0xb52b6efe, 0x28e49324, 0x49432510
	};

	unsigned int in_ctx_1 [8] = {
		0x12c3f2a2, 0x99daa277, 0x9098ada6, 0x01bd7c1c, 0x46b13aab, 0xb52b6efe, 0x28e49324, 0x49432510
	};

	unsigned int in_ctx_2 [8] = {
		0x12c3f2a2, 0x99daa277, 0x9098ada6, 0x01bd7c1c, 0x46b13aab, 0xb52b6efe, 0x28e49324, 0x49432510
	};

	unsigned int in_ctx_3 [8] = {
		0x12c3f2a2, 0x99daa277, 0x9098ada6, 0x01bd7c1c, 0x46b13aab, 0xb52b6efe, 0x28e49324, 0x49432510
	};

	unsigned int in_ctx_4 [8] = {
		0x12c3f2a2, 0x99daa277, 0x9098ada6, 0x01bd7c1c, 0x46b13aab, 0xb52b6efe, 0x28e49324, 0x49432510
	};


	unsigned int in_data_0 [16] = {
		0x0d18a473, 0x840b6d05, 0x8448cf7b, 0xf2fdad7e, 0x05b9b14a, 0xe9563adc, 0x234f273b, 0x8fcd09cf,
		0x3e5db337, 0x5efe1fa4, 0x5d06948b, 0xfeb0331b, 0xd3b374bc, 0x296fb80a, 0x390b0e83, 0x8b5953ad
	};

	unsigned int in_data_1 [16] = {
		0x0d18a473, 0x840b6d05, 0x8448cf7b, 0xf2fdad7e, 0x05b9b14a, 0xe9563adc, 0x234f273b, 0x8fcd09cf,
		0x3e5db337, 0x5efe1fa4, 0x5d06948b, 0xfeb0331b, 0xd3b374bc, 0x296fb80a, 0x390b0e83, 0x8b5953ad
	};

	unsigned int in_data_2 [16] = {
		0x0d18a473, 0x840b6d05, 0x8448cf7b, 0xf2fdad7e, 0x05b9b14a, 0xe9563adc, 0x234f273b, 0x8fcd09cf,
		0x3e5db337, 0x5efe1fa4, 0x5d06948b, 0xfeb0331b, 0xd3b374bc, 0x296fb80a, 0x390b0e83, 0x8b5953ad
	};

	unsigned int in_data_3 [16] = {
		0x0d18a473, 0x840b6d05, 0x8448cf7b, 0xf2fdad7e, 0x05b9b14a, 0xe9563adc, 0x234f273b, 0x8fcd09cf,
		0x3e5db337, 0x5efe1fa4, 0x5d06948b, 0xfeb0331b, 0xd3b374bc, 0x296fb80a, 0x390b0e83, 0x8b5953ad
	};

	unsigned int in_data_4 [16] = {
		0x0d18a473, 0x840b6d05, 0x8448cf7b, 0xf2fdad7e, 0x05b9b14a, 0xe9563adc, 0x234f273b, 0x8fcd09cf,
		0x3e5db337, 0x5efe1fa4, 0x5d06948b, 0xfeb0331b, 0xd3b374bc, 0x296fb80a, 0x390b0e83, 0x8b5953ad
	};


	//1.2 Expected
	unsigned int exp_tkn_0 [2] = {
		0x00000040, 0x00000000
	};
	unsigned int exp_tkn_1 [2] = {
		0x00000040, 0x00000000
	};
	unsigned int exp_tkn_2 [2] = {
		0x00000040, 0x00000000
	};
	unsigned int exp_tkn_3 [2] = {
		0x00000040, 0x00000000
	};
	unsigned int exp_tkn_4 [2] = {
		0x00000040, 0x00000000
	};

	unsigned int exp_data_0[16] = {
		0xf1c51be2, 0x555bbce7, 0x5dfa74d7, 0x9aebc804, 0xab496ce5, 0x64f2366b, 0x7302fe97, 0x377dcc00,
		0xf173cf0b, 0x419d9eb5, 0xac0e8ee8, 0xcfafef46, 0xb9897640, 0x47f2e21f, 0xe0e9a8f6, 0xa58169f2
	};

	unsigned int exp_data_1[16] = {
		0xf1c51be2, 0x555bbce7, 0x5dfa74d7, 0x9aebc804, 0xab496ce5, 0x64f2366b, 0x7302fe97, 0x377dcc00,
		0xf173cf0b, 0x419d9eb5, 0xac0e8ee8, 0xcfafef46, 0xb9897640, 0x47f2e21f, 0xe0e9a8f6, 0xa58169f2
	};

	unsigned int exp_data_2[16] = {
		0xf1c51be2, 0x555bbce7, 0x5dfa74d7, 0x9aebc804, 0xab496ce5, 0x64f2366b, 0x7302fe97, 0x377dcc00,
		0xf173cf0b, 0x419d9eb5, 0xac0e8ee8, 0xcfafef46, 0xb9897640, 0x47f2e21f, 0xe0e9a8f6, 0xa58169f2
	};

	unsigned int exp_data_3[16] = {
		0xf1c51be2, 0x555bbce7, 0x5dfa74d7, 0x9aebc804, 0xab496ce5, 0x64f2366b, 0x7302fe97, 0x377dcc00,
		0xf173cf0b, 0x419d9eb5, 0xac0e8ee8, 0xcfafef46, 0xb9897640, 0x47f2e21f, 0xe0e9a8f6, 0xa58169f2
	};

	unsigned int exp_data_4[16] = {
		0xf1c51be2, 0x555bbce7, 0x5dfa74d7, 0x9aebc804, 0xab496ce5, 0x64f2366b, 0x7302fe97, 0x377dcc00,
		0xf173cf0b, 0x419d9eb5, 0xac0e8ee8, 0xcfafef46, 0xb9897640, 0x47f2e21f, 0xe0e9a8f6, 0xa58169f2
	};


	//2. Pointer assignment (un-changed code)
	in_tkn_array_header_queue.mem_array_header_ptr = in_tkn_array_header;
	in_ctx_array_header_queue.mem_array_header_ptr = in_ctx_array_header;
	in_data_array_header_queue.mem_array_header_ptr = in_data_array_header;
	exp_tkn_array_header_queue.mem_array_header_ptr = exp_tkn_array_header;
	exp_data_array_header_queue.mem_array_header_ptr = exp_data_array_header;

	//3. Record length and pointer to memory array
	write_mem_array_header(&in_tkn_array_header_queue, in_tkn_0, 28);
	write_mem_array_header(&in_tkn_array_header_queue, in_tkn_1, 28);
	write_mem_array_header(&in_tkn_array_header_queue, in_tkn_2, 28);
	write_mem_array_header(&in_tkn_array_header_queue, in_tkn_3, 28);
	write_mem_array_header(&in_tkn_array_header_queue, in_tkn_4, 28);

	write_mem_array_header(&in_ctx_array_header_queue, in_ctx_0, 32);
	write_mem_array_header(&in_ctx_array_header_queue, in_ctx_1, 32);
	write_mem_array_header(&in_ctx_array_header_queue, in_ctx_2, 32);
	write_mem_array_header(&in_ctx_array_header_queue, in_ctx_3, 32);
	write_mem_array_header(&in_ctx_array_header_queue, in_ctx_4, 32);

	write_mem_array_header(&in_data_array_header_queue, in_data_0, 64);
	write_mem_array_header(&in_data_array_header_queue, in_data_1, 64);
	write_mem_array_header(&in_data_array_header_queue, in_data_2, 64);
	write_mem_array_header(&in_data_array_header_queue, in_data_3, 64);
	write_mem_array_header(&in_data_array_header_queue, in_data_4, 64);


	for (i = 0; i < 5; i++) {
		in_data_buf_num[i] = 1;
		in_data_len[i] = 0x100;
	}

	//1.2 Expected
	write_mem_array_header(&exp_tkn_array_header_queue, exp_tkn_0, 8);
	write_mem_array_header(&exp_tkn_array_header_queue, exp_tkn_1, 8);
	write_mem_array_header(&exp_tkn_array_header_queue, exp_tkn_2, 8);
	write_mem_array_header(&exp_tkn_array_header_queue, exp_tkn_3, 8);
	write_mem_array_header(&exp_tkn_array_header_queue, exp_tkn_4, 8);


	write_mem_array_header(&exp_data_array_header_queue, exp_data_0, 64);
	write_mem_array_header(&exp_data_array_header_queue, exp_data_1, 64);
	write_mem_array_header(&exp_data_array_header_queue, exp_data_2, 64);
	write_mem_array_header(&exp_data_array_header_queue, exp_data_3, 64);
	write_mem_array_header(&exp_data_array_header_queue, exp_data_4, 64);

	for (i = 0; i < 5; i++) {
		out_data_buf_num[i] = 1;
		out_data_len[i] = 0x100;
	}

	// Load token, context, input data
	//
	debug_sec("\n *** Start loading context ***\n");

	no_of_array = in_ctx_array_header_queue.no_of_entry;

	for (i = 0; i < no_of_array; i++)
	{
		mem_addr = alot_mem(in_ctx_mem_manager_ptr, in_ctx_array_header[i].mem_len, A_32BYTE);
		load_mem(mem_addr, in_ctx_array_header[i].mem_len, in_ctx_array_header[i].mem_array_ptr);
		dump_mem(mem_addr, in_ctx_array_header[i].mem_len);
		//This code is to adjust context pointer in input token
		(in_tkn_array_header[i].mem_array_ptr)[0] = (in_tkn_array_header[i].mem_array_ptr)[0] & 0xFF807FFF; // Clear bit 22:15
		(in_tkn_array_header[i].mem_array_ptr)[0] =
				(in_tkn_array_header[i].mem_array_ptr)[0] | ((unsigned int)((mem_addr >> 21) & 0x007f8000));
		(in_tkn_array_header[i].mem_array_ptr)[1] = (unsigned int)((mem_addr >> 4)&0xffffffff);
	}

	debug_sec(" *** End loading context ***\n");

	debug_sec("\n *** Start loading token ***\n");

	// Input token
	no_of_array = in_tkn_array_header_queue.no_of_entry;
	for (i = 0; i < no_of_array; i++)
	{
		mem_addr = alot_mem(in_tkn_mem_manager_ptr, in_tkn_array_header[i].mem_len+0x10, A_16BYTE);
		load_mem(mem_addr+0x10, in_tkn_array_header[i].mem_len, in_tkn_array_header[i].mem_array_ptr);
		dump_mem(mem_addr+0x10, in_tkn_array_header[i].mem_len);
		in_tkn_ptr[i] = mem_addr; // Save this for building packet
	}

	//Expected token
	no_of_array = exp_tkn_array_header_queue.no_of_entry;
	for (i = 0; i < no_of_array; i++)
	{
		mem_addr = alot_mem(exp_tkn_mem_manager_ptr, exp_tkn_array_header[i].mem_len, A_4BYTE);
		load_mem(mem_addr, exp_tkn_array_header[i].mem_len, exp_tkn_array_header[i].mem_array_ptr);
		expt_buf_header.field.BufDataLength = exp_tkn_array_header[i].mem_len;
		expt_buf_header.field.BufDataAddr = mem_addr;
		write_buf_header(expt_tkn_queue_ptr, expt_buf_header, MAX_WK_MSG);
	}
	debug_sec(" *** End loading token ***\n");

	debug_sec("\n *** Start loading input data ***\n");
	no_of_array = in_data_array_header_queue.no_of_entry;

	for(i = 0; i < no_of_array; i++)
	{
		mem_addr = alot_mem(in_data_mem_manager_ptr, in_data_array_header[i].mem_len, A_BYTE);
		load_mem(mem_addr, in_data_array_header[i].mem_len, in_data_array_header[i].mem_array_ptr);
		in_data_ptr[i] = mem_addr; //Save this for building packet
		in_data_len[i] = in_data_array_header[i].mem_len; // Save this for building packet
	}
	debug_sec(" *** End loading input data ***\n");

	debug_sec("\n *** Start loading expected output data ***\n");
	no_of_array = exp_data_array_header_queue.no_of_entry;
	for(i = 0; i < no_of_array; i++)
	{
		mem_addr = alot_mem(exp_data_mem_manager_ptr, exp_data_array_header[i].mem_len, A_BYTE);
		load_mem(mem_addr, exp_data_array_header[i].mem_len, exp_data_array_header[i].mem_array_ptr);
		expt_buf_header.field.BufDataLength = exp_data_array_header[i].mem_len;
		expt_buf_header.field.BufDataAddr =   mem_addr;
		write_buf_header(expt_buf_queue_ptr, expt_buf_header, MAX_MEM_BUF);
		out_data_len[i] = exp_data_array_header[i].mem_len; //Save this to build up message
	}
	debug_sec(" *** End loading expected output data ***\n");
}

int build_msg_xts_dec_128b_key_multimem(enq_msg_header_queue *wq_msg_header_queue_ptr, enq_msg_header_queue* fp_msg_header_queue_ptr,
      unsigned long long* in_tkn_ptr, unsigned long long* in_data_buf_ptr, unsigned int* in_data_len, unsigned char*in_data_buf_num,
      unsigned int* out_data_len, unsigned char* out_data_buf_num)
{
	int i, j;
	int num_of_msg = 0;
	int user_info, wqid, fpqid, hfpsel;
	unsigned char num_of_buf;
	unsigned char cur_in_buf, cur_out_buf;
	unsigned long long dat_out_ptr;

	cur_in_buf = 0;
	cur_out_buf = 0;
	user_info = gen_sec_user_info(XTS_CORE_TYPE);
	wqid = get_sec_wqid(XTS_CORE_TYPE);

	fpqid = FPQID9;
	hfpsel = 0;

	debug_sec(" *** Start preparing message for xts_dec_128b_key_multimem test case ***\n");
	for (i = 0; i < 5; i++)
	{
		// Prepare FP to store output data
		num_of_buf = out_data_buf_num[i];

		for (j = 0; j < num_of_buf; j++)
		{
			if(j == 5) // Need to a free pool to store linked list at completion message
			{
				dat_out_ptr = alot_mem(out_data_mem_manager_ptr, (num_of_buf - 4)*8, A_BYTE);
				build_sec_16b_fp_msg (fpqid, out_data_len[cur_out_buf], dat_out_ptr,
				user_info++, fp_msg_header_queue_ptr);
			}

			dat_out_ptr = alot_mem(out_data_mem_manager_ptr, out_data_len[cur_out_buf], A_BYTE);
			build_sec_16b_fp_msg (fpqid, out_data_len[cur_out_buf], dat_out_ptr,
			user_info++, fp_msg_header_queue_ptr);
			cur_out_buf++;
		}

		// Prepare work message
		num_of_buf = in_data_buf_num[i];
		if (num_of_buf > 5)
		{
			debug_sec("ERROR: SEC driver has not supported this mode, please manual build message and linked list\n");
		}
		else if (num_of_buf > 1)
		{
			build_sec_64b_src2buf_wq_msg(wqid, fpqid, WQID0, hfpsel,
										(num_of_buf - 1),
										in_data_len[cur_in_buf],   in_data_buf_ptr[cur_in_buf],
										in_data_len[cur_in_buf+1], in_data_buf_ptr[cur_in_buf+1],
										in_data_len[cur_in_buf+2], in_data_buf_ptr[cur_in_buf+2],
										in_data_len[cur_in_buf+3], in_data_buf_ptr[cur_in_buf+3],
										in_data_len[cur_in_buf+4], in_data_buf_ptr[cur_in_buf+4],
										(in_tkn_ptr[i]), user_info++, wq_msg_header_queue_ptr);
		}
		else if (num_of_buf == 1)
		{
			build_sec_32b_src2buf_wq_msg(wqid, fpqid, WQID0, hfpsel,
									in_data_len[cur_in_buf], in_data_buf_ptr[cur_in_buf],
									in_tkn_ptr[i], user_info++, wq_msg_header_queue_ptr);
		}
		else
		{
			debug_sec("ERROR: Number of buffer is zero");
		}
		cur_in_buf += num_of_buf;
		num_of_msg++;
	}
	// Note, in this test case don't need FP message so fp_msg_header_queue_ptr is not used
	debug_sec(" *** End preparing message for xts_dec_128b_key_multimem test case *** \n\r");
	return num_of_msg;
}

int test_xts_dec_128bit_key_multimem (enq_msg_header_queue *wq_msg_header_queue_ptr, enq_msg_header_queue* fp_msg_header_queue_ptr,
							buf_header_queue *expt_buf_queue_ptr, buf_header_queue *expt_tkn_queue_ptr)
{
	int num_of_msg;
	unsigned long long in_tkn_addr[MAX_MEM_BUF/2];
	unsigned long long in_data_addr[MAX_MEM_BUF];
	unsigned int in_data_len[MAX_MEM_BUF];
	unsigned char in_data_buf_num[MAX_MEM_BUF/2];
	unsigned int out_data_len[MAX_MEM_BUF];
	unsigned char out_data_buf_num[MAX_MEM_BUF/2];

	config_xts_dec_128b_key_multimem();
	load_mem_xts_dec_128b_key_multimem(expt_buf_queue_ptr, expt_tkn_queue_ptr, in_tkn_addr,
							in_data_addr, in_data_len, in_data_buf_num,
							out_data_len, out_data_buf_num);

	num_of_msg = build_msg_xts_dec_128b_key_multimem(wq_msg_header_queue_ptr, fp_msg_header_queue_ptr,
										in_tkn_addr, in_data_addr, in_data_len, in_data_buf_num,
										out_data_len, out_data_buf_num);
	return num_of_msg;
}

int EIP38_BULK_AES_XTS_DEC_128BIT_KEY_MULTIMEM (void) {
	int error = 0;

	//----- Put your code here -------
	int i, no_of_entry, no_of_cm_msg, num_of_msg;
	enq_msg_header* msg_header_ptr;

	static queue_mem_manager in_tkn_mem_manager;
	static queue_mem_manager in_ctx_mem_manager;
	static queue_mem_manager in_data_mem_manager;
	static queue_mem_manager out_data_mem_manager;
	static queue_mem_manager exp_tkn_mem_manager;
	static queue_mem_manager exp_data_mem_manager;

	static enq_msg_header wq_msg_header_array[MAX_WK_MSG];
	static enq_msg_header fp_msg_header_array[MAX_FP_MSG];

	static buf_header expt_buf_header_array[MAX_MEM_BUF];
	static buf_header expt_tkn_header_array[MAX_WK_MSG];
	static buf_header expt_deallot_header_array[MAX_FP_MSG];
	static buf_header expt_cm_header_array[MAX_WK_MSG];

	init_ocm();
	qm_disable();
	init_qm();
	init_queue_ptr();
	qm_enable();
	init_sec(); //Common SEC settings for all test case

	in_tkn_mem_manager_ptr   = &in_tkn_mem_manager;
	in_ctx_mem_manager_ptr   = &in_ctx_mem_manager;
	in_data_mem_manager_ptr  = &in_data_mem_manager;
	out_data_mem_manager_ptr = &out_data_mem_manager;
	exp_tkn_mem_manager_ptr  = &exp_tkn_mem_manager;
	exp_data_mem_manager_ptr = &exp_data_mem_manager;

	init_queue_mem_manager(in_tkn_mem_manager_ptr, MEM_BASE_ADDR+SEC_TEST_OFST+SEC_TKN_OFST, SEC_TKN_MEM_LEN);
	init_queue_mem_manager(in_ctx_mem_manager_ptr, MEM_BASE_ADDR+SEC_TEST_OFST+SEC_CTX_OFST, SEC_CTX_MEM_LEN);
	init_queue_mem_manager(in_data_mem_manager_ptr, MEM_BASE_ADDR+SEC_TEST_OFST+SEC_DAT_IN_OFST, SEC_DAT_IN_MEM_LEN);
	init_queue_mem_manager(out_data_mem_manager_ptr, MEM_BASE_ADDR+SEC_TEST_OFST+SEC_DAT_OUT_OFST, SEC_DAT_OUT_MEM_LEN);
	init_queue_mem_manager(exp_tkn_mem_manager_ptr, MEM_BASE_ADDR+SEC_TEST_OFST+SEC_EXP_RTKN_OFST, SEC_EXP_RTKN_MEM_LEN);
	init_queue_mem_manager(exp_data_mem_manager_ptr, MEM_BASE_ADDR+SEC_TEST_OFST+SEC_EXP_DAT_OUT_OFST, SEC_EXP_DAT_OUT_MEM_LEN);

	for (i = 0; i < MAX_WK_MSG; i++) {
		wq_msg_header_array[i].msg_type = 0;
		wq_msg_header_array[i].num_of_buf = 0;
		wq_msg_header_array[i].qid = 0;
		expt_tkn_header_array[i].field.BufDataAddr = 0;
		expt_tkn_header_array[i].field.BufDataLength = 0;
		expt_tkn_header_array[i].field.Reserved0 = 0;
		expt_tkn_header_array[i].field.Reserved1 = 0;
		expt_tkn_header_array[i].raw[0] = 0;
		expt_tkn_header_array[i].raw[1] = 0;
		expt_cm_header_array[i].field.BufDataAddr = 0;
		expt_cm_header_array[i].field.BufDataLength = 0;
		expt_cm_header_array[i].field.Reserved0 = 0;
		expt_cm_header_array[i].field.Reserved1 = 0;
		expt_cm_header_array[i].raw[0] = 0;
		expt_cm_header_array[i].raw[1] = 0;
	}

	for (i = 0; i < MAX_FP_MSG; i++) {
		fp_msg_header_array[i].msg_type = 0;
		fp_msg_header_array[i].num_of_buf = 0;
		fp_msg_header_array[i].qid = 0;
		expt_deallot_header_array[i].field.BufDataAddr = 0;
		expt_deallot_header_array[i].field.BufDataLength = 0;
		expt_deallot_header_array[i].field.Reserved0 = 0;
		expt_deallot_header_array[i].field.Reserved1 = 0;
		expt_deallot_header_array[i].raw[0] = 0;
		expt_deallot_header_array[i].raw[1] = 0;
	}

	for (i = 0; i < MAX_MEM_BUF; i++) {
		expt_buf_header_array[i].field.BufDataAddr = 0;
		expt_buf_header_array[i].field.BufDataLength = 0;
		expt_buf_header_array[i].field.Reserved0 = 0;
		expt_buf_header_array[i].field.Reserved1 = 0;
		expt_buf_header_array[i].raw[0] = 0;
		expt_buf_header_array[i].raw[1] = 0;
	}

	enq_msg_header_queue wq_msg_header_queue	= {0, 0, 0, 0};
	enq_msg_header_queue fp_msg_header_queue	= {0, 0, 0, 0};

	buf_header_queue expt_buf_header_queue		= {0, 0, 0, 0};
	buf_header_queue expt_tkn_header_queue		= {0, 0, 0, 0};
	buf_header_queue expt_deallot_header_queue	= {0, 0, 0, 0};
	buf_header_queue expt_cm_header_queue		= {0, 0, 0, 0};

	wq_msg_header_queue.enq_msg_header_ptr = wq_msg_header_array;
	fp_msg_header_queue.enq_msg_header_ptr = fp_msg_header_array;

	expt_buf_header_queue.buf_header_ptr = expt_buf_header_array;
	expt_tkn_header_queue.buf_header_ptr = expt_tkn_header_array;
	expt_deallot_header_queue.buf_header_ptr = expt_deallot_header_array;
	expt_cm_header_queue.buf_header_ptr = expt_cm_header_array;

	num_of_msg = test_xts_dec_128bit_key_multimem(&wq_msg_header_queue, &fp_msg_header_queue, &expt_buf_header_queue, &expt_tkn_header_queue);
	debug_sec("\nnum_of_msg = 0x%08x\n", num_of_msg);

	debug_sec("Start message transfer.....\n");
	data_cache_flush_all();

	// Enqueue FP message if any
	no_of_entry = fp_msg_header_queue.no_of_entry;

	debug_sec("\nfp_msg_header_queue.no_of_entry = 0x%08x\n", no_of_entry);
	for (i = 0; i < no_of_entry; i++)
	{
		msg_header_ptr = read_enq_msg_header(&fp_msg_header_queue, MAX_FP_MSG);
		alternate_enqueue((*msg_header_ptr).qid, 1); //Inform QM to start loading message and sending to DUT IP
	}

	// Enqueue work message
	no_of_entry = wq_msg_header_queue.no_of_entry;
	debug_sec("\nwq_msg_header_queue.no_of_entry = 0x%08x\n", no_of_entry);
	for (i = 0; i < no_of_entry; i++)
	{
		msg_header_ptr = read_enq_msg_header(&wq_msg_header_queue, MAX_WK_MSG);
		if ((*msg_header_ptr).msg_type == 0)
		{
			alternate_enqueue((*msg_header_ptr).qid, 1); // Inform QM to start loading message
		}
		else
		{
			alternate_enqueue((*msg_header_ptr).qid, 2);
		}
	}

	debug_sec("\nStart pooling completion message\n");

	for (no_of_cm_msg = 1; no_of_cm_msg <= num_of_msg; no_of_cm_msg++)
	{
		poll_cm_msg(); //Pool completion message returned from DUT IP
		debug_sec("Received 0x%08x completion messages\n", no_of_cm_msg);
		error += chk_result(&expt_buf_header_queue, &expt_tkn_header_queue,
				&expt_deallot_header_queue, &expt_cm_header_queue, WQID0, 0);

		debug_sec("\n *** Number of errors = 0x%08x\n", error);
		debug_sec("Finished checking result for message 0x%08x\n", no_of_cm_msg);
	}

	if (read_qm_ne_sts() != 0)
	{
		debug_sec("\nqm_ne_sts = 0x%08x\n", read_qm_ne_sts());
		debug_sec("\n *** ERROR: Number of completion message is over number of work messages *** \n");
		error++;
	}

	debug_sec("\n *** Total number of errors = 0x%08x ***\n", error);


	//--------------------------------
	if (error == 0)
	{
		printPASS();
		return 0;
	}
	else
	{
		printFAIL();
		return 1;
	}


}

