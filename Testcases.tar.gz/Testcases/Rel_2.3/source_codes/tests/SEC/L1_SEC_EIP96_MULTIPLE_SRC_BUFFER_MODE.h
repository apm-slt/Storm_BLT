/* Author: ldinh@apm.com
*  Company: Applied Micro Circuits Corporation (AMCC)
* 
* Describe the purpose of your Test here
*
*/
#ifndef __L1_SEC_EIP96_MULTIPLE_SRC_BUFFER_MODE_H__
#define __L1_SEC_EIP96_MULTIPLE_SRC_BUFFER_MODE_H__

//Tinh-SLT: change full path to include all the header file
#include "../../SEC/include/vSEC_defines.h"
//#include "../include/vSEC_defines.h"

#include <types.h>
#include <stdio.h>
#include <armv8.h>
#include <cpu.h>
#include <common.h>
#include <delay.h>

//Tinh-SLT: change full path to include all the header files
#include "../../SEC/include/common.h"
#include "../../SEC/include/vSEC_regs.h"
#include "../../SEC/include/vSEC_macros.h"

#include "../../SEC/include/vSEC_globals.h"
#include "../../SEC/include/vSEC_mem_manager.h"
#include "../../SEC/include/vSEC_ocm_driver.h"
#include "../../SEC/include/vSEC_qm_driver.h"
#include "../../SEC/include/vSEC_test_driver.h"
#include "../../SEC/include/sec_driver.h"
#include "../../SEC/include/sec_dat_struct.h"
#include "../../SEC/include/sec_dbg.h"
#include "../../SEC/include/sec_test.h"
//End of Tinh-SLT

int EIP96_MULTIPLE_SRC_BUFFER_MODE(void);

#endif /*__L1_SEC_EIP96_MULTIPLE_SRC_BUFFER_MODE_H__*/
