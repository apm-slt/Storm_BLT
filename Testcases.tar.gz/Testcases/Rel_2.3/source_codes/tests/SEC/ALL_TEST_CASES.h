/*
 * ALL_TEST_CASES.h
 *
 *  Created on: May 28, 2014
 *      Author: ldinh
 */

#ifndef ALL_TEST_CASES_H_
#define ALL_TEST_CASES_H_

#include "L1_SEC_EIP96_MULTIPLE_SRC_BUFFER_MODE.h"
#include "L1_SEC_EIP38_BULK_AES_XTS_DEC_128BIT_KEY_MULTIMEM.h"

#endif /* ALL_TEST_CASES_H_ */
