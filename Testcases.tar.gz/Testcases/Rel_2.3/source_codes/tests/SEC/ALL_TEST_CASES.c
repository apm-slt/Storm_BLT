/*
 * ALL_TEST_CASES.c
 *
 *  Created on: May 28, 2014
 *      Author: ldinh
 */

#include "ALL_TEST_CASES.h"

//Tinh-SLT
//function call
#define printPASS printPASS_slt_sec
#define printFAIL printFAIL_slt_sec
#define qm_enable qm_enable_slt_sec
//End of Tinh-SLT

#define TEST_NUM 2
#define SOC_EFUSE0_SHADOW_ADDR 0x1054A000
#define SEC_EIP96_DISABLE_BIT  (1<<18)
#define SEC_EIP62_DISABLE_BIT  (1<<20)

unsigned long long enq_ptr[MAX_NO_OF_QUEUE];
unsigned long long deq_ptr[MAX_NO_OF_QUEUE];

int SEC_test(void){

	typedef struct{
		char *test_name;
		unsigned int test_id;
	}testcase_t;

	unsigned int reg_val = 0;
	int eip96_disable = 0;
	int eip62_disable = 0;
	int num_of_test = 0;

	reg_val = READ32(SOC_EFUSE0_SHADOW_ADDR);
	printf("\nEFUSE0 register = 0x%08x\n", reg_val);

	if (reg_val != 0) {
		if ((reg_val & SEC_EIP96_DISABLE_BIT) != 0) { //Check EIP96 EFUSE
			printf("\n\t==> SEC EIP96 IS DISABLEB!!!");
			eip96_disable = 1;
		}
		else {
			printf("\n\t==> SEC EIP96 IS ENABLED.");
		}

		if ((reg_val & SEC_EIP62_DISABLE_BIT) != 0) { //Check EIP62 EFUSE --> EIP62 is disabled in all part number --> no test
			printf("\n\t==> SEC EIP62 IS DISABLEB!!!");
			eip62_disable = 1;
		}
		else {
			printf("\n\t==> SEC EIP62 IS ENABLED.");
		}
	}
	else {
		printf("\n\t==> All of EFUSE is zero\n");
	}

	if (eip96_disable == 1) {
		num_of_test = 1; //just test EIP38 (XTS)
	}
	else {
		num_of_test = 3; //EIP96 test, EIP38 test and all_test_case
	}

	printf("\nPress any key to continue...\n");
	getchar();

	testcase_t testcase[TEST_NUM+1];

	testcase[0].test_name = "L1_SEC_EIP38_BULK_AES_XTS_DEC_128BIT_KEY_MULTMEM";
	testcase[0].test_id = 0;
	testcase[1].test_name = "L1_SEC_EIP96_MULTIPLE_SRC_BUFFER_MODE";
	testcase[1].test_id = 1;
	testcase[2].test_name = "ALL_TEST_CASES_SEC";
	testcase[2].test_id = 2;

	printf("####  Regression testcases for Storm B0 ####\n");

	int i;

    char ch, str[30];
    int number;

	init_ocm();
	qm_disable();
	init_qm();
	init_queue_ptr();
	qm_enable();
	init_sec(); //Common SEC settings for all test case

	while(1){
		printf("************  Instruction  *****************\n");
		printf(" Numbers corresponding to the testcases\n");
		printf("Enter Ctrl+C to exit\n");
		for(i = 0;i < num_of_test ; i++){
			printf("%u. %s\n", testcase[i].test_id, testcase[i].test_name);
		}

		if (eip96_disable == 1) {
			printf("\nPlease enter 0 to run EIP38 test\n");
			gets(str);
			if((str[0] >= 0x30) && (str[0] <= 0x39)){
				number = atoi(str);
			}
			else if(str[0] == 0x3){  //ctrl + C
				break;
			}

			 switch (number){
			 case 0:
				 EIP38_BULK_AES_XTS_DEC_128BIT_KEY_MULTIMEM();
				 break;
			 default:
				 EIP38_BULK_AES_XTS_DEC_128BIT_KEY_MULTIMEM();
				 break;
			 }
		}
		else {
			printf("\nPlease enter an integer number between 0 and %u\n",TEST_NUM);
			gets(str);
			if((str[0] >= 0x30) && (str[0] <= 0x39)){
				number = atoi(str);
			}
			else if(str[0] == 0x3){  //ctrl + C
				break;
			}
			 switch (number){
			 case 0:
				 EIP38_BULK_AES_XTS_DEC_128BIT_KEY_MULTIMEM();
				 break;
			 case 1:
				 EIP96_MULTIPLE_SRC_BUFFER_MODE();
				 break;
			 case 2:
				 ALL_TEST_CASES_SEC();
				 break;
			 default:
				 ALL_TEST_CASES_SEC();
				 break;
			 }
		}
	}
	return 0;
}

int ALL_TEST_CASES_SEC (void) {
	int error = 0;
	int in_ch;

	error += EIP38_BULK_AES_XTS_DEC_128BIT_KEY_MULTIMEM();
	MSDELAY(500);

	error += EIP96_MULTIPLE_SRC_BUFFER_MODE();
	MSDELAY(500);

	printf("############################################################\n");
	printf("##             Number of PASSED Tests: %02u                 ##\n", (TEST_NUM - error));
	printf("##             Number of FAILED Tests: %02u                 ##\n",error);
	printf("############################################################\n");
//--------------------------------

	if (error == 0)
		printPASS();
	else
		printFAIL();

	return 0;
}
