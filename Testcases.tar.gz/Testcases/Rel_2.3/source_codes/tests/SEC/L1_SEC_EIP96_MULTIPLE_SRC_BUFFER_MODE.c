/* Author: ldinh@apm.com 
*  Company: Applied Micro Circuits Corporation (AMCC)
* 
* Describe the purpose of your Test here
*
*/
#include "L1_SEC_EIP96_MULTIPLE_SRC_BUFFER_MODE.h"

//Tinh-SLT
//function call
#define printPASS printPASS_slt_sec
#define printFAIL printFAIL_slt_sec
#define qm_enable qm_enable_slt_sec
//End of Tinh-SLT

extern unsigned long long enq_ptr[MAX_NO_OF_QUEUE];
extern unsigned long long deq_ptr[MAX_NO_OF_QUEUE];

void config_eip96_bypass_msrc_bufmd(void)
{
	int i;
	int eip96_core_cfg_tbl[30] = {
		0x3800, 0x4004,
		0x3804, 0xffffffff,
		0x3808, 0x236,
		0x3814, 0xf88008ff,
		0x3818, 0xf88008ff,
		0x3844, 0x0,
		0x3810, 0x0,
		0x3848, 0x4005,
		0x384c, 0x4006,
		0x3850, 0x4007,
		0x3854, 0x4008,
		0x3858, 0x4009,
		0x385c, 0x400a,
		0x3870, 0x400b,
		0x3874, 0x400c
	};
	// Select EIP96
	WRITE32(SEC_CSR_BASE + SM_SEC_GLBL_CTRL_CSR_CSR_GLB_SEC_WQ_EIP96_EIP62__ADDR, 0x0);

	debug_sec("\n *** Start config. SEC CSR for eip96_bypass_msrc_bufmd test case ***\n");
	// Enable EIP96 AXI domain logic to process message from QMI
	WRITE32 (SEC_CSR_BASE + SM_SEC_CSR__INSTANCE_ADDR_OFFSET*1 + SM_SEC_CSR_CSR_SEC_CFG__ADDR, 0x80000000);

	// Set token read offset size and prefetch size
	WRITE32 (SEC_CSR_BASE + SM_SEC_CSR__INSTANCE_ADDR_OFFSET*1 + SM_SEC_CRYPTO_CSR_CSR_SEC_CRYPTO_CFG_0__ADDR, 0x74000000);

	// Configure EIP96 core
	for (i = 0; i < 30; i += 2)
	{
		WRITE32(SEC_CSR_BASE+ eip96_core_cfg_tbl[i], eip96_core_cfg_tbl[i+1]);
	}

	debug_sec("*** End config. SEC CSR for eip96_bypass_msrc_bufmd test case ***\n");
}

void load_mem_eip96_bypass_msrc_bufmd (buf_header_queue *expt_buf_queue_ptr, buf_header_queue *expt_tkn_queue_ptr)
{
	buf_header expt_buf_header;
	buf_header expt_tkn_header;

	unsigned long long mem_addr;
	int i;

	unsigned int in_tkn_0 [11] = {
		0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x014004a0, 0x00000007, (unsigned int)(((MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_CTX_OFST+0x0000 >> 36) & 0xffffffff), (unsigned int)(((MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_CTX_OFST+0x0000 >> 4) & 0xffffffff),
		0x40d8000e, 0x69060492, 0x09060486
	};
	unsigned int in_ctx_0 [16] = {
		0x5a8c0001, 0x00000001, 0x67795a01, 0x3f210ed0, 0x00000001, 0x00000000, 0x367965b7, 0x0b91d6c5,
		0xae88ab6b, 0xc19b2495, 0x5885b9e4, 0x942e3f91, 0x8e6c8b29, 0x11c15e9c, 0xd23bee23, 0x798e6f13
	};
	//Buffer[0] size = 000000a8
	unsigned int in_data_buf_0[42] = {
		0x01E1C6E5, 0x187059B6, 0xA3E754BE, 0xBE450008, 0x00009204, 0x06CE0000, 0xCDCD0435, 0xE9FA2FB1,
		0x0100BD38, 0x05040302, 0x09080706, 0x0D0C0B0A, 0x11100F0E, 0x15141312, 0x19181716, 0x1D1C1B1A,
		0x55AA55AA, 0xAA55AA55, 0x5AA55AA5, 0xA55AA55A, 0xAAAAAAAA, 0x00000000, 0x00000001, 0x00000002,
		0x00000004, 0x00000008, 0x00000010, 0x00000020, 0x00000040, 0x00000080, 0x00000100, 0x00000200,
		0x00000400, 0x00000800, 0x00001000, 0x00002000, 0x00004000, 0x00008000, 0x00010000, 0x00020000,
		0x00040000, 0x00080000
	};

	//Buffer[1] size = 000000b9
	unsigned int in_data_buf_1[47] = {
		0x00100000, 0x00200000, 0x00400000, 0x00800000, 0x01000000, 0x02000000, 0x04000000, 0x08000000,
		0x10000000, 0x20000000, 0x40000000, 0x80000000, 0xFFFFFFFF, 0xFFFFFFFE, 0xFFFFFFFD, 0xFFFFFFFB,
		0xFFFFFFF7, 0xFFFFFFEF, 0xFFFFFFDF, 0xFFFFFFBF, 0xFFFFFF7F, 0xFFFFFEFF, 0xFFFFFDFF, 0xFFFFFBFF,
		0xFFFFF7FF, 0xFFFFEFFF, 0xFFFFDFFF, 0xFFFFBFFF, 0xFFFF7FFF, 0xFFFEFFFF, 0xFFFDFFFF, 0xFFFBFFFF,
		0xFFF7FFFF, 0xFFEFFFFF, 0xFFDFFFFF, 0xFFBFFFFF, 0xFF7FFFFF, 0xFEFFFFFF, 0xFDFFFFFF, 0xFBFFFFFF,
		0xF7FFFFFF, 0xEFFFFFFF, 0xDFFFFFFF, 0xBFFFFFFF, 0x7FFFFFFF, 0x55555555, 0x41403F3E
	};

	//Buffer[2] size = 000000ca
	unsigned int in_data_buf_2[51] = {
		0x4241403F, 0x46454443, 0x4A494847, 0x4E4D4C4B, 0x5251504F, 0x56555453, 0x5A595857, 0x5E5D5C5B,
		0x6261605F, 0x66656463, 0x6A696867, 0x6E6D6C6B, 0x7271706F, 0x76757473, 0x7A797877, 0x7E7D7C7B,
		0x8281807F, 0x86858483, 0x8A898887, 0x8E8D8C8B, 0x9291908F, 0x96959493, 0x9A999897, 0x9E9D9C9B,
		0xA2A1A09F, 0xA6A5A4A3, 0xAAA9A8A7, 0xAEADACAB, 0xB2B1B0AF, 0xB6B5B4B3, 0xBAB9B8B7, 0xBEBDBCBB,
		0xC2C1C0BF, 0xC6C5C4C3, 0xCAC9C8C7, 0xCECDCCCB, 0xD2D1D0CF, 0xD6D5D4D3, 0xDAD9D8D7, 0xDEDDDCDB,
		0xE2E1E0DF, 0xE6E5E4E3, 0xEAE9E8E7, 0xEEEDECEB, 0xF2F1F0EF, 0xF6F5F4F3, 0xFAF9F8F7, 0xFEFDFCFB,
		0x020100FF, 0x06050403, 0x0A090807
	};

	//Buffer[3] size = 000000db
	unsigned int in_data_buf_3[55] = {
		0x0C0B0A09, 0x100F0E0D, 0x14131211, 0x18171615, 0x1C1B1A19, 0x201F1E1D, 0x24232221, 0x28272625,
		0x2C2B2A29, 0x302F2E2D, 0x34333231, 0x38373635, 0x3C3B3A39, 0x403F3E3D, 0x44434241, 0x48474645,
		0x4C4B4A49, 0x504F4E4D, 0x54535251, 0x58575655, 0x5C5B5A59, 0x605F5E5D, 0x64636261, 0x68676665,
		0x6C6B6A69, 0x706F6E6D, 0x74737271, 0x78777675, 0x7C7B7A79, 0x807F7E7D, 0x84838281, 0x88878685,
		0x8C8B8A89, 0x908F8E8D, 0x94939291, 0x98979695, 0x9C9B9A99, 0xA09F9E9D, 0xA4A3A2A1, 0xA8A7A6A5,
		0xACABAAA9, 0xB0AFAEAD, 0xB4B3B2B1, 0xB8B7B6B5, 0xBCBBBAB9, 0xC0BFBEBD, 0xC4C3C2C1, 0xC8C7C6C5,
		0xCCCBCAC9, 0xD0CFCECD, 0xD4D3D2D1, 0xD8D7D6D5, 0xDCDBDAD9, 0xE0DFDEDD, 0xE4E3E2E1
	};

	//Buffer[4] size = 000000ec
	unsigned int in_data_buf_4[59] = {
		0xE7E6E5E4, 0xEBEAE9E8, 0xEFEEEDEC, 0xF3F2F1F0, 0xF7F6F5F4, 0xFBFAF9F8, 0xFFFEFDFC, 0x03020100,
		0x07060504, 0x0B0A0908, 0x0F0E0D0C, 0x13121110, 0x17161514, 0x1B1A1918, 0x1F1E1D1C, 0x23222120,
		0x27262524, 0x2B2A2928, 0x2F2E2D2C, 0x33323130, 0x37363534, 0x3B3A3938, 0x3F3E3D3C, 0x43424140,
		0x47464544, 0x4B4A4948, 0x4F4E4D4C, 0x53525150, 0x57565554, 0x5B5A5958, 0x5F5E5D5C, 0x63626160,
		0x67666564, 0x6B6A6968, 0x6F6E6D6C, 0x73727170, 0x77767574, 0x7B7A7978, 0x7F7E7D7C, 0x83828180,
		0x87868584, 0x8B8A8988, 0x8F8E8D8C, 0x93929190, 0x97969594, 0x9B9A9998, 0x9F9E9D9C, 0xA3A2A1A0,
		0xA7A6A5A4, 0xABAAA9A8, 0xAFAEADAC, 0xB3B2B1B0, 0xB7B6B5B4, 0xBBBAB9B8, 0xBFBEBDBC, 0xC3C2C1C0,
		0xC7C6C5C4, 0xCBCAC9C8, 0xCFCECDCC
	};

	//Buffer[5] size = 0000001d
	unsigned int in_data_buf_5[8] = {
		0xD3D2D1D0, 0xD7D6D5D4, 0xDBDAD9D8, 0xDFDEDDDC, 0xE3E2E1E0, 0xE7E6E5E4, 0xEBEAE9E8, 0xEFEEEDEC
	};

	//Buffer[6] size = 0000002e
	unsigned int in_data_buf_6[12] = {
		0xF0EFEEED, 0xF4F3F2F1, 0xF8F7F6F5, 0xFCFBFAF9, 0x00FFFEFD, 0x04030201, 0x08070605, 0x0C0B0A09,
		0x100F0E0D, 0x14131211, 0x18171615, 0x1C1B1A19
	};

	//Buffer[7] size = 0000003f
	unsigned int in_data_buf_7[16] = {
		0x1E1D1C1B, 0x2221201F, 0x26252423, 0x2A292827, 0x2E2D2C2B, 0x3231302F, 0x36353433, 0x3A393837,
		0x3E3D3C3B, 0x4241403F, 0x46454443, 0x4A494847, 0x4E4D4C4B, 0x5251504F, 0x56555453, 0x5A595857
	};

	//Buffer[8] size = 00000024
	unsigned int in_data_buf_8[9] = {
		0x5D5C5B5A, 0x00000000, 0xFFFFFFFF, 0x00FF00FF, 0xAAAAAAAA, 0x55555555, 0xA55A5AA5, 0x12345678,
		0x1A6D5CF2
	};

	// Length     = 0x00000010
	unsigned int exp_tkn_0 [11] = {
		0x00000492, 0x00000000, 0x00000000, 0x04360000, 0x014004a0, 0x00000007, (unsigned int)(((MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_CTX_OFST+0x0000 >> 36) & 0xffffffff), (unsigned int)(((MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_CTX_OFST+0x0000 >> 4) & 0xffffffff),
		0x40d8000e, 0x69060492, 0x09060486
	};

	//Buffer[0] size = 00000014
	unsigned int exp_data_buf_0[5] = {
		0x9204BE45, 0x00000000, 0x043606CD, 0x2FB1CDCD, 0xBD38E9FA
	};

	//Buffer[1] size = 0000010f
	unsigned int exp_data_buf_1[68] = {
		0x03020100, 0x07060504, 0x0B0A0908, 0x0F0E0D0C, 0x13121110, 0x17161514, 0x1B1A1918, 0x55AA1D1C,
		0xAA5555AA, 0x5AA5AA55, 0xA55A5AA5, 0xAAAAA55A, 0x0000AAAA, 0x00010000, 0x00020000, 0x00040000,
		0x00080000, 0x00100000, 0x00200000, 0x00400000, 0x00800000, 0x01000000, 0x02000000, 0x04000000,
		0x08000000, 0x10000000, 0x20000000, 0x40000000, 0x80000000, 0x00000000, 0x00000001, 0x00000002,
		0x00000004, 0x00000008, 0x00000010, 0x00000020, 0x00000040, 0x00000080, 0x00000100, 0x00000200,
		0x00000400, 0x00000800, 0x00001000, 0x00002000, 0x00004000, 0xFFFF8000, 0xFFFEFFFF, 0xFFFDFFFF,
		0xFFFBFFFF, 0xFFF7FFFF, 0xFFEFFFFF, 0xFFDFFFFF, 0xFFBFFFFF, 0xFF7FFFFF, 0xFEFFFFFF, 0xFDFFFFFF,
		0xFBFFFFFF, 0xF7FFFFFF, 0xEFFFFFFF, 0xDFFFFFFF, 0xBFFFFFFF, 0x7FFFFFFF, 0xFFFFFFFF, 0xFFFFFFFE,
		0xFFFFFFFD, 0xFFFFFFFB, 0xFFFFFFF7, 0xFFFFFFEF
	};

	//Buffer[2] size = 0000008e
	unsigned int exp_data_buf_2[36] = {
		0xFFFFDFFF, 0xFFFFBFFF, 0xFFFF7FFF, 0xFFFEFFFF, 0xFFFDFFFF, 0xFFFBFFFF, 0xFFF7FFFF, 0xFFEFFFFF,
		0xFFDFFFFF, 0xFFBFFFFF, 0x557FFFFF, 0x3E555555, 0x4241403F, 0x46454443, 0x4A494847, 0x4E4D4C4B,
		0x5251504F, 0x56555453, 0x5A595857, 0x5E5D5C5B, 0x6261605F, 0x66656463, 0x6A696867, 0x6E6D6C6B,
		0x7271706F, 0x76757473, 0x7A797877, 0x7E7D7C7B, 0x8281807F, 0x86858483, 0x8A898887, 0x8E8D8C8B,
		0x9291908F, 0x96959493, 0x9A999897, 0x9E9D9C9B
	};

	//Buffer[3] size = 000001ad
	unsigned int exp_data_buf_3[108] = {
		0xA09F9E9D, 0xA4A3A2A1, 0xA8A7A6A5, 0xACABAAA9, 0xB0AFAEAD, 0xB4B3B2B1, 0xB8B7B6B5, 0xBCBBBAB9,
		0xC0BFBEBD, 0xC4C3C2C1, 0xC8C7C6C5, 0xCCCBCAC9, 0xD0CFCECD, 0xD4D3D2D1, 0xD8D7D6D5, 0xDCDBDAD9,
		0xE0DFDEDD, 0xE4E3E2E1, 0xE8E7E6E5, 0xECEBEAE9, 0xF0EFEEED, 0xF4F3F2F1, 0xF8F7F6F5, 0xFCFBFAF9,
		0x00FFFEFD, 0x04030201, 0x08070605, 0x0C0B0A09, 0x100F0E0D, 0x14131211, 0x18171615, 0x1C1B1A19,
		0x201F1E1D, 0x24232221, 0x28272625, 0x2C2B2A29, 0x302F2E2D, 0x34333231, 0x38373635, 0x3C3B3A39,
		0x403F3E3D, 0x44434241, 0x48474645, 0x4C4B4A49, 0x504F4E4D, 0x54535251, 0x58575655, 0x5C5B5A59,
		0x605F5E5D, 0x64636261, 0x68676665, 0x6C6B6A69, 0x706F6E6D, 0x74737271, 0x78777675, 0x7C7B7A79,
		0x807F7E7D, 0x84838281, 0x88878685, 0x8C8B8A89, 0x908F8E8D, 0x94939291, 0x98979695, 0x9C9B9A99,
		0xA09F9E9D, 0xA4A3A2A1, 0xA8A7A6A5, 0xACABAAA9, 0xB0AFAEAD, 0xB4B3B2B1, 0xB8B7B6B5, 0xBCBBBAB9,
		0xC0BFBEBD, 0xC4C3C2C1, 0xC8C7C6C5, 0xCCCBCAC9, 0xD0CFCECD, 0xD4D3D2D1, 0xD8D7D6D5, 0xDCDBDAD9,
		0xE0DFDEDD, 0xE4E3E2E1, 0xE8E7E6E5, 0xECEBEAE9, 0xF0EFEEED, 0xF4F3F2F1, 0xF8F7F6F5, 0xFCFBFAF9,
		0x00FFFEFD, 0x04030201, 0x08070605, 0x0C0B0A09, 0x100F0E0D, 0x14131211, 0x18171615, 0x1C1B1A19,
		0x201F1E1D, 0x24232221, 0x28272625, 0x2C2B2A29, 0x302F2E2D, 0x34333231, 0x38373635, 0x3C3B3A39,
		0x403F3E3D, 0x44434241, 0x48474645, 0x4C4B4A49
	};

	//Buffer[4] size = 0000000c
	unsigned int exp_data_buf_4[3] = {
		0x4D4C4B4A, 0x51504F4E, 0x55545352
	};

	//Buffer[5] size = 0000004b
	unsigned int exp_data_buf_5[19] = {
		0x59585756, 0x5D5C5B5A, 0x61605F5E, 0x65646362, 0x69686766, 0x6D6C6B6A, 0x71706F6E, 0x75747372,
		0x79787776, 0x7D7C7B7A, 0x81807F7E, 0x85848382, 0x89888786, 0x8D8C8B8A, 0x91908F8E, 0x95949392,
		0x99989796, 0x9D9C9B9A, 0xA1A09F9E
	};

	//Buffer[6] size = 0000005a
	unsigned int exp_data_buf_6[23] = {
		0xA4A3A2A1, 0xA8A7A6A5, 0xACABAAA9, 0xB0AFAEAD, 0xB4B3B2B1, 0xB8B7B6B5, 0xBCBBBAB9, 0xC0BFBEBD,
		0xC4C3C2C1, 0xC8C7C6C5, 0xCCCBCAC9, 0xD0CFCECD, 0xD4D3D2D1, 0xD8D7D6D5, 0xDCDBDAD9, 0xE0DFDEDD,
		0xE4E3E2E1, 0xE8E7E6E5, 0xECEBEAE9, 0xF0EFEEED, 0xF4F3F2F1, 0xF8F7F6F5, 0xFCFBFAF9
	};

	//Buffer[7] size = 00000083
	unsigned int exp_data_buf_7[33] = {
		0xFEFDFCFB, 0x020100FF, 0x06050403, 0x0A090807, 0x0E0D0C0B, 0x1211100F, 0x16151413, 0x1A191817,
		0x1E1D1C1B, 0x2221201F, 0x26252423, 0x2A292827, 0x2E2D2C2B, 0x3231302F, 0x36353433, 0x3A393837,
		0x3E3D3C3B, 0x4241403F, 0x46454443, 0x4A494847, 0x4E4D4C4B, 0x5251504F, 0x56555453, 0x5A595857,
		0x005D5C5B, 0xFF000000, 0xFFFFFFFF, 0xAA00FF00, 0x55AAAAAA, 0xA5555555, 0x78A55A5A, 0xF2123456,
		0x001A6D5C
	};


	// Load token, context, input data
	//
	debug_sec("\n *** Start loading token ***\n");
	//Input token
	mem_addr =(MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_TKN_OFST+0x0;
	for (i = 0; i < 11; i++)
	{
		WRITE32(mem_addr, in_tkn_0[i]);
		mem_addr += 4;
	}

	// Expected token (result token + input token)
	mem_addr =(MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_EXP_RTKN_OFST+0x0;
	for (i = 0; i < 11; i++)
	{
		WRITE32(mem_addr, exp_tkn_0[i]);
		mem_addr += 4;
	}
	// Push header into queue to retrieve later
	expt_tkn_header.field.BufDataAddr = (MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_EXP_RTKN_OFST+0x0;
	expt_tkn_header.field.BufDataLength = 0x2c;
	// Repeat 4 times as token are same for 4 packets
	for (i = 0; i < 4; i++)
	{
		write_buf_header(expt_tkn_queue_ptr, expt_tkn_header, MAX_WK_MSG);
	}
	debug_sec(" *** End loading token ***\n");

	debug_sec("\n *** Start loading context ***\n");
	mem_addr =(MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_CTX_OFST+0x0000;
	for (i = 0; i < 16; i++)
	{
		WRITE32(mem_addr, in_ctx_0[i]);
		mem_addr += 4;
	}
	debug_sec(" *** End loading context ***\n");

	debug_sec("\n *** Start loading input data ***\n");
	mem_addr = (MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_DAT_IN_OFST+0x000;
	for (i = 0; i < 42; i++)
	{
		WRITE32(mem_addr, in_data_buf_0[i]);
		mem_addr += 4;
	}

	mem_addr = (MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_DAT_IN_OFST+0x100;
	for (i = 0; i < 47; i++)
	{
		WRITE32(mem_addr, in_data_buf_1[i]);
		mem_addr += 4;
	}

	mem_addr = (MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_DAT_IN_OFST+0x200;
	for (i = 0; i < 51; i++)
	{
		WRITE32(mem_addr, in_data_buf_2[i]);
		mem_addr += 4;
	}

	mem_addr = (MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_DAT_IN_OFST+0x300;
	for (i = 0; i < 55; i++)
	{
		WRITE32(mem_addr, in_data_buf_3[i]);
		mem_addr += 4;
	}

	mem_addr = (MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_DAT_IN_OFST+0x400;
	for (i = 0; i < 59; i++)
	{
		WRITE32(mem_addr, in_data_buf_4[i]);
		mem_addr += 4;
	}

	mem_addr = (MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_DAT_IN_OFST+0x4EC;
	for (i = 0; i < 8; i++)
	{
		WRITE32(mem_addr, in_data_buf_5[i]);
		mem_addr += 4;
	}

	mem_addr = (MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_DAT_IN_OFST+0x514;
	for (i = 0; i < 12; i++)
	{
		WRITE32(mem_addr, in_data_buf_6[i]);
		mem_addr += 4;
	}

	mem_addr = (MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_DAT_IN_OFST+0x568;
	for (i = 0; i < 16; i++)
	{
		WRITE32(mem_addr, in_data_buf_7[i]);
		mem_addr += 4;
	}

	mem_addr = (MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_DAT_IN_OFST+0x604;
	for (i = 0; i < 9; i++)
	{
		WRITE32(mem_addr, in_data_buf_8[i]);
		mem_addr += 4;
	}
	debug_sec(" *** End loading input data ***\n");

	debug_sec("\n *** Start loading expected output data ***\n");
	mem_addr = (MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_EXP_DAT_OUT_OFST+0x000;
	for (i = 0; i < 5; i++)
	{
		WRITE32(mem_addr, exp_data_buf_0[i]);
		mem_addr += 4;
	}

	mem_addr = (MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_EXP_DAT_OUT_OFST+0x200;
	for (i = 0; i < 68; i++)
	{
		WRITE32(mem_addr, exp_data_buf_1[i]);
		mem_addr += 4;
	}

	mem_addr = (MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_EXP_DAT_OUT_OFST+0x400;
	for (i = 0; i < 36; i++)
	{
		WRITE32(mem_addr, exp_data_buf_2[i]);
		mem_addr += 4;
	}

	mem_addr = (MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_EXP_DAT_OUT_OFST+0x600;
	for (i = 0; i < 108; i++)
	{
		WRITE32(mem_addr, exp_data_buf_3[i]);
		mem_addr += 4;
	}

	mem_addr = (MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_EXP_DAT_OUT_OFST+0x800;
	for (i = 0; i < 3; i++)
	{
		WRITE32(mem_addr, exp_data_buf_4[i]);
		mem_addr += 4;
	}

	mem_addr = (MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_EXP_DAT_OUT_OFST+0xa00;
	for (i = 0; i < 19; i++)
	{
		WRITE32(mem_addr, exp_data_buf_5[i]);
		mem_addr += 4;
	}

	mem_addr = (MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_EXP_DAT_OUT_OFST+0xa50;
	for (i = 0; i < 23; i++)
	{
		WRITE32(mem_addr, exp_data_buf_6[i]);
		mem_addr += 4;
	}

	mem_addr = (MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_EXP_DAT_OUT_OFST+0xabc;
	for (i = 0; i < 33; i++)
	{
		WRITE32(mem_addr, exp_data_buf_7[i]);
		mem_addr += 4;
	}

	for (i =  0; i < 4; i++)
	{
		expt_buf_header.field.BufDataLength = 0x7014;
		expt_buf_header.field.BufDataAddr = (MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_EXP_DAT_OUT_OFST+0x000;
		write_buf_header(expt_buf_queue_ptr, expt_buf_header, MAX_FP_MSG);
		expt_buf_header.field.BufDataLength = 0x610f;
		expt_buf_header.field.BufDataAddr = (MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_EXP_DAT_OUT_OFST+0x200;
		write_buf_header(expt_buf_queue_ptr, expt_buf_header, MAX_FP_MSG);
		expt_buf_header.field.BufDataLength = 0x508E;
		expt_buf_header.field.BufDataAddr = (MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_EXP_DAT_OUT_OFST+0x400;
		write_buf_header(expt_buf_queue_ptr, expt_buf_header, MAX_FP_MSG);
		expt_buf_header.field.BufDataLength = 0x41ad;
		expt_buf_header.field.BufDataAddr = (MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_EXP_DAT_OUT_OFST+0x600;
		write_buf_header(expt_buf_queue_ptr, expt_buf_header, MAX_FP_MSG);
		expt_buf_header.field.BufDataLength = 0x600c;
		expt_buf_header.field.BufDataAddr = (MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_EXP_DAT_OUT_OFST+0x800;
		write_buf_header(expt_buf_queue_ptr, expt_buf_header, MAX_FP_MSG);
		expt_buf_header.field.BufDataLength = 0x504b;
		expt_buf_header.field.BufDataAddr = (MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_EXP_DAT_OUT_OFST+0xA00;
		write_buf_header(expt_buf_queue_ptr, expt_buf_header, MAX_FP_MSG);
		expt_buf_header.field.BufDataLength = 0x605a;
		expt_buf_header.field.BufDataAddr = (MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_EXP_DAT_OUT_OFST+0xA50;
		write_buf_header(expt_buf_queue_ptr, expt_buf_header, MAX_FP_MSG);
		expt_buf_header.field.BufDataLength = 0x7083;
		expt_buf_header.field.BufDataAddr = (MEM_BASE_ADDR+SEC_TEST_OFST)+SEC_EXP_DAT_OUT_OFST+0xABC;
		write_buf_header(expt_buf_queue_ptr, expt_buf_header, MAX_FP_MSG);
	}
	debug_sec(" *** End loading expected output data ***\n");
}

int build_msg_eip96_bypass_msrc_bufmd(enq_msg_header_queue *wq_msg_header_queue_ptr, enq_msg_header_queue* fp_msg_header_queue_ptr)
{
	int i,j;
	unsigned long long mem_addr;
	int no_of_msg = 0;
	unsigned int user_info, wqid, fpqid, hfpsel;
	buf_header buf_header;
	unsigned long long wq_msg_sll_ptr = MEM_BASE_ADDR+SEC_WQ_MSG_SLL_OFST;
	unsigned long long cm_msg_dll_ptr = MEM_BASE_ADDR+SEC_CM_MSG_DLL_OFST;
	unsigned long long dat_in_ptr     = MEM_BASE_ADDR+SEC_TEST_OFST+SEC_DAT_IN_OFST;
	unsigned long long dat_out_ptr    = MEM_BASE_ADDR+SEC_TEST_OFST+SEC_DAT_OUT_OFST;

	user_info = gen_sec_user_info(EIP96_CORE_TYPE);
	wqid = get_sec_wqid(EIP96_CORE_TYPE);
	for (i =  0; i < 4; i++)
	{
		debug_sec(" *** Start preparing message for eip96_bypass_msrc_bufmd test case ***\n");
		// Src linked list to store input memory pointer
		buf_header.field.BufDataLength = 0x401d;
		buf_header.field.BufDataAddr = dat_in_ptr + 0x4ec;
		WRITE32(wq_msg_sll_ptr+0x00, buf_header.raw[0]);
		WRITE32(wq_msg_sll_ptr+0x04, buf_header.raw[1]);
		buf_header.field.BufDataLength = 0x00ec;
		buf_header.field.BufDataAddr = dat_in_ptr + 0x400;
		WRITE32(wq_msg_sll_ptr+0x08, buf_header.raw[0]);
		WRITE32(wq_msg_sll_ptr+0x0C, buf_header.raw[1]);

		buf_header.field.BufDataLength = 0x603f;
		buf_header.field.BufDataAddr = dat_in_ptr + 0x568;
		WRITE32(wq_msg_sll_ptr+0x10, buf_header.raw[0]);
		WRITE32(wq_msg_sll_ptr+0x14, buf_header.raw[1]);
		buf_header.field.BufDataLength = 0x502e;
		buf_header.field.BufDataAddr = dat_in_ptr + 0x514;
		WRITE32(wq_msg_sll_ptr+0x18, buf_header.raw[0]);
		WRITE32(wq_msg_sll_ptr+0x1C, buf_header.raw[1]);

		buf_header.field.BufDataLength = 0x7024;
		buf_header.field.BufDataAddr = dat_in_ptr + 0x604;
		WRITE32(wq_msg_sll_ptr+0x28, buf_header.raw[0]);
		WRITE32(wq_msg_sll_ptr+0x2C, buf_header.raw[1]);

		// FP message to store output data
		fpqid = gen_sec_fpqid();
		hfpsel = get_sec_hfpsel(fpqid);

		build_sec_16b_fp_msg (fpqid, 0x7014, (dat_out_ptr + 0x0000),
							user_info++, fp_msg_header_queue_ptr);
		build_sec_16b_fp_msg (fpqid, 0x610f, (dat_out_ptr + 0x0021),
							user_info++, fp_msg_header_queue_ptr);
		build_sec_16b_fp_msg (fpqid, 0x508e, (dat_out_ptr + 0x0142),
							user_info++, fp_msg_header_queue_ptr);
		build_sec_16b_fp_msg (fpqid, 0x41ad, (dat_out_ptr + 0x01d3),
							user_info++, fp_msg_header_queue_ptr);
		build_sec_16b_fp_msg (fpqid, 0x700c, (dat_out_ptr + 0x0384),
							user_info++, fp_msg_header_queue_ptr);
		// FP message to store CM message linked list
		build_sec_16b_fp_msg(fpqid, 0x7040, cm_msg_dll_ptr,
							user_info++, fp_msg_header_queue_ptr);

		// Remaining FP message to store output data
		build_sec_16b_fp_msg (fpqid, 0x604b, (dat_out_ptr + 0x0405),
							user_info++, fp_msg_header_queue_ptr);
		build_sec_16b_fp_msg (fpqid, 0x505a, (dat_out_ptr + 0x0476),
							user_info++, fp_msg_header_queue_ptr);
		build_sec_16b_fp_msg (fpqid, 0x4083, (dat_out_ptr + 0x0547),
							user_info++, fp_msg_header_queue_ptr);

		build_sec_64b_sll_bufmd_wq_msg(wqid, FPQID9, WQID0, hfpsel,
									0x40a8, (MEM_BASE_ADDR+SEC_TEST_OFST+SEC_DAT_IN_OFST+0x000),
									0x00, // Total linked list len (don't care for now)
									0x50b9, (MEM_BASE_ADDR+SEC_TEST_OFST+SEC_DAT_IN_OFST+0x100),
									0x60ca, (MEM_BASE_ADDR+SEC_TEST_OFST+SEC_DAT_IN_OFST+0x200),
									0x70db, (MEM_BASE_ADDR+SEC_TEST_OFST+SEC_DAT_IN_OFST+0x300),
									wq_msg_sll_ptr, 5,
									(MEM_BASE_ADDR+SEC_TEST_OFST+SEC_TKN_OFST),
									user_info++, wq_msg_header_queue_ptr);

		no_of_msg++;

		wq_msg_sll_ptr += 0x40;
		cm_msg_dll_ptr += 0x40;
		dat_out_ptr    += 0x5ca;
	}

	debug_sec(" *** End preparing message for eip96_bypass_msrc_bufmd test case *** \n");
	return no_of_msg;
}

int test_eip96_bypass_msrc_bufmd (enq_msg_header_queue *wq_msg_header_queue_ptr, enq_msg_header_queue* fp_msg_header_queue_ptr,
                       buf_header_queue *expt_buf_queue_ptr, buf_header_queue *expt_tkn_queue_ptr )
{
	int no_of_msg;

	config_eip96_bypass_msrc_bufmd();
	load_mem_eip96_bypass_msrc_bufmd(expt_buf_queue_ptr, expt_tkn_queue_ptr);
	no_of_msg = build_msg_eip96_bypass_msrc_bufmd (wq_msg_header_queue_ptr, fp_msg_header_queue_ptr);

	return no_of_msg;
}

int EIP96_MULTIPLE_SRC_BUFFER_MODE(void) {
	int error = 0;

//----- Put your code here -------
	int i, no_of_entry, no_of_cm_msg, num_of_msg;
	enq_msg_header* msg_header_ptr;

	static enq_msg_header wq_msg_header_array[MAX_WK_MSG];
	static enq_msg_header fp_msg_header_array[MAX_FP_MSG];

	static buf_header expt_buf_header_array[MAX_MEM_BUF];
	static buf_header expt_tkn_header_array[MAX_WK_MSG];
	static buf_header expt_deallot_header_array[MAX_FP_MSG];
	static buf_header expt_cm_header_array[MAX_WK_MSG];

	init_ocm();
	qm_disable();
	init_qm();
	init_queue_ptr();
	qm_enable();
	init_sec(); //Common SEC settings for all test case

    for (i = 0; i < MAX_WK_MSG; i++) {
    	wq_msg_header_array[i].msg_type = 0;
    	wq_msg_header_array[i].num_of_buf = 0;
    	wq_msg_header_array[i].qid = 0;
    	expt_tkn_header_array[i].field.BufDataAddr = 0;
    	expt_tkn_header_array[i].field.BufDataLength = 0;
    	expt_tkn_header_array[i].field.Reserved0 = 0;
    	expt_tkn_header_array[i].field.Reserved1 = 0;
    	expt_tkn_header_array[i].raw[0] = 0;
    	expt_tkn_header_array[i].raw[1] = 0;
    	expt_cm_header_array[i].field.BufDataAddr = 0;
    	expt_cm_header_array[i].field.BufDataLength = 0;
    	expt_cm_header_array[i].field.Reserved0 = 0;
    	expt_cm_header_array[i].field.Reserved1 = 0;
    	expt_cm_header_array[i].raw[0] = 0;
    	expt_cm_header_array[i].raw[1] = 0;
    }

    for (i = 0; i < MAX_FP_MSG; i++) {
    	fp_msg_header_array[i].msg_type = 0;
    	fp_msg_header_array[i].num_of_buf = 0;
    	fp_msg_header_array[i].qid = 0;
    	expt_deallot_header_array[i].field.BufDataAddr = 0;
    	expt_deallot_header_array[i].field.BufDataLength = 0;
    	expt_deallot_header_array[i].field.Reserved0 = 0;
    	expt_deallot_header_array[i].field.Reserved1 = 0;
    	expt_deallot_header_array[i].raw[0] = 0;
    	expt_deallot_header_array[i].raw[1] = 0;
    }

    for (i = 0; i < MAX_MEM_BUF; i++) {
    	expt_buf_header_array[i].field.BufDataAddr = 0;
    	expt_buf_header_array[i].field.BufDataLength = 0;
    	expt_buf_header_array[i].field.Reserved0 = 0;
    	expt_buf_header_array[i].field.Reserved1 = 0;
    	expt_buf_header_array[i].raw[0] = 0;
    	expt_buf_header_array[i].raw[1] = 0;
    }

    enq_msg_header_queue wq_msg_header_queue	= {0, 0, 0, 0};
    enq_msg_header_queue fp_msg_header_queue	= {0, 0, 0, 0};

    buf_header_queue expt_buf_header_queue		= {0, 0, 0, 0};
    buf_header_queue expt_tkn_header_queue		= {0, 0, 0, 0};
    buf_header_queue expt_deallot_header_queue	= {0, 0, 0, 0};
    buf_header_queue expt_cm_header_queue		= {0, 0, 0, 0};

    wq_msg_header_queue.enq_msg_header_ptr = wq_msg_header_array;
    fp_msg_header_queue.enq_msg_header_ptr = fp_msg_header_array;

    expt_buf_header_queue.buf_header_ptr = expt_buf_header_array;
    expt_tkn_header_queue.buf_header_ptr = expt_tkn_header_array;
    expt_deallot_header_queue.buf_header_ptr = expt_deallot_header_array;
    expt_cm_header_queue.buf_header_ptr = expt_cm_header_array;


    num_of_msg = test_eip96_bypass_msrc_bufmd(&wq_msg_header_queue, &fp_msg_header_queue, &expt_buf_header_queue, &expt_tkn_header_queue);
    debug_sec("\nnum_of_msg = 0x%08x\n", num_of_msg);

    debug_sec("Start message transfer.....\n");
    data_cache_flush_all();

    // Enqueue FP message if any
    no_of_entry = fp_msg_header_queue.no_of_entry;

	debug_sec("\nfp_msg_header_queue.no_of_entry = 0x%08x\n", no_of_entry);
	for (i = 0; i < no_of_entry; i++)
	{
		msg_header_ptr = read_enq_msg_header(&fp_msg_header_queue, MAX_FP_MSG);
		alternate_enqueue((*msg_header_ptr).qid, 1); //Inform QM to start loading message and sending to DUT IP
	}

	// Enqueue work message
	no_of_entry = wq_msg_header_queue.no_of_entry;
	debug_sec("\nwq_msg_header_queue.no_of_entry = 0x%08x\n", no_of_entry);
	for (i = 0; i < no_of_entry; i++)
	{
		msg_header_ptr = read_enq_msg_header(&wq_msg_header_queue, MAX_WK_MSG);
		if ((*msg_header_ptr).msg_type == 0)
		{
			alternate_enqueue((*msg_header_ptr).qid, 1); // Inform QM to start loading message
		}
		else
		{
			alternate_enqueue((*msg_header_ptr).qid, 2);
		}
	}

	debug_sec("\nStart pooling completion message\n");

	for (no_of_cm_msg = 1; no_of_cm_msg <= num_of_msg; no_of_cm_msg++)
	{
		poll_cm_msg(); //Pool completion message returned from DUT IP
		debug_sec("Received 0x%08x completion messages\n", no_of_cm_msg);
		error += chk_result(&expt_buf_header_queue, &expt_tkn_header_queue,
							&expt_deallot_header_queue, &expt_cm_header_queue, WQID0, 0);

		debug_sec("\n *** Number of errors = 0x%08x\n", error);
		debug_sec("Finished checking result for message 0x%08x\n", no_of_cm_msg);
	}

	if (read_qm_ne_sts() != 0)
	{
		debug_sec("\nqm_ne_sts = 0x%08x\n", read_qm_ne_sts());
		debug_sec("\n *** ERROR: Number of completion message is over number of work messages *** \n");
		error++;
	}

	debug_sec("\n *** Total number of errors = 0x%08x ***\n", error);
//--------------------------------

	if (error == 0) 
	{
		printPASS();
		return 0;
	}
	else
	{
		printFAIL();
		return 1;
	}
}

