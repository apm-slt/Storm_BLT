#define uint32_t unsigned int

#include <stdio.h>
#include <common.h>
#include "eth_common.h"
#include "eth_slt_tx2rx.h"
#include "eth_1g_csr.h"
#include "eth_mg_csr.h"
#include "sm_xxx_serdes.h"

#include "qm_drv.h" 
#include "qm_misc.h"
#include "qm_vfw.h"

static int read_rpkt_as[4] = {0,0,0,0};; 
static int read_rpkt_as_bak[4] = {0,0,0,0}; 
static int read_rfcs_as[4] = {0,0,0,0};
static int read_rfcs_as_bak[4] = {0,0,0,0}; 

extern int enet_base_addr;
static int clk_mode_1g = 0;      //0=External Clk Mode; 1=Internal clk mode
static int cle_enable = 0;       //1=Real CLE; 0=CLE bypass mode
static int mac_mode_1g = 2;      //0=10M 1=100M  2=1G 
static int gating_bypass_1g = 1; //1=No Gating Disabled; 0=Yes Gating Enabled
static int an_en_1g = 1;         //1=AutoNegNode Enabled;  0=Non AutoNegNode Enabled
static int advanced_debug = 0;   //1=Promt for options with xgenet_main, 0=quit to Menu
static int loopback = 1;         //0=No Rx-2-Tx FIFO level lpbk mode 

static int tx2rx_serdes_lb_1g = 0;      //0=Serdes tx-2-rx lpbk disable 1=Serdes tx-2-rx lpbk enable, (Gating should be Disabled with AutoNeg Mode gating_bypass_1g=1)
static int sata_sgmii_init_done = 0;
static int total_err_count[4] ={0, 0, 0, 0};
static int tx2rx_phy_lp = 0;        //1=PHY level tx-2-rx lpbk Enable, 0==PHY level tx-2-rx lpbk Disable
static int prbs_test_mode = 0;      //PRBS test mode only work in SERDES level tx-2-rx Mode   
static int sata_sgmii_margin_tool = 0;
static int hack_cnt=0;


//static int read_command = 0x40000000;
static int write_data = 0x00000000;
static int read_data = 0x00000000;
static int read_address = 0x00000000;
static u32 write_address = 0x00000000;
int itr_count[4];
u64 buf[16]; 
u64 buf32[16]; 
u64 buf33[16]; 
u64 buf34[16]; 


/*
    Error Code Details:
    0x10 = SGMII Core Link Down
    0x20 = Port Link Down
    0x30 = Enqueue Fail
    0x31 = Dequeue Fail
    0x40 = PEM-STAT Read Timeout, RFSC Error
    0x41 = PEM-STAT Read Timeout, No Packet Received 
    0x50 = Queue State Timeout
    0x60 = Packet CRC Error 
*/
void total_err_count_result() {

    int port;

    printf("\n");	
    printf("\n");	
    
    if((total_err_count[0] | total_err_count[1] | total_err_count[2] | total_err_count[3]) == 0x10) {
        for(port=0; port<4; port++) {
            if(total_err_count[port] == 0x10) {
                printf("\nSATA-SGMII PORT %d -- [ FAIL ] SGMII CORE LINK DOWN (ErrCode:%x)\n",port,total_err_count[port]);
            }
            else { 
                printf("\nSATA-SGMII PORT %d -- [ INCOMPLETE ] SGMII-CORE LINK-UP TEST ABORTED\n",port);
            }
        }
    }
    if((total_err_count[0] | total_err_count[1] | total_err_count[2] | total_err_count[3]) == 0x20) {
        for(port=0; port<4; port++) {
            if(total_err_count[port] == 0x20) {
                printf("\nSATA-SGMII PORT %d -- [ FAIL ] PORT LINK DOWN (ErrCode:%x)\n",port,total_err_count[port]);
            }
            else { 
                printf("\nSATA-SGMII PORT %d -- [ INCOMPLETE ] PORT LINK-UP TEST ABORTED\n",port);
            }
        }
    }
    if((total_err_count[0] | total_err_count[1] | total_err_count[2] | total_err_count[3]) == 0x30) {
        for(port=0; port<4; port++) {
            if(total_err_count[port] == 0x30) {
                printf("\nSATA-SGMII PORT %d -- [ FAIL ] PKT ENQUEUE ERROR (ErrCode:%x)\n",port,total_err_count[port]);
            }
            else { 
                printf("\nSATA-SGMII PORT %d -- [ INCOMPLETE ] TEST ABORTED\n",port);
            }
        }
    }
    if((total_err_count[0] | total_err_count[1] | total_err_count[2] | total_err_count[3]) == 0x31) {
        for(port=0; port<4; port++) {
            if(total_err_count[port] == 0x31) {
                printf("\nSATA-SGMII PORT %d -- [ FAIL ] PKT DEQUEUE ERROR (ErrCode:%x)\n",port,total_err_count[port]);
            }
            else { 
                printf("\nSATA-SGMII PORT %d -- [ INCOMPLETE ] TEST ABORTED\n",port);
            }
        }
    }
    if((total_err_count[0] | total_err_count[1] | total_err_count[2] | total_err_count[3]) == 0x40) {
        for(port=0; port<4; port++) {
            if(total_err_count[port] == 0x40) {
                printf("\nSATA-SGMII PORT %d -- [ FAIL ] PEMSTAT TIMEOUT RFCS ERROR (ErrCode:%x)\n",port,total_err_count[port]);
            }
            else { 
                printf("\nSATA-SGMII PORT %d -- [ INCOMPLETE ] TEST ABORTED\n",port);
            }
        }
    }
    if((total_err_count[0] | total_err_count[1] | total_err_count[2] | total_err_count[3]) == 0x41) {
        for(port=0; port<4; port++) {
            if(total_err_count[port] == 0x41) {
                printf("\nSATA-SGMII PORT %d -- [ FAIL ] PEMSTAT TIMEOUT NO PKT RECEIVED (ErrCode:%x)\n",port,total_err_count[port]);
            }
            else { 
                printf("\nSATA-SGMII PORT %d -- [ INCOMPLETE ] TEST ABORTED\n",port);
            }
        }
    }
    if((total_err_count[0] | total_err_count[1] | total_err_count[2] | total_err_count[3]) == 0x50) {
        for(port=0; port<4; port++) {
            if(total_err_count[port] == 0x50) {
                printf("\nSATA-SGMII PORT %d -- [ FAIL ] QUEUE STATE TIMEOUT (ErrCode:%x)\n",port,total_err_count[port]);
            }
            else { 
                printf("\nSATA-SGMII PORT %d -- [ INCOMPLETE ] TEST ABORTED\n",port);
            }
        }
    }
    if((total_err_count[0] | total_err_count[1] | total_err_count[2] | total_err_count[3]) == 0x60) {
        for(port=0; port<4; port++) {
            if(total_err_count[port] == 0x60) {
                printf("\nSATA-SGMII PORT %d -- [ FAIL ] PKT CRC ERROR (ErrCode:%x)\n",port,total_err_count[port]);
            }
            else { 
                printf("\nSATA-SGMII PORT %d -- [ INCOMPLETE ] TEST ABORTED\n",port);
            }
        }
    }
    if((total_err_count[0] | total_err_count[1] | total_err_count[2] | total_err_count[3]) == 0) {
        for(port=0; port<4; port++) {
            printf("\nSATA-SGMII PORT %d -- [ PASS ]\n",port,total_err_count[port]);
        }
    }

    if(total_err_count[0] || total_err_count[1] || total_err_count[2] || total_err_count[3])
        printf("\nTest Result : SATA-SGMII FAIL\n");
    else
        printf("\nTest Result : SATA-SGMII PASS\n");
}

void slt_hack_sata_sg(int port) {
    int temp;
    port = temp & 0x3;
    printf("\nSATA-SGMII Change Tx-Amplitude Reset Tx-Term, Tx-Analog-Rst, Tx-Digital-Rst,\n");
    enet_sds_rxtx_re_cfg_sata_sgmii(port,1);
    printf("Done\n");
    printf("Reconfigure SGMII core,");
    configure_sgmii(port, 0x0, 20);
    printf("Done\n");
    for(port=0; port<4; port++) {
        total_err_count[port] = 0; 
    }
    hack_cnt++;
}

int eyescan_sata_sgmii(int argc, char *argv[]) {
    int port;

    if (argc < 1){
        printf("\nnot enough argument, port# \n\r");
        return -1;
    } else {
        port = atoi(argv[0]);
    }

    printf("\nEyescan for port-%d\n",port);
    eyescan_sub_sata_sgmii(port, 5);
} 


int eyescan_sata_sgmii_all_lane() {
    int port;

    for(port=0;port<4;port++) {
        printf("\nEyescan for port-%d\n",port);
        eyescan_sub_sata_sgmii(port, 5);
    }
} 

int pkt_compare(int tx_port, int rx_port, u32 pn)
{
    u64 st_address1; 	
    int msg_num;
    u64 st_address2; 	
    u64 st_address3; 	
    u64 st_address4; 	
    u64 addr_1,addr_2;
    u64 addr_3,addr_4;
    u8 wn1[] = {1, 1, 1, 1, 1};
    u32 crc_data_tx,crc_data_rx;

    u64 n_msg_rx[4]={0};
    u64 ddr_base_tx_pkt[4]={0};
    u64 ddr_base_rx_pkt[4]={0};
    u64 k; 
    u64 temp_tx,temp_rx;
    int i;
    u32 timeout, pn_tmp;
    int temp=0;

    pn_tmp = pn/4; //required for comparing 4 bytes at a time
    q_state_t q_state_pq_32_1[50];
    q_state_t q_state_pq_33_1[50];
    q_state_t q_state_pq_34_1[50];
    q_state_t q_state_pq_35_1[50];

    q_state_t q_state_pq_64_1[50];
    q_state_t q_state_pq_65_1[50];
    q_state_t q_state_pq_66_1[50];
    q_state_t q_state_pq_67_1[50];

    timeout = 1000000;
    temp = 0;
    while(temp != SLT_MSG_NUM) {
        temp += read_rpkt_as[rx_port] = mac_stat_rd(PEMSTAT_RPKT__ADDR , rx_port);
        timeout--;
        if(timeout==0) {
            printf("PEMSTAT Read Timeout Timeout\n");
            printf("PEMSTAT_RPKT on port-%d: pkt_num:%d temp:%d\n", rx_port, read_rpkt_as[rx_port],temp);

            read_rfcs_as[rx_port] = mac_stat_rd(PEMSTAT_RFCS__ADDR , rx_port);
            if(read_rfcs_as[rx_port]) {
                total_err_count[rx_port]=0x40;
                printf("\nFAIL Port-%d (RFCS ERROR)\n",rx_port);
            }
            else {
                total_err_count[rx_port]=0x41;
                printf("\nFAIL Port-%d Packets Not Received (SERDES ERROR)\n",rx_port);
            }

            read_rfcs_as_bak[rx_port] += read_rfcs_as[rx_port]; 
            mac_stat_1g_sata();
            return 1;
        }
        read_rpkt_as_bak[rx_port] += read_rpkt_as[rx_port]; 
    }

    switch(tx_port) {
        case 0:
            USDELAY(1);// required for even for 1 pkt to read qstate
            QM_CHK_RET(qm_get_q_state_dir(1,32,1,wn1,&q_state_pq_32_1[0]));
            st_address1 = (q_state_pq_32_1[0].pqfp.st_addr);        // start addess of the queue 
            lprintf(8,"\nst_address_tx[0]     : 0x%x\n",st_address1);
            lprintf(8,"n_msg_tx[0]          : 0x%x\n",(q_state_pq_32_1[0].pqfp.n_msg));
            st_address2 = (st_address1<<8);                         // get proper 42 bit start address queue (by shifting 8 bits, refer QM DS)

            if(!(q_state_pq_32_1[0].pqfp.hd_ptr == 0))              // head pointer wraparound 
                st_address1 = (q_state_pq_32_1[0].pqfp.hd_ptr-2);   // get head pointer of queue 
            else 
                st_address1 = 0x3fe;                                // last head pointer of the queue  
            lprintf(8,"hd_prt_tx[0]         : 0x%x\n",st_address1);
            st_address2 += (st_address1<<4);                        // get proper head pointer (by shifting 4 bits, refer QM DS)

            st_address2 +=8;                                        // get the proper offest freePool buffer 
            lprintf(8,"st_address2[0]       : 0x%x\n",st_address2);
            st_address2 = qm_get_va(st_address2);                   // get the virtual address
            addr_1      = read_64((u64 *)st_address2);
            addr_1      &= 0x3ffffffffff;
            lprintf(8,"addr_1[0]            : 0x%x\n",addr_1);
            ddr_base_tx_pkt[0] = qm_get_va(addr_1);

            lprintf(8,"ddr_base_tx_pkt[0]   : 0x%x\n",ddr_base_tx_pkt[0]);
            lprintf(8,"hd_ptr_tx[0]         : 0x%x\n",q_state_pq_32_1[0].pqfp.hd_ptr);
            lprintf(8,"addr_1[0]            : 0x%x\n",addr_1);
            break;

        case 1:
            USDELAY(1);// required for even for 1 pkt to read qstate
            QM_CHK_RET(qm_get_q_state_dir(1,33,1,wn1,&q_state_pq_33_1[0]));
            st_address1 = (q_state_pq_33_1[0].pqfp.st_addr);        // start addess of the queue 
            lprintf(8,"\nst_address_tx[1]     : 0x%x\n",st_address1);
            lprintf(8,"n_msg_tx[1]          : 0x%x\n",(q_state_pq_33_1[0].pqfp.n_msg));
            st_address2 = (st_address1<<8);                         // get proper 42 bit start address queue (by shifting 8 bits, refer QM DS)

            if(!(q_state_pq_33_1[0].pqfp.hd_ptr == 0))              // head pointer wraparound 
                st_address1 = (q_state_pq_33_1[0].pqfp.hd_ptr - 2); // get head pointer of queue 
            else 
                st_address1 = 0x3fe;                                // last head pointer of the queue   
            lprintf(8,"hd_prt_tx[1]         : 0x%x\n",st_address1);
            st_address2 += (st_address1<<4);                        // get proper head pointer (by shifting 4 bits, refer QM DS)

            st_address2 +=8;                                        // get the proper offest freePool buffer 
            st_address2 = qm_get_va(st_address2);                   // get the virtual address
            addr_1      = read_64((u64 *)st_address2);
            addr_1      &= 0x3ffffffffff;
            lprintf(8,"addr_1[1]            : 0x%x\n",addr_1);
            ddr_base_tx_pkt[1] = qm_get_va(addr_1);

            lprintf(8,"ddr_base_tx_pkt[1]   : 0x%x\n",ddr_base_tx_pkt[1]);
            lprintf(8,"hd_ptr_tx[1]         : 0x%x\n",q_state_pq_33_1[0].pqfp.hd_ptr);
            lprintf(8,"addr_1[1]            : 0x%x\n",addr_1);
            break;

        case 2:
            USDELAY(1);// required for even for 1 pkt to read qstate
            QM_CHK_RET(qm_get_q_state_dir(1,34,1,wn1,&q_state_pq_34_1[0]));
            st_address1 = (q_state_pq_34_1[0].pqfp.st_addr);
            lprintf(8,"\nst_address_tx[2]     : 0x%x\n",st_address1);
            lprintf(8,"n_msg_tx[2]          : 0x%x\n",(q_state_pq_34_1[0].pqfp.n_msg));
            st_address2 = (st_address1<<8);
            if(!(q_state_pq_34_1[0].pqfp.hd_ptr == 0))
                st_address1 = (q_state_pq_34_1[0].pqfp.hd_ptr - 2);     // get head pointer of queue 
            else 
                st_address1 = 0x3fe;     
            lprintf(8,"hd_prt_tx[2]         : 0x%x\n",st_address1);
            st_address2 += (st_address1<<4);
            st_address2 +=8;
            st_address2 = qm_get_va(st_address2);
            addr_1      = read_64((u64 *)st_address2);
            addr_1      &= 0x3ffffffffff;
            lprintf(8,"addr_1[2]            : 0x%x\n",addr_1);
            ddr_base_tx_pkt[2] = qm_get_va(addr_1);

            lprintf(8,"ddr_base_tx_pkt[2]   : 0x%x\n",ddr_base_tx_pkt[2]);
            lprintf(8,"hd_ptr_tx[2]         : 0x%x\n",q_state_pq_34_1[0].pqfp.hd_ptr);
            lprintf(8,"addr_1[2]            : 0x%x\n",addr_1);
            break;

        case 3:
            USDELAY(1);// required for even for 1 pkt to read qstate
            QM_CHK_RET(qm_get_q_state_dir(1,35,1,wn1,&q_state_pq_35_1[0]));
            st_address1 = (q_state_pq_35_1[0].pqfp.st_addr);
            lprintf(8,"\nst_address_tx[3]     : 0x%x\n",st_address1);
            lprintf(8,"n_msg_tx[3]          : 0x%x\n",(q_state_pq_35_1[0].pqfp.n_msg));
            st_address2 = (st_address1<<8);
            if(!(q_state_pq_35_1[0].pqfp.hd_ptr == 0))
                st_address1 = (q_state_pq_35_1[0].pqfp.hd_ptr - 2);     // get head pointer of queue 
            else 
                st_address1 = 0x3fe;     
            lprintf(8,"hd_prt_tx[3]         : 0x%x\n",st_address1);
            st_address2 += (st_address1<<4);            

            st_address2 +=8;
            st_address2 = qm_get_va(st_address2);
            addr_1      = read_64((u64 *)st_address2);
            addr_1      &= 0x3ffffffffff;
            lprintf(8,"addr_1[3]            : 0x%x\n",addr_1);
            ddr_base_tx_pkt[3] = qm_get_va(addr_1);

            lprintf(8,"ddr_base_tx_pkt[3]   : 0x%x\n",ddr_base_tx_pkt[3]);
            lprintf(8,"hd_ptr_tx[3]         : 0x%x\n",q_state_pq_35_1[0].pqfp.hd_ptr);
            lprintf(8,"addr_1[3]            : 0x%x\n",addr_1);
            break;

defaut:
            printf("Wrong Port number\n");
    }
    switch(rx_port) {
        case 0:
            USDELAY(1);// required for even for 1 pkt to read qstate
            QM_CHK_RET(qm_get_q_state_dir(1,64,1,wn1,&q_state_pq_64_1[0]));
            timeout = 100000;
            while((q_state_pq_64_1[0].pqfp.n_msg)!= SLT_MSG_NUM) {          // Polling number of msg Tx-Msg=Rx-Msg
                QM_CHK_RET(qm_get_q_state_dir(1,64,1,wn1,&q_state_pq_64_1[0]));
                timeout--;
                if(timeout==0) {
                    printf("\nQueue State Timeout Timeout\n");
                    printf("n_msg_rx[0]          : 0x%x\n",(q_state_pq_64_1[0].pqfp.n_msg));
                    total_err_count[0]=0x50;
                    return 1;
                }
            }
            st_address1 = (q_state_pq_64_1[0].pqfp.st_addr);                // start addess of the queue 
            lprintf(8,"\nst_address_rx[0]     : 0x%x\n",st_address1);
            st_address2 = (st_address1<<8);                                 // get proper 42 bit start address queue (by shifting 8 bits, refer QM DS)
            lprintf(8,"n_msg_rx[0]           : 0x%x\t",(q_state_pq_64_1[0].pqfp.n_msg));   
            lprintf(8,"hd_ptr_rx[0]          : 0x%x\n",(q_state_pq_64_1[0].pqfp.hd_ptr));
            if(!((q_state_pq_64_1[0].pqfp.hd_ptr + 2*q_state_pq_64_1[0].pqfp.n_msg) == 0))      // get proper Rx buffer addresss
                st_address1 = (q_state_pq_64_1[0].pqfp.hd_ptr+ 2*q_state_pq_64_1[0].pqfp.n_msg -2);  
            else 
                st_address1 = 0x3fe;     
            st_address2 += (st_address1<<4);                    // get proper head pointer (by shifting 4 bits, refer QM DS)
            lprintf(8,"fetch_addr_rx[0]      : 0x%x\n",st_address1);
            st_address2 += 8;                                   // get the proper offest freePool buffer 
            st_address2 = qm_get_va(st_address2);               // get the virtual address
            addr_1 = read_64((u64 *)st_address2);
            addr_1 &= 0x3ffffffffff;
            lprintf(8,"addr_1[0]            : 0x%x\n",addr_1);
            ddr_base_rx_pkt[0] = qm_get_va(addr_1);

            lprintf(8,"ddr_base_rx_pkt[0]   : 0x%x\n",ddr_base_rx_pkt[0]);
            lprintf(8,"hd_ptr_rx[0]         : 0x%x\n",q_state_pq_33_1[0].pqfp.hd_ptr);
            lprintf(8,"addr_1[0]            : 0x%x\n",addr_1);
            data_cache_flush_all();
            lprintf(8,"data_cache_flush_all case-0\n");
            break;

        case 1:
            USDELAY(1);// required for even for 1 pkt to read qstate
            QM_CHK_RET(qm_get_q_state_dir(1,65,1,wn1,&q_state_pq_65_1[0]));
            lprintf(8,"\nst_address_rx[1]     : 0x%x\n",st_address1);
            timeout = 100000;
            while((q_state_pq_65_1[0].pqfp.n_msg)!= SLT_MSG_NUM) {
                QM_CHK_RET(qm_get_q_state_dir(1,65,1,wn1,&q_state_pq_65_1[0]));
                timeout--;
                if(timeout==0) {
                    printf("\nQueue State Timeout Timeout\n");
                    printf("n_msg_rx[1]          : 0x%x\n",(q_state_pq_65_1[0].pqfp.n_msg));
                    total_err_count[1]=0x50;
                    return 1;
                }                
            }
            st_address1 = (q_state_pq_65_1[0].pqfp.st_addr);    // start addess of the queue 
            lprintf(8,"st_address_rx[1]      : 0x%x\n",st_address1);
            n_msg_rx[1]+= (q_state_pq_65_1[0].pqfp.n_msg);
            lprintf(8,"n_msg_rx[1]           : 0x%x\t",(q_state_pq_65_1[0].pqfp.n_msg));
            lprintf(8,"hd_ptr_rx[1]          : 0x%x\n",(q_state_pq_65_1[0].pqfp.hd_ptr));
            st_address2 = (st_address1<<8);                     // get proper 42 bit start address queue (by shifting 8 bits, refer QM DS)
            if(!((q_state_pq_65_1[0].pqfp.hd_ptr+ 2*q_state_pq_65_1[0].pqfp.n_msg) == 0))
                st_address1 = (q_state_pq_65_1[0].pqfp.hd_ptr+ 2*q_state_pq_65_1[0].pqfp.n_msg-2);   // get head pointer of queue
            else 
                st_address1 = 0x3fe;     
            lprintf(8,"hd_ptr_rx[1]         : 0x%x\n",st_address1);
            st_address2 += (st_address1<<4);                    // get proper head pointer (by shifting 4 bits, refer QM DS)
            st_address2 +=8;                                    // get the proper offest freePool buffer 
            st_address2 = qm_get_va(st_address2);               // get the virtual address
            addr_1 = read_64((u64 *)st_address2);
            addr_1 &= 0x3ffffffffff;
            lprintf(8,"addr_1[1]            : 0x%x\n",addr_1);
            ddr_base_rx_pkt[1] = qm_get_va(addr_1);

            lprintf(8,"ddr_base_rx_pkt[1]   : 0x%x\n",ddr_base_rx_pkt[1]);
            lprintf(8,"hd_ptr_rx[1]         : 0x%x\n",q_state_pq_32_1[0].pqfp.hd_ptr);
            lprintf(8,"addr_1[1]            : 0x%x\n",addr_1);
            data_cache_flush_all();
            lprintf(8,"data_cache_flush_all case-1\n");
            break;

        case 2:
            USDELAY(1);// required for even for 1 pkt to read qstate
            QM_CHK_RET(qm_get_q_state_dir(1,66,1,wn1,&q_state_pq_66_1[0]));
            timeout = 100000;
            while((q_state_pq_66_1[0].pqfp.n_msg)!= SLT_MSG_NUM) {
                QM_CHK_RET(qm_get_q_state_dir(1,66,1,wn1,&q_state_pq_66_1[0]));
                timeout--;
                if(timeout==0) {
                    printf("\nQueue State Timeout Timeout\n");
                    printf("n_msg_rx[2]          : 0x%x\n",(q_state_pq_66_1[0].pqfp.n_msg));
                    total_err_count[2]=0x50;
                    return 1;
                }                
            }
            st_address1 = (q_state_pq_66_1[0].pqfp.st_addr);
            n_msg_rx[2]+= (q_state_pq_66_1[0].pqfp.n_msg);
            lprintf(8,"n_msg_rx[2]          : 0x%x\t",(q_state_pq_66_1[0].pqfp.n_msg));
            lprintf(8,"hd_ptr_rx[2]         : 0x%x\n",(q_state_pq_66_1[0].pqfp.hd_ptr));
            lprintf(8,"\nst_address_rx[2]   : 0x%x\n",st_address1);
            st_address2 = (st_address1<<8);
            if(!((q_state_pq_66_1[0].pqfp.hd_ptr+ 2*q_state_pq_66_1[0].pqfp.n_msg) == 0))
                st_address1 = (q_state_pq_66_1[0].pqfp.hd_ptr+ 2*q_state_pq_66_1[0].pqfp.n_msg -2);   // get head pointer of queue
            else 
                st_address1 = 0x3fe;     
            lprintf(8,"st_address_rx[2]     : 0x%x\n",st_address1);
            st_address2 += (st_address1<<4);
            st_address2+=8;
            st_address2 = qm_get_va(st_address2);
            addr_1 = read_64((u64 *)st_address2);
            addr_1 &= 0x3ffffffffff;
            lprintf(8,"addr_1[2]            : 0x%x\n",addr_1);
            ddr_base_rx_pkt[2] = qm_get_va(addr_1);

            lprintf(8,"ddr_base_rx_pkt[2]   : 0x%x\n",ddr_base_rx_pkt[2]);
            lprintf(8,"hd_ptr_rx[2]         : 0x%x\n",q_state_pq_35_1[0].pqfp.hd_ptr);
            lprintf(8,"addr_1[2]            : 0x%x\n",addr_1);
            data_cache_flush_all();
            lprintf(8,"data_cache_flush_all case-2\n");
            break;

        case 3:
            USDELAY(1);// required for even for 1 pkt to read qstate
            QM_CHK_RET(qm_get_q_state_dir(1,67,1,wn1,&q_state_pq_67_1[0]));
            timeout = 100000;
            while((q_state_pq_67_1[0].pqfp.n_msg)!= SLT_MSG_NUM) {
                QM_CHK_RET(qm_get_q_state_dir(1,67,1,wn1,&q_state_pq_67_1[0]));
                timeout--;
                if(timeout==0) {
                    printf("\nQueue State Timeout Timeout\n");
                    printf("n_msg_rx[3]          : 0x%x\n",(q_state_pq_67_1[0].pqfp.n_msg));
                    total_err_count[3]=0x50;                      
                    return 1;
                }                
            }
            st_address1 = (q_state_pq_67_1[0].pqfp.st_addr);
            n_msg_rx[3]+= (q_state_pq_67_1[0].pqfp.n_msg);
            lprintf(8,"n_msg_rx[3]          : 0x%x\t",(q_state_pq_67_1[0].pqfp.n_msg));
            lprintf(8,"hd_ptr_rx[3]         : 0x%x\n",(q_state_pq_67_1[0].pqfp.hd_ptr));
            st_address2 = (st_address1<<8);
            if(!((q_state_pq_67_1[0].pqfp.hd_ptr+ 2*q_state_pq_67_1[0].pqfp.n_msg) == 0))
                st_address1 = (q_state_pq_67_1[0].pqfp.hd_ptr+ 2*q_state_pq_67_1[0].pqfp.n_msg -2);   // get head pointer of queue
            else 
                st_address1 = 0x3fe;     
            lprintf(8,"st_address_rx[3]     : 0x%x\n",st_address1);
            st_address2 += (st_address1<<4);
            st_address2+=8;
            st_address2 = qm_get_va(st_address2); //works for DIMM suze (1/2/4/8/16GB)
            addr_1 = read_64((u64 *)st_address2);
            addr_1 &= 0x3ffffffffff;
            lprintf(8,"addr_1[3]            : 0x%x\n",addr_1);
            ddr_base_rx_pkt[3] = qm_get_va(addr_1);

            lprintf(8,"ddr_base_rx_pkt[3]   : 0x%x\n",ddr_base_rx_pkt[2]);
            lprintf(8,"hd_ptr_rx[3]         : 0x%x\n",q_state_pq_34_1[0].pqfp.hd_ptr);
            lprintf(8,"addr_1[3]            : 0x%x\n",addr_1);
            data_cache_flush_all();
            lprintf(8,"data_cache_flush_all case-3\n");
            break;
        default :
            printf("Worng port\n");
    }

    return 0;
}

int eth_tx2rx_lpbk_test_sata_1g_ext_lpbk() {

    total_err_count[0]=0;
    total_err_count[1]=0;
    total_err_count[2]=0;
    total_err_count[3]=0;
    unsigned int ps,pn,temp;
    u64 *guess;
    qm_ret_t ret;
    enq_req_t *per;
    enq_req_t *per32;
    enq_req_t *per33;
    enq_req_t *per34;    
    qm_buf_t qm_buf;
    qm_buf_t qm_buf32;
    qm_buf_t qm_buf33;
    qm_buf_t qm_buf34;    
    enq_cfg_t enq_cfg;
    q_state_t cfg;
    int tx_port,rx_port, mn; 
    int port,i,retval;
    u32 fpqid, dots;
    u8 pdl_pattern,qmid;
    u16 tx_enq_qid, rx_deq_qid;

    qm_buf.bp = buf;
    qm_buf32.bp = buf32;
    qm_buf33.bp = buf33;
    qm_buf34.bp = buf34; 

    memset ((u8 *)msgbuf, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    memset ((u8 *)msgbuf32, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    memset ((u8 *)msgbuf33, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    memset ((u8 *)msgbuf34, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);

#ifdef RANDOMIZE_SLT    
    ps=(rand()%1454)+64; 
#else    
    ps=512; //256; 
#endif    
    pn=0x40000; //0x140000; //0x40000; //0x280000; //0x100000; //10; //10000; //100;
    //printf("\n\nEnter No of packets in hex : 0x");pn = get_val(); //pn = get_val(); 

    for(port=0; port<4; port++) {
        if(!(sgmii_core_link_check(port,ENET))) {
            printf("\nPort-%d SGMII Core Link is DOWN!!!!\n",port);
            total_err_count[port] = 0x10; 
        }
    }

    if(total_err_count[0] || total_err_count[1] || total_err_count[2] || total_err_count[3]) return 1;

    if(!(port_link_check(0x11))) {
        printf("\nPort-0 Link is DOWN!!!!\n");
        printf("Please Connect CAT-5 Cable From Port-0 to Port-1, Then Rerun the Test\n");
        total_err_count[0] = 0x20;
    }
    if(!(port_link_check(0x12))) {
        printf("\nPort-1 Link is DOWN!!!!\n");
        printf("Please Connect CAT-5 Cable From Port-1 to Port-0, Then Rerun the Test\n");
        total_err_count[1] = 0x20;
    }
    if(!(port_link_check(0x13))) {
        printf("\nPort-2 Link is DOWN!!!!\n");
        printf("Please Connect CAT-5 Cable From Port-2 to Port-3, Then Rerun the Test\n");
        total_err_count[2] = 0x20;
    }
    if(!(port_link_check(0x14))) {
        printf("\nPort-3 Link is DOWN!!!!\n");
        printf("Please Connect CAT-5 Cable From Port-3 to Port-2, Then Rerun the Test\n");
        total_err_count[3] = 0x20;        
    }
    
    if(total_err_count[0] || total_err_count[1] || total_err_count[2] || total_err_count[3]) return 1;

    printf("\nTotal no. of packets =%d Enqueued at a time with no of pkts :%d with pkt size: %d... \n",pn,SLT_MSG_NUM, ps);
    printf("Number of Packets Expected to Transmit and Receive:%d\n",(pn*SLT_MSG_NUM));
    printf("\nRunning Ethernet Traffic [");

    pn = pn*4;
    dots = pn/20;
    qmid = 1;
    mn = QM_TEST_MSG_NUM; 

    fpqid=0;
    ret = sys_alloc_enet_buf(qmid, fpqid, mn, &qm_buf); 
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf Fail qmid:%d\r\n",qmid);
        return ret;
    }
    fpqid=1;
    ret = sys_alloc_enet_buf(qmid, fpqid, mn, &qm_buf32); 
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf qm_buf32 Fail qmid:%d\r\n",qmid);
        return ret;
    }
    fpqid=2;
    ret = sys_alloc_enet_buf(qmid, fpqid, mn, &qm_buf33); 
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf qm_buf33 Fail qmid:%d\r\n",qmid);
        return ret;
    }
    fpqid=3;
    ret = sys_alloc_enet_buf(qmid, fpqid, mn, &qm_buf34); 
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf qm_buf34 Fail qmid:%d\r\n",qmid);
        return ret;
    }

    pdl_pattern=0xAA;
    ret = qm_build_eth_pkt_pdl((unsigned char *)buf[0], ps, pdl_pattern);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt_pdl Fail qmid:%d\r\n",qmid);
        return ret;

    }    
    pdl_pattern=0x55; //0xBB;
    ret = qm_build_eth_pkt_pdl((unsigned char *)buf32[0], ps, pdl_pattern);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt_pdl buf32 Fail qmid:%d\r\n",qmid);
        return ret;

    }    
    pdl_pattern=0xAA; //0xCC;
    ret = qm_build_eth_pkt_pdl((unsigned char *)buf33[0], ps, pdl_pattern);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt_pdl buf33 Fail qmid:%d\r\n",qmid);
        return ret;

    }    
    pdl_pattern=0x55; //0xDD;
    ret = qm_build_eth_pkt_pdl((unsigned char *)buf34[0], ps, pdl_pattern);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt_pdl buf34 Fail qmid:%d\r\n",qmid);
        return ret;

    }

    per = sys_enet_enq_cfg(buf[0], ps);
    extern enq_req_t er;
    per = &er;
    if (!per) {
        printf("QM sys_enet_enq_cfg failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }
    per32 = sys_enet_enq_cfg32(buf32[0], ps);
    extern enq_req_t er32;
    per32 = &er32;
    if (!per32) {
        printf("QM sys_enet_enq_cfg32 failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }
    per33 = sys_enet_enq_cfg33(buf33[0], ps);
    extern enq_req_t er33;
    per33 = &er33;
    if (!per33) {
        printf("QM sys_enet_enq_cfg33 failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }
    per34 = sys_enet_enq_cfg34(buf34[0], ps);
    extern enq_req_t er34;
    per34 = &er34;
    if (!per34) {
        printf("QM sys_enet_enq_cfg34 failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }

    for(i=0; i<pn; i++) {
        if((i%4) == 0) {
            dcache_flush_all();
            tx_port=0;  rx_port=1;	
            tx_enq_qid = QID32; rx_deq_qid = QID65;
            per->qid =  tx_enq_qid;     // port-0
            ret = qm_proc_enq_dir(qmid,per);
            if (ret != QM_OK) {
                printf("\nQM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count[0] = 0x30;
                return ret;
            }
            retval = pkt_compare(tx_port, rx_port, ps);
            if(retval)
                return 1;
            mn=SLT_MSG_NUM;
            while(mn) {
                mn = SLT_MSG_NUM;
                ret = qm_proc_deq_dir(qmid, rx_deq_qid, QM_MSG_SZ_32B, &mn, msgbuf); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    total_err_count[0] = 0x31;
                    return ret;
                }
                mn=0; 
            }
        }
        else if((i%4) == 1)  {
            dcache_flush_all();
            tx_port=1; rx_port=0;
            tx_enq_qid = QID33; rx_deq_qid = QID64;	
            per32->qid = tx_enq_qid;     // port-1
            ret = qm_proc_enq_dir(qmid,per32);
            if (ret != QM_OK) {
                printf("\nQM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count[1] = 0x30;
                return ret;
            }            
            retval = pkt_compare(tx_port, rx_port, ps);
            if(retval)
                return 1;            
            mn=SLT_MSG_NUM;
            while(mn) {
                mn = SLT_MSG_NUM;
                ret = qm_proc_deq_dir(qmid, rx_deq_qid, QM_MSG_SZ_32B, &mn, msgbuf32); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    total_err_count[1] = 0x31;
                    return ret;
                }
                mn=0; 
            }
        } 
        else if((i%4) == 2)  {
            dcache_flush_all();
            tx_port=2; rx_port=3;	
            tx_enq_qid = QID34; rx_deq_qid = QID67;
            per33->qid = tx_enq_qid;    // port-1
            ret = qm_proc_enq_dir(qmid,per33);
            if (ret != QM_OK) {
                printf("\nQM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count[2]=0x30;
                return ret;
            }             
            retval = pkt_compare(tx_port, rx_port ,ps);
            if(retval)
                return 1;            
            mn=SLT_MSG_NUM;
            while(mn) {
                mn = SLT_MSG_NUM;
                ret = qm_proc_deq_dir(qmid, rx_deq_qid, QM_MSG_SZ_32B, &mn, msgbuf33); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    total_err_count[2] = 0x31;
                    return ret;
                }
                mn=0; 
            }
        }
        else if((i%4) == 3)  {
            dcache_flush_all();
            tx_port=3; rx_port=2;
            tx_enq_qid = QID35;	 rx_deq_qid = QID66;    
            per34->qid = tx_enq_qid;     // port-1
            ret = qm_proc_enq_dir(qmid,per34);
            if (ret != QM_OK) {
                printf("\nQM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count[3]=0x30;
                return ret;
            }             
            retval = pkt_compare(tx_port, rx_port, ps);
            if(retval)
                return 1;            
            mn=SLT_MSG_NUM;
            while(mn) {
                mn = SLT_MSG_NUM;
                ret = qm_proc_deq_dir(qmid, rx_deq_qid, QM_MSG_SZ_32B, &mn, msgbuf34); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    total_err_count[3] = 0x31;
                    return ret;
                }
                mn=0; 
            }
        }

        lprintf(8, "\n<----------------- PortNo:%d PacketNo:%d ------------------->\n",(i%4),(i/4));
        if ((i%dots)==0) printf(".");
    }
    printf("]\n");
    return 0;
}

int eth_tx2rx_lpbk_test_sata_1g_int_lpbk() {

    total_err_count[0]=0;
    total_err_count[1]=0;
    total_err_count[2]=0;
    total_err_count[3]=0;
    unsigned int ps,pn,temp;
    u64 *guess;
    qm_ret_t ret;
    enq_req_t *per;
    enq_req_t *per32;
    enq_req_t *per33;
    enq_req_t *per34;    
    qm_buf_t qm_buf;
    qm_buf_t qm_buf32;
    qm_buf_t qm_buf33;
    qm_buf_t qm_buf34;    
    enq_cfg_t enq_cfg;
    q_state_t cfg;
    int tx_port,rx_port, mn; 
    int port,i,retval;
    u32 fpqid, dots;
    u8 pdl_pattern,qmid;
    u16 tx_enq_qid, rx_deq_qid;

    qm_buf.bp = buf;
    qm_buf32.bp = buf32;
    qm_buf33.bp = buf33;
    qm_buf34.bp = buf34; 

    memset ((u8 *)msgbuf, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    memset ((u8 *)msgbuf32, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    memset ((u8 *)msgbuf33, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    memset ((u8 *)msgbuf34, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);

#ifdef RANDOMIZE_SLT    
    ps=(rand()%1454)+64; 
#else    
    ps=512; //256; 
#endif    
    pn=0x40000; //0x140000; //0x40000; //0x280000; //0x100000; //10; //10000; //100;
    //printf("\n\nEnter No of packets in hex : 0x");pn = get_val(); //pn = get_val(); 
    lprintf(3,"\nSERDES Tx-2-Rx Internal loopback mode test SATA-SGMII\n"); 

    for(port=0; port<4; port++) {
        if(!(sgmii_core_link_check(port,ENET))) {
            printf("\nPort-%d SGMII Core Link is DOWN!!!!\n",port);
            total_err_count[port] = 0x10; 
        }
    }

    if(total_err_count[0] || total_err_count[1] || total_err_count[2] || total_err_count[3]) return 1;

    printf("\nTotal no. of packets =%d Enqueued at a time with no of pkts :%d with pkt size: %d... \n",pn,SLT_MSG_NUM, ps);
    printf("Number of Packets Expected to Transmit and Receive:%d\n",(pn*SLT_MSG_NUM));
    printf("\nRunning Ethernet Traffic [");

    pn = pn*4;
    dots = pn/20;
    qmid = 1;
    mn = QM_TEST_MSG_NUM; 

    fpqid=0;
    ret = sys_alloc_enet_buf(qmid, fpqid, mn, &qm_buf); 
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf Fail qmid:%d\r\n",qmid);
        return ret;
    }
    fpqid=1;
    ret = sys_alloc_enet_buf(qmid, fpqid, mn, &qm_buf32); 
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf qm_buf32 Fail qmid:%d\r\n",qmid);
        return ret;
    }
    fpqid=2;
    ret = sys_alloc_enet_buf(qmid, fpqid, mn, &qm_buf33); 
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf qm_buf33 Fail qmid:%d\r\n",qmid);
        return ret;
    }
    fpqid=3;
    ret = sys_alloc_enet_buf(qmid, fpqid, mn, &qm_buf34);
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf qm_buf34 Fail qmid:%d\r\n",qmid);
        return ret;
    }

    pdl_pattern=0xAA;
    ret = qm_build_eth_pkt_pdl((unsigned char *)buf[0], ps, pdl_pattern);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt_pdl Fail qmid:%d\r\n",qmid);
        return ret;

    }    
    pdl_pattern=0x55; //0xBB;
    ret = qm_build_eth_pkt_pdl((unsigned char *)buf32[0], ps, pdl_pattern);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt_pdl buf32 Fail qmid:%d\r\n",qmid);
        return ret;

    }    
    pdl_pattern=0xAA; //0xCC;
    ret = qm_build_eth_pkt_pdl((unsigned char *)buf33[0], ps, pdl_pattern);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt_pdl buf33 Fail qmid:%d\r\n",qmid);
        return ret;

    }    
    pdl_pattern=0x55; //0xDD;
    ret = qm_build_eth_pkt_pdl((unsigned char *)buf34[0], ps, pdl_pattern);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt_pdl buf34 Fail qmid:%d\r\n",qmid);
        return ret;

    }

    per = sys_enet_enq_cfg(buf[0], ps);
    extern enq_req_t er;
    per = &er;
    if (!per) {
        printf("QM sys_enet_enq_cfg failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }
    per32 = sys_enet_enq_cfg32(buf32[0], ps);
    extern enq_req_t er32;
    per32 = &er32;
    if (!per32) {
        printf("QM sys_enet_enq_cfg32 failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }
    per33 = sys_enet_enq_cfg33(buf33[0], ps);
    extern enq_req_t er33;
    per33 = &er33;
    if (!per33) {
        printf("QM sys_enet_enq_cfg33 failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }
    per34 = sys_enet_enq_cfg34(buf34[0], ps);
    extern enq_req_t er34;
    per34 = &er34;
    if (!per34) {
        printf("QM sys_enet_enq_cfg34 failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }

    for(i=0; i<pn; i++) {
        if((i%4) == 0) {
            dcache_flush_all();
            tx_port=0;  rx_port=0;	
            tx_enq_qid = QID32; rx_deq_qid = QID64;
            per->qid =  tx_enq_qid;     // port-0
            ret = qm_proc_enq_dir(qmid,per);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count[0] = 0x30;
                return ret;
            }
            retval = pkt_compare(tx_port, rx_port, ps);
            if(retval)
                return 1;            
            mn=SLT_MSG_NUM;
            while(mn) {
                mn = SLT_MSG_NUM;
                ret = qm_proc_deq_dir(qmid, rx_deq_qid, QM_MSG_SZ_32B, &mn, msgbuf); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    total_err_count[0] = 0x31;
                    return ret;
                }
                mn=0; 
            }
        }
        else if((i%4) == 1)  {
            dcache_flush_all();
            tx_port=1; rx_port=1;
            tx_enq_qid = QID33; rx_deq_qid = QID65;	
            per32->qid = tx_enq_qid;     // port-1
            ret = qm_proc_enq_dir(qmid,per32);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count[1] = 0x30;
                return ret;
            }            
            retval = pkt_compare(tx_port, rx_port, ps);
            if(retval)
                return 1;              
            mn=SLT_MSG_NUM;
            while(mn) {
                mn = SLT_MSG_NUM;
                ret = qm_proc_deq_dir(qmid, rx_deq_qid, QM_MSG_SZ_32B, &mn, msgbuf32); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    total_err_count[1] = 0x31;
                    return ret;
                }
                mn=0; 
            }
        } 
        else if((i%4) == 2)  {
            dcache_flush_all();
            tx_port=2; rx_port=2;	
            tx_enq_qid = QID34; rx_deq_qid = QID66;
            per33->qid = tx_enq_qid;    // port-1
            ret = qm_proc_enq_dir(qmid,per33);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count[2]=0x30;
                return ret;
            }             
            retval = pkt_compare(tx_port, rx_port ,ps);
            if(retval)
                return 1;              
            mn=SLT_MSG_NUM;
            while(mn) {
                mn = SLT_MSG_NUM;
                ret = qm_proc_deq_dir(qmid, rx_deq_qid, QM_MSG_SZ_32B, &mn, msgbuf33); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    total_err_count[2] = 0x31;
                    return ret;
                }
                mn=0; 
            }
        }
        else if((i%4) == 3)  {
            dcache_flush_all();
            tx_port=3; rx_port=3;
            tx_enq_qid = QID35;	 rx_deq_qid = QID67;    
            per34->qid = tx_enq_qid;     // port-1
            ret = qm_proc_enq_dir(qmid,per34);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count[3]=0x30;
                return ret;
            }             
            retval = pkt_compare(tx_port, rx_port, ps);
            if(retval)
                return 1;              
            mn=SLT_MSG_NUM;
            while(mn) {
                mn = SLT_MSG_NUM;
                ret = qm_proc_deq_dir(qmid, rx_deq_qid, QM_MSG_SZ_32B, &mn, msgbuf34); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    total_err_count[3] = 0x31;
                    return ret;
                }
                mn=0; 
            }
        }

        lprintf(8, "\n<----------------- PortNo:%d PacketNo:%d ------------------->\n",(i%4),(i/4));
        if ((i%dots)==0) printf(".");
    }
    printf("]\n");
    return 0;
}

void phy_autoneg_bypass_sts() {
    int port;

    total_err_count[0]=0;
    total_err_count[1]=0;
    total_err_count[2]=0;
    total_err_count[3]=0;
    
    set_serial_interface_autoneg_bypass(0x11);
    set_serial_interface_autoneg_bypass(0x12);
    set_serial_interface_autoneg_bypass(0x13);
    set_serial_interface_autoneg_bypass(0x14);

    printf("\nDelay,");
    USDELAY(10000);
    printf("Done");

    for(port=0; port<4; port++) {
        if(!(sgmii_core_link_check(port,ENET))) {
            printf("\nPort-%d SGMII Core Link is DOWN!!!!\n",port);
            total_err_count[port] = 0x10; 
        }
    }

    if(!(check_phy_autoneg_bypass_sts(0x11))) {
        printf("\nPort-0 Serial Interface AutoNegotiation Bypass Status Link DOWN!!!!\n");
        total_err_count[port] = 0x11; 
    }
    if(!(check_phy_autoneg_bypass_sts(0x12))) {
        printf("\nPort-1 Serial Interface AutoNegotiation Bypass Status Link DOWN!!!!\n");
        total_err_count[port] = 0x11; 
    }
    if(!(check_phy_autoneg_bypass_sts(0x13))) {
        printf("\nPort-2 Serial Interface AutoNegotiation Bypass Status Link DOWN!!!!\n");
        total_err_count[port] = 0x11; 
    }
    if(!(check_phy_autoneg_bypass_sts(0x14))) {
        printf("\nPort-3 Serial Interface AutoNegotiation Bypass Status Link DOWN!!!!\n");
        total_err_count[port] = 0x11; 
    }
#if 0
    if(!(port_link_check(0x11))) {
        printf("\nPort-0 Link is DOWN!!!!\n");
        printf("Please Connect CAT-5 Cable From Port-0 to Port-1, Then Rerun the Test\n");
        total_err_count[0] = 0x20;
    }
    if(!(port_link_check(0x12))) {
        printf("\nPort-1 Link is DOWN!!!!\n");
        printf("Please Connect CAT-5 Cable From Port-1 to Port-0, Then Rerun the Test\n");
        total_err_count[1] = 0x20;
    }
    if(!(port_link_check(0x13))) {
        printf("\nPort-2 Link is DOWN!!!!\n");
        printf("Please Connect CAT-5 Cable From Port-2 to Port-3, Then Rerun the Test\n");
        total_err_count[2] = 0x20;
    }
    if(!(port_link_check(0x14))) {
        printf("\nPort-3 Link is DOWN!!!!\n");
        printf("Please Connect CAT-5 Cable From Port-3 to Port-2, Then Rerun the Test\n");
        total_err_count[3] = 0x20;        
    }
#endif
    if(total_err_count[0] || total_err_count[1] || total_err_count[2] || total_err_count[3]) return 1;
}

int eth_dbg_sata() {

    total_err_count[0]=0;
    total_err_count[1]=0;
    total_err_count[2]=0;
    total_err_count[3]=0;
    unsigned int ps,pn,temp;
    u64 *guess;
    qm_ret_t ret;
    enq_req_t *per;
    enq_req_t *per32;
    enq_req_t *per33;
    enq_req_t *per34;    
    qm_buf_t qm_buf;
    qm_buf_t qm_buf32;
    qm_buf_t qm_buf33;
    qm_buf_t qm_buf34;    
    enq_cfg_t enq_cfg;
    q_state_t cfg;
    int tx_port,rx_port, mn; 
    int port,i,retval;
    u32 fpqid, dots;
    u8 pdl_pattern,qmid;
    u16 tx_enq_qid, rx_deq_qid;

    qm_buf.bp = buf;
    qm_buf32.bp = buf32;
    qm_buf33.bp = buf33;
    qm_buf34.bp = buf34; 

    memset ((u8 *)msgbuf, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    memset ((u8 *)msgbuf32, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    memset ((u8 *)msgbuf33, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    memset ((u8 *)msgbuf34, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);

#ifdef RANDOMIZE_SLT    
    ps=(rand()%1454)+64; 
#else    
    ps=512; //256; 
#endif    
    pn=0x40000; //0x140000; //0x40000; //0x280000; //0x100000; //10; //10000; //100;
    printf("\nSATA-SGMII Test\n");
    printf("\n\nEnter No of packets in hex : 0x");pn = get_val(); //pn = get_val(); 

    for(port=0; port<4; port++) {
        if(!(sgmii_core_link_check(port,ENET))) {
            printf("\nPort-%d SGMII Core Link is DOWN!!!!\n",port);
            total_err_count[port] = 0x10; 
        }
    }

    if(total_err_count[0] || total_err_count[1] || total_err_count[2] || total_err_count[3]) return 1;

    if(!(port_link_check(0x11))) {
        printf("\nPort-0 Link is DOWN!!!!\n");
        printf("Please Connect CAT-5 Cable From Port-0 to Port-1, Then Rerun the Test\n");
        total_err_count[0] = 0x20;
    }
    if(!(port_link_check(0x12))) {
        printf("\nPort-1 Link is DOWN!!!!\n");
        printf("Please Connect CAT-5 Cable From Port-1 to Port-0, Then Rerun the Test\n");
        total_err_count[1] = 0x20;
    }
    if(!(port_link_check(0x13))) {
        printf("\nPort-2 Link is DOWN!!!!\n");
        printf("Please Connect CAT-5 Cable From Port-2 to Port-3, Then Rerun the Test\n");
        total_err_count[2] = 0x20;
    }
    if(!(port_link_check(0x14))) {
        printf("\nPort-3 Link is DOWN!!!!\n");
        printf("Please Connect CAT-5 Cable From Port-3 to Port-2, Then Rerun the Test\n");
        total_err_count[3] = 0x20;        
    }
    
    if(total_err_count[0] || total_err_count[1] || total_err_count[2] || total_err_count[3]) return 1;

    printf("\nTotal no. of packets =%d Enqueued at a time with no of pkts :%d with pkt size: %d... \n",pn,SLT_MSG_NUM, ps);
    printf("Number of Packets Expected to Transmit and Receive:%d\n",(pn*SLT_MSG_NUM));
    printf("\nRunning Ethernet Traffic [");

    pn = pn*4;
    dots = pn/20;
    qmid = 1;
    mn = QM_TEST_MSG_NUM; 

    fpqid=0;
    ret = sys_alloc_enet_buf(qmid, fpqid, mn, &qm_buf); 
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf Fail qmid:%d\r\n",qmid);
        return ret;
    }
    fpqid=1;
    ret = sys_alloc_enet_buf(qmid, fpqid, mn, &qm_buf32); 
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf qm_buf32 Fail qmid:%d\r\n",qmid);
        return ret;
    }
    fpqid=2;
    ret = sys_alloc_enet_buf(qmid, fpqid, mn, &qm_buf33); 
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf qm_buf33 Fail qmid:%d\r\n",qmid);
        return ret;
    }
    fpqid=3;
    ret = sys_alloc_enet_buf(qmid, fpqid, mn, &qm_buf34); 
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf qm_buf34 Fail qmid:%d\r\n",qmid);
        return ret;
    }

    pdl_pattern=0xAA;
    ret = qm_build_eth_pkt_pdl((unsigned char *)buf[0], ps, pdl_pattern);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt_pdl Fail qmid:%d\r\n",qmid);
        return ret;

    }    
    pdl_pattern=0x55; //0xBB;
    ret = qm_build_eth_pkt_pdl((unsigned char *)buf32[0], ps, pdl_pattern);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt_pdl buf32 Fail qmid:%d\r\n",qmid);
        return ret;

    }    
    pdl_pattern=0xAA; //0xCC;
    ret = qm_build_eth_pkt_pdl((unsigned char *)buf33[0], ps, pdl_pattern);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt_pdl buf33 Fail qmid:%d\r\n",qmid);
        return ret;

    }    
    pdl_pattern=0x55; //0xDD;
    ret = qm_build_eth_pkt_pdl((unsigned char *)buf34[0], ps, pdl_pattern);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt_pdl buf34 Fail qmid:%d\r\n",qmid);
        return ret;

    }

    per = sys_enet_enq_cfg(buf[0], ps);
    extern enq_req_t er;
    per = &er;
    if (!per) {
        printf("QM sys_enet_enq_cfg failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }
    per32 = sys_enet_enq_cfg32(buf32[0], ps);
    extern enq_req_t er32;
    per32 = &er32;
    if (!per32) {
        printf("QM sys_enet_enq_cfg32 failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }
    per33 = sys_enet_enq_cfg33(buf33[0], ps);
    extern enq_req_t er33;
    per33 = &er33;
    if (!per33) {
        printf("QM sys_enet_enq_cfg33 failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }
    per34 = sys_enet_enq_cfg34(buf34[0], ps);
    extern enq_req_t er34;
    per34 = &er34;
    if (!per34) {
        printf("QM sys_enet_enq_cfg34 failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }

    for(i=0; i<pn; i++) {
        if((i%4) == 0) {
            dcache_flush_all();
            tx_port=0;  rx_port=1;	
            tx_enq_qid = QID32; rx_deq_qid = QID65;
            per->qid =  tx_enq_qid;     // port-0
            ret = qm_proc_enq_dir(qmid,per);
            if (ret != QM_OK) {
                printf("\nQM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count[0] = 0x30;
                return ret;
            }
            retval = pkt_compare(tx_port, rx_port, ps);
            if(retval)
                return 1;
            mn=SLT_MSG_NUM;
            while(mn) {
                mn = SLT_MSG_NUM;
                ret = qm_proc_deq_dir(qmid, rx_deq_qid, QM_MSG_SZ_32B, &mn, msgbuf); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    total_err_count[0] = 0x31;
                    return ret;
                }
                mn=0; 
            }
        }
        else if((i%4) == 1)  {
            dcache_flush_all();
            tx_port=1; rx_port=0;
            tx_enq_qid = QID33; rx_deq_qid = QID64;	
            per32->qid = tx_enq_qid;     // port-1
            ret = qm_proc_enq_dir(qmid,per32);
            if (ret != QM_OK) {
                printf("\nQM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count[1] = 0x30;
                return ret;
            }            
            retval = pkt_compare(tx_port, rx_port, ps);
            if(retval)
                return 1;            
            mn=SLT_MSG_NUM;
            while(mn) {
                mn = SLT_MSG_NUM;
                ret = qm_proc_deq_dir(qmid, rx_deq_qid, QM_MSG_SZ_32B, &mn, msgbuf32); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    total_err_count[1] = 0x31;
                    return ret;
                }
                mn=0; 
            }
        } 
        else if((i%4) == 2)  {
            dcache_flush_all();
            tx_port=2; rx_port=3;	
            tx_enq_qid = QID34; rx_deq_qid = QID67;
            per33->qid = tx_enq_qid;    // port-1
            ret = qm_proc_enq_dir(qmid,per33);
            if (ret != QM_OK) {
                printf("\nQM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count[2]=0x30;
                return ret;
            }             
            retval = pkt_compare(tx_port, rx_port ,ps);
            if(retval)
                return 1;            
            mn=SLT_MSG_NUM;
            while(mn) {
                mn = SLT_MSG_NUM;
                ret = qm_proc_deq_dir(qmid, rx_deq_qid, QM_MSG_SZ_32B, &mn, msgbuf33); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    total_err_count[2] = 0x31;
                    return ret;
                }
                mn=0; 
            }
        }
        else if((i%4) == 3)  {
            dcache_flush_all();
            tx_port=3; rx_port=2;
            tx_enq_qid = QID35;	 rx_deq_qid = QID66;    
            per34->qid = tx_enq_qid;     // port-1
            ret = qm_proc_enq_dir(qmid,per34);
            if (ret != QM_OK) {
                printf("\nQM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count[3]=0x30;
                return ret;
            }             
            retval = pkt_compare(tx_port, rx_port, ps);
            if(retval)
                return 1;            
            mn=SLT_MSG_NUM;
            while(mn) {
                mn = SLT_MSG_NUM;
                ret = qm_proc_deq_dir(qmid, rx_deq_qid, QM_MSG_SZ_32B, &mn, msgbuf34); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    total_err_count[3] = 0x31;
                    return ret;
                }
                mn=0; 
            }
        }

        lprintf(8, "\n<----------------- PortNo:%d PacketNo:%d ------------------->\n",(i%4),(i/4));
        if ((i%dots)==0) printf(".");
    }
    printf("]\n");
    return 0;
}

void mac_ind_write_mode (int port, int addr, int data2, int data1, int data0) {
    int display = 0;
    if     (mac_mode_1g==2)  mcxmac_ind_wr(addr,data2,ENET,port,display); 
    else if(mac_mode_1g==1)  mcxmac_ind_wr(addr,data1,ENET,port,display);
    else                  mcxmac_ind_wr(addr,data0,ENET,port,display);
}

void enet_reg_wr_mode (int port, int addr, int data2, int data1, int data0) {
    int display = 0;
    if     (mac_mode_1g==2) eth_wr(addr, data2,ENET,port,display);
    else if(mac_mode_1g==1) eth_wr(addr, data1,ENET,port,display);
    else                 eth_wr(addr, data0,ENET,port,display);
}


int init_enet_serdes(int inst, int refclk) {
    int loop = 30;
    int pll_ready;
    int vco_fail;
    int port;
    u32 timeout=100000;
    int retval;

    do {
        serdes_pdown_force_vco(inst,0); // FIXME
        USDELAY(10);
        pll_ready = sm_enet_module_init_enet_serdes(inst, refclk,tx2rx_serdes_lb_1g);
        USDELAY(10);
        if(pll_manualcal == 0) {
            vco_fail = vco_status(inst,0x0) >> 3;
            timeout--;
            if(timeout==0) {
                printf("\nENET:%d VCO Callibration Fail!!!\n",inst);
                return -1;
            }            
        }
        else  
            vco_fail = 0;

        if(loop)loop--; 

    } while(vco_fail);

    port = inst;
    //gen_avg_val_1g(port);
    retval = xgene_phy_gen_avg_val_sata_sgmii(port);
    if(retval < 0) {
        total_err_count[0]++;
        total_err_count[1]++;
        total_err_count[2]++;
        total_err_count[3]++;        
        total_err_count_result();	
        return retval;    
    }

    port = inst | 0x1;
    //gen_avg_val_1g(port);
    retval = xgene_phy_gen_avg_val_sata_sgmii(port);
    if(retval < 0) {
        total_err_count[0]++;
        total_err_count[1]++;
        total_err_count[2]++;
        total_err_count[3]++;        
        total_err_count_result();	
        return retval;    
    }
    
    USDELAY(10);

    return 0;
}

void enet_basic(int intf, int display) {
    int lpbk_dat;
    int port;
    port = intf;
    eth_wr(SM_ENET_CSR_CFG_BYPASS__ADDR,0x00000001,ENET,port,display);

    if (loopback == 0) { 
        eth_wr(SM_ENET_CSR_DEBUG_REG__ADDR,0x003e03fe,ENET,port,display);
    }    //Rx-Tx buffer loopback
    else { 
        eth_wr(SM_ENET_CSR_DEBUG_REG__ADDR,0x003E03EE,ENET,port,display);
    }    //QM Loopback
    lpbk_dat = eth_rd(SM_ENET_CSR_DEBUG_REG__ADDR,ENET,port,display);

    port = intf;
    mcxmac_ind_wr(0x00000000,0x00000035,ENET,port, 0);
    mdio_wr(0x00001e11,0,ENET,port,display);

    mcxmac_ind_wr(0x00000004,0x00005231,ENET,port, 0);            
    mcxmac_ind_wr(0x00000020,0x00002580,ENET,port, 0);           

    port = intf | 0x1;
    mcxmac_ind_wr(0x00000000,0x00000035,ENET,port, 0); 
    mdio_wr(0x00001e11,0,ENET,port,display);
    mcxmac_ind_wr(0x00000004,0x00005231,ENET,port, 0);            
    mcxmac_ind_wr(0x00000020,0x00002580,ENET,port, 0);           
    port = intf;

    eth_wr(SM_ENET_CSR_RSIF_CONFIG_REG__ADDR,0xff010044,ENET,port,display);

    if (cle_enable == 0) {
        unsigned int read_data;


        if(port == 0) { //Port-0/1    
            // Port-0  
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR, 0xa000000e,ENET,port,display);
            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,ENET,port,display);
            lprintf(8, "\r\nport:%d SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR, 0x00000440,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR, 0x00000440,ENET,port,display);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,ENET,port,display);
            lprintf(8, "port:%d SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,read_data);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,ENET,port,display);
            lprintf(8, "port:%d SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_0__ADDR, 0x00101000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_0__ADDR, 0x0c000000,ENET,port,display);

            //Port-1  
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR, 0xa000000e,ENET,port,display);
            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR,ENET,port,display);
            lprintf(8, "\r\nport:%d SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR, 0x00110441,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR, 0x00110441,ENET,port,display);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,ENET,port,display);
            lprintf(8, "port:%d SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,read_data);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR,ENET,port,display);
            lprintf(8, "port:%d SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_1__ADDR, 0x00101000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_1__ADDR, 0x0c000000,ENET,port,display);

            eth_wr(SM_ENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,ENET,port,display);
            eth_wr(SM_ENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,ENET,port,display);         
        }
        if(port == 2) { //Port-2/3    
            // Port-2  
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR, 0xa000000e,ENET,port,display);
            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,ENET,port,display);
            lprintf(8, "\r\nport:%d SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR, 0x00000442,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR, 0x00000442,ENET,port,display);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,ENET,port,display);
            lprintf(8, "port:%d SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,read_data);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,ENET,port,display);
            lprintf(8, "port:%d SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_0__ADDR, 0x00101000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_0__ADDR, 0x0c000000,ENET,port,display);

            //Port-3  
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR, 0xa000000e,ENET,port,display);
            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR,ENET,port,display);
            lprintf(8, "\r\nport:%d SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR, 0x00110443,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR, 0x00110443,ENET,port,display);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,ENET,port,display);
            lprintf(8, "port:%d SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,read_data);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR,ENET,port,display);
            lprintf(8, "port:%d SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_1__ADDR, 0x00101000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_1__ADDR, 0x0c000000,ENET,port,display);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_1__ADDR, 0x00101000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_1__ADDR, 0x0c000000,ENET,port,display);

            eth_wr(SM_ENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,ENET,port,display);
            eth_wr(SM_ENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,ENET,port,display);         
        }

    }

    // cfg to enable capture of Rx cntrl wd's
    eth_wr(SM_ENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,ENET,port,display);
    eth_wr(SM_ENET_CSR_CFG_CAPTURE_ECM_CTRLWD_0__ADDR, 0x1,ENET,port,display);

    // Disable Completion messages
    lprintf(8, "\nDisable Completion Queue for SATA-SGMII Ports,");
    eth_wr(SM_ENET_CSR_TSIF_CONFIG_REG_0__ADDR, 0x00004888,ENET,port,display); 
    eth_wr(SM_ENET_CSR_TSIF_CONFIG_REG_1__ADDR, 0x00004888,ENET,port,display); 
    lprintf(8, "Done\n");
}

int init_enet(int inst) {
    int port;
    int retval=0;

    read_rpkt_as[0] = 0; 
    read_rpkt_as[1] = 0; 
    read_rpkt_as[2] = 0; 
    read_rpkt_as[3] = 0; 

    read_rpkt_as_bak[0] = 0; 
    read_rpkt_as_bak[1] = 0; 
    read_rpkt_as_bak[2] = 0; 
    read_rpkt_as_bak[3] = 0; 
    
    read_rfcs_as_bak[0] = 0; 
    read_rfcs_as_bak[1] = 0; 
    read_rfcs_as_bak[2] = 0; 
    read_rfcs_as_bak[3] = 0; 

    enet_clkcfg_1(inst,0); // Common for port0/1

    if(clk_mode_1g == 0) {
        lprintf(4, "\nSATA-SGMII Inst-%d is Configured in External Clock Mode\n",inst);
        retval = init_enet_serdes(inst, 0); 
        if(retval < 0)
            return retval;
    }
    else if(clk_mode_1g == 1) { 
        lprintf(4, "\nSATA-SGMII Inst-%d is Configured in Internal Clock Mode\n",inst);
        retval = init_enet_serdes(inst, 1);  
        if(retval < 0)
            return retval;
    }

    enet_clkcfg_2(inst,0); 
    enet_basic(inst,0);

    port = inst + 0x0;
    configure_sgmii(port,0x0, 1); 
    port = inst + 0x1;
    configure_sgmii(port,0x0, 1);

    return 0;
}

int configure_sgmii(int port, int display, int reconfig_count){
    int link, an_comp, an_done = 0;
    int pass_cnt = 0;
    itr_count[port] = 0;
    if(an_en_1g) { 
        mdio_wr(0x1e00,0x9140,ENET,port,display); // AutoNeg Mode
        lprintf(4,"\nSGMII core in configured in AutoNeg Mode\n");
    }
    else {
        mdio_wr(0x1e00,0x8140,ENET,port,display); // Non AutoNeg Mode
        lprintf(4,"\nSGMII core in configured in Non AutoNeg Mode\n");
    }

    int loop = 100;
    int ext_link,speed;
    int loop_var = 0;
    link =0;
    an_done = 0;
    do {
        link, an_done = 0;
        read_data = mdio_rd(0x1e01,ENET,port,display);
        link    = (read_data >> 2) & 0x1;
        an_comp = (read_data >> 5) & 0x1;
        loop_var = an_en_1g ? an_comp : link;
        if(loop_var) {
            pass_cnt++;
            if(display) printf("?");
            an_done = (pass_cnt == 1000);
        }
        else {
            pass_cnt = 0;
            loop--;
        }
        USDELAY(10);
    }while(((loop != 0) && (an_done == 0) && (pass_cnt == 0)) || ((pass_cnt != 0 ) && (an_done == 0)));

    read_data = mdio_rd(0x1e05,ENET,port,display);
    ext_link = (read_data >> 15) & 0x1;

    if(tx2rx_serdes_lb_1g == 0 && an_en_1g == 1)
        mac_mode_1g = (read_data >> 10) & 0x3;

    if(display) {
        lprintf(5,"Autonegotiation %s complete %s\n\r", an_done ? "" : "NOT",an_en_1g ? "" : " : NON-AUTONEG MODE");
        lprintf(5,"Link Status : %s \n\r", link == 1 ? "UP" : "DOWN");
        if(an_en_1g) {
            lprintf(5, "Link Parameters : 0x%x \n\r", read_data);
            if(link == 1) lprintf(5, "Speed = %x \n\r", mac_mode_1g);
        }
    }
    itr_count[port]++;

    if(display) {
        lprintf(5,"\n\r---------------------------------------- \n\r");
        lprintf(5,"\t Autonegotiation %s complete \n\r", an_done ? "" : "NOT");
        lprintf(5,"\t Link Status Port%x: %s \n\r", port, link == 1 ? "UP" : "DOWN");
        lprintf(5,"\t Link Parameters : 0x%x \n\r", read_data);
        lprintf(5,"\t Speed = %s mbps\n\r", (mac_mode_1g == 2) ? "1000" : ((mac_mode_1g == 1) ? "100" : "10"));
        lprintf(5,"---------------------------------------- \n\r");
    }
    if((an_en_1g == 1 && ext_link == 1) ||             // Auto neg - External link up
            (an_en_1g == 0 && link == 1) ||            // Non Auto - Internal link up , Poll for external link(by software not done here)
            (tx2rx_serdes_lb_1g == 1 && link == 1) ||  // SERDES Tx2Rx loopback - Internal link up
            (tx2rx_phy_lp == 1 && link == 1)) {        // PHY Tx2Rx loopback - Internal link up
        // printf("Configure MAC/SGMII as per new speed : %s mbps\n\r", (mac_mode_1g == 2) ? "1000" : ((mac_mode_1g == 1) ? "100" : "10"));
        if((port == 0) || (port == 2)) {
            enet_reg_wr_mode(port, 0x00002c00,0x0008503f,0x0004503f,0x0000503f);  //ICM_CONFIG0_REG_0 -- MacMode
            enet_reg_wr_mode(port, 0x00002c10,0x0000000f,0x0000000f,0x00010150);  // ICM_Config2_reg_0 -Async read  //AXI freq 	
            eth_wr(SM_ENET_CSR_CFG_LINK_AGGR_RESUME_0__ADDR,0x00000001,ENET,port,display);
            if(gating_bypass_1g)
                eth_wr(SM_ENET_MAC_CSR_RX_DV_GATE_REG_0__ADDR,0x0,ENET,port,display);
            else 
                eth_wr(SM_ENET_MAC_CSR_RX_DV_GATE_REG_0__ADDR,0x7,ENET,port,display);
        } else {
            enet_reg_wr_mode(port, 0x00002c08,0x0008503f,0x0004503f,0x0000503f);  //ICM_CONFIG0_REG_1 -- MacMode
            enet_reg_wr_mode(port, 0x00002c14,0x0000000f,0x0000000f,0x00010150);  // ICM_Config2_reg_0 -Async read  //AXI freq  => 50MHz
            eth_wr(SM_ENET_CSR_CFG_LINK_AGGR_RESUME_1__ADDR,0x00000001,ENET,port,display);
            if(gating_bypass_1g)
                eth_wr(SM_ENET_MAC_CSR_RX_DV_GATE_REG_1__ADDR,0x0,ENET,port,display);
            else 
                eth_wr(SM_ENET_MAC_CSR_RX_DV_GATE_REG_1__ADDR,0x7,ENET,port,display);
        }
        mac_ind_write_mode(port,0x00000004,0x00005231,0x00006131,0x00007111);   // Interface Mode - Nibble vs Byte
        mac_ind_write_mode(port,0x00000038,0x04000000,0x02000000,0x00000000); // MAC mode - 1g,100m,10m
        eth_wr(SM_ENET_CSR_LINK_STS_INTR__ADDR,(0x1 << (port & 0x1)),ENET,port,display);
    }
    return an_done;
}

int eth_tx2rx_1g_sata()
{
    int test_dat = 0;
    int val = 0;
    int count = 0;
    int i = 0;
    int j=0;
    int enet_addr, rd_data,quit_r;
    int num_buffers = 1;
    unsigned int size1;
    unsigned int size;
    int fail_cnt = 0;
    int iter = 0;
    int it = 0;
    int drop_data = 0;
    int bypass_en = 0;
    int intr_stat = 0;
    int num_msg = 0;
    int ind_address =0;
    int ind_data = 0;
    int display = 0;
    int retval=0;
    int reg_1 , reg_2 , reg_3 , reg_4;

    total_err_count[0]=0;
    total_err_count[1]=0;
    total_err_count[2]=0;
    total_err_count[3]=0;

    lprintf(8, "\n*****************************************\n\r");
    lprintf(8, "******** SATA-SGMII Test Start ********\n\r");
    lprintf(8, "*****************************************\n\r");

    lprintf(8, "\n\r\n\r\n\r-------------------------------\n\r");
    lprintf(8, "Configuring ENET ports 0 and 1 \n\r");
    lprintf(8, "-------------------------------\n\r");
    enet_base_addr = ENET_01_BASE_ADDR; 
    retval = init_enet(0); // 0-ENET01
    if(retval < 0) {
        total_err_count[0]++;
        total_err_count[1]++;
        total_err_count[2]++;
        total_err_count[3]++;        
        total_err_count_result();	
        return retval;    
    }
    
    lprintf(8, "\n\r\n\r\n\r-------------------------------\n\r");
    lprintf(8, "Configuring ENET ports 2 and 3 \n\r");
    lprintf(8,"-------------------------------\n\r");
    enet_base_addr = ENET_23_BASE_ADDR; 
    retval = init_enet(2); // 2-ENET23
    if(retval < 0) {
        total_err_count[0]++;
        total_err_count[1]++;
        total_err_count[2]++;
        total_err_count[3]++;          
        total_err_count_result();	
        return retval;
    }

    int port; 
    int intf; 
    link_status();
    vco_status(0x0,0x1);
    vco_status(0x2,0x1);

    menet_clkcfg();
    mgmt_mac_config();

    enable_l3_cache();//Enable L3 cache ...
    enable_64_byte_axi_write_padding();//Enable 64-Byte AXI Write padding

    unsigned int reg,tmp;

    lprintf(8, "\r\nHach HAck SATA Ports for the PAcket Drops!!!!!!! \r\n");
    lprintf(8, "Disable the LErrr from ENET\r\n");
    lprintf(8, "Before write\r\n");
    reg = 0x1f212098;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f222098;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);

    write((unsigned int *)(0x1f212098), 0x0); 
    write((unsigned int *)(0x1f222098), 0x0); 

    lprintf(8, "After write\r\n");
    reg = 0x1f212098;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f222098;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);

    lprintf(8, "\nUn Mask the RSIF & TSIF Interrupts\r\n");
    write((unsigned int *)(0x1f212058), 0x0); 
    write((unsigned int *)(0x1f212060), 0x0); 
    write((unsigned int *)(0x1f2120a0), 0x0); 
    write((unsigned int *)(0x1f2120a8), 0x0);
    write((unsigned int *)(0x1f212130), 0x0);
    write((unsigned int *)(0x1f212138), 0x0);

    write((unsigned int *)(0x1f222058), 0x0); 
    write((unsigned int *)(0x1f222060), 0x0); 
    write((unsigned int *)(0x1f2220a0), 0x0); 
    write((unsigned int *)(0x1f2220a8), 0x0); 
    write((unsigned int *)(0x1f222130), 0x0); 
    write((unsigned int *)(0x1f222138), 0x0); 

    lprintf(8, "\nUn Mask the QMI Interrupts\r\n");
    write((unsigned int *)(0x1f2190a0), 0x0); 
    write((unsigned int *)(0x1f2190a8), 0x0); 
    write((unsigned int *)(0x1f2190b0), 0x0); 
    write((unsigned int *)(0x1f2190b8), 0x0);
    write((unsigned int *)(0x1f2190c0), 0x0);

    write((unsigned int *)(0x1f2290a0), 0x0); 
    write((unsigned int *)(0x1f2290a8), 0x0); 
    write((unsigned int *)(0x1f2290b0), 0x0); 
    write((unsigned int *)(0x1f2290b8), 0x0);
    write((unsigned int *)(0x1f2290c0), 0x0);

    lprintf(8, "\r\nQMI Configuration for Port-2 & Port-3\r\n");
    lprintf(8, "Before write\r\n");
    reg = 0x1f2190dc;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f2190e0;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);

    reg = 0x1f2290dc;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f2290e0;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);

    reg = 0x1f2290f0;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);

    reg = 0x1f2290f4;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);

    write((unsigned int *)(0x1f2190dc), 0xffffffff); 
    write((unsigned int *)(0x1f2190e0), 0xffffffff); 
    //write((unsigned int *)(0x1f2190f0), 0xffffffff); 
    //write((unsigned int *)(0x1f2190f4), 0xffffffff); 

    write((unsigned int *)(0x1f2290dc), 0xffffffff);  // CfgSsQmiFPQAssoc
    write((unsigned int *)(0x1f2290e0), 0xffffffff);  // CfgSsQmiWQAssoc
    //write((unsigned int *)(0x1f2290f0), 0xffffffff);  // CfgSsQmiQMLiteWQAssoc
    //write((unsigned int *)(0x1f2290f4), 0xffffffff);  // CfgSsQmiQMLiteFPQAssoc

    lprintf(8, "\r\nAfter write\r\n");
    reg = 0x1f2190dc;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f2190e0;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);

    reg = 0x1f2290dc;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f2290e0;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);

    reg = 0x1f2290f0;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);

    reg = 0x1f2290f4;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);

    USDELAY(1000);
    lprintf(5,"\nQM-1 Init\r\n");
    qm_n(QM_QM1, QM_ETH);
    USDELAY(4000);

    USDELAY(10000);

    sw_workaround();//Sw workaround as given in XGENET EAS
    config_rsif_vc2();//Set VC2 for Eth RSIF
#if 0
    set_mcu_ref_burst_cnt(0x1);//Set DDR Refresh Burst count = 1
    set_mcu_hpweight(0x300);//Set MCU_HPWEIGHT to highest priority
    set_mcu_lpweight(0x200);//Set MCU_LPWEIGHT to 2nd highest priority
    set_mcu_wpweight(0x100);//Set MCU_WPWEIGHT to lowest priority
#endif
    write((unsigned int *)(0x17001398), 0x001e1e1e); //MDIO enable config

    lprintf(8, "QM initialization begins .... \n\r");

    lprintf(8, "Initialization for CLE begins .... \n\r");

    sata_sgmii_init_done=1;

   
    if(sata_sgmii_margin_tool == 1) {
        margin_util_sgmii_sata();
        return 0;
    }

    lprintf(8,"*****************************************\n\r");
    lprintf(8,"******** SATA-SGMII Test Complete ********\n\r");
    lprintf(8,"*****************************************\n\r");

    if(tx2rx_phy_lp == 1) {
        set_phy_level_lpbk_sgmii(ENET);
        eth_tx2rx_lpbk_test_sata_1g_int_lpbk();  // Internal Self Single Port lpbk mode
        mac_stat_1g_sata();
        return 0;
    }

    if(tx2rx_serdes_lb_1g == 1) {
        if(prbs_test_mode == 1) {
            sata_sgmii_serdes_prbs_test();       // PRBS Self Single Port lpbk mode
            return 0;
        }
        eth_tx2rx_lpbk_test_sata_1g_int_lpbk(); //Internal Self Port level lpbk mode
    }
    else if(tx2rx_serdes_lb_1g == 0) {
        eth_tx2rx_lpbk_test_sata_1g_ext_lpbk(); //External Port to Port lpbk mode
        //serdes_reg_dump_dbg();
        //phy_autoneg_bypass_sts();
    }
    total_err_count_result();	

    if(advanced_debug) {
        debug_1g();
    }

    return 0;
}

int vco_status(int inst, int display) {
    int rd_val,pll_ready,pll_lock,vco_calibration,tx_ready,rx_ready;
    int pll_det;
    int vco_cal_fail;

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg7", CMU + 2*7,ENET,inst,1);

    //pll_ready = FIELD_SATA_ENET_SDS_CMU_STATUS0_CFG_CMU_O_PLL_READY_RD(rd_val);
    pll_lock        = (rd_val >> 15) & 0x1;
    vco_calibration = (rd_val >> 14) & 0x1;
    pll_det         = (rd_val >> 12) & 0x3;
    vco_cal_fail    = (rd_val >> 10) & 0x3;
    if(display){
        //printf("ENET%d%d  VCO_CALIB: PLL is %sREADY\n", 2*inst, 2*inst+1, pll_ready ? "" : "not ");
        lprintf(4,"ENET%d%d  VCO_CALIB: PLL %sLOCKed\n", inst, inst+1, pll_lock ? "" : "not ");
        lprintf(4,"ENET%d%d  VCO_CALIB: PLL VCO Calibration %s\n", inst, inst+1, vco_calibration ? "DONE" : "not done");
        lprintf(4,"ENET%d%d  VCO_CALIB: PLL VCO Calibration %s : 0x%x\n", inst, inst+1, vco_cal_fail == 0 ? "SUCCESSFUL" : "FAILED",vco_cal_fail);
        lprintf(4,"ENET%d%d  VCO_CALIB: PLL DET : %d\n", inst, inst+1, pll_det);
    }
    // printf("ENET%d%d INIT_SERDES : Check TX/RX Ready\n", 2*inst, 2*inst+1);
    // rd_val = eth_rd(SM_SATA_ENET_SDS_CSR_REGS_SATA_ENET_SDS0_RXTX_STATUS__ADDR,ENET,inst,0x1);
    // tx_ready = FIELD_SATA_ENET_SDS0_RXTX_STATUS_CFG_TX_O_TX_READY_RD(rd_val);
    // rx_ready = FIELD_SATA_ENET_SDS0_RXTX_STATUS_CFG_RX_O_RX_READY_RD(rd_val);
    // 
    // printf("ENET%d%d INIT_SERDES : TX is %sready\n", 2*inst, 2*inst+1, tx_ready ? "" : "not ");
    // printf("ENET%d%d INIT_SERDES : RX is %sready\n\n", 2*inst, 2*inst+1, rx_ready ? "" : "not ");
    int vco_cal_done_n = 0;
    if (vco_calibration == 0) vco_cal_done_n = 1;
    return (((vco_cal_done_n << 5 )|(vco_cal_fail<<3) | (pll_det<<1) | (pll_lock == 0))); 

}

int link_status(){
    int an_sts;
    an_sts = lnk_sts(FIRST_PORT,LAST_PORT,1);
    return an_sts;
}

int lnk_sts(int srt_port, int end_port, int display) {
    int tmp;
    int link = 0;
    int an_done = 0;
    int an_comp = 0;
    int port;
    int intf;
    int an_sts = 0;
    int data32;
    
    //-----------------------------------
    // Print Final Link Status
    //-----------------------------------
    for (port = srt_port; port <= end_port; port++){
        if(display)lprintf(5,"\n======== Link Status : Port%d ==========\n", port);
        link, an_done = 0;
        read_data = mdio_rd(0x1e01,ENET,port,0);
        link    = (read_data >> 2) & 0x1;
        an_comp = (read_data >> 5) & 0x1;
        an_done = an_en_1g ? an_comp : link;
        int my_loop = 1000;
        while((my_loop > 0) && an_done) {
            read_data = mdio_rd(0x1e01,ENET,port,0);
            link    = ((read_data >> 2) & 0x1) && link;
            an_comp = ((read_data >> 5) & 0x1) && an_comp;
            an_done = an_en_1g ? an_comp : link;
            my_loop--;
        }
        an_sts = an_sts | (an_done << port);
        if(display)lprintf(5,"Autonegotiation %s complete %s\n", an_comp ? "" : "NOT",an_en_1g ? "" : " : NON-AUTONEG MODE");
        if(display)lprintf(5,"Link Status : %s \n\r", link == 1 ? "UP" : "DOWN");
        if(an_en_1g)
            if(display)lprintf(5,"Link Parameters : 0x%x \n", mdio_rd(0x1e05,ENET,port,0));

        //lprintf(5,"Link Status after %d iterations \n\r", itr_count[port]);
        lprintf(5,"addr:0x1e01 read_data:0x%x \n", mdio_rd(0x1e01,ENET,port,0));
        lprintf(5,"addr:0x1e05 read_data:0x%x \n", mdio_rd(0x1e05,ENET,port,0));

        tmp =   eth_rd(SM_ENET_CSR_LINK_STATUS__ADDR,ENET,port,0) 
            & ((port == 0 || port == 2) ? 0x1 : 0x2 );
        if(gating_bypass_1g) {
            if(port == 0 || port == 2) {
                eth_wr(SM_ENET_CSR_CFG_LINK_AGGR_RESUME_0__ADDR,0x00000001,ENET,port,0);
                eth_wr(SM_ENET_MAC_CSR_RX_DV_GATE_REG_0__ADDR,0x0,ENET,port,0);
            }
            else{
                eth_wr(SM_ENET_CSR_CFG_LINK_AGGR_RESUME_1__ADDR,0x00000001,ENET,port,0);
                eth_wr(SM_ENET_MAC_CSR_RX_DV_GATE_REG_1__ADDR,0x0,ENET,port,0);
            }
        } else if(tmp != 0) {
            if(port == 0 || port == 2) {
                eth_wr(SM_ENET_CSR_CFG_LINK_AGGR_RESUME_0__ADDR,0x00000001,ENET,port,0);
                eth_wr(SM_ENET_MAC_CSR_RX_DV_GATE_REG_0__ADDR,0x7,ENET,port,0);
            }
            else{
                eth_wr(SM_ENET_CSR_CFG_LINK_AGGR_RESUME_1__ADDR,0x00000001,ENET,port,0);
                eth_wr(SM_ENET_MAC_CSR_RX_DV_GATE_REG_1__ADDR,0x7,ENET,port,0);
            }
        } else {
            lprintf(8,"Port%d : Traffic GATED\n",port);
        }
        eth_rd(SM_ENET_CSR_LINK_STATUS__ADDR,ENET,port,0);
        eth_rd(SM_ENET_CSR_LINK_STS_INTR__ADDR,ENET,port,0);
        eth_wr(SM_ENET_CSR_LINK_STS_INTR__ADDR,(0x1 << (port & 0x1)),ENET,port,0);
    }
    return an_sts;
}

void mac_stat_1g_sata(){
    if(sata_sgmii_init_done == 1) {
        int port = 0;
        for(port = FIRST_PORT; port <= LAST_PORT ; port++){
            printf("-------Port%d----------\n",port);
            printf("Tx-Pkt = %d :: ",mac_stat_rd(PEMSTAT_TPKT__ADDR,port));
            //printf("Rx-Pkt = %d \n",mac_stat_rd(PEMSTAT_RPKT__ADDR,port));
            printf("Rx-Pkt = %d \n",read_rpkt_as_bak[port]);
            printf("Tx-Byt = %d :: ",mac_stat_rd(PEMSTAT_TBYT__ADDR,port));
            printf("Rx-Byt = %d \n",mac_stat_rd(PEMSTAT_RBYT__ADDR,port));
            printf("Tx-FCS = %d :: ",mac_stat_rd(PEMSTAT_TFCS__ADDR,port));
            //printf("Rx-FCS = %d \n",mac_stat_rd(PEMSTAT_RFCS__ADDR,port));
            printf("Rx-FCS = %d \n",read_rfcs_as_bak[port]);
            printf("Tx-UND = %d :: ",mac_stat_rd(PEMSTAT_TUND__ADDR,port));
            printf("Rx-UND = %d \n",mac_stat_rd(PEMSTAT_RUND__ADDR,port));
            printf("Tx-OVR = %d :: ",mac_stat_rd(PEMSTAT_TOVR__ADDR,port));
            printf("Rx-OVR = %d \n",mac_stat_rd(PEMSTAT_ROVR__ADDR,port));
            printf("Tx-FRG = %d :: ",mac_stat_rd(PEMSTAT_TFRG__ADDR,port));
            printf("Rx-FRG = %d \n",mac_stat_rd(PEMSTAT_RFRG__ADDR,port));
            printf("\n");
            read_rpkt_as_bak[port] = 0 ;
            read_rfcs_as_bak[port] = 0 ;
        }
    }
    else if (sata_sgmii_init_done == 0) {
        printf("\nSATA-SGMII Ports are in initialized\n");
    }
}

void debug_1g(){
    int val,quit_r,intf,port,i,j,fail_cnt,ind_data,it,iter;
    int phy_addr=0,phy_reg=0;
    int ind_address;
    do
    {
        printf("\n\r\n\r");
        printf("99. BLOCK RESET\n\r");
        printf("97. Select ENET01 or ENET23\n\r");
        printf("\n\r");
        printf("90. Reconfigure Serdes : both ports of the selected instance\n\r");
        printf("95. Assert Deasssert Analog Reset\n\r");
        printf("96. Assert Deasssert Digital & Analog Reset\n\r");
        printf("100. Print PLL Status\n\r");
        printf(" 3. Read port stats\n\r");
        printf(" 8. Switch phy to autoneg\n\r");
        printf(" 9. Switch phy to autoneg + Reconfigure Serdes loop\n\r");
        printf("42. SERDES indirect Read \n\r");
        printf("43. SERDES indirect Write \n\r");
        printf("\n\rq. to quit.. \n\r");

        printf("\n\r");
        val = get_val();
        quit_r = val + 0x57;

        // command interpretation
        if (val == 0x99) // read loop
        {
            display_serdes = 0x1;
        } // ended read loop
        else if (val == 0x98) // read loop
        {
            int temp;
            temp = my_get_val("select port 0/2 : ");
            intf = temp & 0x2;
            port = temp & 0x3;
            enet_base_addr =  intf ? ENET_23_BASE_ADDR : ENET_01_BASE_ADDR; // important           printf("\n\r Asserting Reset ...\n\r");      
            eth_wr(SM_ENET_CLKRST_CSR_ENET_SRST__ADDR ,0x0000001f,ENET,port,0x1);
            init_enet(intf);
        } // ended read loop
        else if (val == 0x97 ){
            enet_base_addr = my_get_val("select port 0/2") ? ENET_23_BASE_ADDR : ENET_01_BASE_ADDR; // important - do not delete

        }
        else if (val == 0x100 ){
            //	pll_status();
        }
        else if (val == 0x90 ) 
        {
            int temp;
            temp = my_get_val("select port 0/2 : ");
            intf = temp & 0x2;
            port = temp & 0x3;
            enet_base_addr =  intf ? ENET_23_BASE_ADDR : ENET_01_BASE_ADDR; // important - do not delete
            temp = my_get_val("select Refclock mode 0-Ext 1- Internal Single ended 2-Internal Differential : ");
            init_enet_serdes(intf,temp); 
        }
        else if (val == 0x96 )
        {
            int temp;
            temp = my_get_val("select port 0/1/2/3");
            intf = temp & 0x2;
            port = temp & 0x3;
            enet_base_addr =  intf ? ENET_23_BASE_ADDR : ENET_01_BASE_ADDR; // important - do not delete
            serdes_reset_rxd_rxa(port,0);
        } 
        else if (val == 0x95 )
        {
            int temp;
            temp = my_get_val("select port 0/1/2/3");
            intf = temp & 0x2;
            port = temp & 0x3;
            enet_base_addr =  intf ? ENET_23_BASE_ADDR : ENET_01_BASE_ADDR; // important - do not delete
            serdes_reset_rxa(port,0x0);
        } 
        else if (val == 0x01) // read loop
        {
            printf("\n\rread address offset (hex)=?\n\r");
            val = get_val();
            read_address = val;
            read_data = myread(read_address,1);
            //	  printf("\n\rread data = 0x");putnum(read_data);printf(" from address = 0x");putnum(read_address);printf("\n\r");
        } // ended read loop

        else if (val == 0x02)    //// Write command
        {
            printf("\n\rwrite address (hex)=?\n\r");      
            val = get_val();
            write_address = val;
            printf("\n\rwrite data=?\n\r");
            // input write data
            val = get_val();
            write_data = val;
            //	  eth_wr(write_address,write_data,ENET,port,display);
            write(write_address,write_data);
            //	  printf("\n\rwritten data = 0x");putnum(write_data);printf(" at address = 0x");putnum(write_address);printf("\n\r");  
        } // ended write loop

        else if (val == 0x03)    //// status command
        {
            int temp,port,intf;
            printf("\n\renter port whose mdio to be used \n\r");
            // mdio_wr(0x716,1,ENET,0x0,display);
            // mdio_wr(0x700,0x8140,ENET,0x0,display);
            // mdio_wr(0x716,0,ENET,0x0,display);
            temp = my_get_val("select port 0/1/2/3");
            port = temp & 0x3;
            intf = temp & 0x2;
            enet_base_addr =  intf ? ENET_23_BASE_ADDR : ENET_01_BASE_ADDR; // important - do not delete
            read_statistics(port);// Function Call to print all the Statistics
        } // ended status read loop

        else if (val == 0x04)    //// mac ind rd command
        {
            printf("\n\renter port whose mac is to be read \n\r");
            port = get_val();
            printf("\n\rRead address (hex)=?\n\r");
            ind_address = get_val();
            read_data = mcxmac_ind_rd(ind_address,ENET,port, 1);
            printf("\n\rdata read is = 0x");putnum(read_data);printf("\n\r");
        } // ended status read loop

        else if (val == 0x05)    //// mac ind wr command
        {
            printf("\n\renter port whose mac is to be written \n\r");
            port = get_val();
            printf("\n\renter write address \n\r");
            val = get_val();
            ind_address = val;
            printf("\n\r enter write data=?\n\r");
            // input write data
            val = get_val();
            write_data = val;
            printf("\n\rwriting....\n\r");
            mcxmac_ind_wr(ind_address,write_data,ENET,port, 1);
            printf("\n\rwritten data = 0x");putnum(write_data);printf(" at address = 0x");putnum(ind_address);printf("\n\r");
        } // ended status read loop
        else if (val == 0x06)    //// mac ind rd command
        {
            printf("\n\renter port whose mdio to be used \n\r");
            port = get_val();
            printf("\n\r Phy addr and reg address combined.in [0:31] format,[0:18] = 19'b0, [19:23]= Phyaddress, [24:26] = 3'b0, [27:31] = reg address in (hex)=?\n\r");
            ind_address = get_val();
            read_data = mdio_rd(ind_address,ENET,port,1);
            printf("\n\rdata read is = 0x");putnum(read_data);printf("\n\r");
        } // ended status read loop

        else if (val == 0x07)    //// mac ind wr command
        {
            printf("\n\renter port whose mdio to be used \n\r");
            port = get_val();
            printf("\n\r Phy addr and reg address combined.in [0:31] format,[0:18] = 19'b0, [19:23]= Phyaddress, [24:26] = 3'b0, [27:31] = reg address in (hex)=?\n\r");
            val = get_val();
            ind_address = val;
            printf("\n\r enter write data=?\n\r");
            // input write data
            val = get_val();
            write_data = val;
            printf("\n\rwriting....\n\r");
            mdio_wr(ind_address,write_data,ENET,port,1);
            printf("\n\rwritten data = 0x");putnum(write_data);printf(" at address = 0x");putnum(ind_address);printf("\n\r");
        } // ended status read loop

        else if (val == 0x08)    //// mac ind wr command
        {
            int temp,port,intf;
            printf("\n\renter port whose mdio to be used \n\r");
            // mdio_wr(0x716,1,ENET,0x0,display);
            // mdio_wr(0x700,0x8140,ENET,0x0,display);
            // mdio_wr(0x716,0,ENET,0x0,display);
            temp = my_get_val("select port 0/1/2/3");
            port = temp & 0x3;
            intf = temp & 0x2;
            enet_base_addr =  intf ? ENET_23_BASE_ADDR : ENET_01_BASE_ADDR; // important - do not delete
            mdio_wr(0x00001e11,0x8000,ENET,port,1);
            USDELAY(1000);
            mdio_wr(0x00001e11,0,ENET,port,1);
            USDELAY(1000);

            mdio_wr(0x1e00,0x9140,ENET,port,1);
            int loop = 20;
            int link, an_done = 0;
            while((loop != 0) && (an_done == 0)){
                link, an_done = 0;
                read_data = mdio_rd(0x1e01,ENET,port,0);

                link    = (read_data >> 2) & 0x1;
                an_done = (read_data >> 5) & 0x1;
                loop--;
            }
            printf("Autonegotiation %s complete \n\r", an_done ? "" : "NOT");
            printf("Link Status : %s \n\r", link ? "UP" : "DOWN");
            printf("Link Parameters : 0x%x \n\r", mdio_rd(0x1e05,ENET,port,0));
        }  
        else if (val == 0x09)    //// mac ind wr command
        {
            int temp,port,intf;
            printf("\n\renter port whose mdio to be used \n\r");
            temp = my_get_val("select port 0/1/2/3");
            port = temp & 0x3;
            intf = temp & 0x2;
            enet_base_addr =  intf ? ENET_23_BASE_ADDR : ENET_01_BASE_ADDR; // important - do not delete
            configure_sgmii(port, 0x0, 20);
        }
        else if (val == 0x10)    //// mac ind wr command
        {
            int display = 1;
            int tmp;
            // Port 0 
            eth_wr(SM_ENET_CSR_CFG_BYPASS__ADDR,0x0,ENET,port,display);
            eth_wr(SM_ENET_MAC_CSR_RX_DV_GATE_REG_0__ADDR,0x7,ENET,port,display);
            tmp = eth_rd(SM_ENET_CSR_LINK_STS_INTR__ADDR,ENET,port,display);
            eth_wr(SM_ENET_CSR_LINK_STS_INTR__ADDR,0xffffffff,ENET,port,display);
            tmp = eth_rd(SM_ENET_CSR_LINK_STATUS__ADDR,ENET,port,display);
            tmp = eth_rd(SM_ENET_CSR_CFG_LINK_AGGR_RESUME_0__ADDR,ENET,port,display);
            eth_wr(SM_ENET_CSR_CFG_LINK_AGGR_RESUME_0__ADDR,0x00000001,ENET,port,display);
            // Port 1 
            eth_wr(SM_ENET_CSR_CFG_LINK_STS_SEL__ADDR,0x00000002,ENET,port,display); 
            eth_wr(SM_ENET_CSR_CFG_FORCE_LINK_STATUS_EN__ADDR,0x00000002,ENET,port,display); 
            eth_wr(SM_ENET_CSR_FORCE_LINK_STATUS__ADDR,0x00000002,ENET,port,display); 
            eth_wr(SM_ENET_MAC_CSR_RX_DV_GATE_REG_1__ADDR,0x7,ENET,port,display);
            tmp = eth_rd(SM_ENET_CSR_CFG_LINK_AGGR_RESUME_1__ADDR,ENET,port,display);
            eth_wr(SM_ENET_CSR_CFG_LINK_AGGR_RESUME_1__ADDR,0x00000001,ENET,port,display);

            printf("\n\r waiting for link down \n\r");
            tmp = 0;
            do {
                //tmp = eth_rd(SM_ENET_CSR_LINK_STS_INTR__ADDR,ENET,port,display);
                tmp = myread(enet_base_addr + SM_ENET_CSR_LINK_STS_INTR__ADDR,0);
            } while ((tmp & 0x00000001) == 0);
            tmp = eth_rd(SM_ENET_CSR_LINK_STATUS__ADDR,ENET,port,display);
            tmp = eth_rd(SM_ENET_CSR_CFG_LINK_AGGR_RESUME_0__ADDR,ENET,port,display);
            printf("\n\r clearing the link down intr \n\r");
            eth_wr(SM_ENET_CSR_LINK_STS_INTR__ADDR,0xffffffff,ENET,port,display);
            printf("\n\r waiting for link to come up \n\r");
            tmp = 0;
            do {
                //tmp = eth_rd(SM_ENET_CSR_LINK_STS_INTR__ADDR,ENET,port,display);
                tmp = myread(enet_base_addr + SM_ENET_CSR_LINK_STS_INTR__ADDR,0);
            } while ((tmp & 0x00000001) == 0);
            tmp = eth_rd(SM_ENET_CSR_LINK_STATUS__ADDR,ENET,port,display);
            printf("\n\r link up intr rcvd, press 1 for setting resume bit , 0 to exit \n\r");
            val = get_val();
            if (val == 1) {
                eth_wr(SM_ENET_CSR_CFG_LINK_AGGR_RESUME_0__ADDR,0x00000001,ENET,port,display);
                eth_wr(SM_ENET_MAC_CSR_RX_DV_GATE_REG_0__ADDR,0x7,ENET,port,display);
                printf("\n\r resume traffic\n\r");
            }
            else
                printf("\n\r traffic should not resume as resume bit not set\n\r");
        }  
        else if (val == 0x11)    //// mac ind wr command
        {
            int temp,port,intf;
            printf("\nCalculating gen_avg value for SATA-SGMII\n\r");
            temp = my_get_val("select port 0/1/2/3:");
            port = temp;
            debug_gen_avg_val_sata_sgmii(port);
        }
        else if (val == 0x12 )
        {
            int temp,port;
            temp = my_get_val("select port 0/1/2/3");
            port = temp & 0x3;
            printf("\nChange Tx-Aplitude Reset Tx-Term, Tx-Analog-Rst, Tx-Digital-Rst (SATA-SGMII),\n");
            enet_sds_rxtx_re_cfg_sata_sgmii(port,1);
            printf("Done\n");
            printf("Reconfigure SATA-SGMII core,");
            configure_sgmii(port, 0x0, 20);
            printf("Done\n");
        } 
        
        else if (val == 0x31)
        {
            printf("\n\r Memory read address : ");
            read_address = 0x9d000000 + get_val();
            printf("\n\r # Dwords : ");
            val = get_val();
            for(j=0;j<val;j++){
                read_address = read_address + 16;
                printf("\n\r read_address ");putnum(read_address);printf(" : ");
                for(i=0;i<4;i++){
                    putnum(myread(read_address+i*4,0));
                    printf("_");
                }
            }
        }

        else if (val == 0x37) // read loop
        {
            fail_cnt = 0;
            it = 0;
            printf("\n\renter port whose mdio to be used \n\r");
            port = get_val();
            printf("\n\r Phy addr and reg address combined.in [0:31] format,[0:18] = 19'b0, [19:23]= Phyaddress, [24:26] = 3'b0, [27:31] = reg address in (hex)=?\n\r");
            ind_address = get_val();
            printf("\n\rEnter the number of iterations\n\r");
            iter = get_val();
            for (it=0;it<iter;it++) {
                read_data = mdio_rd(ind_address,ENET,port,0);
                if ((read_data && 0x00000002) == 0) {fail_cnt++;printf("\n\rvalue read is");putnum(read_data);printf("\n\r");break;}
            }
            if (fail_cnt == 0) { printf("\n\rTest Pass\n\r");}
            else               { printf("\n\rTest Fail\n\r");}
        } // ended read loop

        else if (val == 0x38) // send pause frame in TX
        {
            send_pause_frame_sata();
        }
        else if (val == 40){ // avb config
            int display = 0;
            eth_wr(SM_ENET_CSR_AVB_PER_Q_CONFIG1_0__ADDR,0x55555555,ENET,port,display);//arb_type  
            //eth_wr(SM_ENET_CSR_AVB_PER_Q_CONFIG1_1__ADDR,0x55555555,ENET,port,display);//arb_type
            eth_wr(SM_ENET_CSR_AVB_COMMON_CONFIG1_0__ADDR,0x10000000,ENET,port,display);//mac_speed 
            //eth_wr(SM_ENET_CSR_AVB_COMMON_CONFIG1_1__ADDR,0x10000000,ENET,port,display);//mac_speed
            eth_wr(SM_ENET_CSR_AVB_COMMON_CONFIG2_0__ADDR,0x2000000a,ENET,port,display);//mac_speed 
            //eth_wr(SM_ENET_CSR_AVB_COMMON_CONFIG2_1__ADDR,0x2000000a,ENET,port,display);//mac_speed
            eth_wr(SM_ENET_CSR_AVB_PER_Q_IDLE_SLOPE0_0__ADDR,0x00000001,ENET,port,display);
            //eth_wr(SM_ENET_CSR_AVB_PER_Q_IDLE_SLOPE0_1__ADDR,0x00000001,ENET,port,display);
        }

        else if (val == 0x43)    //// SerDes write
        {
            printf("\n\rwhat port do you like to access (port 0,1,2,3)?\n\r");
            port = get_val();

            printf("\n\rNote: PHY SerDes has two base addres for rxtx_reg (0x400 and 0x600), one base address for CMU (0x0)\n\r");
            printf("\n\rFor each configuration, you must write one for 0x400 and one for 0x600\n\r");
            printf("\n\r Phy Write address in (hex)=?\n\r");
            ind_address = get_val();
            printf("\n\r enter write data=?\n\r");
            ind_data = get_val();
            printf("\n\rwriting....\n\r");
            enet_sds_ind_csr_reg_wr("sedes_reg",ind_address,ind_data,ENET,port,0);
            printf("\n\rwritten data = 0x");putnum(ind_data);printf(" at address = 0x");putnum(ind_address);printf("\n\r");
        } 
        else if (val == 0x88) {
            printf("Enter Debug bus : 0x");
            val = get_val();
            printf("\n\r");
            eth_wr(SM_GLBL_DIAG_CSR_CFG_DIAG_SEL__ADDR,val,ENET,port,0);
            eth_rd(SM_GLBL_DIAG_CSR_DBG_BLOCK_AXI__ADDR,ENET,port,1);
            eth_rd(SM_GLBL_DIAG_CSR_DBG_BLOCK_NON_AXI__ADDR,ENET,port,1);

        }

        else if (val == 0x89) {
            int loop = get_val();
            eth_rd(SM_GLBL_DIAG_CSR_DBG_BLOCK_AXI__ADDR,ENET,port,1);

            do {
                eth_rd(SM_GLBL_DIAG_CSR_DBG_BLOCK_NON_AXI__ADDR,ENET,port,1);
                loop --;
            }while(loop != 0);
        }

        else if (val == 0x103)    
        {
            //printf("Set PHY loopback mode:\n"); 
            //set_phy_level_lpbk();          

            printf("Set serdes level tx2rx loopback mode\n"); 
            set_serdes_lpbk();
        }
        else if (val == 0x104)   
        {
            int tmp;
            printf(" 4->Set_SERDES_Tx-2-Rx_lpbk 5->ReSet_SERDES_Tx-2-Rx_lpbk\n");
            tmp = get_val();
 
            if(tmp == 4) {
                printf("Set SERDES Level Tx-2-Rx loopback mode\n"); 
                set_serdes_lpbk();
            }
            else if(tmp == 5) {
                printf("ReSet SERDES Level Tx-2-Rx loopback mode\n"); 
                reset_serdes_lpbk();
            } 

        }
        else if (val == 0x105)    
        {
            int tmp;
            printf("\n0->XFI-SGMII 1->SATA-SGMII 2->Both\n");
            tmp = get_val();
            if(tmp == 0) {
                printf("\nSend Packets to XFI-SGMII\n");
                //eth_tx2rx_lpbk_test_xfi_1g();
            }
            else if(tmp == 1) {
                printf("\nSend Packets to SATA-SGMII\n");
                //eth_tx2rx_lpbk_test_sata_1g_dbg();
                //total_err_count_result();
            }
            else if(tmp == 2) {
                printf("\nSend Packets to both SATA/XFI SGMII ports\n");
                //eth_tx2rx_lpbk_test_xfi_1g();
            }
        }
        else if (val == 0x106)    
        {
            printf("\nRead From PHY\n"); 
            printf("\nEnter PHY Address (hex): \n");
            phy_addr = get_val();
            printf("\nEnter Reg Address (hex): \n");
            phy_reg = get_val();

            ind_address = ((phy_addr << 8) | phy_reg);

            ind_data = mdio_rd(ind_address,MENET,0,0);
            printf("\nphy_addr:0x%x phy_reg:0x%x ind_address:0x%x ind_data:0x%x \n",phy_addr,phy_reg,ind_address,ind_data);

        }
        else if (val == 0x107)    
        {
            printf("\nEnter PHY Address (hex): \n");
            phy_addr = get_val();
            printf("\nEnter Reg Address (hex): \n");
            phy_reg = get_val();
            printf("\nEnter Write Value (hex): \n");
            ind_data = get_val();

            ind_address = ((phy_addr << 8) | phy_reg);
            mdio_wr(ind_address,ind_data,MENET,0,0);
            printf("\nphy_addr:0x%x phy_reg:0x%x ind_address:0x%x ind_data:0x%x \n",phy_addr,phy_reg,ind_address,ind_data);
        }


        else if (val == 0x307)    
        {print_stat_sgmii_xfi();
        }      
        else if (val == 0x110) 
        {

            int count=0;
            printf("Auto-Neg Regress Test\n");
            printf("\nEnter IterationNo: (hex): ");
            count = get_val();          
            phy_addr= 0x2; 
            while (count) {
                phy_reg = 17;
                ind_address = ((phy_addr << 8) | phy_reg);
                ind_data = mdio_rd(ind_address,MENET,0,0);
                if((ind_data & 0x8000) && (ind_data & 0x2000))
                    printf("Speed:1G FD ");
                else if((ind_data & 0x4000) && (ind_data & 0x2000))
                    printf("Speed:100M FD ");
                else if(ind_data & 0x4000) 
                    printf("Speed:100M HD ");                  
                else if(ind_data & 0x2000) 
                    printf("Speed:10M FD ");
                else 
                    printf("Speed:10M HD ");
                phy_reg = 0x1;
                ind_address = ((phy_addr << 8) | phy_reg);
                ind_data = mdio_rd(ind_address,MENET,0,0);
                if(ind_data & 0x0020) 
                    printf("PhyAddr:%x,AutoNegCompleteDone,RD:0x%x CNT:%d,PASS \n",phy_addr,ind_data,count);
                else
                    printf("PhyAddr:%x,AutoNegCompleteNotDone,RD:0x%x CNT:%d,FAIL\n",phy_addr,ind_data,count);
                count--;
            }

        }


    }while (quit_r != 0x71);//end while
}

