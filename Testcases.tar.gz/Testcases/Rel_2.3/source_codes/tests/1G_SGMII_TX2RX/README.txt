oo===================================================================================oo
How to Compile :
----------------
        source setup.csh && make 
oo===================================================================================oo
Test Sequencie  

- Send 10,000 Packets 
- Receive Back 10,000 Packets 
- Validate 10,000 Packets (Verify the Pay load)
- Dumps the Pass/Fail Status 

oo===================================================================================oo
Below External Loopback Connection details:

Prerequisites 
- Connect a CAT-5 cable between Port-0 to Port-1
- Connect a CAT-5 cable between Port-2 to Port-3


oo===================================================================================oo
Below Run time commands 

Run the below commands from VBIOS Prmpt

VBIOS-0> eth_tx2rx_1g_sata // 4 ports sata-sgmii ports
VBIOS-0> mac_stat_1g_sata  // sata-sgmii ports stat counter dump

VBIOS-0> eth_tx2rx_1g_xfi // 4 ports xfi-sgmii ports
VBIOS-0> mac_stat_1g_xfi  // xfi-sgmii ports stat counter dump

oo===================================================================================oo


