
#include <stdio.h>
#include <common.h>
#include "eth_common.h"
#include "eth_slt_tx2rx.h"
#include "eth_xg_csr.h"
#include "eth_mg_csr.h"
#include "sm_xxx_serdes.h"

#ifndef CMU
#define CMU	  0x0000
#endif

#include "qm_drv.h" 
#include "qm_misc.h"
#include "qm_vfw.h"

#include <common.h> 
#include <iolib/i2c/i2c.h> 
#include <iolib/i2c/apm_i2c.h> 

static int read_rpkt_as_xg[4] = {0, 0, 0, 0}; 
static int read_rpkt_as_bak_xg[4] = {0, 0, 0, 0}; 
static int read_rfcs_as_xg[4] = {0, 0, 0, 0}; 
static int read_rfcs_as_bak_xg[4] = {0, 0, 0, 0}; 

extern int xgenet_base_addr;
static int clk_mode_xg = 0;         //0=External Clk Mode; 1=Internal clk mode
static int cle_enable_xg = 0;       //1=Real CLE; 0=CLE bypass mode
static int mac_mode = 2;            //0=10M ; 1=100M ; 2=1G 
static int gating_bypass_xg = 1;    //1=No Gating Disabled; 0=Yes Gating Enabled 
static int an_en_xg = 1;            //1=AutoNegNode Enabled; 0=Non AutoNegNode Enabled
static int advanced_debug_xg = 0;   //1=Promt for options with xgenet_main, 0=quit to Menu
static int loopback_xg = 1;         //0=No FIFO level rx-2-tx lpbk mode

static int tx2rx_serdes_lb = 0;            //1=serdes level tx-2-rx lpbk enable, (Gating should be Disabled with AutoNeg Mode tx2rx_serdes_lb=1)
static int xfi_sgmii_init_done=0;
static int total_err_count_xfi[4]={0, 0, 0, 0};
static int tx2rx_phy_lp_xg = 0;        //1=PHY level tx-2-rx lpbk Enable, 0==PHY level tx-2-rx lpbk Disable
static int prbs_test_mode_xg = 0;      //PRBS test mode only work in SERDES level tx-2-rx Mode   
static int xfi_sgmii_margin_tool=0;

int itr_count[4];
unsigned int reconfig_loop = 20;
u64 buf_xfi[16]; 
u64 buf32_xfi[16]; 
u64 buf33_xfi[16]; 
u64 buf34_xfi[16]; 

qm_ret_t sys_alloc_enet_buf(u8 qmid, u32 fpqid, int mn, qm_buf_t *p_buf)
{
    qm_ret_t ret;

    p_buf->fpqid = fpqid; 
    p_buf->qmid  = qmid; 

    p_buf->mid  = 0;            
    p_buf->rtype = QM_PROC_RTYPE; 

    p_buf->bn = 1;
    p_buf->bs = 0;

    ret = qm_buf_alloc(p_buf);
    if (ret != QM_OK)
        printf("\r\nqm_buf_alloc failed: ret = %d....\n", ret);

    return ret;
}

enq_req_t *sys_enet_enq_cfg(u64 da, unsigned int len)
{
    enq_cfg_t enq_cfg;

    enq_cfg.rt = QM_PROC_RTYPE;    
    enq_cfg.ui = QM_TEST_PATTERN; 
    enq_cfg.pl = len;
    enq_cfg.da = da;
    enq_cfg.fpqn = QID0;            
    enq_cfg.hl = 1;
    enq_cfg.qid = QID32;             
    enq_cfg.mn = SLT_MSG_NUM;
    enq_cfg.ms = QM_MSG_SZ_32B;
    enq_cfg.notif = QM_PROC_NOTNO;  

    return (qm_proc_bld_enq_req(&enq_cfg));
}

enq_req_t *sys_enet_enq_cfg32(u64 da, unsigned int len)
{
    enq_cfg_t enq_cfg;

    enq_cfg.rt = QM_PROC_RTYPE;    
    enq_cfg.ui = QM_TEST_PATTERN; 
    enq_cfg.pl = len;
    enq_cfg.da = da;
    enq_cfg.fpqn = QID1;            
    enq_cfg.hl = 1;
    enq_cfg.qid = QID33;             
    enq_cfg.mn =  SLT_MSG_NUM;
    enq_cfg.ms = QM_MSG_SZ_32B;
    enq_cfg.notif = QM_PROC_NOTNO;  

    return (qm_proc_bld_enq_req32(&enq_cfg));
}

enq_req_t *sys_enet_enq_cfg33(u64 da, unsigned int len)
{
    enq_cfg_t enq_cfg;

    enq_cfg.rt = QM_PROC_RTYPE;    
    enq_cfg.ui = QM_TEST_PATTERN; 
    enq_cfg.pl = len;
    enq_cfg.da = da;
    enq_cfg.fpqn = QID2;            
    enq_cfg.hl = 1;
    enq_cfg.qid = QID34;             
    enq_cfg.mn =  SLT_MSG_NUM;
    enq_cfg.ms = QM_MSG_SZ_32B;
    enq_cfg.notif = QM_PROC_NOTNO;  

    return (qm_proc_bld_enq_req33(&enq_cfg));
}

enq_req_t *sys_enet_enq_cfg34(u64 da, unsigned int len)
{
    enq_cfg_t enq_cfg;

    enq_cfg.rt = QM_PROC_RTYPE;    
    enq_cfg.ui = QM_TEST_PATTERN; 
    enq_cfg.pl = len;
    enq_cfg.da = da;
    enq_cfg.fpqn = QID3;            
    enq_cfg.hl = 1;
    enq_cfg.qid = QID35;             
    enq_cfg.mn =  SLT_MSG_NUM;
    enq_cfg.ms = QM_MSG_SZ_32B;
    enq_cfg.notif = QM_PROC_NOTNO;  

    return (qm_proc_bld_enq_req34(&enq_cfg));
}

enq_req_t *sys_enet_enq_cfg_xfi(u64 da, u32 len)
{
    enq_cfg_t enq_cfg;
    enq_req_t *enq_req_test;

    enq_cfg.rt = QM_PROC_RTYPE;   
    enq_cfg.ui = QM_TEST_PATTERN; 
    enq_cfg.pl = len;
    enq_cfg.da = da;
    enq_cfg.fpqn = QID0;            
    enq_cfg.hl = 1;
    enq_cfg.qid = QID32;             
    enq_cfg.mn = SLT_MSG_NUM; 
    enq_cfg.ms = QM_MSG_SZ_32B;
    enq_cfg.notif = QM_PROC_NOTNO;  

    enq_req_test=qm_proc_bld_enq_req_xfi(&enq_cfg);

    return enq_req_test;
}

enq_req_t *sys_enet_enq_cfg32_xfi(u64 da, u32 len)
{
    enq_cfg_t enq_cfg;
    enq_req_t *enq_req_test;

    enq_cfg.rt = QM_PROC_RTYPE;    
    enq_cfg.ui = QM_TEST_PATTERN; 
    enq_cfg.pl = len;
    enq_cfg.da = da;
    enq_cfg.fpqn = QID1;            
    enq_cfg.hl = 1;
    enq_cfg.qid = QID33;             
    enq_cfg.mn = SLT_MSG_NUM; 
    enq_cfg.ms = QM_MSG_SZ_32B;
    enq_cfg.notif = QM_PROC_NOTNO;  

    enq_req_test=qm_proc_bld_enq_req32_xfi(&enq_cfg);

    return enq_req_test;
}

enq_req_t *sys_enet_enq_cfg33_xfi(u64 da, u32 len)
{
    enq_cfg_t enq_cfg;
    enq_req_t *enq_req_test;

    enq_cfg.rt = QM_PROC_RTYPE;    
    enq_cfg.ui = QM_TEST_PATTERN; 
    enq_cfg.pl = len;
    enq_cfg.da = da;
    enq_cfg.fpqn = QID0;            
    enq_cfg.hl = 1;
    enq_cfg.qid = QID32;             
    enq_cfg.mn = SLT_MSG_NUM; 
    enq_cfg.ms = QM_MSG_SZ_32B;
    enq_cfg.notif = QM_PROC_NOTNO;  

    enq_req_test=qm_proc_bld_enq_req33_xfi(&enq_cfg);

    return enq_req_test;
}

enq_req_t *sys_enet_enq_cfg34_xfi(u64 da, u32 len)
{
    enq_cfg_t enq_cfg;
    enq_req_t *enq_req_test;

    enq_cfg.rt = QM_PROC_RTYPE;   
    enq_cfg.ui = QM_TEST_PATTERN; 
    enq_cfg.pl = len;
    enq_cfg.da = da;
    enq_cfg.fpqn = QID1;            
    enq_cfg.hl = 1;
    enq_cfg.qid = QID33;             
    enq_cfg.mn = SLT_MSG_NUM; 
    enq_cfg.ms = QM_MSG_SZ_32B;
    enq_cfg.notif = QM_PROC_NOTNO;  

    enq_req_test=qm_proc_bld_enq_req34_xfi(&enq_cfg);

    return enq_req_test;
}

/*
    Error Code Details:
    0x10 = SGMII Core Link Down
    0x20 = Port Link Down
    0x30 = Enqueue Fail
    0x31 = Dequeue Fail
    0x40 = PEM-STAT Read Timeout, RFSC Error
    0x41 = PEM-STAT Read Timeout, No Packet Received 
    0x50 = Queue State Timeout
    0x60 = Packet CRC Error 
*/
void total_err_count_result_xfi() {

    printf("\n");	
    printf("\n");	
    int port;
     
    if((total_err_count_xfi[0] | total_err_count_xfi[1] | total_err_count_xfi[2] | total_err_count_xfi[3]) == 0x10) {
        for(port=0; port<4; port++) {
            if(total_err_count_xfi[port] == 0x10) {
                printf("\nXFI-SGMII PORT %d -- [ FAIL ] SGMII CORE LINK DOWN (ErrCode:%x)\n",port,total_err_count_xfi[port]);
            }
            else { 
                printf("\nXFI-SGMII PORT %d -- [ INCOMPLETE ] SGMII-CORE LINK-UP TEST ABORTED\n",port);
            }
        }
    }
    if((total_err_count_xfi[0] | total_err_count_xfi[1] | total_err_count_xfi[2] | total_err_count_xfi[3]) == 0x20) {
        for(port=0; port<4; port++) {
            if(total_err_count_xfi[port] == 0x20) {
                printf("\nXFI-SGMII PORT %d -- [ FAIL ] PORT LINK DOWN (ErrCode:%x)\n",port,total_err_count_xfi[port]);
            }
            else { 
                printf("\nXFI-SGMII PORT %d -- [ INCOMPLETE ] PORT LINK-UP TEST ABORTED\n",port);
            }
        }
    }
    if((total_err_count_xfi[0] | total_err_count_xfi[1] | total_err_count_xfi[2] | total_err_count_xfi[3]) == 0x30) {
        for(port=0; port<4; port++) {
            if(total_err_count_xfi[port] == 0x30) {
                printf("\nXFI-SGMII PORT %d -- [ FAIL ] PKT ENQUEUE ERROR (ErrCode:%x)\n",port,total_err_count_xfi[port]);
            }
            else { 
                printf("\nXFI-SGMII PORT %d -- [ INCOMPLETE ] TEST ABORTED\n",port);
            }
        }
    }
    if((total_err_count_xfi[0] | total_err_count_xfi[1] | total_err_count_xfi[2] | total_err_count_xfi[3]) == 0x31) {
        for(port=0; port<4; port++) {
            if(total_err_count_xfi[port] == 0x31) {
                printf("\nXFI-SGMII PORT %d -- [ FAIL ] PKT DEQUEUE ERROR (ErrCode:%x)\n",port,total_err_count_xfi[port]);
            }
            else { 
                printf("\nXFI-SGMII PORT %d -- [ INCOMPLETE ] TEST ABORTED\n",port);
            }
        }
    }
    if((total_err_count_xfi[0] | total_err_count_xfi[1] | total_err_count_xfi[2] | total_err_count_xfi[3]) == 0x40) {
        for(port=0; port<4; port++) {
            if(total_err_count_xfi[port] == 0x40) {
                printf("\nXFI-SGMII PORT %d -- [ FAIL ] PEMSTAT TIMEOUT RFCS ERROR (ErrCode:%x)\n",port,total_err_count_xfi[port]);
            }
            else { 
                printf("\nXFI-SGMII PORT %d -- [ INCOMPLETE ] TEST ABORTED\n",port);
            }
        }
    }
    if((total_err_count_xfi[0] | total_err_count_xfi[1] | total_err_count_xfi[2] | total_err_count_xfi[3]) == 0x41) {
        for(port=0; port<4; port++) {
            if(total_err_count_xfi[port] == 0x41) {
                printf("\nXFI-SGMII PORT %d -- [ FAIL ] PEMSTAT TIMEOUT NO PKT RECEIVED (ErrCode:%x)\n",port,total_err_count_xfi[port]);
            }
            else { 
                printf("\nXFI-SGMII PORT %d -- [ INCOMPLETE ] TEST ABORTED\n",port);
            }
        }
    }
    if((total_err_count_xfi[0] | total_err_count_xfi[1] | total_err_count_xfi[2] | total_err_count_xfi[3]) == 0x50) {
        for(port=0; port<4; port++) {
            if(total_err_count_xfi[port] == 0x50) {
                printf("\nXFI-SGMII PORT %d -- [ FAIL ] QUEUE STATE TIMEOUT (ErrCode:%x)\n",port,total_err_count_xfi[port]);
            }
            else { 
                printf("\nXFI-SGMII PORT %d -- [ INCOMPLETE ] TEST ABORTED\n",port);
            }
        }
    }
    if((total_err_count_xfi[0] | total_err_count_xfi[1] | total_err_count_xfi[2] | total_err_count_xfi[3]) == 0x60) {
        for(port=0; port<4; port++) {
            if(total_err_count_xfi[port] == 0x60) {
                printf("\nXFI-SGMII PORT %d -- [ FAIL ] PKT CRC ERROR (ErrCode:%x)\n",port,total_err_count_xfi[port]);
            }
            else { 
                printf("\nXFI-SGMII PORT %d -- [ INCOMPLETE ] TEST ABORTED\n",port);
            }
        }
    }
    if((total_err_count_xfi[0] | total_err_count_xfi[1] | total_err_count_xfi[2] | total_err_count_xfi[3]) == 0) {
        for(port=0; port<4; port++) {
            printf("\nXFI-SGMII PORT %d -- [ PASS ]\n",port,total_err_count_xfi[port]);
        }
    }

    if(total_err_count_xfi[0] || total_err_count_xfi[1] || total_err_count_xfi[2] || total_err_count_xfi[3])
        printf("\nTest Result : XFI-SGMII FAIL\n");
    else
        printf("\nTest Result : XFI-SGMII PASS\n");
}


int eyescan_xfi_sgmii(int argc, char *argv[]) {
    int port;

    if (argc < 1){
        printf("\nnot enough argument, port# \n\r");
        return -1;
    } else {
        port = atoi(argv[0]);
    }

    printf("\nEyescan for port-%d\n",port);
    eyescan_sub_xfi_sgmii(port, 5);
} 

int eyescan_xfi_sgmii_all_lane() {
    int port;

    for(port=0;port<4;port++) {
        printf("\nEyescan for port-%d\n",port);
        eyescan_sub_xfi_sgmii(port, 5);
    }
} 

int pkt_compare_xfi(int tx_port, int rx_port, u32 pn)
{
    u64 st_address1; 	
    int msg_num;
    u64 st_address2; 	
    u64 st_address3; 	
    u64 st_address4; 	
    u64 addr_1,addr_2;
    u64 addr_3,addr_4;
    u8 wn1[] = {1, 1, 1, 1, 1};

    u32 crc_data_tx,crc_data_rx;

    u64 n_msg_rx[4]={0};
    u64 ddr_base_tx_pkt[4]={0};
    u64 ddr_base_rx_pkt[4]={0};
    u64 k;
    u64 temp_tx,temp_rx;
    int i;
    u32 timeout, pn_tmp;
    int temp=0;

    pn_tmp = pn/4; //required for comparing 4 bytes at atime
    q_state_t q_state_pq_32_1[50];
    q_state_t q_state_pq_33_1[50];
    q_state_t q_state_pq_34_1[50];
    q_state_t q_state_pq_35_1[50];

    q_state_t q_state_pq_64_1[50];
    q_state_t q_state_pq_65_1[50];
    q_state_t q_state_pq_66_1[50];
    q_state_t q_state_pq_67_1[50];

    timeout = 1000000;
    temp = 0;
    while(temp != SLT_MSG_NUM) {
        temp += read_rpkt_as_xg[rx_port] = mcxmac_stat_rd(PEMSTAT_RPKT__ADDR , rx_port);
        timeout--;
        if(timeout==0) {
            printf("PEMSTAT Read Timeout Timeout\n");
            printf("PEMSTAT_RPKT on port-%d: pkt_num:%d temp:%d\n", rx_port, read_rpkt_as_xg[rx_port],temp);
       
            read_rfcs_as_xg[rx_port] = mcxmac_stat_rd(PEMSTAT_RFCS__ADDR , rx_port);
            if(read_rfcs_as_xg[rx_port]) {
                total_err_count_xfi[rx_port]=0x40;
                printf("\nFAIL Port-%d (RFCS ERROR)\n",rx_port);
            }
            else {
                total_err_count_xfi[rx_port]=0x41;
                printf("\nFAIL Port-%d Packets Not Received (SERDES ERROR)\n",rx_port);
            }

            read_rfcs_as_bak_xg[rx_port] += read_rfcs_as_xg[rx_port]; 
            mac_stat_1g_xfi();
            return 1;
        }
        read_rpkt_as_bak_xg[rx_port] += read_rpkt_as_xg[rx_port]; 
    }
    
    
    switch(tx_port) {
        case 0:
            USDELAY(1);// required for even for 1 pkt to read qstate
            QM_CHK_RET(qm_get_q_state_dir(0,32,1,wn1,&q_state_pq_32_1[0]));
            st_address1 = (q_state_pq_32_1[0].pqfp.st_addr);        // start addess of the queue 
            lprintf(8,"\nst_address_tx[0]     : 0x%x\n",st_address1);
            lprintf(8,"n_msg_tx[0]          : 0x%x\n",(q_state_pq_32_1[0].pqfp.n_msg));
            st_address2 = (st_address1<<8);                         // get proper 42 bit start address queue (by shifting 8 bits, refer QM DS)

            if(!(q_state_pq_32_1[0].pqfp.hd_ptr == 0))              // head pointer wraparound 
                st_address1 = (q_state_pq_32_1[0].pqfp.hd_ptr-2);   // get head pointer of queue 
            else 
                st_address1 = 0x3fe;                                // last head pointer of the queue  
            lprintf(8,"hd_prt_tx[0]         : 0x%x\n",st_address1);
            st_address2 += (st_address1<<4);                        // get proper head pointer (by shifting 4 bits, refer QM DS)

            st_address2 +=8;                                        // get the proper offest freePool buffer 
            lprintf(8,"st_address2[0]       : 0x%x\n",st_address2);
            st_address2 = qm_get_va(st_address2);                   // get the virtual address
            addr_1      = read_64((u64 *)st_address2);
            addr_1      &= 0x3ffffffffff;
            lprintf(8,"addr_1[0]            : 0x%x\n",addr_1);
            ddr_base_tx_pkt[0] = qm_get_va(addr_1);

            lprintf(8,"ddr_base_tx_pkt[0]   : 0x%x\n",ddr_base_tx_pkt[0]);
            lprintf(8,"hd_ptr_tx[0]         : 0x%x\n",q_state_pq_32_1[0].pqfp.hd_ptr);
            lprintf(8,"addr_1[0]            : 0x%x\n",addr_1);
            break;

        case 1:
            USDELAY(1);// required for even for 1 pkt to read qstate
            QM_CHK_RET(qm_get_q_state_dir(0,33,1,wn1,&q_state_pq_33_1[0]));
            st_address1 = (q_state_pq_33_1[0].pqfp.st_addr);        // start addess of the queue 
            lprintf(8,"\nst_address_tx[1]     : 0x%x\n",st_address1);
            lprintf(8,"n_msg_tx[1]          : 0x%x\n",(q_state_pq_33_1[0].pqfp.n_msg));
            st_address2 = (st_address1<<8);                         // get proper 42 bit start address queue (by shifting 8 bits, refer QM DS)

            if(!(q_state_pq_33_1[0].pqfp.hd_ptr == 0))              // head pointer wraparound 
                st_address1 = (q_state_pq_33_1[0].pqfp.hd_ptr - 2); // get head pointer of queue 
            else 
                st_address1 = 0x3fe;                                // last head pointer of the queue   
            lprintf(8,"hd_prt_tx[1]         : 0x%x\n",st_address1);
            st_address2 += (st_address1<<4);                        // get proper head pointer (by shifting 4 bits, refer QM DS)

            st_address2 +=8;                                        // get the proper offest freePool buffer 
            st_address2 = qm_get_va(st_address2);                   // get the virtual address
            addr_1      = read_64((u64 *)st_address2);
            addr_1      &= 0x3ffffffffff;
            lprintf(8,"addr_1[1]            : 0x%x\n",addr_1);
            ddr_base_tx_pkt[1] = qm_get_va(addr_1);

            lprintf(8,"ddr_base_tx_pkt[1]   : 0x%x\n",ddr_base_tx_pkt[1]);
            lprintf(8,"hd_ptr_tx[1]         : 0x%x\n",q_state_pq_33_1[0].pqfp.hd_ptr);
            lprintf(8,"addr_1[1]            : 0x%x\n",addr_1);
            break;

        case 2:
            USDELAY(1);// required for even for 1 pkt to read qstate
            QM_CHK_RET(qm_get_q_state_dir(2,32,1,wn1,&q_state_pq_34_1[0]));
            st_address1 = (q_state_pq_34_1[0].pqfp.st_addr);
            lprintf(8,"\nst_address_tx[2]     : 0x%x\n",st_address1);
            lprintf(8,"n_msg_tx[2]          : 0x%x\n",(q_state_pq_34_1[0].pqfp.n_msg));
            st_address2 = (st_address1<<8);
            if(!(q_state_pq_34_1[0].pqfp.hd_ptr == 0))
                st_address1 = (q_state_pq_34_1[0].pqfp.hd_ptr - 2);     // get head pointer of queue 
            else 
                st_address1 = 0x3fe;     
            lprintf(8,"hd_prt_tx[2]         : 0x%x\n",st_address1);
            st_address2 += (st_address1<<4);
            st_address2 +=8;
            st_address2 = qm_get_va(st_address2);
            addr_1      = read_64((u64 *)st_address2);
            addr_1      &= 0x3ffffffffff;
            lprintf(8,"addr_1[2]            : 0x%x\n",addr_1);
            ddr_base_tx_pkt[2] = qm_get_va(addr_1);

            lprintf(8,"ddr_base_tx_pkt[2]   : 0x%x\n",ddr_base_tx_pkt[2]);
            lprintf(8,"hd_ptr_tx[2]         : 0x%x\n",q_state_pq_34_1[0].pqfp.hd_ptr);
            lprintf(8,"addr_1[2]            : 0x%x\n",addr_1);
            break;

        case 3:
            USDELAY(1);// required for even for 1 pkt to read qstate
            QM_CHK_RET(qm_get_q_state_dir(2,33,1,wn1,&q_state_pq_35_1[0]));
            st_address1 = (q_state_pq_35_1[0].pqfp.st_addr);
            lprintf(8,"\nst_address_tx[3]     : 0x%x\n",st_address1);
            lprintf(8,"n_msg_tx[3]          : 0x%x\n",(q_state_pq_35_1[0].pqfp.n_msg));
            st_address2 = (st_address1<<8);
            if(!(q_state_pq_35_1[0].pqfp.hd_ptr == 0))
                st_address1 = (q_state_pq_35_1[0].pqfp.hd_ptr - 2);     // get head pointer of queue 
            else 
                st_address1 = 0x3fe;     
            lprintf(8,"hd_prt_tx[3]         : 0x%x\n",st_address1);
            st_address2 += (st_address1<<4);            

            st_address2 +=8;
            st_address2 = qm_get_va(st_address2);
            addr_1      = read_64((u64 *)st_address2);
            addr_1      &= 0x3ffffffffff;
            lprintf(8,"addr_1[3]            : 0x%x\n",addr_1);
            ddr_base_tx_pkt[3] = qm_get_va(addr_1);

            lprintf(8,"ddr_base_tx_pkt[3]   : 0x%x\n",ddr_base_tx_pkt[3]);
            lprintf(8,"hd_ptr_tx[3]         : 0x%x\n",q_state_pq_35_1[0].pqfp.hd_ptr);
            lprintf(8,"addr_1[3]            : 0x%x\n",addr_1);
            break;

defaut:
            printf("Wrong Port number\n");
    }
    switch(rx_port) {
        case 0:
            USDELAY(1);// required for even for 1 pkt to read qstate
            QM_CHK_RET(qm_get_q_state_dir(0,64,1,wn1,&q_state_pq_64_1[0]));
            timeout = 1000000;
            while((q_state_pq_64_1[0].pqfp.n_msg)!= SLT_MSG_NUM) {          // Polling number of msg Tx-Msg=Rx-Msg
                QM_CHK_RET(qm_get_q_state_dir(0,64,1,wn1,&q_state_pq_64_1[0]));
                timeout--;
                if(timeout==0) {
                    printf("Queue State Timeout Timeout\n");
                    printf("n_msg_rx[0]          : 0x%x\n",(q_state_pq_64_1[0].pqfp.n_msg));
                    total_err_count_xfi[0]=0x50;
                    return 1;
                }
            }
            st_address1 = (q_state_pq_64_1[0].pqfp.st_addr);                // start addess of the queue 
            lprintf(8,"\nst_address_rx[0]     : 0x%x\n",st_address1);
            st_address2 = (st_address1<<8);                                 // get proper 42 bit start address queue (by shifting 8 bits, refer QM DS)
            lprintf(8,"n_msg_rx[0]           : 0x%x\t",(q_state_pq_64_1[0].pqfp.n_msg));   
            lprintf(8,"hd_ptr_rx[0]          : 0x%x\n",(q_state_pq_64_1[0].pqfp.hd_ptr));
            if(!((q_state_pq_64_1[0].pqfp.hd_ptr + 2*q_state_pq_64_1[0].pqfp.n_msg) == 0))      // get proper Rx buffer addresss
                st_address1 = (q_state_pq_64_1[0].pqfp.hd_ptr+ 2*q_state_pq_64_1[0].pqfp.n_msg -2);  
            else 
                st_address1 = 0x3fe;     
            st_address2 += (st_address1<<4);                    // get proper head pointer (by shifting 4 bits, refer QM DS)
            lprintf(8,"fetch_addr_rx[0]      : 0x%x\n",st_address1);
            st_address2 += 8;                                   // get the proper offest freePool buffer 
            st_address2 = qm_get_va(st_address2);               // get the virtual address
            addr_1 = read_64((u64 *)st_address2);
            addr_1 &= 0x3ffffffffff;
            lprintf(8,"addr_1[0]            : 0x%x\n",addr_1);
            ddr_base_rx_pkt[0] = qm_get_va(addr_1);

            lprintf(8,"ddr_base_rx_pkt[0]   : 0x%x\n",ddr_base_rx_pkt[0]);
            lprintf(8,"hd_ptr_rx[0]         : 0x%x\n",q_state_pq_33_1[0].pqfp.hd_ptr);
            lprintf(8,"addr_1[0]            : 0x%x\n",addr_1);
            data_cache_flush_all();
            break;

        case 1:
            USDELAY(1);// required for even for 1 pkt to read qstate
            QM_CHK_RET(qm_get_q_state_dir(0,65,1,wn1,&q_state_pq_65_1[0]));
            lprintf(8,"\nst_address_rx[1]     : 0x%x\n",st_address1);
            timeout = 1000000;
            while((q_state_pq_65_1[0].pqfp.n_msg)!= SLT_MSG_NUM) {
                QM_CHK_RET(qm_get_q_state_dir(0,65,1,wn1,&q_state_pq_65_1[0]));
                timeout--;
                if(timeout==0) {
                    printf("Queue State Timeout Timeout\n");
                    printf("n_msg_rx[1]          : 0x%x\n",(q_state_pq_65_1[0].pqfp.n_msg));
                    total_err_count_xfi[1]=0x50;
                    return 1;
                }                
            }
            st_address1 = (q_state_pq_65_1[0].pqfp.st_addr);    // start addess of the queue 
            lprintf(8,"st_address_rx[1]      : 0x%x\n",st_address1);
            n_msg_rx[1]+= (q_state_pq_65_1[0].pqfp.n_msg);
            lprintf(8,"n_msg_rx[1]           : 0x%x\t",(q_state_pq_65_1[0].pqfp.n_msg));
            lprintf(8,"hd_ptr_rx[1]          : 0x%x\n",(q_state_pq_65_1[0].pqfp.hd_ptr));
            st_address2 = (st_address1<<8);                     // get proper 42 bit start address queue (by shifting 8 bits, refer QM DS)
            if(!((q_state_pq_65_1[0].pqfp.hd_ptr+ 2*q_state_pq_65_1[0].pqfp.n_msg) == 0))
                st_address1 = (q_state_pq_65_1[0].pqfp.hd_ptr+ 2*q_state_pq_65_1[0].pqfp.n_msg-2);   // get head pointer of queue
            else 
                st_address1 = 0x3fe;     
            lprintf(8,"hd_ptr_rx[1]         : 0x%x\n",st_address1);
            st_address2 += (st_address1<<4);                    // get proper head pointer (by shifting 4 bits, refer QM DS)
            st_address2 +=8;                                    // get the proper offest freePool buffer 
            st_address2 = qm_get_va(st_address2);               // get the virtual address
            addr_1 = read_64((u64 *)st_address2);
            addr_1 &= 0x3ffffffffff;
            lprintf(8,"addr_1[1]            : 0x%x\n",addr_1);
            ddr_base_rx_pkt[1] = qm_get_va(addr_1);

            lprintf(8,"ddr_base_rx_pkt[1]   : 0x%x\n",ddr_base_rx_pkt[1]);
            lprintf(8,"hd_ptr_rx[1]         : 0x%x\n",q_state_pq_32_1[0].pqfp.hd_ptr);
            lprintf(8,"addr_1[1]            : 0x%x\n",addr_1);
            data_cache_flush_all();
            break;

        case 2:
            USDELAY(1);// required for even for 1 pkt to read qstate
            QM_CHK_RET(qm_get_q_state_dir(2,64,1,wn1,&q_state_pq_66_1[0]));
            timeout = 1000000;
            while((q_state_pq_66_1[0].pqfp.n_msg)!= SLT_MSG_NUM) {
                QM_CHK_RET(qm_get_q_state_dir(2,64,1,wn1,&q_state_pq_66_1[0]));
                timeout--;
                if(timeout==0) {
                    printf("Queue State Timeout Timeout\n");
                    printf("n_msg_rx[2]          : 0x%x\n",(q_state_pq_66_1[0].pqfp.n_msg));
                    total_err_count_xfi[2]=0x50;
                    return 1;
                }                
            }
            st_address1 = (q_state_pq_66_1[0].pqfp.st_addr);
            n_msg_rx[2]+= (q_state_pq_66_1[0].pqfp.n_msg);
            lprintf(8,"n_msg_rx[2]          : 0x%x\t",(q_state_pq_66_1[0].pqfp.n_msg));
            lprintf(8,"hd_ptr_rx[2]         : 0x%x\n",(q_state_pq_66_1[0].pqfp.hd_ptr));
            lprintf(8,"\nst_address_rx[2]   : 0x%x\n",st_address1);
            st_address2 = (st_address1<<8);
            if(!((q_state_pq_66_1[0].pqfp.hd_ptr+ 2*q_state_pq_66_1[0].pqfp.n_msg) == 0))
                st_address1 = (q_state_pq_66_1[0].pqfp.hd_ptr+ 2*q_state_pq_66_1[0].pqfp.n_msg -2);   // get head pointer of queue
            else 
                st_address1 = 0x3fe;     
            lprintf(8,"st_address_rx[2]     : 0x%x\n",st_address1);
            st_address2 += (st_address1<<4);
            st_address2+=8;
            st_address2 = qm_get_va(st_address2);
            addr_1 = read_64((u64 *)st_address2);
            addr_1 &= 0x3ffffffffff;
            lprintf(8,"addr_1[2]            : 0x%x\n",addr_1);
            ddr_base_rx_pkt[2] = qm_get_va(addr_1);

            lprintf(8,"ddr_base_rx_pkt[2]   : 0x%x\n",ddr_base_rx_pkt[2]);
            lprintf(8,"hd_ptr_rx[2]         : 0x%x\n",q_state_pq_35_1[0].pqfp.hd_ptr);
            lprintf(8,"addr_1[2]            : 0x%x\n",addr_1);
            data_cache_flush_all();
            break;

        case 3:
            USDELAY(1);// required for even for 1 pkt to read qstate
            QM_CHK_RET(qm_get_q_state_dir(2,65,1,wn1,&q_state_pq_67_1[0]));
            timeout = 1000000;
            while((q_state_pq_67_1[0].pqfp.n_msg)!= SLT_MSG_NUM) {
                QM_CHK_RET(qm_get_q_state_dir(2,65,1,wn1,&q_state_pq_67_1[0]));
                timeout--;
                if(timeout==0) {
                    printf("Queue State Timeout Timeout\n");
                    printf("n_msg_rx[3]          : 0x%x\n",(q_state_pq_67_1[0].pqfp.n_msg));
                    total_err_count_xfi[3]=0x50;
                    return 1;
                }                
            }
            st_address1 = (q_state_pq_67_1[0].pqfp.st_addr);
            n_msg_rx[3]+= (q_state_pq_67_1[0].pqfp.n_msg);
            lprintf(8,"n_msg_rx[3]          : 0x%x\t",(q_state_pq_67_1[0].pqfp.n_msg));
            lprintf(8,"hd_ptr_rx[3]         : 0x%x\n",(q_state_pq_67_1[0].pqfp.hd_ptr));
            st_address2 = (st_address1<<8);
            if(!((q_state_pq_67_1[0].pqfp.hd_ptr+ 2*q_state_pq_67_1[0].pqfp.n_msg) == 0))
                st_address1 = (q_state_pq_67_1[0].pqfp.hd_ptr+ 2*q_state_pq_67_1[0].pqfp.n_msg -2);   // get head pointer of queue
            else 
                st_address1 = 0x3fe;     
            lprintf(8,"st_address_rx[3]     : 0x%x\n",st_address1);
            st_address2 += (st_address1<<4);
            st_address2+=8;
            st_address2 = qm_get_va(st_address2); //works for DIMM suze (1/2/4/8/16GB)
            addr_1 = read_64((u64 *)st_address2);
            addr_1 &= 0x3ffffffffff;
            lprintf(8,"addr_1[3]            : 0x%x\n",addr_1);
            ddr_base_rx_pkt[3] = qm_get_va(addr_1);

            lprintf(8,"ddr_base_rx_pkt[3]   : 0x%x\n",ddr_base_rx_pkt[2]);
            lprintf(8,"hd_ptr_rx[3]         : 0x%x\n",q_state_pq_34_1[0].pqfp.hd_ptr);
            lprintf(8,"addr_1[3]            : 0x%x\n",addr_1);
            data_cache_flush_all();
            break;
        default :
            printf("Worng port\n");
    }

    switch(rx_port) {
        case 0 :
            if(read_rpkt_as_xg[rx_port]) {
                for(msg_num=0;msg_num<SLT_MSG_NUM;msg_num++) {
                    for(k=0;k<pn_tmp;k++) {
                        crc_data_tx=read_word((u64 *)(ddr_base_tx_pkt[tx_port]+(k*4)));
                        crc_data_rx=read_word((u64 *)(ddr_base_rx_pkt[rx_port]+((SLT_FP_SIZE*msg_num)+(k*4)-SLT_FP_SIZE*(SLT_MSG_NUM-1))));  // To Reset the Rx st_adress pointer to start of the Received Packet instead of current packet
                        if(crc_data_tx!=crc_data_rx) {
                            printf("\nPort 0 (PKT CRC ERROR)\nmsg_num=%d ADDR_tx= 0x%x ADDR_rx= 0x%x\n", msg_num,ddr_base_tx_pkt[tx_port]+(k*4), ddr_base_rx_pkt[rx_port]+((SLT_FP_SIZE*msg_num)+(k*4)-SLT_FP_SIZE*(SLT_MSG_NUM-1) ));
                            printf("data_tx=0x%x data_rx= 0x%x\n",crc_data_tx,crc_data_rx);
                            printf("FAIL\n");
                            total_err_count_xfi[0]=0x60;
                            mac_stat_1g_xfi();
                            return 1;
                        }
                    }
                } 
            }
            break;

        case 1 :
            if(read_rpkt_as_xg[rx_port]) {
                for(msg_num=0;msg_num<SLT_MSG_NUM;msg_num++) {
                    for(k=0;k<pn_tmp;k++) {
                        crc_data_tx=read_word((u64 *)(ddr_base_tx_pkt[tx_port]+(k*4)));
                        crc_data_rx=read_word((u64 *)(ddr_base_rx_pkt[rx_port]+((SLT_FP_SIZE*msg_num)+(k*4) -SLT_FP_SIZE*(SLT_MSG_NUM-1)))); 
                        if(crc_data_tx!=crc_data_rx) {
                            printf("\nPort 1 (PKT CRC ERROR)\nmsg_num=%d ADDR_tx= 0x%x ADDR_rx= 0x%x\n", msg_num,ddr_base_tx_pkt[tx_port]+(k*4), ddr_base_rx_pkt[rx_port]+((SLT_FP_SIZE*msg_num)+(k*4)) -SLT_FP_SIZE*(SLT_MSG_NUM-1));
                            printf("data_tx=0x%x data_rx= 0x%x\n",crc_data_tx,crc_data_rx);
                            printf("FAIL\n");
                            total_err_count_xfi[1]=0x60;
                            mac_stat_1g_xfi();
                            return 1;
                        }
                    }
                }
            }
            break;

        case 2 :
            if(read_rpkt_as_xg[rx_port]) {
                for(msg_num=0;msg_num<SLT_MSG_NUM;msg_num++) {
                    for(k=0;k<pn_tmp;k++) {
                        crc_data_tx=read_word((u64 *)(ddr_base_tx_pkt[tx_port]+(k*4)));
                        crc_data_rx=read_word((u64 *)(ddr_base_rx_pkt[rx_port]+((SLT_FP_SIZE*msg_num)+(k*4)-SLT_FP_SIZE*(SLT_MSG_NUM-1))));  
                        if(crc_data_tx!=crc_data_rx) {
                            printf("\nPort 2 (PKT CRC ERROR)\nmsg_num=%d ADDR_tx= 0x%x ADDR_rx= 0x%x\n", msg_num,ddr_base_tx_pkt[tx_port]+(k*4), ddr_base_rx_pkt[rx_port]+((SLT_FP_SIZE*msg_num)+(k*4) -SLT_FP_SIZE*(SLT_MSG_NUM-1)));
                            printf("data_tx=0x%x data_rx= 0x%x\n",crc_data_tx,crc_data_rx);
                            printf("FAIL\n");
                            total_err_count_xfi[2]=0x60;
                            mac_stat_1g_xfi();
                            return 1;
                        }
                    }
                } 
            }
            break;

        case 3 :
            if(read_rpkt_as_xg[rx_port]) {
                for(msg_num=0;msg_num<SLT_MSG_NUM;msg_num++) {
                    for(k=0;k<pn_tmp;k++) {
                        crc_data_tx=read_word((u64 *)(ddr_base_tx_pkt[tx_port]+(k*4)));
                        crc_data_rx=read_word((u64 *)(ddr_base_rx_pkt[rx_port]+((SLT_FP_SIZE*msg_num)+(k*4) -SLT_FP_SIZE*(SLT_MSG_NUM-1))));
                        if(crc_data_tx!=crc_data_rx) {
                            printf("\nPort 3 (PKT CRC ERROR)\nmsg_num=%d ADDR_tx= 0x%x ADDR_rx= 0x%x\n", msg_num,ddr_base_tx_pkt[tx_port]+(k*4), ddr_base_rx_pkt[rx_port]+((SLT_FP_SIZE*msg_num)+(k*4)-SLT_FP_SIZE*(SLT_MSG_NUM-1) ));
                            printf("data_tx=0x%x data_rx= 0x%x\n",crc_data_tx,crc_data_rx);
                            printf("FAIL\n");
                            total_err_count_xfi[3]=0x60;                              
                            mac_stat_1g_xfi();
                            return 1;
                        }
                    }
                }
            }
            break;

        default :
            printf("\nOops !! Invalid port number passed\n");
    }
    return 0;
}

int eth_dbg_xfi() {

    total_err_count_xfi[0]=0;
    total_err_count_xfi[1]=0;
    total_err_count_xfi[2]=0;
    total_err_count_xfi[3]=0;
    unsigned int ps,pn,temp;
    u64 *guess;
    qm_ret_t ret;
    enq_req_t *per;
    enq_req_t *per32;
    enq_req_t *per33;
    enq_req_t *per34;    
    qm_buf_t qm_buf_xfi;
    qm_buf_t qm_buf32_xfi;
    qm_buf_t qm_buf33_xfi;
    qm_buf_t qm_buf34_xfi;    
    enq_cfg_t enq_cfg;
    q_state_t cfg;
    int tx_port,rx_port, mn; 
    int port,i,retval;
    u32 fpqid, dots;
    u8 pdl_pattern,qmid;
    u16 tx_enq_qid, rx_deq_qid;

    qm_buf_xfi.bp = buf_xfi;
    qm_buf32_xfi.bp = buf32_xfi;
    qm_buf33_xfi.bp = buf33_xfi;
    qm_buf34_xfi.bp = buf34_xfi; 

    memset ((u8 *)msgbuf_xfi, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    memset ((u8 *)msgbuf32_xfi, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    memset ((u8 *)msgbuf33_xfi, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    memset ((u8 *)msgbuf34_xfi, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);

#ifdef RANDOMIZE_SLT    
    ps=(rand()%1454)+64; 
#else    
    ps=512; //256; 
#endif    
    //pn=0x40000; //0x140000; //0x40000; //0x280000; //0x100000; //10; //10000; //100;
    printf("\nXFI-SGMII Test\n");
    printf("\n\nEnter No of packets in hex : 0x");pn = get_val(); //pn = get_val(); 

    for(port=0; port<4; port++) {
        if(!(sgmii_core_link_check(port,XGENET))) {
            printf("\nPort-%d XFI-SGMII Core Link is DOWN!!!!\n",port);
            total_err_count_xfi[port] = 0x10;
        }
    }
    
    if(total_err_count_xfi[0] || total_err_count_xfi[1] || total_err_count_xfi[2] || total_err_count_xfi[3]) return 1;
    
    if(!(port_link_check(0x15))) {
        printf("\nPort-0 Link is DOWN!!!!\n");
        printf("Please Connect CAT-5 Cable From Port-0 to Port-1, Then Rerun the Test\n");
        total_err_count_xfi[0] = 0x20;
    }
    if(!(port_link_check(0x16))) {
        printf("\nPort-1 Link is DOWN!!!!\n");
        printf("Please Connect CAT-5 Cable From Port-1 to Port-0, Then Rerun the Test\n");
        total_err_count_xfi[1] = 0x20;
    }
    if(!(port_link_check(0x17))) {
        printf("\nPort-2 Link is DOWN!!!!\n");
        printf("Please Connect CAT-5 Cable From Port-2 to Port-3, Then Rerun the Test\n");
        total_err_count_xfi[2] = 0x20;
    }
    if(!(port_link_check(0x18))) {
        printf("\nPort-3 Link is DOWN!!!!\n");
        printf("Please Connect CAT-5 Cable From Port-3 to Port-2, Then Rerun the Test\n");
        total_err_count_xfi[3] = 0x20;        
    }
    
    if(total_err_count_xfi[0] || total_err_count_xfi[1] || total_err_count_xfi[2] || total_err_count_xfi[3]) return 1;
    
    printf("\nTotal no. of packets =%d Enqueued at a time with no of pkts :%d with pkt size: %d... \n",pn,SLT_MSG_NUM, ps);
    printf("Number of Packets Expected to Transmit and Receive:%d\n",(pn*SLT_MSG_NUM));
    printf("\nRunning Ethernet Traffic [");
    
    pn = pn*4;
    dots = pn/20;
    mn = QM_TEST_MSG_NUM; 

    qmid = 0;
    fpqid=0;
    ret = sys_alloc_enet_buf(qmid, fpqid, mn, &qm_buf_xfi); 
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf Fail qmid:%d\r\n",qmid);
        return ret;
    }
    fpqid=1;
    ret = sys_alloc_enet_buf(qmid, fpqid, mn, &qm_buf32_xfi); 
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf qm_buf32_xfi Fail qmid:%d\r\n",qmid);
        return ret;
    }
    qmid = 2;
    fpqid=0;
    ret = sys_alloc_enet_buf(qmid, fpqid, mn, &qm_buf33_xfi); 
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf qm_buf33_xfi Fail qmid:%d\r\n",qmid);
        return ret;
    }
    fpqid=1;
    ret = sys_alloc_enet_buf(qmid, fpqid, mn, &qm_buf34_xfi); 
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf qm_buf34_xfi Fail qmid:%d\r\n",qmid);
        return ret;
    }

    pdl_pattern=0xAA;
    ret = qm_build_eth_pkt_pdl((unsigned char *)buf_xfi[0], ps, pdl_pattern);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt_pdl Fail qmid:%d\r\n",qmid);
        return ret;

    }    
    pdl_pattern=0x55; //0xBB;
    ret = qm_build_eth_pkt_pdl((unsigned char *)buf32_xfi[0], ps, pdl_pattern);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt_pdl buf32_xfi Fail qmid:%d\r\n",qmid);
        return ret;

    }    
    pdl_pattern=0xAA; //0xCC;
    ret = qm_build_eth_pkt_pdl((unsigned char *)buf33_xfi[0], ps, pdl_pattern);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt_pdl buf33_xfi Fail qmid:%d\r\n",qmid);
        return ret;

    }    
    pdl_pattern=0x55; //0xDD;
    ret = qm_build_eth_pkt_pdl((unsigned char *)buf34_xfi[0], ps, pdl_pattern);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt_pdl buf34_xfi Fail qmid:%d\r\n",qmid);
        return ret;

    }

    per = sys_enet_enq_cfg_xfi(buf_xfi[0], ps);
    extern enq_req_t er_xfi;
    per = &er_xfi;
    if (!per) {
        printf("QM sys_enet_enq_cfg_xfi failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }
    per32 = sys_enet_enq_cfg32_xfi(buf32_xfi[0], ps);
    extern enq_req_t er32_xfi;
    per32 = &er32_xfi;
    if (!per32) {
        printf("QM sys_enet_enq_cfg32_xfi failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }
    per33 = sys_enet_enq_cfg33_xfi(buf33_xfi[0], ps);
    extern enq_req_t er33_xfi;
    per33 = &er33_xfi;
    if (!per33) {
        printf("QM sys_enet_enq_cfg33_xfi failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }
    per34 = sys_enet_enq_cfg34_xfi(buf34_xfi[0], ps);
    extern enq_req_t er34_xfi;
    per34 = &er34_xfi;
    if (!per34) {
        printf("QM sys_enet_enq_cfg34_xfi failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }

    for(i=0; i<pn; i++) {
        if((i%4) == 0) {
            dcache_flush_all();
            tx_port=0;  rx_port=1;	
            tx_enq_qid = QID32; rx_deq_qid = QID65;
            per->qid =  tx_enq_qid;     // port-0
            ret = qm_proc_enq_dir(0,per);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count_xfi[0] = 0x30;
                return ret;
            }
            retval = pkt_compare_xfi(tx_port, rx_port, ps);
            if(retval)
                return 1;              
            mn=SLT_MSG_NUM;
            while(mn) {
                mn = SLT_MSG_NUM;
                ret = qm_proc_deq_dir(0, rx_deq_qid, QM_MSG_SZ_32B, &mn, msgbuf_xfi); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    total_err_count_xfi[0] = 0x31;
                    return ret;
                }
                mn=0; 
            }
        }
        else if((i%4) == 1)  {
            dcache_flush_all();
            tx_port=1; rx_port=0;
            tx_enq_qid = QID33; rx_deq_qid = QID64;	
            per32->qid = tx_enq_qid;     // port-1
            ret = qm_proc_enq_dir(0,per32);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count_xfi[1] = 0x30;
                return ret;
            }            
            retval = pkt_compare_xfi(tx_port, rx_port, ps);
            if(retval)
                return 1;              
            mn=SLT_MSG_NUM;
            while(mn) {
                mn = SLT_MSG_NUM;
                ret = qm_proc_deq_dir(0, rx_deq_qid, QM_MSG_SZ_32B, &mn, msgbuf32_xfi); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    total_err_count_xfi[1] = 0x31;
                    return ret;
                }
                mn=0; 
            }
        } 
        else if((i%4) == 2)  {
            dcache_flush_all();
            tx_port=2; rx_port=3;	
            tx_enq_qid = QID32; rx_deq_qid = QID65;
            per33->qid = tx_enq_qid;    // port-1
            ret = qm_proc_enq_dir(2,per33);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count_xfi[2] = 0x30;
                return ret;
            }             
            retval = pkt_compare_xfi(tx_port, rx_port ,ps);
            if(retval)
                return 1;              
            mn=SLT_MSG_NUM;
            while(mn) {
                mn = SLT_MSG_NUM;
                ret = qm_proc_deq_dir(2, rx_deq_qid, QM_MSG_SZ_32B, &mn, msgbuf33_xfi); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    total_err_count_xfi[2] = 0x31;
                    return ret;
                }
                mn=0; 
            }
        }
        else if((i%4) == 3)  {
            dcache_flush_all();
            tx_port=3; rx_port=2;
            tx_enq_qid = QID33;	 rx_deq_qid = QID64;    
            per34->qid = tx_enq_qid;     // port-1
            ret = qm_proc_enq_dir(2,per34);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count_xfi[3] = 0x30;
                return ret;
            }             
            retval = pkt_compare_xfi(tx_port, rx_port, ps);
            if(retval)
                return 1;              
            mn=SLT_MSG_NUM;
            while(mn) {
                mn = SLT_MSG_NUM;
                ret = qm_proc_deq_dir(2, rx_deq_qid, QM_MSG_SZ_32B, &mn, msgbuf34_xfi); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    total_err_count_xfi[3] = 0x31;
                    return ret;
                }
                mn=0; 
            }
        }

        lprintf(8, "\n<----------------- PortNo:%d PacketNo:%d ------------------->\n",(i%4),(i/4));
        if ((i%dots==0)) printf(".");
    }
    printf("]\n");
    return 0;
}

int eth_tx2rx_lpbk_test_xfi_1g_ext_lpbk() {

    total_err_count_xfi[0]=0;
    total_err_count_xfi[1]=0;
    total_err_count_xfi[2]=0;
    total_err_count_xfi[3]=0;
    unsigned int ps,pn,temp;
    u64 *guess;
    qm_ret_t ret;
    enq_req_t *per;
    enq_req_t *per32;
    enq_req_t *per33;
    enq_req_t *per34;    
    qm_buf_t qm_buf_xfi;
    qm_buf_t qm_buf32_xfi;
    qm_buf_t qm_buf33_xfi;
    qm_buf_t qm_buf34_xfi;    
    enq_cfg_t enq_cfg;
    q_state_t cfg;
    int tx_port,rx_port, mn; 
    int port,i,retval;
    u32 fpqid, dots;
    u8 pdl_pattern,qmid;
    u16 tx_enq_qid, rx_deq_qid;

    qm_buf_xfi.bp = buf_xfi;
    qm_buf32_xfi.bp = buf32_xfi;
    qm_buf33_xfi.bp = buf33_xfi;
    qm_buf34_xfi.bp = buf34_xfi; 

    memset ((u8 *)msgbuf_xfi, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    memset ((u8 *)msgbuf32_xfi, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    memset ((u8 *)msgbuf33_xfi, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    memset ((u8 *)msgbuf34_xfi, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);

#ifdef RANDOMIZE_SLT    
    ps=(rand()%1454)+64; 
#else    
    ps=512; //256; 
#endif    
    pn=0x40000; //0x140000; //0x40000; //0x280000; //0x100000; //10; //10000; //100;
    //printf("\n\nEnter No of packets in hex : 0x");pn = get_val(); //pn = get_val(); 

    for(port=0; port<4; port++) {
        if(!(sgmii_core_link_check(port,XGENET))) {
            printf("\nPort-%d SGMII Core Link is DOWN!!!!\n",port);
            total_err_count_xfi[port] = 0x10;
        }
    }
    
    if(total_err_count_xfi[0] || total_err_count_xfi[1] || total_err_count_xfi[2] || total_err_count_xfi[3]) return 1;
    
    if(!(port_link_check(0x15))) {
        printf("\nPort-0 Link is DOWN!!!!\n");
        printf("Please Connect CAT-5 Cable From Port-0 to Port-1, Then Rerun the Test\n");
        total_err_count_xfi[0] = 0x20;
    }
    if(!(port_link_check(0x16))) {
        printf("\nPort-1 Link is DOWN!!!!\n");
        printf("Please Connect CAT-5 Cable From Port-1 to Port-0, Then Rerun the Test\n");
        total_err_count_xfi[1] = 0x20;
    }
    if(!(port_link_check(0x17))) {
        printf("\nPort-2 Link is DOWN!!!!\n");
        printf("Please Connect CAT-5 Cable From Port-2 to Port-3, Then Rerun the Test\n");
        total_err_count_xfi[2] = 0x20;
    }
    if(!(port_link_check(0x18))) {
        printf("\nPort-3 Link is DOWN!!!!\n");
        printf("Please Connect CAT-5 Cable From Port-3 to Port-2, Then Rerun the Test\n");
        total_err_count_xfi[3] = 0x20;        
    }
    
    if(total_err_count_xfi[0] || total_err_count_xfi[1] || total_err_count_xfi[2] || total_err_count_xfi[3]) return 1;
    
    printf("\nTotal no. of packets =%d Enqueued at a time with no of pkts :%d with pkt size: %d... \n",pn,SLT_MSG_NUM, ps);
    printf("Number of Packets Expected to Transmit and Receive:%d\n",(pn*SLT_MSG_NUM));
    printf("\nRunning Ethernet Traffic [");
    
    pn = pn*4;
    dots = pn/20;
    mn = QM_TEST_MSG_NUM; 

    qmid = 0;
    fpqid=0;
    ret = sys_alloc_enet_buf(qmid, fpqid, mn, &qm_buf_xfi); 
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf Fail qmid:%d\r\n",qmid);
        return ret;
    }
    fpqid=1;
    ret = sys_alloc_enet_buf(qmid, fpqid, mn, &qm_buf32_xfi); 
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf qm_buf32_xfi Fail qmid:%d\r\n",qmid);
        return ret;
    }
    qmid = 2;
    fpqid=0;
    ret = sys_alloc_enet_buf(qmid, fpqid, mn, &qm_buf33_xfi); 
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf qm_buf33_xfi Fail qmid:%d\r\n",qmid);
        return ret;
    }
    fpqid=1;
    ret = sys_alloc_enet_buf(qmid, fpqid, mn, &qm_buf34_xfi); 
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf qm_buf34_xfi Fail qmid:%d\r\n",qmid);
        return ret;
    }

    pdl_pattern=0xAA;
    ret = qm_build_eth_pkt_pdl((unsigned char *)buf_xfi[0], ps, pdl_pattern);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt_pdl Fail qmid:%d\r\n",qmid);
        return ret;

    }    
    pdl_pattern=0x55; //0xBB;
    ret = qm_build_eth_pkt_pdl((unsigned char *)buf32_xfi[0], ps, pdl_pattern);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt_pdl buf32_xfi Fail qmid:%d\r\n",qmid);
        return ret;

    }    
    pdl_pattern=0xAA; //0xCC;
    ret = qm_build_eth_pkt_pdl((unsigned char *)buf33_xfi[0], ps, pdl_pattern);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt_pdl buf33_xfi Fail qmid:%d\r\n",qmid);
        return ret;

    }    
    pdl_pattern=0x55; //0xDD;
    ret = qm_build_eth_pkt_pdl((unsigned char *)buf34_xfi[0], ps, pdl_pattern);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt_pdl buf34_xfi Fail qmid:%d\r\n",qmid);
        return ret;

    }

    per = sys_enet_enq_cfg_xfi(buf_xfi[0], ps);
    extern enq_req_t er_xfi;
    per = &er_xfi;
    if (!per) {
        printf("QM sys_enet_enq_cfg_xfi failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }
    per32 = sys_enet_enq_cfg32_xfi(buf32_xfi[0], ps);
    extern enq_req_t er32_xfi;
    per32 = &er32_xfi;
    if (!per32) {
        printf("QM sys_enet_enq_cfg32_xfi failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }
    per33 = sys_enet_enq_cfg33_xfi(buf33_xfi[0], ps);
    extern enq_req_t er33_xfi;
    per33 = &er33_xfi;
    if (!per33) {
        printf("QM sys_enet_enq_cfg33_xfi failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }
    per34 = sys_enet_enq_cfg34_xfi(buf34_xfi[0], ps);
    extern enq_req_t er34_xfi;
    per34 = &er34_xfi;
    if (!per34) {
        printf("QM sys_enet_enq_cfg34_xfi failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }

    for(i=0; i<pn; i++) {
        if((i%4) == 0) {
            dcache_flush_all();
            tx_port=0;  rx_port=1;	
            tx_enq_qid = QID32; rx_deq_qid = QID65;
            per->qid =  tx_enq_qid;     // port-0
            ret = qm_proc_enq_dir(0,per);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count_xfi[0] = 0x30;
                return ret;
            }
            retval = pkt_compare_xfi(tx_port, rx_port, ps);
            if(retval)
                return 1;              
            mn=SLT_MSG_NUM;
            while(mn) {
                mn = SLT_MSG_NUM;
                ret = qm_proc_deq_dir(0, rx_deq_qid, QM_MSG_SZ_32B, &mn, msgbuf_xfi); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    total_err_count_xfi[0] = 0x31;
                    return ret;
                }
                mn=0; 
            }
        }
        else if((i%4) == 1)  {
            dcache_flush_all();
            tx_port=1; rx_port=0;
            tx_enq_qid = QID33; rx_deq_qid = QID64;	
            per32->qid = tx_enq_qid;     // port-1
            ret = qm_proc_enq_dir(0,per32);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count_xfi[1] = 0x30;
                return ret;
            }            
            retval = pkt_compare_xfi(tx_port, rx_port, ps);
            if(retval)
                return 1;              
            mn=SLT_MSG_NUM;
            while(mn) {
                mn = SLT_MSG_NUM;
                ret = qm_proc_deq_dir(0, rx_deq_qid, QM_MSG_SZ_32B, &mn, msgbuf32_xfi); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    total_err_count_xfi[1] = 0x31;
                    return ret;
                }
                mn=0; 
            }
        } 
        else if((i%4) == 2)  {
            dcache_flush_all();
            tx_port=2; rx_port=3;	
            tx_enq_qid = QID32; rx_deq_qid = QID65;
            per33->qid = tx_enq_qid;    // port-1
            ret = qm_proc_enq_dir(2,per33);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count_xfi[2] = 0x30;
                return ret;
            }             
            retval = pkt_compare_xfi(tx_port, rx_port ,ps);
            if(retval)
                return 1;              
            mn=SLT_MSG_NUM;
            while(mn) {
                mn = SLT_MSG_NUM;
                ret = qm_proc_deq_dir(2, rx_deq_qid, QM_MSG_SZ_32B, &mn, msgbuf33_xfi); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    total_err_count_xfi[2] = 0x31;
                    return ret;
                }
                mn=0; 
            }
        }
        else if((i%4) == 3)  {
            dcache_flush_all();
            tx_port=3; rx_port=2;
            tx_enq_qid = QID33;	 rx_deq_qid = QID64;    
            per34->qid = tx_enq_qid;     // port-1
            ret = qm_proc_enq_dir(2,per34);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count_xfi[3] = 0x30;
                return ret;
            }             
            retval = pkt_compare_xfi(tx_port, rx_port, ps);
            if(retval)
                return 1;              
            mn=SLT_MSG_NUM;
            while(mn) {
                mn = SLT_MSG_NUM;
                ret = qm_proc_deq_dir(2, rx_deq_qid, QM_MSG_SZ_32B, &mn, msgbuf34_xfi); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    total_err_count_xfi[3] = 0x31;
                    return ret;
                }
                mn=0; 
            }
        }

        lprintf(8, "\n<----------------- PortNo:%d PacketNo:%d ------------------->\n",(i%4),(i/4));
        if ((i%dots==0)) printf(".");
    }
    printf("]\n");
    return 0;
}

int eth_tx2rx_lpbk_test_xfi_1g_int_lpbk() {

    total_err_count_xfi[0]=0;
    total_err_count_xfi[1]=0;
    total_err_count_xfi[2]=0;
    total_err_count_xfi[3]=0;
    unsigned int ps,pn,temp;
    u64 *guess;
    qm_ret_t ret;
    enq_req_t *per;
    enq_req_t *per32;
    enq_req_t *per33;
    enq_req_t *per34;    
    qm_buf_t qm_buf_xfi;
    qm_buf_t qm_buf32_xfi;
    qm_buf_t qm_buf33_xfi;
    qm_buf_t qm_buf34_xfi;    
    enq_cfg_t enq_cfg;
    q_state_t cfg;
    int tx_port,rx_port, mn, retval; 
    int port,i;
    u32 fpqid, dots;
    u8 pdl_pattern,qmid;
    u16 tx_enq_qid, rx_deq_qid;

    qm_buf_xfi.bp = buf_xfi;
    qm_buf32_xfi.bp = buf32_xfi;
    qm_buf33_xfi.bp = buf33_xfi;
    qm_buf34_xfi.bp = buf34_xfi; 

    memset ((u8 *)msgbuf_xfi, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    memset ((u8 *)msgbuf32_xfi, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    memset ((u8 *)msgbuf33_xfi, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);
    memset ((u8 *)msgbuf34_xfi, 0, QM_MAX_MBOX_SLOT*QM_MBOX_SLOT_SIZE);

#ifdef RANDOMIZE_SLT    
    ps=(rand()%1454)+64; 
#else    
    ps=512; //256; 
#endif    
    pn=0x40000; //0x140000; //0x40000; //0x280000; //0x100000; //10; //10000; //100;
    //printf("\n\nEnter No of packets in hex : 0x");pn = get_val(); //pn = get_val(); 
    lprintf(3,"\nSERDES Tx-2-Rx Internal loopback mode test XFI-SGMII\n"); 

    for(port=0; port<4; port++) {
        if(!(sgmii_core_link_check(port,XGENET))) {
            printf("\nPort-%d SGMII Core Link is DOWN!!!!\n",port);
            total_err_count_xfi[port] = 0x10;
        }
    }
    
    if(total_err_count_xfi[0] || total_err_count_xfi[1] || total_err_count_xfi[2] || total_err_count_xfi[3]) return 1;

    printf("\nTotal no. of packets =%d Enqueued at a time with no of pkts :%d with pkt size: %d... \n",pn,SLT_MSG_NUM, ps);
    printf("Number of Packets Expected to Transmit and Receive:%d\n",(pn*SLT_MSG_NUM));
    printf("\nRunning Ethernet Traffic [");

    pn = pn*4;
    dots = pn/20;
    mn = QM_TEST_MSG_NUM; 

    qmid = 0;
    fpqid=0;
    ret = sys_alloc_enet_buf(qmid, fpqid, mn, &qm_buf_xfi); 
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf Fail qmid:%d\r\n",qmid);
        return ret;
    }
    fpqid=1;
    ret = sys_alloc_enet_buf(qmid, fpqid, mn, &qm_buf32_xfi); 
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf qm_buf32_xfi Fail qmid:%d\r\n",qmid);
        return ret;
    }
    qmid = 2;
    fpqid=0;
    ret = sys_alloc_enet_buf(qmid, fpqid, mn, &qm_buf33_xfi); 
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf qm_buf33_xfi Fail qmid:%d\r\n",qmid);
        return ret;
    }
    fpqid=1;
    ret = sys_alloc_enet_buf(qmid, fpqid, mn, &qm_buf34_xfi); 
    if (ret != QM_OK) {
        printf("\nQM sys_alloc_enet_buf qm_buf34_xfi Fail qmid:%d\r\n",qmid);
        return ret;
    }

    pdl_pattern=0xAA;
    ret = qm_build_eth_pkt_pdl((unsigned char *)buf_xfi[0], ps, pdl_pattern);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt_pdl Fail qmid:%d\r\n",qmid);
        return ret;

    }    
    pdl_pattern=0x55; //0xBB;
    ret = qm_build_eth_pkt_pdl((unsigned char *)buf32_xfi[0], ps, pdl_pattern);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt_pdl buf32_xfi Fail qmid:%d\r\n",qmid);
        return ret;

    }    
    pdl_pattern=0xAA; //0xCC;
    ret = qm_build_eth_pkt_pdl((unsigned char *)buf33_xfi[0], ps, pdl_pattern);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt_pdl buf33_xfi Fail qmid:%d\r\n",qmid);
        return ret;

    }    
    pdl_pattern=0x55; //0xDD;
    ret = qm_build_eth_pkt_pdl((unsigned char *)buf34_xfi[0], ps, pdl_pattern);
    if (ret != QM_OK) {
        printf("QM qm_build_eth_pkt_pdl buf34_xfi Fail qmid:%d\r\n",qmid);
        return ret;

    }

    per = sys_enet_enq_cfg_xfi(buf_xfi[0], ps);
    extern enq_req_t er_xfi;
    per = &er_xfi;
    if (!per) {
        printf("QM sys_enet_enq_cfg_xfi failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }
    per32 = sys_enet_enq_cfg32_xfi(buf32_xfi[0], ps);
    extern enq_req_t er32_xfi;
    per32 = &er32_xfi;
    if (!per32) {
        printf("QM sys_enet_enq_cfg32_xfi failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }
    per33 = sys_enet_enq_cfg33_xfi(buf33_xfi[0], ps);
    extern enq_req_t er33_xfi;
    per33 = &er33_xfi;
    if (!per33) {
        printf("QM sys_enet_enq_cfg33_xfi failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }
    per34 = sys_enet_enq_cfg34_xfi(buf34_xfi[0], ps);
    extern enq_req_t er34_xfi;
    per34 = &er34_xfi;
    if (!per34) {
        printf("QM sys_enet_enq_cfg34_xfi failed.... qmid:%d\r\n",qmid);
        return QM_FAIL;
    }

    for(i=0; i<pn; i++) {
        if((i%4) == 0) {
            tx_port=0;  rx_port=0;	
            tx_enq_qid = QID32; rx_deq_qid = QID64;
            per->qid =  tx_enq_qid;     // port-0
            ret = qm_proc_enq_dir(0,per);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count_xfi[0] = 0x30;
                return ret;
            }
            retval = pkt_compare_xfi(tx_port, rx_port, ps);
            if(retval)
                return 1;            
            mn=SLT_MSG_NUM;
            while(mn) {
                mn = SLT_MSG_NUM;
                ret = qm_proc_deq_dir(0, rx_deq_qid, QM_MSG_SZ_32B, &mn, msgbuf_xfi); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    total_err_count_xfi[0] = 0x31;
                    return ret;
                }
                mn=0; 
            }
        }
        else if((i%4) == 1)  {
            tx_port=1; rx_port=1;
            tx_enq_qid = QID33; rx_deq_qid = QID65;	
            per32->qid = tx_enq_qid;     // port-1
            ret = qm_proc_enq_dir(0,per32);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count_xfi[1] = 0x30;
                return ret;
            }            
            retval = pkt_compare_xfi(tx_port, rx_port, ps);
            if(retval)
                return 1;
            mn=SLT_MSG_NUM;
            while(mn) {
                mn = SLT_MSG_NUM;
                ret = qm_proc_deq_dir(0, rx_deq_qid, QM_MSG_SZ_32B, &mn, msgbuf32_xfi); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    total_err_count_xfi[1] = 0x31;
                    return ret;
                }
                mn=0; 
            }
        } 
        else if((i%4) == 2)  {
            tx_port=2; rx_port=2;	
            tx_enq_qid = QID32; rx_deq_qid = QID64;
            per33->qid = tx_enq_qid;    // port-1
            ret = qm_proc_enq_dir(2,per33);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count_xfi[2] = 0x30;
                return ret;
            }             
            retval = pkt_compare_xfi(tx_port, rx_port ,ps);
            if(retval)
                return 1;            
            mn=SLT_MSG_NUM;
            while(mn) {
                mn = SLT_MSG_NUM;
                ret = qm_proc_deq_dir(2, rx_deq_qid, QM_MSG_SZ_32B, &mn, msgbuf33_xfi); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    total_err_count_xfi[2] = 0x31;
                    return ret;
                }
                mn=0; 
            }
        }
        else if((i%4) == 3)  {
            tx_port=3; rx_port=3;
            tx_enq_qid = QID33;	 rx_deq_qid = QID65;    
            per34->qid = tx_enq_qid;     // port-1
            ret = qm_proc_enq_dir(2,per34);
            if (ret != QM_OK) {
                printf("QM mb_proc_enq_dir qmid:%d failed ret:%d\r\n",qmid,ret);
                total_err_count_xfi[3] = 0x30;
                return ret;
            }             
            retval = pkt_compare_xfi(tx_port, rx_port, ps);
            if(retval)
                return 1;            
            mn=SLT_MSG_NUM;
            while(mn) {
                mn = SLT_MSG_NUM;
                ret = qm_proc_deq_dir(2, rx_deq_qid, QM_MSG_SZ_32B, &mn, msgbuf34_xfi); //deqid
                if (ret != QM_OK) {
                    printf("\nQM qm_proc_deq_dir to qmid=%d port:%d mn:%d failed: ret = %d....\n", qmid,i,mn,ret);
                    total_err_count_xfi[3] = 0x31;
                    return ret;
                }
                mn=0; 
            }
        }

        lprintf(8, "\n<----------------- PortNo:%d PacketNo:%d ------------------->\n",(i%4),(i/4));
        if ((i%dots==0)) printf(".");
    }
    printf("]\n");
    return 0;
}

void eth_reg_wr_mode (int addr, int data2, int data1, int data0, int eth_type, int port, int display ) {
    if (mac_mode==2)     eth_wr(addr, data2,eth_type,port,display);
    else if(mac_mode==1) eth_wr(addr, data1,eth_type,port,display);
    else                 eth_wr(addr, data0,eth_type,port,display);
}

void mcxmac_ind_wr_mode(int offset, int wr_data2, int wr_data1, int wr_data0, int eth_type, int port, int display){
    if (mac_mode==2)      mcxmac_ind_wr(offset,wr_data2,eth_type, port, display);
    else if(mac_mode==1)  mcxmac_ind_wr(offset,wr_data1,eth_type, port, display);
    else                  mcxmac_ind_wr(offset,wr_data0,eth_type, port, display);
}

int init_xgenet_serdes(int port, int display) {
    uint32_t rd_data;
    uint32_t infmode;

    int pll_ready;
    int vco_fail;
    u32 timeout=100000;

    infmode = 0; //SGMII
    do {
        USDELAY(100);

        if(clk_mode_xg == 0) {
            lprintf(4,"\nXFI-SGMII Port-%d is Configured in External Clock Mode\n",port);  
            pll_ready = sm_xgenet_module_init_enet_serdes(infmode, 0, tx2rx_serdes_lb,XGENET,port,display);
        }
        else if(clk_mode_xg == 1) { 
            lprintf(4,"\nXFI-SGMII Port-%d is Configured in Internal Clock Mode\n",port);  
            pll_ready = sm_xgenet_module_init_enet_serdes(infmode, 1, tx2rx_serdes_lb,XGENET,port,display); // Internal clock mode
        }
        USDELAY(10);
        if(pll_manualcal == 0) {
            vco_fail = vco_status_xg(port,0x0) >> 3 ;
            timeout-- ;
            if(timeout==0) {
                printf("\nPort:%d VCO Callibration Fail!!!\n",port);
                return -1;
            }
        }
        else  
            vco_fail = 0;

    } while(vco_fail);

    //force_lat_summer_cal_xg(XGENET,port,0); // 04/08/2014 this is covered in the xgene_phy_gen_avg_val()
 

    return 0;
}

void loopback_cfg(int port, int display) {
    int read_data;

    if (loopback_xg == 0) { 
        eth_wr(SM_XGENET_CSR_DEBUG_REG__ADDR, 0x003e03fe,XGENET,port,display);
        lprintf(5,"\n====== CONFIG_XGENET_RX2TSO_LPBK ========\n");
    } 
    else {
        eth_wr(SM_XGENET_CSR_DEBUG_REG__ADDR, 0x003e03ee,XGENET,port,display);//QM Loopback
        lprintf(8, "\n====== CONFIG_XGENET_QN_RX2TX_LPBK ======\n");
    }
    read_data = eth_rd(SM_XGENET_CSR_DEBUG_REG__ADDR,XGENET,port,display);
}

void cle_bypass_mode_cfg (int port, int display) {

    u32 read_data; 

    lprintf(8, "\r\n++++++++++++ CPU Level Loopback Test +++++++++++++\r\n");
    if(port == 0) {    
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
        lprintf(8, "\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00000040,XGENET,port,display);
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00000040,XGENET,port,display);

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
        lprintf(8, "port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data);
        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
        lprintf(8, "port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data);

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
        eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
        // cfg to enable capture of Rx cntrl wd's
        eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
    }
    else if(port == 1) {    
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
        lprintf(8, "\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110041,XGENET,port,display);
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110041,XGENET,port,display);

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
        lprintf(8, "port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data);
        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
        lprintf(8, "port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data);

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
        eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
        // cfg to enable capture of Rx cntrl wd's
        eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
    }
    else if(port == 2) {    
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
        lprintf(8, "\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00000840,XGENET,port,display);
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00000840,XGENET,port,display);

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
        lprintf(8, "port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data);
        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
        lprintf(8, "port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data);

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
        eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
        // cfg to enable capture of Rx cntrl wd's
        eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
    }
    else if(port == 3) {    
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
        lprintf(8, "\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110841,XGENET,port,display);
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110841,XGENET,port,display);

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
        lprintf(8, "port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data);
        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
        lprintf(8, "port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data);

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
        eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
        // cfg to enable capture of Rx cntrl wd's
        eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
    }

}

int init_xgenet(int port, int display) {
    int retval=0;
    clk_reset_cfg(     port, display);
    USDELAY(10);
    retval = init_xgenet_serdes(port, display);
    if(retval < 0)
        return retval;
    USDELAY(10);
    eth_wr(SM_XGENET_CLKRST_CSR_XGENET_SRST__ADDR, 0x0,XGENET,port,display);
    USDELAY(10);
    xgenet_init_ecc(   port, display);

    init_mcxmac(     XGENET,port,display);

    mdio_wr(0x1e11,0,XGENET,port,display);
    configure_sgmii_xg(port,0x0, 1);

    bypass_resume_cfg(port,display);
    loopback_cfg(port,display);

    if(cle_enable_xg == 0)  
        cle_bypass_mode_cfg(port,display);

    eth_wr(SM_XGENET_CSR_RSIF_LERR_MASK__ADDR, 0x0,XGENET,port,display);
    eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x21010000,XGENET,port,display);

    return retval;
}

int eth_tx2rx_1g_xfi() {
    int port = 0; 

    read_rpkt_as_xg[0] = 0; 
    read_rpkt_as_xg[1] = 0; 
    read_rpkt_as_xg[2] = 0; 
    read_rpkt_as_xg[3] = 0; 

    read_rpkt_as_bak_xg[0] = 0; 
    read_rpkt_as_bak_xg[1] = 0; 
    read_rpkt_as_bak_xg[2] = 0; 
    read_rpkt_as_bak_xg[3] = 0; 

    read_rfcs_as_bak_xg[0] = 0; 
    read_rfcs_as_bak_xg[1] = 0; 
    read_rfcs_as_bak_xg[2] = 0; 
    read_rfcs_as_bak_xg[3] = 0; 

#if 1 //XFI-SGMII 
    int retval=0; 

    lprintf(5,"\r\n<---------- XFI-SGMII Configure Starts ----------->\n\r");
    sfp_laser_enable_top_level_function();
    for(port=0; port<2; port++) {
        printf("\nConfiguring copper SFP+ port-%d\n\n",port);
        USDELAY(1000000);
        USDELAY(10000);
        cu_sfpp_write(port);
        USDELAY(10000);
    }

    xgenet_base_addr = XGENET_0_BASE_ADDR;
    for (port=FIRST_PORT;port<=LAST_PORT;port++) {
        lprintf(8, "\n\r\n\r======= Configure port %x =============\n\r\n\r",port);
        retval = init_xgenet(port, 0x0); // Port 0 - Display configuration 
        if(retval < 0) {
            total_err_count_xfi[0]++;
            total_err_count_xfi[1]++;
            total_err_count_xfi[2]++;
            total_err_count_xfi[3]++;            
            total_err_count_result_xfi();	
            return retval;
        }
        lprintf(8, "\n\r\n\r======= Configure port %x Done ========\n\r\n\r",port);
    }

    for (port=FIRST_PORT;port<=LAST_PORT;port++)
        vco_status_xg(port,0x1); 

    write((unsigned int *)(0x17001398), 0x001e1e1e); //MDIO enable config
    //gen_avg_val();
    for (port=FIRST_PORT;port<=LAST_PORT;port++) {
        retval = xgene_phy_gen_avg_val(port);
        if(retval < 0) {
            total_err_count_xfi[0]++;
            total_err_count_xfi[1]++;
            total_err_count_xfi[2]++;
            total_err_count_xfi[3]++;            
            total_err_count_result_xfi();	
            return retval;
        }
    }

    link_status_xg(); 

    menet_clkcfg();
    mgmt_mac_config();

    // Disable the Completion Queeue
    lprintf(8, "\nDisable Completion Queue for XFI-SGMII Ports,");
    for(port=0; port<4; port++) {
        eth_rd(SM_XGENET_CSR_TSIF_CONFIG_REG_0__ADDR,XGENET,port,0);
        eth_wr(SM_XGENET_CSR_TSIF_CONFIG_REG_0__ADDR, 0x00704887,XGENET,port,0); // CompletioQueu BitNo21=0 
        eth_rd(SM_XGENET_CSR_TSIF_CONFIG_REG_0__ADDR,XGENET,port,0);
    }
    lprintf(8, "Done\n");

    enable_l3_cache();//Enable L3 cache ...
    enable_64_byte_axi_write_padding_xg();//Enable 64-Byte AXI Write padding

    unsigned int reg,tmp;

    // QMI configuration for Port-2/3
    lprintf(8, "\r\nQMI configuration for Port-2 & Port-3\r\n");
    lprintf(8, "Before write\r\n");
    reg = 0x1f7190dc;       
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7190e0;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7190f0;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7190f4;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);

    reg = 0x1f7290dc;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7290e0;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7290f0;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7290f4;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);

    // Port-2
    //write((unsigned int *)(0x1f7190dc), 0xffffffff); // CfgSsQmiFPQAssoc 
    //write((unsigned int *)(0x1f7190e0), 0xffffffff); // CfgSsQmiWQQAssoc 
    write((unsigned int *)(0x1f7190f0), 0xffffffff); // CfgSsQmiQMLiteFPQAssoc 
    write((unsigned int *)(0x1f7190f4), 0xffffffff); // CfgSsQmiQMLiteWQAssoc 

    // Port-3
    //write((unsigned int *)(0x1f7290dc), 0xffffffff); // CfgSsQmiFPQAssoc 
    //write((unsigned int *)(0x1f7290e0), 0xffffffff); // CfgSsQmiWQAssoc 
    write((unsigned int *)(0x1f7290f0), 0xffffffff); // CfgSsQmiQMLitePFQAssoc
    write((unsigned int *)(0x1f7290f4), 0xffffffff); // CfgSsQmiQMLiteWQAssoc

    lprintf(8, "\r\nAftre write\r\n");
    reg = 0x1f7190dc;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7190e0;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7190f0;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7190f4;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);

    reg = 0x1f7290dc;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7290e0;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7290f0;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7290f4;
    tmp = read32(reg);
    lprintf(8, "reg:0x%x tmp:0x%x\r\n",reg,tmp);

    USDELAY(1000);

    lprintf(5,"\nQM-0/2 Init\r\n");
    qm_n_xfi((QM_QM0 | QM_QM2), QM_ETH);
    USDELAY(4000);

    USDELAY(10000);

    sw_workaround_xg();//Sw workaround as given in XGENET EAS
    config_rsif_vc2_xg();//Set VC2 for Eth RSIF

#if 0
    set_mcu_ref_burst_cnt(0x1);//Set DDR Refresh Burst count = 1
    set_mcu_hpweight(0x300);//Set MCU_HPWEIGHT to highest priority
    set_mcu_lpweight(0x200);//Set MCU_LPWEIGHT to 2nd highest priority
    set_mcu_wpweight(0x100);//Set MCU_WPWEIGHT to lowest priority
#endif
    xfi_sgmii_init_done=1;
   
    if(xfi_sgmii_margin_tool == 1) {
        margin_util_sgmii_xfi();
        return 0;
    }
    
    if(tx2rx_phy_lp_xg == 1) {
        set_phy_level_lpbk_sgmii(XGENET);
        eth_tx2rx_lpbk_test_xfi_1g_int_lpbk();  // Internal Self Single Port lpbk mode
        mac_stat_1g_xfi();
        return 0;
    }

    dual_sgmii_rtl_phy_disable_eee_mode();

    if(tx2rx_serdes_lb == 1) {
        if(prbs_test_mode_xg == 1) {
            xfi_sgmii_serdes_prbs_test();       // PRBS Self Single Port lpbk mode
            return 0;
        }
        eth_tx2rx_lpbk_test_xfi_1g_int_lpbk();  // Internal Self Single Port lpbk mode
    }
    else if(tx2rx_serdes_lb == 0) {
        eth_tx2rx_lpbk_test_xfi_1g_ext_lpbk();  // External Port to Port lpbk mode
    }
    
    total_err_count_result_xfi();	

    if(advanced_debug_xg) {
        debug_xg();
    }
    lprintf(8,"\r\n<---------- XFI-SGMII Configure Completes --------->\n\r");
#endif //XFI-SGMII 

#if 0 // md: SATA-SGMII
    printf("\r\n<---------- SATA-SGMII Configure Starts --------->\n\r");
    eth_tx2rx_1g_sata();
    printf("\r\n<---------- SATA-SGMII Configure Completes --------->\n\r");
#endif 

    return 0;
}


int link_status_xg(){
    int an_sts;
    an_sts = lnk_sts_xg(FIRST_PORT,LAST_PORT,1);
    return an_sts;
}

int lnk_sts_xg(int srt_port, int end_port, int display){
    int tmp;
    int link = 0;
    int an_done = 0;
    int an_comp = 0;
    int port;
    int intf;
    int an_sts = 0;
    int  read_data;
    //-----------------------------------
    // Print Final Link Status
    //-----------------------------------
    for (port=srt_port;port<=end_port;port++) {
        if(display)lprintf(5,"\n======== Link Status : Port%d ==========\n", port);
        link, an_done = 0;
        read_data = mdio_rd(0x1e01,XGENET,port,0);
        link    = (read_data >> 2) & 0x1;
        an_comp = (read_data >> 5) & 0x1;
        an_done = an_en_xg ? an_comp : link;
        int my_loop = 1000;
        while((my_loop > 0) && an_done) {
            read_data = mdio_rd(0x1e01,XGENET,port,0);
            link    = ((read_data >> 2) & 0x1) && link;
            an_comp = ((read_data >> 5) & 0x1) && an_comp;
            an_done = an_en_xg ? an_comp : link;
            my_loop--;
        }
        if(display)lprintf(5,"Autonegotiation %s complete %s\n", an_comp ? "" : "NOT",an_en_xg ? "" : " : NON-AUTONEG MODE");
        if(display)lprintf(5,"Link Status : %s \n", link == 1 ? "UP" : "DOWN");
        if(an_en_xg)
            if(display) lprintf(5,"Link Parameters : 0x%x \n", mdio_rd(0x1e05,XGENET,port,0));

        //printf("Link Status after %d iterations \n\r", itr_count[port]);
        lprintf(5,"addr:0x1e01 read_data:0x%x \n", mdio_rd(0x1e01,XGENET,port,0));
        lprintf(5,"addr:0x1e05 read_data:0x%x \n", mdio_rd(0x1e05,XGENET,port,0));

        tmp =   eth_rd(SM_XGENET_CSR_LINK_STATUS__ADDR,XGENET,port,0) & 0x1;
        if(gating_bypass_xg) {
            eth_wr(SM_XGENET_CSR_CFG_LINK_AGGR_RESUME_0__ADDR,0x00000001,XGENET,port,0);
            eth_wr(SM_XGENET_MCXMAC_CSR_RX_DV_GATE_REG_0__ADDR,0x0,XGENET,port,0);
            an_sts = an_sts | (an_done << port);
        } else if(tmp != 0) {
            eth_wr(SM_XGENET_CSR_CFG_LINK_AGGR_RESUME_0__ADDR,0x00000001,XGENET,port,0);
            eth_wr(SM_XGENET_MCXMAC_CSR_RX_DV_GATE_REG_0__ADDR,0x7,XGENET,port,0);
            an_sts = an_sts | (an_done << port);
        } else {
            printf("Port%d : Traffic GATED\n",port);
        }
        eth_rd(SM_XGENET_CSR_LINK_STATUS__ADDR,XGENET,port,0);
        eth_rd(SM_XGENET_CSR_LINK_STS_INTR__ADDR,XGENET,port,0);
        eth_wr(SM_XGENET_CSR_LINK_STS_INTR__ADDR,0x1,XGENET,port,0);
    }

    return an_sts;
}


int vco_status_xg(int inst, int display) {
    int rd_val,pll_ready,pll_lock,vco_calibration,tx_ready,rx_ready;
    int pll_det;
    int vco_cal_fail;

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg7", CMU + 2*7,XGENET,inst,1);

    //pll_ready = FIELD_SATA_ENET_SDS_CMU_STATUS0_CFG_CMU_O_PLL_READY_RD(rd_val);
    pll_lock        = (rd_val >> 15) & 0x1;
    vco_calibration = (rd_val >> 14) & 0x1;
    pll_det         = (rd_val >> 12) & 0x3;
    vco_cal_fail    = (rd_val >> 10) & 0x3;
    if(display){
        //printf("XGENET%d  VCO_CALIB: PLL is %sREADY\n", inst, pll_ready ? "" : "not ");
        lprintf(8, "XGENET%d  VCO_CALIB: PLL %sLOCKed\n", inst, pll_lock ? "" : "not ");
        lprintf(8, "XGENET%d  VCO_CALIB: PLL VCO Calibration %s\n", inst,  vco_calibration ? "DONE" : "not done");
        lprintf(8, "XGENET%d  VCO_CALIB: PLL VCO Calibration %s : 0x%x\n", inst,  vco_cal_fail == 0 ? "NO FAILURE" : "FAILED",vco_cal_fail);
        lprintf(8, "XGENET%d  VCO_CALIB: PLL DET : %d\n", inst, pll_det);
    }

    int vco_cal_done_n = 0;
    if (vco_calibration == 0) vco_cal_done_n = 1;
    return (((vco_cal_done_n << 5 )|(vco_cal_fail<<3) | (pll_det<<1) | (pll_lock == 0))); 
}

int configure_sgmii_xg(int port, int display, unsigned int reconfig_count) {
    int link,link_up, an_comp;
    int  read_data,read_data1;
    int times = 0;

reset_phy:
    mdio_wr(0x1e11,0x0000,XGENET,port,display); //chandra
    USDELAY(20);

    if(an_en_xg) 
        mdio_wr(0x1e00,0x9140,XGENET,port,display); // Enable Auto Neg
    else
        mdio_wr(0x1e00,0x8140,XGENET,port,display); // Non Auto Neg

    int loop = 50000; //totake care copper SFP as well
    int ext_link;
    link =0;
    do {
        read_data = mdio_rd(0x1e01,XGENET,port,display);
        USDELAY(100);
        loop--;
        if(loop == 0) break;
    }while((read_data != 0x17d)); 

    read_data = mdio_rd(0x1e01,XGENET,port,display);
    lprintf(4,"\nlink(0x1e01) = 0x%x\n", read_data);
    link    = FIELD_SGMII_STATUS_LINK_STATUS_RD(read_data);//(read_data >> 2) & 0x1;
    an_comp = FIELD_SGMII_STATUS_AUTO_NEGOTIATION_COMPLETE_RD(read_data);//(read_data >> 5) & 0x1;

    read_data1 = mdio_rd(0x1e05,XGENET,port,display);
    lprintf(4,"\nlink(0x1e05) = 0x%x\n", read_data1);
    link_up  = FIELD_SGMII_AN_SGMII_PARTNER_BASE_PAGE_ABILITY_LINK_UP_RD(read_data1);

    if(!(link && an_comp && link_up)) {
        if (times ++ < 15) {
            lprintf(3,"\ntimes = %d ---->\n", times);
            mdio_wr(0x1e11,0x8000,XGENET,port,display); //chandra
            goto reset_phy;
        }
    }

    read_data = mdio_rd(0x1e05,XGENET,port,display);
    ext_link = (read_data >> 15) & 0x1;
    if(tx2rx_serdes_lb == 0 && an_en_xg == 1)
        mac_mode = (read_data >> 10) & 0x3;

    lprintf(8, "\n\r---------------------------------------- \n\r");
    lprintf(8, "\t Link Status Port%x: %s \n\r", port, link == 1 ? "UP" : "DOWN");
    if(an_en_xg)   lprintf(8, "\t Link Parameters : 0x%x \n\r", read_data);
    lprintf(8, "\t Speed = %s mbps\n\r", (mac_mode == 2) ? "1000" : ((mac_mode == 1) ? "100" : "10"));
    lprintf(8, "---------------------------------------- \n\r");
    if((an_en_xg == 1 && ext_link == 1) || // Auto neg - External link up
            (an_en_xg == 0 && link == 1) ||     // Non Auto - Internal link up , Poll for external link(by software not done here)
            (tx2rx_serdes_lb == 1 && link == 1))  //serdes level Tx2Rx loopback - Internal link up
    { //phy level Tx2Rx loopback - Internal link up
        lprintf(8,"Configure MAC/SGMII as per new speed : %s mbps\n\r", (mac_mode == 2) ? "1000" : ((mac_mode == 1) ? "100" : "10"));
        eth_reg_wr_mode(SM_XGENET_MCXMAC_CSR_ICM_CONFIG0_REG_0__ADDR,0x0008503f,0x0004503f,0x0000503f,XGENET,port,display);  //ICM_CONFIG0_REG_0 -- MacMode[12:13]:0=10M,1=100M,2=1G
        eth_reg_wr_mode(SM_XGENET_MCXMAC_CSR_ICM_CONFIG2_REG_0__ADDR,0x0001000f,0x00010050,0x000101f4,XGENET,port,display);  // ICM_Config2_reg_0 -Async read  //AXI freq  => 100MHz
        mcxmac_ind_wr_mode(PE_MCXMAC_MAC_CONFIG_2__ADDR,     0x00005211,0x00006111,0x00007111,XGENET,port,display);//FD,frm_len,mac)inf:nible vs byte
        mcxmac_ind_wr_mode(PE_MCXMAC_INTERFACE_CONTROL__ADDR,0x04000000,0x02000000,0x00000000,XGENET,port,display); // MAC mode - 1g,100m,10m

        eth_wr(SM_XGENET_CSR_CFG_LINK_AGGR_RESUME_0__ADDR,0x00000001,XGENET,port,display);
        if(gating_bypass_xg)
            eth_wr(SM_XGENET_MCXMAC_CSR_RX_DV_GATE_REG_0__ADDR,0x0,XGENET,port,display);
        else
            eth_wr(SM_XGENET_MCXMAC_CSR_RX_DV_GATE_REG_0__ADDR,0x7,XGENET,port,display);            

    }
    return 0;// an_done;
}

void mac_stat_1g_xfi(){
    int port = 0;
    if(xfi_sgmii_init_done == 1) {
        for(port=FIRST_PORT; port <= LAST_PORT; port++){
            printf("-------Port%d----------\n",port);
            printf("Tx-Pkt = %d :: ",mcxmac_stat_rd(PEMSTAT_TPKT__ADDR,port));
            //printf("Rx-Pkt = %d\n",mcxmac_stat_rd(PEMSTAT_RPKT__ADDR,port));
            printf("Rx-Pkt = %d \n",read_rpkt_as_bak_xg[port]);
            printf("Tx-Byt = %d :: ",mcxmac_stat_rd(PEMSTAT_TBYT__ADDR,port));
            printf("Rx-Byt = %d\n",mcxmac_stat_rd(PEMSTAT_RBYT__ADDR,port));
            printf("Tx-FCS = %d :: ",mcxmac_stat_rd(PEMSTAT_TFCS__ADDR,port));
            //printf("Rx-FCS = %d \n",mcxmac_stat_rd(PEMSTAT_RFCS__ADDR,port));
            printf("Rx-FCS = %d \n",read_rfcs_as_bak_xg[port]);
            printf("Tx-UND = %d :: ",mcxmac_stat_rd(PEMSTAT_TUND__ADDR,port));
            printf("Rx-UND = %d \n",mcxmac_stat_rd(PEMSTAT_RUND__ADDR,port));
            printf("Tx-OVR = %d :: ",mcxmac_stat_rd(PEMSTAT_TOVR__ADDR,port));
            printf("Rx-OVR = %d \n",mcxmac_stat_rd(PEMSTAT_ROVR__ADDR,port));
            printf("Tx-FRG = %d :: ",mcxmac_stat_rd(PEMSTAT_TFRG__ADDR,port));
            printf("Rx-FRG = %d \n",mcxmac_stat_rd(PEMSTAT_RFRG__ADDR,port));
            printf("\n");
            read_rpkt_as_bak_xg[port] = 0 ;
            read_rfcs_as_bak_xg[port] = 0 ;
        }
    }
    else if (xfi_sgmii_init_done == 0) {
        printf("\nXFI-SGMII Ports are in initialized\n");
    }
}

void rst_sds_rxa_xg(){
    int port;
    for(port = FIRST_PORT; port <= LAST_PORT ; port++){
        printf(" Port%d Serdes analog Reset ...\n",port);

        mdio_wr(0x00001e11,0x8000,XGENET,port,0);
        serdes_reset_rxa_xg(XGENET,port,0x0);
        mdio_wr(0x00001e11,0,XGENET,port,0);
        configure_sgmii_xg(port,0x0, reconfig_loop);
    }
}

void debug_xg(){
    int val = 0;
    int quit_r;
    int ind_address, ind_data;
    int port = 0, phy_addr=0,phy_reg=0; 
    do
    {
        printf("\n\r99. Configure Port\n\r");
        printf("\n\r1. Read Register\n\r");
        printf("\n\r2. Write Register\n\r");
        printf("\n\r3. Read AXGMAC port stats\n\r");
        printf("\n\r4. AXGMAC Indirect Read  \n\r");
        printf("\n\r5. AXGMAC Indirect Write \n\r");
        printf("\n\r6. 10GBaseR Indirect Read  \n\r");
        printf("\n\r7. 10GBaseR Indirect Write \n\r");
        printf("\n\r8. MDIO Read  \n\r");
        printf("\n\r9. MDIO Write \n\r");
        printf("\n\r10. SerDes Read \n\r");
        printf("\n\r11. SerDes Write \n\r");
        printf("\n\r13. Read MCXMAC port stats\n\r");
        printf("\n\r16. Reautoneg SGMII\n\r");
        printf("\n\r17. SerDes analog reset only\n\r");
        printf("30. TEST Profile  \n\r");
        printf("31. QM Dump PB state\n\r");
        printf("37. Send AXGMAC SW pause frame and force RX OSET to idles  \n\r");
        printf("38. Send AXGMAC SW pause frame  \n\r");
        printf("40. Send MCXMAC SW pause frame  \n\r");
        printf("\n\rq. to quit.. \n\r");

        val = get_val();
        quit_r = val + 0x57;

        if (val == 0x01) // read command 
        {
            printf("\n\rread address (hex)=?\n\r");
            ind_address = get_val();
            printf("\n\rread address entered = 0x%x \n\r", val);
            ind_data = read(ind_address);
            printf("\n\rread data = 0x");putnum(ind_data);printf(" from address = 0x");putnum(ind_address);printf("\n\r");
        } 

        else if (val == 0x02)    // Write command
        {
            printf("\n\rwrite address (hex)=?\n\r");      
            ind_address  = get_val();
            printf("\n\rwrite address entered = 0x%x \n\r", ind_address);
            printf("\n\rwrite data=?\n\r");
            ind_data = get_val();
            printf("\n\rwrite data entered = 0x%x\n\r", ind_data);
            write(ind_address,ind_data);
            printf("\n\rwritten data = 0x");putnum(ind_data);printf(" at address = 0x");putnum(ind_address);printf("\n\r");  
        } 

        else if (val == 0x03)    //Read AXGMAC port stats
        {
            printf("Select port to print Statistics : ");
            read_statistics_mcxmac(get_val());
        } 

        else if (val == 0x04)    //axgmac ind rd command
        { int port =0;

            printf("\n\rRead address (hex)=?\n\r");
            ind_address = get_val();
#ifdef CONFIG_XGENET_IF_XGMII
            ind_data = axgmac_ind_read(ind_address);
#else
            printf("Select port to print Statistics : ");
            ind_data = mcxmac_ind_rd(ind_address, XGENET,get_val(),1);
#endif
            printf("\n\rdata read is = 0x");putnum(ind_data);printf("\n\r");
        } 

        else if (val == 0x05)    //axgmac ind wr command
        {
            printf("\n\renter write address \n\r");
            ind_address = get_val();
            printf("\n\r enter write data=?\n\r");
            ind_data = get_val();
            printf("\n\rwriting....\n\r");
#ifdef CONFIG_XGENET_IF_XGMII
            axgmac_ind_write(ind_address,ind_data);
#else
            printf("Select port to print Statistics : ");
            mcxmac_ind_wr(ind_address,ind_data,XGENET,get_val(),0);
#endif
            printf("\n\rwritten data = 0x");putnum(ind_data);printf(" at address = 0x");putnum(ind_address);printf("\n\r");
        } 
        else if (val == 0x08)    //// MDIO read
        {
            printf("\n\r Phy addr and reg address combined.in [0:31] format,[0:18] = 19'b0, [19:23]= Phyaddress, [24:26] = 3'b0, [27:31] = reg address in (hex)=?\n\r");
            ind_address = get_val();
            printf("Select port to print Statistics : ");
            ind_data = mdio_rd(ind_address,XGENET,get_val(),1);
        } 
        else if (val == 0x09)    //// MDIO write
        {
            printf("\n\r Phy addr and reg address combined in [0:31] format,[0:18] = 19'b0, [19:23]= Phyaddress, [24:26] = 3'b0, [27:31] = reg address in (hex)=?\n\r");
            printf("\n\renter write address \n\r");
            ind_address = get_val();
            printf("\n\r enter write data=?\n\r");
            ind_data = get_val();
            printf("\n\rwriting....\n\r");
            printf("Select port to print Statistics : ");
            mdio_wr(ind_address,ind_data,XGENET,get_val(),1);
            printf("\n\rwritten data = 0x");putnum(ind_data);printf(" at address = 0x");putnum(ind_address);printf("\n\r");
        } 
        else if (val == 0x11)    //// mac ind wr command
        {
            int port;
            printf("\nCalculating gen_avg value for XFI-SGMII\n\r");
            port = my_get_val("select port 0/1/2/3:");
            debug_gen_avg_val_xfi_sgmii(port);

        }
        else if (val == 0x12 )
        {
            int port;
            port = my_get_val("select port 0/1/2/3");
            printf("\nChange Tx-Aplitude Reset Tx-Term, Tx-Analog-Rst, Tx-Digital-Rst (XFI-SGMII),\n");
            enet_sds_rxtx_re_cfg_xfi_sgmii(port,1);
            printf("Done\n");
            printf("Reconfigure XFI-SGMII core,");
            configure_sgmii_xg(port, 0x0, 20);
            printf("Done\n");
        } 

        else if (val == 0x20)    //// SerDes read
        {
            printf("\n\rNote: PHY SerDes has two base addres for rxtx_reg (0x400 and 0x600), one base address for CMU (0x0)\n\r");
            printf("\n\rFor each configuration, you must write one for 0x400 and one for 0x600\n\r");
            printf("\n\rPHY SerDes read address in (hex)=?\n\r");
            ind_address = get_val();
            printf("Select port to print Statistics : ");
            ind_data = enet_sds_ind_csr_reg_rd("SerDes_reg", ind_address,XGENET,get_val(),1);
            printf("\n\rdata read is = 0x");putnum(ind_data);printf("\n\r");
        } 
        else if (val == 0x21)    //// SerDes write
        {
            printf("\n\rNote: PHY SerDes has two base addres for rxtx_reg (0x400 and 0x600), one base address for CMU (0x0)\n\r");
            printf("\n\rFor each configuration, you must write one for 0x400 and one for 0x600\n\r");
            printf("\n\r Phy Write address in (hex)=?\n\r");
            ind_address = get_val();
            printf("\n\r enter write data=?\n\r");
            ind_data = get_val();
            printf("\n\rwriting....\n\r");
            printf("Select port to print Statistics : ");
            enet_sds_ind_csr_reg_wr("sedes_reg",ind_address,ind_data,XGENET,get_val(),1);
            printf("\n\rwritten data = 0x");putnum(ind_data);printf(" at address = 0x");putnum(ind_address);printf("\n\r");
        } 
        else if (val == 0x15) {

            int rd_data;
            int counter = 10;
            int eth_type = XGENET;
            int port=  0;

            mcxmac_ind_wr(PE_MCXMAC_MII_MGMT_ADDRESS__ADDR,0x1e11   , eth_type, port, 0);
            mcxmac_ind_wr(PE_MCXMAC_MII_MGMT_CONTROL__ADDR,0x0   , eth_type, port, 0);
            do {
                rd_data = mcxmac_ind_rd(PE_MCXMAC_MII_MGMT_INDICATORS__ADDR, eth_type, port, 0);
            }while(rd_data != 0x0);

            printf("MDIO WR P%x : [0x%x] <- 0x%x \n\r",port,0x1e11,0x0);

            mcxmac_ind_wr(PE_MCXMAC_MII_MGMT_ADDRESS__ADDR,0x1e00   , eth_type, port, 0);
            mcxmac_ind_wr(PE_MCXMAC_MII_MGMT_CONTROL__ADDR,0x9140   , eth_type, port, 0);
            do {
                rd_data = mcxmac_ind_rd(PE_MCXMAC_MII_MGMT_INDICATORS__ADDR, eth_type, port, 0);
            }while(rd_data != 0x0);

            printf("MDIO WR P%x : [0x%x] <- 0x%x \n\r",port,0x1e00,0x9140);
            mcxmac_ind_wr(PE_MCXMAC_MII_MGMT_ADDRESS__ADDR,0x1e00   , eth_type, port, 0);
            mcxmac_ind_wr(PE_MCXMAC_MII_MGMT_COMMAND__ADDR,0x00000001, eth_type, port, 0);
            do {
                rd_data = mcxmac_ind_rd(PE_MCXMAC_MII_MGMT_INDICATORS__ADDR, eth_type, port, 0);
                counter--;
            }while(rd_data != 0x0);

            printf("MDIO RD P%x : [0x%x] -> 0x%x \n\r",port,0x1e00,mcxmac_ind_rd(PE_MCXMAC_MII_MGMT_STATUS__ADDR, eth_type, port, 0));

        }
        else if (val == 0x16)
        {
            int port =0;
            int display = 1;
            int read_data =0;
            printf("Enter XGENET Port serdes to be reset (0/1/2/3) : ");
            port = get_val();
            mdio_wr(0x1e11,0     ,XGENET,port,display); // Deassert Reset
            mdio_wr(0x1e00,0x9140,XGENET,port,display); // Enable Auto Neg
            int loop = 50;
            int link, an_done = 0;
            while((loop != 0) && (an_done == 0)){
                link, an_done = 0;
                read_data = mdio_rd(0x1e01,XGENET,port,display);
                link    = (read_data >> 2) & 0x1;
                an_done = (read_data >> 5) & 0x1;
                loop--;
            }
            printf("Autonegotiation %s complete \n\r", an_done ? "" : "NOT");
            printf("Link Status : %s \n\r", link == 1 ? "UP" : "DOWN");
            printf("Link Parameters : 0x%x \n\r", mdio_rd(0x1e05,XGENET,port,display));
        }
        else if (val == 0x17) //Serdes analog reset only
        {
            printf("Enter XGENET Port serdes to be reset (0/1/2/3) : ");
            serdes_reset_rxa_xg(XGENET,get_val(),0x1);
        }
        else if (val == 0x38) //Send AXGMAC SW pause frame
        {
            eth_wr(SM_XGENET_AXGMAC_CSR_XGENET_CSR_ECM_CFG_0__ADDR, 0x08000000,XGENET,port,1);
            while(eth_rd(SM_XGENET_AXGMAC_CSR_XGENET_CSR_ECM_CFG_0__ADDR,XGENET,port,1) != 0){
                printf("\n\rWaiting for AXGMAC SW pause_req bit to get cleared\n\r");
            }

        }
        else if (val == 0x88) {
            printf("Enter Debug bus : 0x");
            val = get_val();
            printf("\n\r");
            eth_wr(SM_GLBL_DIAG_CSR_CFG_DIAG_SEL__ADDR,val,XGENET,0,1);
            eth_rd(SM_GLBL_DIAG_CSR_DBG_BLOCK_AXI__ADDR,XGENET,0,1);
            eth_rd(SM_GLBL_DIAG_CSR_DBG_BLOCK_NON_AXI__ADDR,XGENET,0,1);

        }
        else if (val == 0x89) {
            int loop = get_val();
            eth_rd(SM_GLBL_DIAG_CSR_DBG_BLOCK_AXI__ADDR,XGENET,0,1);

            do {
                eth_rd(SM_GLBL_DIAG_CSR_DBG_BLOCK_NON_AXI__ADDR,XGENET,0,1);
                loop --;
            }while(loop != 0);
        }
        else if(val == 0x99) {
            printf("Enter XGENET Port to Configure(0/1/2/3) : ");
            init_xgenet(get_val(), 0x1);
        }
        else if (val == 0x104)   
        {
            //printf("ReSet PHY loopback mode:\n"); 

            int tmp;
            printf("\n0->Set_SERDES_Tx-2-Rx_lpbk 1->ReSet_SERDES_Tx-2-Rx_lpbk\n");
            tmp = get_val();
            if(tmp == 0) {
                printf("Set SERDES Level Tx-2-Rx loopback mode\n"); 
                set_serdes_lpbk();
            }
            else if(tmp == 1) {
                printf("ReSet SERDES Level Tx-2-Rx loopback mode\n"); 
                reset_serdes_lpbk();
            }    
        }
        else if (val == 0x105)    
        {
            printf("Send PAckets\n"); 
        }
        else if (val == 0x106)    
        {
            printf("Read From PHY\n"); 
            printf("\nEnter PHY Address (hex): \n");
            phy_addr = get_val();
            printf("\nEnter Reg Address (hex): \n");
            phy_reg = get_val();

            ind_address = ((phy_addr << 8) | phy_reg);

            ind_data = mdio_rd(ind_address,MENET,0,0);
            printf("\nphy_addr:0x%x phy_reg:0x%x ind_address:0x%x ind_data:0x%x \n",phy_addr,phy_reg,ind_address,ind_data);
        }
        else if (val == 0x107)    
        {
            printf("\nEnter PHY Address (hex): \n");
            phy_addr = get_val();
            printf("\nEnter Reg Address (hex): \n");
            phy_reg = get_val();
            printf("\nEnter Write Value (hex): \n");
            ind_data = get_val();

            ind_address = ((phy_addr << 8) | phy_reg);
            mdio_wr(ind_address,ind_data,MENET,0,0);
            printf("\nphy_addr:0x%x phy_reg:0x%x ind_address:0x%x ind_data:0x%x \n",phy_addr,phy_reg,ind_address,ind_data);
        }
        else if (val == 0x200)    
        {
            printf("OPTIONAL : 205 link_status_xg  - Prints Link Status of four ports\n");
            printf("OPTIONAL : 206 mac_stat_1g_xfi     - Prints MAC  Statistics of four ports\n");
            printf("OPTIONAL : 207 print_stat_xg   - Prints Full Statistics \n");
        }

        else if (val == 0x205)    
        {link_status_xg();
        }
        else if (val == 0x206)    
        {mac_stat_1g_xfi();
        }
        else if (val == 0x207)    
        {print_stat_sgmii_xfi();
        }

    }while (quit_r != 0x71);//end while
}

