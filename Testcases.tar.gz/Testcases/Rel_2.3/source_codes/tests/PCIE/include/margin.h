#include "pcie_base.h"

#define EMPTYY                                 0
#define CTLE_AC_IDX                            1
#define CTLE_DC_IDX                            2
#define CTLE_EQ_FR_IDX                         3
#define CTLE_EQ_QR_IDX                         4
#define CTLE_EQ_HR_IDX                         5
#define CTLE_EQ_IDX                            6
#define DFE_IDX                                7
#define PQ_SIGN_IDX                            8
#define PQ_VALUE_IDX                           9
#define LOCAL_PRESET_IDX                       10
#define REMOTE_PRESET_IDX                      11
#define REMOTE_BCA_PRESET_IDX                  12
#define MU_PHASE1_IDX                          13
#define MU_PHASE2_IDX                          14
#define MU_PHASE3_IDX                          15
#define MU_PHASE4_IDX                          16
#define MU_PHASE5_IDX                          17
#define MU_PHASE6_IDX                          18
#define MU_PHASE7_IDX                          19
#define MU_PHASE8_IDX                          20
#define MU_PHASE9_IDX                          21

#define MAX_SUPPRTED_RX_PARAM                  21

#define CH_TX_RX_REG  50
#define RANGE         3
#define HIGH_RANGE    3

typedef uint32_t (* get_margin_t)(uint32_t);

extern uint32_t X_AXIS, Y_AXIS;
extern void print_rx_data(pcie_core_id);
extern char *Rx_serdes_param[];
extern uint32_t Ch_RxTxParam[CH_TX_RX_REG][RANGE];
extern get_margin_t get_margin[3];




