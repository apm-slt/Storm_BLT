/*
 */
#ifndef __PCIE_BASE_TEST_H_
#define __PCIE_BASE_TEST_H_

 // #define DBG_1                                 // BUG :41145
 // #define DBG_3                                 // to disable memory initilization
 // #define PCIE_EXERCISER
 // #define BOARD_MUSTANG2
 // #define MORE_DESCRIPTORS                      // Not possible since it causes SW overhead
 // #define MULTIPLE_Q
 // #define PERF_RC_OB_WR                         // To measure performnace with Mellanox card
 // #define PERF_2_PORTS

 #define DMA_INT_ENABLE
 #define EN_AER
// #define STRESS_TEST
 #define BLT_TEST
 
 #define PERF_MEASURMENT
 #define TEST_LEN  0x2000000

#ifdef STRESS_TEST
#define STRESS_ITR_CNT 10000

// #define STRESS_TEST_LEN 0x4000000             // 64MB
 #define STRESS_TEST_LEN 0x2000000                // 33MB
#endif

#ifdef MULTIPLE_Q
#define MAX_FILES 10
#endif

#ifdef MORE_DESCRIPTORS
#define STRESS_TEST_LEN 0xFF00000               // 255 MB
#define MAX_DESCRIPTORS 16                      // For 256MB SET TO : 16 is max
#define MAX_DESC_SIZE 0xFFFFFC                  // 16 MB
#endif


#if defined(CONFIG_VHP) | defined(CONFIG_BB1) | defined(CONFIG_BB2) //Storm test
#define VBIOS 1
#endif
#define MSI_TER_SIZE 0xFFFFFFFFFF800000ULL
#define MSI_INDX_REG 0x79000000

#define RD 0
#define WR 1

#include "pcie_ib_test.h"
#include "pcie_ob_test.h"
#include "pcie_dma_test.h"
#include "pcie_int_msi_test.h"
#include "pcie_pwr_mgmt.h"

void sm_pcie_clear_ep_test_sig(uint32_t pcie_core_id);
uint32_t sm_pcie_test_rc(uint32_t pcie_core_id, uint32_t test_name, uint32_t test_pattern, uint32_t length, uint32_t extended_addr);
void sm_pcie_test_ep(uint32_t pcie_core_id);
uint32_t sm_pcie_chk_eq_result(uint32_t pcie_core_id);
uint32_t sm_pcie_chk_results(uint32_t pcie_core_id, uint32_t test_id, uint32_t test_pattern, uint32_t len);
#endif
