//Tinh-SLT
#include "../include/pcie_base.h"
#include "../include/pcie_base_test.h"
//End of Tinh-SLT
int l_sumer [8], lsumer_p [8], lsumer_n[8];
int l_do [8], ldo_p [8], ldo_n [8];
int l_de [8], lde_p [8], lde_n [8];
int l_eo [8], leo_p [8], leo_n [8];
int l_ee [8], lee_p [8], lee_n [8];
int l_xo [8], lxo_p [8], lxo_n [8];
int l_xe [8], lxe_p [8], lxe_n [8];
int l_so [8], lso_p [8], lso_n [8];
int l_se [8], lse_p [8], lse_n [8];

void sm_pcie_init_only(uint32_t pcie_core_id, uint32_t port_type, uint32_t en_lpbk, uint32_t gen, uint32_t ext_ref, uint32_t link_width, uint32_t poll) {
uint32_t data, full_width, i, print_state;
uint32_t act_link_width, exp_link_width;
uint32_t act_link_speed, exp_link_speed;
uint32_t  pllnoerr = 1, count = 0;

  act_link_width = 0;
  exp_link_width = link_width;
  act_link_speed = 0;
  exp_link_speed = gen;


//  pcie_ddr_remap();   //DDR remap, not used as 40bit DDR map works now
  if (((pcie_core_id == 0) || (pcie_core_id == 3)) && (link_width == 8))
    full_width = 1;
  else
    full_width = 0;

    lprintf(5,"Initializing the clkrst module to enable the csr clks and deassert the csr resets.\n\r");
    sm_pcie_init_csr_clkrst(pcie_core_id);
  
    if((pcie_core_id == 0) || (pcie_core_id == 3)){
      if (full_width) {
        lprintf(5,"setting PCIEX8 full width\n\r");
        //setting this bit will allow reset from core 0 to reset serdes of core 1
        data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_MUX__ADDR);
        data = FIELD_PCIE_SDS_MUX_SEL_PCIE_FULL_WIDTH_SET(data, 0x1);
        pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_MUX__ADDR, data);
      }
      else {
        lprintf(5,"Clearing PCIEX8 full width\n\r");
        //setting this bit will allow reset from core 0 to reset serdes of core 1
        data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_MUX__ADDR);
        data = FIELD_PCIE_SDS_MUX_SEL_PCIE_FULL_WIDTH_SET(data, 0x0);
        pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_MUX__ADDR, data);      
      }
    }
  
    sm_pcie_init_phy(pcie_core_id, port_type, gen, ext_ref, link_width, en_lpbk);
    sm_pcie_init_ecc(pcie_core_id);
   en_event_int(pcie_core_id); 
   sm_pcie_wait_phy_rdy(pcie_core_id);

  if(port_type == EP) {
	  lprintf(5,"Initializing the controller for EP mode\n\r");
	  sm_pcie_init_ctrl_ep(pcie_core_id, gen);
  } else {
	  lprintf(5,"Initializing the controller for RC mode\n\r");
	  sm_pcie_init_ctrl_rc(pcie_core_id, gen);
	  sm_pcie_init_ven_msg_capture(pcie_core_id);
      sm_pcie_setup_ob_space(pcie_core_id, RC); 
  }
  
  //to set remote end to be 3.5db in GEN2, core reset must be release to program link control2 register
  //receiver detect inhibit is set first to prevent controller entering polling stage
  //once link control2 register is programmed, receiver detect bypass is set and inhibit is cleared
  pcie_inhibt_rxdet(pcie_core_id);
  sm_pcie_init_core_clkrst(pcie_core_id);
  
  if (port_type == RC){
    sm_pcie_setup_ob_cfg(pcie_core_id, RC);             
    pcie_g2_35db(pcie_core_id);
  }
  
  pcie_rcvr_det_bypass(pcie_core_id);
}

int waitComplianceMode(int pcie_core_id){
    int data, linkup;

   while(1){
	data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_PCIECORE_LTSSM__ADDR);
	if ((FIELD_PCIECORE_LTSSM_S_LTS_STATE_RD(data) == 0x1) &&
		(FIELD_PCIECORE_LTSSM_S_LTS_SUB_STATE_RD(data) == 0x10)){
   		print("entered complaince state \n\r");
		MSDELAY(100);
		break;
		}	
	}
}

int chk_link_up(int pcie_core_id){
    int data, linkup;

  MSDELAY(500);
  //polling for DL LinkUp
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_PCIECORE_CTLANDSTATUS__ADDR);
  linkup = FIELD_PCIECORE_CTLANDSTATUS_S_LINK_UP_RD(data);        
  return linkup;
}

int port_under_reset(int pcie_core_id){
  int data;
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_SRST__ADDR);
  return (data != 0);
}

void set_init_lat_val(int pcie_core_id, int ch){
int lch, sds2_offset;

	if (ch >3){
	  lch = ch-4;
	  sds2_offset = 0x30000;
	}else {
	  sds2_offset = 0x0;
	  lch = ch;
	 }
	l_sumer[ch] = FIELD_CH0_RXTX_REG14_CLTE_LATCAL_MAN_PROG_RD( pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG14__ADDR + (0x200 * lch) + sds2_offset));
    l_do[ch] = FIELD_CH0_RXTX_REG127_DO_LATCH_MANCAL_RD(pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * lch) + sds2_offset));
	l_de[ch] = FIELD_CH0_RXTX_REG129_DE_LATCH_MANCAL_RD(pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG129__ADDR + (0x200 * lch) + sds2_offset));
    l_eo[ch] = FIELD_CH0_RXTX_REG128_EO_LATCH_MANCAL_RD(pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG128__ADDR + (0x200 * lch) + sds2_offset));
	l_ee[ch] = FIELD_CH0_RXTX_REG130_EE_LATCH_MANCAL_RD(pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG130__ADDR + (0x200 * lch) + sds2_offset));
	l_xo[ch] = FIELD_CH0_RXTX_REG127_XO_LATCH_MANCAL_RD(pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * lch) + sds2_offset));
	l_xe[ch] = FIELD_CH0_RXTX_REG129_XE_LATCH_MANCAL_RD(pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG129__ADDR + (0x200 * lch) + sds2_offset));
    l_so[ch] = FIELD_CH0_RXTX_REG128_SO_LATCH_MANCAL_RD(pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG128__ADDR + (0x200 * lch) + sds2_offset));
	l_se[ch] = FIELD_CH0_RXTX_REG130_SE_LATCH_MANCAL_RD(pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG130__ADDR + (0x200 * lch) + sds2_offset));
}

void check_latch_range(int pcie_core_id, int ch){
int lch, sds2_offset;
int ldo, lde, leo, lee, lxo, lxe, lso, lse, lsumer;
int step = 1;
	if (ch >3){
	  lch = ch-4;
	  sds2_offset = 0x30000;
	}else {
	  sds2_offset = 0x0;
	  lch = ch;
	 }
	lsumer = FIELD_CH0_RXTX_REG14_CLTE_LATCAL_MAN_PROG_RD( pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG14__ADDR + (0x200 * lch) + sds2_offset));
    ldo    = FIELD_CH0_RXTX_REG127_DO_LATCH_MANCAL_RD(pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * lch) + sds2_offset));
	lde    = FIELD_CH0_RXTX_REG129_DE_LATCH_MANCAL_RD(pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG129__ADDR + (0x200 * lch) + sds2_offset));
    leo    = FIELD_CH0_RXTX_REG128_EO_LATCH_MANCAL_RD(pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG128__ADDR + (0x200 * lch) + sds2_offset));
	lee    = FIELD_CH0_RXTX_REG130_EE_LATCH_MANCAL_RD(pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG130__ADDR + (0x200 * lch) + sds2_offset));
	lxo    = FIELD_CH0_RXTX_REG127_XO_LATCH_MANCAL_RD(pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * lch) + sds2_offset));
	lxe    = FIELD_CH0_RXTX_REG129_XE_LATCH_MANCAL_RD(pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG129__ADDR + (0x200 * lch) + sds2_offset));
    lso    = FIELD_CH0_RXTX_REG128_SO_LATCH_MANCAL_RD(pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG128__ADDR + (0x200 * lch) + sds2_offset));
	lse    = FIELD_CH0_RXTX_REG130_SE_LATCH_MANCAL_RD(pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG130__ADDR + (0x200 * lch) + sds2_offset));

    //capture when value hit upper or lower limit
    /*
	if (lsumer == l_sumer[ch]+step) lsumer_p[ch] = 1;
    if (lsumer == l_sumer[ch]-step) lsumer_n[ch] = 1;
    if (ldo == l_do[ch]+step) ldo_p[ch] = 1;
	if (ldo == l_do[ch]-step) ldo_n[ch] = 1;
    if (lde == l_de[ch]+step) lde_p[ch] = 1;
	if (lde == l_de[ch]-step) lde_n[ch] = 1;
    if (leo == l_eo[ch]+step) leo_p[ch] = 1;
	if (leo == l_eo[ch]-step) leo_n[ch] = 1;
    if (lee == l_ee[ch]+step) lee_p[ch] = 1;
	if (lee == l_ee[ch]-step) lee_n[ch] = 1;
    if (lxo == l_xo[ch]+step) lxo_p[ch] = 1;
	if (lxo == l_xo[ch]-step) lxo_n[ch] = 1;
    if (lxe == l_xe[ch]+step) lxe_p[ch] = 1;
	if (lxe == l_xe[ch]-step) lxe_n[ch] = 1;
    if (lso == l_so[ch]+step) lso_p[ch] = 1;
	if (lso == l_so[ch]-step) lso_n[ch] = 1;
    if (lse == l_se[ch]+step) lse_p[ch] = 1;
	if (lse == l_se[ch]-step) lse_n[ch] = 1;
     */
	lsumer_p[ch] = 1;
    lsumer_n[ch] = 1;
    ldo_p[ch] = 1;
	ldo_n[ch] = 1;
    lde_p[ch] = 1;
	lde_n[ch] = 1;
    leo_p[ch] = 1;
	leo_n[ch] = 1;
    lee_p[ch] = 1;
	lee_n[ch] = 1;
    lxo_p[ch] = 1;
	lxo_n[ch] = 1;
    lxe_p[ch] = 1;
	lxe_n[ch] = 1;
    lso_p[ch] = 1;
	lso_n[ch] = 1;
    lse_p[ch] = 1;
	lse_n[ch] = 1;

    if (((lsumer > l_sumer[ch]+step) && lsumer_n[ch]) ||
		((lsumer < l_sumer[ch]-step) && lsumer_p[ch]))
		printf("SUMER cal out of range, ch %d, summer threshold 0x%x, summer val 0x%x \n", ch, l_sumer[ch], lsumer);
    if (((ldo > l_do[ch]+step) && ldo_n[ch]) ||
		((ldo < l_do[ch]-step) && ldo_p[ch]))
		printf("DO out of range, ch %d, DO threshold 0x%x, DO val 0x%x \n", ch, l_do[ch], ldo);
    if (((lde > l_de[ch]+step) && lde_n[ch]) ||
		((lde < l_de[ch]-step) && lde_p[ch]))
		printf("DE out of range, ch %d, DE threshold 0x%x, DE val 0x%x \n", ch, l_de[ch], lde);
    if (((leo > l_eo[ch]+step) && leo_n[ch]) ||
		((leo < l_eo[ch]-step) && leo_p[ch]))
		printf("EO out of range, ch %d, EO threshold 0x%x, EO val 0x%x \n", ch, l_eo[ch], leo);
    if (((lee > l_ee[ch]+step) && lee_n[ch]) ||
		((lee < l_ee[ch]-step) && lee_p[ch]))
		printf("EE out of range, ch %d, EE threshold 0x%x, EE val 0x%x \n", ch, l_ee[ch], lee);
    if (((lxo > l_xo[ch]+step) && lxo_n[ch]) ||
		((lxo < l_xo[ch]-step) && lxo_p[ch]))
		printf("XO out of range, ch %d, XO threshold 0x%x, XO val 0x%x \n", ch, l_xo[ch], lxo);
    if (((lxe > l_xe[ch]+step) && lxe_n[ch]) ||
		((lxe < l_xe[ch]-step) && lxe_p[ch]))
		printf("XE out of range, ch %d, XE threshold 0x%x, XE val 0x%x \n", ch, l_xe[ch], lxe);
    if (((lso > l_so[ch]+step) && lso_n[ch]) ||
		((lso < l_so[ch]-step) && lso_p[ch]))
		printf("SO out of range, ch %d, SO threshold 0x%x, SO val 0x%x \n", ch, l_so[ch], lso);
    if (((lse > l_se[ch]+step) && lse_n[ch]) ||
		((lse < l_se[ch]-step) && lse_p[ch]))
		printf("SE out of range, ch %d, SE threshold 0x%x, SE val 0x%x \n", ch, l_se[ch], lse);
}

int pcie_rst_test(int argc, char *argv[])
{
    uint32_t gen;           // 0 => gen1, 1 => gen2, 2 => gen3.
    uint32_t pcie_core_id;
    uint32_t link_width,i;
    int status = 0, cnt;
    int reinit = 0;
    int mlx = 0;
	int no_rst = 0;

    if (argc < 7){
       print("not enough argument portid, gen, link_width, cnt, reinit core, use mellanox seq, no reset\n\r");
       return -1;
    } else {
        pcie_core_id = atoi(argv[0]);
        gen          = atoi(argv[1]);
        link_width   = atoi(argv[2]);
        cnt          = atoi(argv[3]);
        reinit       = atoi(argv[4]);
        mlx          = atoi(argv[5]);
        no_rst       = atoi(argv[6]);
    }

   
    for(i=0; i<cnt; i++) {
    print("iteration %d\n\r", i);
    if (!no_rst) {
		print("set pcie reset \n\r");
		gpiods_clr_sub(pcie_core_id);
		if(!port_under_reset(pcie_core_id) && chk_link_up(pcie_core_id)){
			printf("ERROR: LINK still up after reset \n\r");
			break;
		};
	}
    
    if (mlx && !no_rst) {
        //mellanox require clearing of PCIERST# first
    	MSDELAY(100);
		print("clr pcie reset after 100ms\n\r");
        gpiods_set_sub(pcie_core_id);
    }
    
    if(reinit){
        print("initialize core \n\r");
        sm_pcie_init_only(pcie_core_id, 1, 0, gen, 1, link_width, 0);
    }

    if (!mlx && !no_rst) {
    	//waitComplianceMode(pcie_core_id);
    	print("clr pcie reset \n\r");
        gpiods_set_sub(pcie_core_id);
    }

    print("poll linkup \n\r");
    if (wait_linkup(pcie_core_id, gen, link_width) != CORRECT_LINK)
        break;
    /*
	if (i==0) {
		set_init_lat_val(pcie_core_id, 0);
		set_init_lat_val(pcie_core_id, 1);
		set_init_lat_val(pcie_core_id, 2);
		set_init_lat_val(pcie_core_id, 3);
		set_init_lat_val(pcie_core_id, 4);
		set_init_lat_val(pcie_core_id, 5);
		set_init_lat_val(pcie_core_id, 6);
		set_init_lat_val(pcie_core_id, 7);
	} else {
		check_latch_range(pcie_core_id, 0);
		check_latch_range(pcie_core_id, 1);
		check_latch_range(pcie_core_id, 2);
		check_latch_range(pcie_core_id, 3);
		check_latch_range(pcie_core_id, 4);
		check_latch_range(pcie_core_id, 5);
		check_latch_range(pcie_core_id, 6);
		check_latch_range(pcie_core_id, 7);
	}
     */
    printf("\n");
    }
}
