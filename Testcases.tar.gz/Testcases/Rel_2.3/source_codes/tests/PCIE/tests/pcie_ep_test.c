/*
 * Copyright (c) 2009 Xilinx, Inc.  All rights reserved.
 *
 * Xilinx, Inc.
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS" AS A
 * COURTESY TO YOU.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION AS
 * ONE POSSIBLE   IMPLEMENTATION OF THIS FEATURE, APPLICATION OR
 * STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS IMPLEMENTATION
 * IS FREE FROM ANY CLAIMS OF INFRINGEMENT, AND YOU ARE RESPONSIBLE
 * FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE FOR YOUR IMPLEMENTATION.
 * XILINX EXPRESSLY DISCLAIMS ANY WARRANTY WHATSOEVER WITH RESPECT TO
 * THE ADEQUACY OF THE IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO
 * ANY WARRANTIES OR REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE
 * FROM CLAIMS OF INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

/*
 * helloworld.c: simple test application
 */
//Tinh-SLT
#include "../include/pcie_base.h"
#include "../include/pcie_base_test.h"
//End of Tinh-SLT

int pcie_ep_test(int argc, char *argv[])
{
    uint32_t port_type = 0;     // 0 => EP mode, 1 => RC mode.
    uint32_t en_lpbk = 0;       // 1 => self crosslink mode is enabled.
    uint32_t gen;           // 0 => gen1, 1 => gen2, 2 => gen3.
    uint32_t pcie_core_id;
    uint32_t ext_ref = 1;
    uint32_t link_width = 8;   
    uint32_t poll = 1;
    uint32_t mode = 0;

    if (argc < 1){
       print("not enough argument: portid mode\n\r");
       return -1;
    } else {
        pcie_core_id = atoi(argv[0]);
        mode = atoi(argv[1]);
        if (pcie_core_id>4) {
            print("error argument portid=%d, gen=%d, link_width=%d\n\r", pcie_core_id, gen, link_width);
            return -2;
        }
    }

#ifndef SM_SOC_SIM   
    init_platform();
    ocm_init();
#endif    
    print("pcie_ep_test w/o init \n\r\n\r");

//    sm_pcie_init(pcie_core_id, port_type, en_lpbk, gen, ext_ref, link_width, poll);
//    print("Linkup achieved for EP DUT in normal mode. Now, will do some testing.\n\r");

    sm_pcie_test_ep(pcie_core_id);

#ifndef SM_SOC_SIM
    cleanup_platform();
#endif    

    print("************** pcie_ep_test() return ************\n\r");
    return 0;
}
