/*
 * Copyright (c) 2009 Xilinx, Inc.  All rights reserved.
 *
 * Xilinx, Inc.
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS" AS A
 * COURTESY TO YOU.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION AS
 * ONE POSSIBLE   IMPLEMENTATION OF THIS FEATURE, APPLICATION OR
 * STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS IMPLEMENTATION
 * IS FREE FROM ANY CLAIMS OF INFRINGEMENT, AND YOU ARE RESPONSIBLE
 * FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE FOR YOUR IMPLEMENTATION.
 * XILINX EXPRESSLY DISCLAIMS ANY WARRANTY WHATSOEVER WITH RESPECT TO
 * THE ADEQUACY OF THE IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO
 * ANY WARRANTIES OR REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE
 * FROM CLAIMS OF INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

/*
 * helloworld.c: simple test application
 */

//Tinh-SLT
#include "../include/pcie_base.h"
#include "../include/pcie_base_test.h"
//End of Tinh-SLT

//#define SDS_DEBUG
#define PER_CNT 1
uint32_t perf_number[PER_CNT];

int pcie_rc_test(int argc, char *argv[])
{
    uint32_t port_type = 1;     // 0 => EP mode, 1 => RC mode.
    uint32_t en_lpbk = 0;       // 1 => self crosslink mode is enabled.
    uint32_t gen;           // 0 => gen1, 1 => gen2, 2 => gen3.
    uint32_t pcie_core_id;
    uint32_t ext_ref = 1;
    uint32_t link_width;
    uint32_t test_name;
    uint32_t test_pattern = 1;
    uint32_t length = /*0x3fffffc*/0x2000000;
    uint32_t extended_addr = 0;
    uint32_t poll = 1,i=0;
    
    if (argc < 3){
       print("not enough argument portid, gen, link_width, test_id [test_pattern]\n\r");
       printf("For test_id 15 (ASPM test), valid values of test_pattern are only 0 or 1.\n\r");
       return -1;
    } else {
        pcie_core_id = atoi(argv[0]);
        gen          = atoi(argv[1]);
        link_width   = atoi(argv[2]);
        test_name    = atoi(argv[3]);
        if(argc == 4) {
          test_pattern = atoi(argv[4]);
          if(test_name == 15 && test_pattern > 1) {
            printf("For test_id 15 (ASPM test), valid values of test_pattern are only 0 or 1.\n\r");
            return -1;
          }
        }
        if ((pcie_core_id>4)||(gen>2)||(link_width>8)) {
            print("error argument portid=%d, gen=%d, link_width=%d, test_id=%d \n\r", pcie_core_id, gen, link_width, test_name);
            return -2;
        }
    }

#ifndef SM_SOC_SIM   
    init_platform();
    ocm_init();
#endif    
    print("pcie_rc_test w/o init \n\r\n\r");

//    sm_pcie_init(pcie_core_id, port_type, en_lpbk, gen, ext_ref, link_width, poll);
//    print("Linkup achieved in gen1 for RC DUT in normal mode. Now, will do some testing.\n\r");

  test_pattern=1;
  for(i=0;i<=PER_CNT;i++)
  {
    sm_pcie_test_rc(pcie_core_id, test_name, test_pattern, length, extended_addr);

  }
  for(i=0;i<=PER_CNT;i++)
  {
	  printf("Iteration : %d -> Performance : %d \n\r :" ,i,perf_number[i]);
  }

#ifndef SM_SOC_SIM
    cleanup_platform();
#endif    

    print("************** pcie_rc_test() return ************\n\r");
    return 0;
}
