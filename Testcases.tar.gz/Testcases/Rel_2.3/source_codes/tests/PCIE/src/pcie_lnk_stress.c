#include <stdio.h>
//Tinh-SLT
#include "../include/pcie_lpbk.h"
#include "../include/pcie_isr.h"
#include "../include/pcie_base_test.h"
#include "../include/pcie_base.h"
#include "../include/pcie_ib_test.h"
//End of Tinh-SLT
#include <common.h>

 // extern volatile unsigned int dma_int;


int st_lnk(int argc, char *argv[])
{
  int i=argc+1, j=0;
  int error=0;
  uint32_t rc_slot,ep_slot,gen,link_width,test_id,len= TEST_LEN,ex_cnt=0,max_cnt=5,data=0 ; 
  
  if ((i<6)||(i>8)) 
    error=1;  
  else {
    rc_slot = atoi(argv[j]);
    ep_slot = atoi(argv[j+1]);
    gen = atoi(argv[j+2]);
    link_width = atoi(argv[j+3]);
    test_id = atoi(argv[j+4]);
	if(argc==6)
	max_cnt=atoi(argv[j+5]);	
    if (i==8) {
      if (strncmp(argv[j+5],"0x",2)!=0) 
        len = strtol(argv[j+5], NULL, 16);
      else
        len = strtol(argv[j+5], NULL, 0);
    }
    if (len<16)
      len = 2048;
    if (len>(1<<28))
      len = 1<<28;
    if ((gen>2)||((link_width!=1)&&(link_width!=2)&&(link_width!=4)&&(link_width!=8)))
      error=2;
    if ((rc_slot>2)||(ep_slot>2)||(rc_slot==ep_slot))
      error = 3;
  }
  if (error) {
    lprintf(3,"pcie_lpbk: argument error %1d-%d. Usage: rc_slot ep_slot gen link_width test_id [len]\n", error, i);
    lprintf(3,"           gen=0~2, link=1/2/4/8,Loop cnt,default len=32MB.\n");
    lprintf(3," test_id = \n");
    lprintf(3,"           4 => Multi Channel RC DMA AXI-to-PCIE\n");
    lprintf(3,"           5 => Multi Channel RC DMA PCIE-to-AXI\n");
    lprintf(3,"           10=> Multi Channel EP DMA AXI-to-PCIE\n");
    lprintf(3,"           11=> Multi Channel EP DMA PCIE-to-AXI\n");
    lprintf(3,"           12=> Multi Channel EP DMA interleaved\n");
    return error;
  }

   	error = pcie_lpbk_stress(rc_slot, ep_slot, gen, link_width, test_id, len);
  
   printf("\n");
   printf("\n");	
    return error;
  }

 extern uint32_t Stress_TestOnGng;
int pcie_lpbk_stress(uint32_t rc_slot, uint32_t ep_slot, uint32_t gen, uint32_t link_width, uint32_t test_id, uint32_t length)
{
    int error = 0,res=0,data=0;
    uint32_t ext_ref = 1, rc_id = rc_slot, ep_id = ep_slot;
       uint32_t extended_addr = 0;
    uint32_t itr=0,lnk_status=0;
    uint32_t test_pattern = 0;

    if (rc_slot!=0)
      rc_id++; 
    if (ep_slot!=0)
      ep_id++; 

	lprintf(5,"RC Initialization on core%1d \n", rc_id);  	
    sm_pcie_init(rc_id, 1, 0, gen, ext_ref, link_width, 0);
    en_event_int(rc_id);
   
    lprintf(5," EP Initialization on core%1d \n", ep_id); 
    sm_pcie_init(ep_id, 0, 0, gen, ext_ref, link_width, 0);

    en_event_int(ep_id);
  
    lprintf(5,"Polling for linkup through RC side\n");	

    //res=sm_pcie_poll_linkup(rc_id, gen, link_width, 0);
    res=wait_linkup(rc_id, gen, link_width);
	  
    switch(res)
    {
    case NO_LINK:
    	printf(" >> Link up Fail<<  \n\r");
		
    	return(0);
    	break;
    case CORRECT_LINK:
    	//printf("  >> Link up PASS  <<  \n\r");
		print_link(rc_id);
    	break;
    case WRONG_LINK:
        print_link(rc_id);
    	printf(" >> LINK ALIVE with Incorrect Negotiation ** << \n\r",itr);
		
        return;
    	break;

    }      
    
	switch(test_id)
   {
    case 0 : error = sm_pcie_test_rc(rc_id, 10, test_pattern, length, extended_addr);   //EP DMA OB-WR
             sm_pcie_test_ep(ep_id); 
			 Stress_TestOnGng=1;
		//	 printf("Total Int : %d \n\r",dma_int);
		//	 dma_int=0;
	break;
	default:
	break;
   }	 

}
