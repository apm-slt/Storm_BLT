/* debug and miscellaneous function used in PCIE validation and test */
#include <types.h>
#include <stdio.h>
#include <common.h>
//Tinh-SLT
#include "../include/pcie_base.h"
#include "../include/pcie_ib_test.h"

extern void InitPERST_EP(unsigned int pcie_core_id);
extern uint32_t WR_BW_g,RD_BW_g;

#define SEC_2_NS_CONST 1000000000
#define KB_2_MB_CONST  1024

void serdes_config_x1_fr_lpbk(uint32_t pcie_core_id) {
  uint32_t data;

  lprintf(5,"Enabling the tx-to-rx fwd loopback for X1 SERDES\n\r");
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG11__ADDR);
  data = FIELD_CH0_RXTX_REG11_PHASE_ADJUST_LIMIT_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG11__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR);
  data = FIELD_CH0_RXTX_REG4_TX_LOOPBACK_BUF_EN_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR);
  data = FIELD_CH0_RXTX_REG7_LOOP_BACK_ENA_CTLE_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR, data);
};  

void serdes_config_x4_fr_lpbk(uint32_t pcie_core_id) {
  uint32_t data;

  lprintf(5,"Enabling the tx-to-rx fwd loopback for X4 SERDES\n\r");
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG11__ADDR);
  data = FIELD_CH0_RXTX_REG11_PHASE_ADJUST_LIMIT_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG11__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR);
  data = FIELD_CH0_RXTX_REG4_TX_LOOPBACK_BUF_EN_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR);
  data = FIELD_CH0_RXTX_REG7_LOOP_BACK_ENA_CTLE_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH1_RXTX_REG11__ADDR);
  data = FIELD_CH1_RXTX_REG11_PHASE_ADJUST_LIMIT_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH1_RXTX_REG11__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH1_RXTX_REG4__ADDR);
  data = FIELD_CH1_RXTX_REG4_TX_LOOPBACK_BUF_EN_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH1_RXTX_REG4__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH1_RXTX_REG7__ADDR);
  data = FIELD_CH1_RXTX_REG7_LOOP_BACK_ENA_CTLE_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH1_RXTX_REG7__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH2_RXTX_REG11__ADDR);
  data = FIELD_CH2_RXTX_REG11_PHASE_ADJUST_LIMIT_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH2_RXTX_REG11__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH2_RXTX_REG4__ADDR);
  data = FIELD_CH2_RXTX_REG4_TX_LOOPBACK_BUF_EN_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH2_RXTX_REG4__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH2_RXTX_REG7__ADDR);
  data = FIELD_CH2_RXTX_REG7_LOOP_BACK_ENA_CTLE_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH2_RXTX_REG7__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH3_RXTX_REG11__ADDR);
  data = FIELD_CH3_RXTX_REG11_PHASE_ADJUST_LIMIT_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH3_RXTX_REG11__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH3_RXTX_REG4__ADDR);
  data = FIELD_CH3_RXTX_REG4_TX_LOOPBACK_BUF_EN_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH3_RXTX_REG4__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH3_RXTX_REG7__ADDR);
  data = FIELD_CH3_RXTX_REG7_LOOP_BACK_ENA_CTLE_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH3_RXTX_REG7__ADDR, data);  
};

void serdes2_config_x4_fr_lpbk(uint32_t pcie_core_id) {
  uint32_t data;

  lprintf(5,"Enabling the tx-to-rx fwd loopback for X4 SERDES2\n\r");
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH0_RXTX_REG11__ADDR);
  data = FIELD_CH0_RXTX_REG11_PHASE_ADJUST_LIMIT_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH0_RXTX_REG11__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR);
  data = FIELD_CH0_RXTX_REG4_TX_LOOPBACK_BUF_EN_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR);
  data = FIELD_CH0_RXTX_REG7_LOOP_BACK_ENA_CTLE_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH1_RXTX_REG11__ADDR);
  data = FIELD_CH1_RXTX_REG11_PHASE_ADJUST_LIMIT_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH1_RXTX_REG11__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH1_RXTX_REG4__ADDR);
  data = FIELD_CH1_RXTX_REG4_TX_LOOPBACK_BUF_EN_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH1_RXTX_REG4__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH1_RXTX_REG7__ADDR);
  data = FIELD_CH1_RXTX_REG7_LOOP_BACK_ENA_CTLE_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH1_RXTX_REG7__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH2_RXTX_REG11__ADDR);
  data = FIELD_CH2_RXTX_REG11_PHASE_ADJUST_LIMIT_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH2_RXTX_REG11__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH2_RXTX_REG4__ADDR);
  data = FIELD_CH2_RXTX_REG4_TX_LOOPBACK_BUF_EN_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH2_RXTX_REG4__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH2_RXTX_REG7__ADDR);
  data = FIELD_CH2_RXTX_REG7_LOOP_BACK_ENA_CTLE_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH2_RXTX_REG7__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH3_RXTX_REG11__ADDR);
  data = FIELD_CH3_RXTX_REG11_PHASE_ADJUST_LIMIT_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH3_RXTX_REG11__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH3_RXTX_REG4__ADDR);
  data = FIELD_CH3_RXTX_REG4_TX_LOOPBACK_BUF_EN_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH3_RXTX_REG4__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH3_RXTX_REG7__ADDR);
  data = FIELD_CH3_RXTX_REG7_LOOP_BACK_ENA_CTLE_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES2_X4_RXTX_REGS_CH3_RXTX_REG7__ADDR, data);  
};

//force complaince pattern on port, used in tests
void force_cp_mode(int pcie_core_id) {
uint32_t data;
  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR);
  data = FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352_CFG_CONSTANTS_FORCE_COMPLIANCE_PATTERN_SET(data, 0x1);
  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR, data);
}

void clr_cp_mode(int pcie_core_id) {
uint32_t data;
  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR);
  data = FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352_CFG_CONSTANTS_FORCE_COMPLIANCE_PATTERN_SET(data, 0x0);
  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR, data);
}

//set 3 phy parameters to adjust the eye, use 2,15,5 for gen3 else 2,15,0
int set_cp(int argc, char *argv[]){
  uint32_t data, cn2, cp1, cn1, pcie_core_id, ch, sds2, sds2_offset;

  if (argc < 5){
    lprintf(5,"not enough argument, pcie_id, ch, cp1, cn1, cn2 \n\r");
    return -1;
  } else {
    pcie_core_id = atoi(argv[0]);
    ch = atoi(argv[1]);
    cp1  = atoi(argv[2]);
    cn1  = atoi(argv[3]);
    cn2  = atoi(argv[4]);
  }

  if (ch > 4){
    sds2_offset = 0x30000;
  } else {
    sds2_offset = 0x0;
  }

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG5__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG5_TX_CN2_SET(data, cn2);
  data = FIELD_CH0_RXTX_REG5_TX_CP1_SET(data, cp1);
  data = FIELD_CH0_RXTX_REG5_TX_CN1_SET(data, cn1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG5__ADDR + (0x200 * ch) + sds2_offset, data);
}

int set_pipe_cp(int argc, char *argv[]){
  uint32_t data, c0, cp1, cm1, pcie_core_id;

  if (argc < 4){
    lprintf(3,"not enough argument, pcie_id, c0, cp1, cm1 \n\r");
    return -1;
  } else {
    pcie_core_id = atoi(argv[0]);
    c0  = atoi(argv[2]);
    cp1  = atoi(argv[3]);
    cm1  = atoi(argv[4]);
  }

  data = c0;
  data = cp1 << 6 | data;
  data = cm1 << 12 | data;
  pcie_phy_csr_write(pcie_core_id, (0x10000 | 0x0c), data);
  data = pcie_phy_csr_read(pcie_core_id, (0x10000 | 0x0c));
  lprintf(5,"pipe read data addr 0x1000c, data 0x%x \n\r", data);
}

int bert_check(int argc, char *argv[]){
  uint32_t data, pcie_core_id, ch, pass, fail, rst;

  if (argc < 3) {
    printf("Usage: core_id, channel, reset\n");
    return -1;
  }
  pcie_core_id = atoi(argv[0]);
  ch = atoi(argv[1]);
  rst = atoi(argv[2]);
  
  bert_check_sub(pcie_core_id, ch, 1, rst);
}

int bert_check_sub (int pcie_core_id, int ch, int dbg,int rst){
  uint32_t data, pass, fail, sds_offset;
  
  pass = 0;
  fail = 0;

  if (ch >= 4){ sds_offset = 0x30000; ch = ch - 4;}
  else sds_offset = 0;
  

if(rst) 
{
  if (dbg) lprintf(5,"Digital RX reset \n\r");
  //toggle 0-1
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds_offset);
  data = FIELD_CH0_RXTX_REG7_RESETB_RXD_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds_offset, data);

  MSDELAY(100);
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds_offset);
  data = FIELD_CH0_RXTX_REG7_RESETB_RXD_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds_offset, data);

  if (dbg) lprintf(5,"BERT RESYNC \n\r");
  //toggle 1-0
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG6__ADDR + (0x200 * ch) + sds_offset);
  data = FIELD_CH0_RXTX_REG6_RX_BIST_RESYNC_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG6__ADDR + (0x200 * ch) + sds_offset, data);

  MSDELAY(100);
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG6__ADDR + (0x200 * ch) + sds_offset);
  data = FIELD_CH0_RXTX_REG6_RX_BIST_RESYNC_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG6__ADDR + (0x200 * ch) + sds_offset, data);

  if (dbg) lprintf(5,"BERT RESET \n\r");
  //toggle 0-1
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds_offset);
  data = FIELD_CH0_RXTX_REG61_BERT_RESETB_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds_offset, data);

  MSDELAY(100);
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds_offset);
  data = FIELD_CH0_RXTX_REG61_BERT_RESETB_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds_offset, data);

 }

  MSDELAY(100);
  if (dbg) lprintf(5,"BERT check result \n\r");
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG158__ADDR + (0x200 * ch) + sds_offset);
  pass = (data & 0x0080) >> 7;
  fail = (data & 0x0040) >> 6;
  
  if(dbg) {
      if (pass & fail)
        lprintf(3,"PASS and FAIL\n\r");
      else if (pass) 
        lprintf(3,"BIST PASS.\n\r");
      else if (fail)
        lprintf(3,"BIST FAIL.\n\r");
      else
        lprintf(3,"no PASS or FAIL\n\r");
  }
  if(fail) return 1;
  else if (pass) return 0;
}

int bert_cnt(int argc, char *argv[]){
  uint32_t data, lsb_cnt, msb_cnt;
  uint32_t pcie_core_id, ch;

  if (argc < 2) {
    lprintf(3,"Usage: core_id, channel\n");
    return -1;
  }
  pcie_core_id = atoi(argv[0]);
  ch = atoi(argv[1]);

  bert_cnt_sub(pcie_core_id, ch);

}

void bert_cnt_sub(int pcie_core_id, int ch){
int sds_offset;
uint32_t data, lsb_cnt, msb_cnt;

  if (ch >= 4){ sds_offset = 0x30000; ch = ch - 4;}
  else sds_offset = 0;
  
  //toggle 1 to 0
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG6__ADDR+ (0x200 * ch)+ sds_offset);
  data = FIELD_CH0_RXTX_REG6_RX_BIST_ERRCNT_RD_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG6__ADDR+ (0x200 * ch)+ sds_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG6__ADDR + (0x200 * ch) + sds_offset);
  data = FIELD_CH0_RXTX_REG6_RX_BIST_ERRCNT_RD_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG6__ADDR + (0x200 * ch) + sds_offset, data);

  lsb_cnt = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG153__ADDR + (0x200 * ch)+ sds_offset);
  msb_cnt = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG152__ADDR + (0x200 * ch)+ sds_offset);

  printf(" MSB ERR Count 0x%x : LSB ERR Count 0x%x \n\r", msb_cnt, lsb_cnt);
}

void chk_bert_active(int pcie_core_id, int ch){
int sds_offset;
uint32_t data, lsb_cnt, msb_cnt;
int org_ch;
  org_ch = ch;
  if (ch >= 4){ sds_offset = 0x30000; ch = ch - 4;}
  else sds_offset = 0;

while(1){
  //toggle 1 to 0
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG6__ADDR+ (0x200 * ch)+ sds_offset);
  data = FIELD_CH0_RXTX_REG6_RX_BIST_ERRCNT_RD_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG6__ADDR+ (0x200 * ch)+ sds_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG6__ADDR + (0x200 * ch) + sds_offset);
  data = FIELD_CH0_RXTX_REG6_RX_BIST_ERRCNT_RD_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG6__ADDR + (0x200 * ch) + sds_offset, data);

  lsb_cnt = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG153__ADDR + (0x200 * ch)+ sds_offset);
  msb_cnt = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG152__ADDR + (0x200 * ch)+ sds_offset);

  if ((msb_cnt == 0x8000) && (lsb_cnt == 0x0)){
      printf("BERT count not reset, reseting the BERT ch %d \n", org_ch);
      bert_check_sub (pcie_core_id, org_ch, 0, 1);
  } else break; 
}
  
}

int bert_chk_all(int argc, char *argv[]){
  uint32_t core, ch, i;

  if (argc < 1) {
    print("Usage: core_id\n");
    return -1;
  }
  core = atoi(argv[0]);

  if(core == 2) ch = 1;
  else if ((core == 0) || (core == 3)) ch= 8;
  else if ((core == 1) || (core == 4)) ch= 4;
  
  for(i=0; i < ch; i++){
    printf("CH %d \n", i);
    bert_check_sub(core, i, 1, 0);
    bert_cnt_sub(core, i);
    printf("\n");
  }
}


int rx_pattern(int argc, char *argv[]){
  uint32_t data0, data1, data2, data3, data4;
  uint32_t pcie_core_id, ch, sds_offset;

  if (argc < 2) {
    lprintf(3,"Usage: ip_port\n");
    return -1;
  }
  pcie_core_id = atoi(argv[0]);
  ch = atoi(argv[1]);

  if (ch >= 4){ sds_offset = 0x30000; ch = ch - 4;}
  else sds_offset = 0;
  
  data0 = pcie_phy_csr_read(pcie_core_id, (KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG60__ADDR + (0x200 * ch)+sds_offset));
  data1 = pcie_phy_csr_read(pcie_core_id, (KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG59__ADDR + (0x200 * ch)+sds_offset));
  data2 = pcie_phy_csr_read(pcie_core_id, (KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG58__ADDR + (0x200 * ch)+sds_offset));
  data3 = pcie_phy_csr_read(pcie_core_id, (KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG57__ADDR + (0x200 * ch)+sds_offset));
  data4 = pcie_phy_csr_read(pcie_core_id, (KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG56__ADDR + (0x200 * ch)+sds_offset));

  printf("rx pattern 0 0x%x \n\r", data0);
  printf("rx pattern 1 0x%x \n\r", data1);
  printf("rx pattern 2 0x%x \n\r", data2);
  printf("rx pattern 3 0x%x \n\r", data3);
  printf("rx pattern 4 0x%x \n\r", data4);
}

void rxdetect_mask(uint32_t pcie_core_id, uint32_t width) {
uint32_t data, mask;
  switch (width)
  {
    case (1): mask = 0x1; break;
    case (2): mask = 0x3; break;
    case (4): mask = 0xf; break;
    case (8): mask = 0xff; break;
    default: mask = 0xffff; break;
  }

  data = pcie_csr_read(pcie_core_id,  NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_543_512__ADDR);
  data = FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_543_512_CFG_CONSTANTS_RX_DETECT_OVERRIDE_SET(data, 0x1);
  pcie_csr_write(pcie_core_id,  NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_543_512__ADDR, data);

  data = pcie_csr_read(pcie_core_id,  NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_575_544__ADDR);
  data = FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_575_544_CFG_CONSTANTS_RX_DETECT_MASK_SET(data, mask);
  pcie_csr_write(pcie_core_id,  NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_575_544__ADDR, data);
}

void sm_pcie_en_self_crslink(uint32_t pcie_core_id) {
  uint32_t data;

  lprintf(5,"Enabling self crosslink in the controller.\n\r");

  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_543_512__ADDR));
  data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_543_512_CFG_CONSTANTS_SELF_CROSSLINK_MASK;
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_543_512__ADDR), data);

  lprintf(5,"Bypassing the receiver detection .\n\r");
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR));
  data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352_CFG_CONSTANTS_BYPASS_RECEIVER_DETECTION_MASK;
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR), data);

  //daniel: not sure if this is needed
  //lprintf(5,"force PIPE into loopback mode .\n\r");
  //data = pcie_phy_csr_read(pcie_core_id, KC_PIPE_REGS_PIPE_CONTROL__ADDR);
  //data = FIELD_PIPE_CONTROL_PIPE_LOOPBACK_FORCE_SET(data, 0x1);
  //pcie_phy_csr_write(pcie_core_id, KC_PIPE_REGS_PIPE_CONTROL__ADDR, data);
}  

void sds_rx_invert(int pcie_core_id, int link_width){
int data, i;

  lprintf(5,"Invert serdes rx clock ..... \n\r");
  if (link_width < 4) {
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG13__ADDR);
    data = data | 0x2000;
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG13__ADDR, data);
  } else if (link_width == 4){
    for (i = 0 ; i < 4; i++) {
        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG13__ADDR + (0x200 * i));
        data = data | 0x2000;
        pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG13__ADDR + (0x200 * i), data);
    }
  } else if (link_width == 8) {
    for (i = 0 ; i < 4; i++) {
        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG13__ADDR + (0x200 * i));
        data = data | 0x2000;
        pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG13__ADDR + (0x200 * i), data);
    }
    for (i = 0 ; i < 4; i++) {
        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG13__ADDR + (0x200 * i) + 0x30000);
        data = data | 0x2000;
        pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG13__ADDR + (0x200 * i) + 0x30000, data);
    }
  }
}

void sm_pcie_setup_generic_debug_hooks(uint32_t pcie_core_id, uint32_t axi_shim, uint32_t axi, uint32_t diagsel){
  uint32_t data;

  lprintf(5,"Setting the generic controls to bring the debug bus out on GPIOs\n\r");
  // Program GPIO_DS15 ~ GPIO_DS0 pins to select Diagnostics Data Alternate Output Function.
  data = cpu_read(0x17001294);
  //data = (data & 0xC0003000) | 0x2AAA8AAA;  //leave bit15/6 untouched, BB1 used for reset/I2C
  data = (data & 0xC3000000) | 0x28AAAAAA;  //leave bit15/12 untouched, BB1 used for reset, PCIE reset
  cpu_write(0x17001294, data);
  data = cpu_read(0x17001294);
  lprintf(5,"Value of register @0x17001294 is "); putnum_pcie(data); lprintf(5,"\n\r");

  // Program GPIO_DS15 ~ GPIO_DS0 as outputs.
  data = cpu_read(0x1700129c);
  //data |= 0x7FBF;                           //leave bit15/6 untouched
  data |= 0x6FFF;                           //leave bit15/12 untouched
  cpu_write(0x1700129c, data);
  data = cpu_read(0x1700129c);
  lprintf(5,"Value of register @0x1700129c is "); putnum_pcie(data); lprintf(5,"\n\r");

  // Write to 0x000_1700_1320 (MPA_DIAG ) to select the module to observe
  switch(pcie_core_id) {
    case 0: data = 0x00000010;
            break;
    case 1: data = 0x00000410;
            break;
    case 2: data = 0x00003022;
            break;
    case 3: data = 0x00000810;
            break;
    case 4: data = 0x00000C10;
            break;
    default: data = 0x00003022;
            break;            
  }
  cpu_write(0x17001320, data);

  data = pcie_csr_read(pcie_core_id, SM_GLBL_DIAG_CSR_CFG_DIAG_SEL__ADDR);
  if(axi_shim) {
    lprintf(5,"Selecting the AXI shim over the PCIE for diag bus\n\r");
    data |= FIELD_CFG_DIAG_SEL_CFG_SHIM_BLK_DBUS_MUX_SELECT_MASK;
  } else {
    lprintf(5,"Selecting the PCIE over the AXI shim for diag bus\n\r");
    data &= ~FIELD_CFG_DIAG_SEL_CFG_SHIM_BLK_DBUS_MUX_SELECT_MASK;
  }
  if(axi) {
    lprintf(5,"Selecting AXI parameters for diag bus\n\r");
    data &= ~FIELD_CFG_DIAG_SEL_CFG_AXI_NON_AXI_MUX_SELECT_MASK;
  } else {
    lprintf(5,"Selecting PCIE parameters for diag bus\n\r");
    data |= FIELD_CFG_DIAG_SEL_CFG_AXI_NON_AXI_MUX_SELECT_MASK;
  }
  data = FIELD_CFG_DIAG_SEL_CFG_MUX_SELECTOR_SET(data, diagsel<<1);;
  pcie_csr_write(pcie_core_id, SM_GLBL_DIAG_CSR_CFG_DIAG_SEL__ADDR, data);

  lprintf(5,"Completed setting the generic controls to bring the debug bus out on GPIOs\n\r");
}  

void sm_pcie_setup_cntlr_axi_debug_hooks(uint32_t pcie_core_id, uint32_t master, uint32_t diagsel) {
  uint32_t data;

  lprintf(5,"Setting the controller AXI debug bus to capture ");
  if(master)
    lprintf(5,"master ");
  else
    lprintf(5,"slave ");
  lprintf(5,"request attributes.\n\r");

  switch(diagsel) {
    case 0: lprintf(5,"Selecting write request attributes\n\r");
            break;
    case 1: lprintf(5,"Selecting write response attributes\n\r");
            break;
    case 2: lprintf(5,"Selecting read request attributes\n\r");
            break;
    default: lprintf(5,"Invalid option.0 will be returned on the controller AXI debug bus.\n\r");
            break;
  }

  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_I_DEBUG__ADDR);
  data |= diagsel;
  data |= (master << 4);
  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_I_DEBUG__ADDR, data);
}  

void sm_pcie_setup_cntlr_pcie_debug_hooks(uint32_t pcie_core_id, uint32_t lane, uint32_t diagsel) {
  uint32_t data;

  lprintf(5,"Setting the controller PCIE debug bus.\n\r");

  if(lane > 7)
    lprintf(5,"Caution: Setting the controller PCIE debug bus to nonexistent lane\n\r");
  if(diagsel > 7)
    lprintf(5,"Caution: Setting the diagsel to invalid option. Valid values are 0-7. 0 will be returned on controller PCIE debug bus\n\r");
// p_debug[15:12]=phy_rx_data
// p_debug[11]=phy_rx_data_valid
// p_debug[10]=phy_rx_start_block
// p_debug[9] = phy_rx_status[2] // phy-reported error
// p_debug[8] = phy_rcv_det // i.e. phy_rx_status[1:0] == 2'b11.
// p_debug[7] = phy_rx_valid
// p_debug[6] = phy_rx_elec_idle
// p_debug[5] = phy_phy_status
// p_debug[4] = phy_tx_detect_rx_loopback
// p_debug[3:2] = phy_rate
// p_debug[1:0] = phy_power_down

  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_P_DEBUG__ADDR);
  data |= lane;
  data |= (diagsel << 4);
  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_P_DEBUG__ADDR, data);
}

void sm_pcie_setup_pipe_debug_hooks(uint32_t pcie_core_id, uint32_t diagsel) {
  uint32_t data;

  lprintf(5,"Setting the PIPE debug bus.\n\r");

  if(diagsel > 5)
    lprintf(5,"Caution: Setting invalid option for PIPE debug bus mux sel. Valid values are 0-5.\n\r.");

  data = pcie_phy_csr_read(pcie_core_id, KC_PIPE_REGS_PIPE_CONTROL__ADDR);
  data = ((data & ~FIELD_PIPE_CONTROL_DEBUG_MUX_SEL_MASK) | (diagsel << FIELD_PIPE_CONTROL_DEBUG_MUX_SEL_SHIFT_MASK));
  pcie_phy_csr_write(pcie_core_id, KC_PIPE_REGS_PIPE_CONTROL__ADDR, data);

}  

uint32_t ltssm_sub(uint32_t pcie_core_id, uint32_t *status) {
  uint32_t i=*status, j=*status;
  uint32_t data,data2;
  
  do {
      *status = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_PCIECORE_LTSSM__ADDR);
      data2 = *status & FIELD_PCIECORE_LTSSM_S_LTS_STATE_MASK;
      data  = (*status & FIELD_PCIECORE_LTSSM_S_LTS_SUB_STATE_MASK) >> FIELD_PCIECORE_LTSSM_S_LTS_SUB_STATE_SHIFT_MASK;
      if ((data2 == 3)&&(data == 2)) 
        break;
      if (j > 0) 
        MSDELAY(10);
  } while (i-- > 0);
 // data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_31_0__ADDR);
 // lprintf(5,"LTSSM_STATUS: lts_state = "); putnum(*status & FIELD_PCIECORE_LTSSM_S_LTS_STATE_MASK); lprintf(5," and lts_substate = "); putnum((*status & FIELD_PCIECORE_LTSSM_S_LTS_SUB_STATE_MASK) >> FIELD_PCIECORE_LTSSM_S_LTS_SUB_STATE_SHIFT_MASK); lprintf(5,"\n\r");
//  lprintf(5,"LINK Width: "); putnum((data & 0xfc000000)>>26); lprintf(5," current link speed = "); putnum((data & 0x03000000) >> 24); lprintf(5,"\n\r");
//  sm_pcie_chk_eq_result(pcie_core_id);
  return data;
}
int ltssm(int argc, char *argv[]) {
  uint32_t status, pcie_core_id;
  uint32_t loop, data;

  if (argc < 2){
    lprintf(3,"not enough argument. port, loop \n\r");
  }
  pcie_core_id = atoi(argv[0]);
  loop = atoi(argv[1]);
  if (pcie_core_id>4) {
      lprintf(3,"wrong argument. port=0~4\n\r");
  }


  do {
	  status = 0;
	  data = ltssm_sub(pcie_core_id, &status);

	  status = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_PCIECORE_LTSSM__ADDR);
	  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_31_0__ADDR);
	  printf("LTSSM_STATUS: lts_state = %d and lts_substate = %d",status & FIELD_PCIECORE_LTSSM_S_LTS_STATE_MASK,(status & FIELD_PCIECORE_LTSSM_S_LTS_SUB_STATE_MASK) >> FIELD_PCIECORE_LTSSM_S_LTS_SUB_STATE_SHIFT_MASK);
	  printf("\n\r");
	  printf("Link Status Gen%dx%d \n\r",((data & 0x03000000) >> 24)+1,((data & 0xfc000000)>>26) );

  } while (loop--);
  return data;
}

int pcie_ltssm(int argc, char *argv[]) {
  uint32_t status, pcie_core_id;
  uint32_t loop, data;

  if (argc < 2){
    lprintf(3,"not enough argument. port, loop \n\r");
  }
  pcie_core_id = atoi(argv[0]);
  loop = atoi(argv[1]);

  do {
      status = 400;
      data = ltssm_sub(pcie_core_id, &status); 
  } while (loop--);
  return data;
}

int pcie_relink_sub(uint32_t pcie_core_id, uint32_t gen_match, uint32_t cnt)
{
    int i,j, k, devid, class, linkerr;
    uint32_t data, gen, width, status, link_width, link_speed, expected_width, expected_speed;
	uint32_t timeout=30000;
    static uint32_t counter=0; 
    expected_width = gen_match >> 8;
    expected_speed = gen_match & 0x0f;
    sm_pcie_setup_ob_cfg(pcie_core_id, RC);             
    sm_pcie_setup_ob_space(pcie_core_id, RC); 
    for (i=0;i<cnt;i++) {
        //set hot reset to retrain the link
        printf("HOT RESET of relink %d\n\r", i);
        data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_INT__ADDR);
        data = data | 0x400000;
        pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_INT__ADDR, data);
                           
        //clear hot reset
        MSDELAY(10);
        data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_INT__ADDR);
        data = data & ~(0x400000);
        pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_INT__ADDR, data);

        //check linkup status
        status = 400;
        data = ltssm_sub(pcie_core_id, &status); 
        
        data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_31_0__ADDR);
        link_width = (data & 0xfc000000) >> 26;
        link_speed = (data & 0x03000000)>>24 ;
        if(link_width != expected_width) {
            printf("link width missmatch \n\r");
            break;
        }
        if(link_speed != expected_speed) {
            printf("link speed missmatch \n\r");
            break;
        }
        MSDELAY(400);
        //clear error status
        pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_CORR_ERR_STAT__ADDR, 0xffff);
        
        //do a outbound cfg read to check link is stable
        data = 0xffffffff;
        do{
        data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR);
		timeout--;
        }while ( timeout &&(data == 0xffffffff));
		if(!timeout){
		//  lprintf(5,"Bug - > BUG_44393 \n\r ");
		  return(data);
		}
        printf("PCI DEV/VEN ID %x \n\r", data);
        data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_CLASS__ADDR);
        printf("PCI CLASS %x \n\r", data);
        
        data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_CORR_ERR_STAT__ADDR);
        linkerr = ((data & 0x10FF) != 0);
        if(linkerr) printf("link error 0x%x \n\r", data);


        printf("256 cfg read request \n\r");
        for (k=0; k<256; k++) {
        devid = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR);
        class = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_CLASS__ADDR);
        }

        printf("PCI DEV/VEN ID %x \n\r", devid);
        printf("PCI CLASS %x \n\r", class);
        data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_CORR_ERR_STAT__ADDR);
        linkerr = ((data & 0x10FF) != 0);
        if(linkerr) printf("link error 0x%x \n\r", data);
        printf("\n");
    }
    return data;
}

int pcie_relink(int argc, char *argv[])
{
    uint32_t gen_match = 0;     // width-gen
    uint32_t pcie_core_id;
    uint32_t cnt, data, width, gen,link_width;

    if (argc < 4){
       lprintf(3,"not enough argument portid, count, gen(0, 1, 2), width\n\r");
       return -1;
    } else {
        pcie_core_id = atoi(argv[0]);
        cnt = atoi(argv[1]);
        gen = atoi(argv[2]);
        width = atoi(argv[3]);
    }
    gen_match = (width << 8) | gen;
    data = pcie_relink_sub(pcie_core_id, gen_match, cnt);

    return(data);
}

int gpiods_set_sub(int core){
int val, pin;

if (core == 0)
	pin = 12;
else if (core == 3)
	pin = 13;

val = cpu_read(0x17001294);
//lprintf(5,"GPIO sel 0x%x \n\r", val);
val &= ~(3<<(pin*2));
cpu_write(0x17001294, val);

val = cpu_read(0x1700129c);
//lprintf(5,"GPIO OE 0x%x \n\r", val);
val |= 1<<pin;
cpu_write(0x1700129c, val);

val = cpu_read(0x170012a0);
//lprintf(5,"GPIO 0x%x \n\r", val);
cpu_write(0x170012a0, val|(1<<pin));
}

int gpiods_clr_sub (int core){
int val, pin;

if (core == 0)
	pin = 12;
else if (core == 3)
	pin = 13;

val = cpu_read(0x17001294);
//lprintf(5,"GPIO sel 0x%x \n\r", val);
val &= ~(3<<(pin*2));
cpu_write(0x17001294, val);

val = cpu_read(0x1700129c);
//lprintf(5,"GPIO OE 0x%x \n\r", val);
val |= 1<<pin;
cpu_write(0x1700129c, val);

val = cpu_read(0x170012a0);
//lprintf(5,"GPIO 0x%x \n\r", val);
cpu_write(0x170012a0, val & ~(1<<pin));
}

void pcie_reset(int argc, char *argv[])
{
    uint32_t data, slots = 7, toggle=3; 

    if (argc > 0) {
        slots = atoi(argv[0]); toggle = 0;
        if (slots==0) 
          toggle |= 1;
        else if (slots == 2) 
          toggle |= 2; 
    }
 
    pcie_reset_sub(toggle);
    lprintf(5,"PCIe slot reset done, argu=0/2/none for slot 0/2/0+2\n");
}

void pcie_reset_sub(uint32_t toggle)
{
    uint32_t data; 

#ifndef BOARD_MUSTANG2

    data = cpu_read(0x17001294);  //as GPIO
    data &= ~(0x0f<<24);
    cpu_write(0x17001294, data);

    data = cpu_read(0x1700129c);  //as outputs
    data |= 3<<12;
    cpu_write(0x1700129c, data);

    data = cpu_read(0x170012a0);
    cpu_write(0x170012a0, data | (toggle<<12));

    MSDELAY(500);
    data &= ~(toggle<<12);
    cpu_write(0x170012a0, data);
    MSDELAY(10);
#else
    // cfg_pin_mux_sel_2   Alternatate funation as GPIO
    data=cpu_read(0x1f2a0170);
    lprintf(5, "CFG_PIN_MUX_SEL_2 : 0x%x \n\r ",data) ;  //as GPIO  0x1f2a0170;
    data |= 0xC;
    cpu_write(0x1f2a0170, data);
    lprintf(5, "CFG_PIN_MUX_SEL_2 : 0x%x\n\r ",cpu_read(0x1f2a0170)) ;  //as GPIO  0x1f2a0170;

   // GPIO_SWPORTA_DDR
    data=cpu_read(0x1c024004);
    lprintf(5, "GPIO_SWPORTA_DDR : 0x%x \n\r ",data) ;  //as GPIO  0x1f2a0170;
    data |= 0x2000000;
    cpu_write(0x1c024004, data);
    lprintf(5, "GPIO_SWPORTA_DDR : 0x%x\n\r ",cpu_read(0x1c024004)) ;  //as GPIO  0x1f2a0170;

    data=cpu_read(0x1c024008);
    lprintf(5, "GPIO_PORTA_CTL_HW/SW : 0x%x \n\r ",data) ;  //as GPIO  0x1f2a0170;
 //   data |= 0x1;
 //   cpu_write(0x1c024008, data);

    // GPIO_SWPORTA_DR  TURN TO ZERO
      data=cpu_read(0x1c024000);
      lprintf(5, "GPIO_SWPORTA_DR : 0x%x \n\r ",data) ;  //as GPIO  0x1f2a0170;
      data &= ~0x2000000;
      cpu_write(0x1c024000, data);

      MSDELAY(10);


    // GPIO_SWPORTA_DDR
     data=cpu_read(0x1c024000);
     lprintf(5, "GPIO_SWPORTA_DR : 0x%x \n\r ",data) ;  //as GPIO  0x1f2a0170;
     data |= 0x2000000;
     cpu_write(0x1c024000, data);
     lprintf(5, "GPIO_SWPORTA_DR : 0x%x \n\r ",cpu_read(0x1c024000)) ;  //as GPIO  0x1f2a0170;

#endif

    lprintf(5,"PCIe slot reset done, argu=0/2/none for slot 0/2/0+2\n");
}

void prep_diag_mode(uint32_t pcie_core_id,uint32_t len)
{

  uint32_t data=0;

  lprintf(5,"ENABLING DIAG MODE MEASUREMENT  \n\r");

   data= pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR));
   data = 0x00000000;
   pcie_csr_write(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR),data); // Disable any running calculation

   data= pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_BW_MSTR_STOP_CNT__ADDR)); // Configure length
   data = ( (   (len/1024) << 16  ) | (len/1024) )  ; // Same Len for READ & WRITE

   pcie_csr_write(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_BW_MSTR_STOP_CNT__ADDR),data) ; // Configure RD length

 /* data= pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_BW_SLV_STOP_CNT__ADDR)); // Configure length
  data =0x2000200; // 512k RD

  pcie_csr_write(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_BW_SLV_STOP_CNT__ADDR),data) ; // Configure RD length
*/
   data= pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_BW_MSTR_STOP_CNT__ADDR)); // Configure length
   lprintf(5,"Total SIZE configured : = 0x%x \n\r",data);

   data=0x000000f;
   pcie_csr_write(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR),data) ; // Start

  lprintf(5, "CFG START_STOP_STATUS := 0x%x \n\r",
     	    pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR)));

  lprintf(5, "Clock Count  := 0x%x \n\r",
  pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_STS_AXI_MRD_BW_CLK_CNT__ADDR)));

  lprintf(5, "Byte Count := 0x%x \n\r",
  pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_STS_AXI_MRD_BW_BYTE_CNT__ADDR)));

}

extern uint32_t perf_number[100];

void print_M_AXI_WR_RD(uint32_t pcie_core_id,uint32_t mode)
{

  uint32_t data=0,data_rd=0,data_wr=0,
		   rd_bw=0,rd_time=0,
		   wr_bw=0,wr_time=0;

static uint32_t cnt =0;

if(cnt==100)
cnt=0;

// To know AXI CLOCK Freq.,

  lprintf(5,"SCU_SOCIOBAXIDIV = 0x%x \n\r", cpu_read(0x17000150));
  lprintf(5,"SCU_SOCAXIDIV = 0x%x \n\r", cpu_read(0x17000160));

  if(mode==RD)
  {
	  // to know how many bytes were observed
    data_rd=pcie_csr_read( pcie_core_id, (SM_GLBL_DIAG_CSR_STS_AXI_MRD_BW_BYTE_CNT__ADDR) );
    rd_time=pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_STS_AXI_MRD_BW_CLK_CNT__ADDR))<<2; //*4 to get ns

    lprintf(5," ******************************************************** \n\r") ;
    lprintf(5," *** Total AXI Read BW  (AXI to PCIE OB-WRITE)  ***      \n\r");
    lprintf(5," ******************************************************** \n\r") ;
    lprintf(5,"\n\r");

    lprintf(5,"Total Bytes Read from AXI:  0x%lx \n\r", data_rd);
    lprintf(5,"Total READ time: %d ns (%d AXI cycles)\n\r", rd_time, rd_time>>2);

    rd_bw = (SEC_2_NS_CONST/rd_time) * (data_rd >>10) ;   //KB/s
    rd_bw=( 8 * rd_bw ) >> 10;             // Mb/s


#ifdef CONFIG_ARCH_TIMER
 //   data_rd
 //   rd_time
 //   rd_bw
#endif


  //  lprintf(5," * Total Read-time: %d ns (%d AXI cycles) \n\r * For Reading Bytes : 0x%lx = \n\r", rd_bw>>2,rd_bw,data_rd);
    lprintf(3,"Total Data Throughput OB-WRITE: %d Mb/s = %d MB/s\n\n", rd_bw, rd_bw>>3);

    RD_BW_g=rd_bw;

    cnt++;
    perf_number[cnt]=rd_bw;

    pcie_csr_write(pcie_core_id,SM_GLBL_DIAG_CSR_STS_AXI_MRD_BW_CLK_CNT__ADDR,0);
    pcie_csr_write(pcie_core_id,SM_GLBL_DIAG_CSR_STS_AXI_MRD_BW_BYTE_CNT__ADDR,0);

    lprintf(5," *********************************************** \n\r");

  }

  // Calculation Part in terms of MB/s for write
  else
  {
    data_wr=pcie_csr_read( pcie_core_id, (SM_GLBL_DIAG_CSR_STS_AXI_MWR_BW_BYTE_CNT__ADDR) );
    wr_time=pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_STS_AXI_MWR_BW_CLK_CNT__ADDR)) <<2 ; //*4 to get ns

    lprintf(5," ******************************************************** \n\r") ;
    lprintf(5," *** Total AXI Write BW  (PCIE to AXI OB-READ)  ***       \n\r");
    lprintf(5," ******************************************************** \n\r") ;
    lprintf(5,"\n\r");


   lprintf(5,"Total Bytes Written to AXI = 0x%lx \n\r",
 		  pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_STS_AXI_MWR_BW_BYTE_CNT__ADDR)));

    lprintf(5,"Total AXI Cycles used to Write= 0x%lx\n\r",
   		  pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_STS_AXI_MWR_BW_CLK_CNT__ADDR)));


   lprintf(5,"Total Bytes WRITE from AXI: %d\n\r", data_wr);
   lprintf(5,"Total WRITE time: %d ns (%d AXI cycles)\n", wr_time, wr_time>>2);

    wr_bw = (SEC_2_NS_CONST/wr_time) * (data_wr >>10) ;   //KB/s
    wr_bw= (8 * wr_bw) >> 10;             // Mb/s
    lprintf(3,"Total Data Throughput: OB-READ %d Mb/s = %d MB/s \n\r", wr_bw, wr_bw>>3);


#ifdef CONFIG_ARCH_TIMER

#endif


    WR_BW_g=wr_bw;

    cnt++;
    perf_number[cnt]=wr_bw;

    pcie_csr_write(pcie_core_id,SM_GLBL_DIAG_CSR_STS_AXI_MWR_BW_CLK_CNT__ADDR,0);
    pcie_csr_write(pcie_core_id,SM_GLBL_DIAG_CSR_STS_AXI_MWR_BW_BYTE_CNT__ADDR,0);
    lprintf(5," *********************************************** \n\r");
  }
}

void print_S_AXI_WR_RD(uint32_t pcie_core_id,uint32_t mode)
{
	// to know how many bytes were observed
	lprintf(5,"SLAVE AXI \n\r");
    lprintf(5,"Total Bytes Writeen to AXI = %d \n\r",
			  pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_STS_AXI_SWR_BW_BYTE_CNT__ADDR)));
    lprintf(5,"Total AXI Cycles used to Write= %d \n\r",
	  		  pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_STS_AXI_SWR_BW_CLK_CNT__ADDR)));
    lprintf(5,"Total Bytes READ from AXI = %d\n\r",
			  pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_STS_AXI_SRD_BW_BYTE_CNT__ADDR)));
    lprintf(5,"Total AXI Cycles used to READ = %d \n\r",
	  		  pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_STS_AXI_SRD_BW_CLK_CNT__ADDR)));
}

//support x8 mode slot 0/2 only
//Tinh-SLT
//int linkup(int argc, char *argv[]) {
int linkup_pcie(int argc, char *argv[]) {
  uint32_t gen, port0rc = 0;
  uint32_t i = 0, status;

  if (argc < 1) i = 1;
  gen = atoi(argv[0]);
  if (gen>2) i = 2;
  if (argc > 1) {
    port0rc = atoi(argv[1]);
    if (port0rc !=0) 
        port0rc = 1;
  }
  if (i) {
    lprintf(3,"not enough argument: gen [reverse] \n\r");
    return i;
  } 
  sm_pcie_init(0, port0rc, 0, gen, 1, 8, 0);
  sm_pcie_init(3, (port0rc?0:1), 0, gen, 1, 8, 0);
  status = 400;
  i = ltssm_sub(0, &status); 
  return i;
}

int gpio_uart(int argc, char *argv[]){
  uint32_t i = 0, data, gpio;
  if (argc < 2) {
    lprintf(3,"not enough argument: gpio#, wrdata \n\r");
    return i;
  } 

  gpio = atoi(argv[0]);
  i = atoi(argv[1]) ? 1: 0;

  lprintf(5,"GPIO # %d, value %d \n\r", gpio, i);
  
  data = cpu_read(0x1f2ac008);
  data |= 0x4;   //enable gpio clk
  cpu_write(0x1f2ac008, data);

  data = cpu_read(0x1f2ac000);
  data = data & ~0x4;   //clear gpio rst
  cpu_write(0x1f2ac000, data);

  data = cpu_read(0x1c024000);
  if(i)
    data = data | (1<<gpio);   //write GPIO value 
  else
    data = data & ~(1<<gpio);
  cpu_write(0x1c024000, data);
  
  if(gpio<=7) {
    data = cpu_read(0x1f2a0168);
    data |= 3<<(gpio*2);              //cfg pin mux select for gpio 0 ~ 7
    cpu_write(0x1f2a0168, data);
  } else if (gpio >7 && gpio <= 23) {
    data = cpu_read(0x1f2a016c);
    data |= 3<<((gpio-8)*2);         //cfg pin mux select for gpio 8 ~ 23
    cpu_write(0x1f2a016c, data);
  } else {
    data = cpu_read(0x1f2a0170);
    data |= 3<<((gpio-24)*2);         //cfg pin mux select for gpio 24 ~ 31
    cpu_write(0x1f2a0170, data);
  }

  data = cpu_read(0x1c024004);
  data |= 1<<gpio;              //set GPIO direction
  cpu_write(0x1c024004, data);

}

void set_tx_prbs(int pcie_core_id, int prbs_num){
int sds2_offset, ch, data, prbs;

lprintf(5,"enable TX PRBS,  core # 0x%x, prbs# %d \n\r", pcie_core_id, prbs_num);
switch (prbs_num){
case (7): prbs = 0; break;
case (9): prbs = 1; break;
case (11): prbs = 2; break;
case (23): prbs = 3; break;
case (31): prbs = 4; break;
default: prbs = 4; break;
}

if(pcie_core_id == 0 || pcie_core_id == 1 ||
   pcie_core_id == 3 || pcie_core_id == 4){  
  
  sds2_offset = 0;
  for(ch = 0; ch<4; ch++){
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG2_BIST_ENA_TX_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset, data);
  
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG4_TX_PRBS_SEL_SET(data, prbs);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR + (0x200 * ch) + sds2_offset, data);
  
  //reset TX digital logic
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG2_RESETB_TXD_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset, data);
  MSDELAY(10);
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG2_RESETB_TXD_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset, data);
  }
  
  if(pcie_core_id == 0 || pcie_core_id == 3){
      sds2_offset = 0x30000;
      for(ch = 0; ch<4; ch++){
      data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset);
      data = FIELD_CH0_RXTX_REG2_BIST_ENA_TX_SET(data, 0x1);
      pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset, data);
      
      data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR + (0x200 * ch) + sds2_offset);
      data = FIELD_CH0_RXTX_REG4_TX_PRBS_SEL_SET(data, prbs);
      pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR + (0x200 * ch) + sds2_offset, data);
      
      //reset TX digital logic
      data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset);
      data = FIELD_CH0_RXTX_REG2_RESETB_TXD_SET(data, 0x0);
      pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset, data);
      MSDELAY(10);
      data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset);
      data = FIELD_CH0_RXTX_REG2_RESETB_TXD_SET(data, 0x1);
      pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset, data);
      }
  }
} else if (pcie_core_id == 2) {
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR);
  data = FIELD_CH0_RXTX_REG2_BIST_ENA_TX_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR, data);
  
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR);
  data = FIELD_CH0_RXTX_REG4_TX_PRBS_SEL_SET(data, prbs);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR, data);
      
  //reset TX digital logic
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG2_RESETB_TXD_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset, data);
  MSDELAY(10);
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG2_RESETB_TXD_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset, data);
  }
}


void set_rx_prbs(int pcie_core_id, int prbs_num){
int sds2_offset, ch, data, prbs;

lprintf(5,"enable RX PRBS check, core # 0x%x, prbs# %d \n\r", pcie_core_id, prbs_num);
switch (prbs_num){
case (7): prbs = 0; break;
case (9): prbs = 1; break;
case (11): prbs = 2; break;
case (23): prbs = 3; break;
case (31): prbs = 4; break;
default: prbs = 4; break;
}

if(pcie_core_id == 0 || pcie_core_id == 3){  
  sds2_offset = 0;
  for(ch = 0; ch<4; ch++){
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG7_BIST_ENA_RX_SET(data, 0x1);
  data = FIELD_CH0_RXTX_REG7_RX_PRBS_SEL_SET(data, prbs);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset, data);
  }
  sds2_offset = 0x30000;
  for(ch = 0; ch<4; ch++){
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG7_BIST_ENA_RX_SET(data, 0x1);
  data = FIELD_CH0_RXTX_REG7_RX_PRBS_SEL_SET(data, prbs);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset, data);
  }
} else if (pcie_core_id == 2) {
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR);
  data = FIELD_CH0_RXTX_REG7_BIST_ENA_RX_SET(data, 0x1);
  data = FIELD_CH0_RXTX_REG7_RX_PRBS_SEL_SET(data, prbs);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR, data);
} else if (pcie_core_id == 1 || pcie_core_id == 4) {
  sds2_offset = 0;
  for(ch = 0; ch<4; ch++){
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG7_BIST_ENA_RX_SET(data, 0x1);
  data = FIELD_CH0_RXTX_REG7_RX_PRBS_SEL_SET(data, prbs);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset, data);
  }
}

}

void sm_pcie_hack_for_kc(uint32_t pcie_core_id) {
  uint32_t data;

  lprintf(5,"Bypassing the receiver detection and disabling L2 power mgmt, due to bug in KC testchip.\n\r");
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR));
  data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352_CFG_CONSTANTS_BYPASS_RECEIVER_DETECTION_MASK;
  data = data & ~FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352_CFG_CONSTANTS_ENABLE_L2_POWER_MGMT_MASK;
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR), data);
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR));
}  

void sm_pcie_hack_for_sim(uint32_t pcie_core_id, uint32_t gen) {
  uint32_t data;

  lprintf(5,"Enabling the reduced timeout and reduced TS1 for simulation\n\r");
  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR);
  data |= FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352_CFG_CONSTANTS_QUICK_SIMULATION_REDUCE_TIMEOUTS_MASK;
  data |= FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352_CFG_CONSTANTS_QUICK_SIMULATION_REDUCE_TS1_MASK;
  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR, data);
  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR);

  lprintf(5,"Reducing the EQ_TS1_ACK_DELAY\n\r");
  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_63_32__ADDR);
  data = data & ~FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_63_32_CFG_8G_CONSTANTS_EQ_TS1_ACK_DELAY_MASK;
  data |= 0x100;

  if(gen == 2)
    data |= 0x3F00;

  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_63_32__ADDR, data);
  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_63_32__ADDR);
}

void pcie_reset_mellanox (uint32_t pcie_core_id) {

	uint32_t data;
	data = cpu_read(0x17001294);  //as GPIO
    data &= ~(0x0f<<24);
    cpu_write(0x17001294, data);

    data = cpu_read(0x1700129c);  //as outputs
    data |= 3 <<12;
    cpu_write(0x1700129c, data);

	if (pcie_core_id == 0 || pcie_core_id == 1) {
		data = cpu_read(0x170012a0);
		cpu_write(0x170012a0, data & ~(1<<12));      // Put Card in Reset
		MSDELAY(1);
	    data = cpu_read(0x170012a0);
		data |= (1<<12);
		cpu_write(0x170012a0, data);                                  // Release Reset here
	} else if(pcie_core_id == 3 || pcie_core_id == 4) {
		data = cpu_read(0x170012a0);
		cpu_write(0x170012a0, data & ~(1<<13));      // Put Card in Reset
		MSDELAY(1);
	    data = cpu_read(0x170012a0);
		data |= (1<<13);
		cpu_write(0x170012a0, data);                                  // Release Reset here
	}	
}  
