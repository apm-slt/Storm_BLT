//Tinh-SLT
#include "../include/pcie_dma_test.h"
//End of Tinh-SLT
#include "armv8.h"
// This function writes the DMA elements into the memory.
#ifdef DMA_INT_ENABLE

//Tinh-SLT
#include "../include/pcie_isr.h"
//End of Tinh-SLT
volatile unsigned int g_Int_Status=0;
#endif


#define AXI_DESC_COHERENCY      (1)  // Descriptor coherent settings
#define COHERENCY_ON            (8)  // Coherency to DMA_CTRL status
#define INT 1
volatile u64 stime=0, etime=0;

void write_dma_element(uint64_t addr, uint32_t axi, uint64_t element, uint32_t size, uint32_t eop)
{
  uint32_t data;
  uint32_t flags;
  uint64_t element_int;
  
  element_int = element;
  if(eop)
  {
	  lprintf(5," Element with EOP written :\n\r");
  }
  data = ((uint32_t) addr); // lower 32-bits of address
  cpu_write(element_int, data);
  element_int = element_int + 4;

  data = (uint32_t) (addr>>32); // higher 32-bits of address
  cpu_write(element_int, data);
  element_int = element_int + 4;

/*
axi: FLag communicates what is role of AXI
1: When 1 set coherent settings. else leave non-zero.
*/
  if(axi)     // AXI bit is set only to indicate role of AXI, in case of : OB-WR this is called with AXI set as SRC and in OB-RD when destination descriptors written. 
    flags = ( AXI_DESC_COHERENCY << 5)| axi; // bit 0 for flag conveys the location of the data, while bit 1 for flag conveys the eop.

#ifdef DMA_INT_ENABLE
  flags |= ((uint32_t) (INT << 2));
#endif
 flags |= eop << 1 ;
  
  data = size; // set up the src element size
  data = data | ((uint32_t) (flags << 24)); 
  cpu_write(element_int, data);
  element_int = element_int + 4;
  element_int = element_int + 4; // Bits 127:96 are reserved.
}  

// This function generates the random length elements. However, it also takes care that, the total number of elements are >= 2
// and the combined length specified by all the elements is not more than the length of the data transfer requested.
uint32_t setup_dma_elements(uint64_t addr_base, uint32_t axi, uint64_t element_base, uint32_t length) {
  uint64_t element;
  uint64_t addr;
  uint32_t i, size, eop, num_elements,total_des_req=0;

  lprintf(5,"Setting up the DMA elements for "); putnum_pcie(length); lprintf(5," bytes.\n\r");
  i = 0;
  addr = addr_base;
  element = element_base;
  num_elements = 0;
  while(i < length) {
#ifndef MORE_DESCRIPTORS
	  size = length/4;
    if (length==1024)
      size = 512;

#else
	  total_des_req = length/MAX_DESC_SIZE;
	  size = length/total_des_req;
#endif

    if(size == 0)
      size = length - i;

    eop = (i + size >= length);

    if(eop && ((num_elements + 1) == 1))
      continue;

    i = i + size;
    num_elements++;
    write_dma_element(addr, axi, element, size, eop);
    addr = addr + size;
    element = element + 16;
  }
  
  dcache_flush_all();
  return num_elements;
} 

// This function generates elements and also generates parameters for setting up the registers for the DMA access.
void setup_src_dst_elements(uint64_t addr, uint32_t axi, uint64_t element_ptr, uint32_t length, uint64_t q_param_loc) {
  uint32_t num_elements;
  uint32_t data;

  num_elements = setup_dma_elements(addr, axi, element_ptr, length);

  lprintf(5,"Initializing the q parameters : SIZE = %d \n\r",(num_elements+1));
  cpu_write(q_param_loc, num_elements+1);
  lprintf(5,"Initializing the q parameters : LIMIT = %d \n\r",num_elements);
  cpu_write(q_param_loc+4, num_elements);

}  

// Initialize the descriptors at src and dst memory
void init_dma_src_dst_elements(uint32_t pcie_core_id, uint64_t addr, uint64_t addr2, uint32_t axi, uint32_t axi2, uint32_t src_dst, uint32_t length) {
  uint64_t element_ptr;
  uint64_t q_param_loc;
  uint64_t PCIE_PIM2, PCIE_PIM3;

  PCIE_PIM2 = ret_pim2_base(pcie_core_id);
  PCIE_PIM3 = ret_pim3_base(pcie_core_id);
  
  lprintf(5,"Initializing the DMA elements for "); putnum_pcie(length); lprintf(5," bytes\n\r");

 // if(addr != 0)
 {
    if(src_dst == SRC) {
      // setup the source elements
      q_param_loc = PCIE_PIM2+DMA_SRC_Q_PTR;
      element_ptr = PCIE_PIM3+DMA_SRC_ELE;
      lprintf(5,"Initializing the source q_param_loc=0x%lx, element_ptr=0x%lx\n\r", q_param_loc, element_ptr);
    }
    else {
      // setup the destinition elements
      q_param_loc = PCIE_PIM2+DMA_DST_Q_PTR;
      element_ptr = PCIE_PIM3+DMA_DST_ELE;
      lprintf(5,"Initializing the destination q_param_loc=0x%lx, element_ptr=0x%lx\n\r", q_param_loc, element_ptr);
    }

    setup_src_dst_elements(addr, axi, element_ptr, length, q_param_loc);
  }

  if(addr2 != 0) {
    if(src_dst == SRC) {
      q_param_loc = PCIE_PIM2+DMA_SRC2_Q_PTR;
      element_ptr = PCIE_PIM3+DMA_SRC2_ELE;
      lprintf(5,"Initializing the source2 q_param_loc=0x%lx, element_ptr=0x%lx\n\r", q_param_loc, element_ptr);
    }
    else {
      q_param_loc = PCIE_PIM2+DMA_DST2_Q_PTR;
      element_ptr = PCIE_PIM3+DMA_DST2_ELE;
      lprintf(5,"Initializing the destination2 q_param_loc=0x%lx, element_ptr=0x%lx\n\r", q_param_loc, element_ptr);
    }

    setup_src_dst_elements(addr2, axi2, element_ptr, length, q_param_loc);
  }
}

// Initialize the descriptors at status memory
void init_dma_sta_elements(uint32_t pcie_core_id, uint32_t mult_ch, uint32_t length) {
  uint64_t element_ptr, i;
  uint32_t data;
  uint64_t PCIE_PIM2;

  PCIE_PIM2 = ret_pim2_base(pcie_core_id);
  
  // setup the status element
  lprintf(5,"Initializing the status elements\n\r");
  element_ptr = PCIE_PIM2+DMA_STA;
  for (i=0; i<length; i++) {
    cpu_write(element_ptr, 0);
    element_ptr += 4;
  }

  if(mult_ch) {
    lprintf(5,"Initializing the status elements for second channel\n\r");
    element_ptr = PCIE_PIM2+DMA_STA2;
    for (i=0; i<length; i++) {
      cpu_write(element_ptr, 0);
      element_ptr += 4;
    }
  }
}

// Setup the dma
uint32_t ch_on[4]={0,0,0,0};

void sm_pcie_setup_dma(uint32_t pcie_core_id, uint32_t src_axi, uint32_t dst_axi, uint32_t mult_ch, uint32_t intlv){
  uint32_t ch_no=0,Turn_DMA_ON_Mult_Ch=0;
  uint32_t data;
  uint32_t i = 0;
  uint32_t src_addrlo, src_addrhi, src_size, src_limit;
  uint32_t dst_addrlo, dst_addrhi, dst_size, dst_limit;
  uint32_t sta_addrlo, sta_addrhi, sta_size, sta_limit;
  uint64_t q_ptr;
  uint64_t PCIE_PIM2, PCIE_PIM3, PCIE_PIM2_PA;

  PCIE_PIM2 = ret_pim2_base(pcie_core_id);
  PCIE_PIM2_PA = ret_pim2_base_pa(pcie_core_id);
  PCIE_PIM3 = ret_pim3_base_pa(pcie_core_id);  

//  if(!mult_ch) Turn_DMA_ON_Mult_Ch=1;

  for(i = 0; i <= mult_ch; i++){
    if (i==0) 
      ch_no = (uint32_t)RANDOM() % NUM_DMA_CH;
    else 
      ch_no = (ch_no+1) % 4;
#ifdef NO_RANDOM_CH  
  ch_no=0;
#endif
    lprintf(5,"Setting up the DMA for channel "); putnum_pcie(ch_no); lprintf(5,".\n\r");

    if(i){
      q_ptr = PCIE_PIM2+DMA_SRC2_Q_PTR;
      src_addrlo = (uint32_t) (PCIE_PIM3+DMA_SRC2_ELE) | 0x1;
      src_addrhi = (PCIE_PIM3+DMA_SRC2_ELE) >> 32;
    }
    else{
      q_ptr = PCIE_PIM2+DMA_SRC_Q_PTR;
      src_addrlo = (uint32_t) (PCIE_PIM3+DMA_SRC_ELE) | 0x1;
      src_addrhi = (PCIE_PIM3+DMA_SRC_ELE) >> 32;
    }

    lprintf(5,"Reading the SRC Q parameters first.\n\r");
    src_size   = cpu_read(q_ptr);
    src_limit  = cpu_read(q_ptr+4);

    if(i){
      q_ptr = PCIE_PIM2+DMA_DST2_Q_PTR;
      dst_addrlo = (uint32_t) (PCIE_PIM3+DMA_DST2_ELE) | 0x1;
      dst_addrhi = (PCIE_PIM3+DMA_DST2_ELE) >> 32;
    }
    else{
      q_ptr = PCIE_PIM2+DMA_DST_Q_PTR;
      dst_addrlo = (uint32_t) (PCIE_PIM3+DMA_DST_ELE) | 0x1;
      dst_addrhi = (PCIE_PIM3+DMA_DST_ELE) >> 32;
    }

    lprintf(5,"Reading the DST Q parameters next.\n\r");
    dst_size   = cpu_read(q_ptr);
    dst_limit  = cpu_read(q_ptr+4);

#ifdef PCIE_EXERCISER
    dst_size    = cpu_read(q_ptr);
    dst_limit  =  cpu_read(q_ptr+4);

    dst_addrlo = (uint32_t) (PCIE_PIM3+DMA_DST_ELE) | 0x1;
    dst_addrhi = (PCIE_PIM3+DMA_DST_ELE) >> 32;

    lprintf(5," Destination address _L0 @ : 0x%x => 0x%x \n\r",(PCIE_PIM3+DMA_DST_ELE),dst_addrlo);
    lprintf(5," Destination address _Hi @ : 0x%x => 0x%x \n\r",(PCIE_PIM3+DMA_DST_ELE),dst_addrhi);

#endif

    switch(i) {
      case 0: sta_addrlo = (uint32_t) (PCIE_PIM2_PA+DMA_STA) | 0x1; // Status elements always reside in AXI memory.
              sta_addrhi = (uint32_t) ((PCIE_PIM2_PA+DMA_STA) >> 32);
              break;

      case 1: sta_addrlo = (uint32_t) (PCIE_PIM2_PA+DMA_STA2) | 0x1; // Status elements always reside in AXI memory.
              sta_addrhi = (uint32_t) ((PCIE_PIM2_PA+DMA_STA2) >> 32);
              break;        
    }

    dst_addrlo |= COHERENCY_ON;  
    sta_addrlo |= COHERENCY_ON;
    src_addrlo |= COHERENCY_ON;
    
    sta_size = 2;
    sta_limit = 1;

    lprintf(5,"Setting the src address q\n\r");
    pcie_ob_cfg_write(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_SRC_Q_PTR_LO__ADDR | (ch_no * 0x40), src_addrlo);
    pcie_ob_cfg_write(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_SRC_Q_PTR_HI__ADDR | (ch_no * 0x40), src_addrhi);

    lprintf(5,"Setting the src size and limit registers\n\r");
    pcie_ob_cfg_write(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_SRC_Q_SIZE__ADDR | (ch_no * 0x40), src_size);
    pcie_ob_cfg_write(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_SRC_Q_LIMIT__ADDR | (ch_no * 0x40), src_limit);

    lprintf(5,"Setting the dst address q\n\r");
    pcie_ob_cfg_write(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DST_Q_PTR_LO__ADDR | (ch_no * 0x40), dst_addrlo);
    pcie_ob_cfg_write(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DST_Q_PTR_HI__ADDR | (ch_no * 0x40), dst_addrhi);

    lprintf(5,"Setting the dst size and limit registers\n\r");
    pcie_ob_cfg_write(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DST_Q_SIZE__ADDR | (ch_no * 0x40), dst_size);
    pcie_ob_cfg_write(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DST_Q_LIMIT__ADDR | (ch_no * 0x40), dst_limit);

    lprintf(5,"Setting the status address q\n\r");
    pcie_ob_cfg_write(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_STA_Q_PTR_LO__ADDR | (ch_no * 0x40), sta_addrlo);
    pcie_ob_cfg_write(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_STA_Q_PTR_HI__ADDR | (ch_no * 0x40), sta_addrhi);

    lprintf(5,"Setting the status size and limit registers\n\r");
    pcie_ob_cfg_write(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_STA_Q_SIZE__ADDR | (ch_no * 0x40), sta_size);
    pcie_ob_cfg_write(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_STA_Q_LIMIT__ADDR | (ch_no * 0x40), sta_limit);
 
    lprintf(5,"Setting the src, dst and status q next address to 0\n\r");
    data = 0;
    pcie_ob_cfg_write(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_SRC_Q_NEXT__ADDR | (ch_no * 0x40), data);
    pcie_ob_cfg_write(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DST_Q_NEXT__ADDR | (ch_no * 0x40), data);
    pcie_ob_cfg_write(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_STA_Q_NEXT__ADDR | (ch_no * 0x40), data);

#ifdef DMA_INT_ENABLE

#ifdef BUG_37105
    data=pcie_csr_read(pcie_core_id,SM_SLAVE_SHIM_CSR_CFG_AMA_MODE__ADDR);
    data=FIELD_CFG_AMA_MODE_CFG_RD2WR_EN_WR(1);
    pcie_csr_write( pcie_core_id, SM_SLAVE_SHIM_CSR_CFG_AMA_MODE__ADDR , data );

    lprintf(5," AMA CONFIGURATION : 0x%x\n\r",
    		 pcie_csr_read(pcie_core_id,SM_SLAVE_SHIM_CSR_CFG_AMA_MODE__ADDR));
#endif


    data = pcie_ob_cfg_read(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (ch_no * 0x40));
//    data = data | 0x000000;   //  Enable DMA and INT to AXI : Turn 16th to 1 only for PCIE INTx Interrupt
    data = data | 0x1000000;
    pcie_ob_cfg_write(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (ch_no * 0x40), data);

    en_event_int(pcie_core_id);
 /*
  // Vv: This needs to check with DV team since, it genrates INTx but fails to clear
  // and DMA always shows running status, after completion 
    data = pcie_ob_cfg_read(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (ch_no * 0x40));
    data = data | 0x0010000;   //  Enable DMA and INT to AXI : Turn 16th to 1 only for PCIE INTx Interrupt
    pcie_ob_cfg_write(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (ch_no * 0x40), data);
    en_intx_int(pcie_core_id);
 */
#endif

#ifndef PERF_2_PORTS

#ifdef CONFIG_ARCH_TIMER
	__asm__ volatile ("mrs %0, cntpct_el0": "=r"(stime));
#endif
if(mult_ch)
{
     if( Turn_DMA_ON_Mult_Ch )
     {
        lprintf(5,"Finally, enabling the dma channel"); putnum_pcie(ch_no); lprintf(5,"\n\r");
        data = pcie_ob_cfg_read(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (ch_no * 0x40));
        data = data | 0x1;
        pcie_ob_cfg_write(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (ch_no * 0x40), data);

        lprintf(5,"Finally, enabling the dma channel"); putnum_pcie(ch_on[0]); lprintf(5,"\n\r");
        data = pcie_ob_cfg_read(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (ch_on[0] * 0x40));
        data = data | 0x1;
        pcie_ob_cfg_write(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (ch_on[0] * 0x40), data);

        ch_on[1]=ch_no;
     }
     else
     {
       ch_on[0]=ch_no;
       Turn_DMA_ON_Mult_Ch=1;
     }
}
else
{
  lprintf(5,"Finally, enabling the dma channel"); putnum_pcie(ch_no); lprintf(5,"\n\r");

  data = pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_PCIE_RX__ADDR);
//  data = 0xff;
  pcie_csr_write(pcie_core_id,NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_PCIE_RX__ADDR,data);
  lprintf(5," PCIE_CFG_CFG_RX_DATA : 0x%x \n\r",pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_PCIE_RX__ADDR));
  data = pcie_ob_cfg_read(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (ch_no * 0x40));
  data = data & 0xFFFFFFFE;
  pcie_ob_cfg_write(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (ch_no * 0x40), data);
  
  data = pcie_ob_cfg_read(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (ch_no * 0x40));
  data = data | 0x1;
  pcie_ob_cfg_write(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (ch_no * 0x40), data);
}
#endif

  }
};  

// Poll the status memory for the completion
uint32_t poll_dma_cmpl(uint32_t pcie_core_id, uint32_t mult_ch){
  uint32_t data;
  uint32_t i, j, k;
  uint64_t sta_addr;
  uint32_t sta_size;
  uint32_t err;
  uint32_t fail = 0;
  uint64_t PCIE_PIM2;

  PCIE_PIM2 = ret_pim2_base(pcie_core_id);  
  sta_size = 2;

  for(i = 0; i <= mult_ch; i++){
    err = 0;

    switch(i) {
      case 0: sta_addr = PCIE_PIM2+DMA_STA;
              break;

      case 1: sta_addr = PCIE_PIM2+DMA_STA2;
              break;        
    };

    for(j = 0; j < (sta_size - 1); j++) {
      lprintf(5,"Waiting for DMA ch%1d status at addr 0x%lx: ", i, sta_addr);
      k = 2000000;
      do {
        data = cpu_read(sta_addr);
#ifdef SIMULATION
        sm_host_delay_ns(1000);
#endif
      } while((data == 0)&&(--k));

      if (data == 1) 
        lprintf(5,"0x%x PASS!\n", data); 
      else {
        lprintf(5,"0x%x FAIL!\n", data); 
        err++;
      }
      sta_addr = sta_addr + 4;
    }

    if(err) 
      fail = 1;
    else 
    lprintf(5,"There was no error at least in the dma operation. Lets check destinition memory for the data integrity\n\r");
  }

  return fail;
};

uint32_t ch_on[4];
uint32_t isr_cnt=0;

extern uint32_t rx_err, bad_tlp_err, bad_dllp_err, replay_to;
extern uint32_t rx_err_ep, bad_tlp_err_ep, bad_dllp_err_ep, replay_to_ep;
extern uint32_t corr_err;
extern uint32_t odd_cnd;
extern uint32_t bad_lnk_cnt;
extern uint32_t loop_cnt;
static volatile uint32_t rcv_err=0;
  
#ifdef DMA_INT_ENABLE
uint32_t evt_dma_cmpl (uint32_t pcie_core_id, uint32_t mult_ch){
  volatile uint32_t data,ch=0,phy_err=0;
  uint32_t data_ep=0,phy_err_ep=0;
  uint32_t i, j, k;
  uint64_t sta_addr;
  uint32_t sta_size;
  uint32_t err;
  uint32_t fail = 0;
  uint64_t PCIE_PIM2;
  volatile int timeout=100;
  uint32_t tick_time=0,tick_bw=0;

 for(i = 0; i <= 1; i++)
 {

  do{
     ch=ch_on[i];
     loop_cnt+=1;
     // timeout--; 
    //data = pcie_ob_cfg_read(0,NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (ch * 0x40));
	// lprintf(5,"Int_G-VAR = %d\n\r",g_Int_Status);

   if(0xFFFFFFFF == pcie_ob_cfg_read(0,SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR)) 
   {
     bad_lnk_cnt+=1;
     printf("0x%x \n\r",pcie_ob_cfg_read(0,SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR));

   }
   data=0;
	data = pcie_ob_cfg_read(0, 0x110); //read correctable error status register
//    printf("\nRC Corr err data=0x%x",data);
	data_ep = pcie_ob_cfg_read(0, 0x10110); //read correctable error status register
//    printf("\nEP Corr err data=0x%x",data);
	phy_err = data ; //bit 0 is receiver error
	phy_err_ep = data_ep ; //bit 0 is receiver error
    if (pcie_ob_cfg_read(0, 0x110))
	{
	 if(pcie_ob_cfg_read(0, 0x110) & 0x1)  {rx_err++;}
	 if((pcie_ob_cfg_read(0, 0x110) & 0x40)>>6)  bad_tlp_err++;
	 if((pcie_ob_cfg_read(0, 0x110) & 0x80)>>7)  bad_dllp_err++;
	 if((pcie_ob_cfg_read(0, 0x110) & 0x1000)>>12)  replay_to++;
	 corr_err += 1;
     phy_err=0;
	 pcie_ob_cfg_write(0,0x110, 0xFFFFFFFF);  //clear correctable error
     if(pcie_ob_cfg_read(0, 0x110) & 0x1 )
	 {
	  odd_cnd++; 
	  //break; 
	 }
	}
    if (phy_err_ep) {
	 if(phy_err_ep & 0x1)  rx_err_ep++;
	 if((phy_err_ep & 0x40)>>6)  bad_tlp_err_ep++;
	 if((phy_err_ep & 0x80)>>7)  bad_dllp_err_ep++;
	 if((phy_err_ep & 0x1000)>>12)  replay_to_ep++;
	 pcie_ob_cfg_write(0,0x10110, 0xFFFFFFFF);  //clear correctable error
     phy_err_ep=0;
    }
    }while((!WAIT_DMA_INT(pcie_core_id))&& (timeout)  ) ;
   //  g_Int_Status=0;
	timeout=100;
   
 }

#if 0
 if(mult_ch)
 {
	while(isr_cnt!=2);
#ifdef CONFIG_ARCH_TIMER
__asm__ volatile ("mrs %0, cntpct_el0": "=r"(etime));
#endif
 }
   isr_cnt=0;
#if 0
   lprintf(5,"--------------------------------------------------------\n");
   lprintf(5,"End Time(in timer ticks) : 0x%X\n", etime);
   lprintf(5,"Execution Time(in timer ticks) : approx. 0x%X\n", etime-stime);
   lprintf(5,"***Execution Time includes printing(start-time,2 dashed lines)\n");

    tick_time = (etime-stime) * 20 ;    // Timer Resolution is 20ns
    tick_bw = (1000000000/tick_time) * (TEST_LEN >>10) ;   //KB/s
    tick_bw=( 8 * tick_bw ) >> 10;             // Mb/s

    lprintf(5,"Total Data Throughput Using Timer: %d Mb/s = %d MB/s\n\n", tick_bw, tick_bw>>3);
#endif
#endif

  return (fail);
};

#endif


