//Tinh-SLT
#include "../include/pcie_pwr_mgmt.h"
//End of Tinh-SLT
//
void en_l1_pwr_mgmt(uint32_t pcie_core_id) {
  uint32_t data;

  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR);
  data |= FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352_CFG_CONSTANTS_ENABLE_L1_POWER_MGMT_MASK;
  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR, data);
  printf("EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352 0x%x  \n\r",
		  pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR));
}

void send_link_to_l1(uint32_t pcie_core_id) {
  uint32_t data;

  print("Send the EP to D1\n\r");

  data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_PM_CTRL_STAT__ADDR);
  //data &= 0xFFFFFFFC;
  data|=0x1;
  pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_PM_CTRL_STAT__ADDR, data);

}

void poll_link_to_l1(uint32_t pcie_core_id) {
  uint32_t data,data1;

  do {
    data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_POWERMANAGEMENTREG__ADDR);
   }  while((data & FIELD_POWERMANAGEMENTREG_PM_L1_ENTER_MASK) != FIELD_POWERMANAGEMENTREG_PM_L1_ENTER_MASK);

  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_POWERMANAGEMENTREG__ADDR, data);

}  

void wake_frm_l1(uint32_t pcie_core_id) {
  uint32_t data;

  data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_PM_CTRL_STAT__ADDR);
  data &= 0xFFFFFFFC;
  pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_PM_CTRL_STAT__ADDR, data);

  do {
    data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_POWERMANAGEMENTREG__ADDR);
#ifdef Dgb_38227
                 printf("Bug 38227: PIPE_REGS_LOS_PARAM @ AfterL1 0x%x  = \n\r" ,
                                             pcie_phy_csr_read(pcie_core_id, KC_PIPE_REGS_LOS_PARAM__ADDR) );
                 printf("Bug 38227: EP_CFG_STATUS_CFG_STATUS_1087_1056 @ AfterL1 0x%x  = \n\r" ,
                                              pcie_csr_read(0, NWL_PCIE_APB_REGS_EXPRESSO_CFG_STATUS_CFG_STATUS_1087_1056__ADDR) );
                 printf("Bug 38227: EP_POWERMANAGEMENTREG @ AfterL1 0x%x = \n\r" ,
                                              pcie_csr_read(0, SM_PCIE_CSR_REGS_POWERMANAGEMENTREG__ADDR));
#endif

  } while((data & FIELD_POWERMANAGEMENTREG_PM_L1_EXIT_MASK) != FIELD_POWERMANAGEMENTREG_PM_L1_EXIT_MASK);

  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_POWERMANAGEMENTREG__ADDR, data);
}

void en_l1l2_pwr_mgmt(uint32_t pcie_core_id) {
  uint32_t data;

  print("Enabling the L1 and L2 power management\n\r");
  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR);
  data |= FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352_CFG_CONSTANTS_ENABLE_L1_POWER_MGMT_MASK;
  data |= FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352_CFG_CONSTANTS_ENABLE_L2_POWER_MGMT_MASK;
  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR, data);

  print("Enabling the D3cold PM state\n\r");
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_POWERMANAGEMENTREG__ADDR);
  data |= FIELD_POWERMANAGEMENTREG_PM_ENABLE_D3COLD_MASK;
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_POWERMANAGEMENTREG__ADDR, data);
}

void send_link_to_l2(uint32_t pcie_core_id) {
  uint32_t data;
  uint32_t msg_data = 0;
  uint32_t msg_code = 0x19; // PME Turn Off message
  uint32_t msg_routing_code = 3;

  print("First send the EP to D3\n\r");

  data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_PM_CTRL_STAT__ADDR);
  data |= 0x3;
  pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_PM_CTRL_STAT__ADDR, data);

  print("Will wait for the link to go to L1 first\n\r");
  poll_link_to_l1(pcie_core_id);

  print("Link went into L1. Now, will send PME_Turn_off message to initiate L2 entry\n\r");
  send_ob_msg(pcie_core_id, msg_code, msg_routing_code, msg_data);
}

void poll_link_to_l2(uint32_t pcie_core_id) {
  uint32_t data;

  do {
    data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_POWERMANAGEMENTREG__ADDR);
  } while((data & FIELD_POWERMANAGEMENTREG_PM_L2_ENTER_MASK) != FIELD_POWERMANAGEMENTREG_PM_L2_ENTER_MASK);

  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_POWERMANAGEMENTREG__ADDR, data);    

  print("Core entered L2 state. Now, deasserting the core clk and deasserting the core reset\n\r");

  sm_pcie_disable_core_clk(pcie_core_id);

  sm_pcie_assert_core_reset(pcie_core_id);
}

void wake_frm_l2(uint32_t pcie_core_id, uint32_t gen, uint32_t ext_ref, uint32_t link_width) {
  uint32_t data;
  uint32_t pm_l2_store;
  uint32_t i;

  print("First bringing the pipe out of P2 state\n\r");
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_POWERMANAGEMENTREG__ADDR);
  data |= FIELD_POWERMANAGEMENTREG_CLR_POWER_DOWN_P2_LATCHING_MASK;

  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_POWERMANAGEMENTREG__ADDR, data);    

  print("Re-initializing the core\n\r");
//  sm_pcie_init(pcie_core_id, 1, 0, 2, 1, 8, 0);


}

