/*
 */
#include <types.h>
#include <stdio.h>
#include <common.h>
//Tinh-SLT
#include "../include/pcie_base.h"
#include "../include/pcie_sds_config.h"
#include "../include/pcie_ib_test.h"
//End of Tinh-SLT
//#define Change4
#define Change5

//#define STRESS_TEST
#define BLT_TEST

#define SKIP_BCA

//set to program PVT cal value manually
//#define manual_PVT

//set to bypass receiver detect
#define RCV_DET_BYPASS

//set to allow serdes control TX amplitude and pre/post cursor
//if not set, PIPE controls TX amplitude and pre/post cursor
//#define SDS_TX_CTRL

//set to use reference clock / 2 for serdes workaround on gen1/2
//#define REF_DIVIDE2

//set to use reference clock / 2 for serdes workaround on gen3
#define REF_DIVIDE2_GEN3

//set to use MOMSEL auto calibration
#define MOMSEL_AUTO

//set to enable debug hook. 
//#define ENB_DEBUG_HOOK

#ifndef VBIOS
#define MSDELAY(val)    {do sm_host_delay_ns(100000); while(val--);}
#endif

#ifdef SM_SOC_SIM
//Tinh-SLT
//void putnum(uint32_t num) {
void putnum_pcie(uint32_t num) {
  char str[32];

  sprintf(str, " 0x%x", num);
  lprintf(5,str);
}  
#endif
extern uint32_t pq_val;
// **********************************************************************************
// function used to do basic read-write 
// **********************************************************************************
void cpu_write(uint64_t addr, uint32_t data) {
  uint64_t cpu_addr;

  cpu_addr = CPU_ACCESS_BASE | addr;
#ifdef SM_SOC_SIM
  sm_host_write32_pcie(cpu_addr, data);
#else  
  uint32_t cpu_addr32 = (uint32_t)cpu_addr;
  write(cpu_addr32, data); 
#endif
  lprintf(7, "CPU Write addr 0x%x, data 0x%x \n\r", addr, data);
}

uint32_t cpu_read(uint64_t addr) {
  uint64_t cpu_addr;
  uint32_t data;

  cpu_addr = CPU_ACCESS_BASE | addr;
#ifdef SM_SOC_SIM
  sm_host_read32_pcie(cpu_addr, &data);
#else  
  uint32_t cpu_addr32 = (uint32_t)cpu_addr;
  data = read(cpu_addr32); 
#endif

  lprintf(7, "CPU Read addr 0x%x, data 0x%x \n\r", addr, data);
  return data;
}

// **********************************************************************************
// function used to read-write registers inside the PCIE CSR space.
// **********************************************************************************
uint64_t ret_csr_base(uint32_t pcie_core_id) {
  uint64_t SM_ADDR_MAP_PCIE_CSR_BASE;

  switch(pcie_core_id) {
    case 0: SM_ADDR_MAP_PCIE_CSR_BASE = SM_ADDR_MAP_PCIE0_CSR_BASE; 
            break;
    case 1: SM_ADDR_MAP_PCIE_CSR_BASE = SM_ADDR_MAP_PCIE1_CSR_BASE; 
            break;
    case 3: SM_ADDR_MAP_PCIE_CSR_BASE = SM_ADDR_MAP_PCIE3_CSR_BASE; 
            break;
    case 4: SM_ADDR_MAP_PCIE_CSR_BASE = SM_ADDR_MAP_PCIE4_CSR_BASE; 
            break;
    default: SM_ADDR_MAP_PCIE_CSR_BASE = SM_ADDR_MAP_PCIE2_CSR_BASE; 
            break;           
  }

  return SM_ADDR_MAP_PCIE_CSR_BASE;
}

void pcie_csr_write(uint32_t pcie_core_id, uint32_t offset, uint32_t data) {
  uint64_t addr; 
  uint64_t SM_ADDR_MAP_PCIE_CSR_BASE;

  SM_ADDR_MAP_PCIE_CSR_BASE = ret_csr_base(pcie_core_id);

  addr = SM_ADDR_MAP_PCIE_CSR_BASE | ((uint64_t ) offset);

  lprintf(7, "pcie_csr_write(addr=0x%x)=0x%x\n",addr, data);
  cpu_write(addr, data);
}  

uint32_t pcie_csr_read(uint32_t pcie_core_id, uint32_t offset) {
  uint64_t addr; 
  uint64_t SM_ADDR_MAP_PCIE_CSR_BASE;
  uint32_t data; 

  SM_ADDR_MAP_PCIE_CSR_BASE = ret_csr_base(pcie_core_id);
  addr = SM_ADDR_MAP_PCIE_CSR_BASE | ((uint64_t ) offset);
  data = cpu_read(addr);
  lprintf(7, "pcie_csr_read(addr=0x%x)=0x%x\n",addr, data);
  return data;
}

// **********************************************************************************
// function used to read-write registers inside the PCIE config space (cfg0/cfg1) 
// or DMA CSR space.
// **********************************************************************************
uint64_t ret_pcie_mem_base(uint32_t pcie_core_id) {
  uint64_t SM_ADDR_MAP_PCIE_BASE;

  switch(pcie_core_id) {
    case 0: SM_ADDR_MAP_PCIE_BASE = SM_ADDR_MAP_PCIE0_BASE; 
            break;

    case 1: SM_ADDR_MAP_PCIE_BASE = SM_ADDR_MAP_PCIE1_BASE; 
            break;

    case 3: SM_ADDR_MAP_PCIE_BASE = SM_ADDR_MAP_PCIE3_BASE; 
            break;

    case 4: SM_ADDR_MAP_PCIE_BASE = SM_ADDR_MAP_PCIE4_BASE; 
            break;

    default: SM_ADDR_MAP_PCIE_BASE = SM_ADDR_MAP_PCIE2_BASE; 
            break;           
  }

  return SM_ADDR_MAP_PCIE_BASE;
}

uint64_t ret_ob_cfg_base(uint32_t pcie_core_id) {
  uint64_t SM_ADDR_MAP_PCIE_BASE;
  uint64_t SM_ADDR_MAP_PCIE_OB_CFG_BASE;

  SM_ADDR_MAP_PCIE_BASE = ret_pcie_mem_base(pcie_core_id);

  SM_ADDR_MAP_PCIE_OB_CFG_BASE = SM_ADDR_MAP_PCIE_BASE + PCIE_OB_CFG_OFFSET;

  return SM_ADDR_MAP_PCIE_OB_CFG_BASE;
}

uint64_t ret_ob_msg_base(uint32_t pcie_core_id) {
  uint64_t SM_ADDR_MAP_PCIE_BASE;
  uint64_t SM_ADDR_MAP_PCIE_OB_MSG_BASE;

  SM_ADDR_MAP_PCIE_BASE = ret_pcie_mem_base(pcie_core_id);

  SM_ADDR_MAP_PCIE_OB_MSG_BASE = SM_ADDR_MAP_PCIE_BASE + PCIE_OB_MSG_OFFSET;

  return SM_ADDR_MAP_PCIE_OB_MSG_BASE;
}

uint64_t ret_omr1_base(uint32_t pcie_core_id) {
  uint64_t SM_ADDR_MAP_PCIE_BASE;
  uint64_t SM_ADDR_MAP_PCIE_OMR1_BASE;

  SM_ADDR_MAP_PCIE_BASE = ret_pcie_mem_base(pcie_core_id);

  SM_ADDR_MAP_PCIE_OMR1_BASE = SM_ADDR_MAP_PCIE_BASE + PCIE_OMR1_OFFSET;

  return SM_ADDR_MAP_PCIE_OMR1_BASE;
}

uint64_t ret_omr2_base(uint32_t pcie_core_id) {
  uint64_t SM_ADDR_MAP_PCIE_BASE;
  uint64_t SM_ADDR_MAP_PCIE_OMR2_BASE;

  SM_ADDR_MAP_PCIE_BASE = ret_pcie_mem_base(pcie_core_id);

  SM_ADDR_MAP_PCIE_OMR2_BASE = SM_ADDR_MAP_PCIE_BASE + PCIE_OMR2_OFFSET;

  return SM_ADDR_MAP_PCIE_OMR2_BASE;
}

uint64_t ret_omr3_base(uint32_t pcie_core_id) {
  uint64_t SM_ADDR_MAP_PCIE_BASE;
  uint64_t SM_ADDR_MAP_PCIE_OMR3_BASE;

  SM_ADDR_MAP_PCIE_BASE = ret_pcie_mem_base(pcie_core_id);

  SM_ADDR_MAP_PCIE_OMR3_BASE = SM_ADDR_MAP_PCIE_BASE + PCIE_OMR3_OFFSET;

  return SM_ADDR_MAP_PCIE_OMR3_BASE;
}

void pcie_ob_cfg_write(uint32_t pcie_core_id, uint32_t offset, uint32_t data) {
  uint64_t addr; 
  uint64_t SM_ADDR_MAP_PCIE_OB_CFG_BASE;

  SM_ADDR_MAP_PCIE_OB_CFG_BASE = ret_ob_cfg_base(pcie_core_id);

  addr = SM_ADDR_MAP_PCIE_OB_CFG_BASE | ((uint64_t ) offset);

  cpu_write(addr, data);
  lprintf(6,"  PCIE OB CFG Write [0x%x] <= 0x%x \n", addr, data);
}  

static uint32_t called=0;
uint32_t pcie_ob_cfg_read(uint32_t pcie_core_id, uint32_t offset) {
  uint64_t addr; 
  uint64_t SM_ADDR_MAP_PCIE_OB_CFG_BASE;
  uint32_t data; 

  SM_ADDR_MAP_PCIE_OB_CFG_BASE = ret_ob_cfg_base(pcie_core_id);

  addr = SM_ADDR_MAP_PCIE_OB_CFG_BASE | ((uint64_t ) offset);
  
  if(!called)
  { 
    USDELAY(1);  // has effect-1
	called=1;
  }
  
  data = cpu_read(addr);

  lprintf(6,"  PCIE OB CFG Read  [0x%x] => 0x%x, core_id=%d\n", addr, data, pcie_core_id);
  return data;
}

// **********************************************************************************
// function used to read-write registers inside the PCIE PHY
// **********************************************************************************
void pcie_phy_csr_write(uint32_t pcie_core_id, uint32_t addr, uint32_t data) {
  uint32_t cap_value;
  uint32_t ind_addr_cmd;

  ind_addr_cmd =(addr << FIELD_PCIE_SDS_IND_CMD_REG_CFG_IND_ADDR_SHIFT_MASK) | FIELD_PCIE_SDS_IND_CMD_REG_CFG_IND_WR_CMD_MASK; // Setting the wr bit in the ind_cmd register.
  ind_addr_cmd |= FIELD_PCIE_SDS_IND_CMD_REG_CFG_IND_CMD_DONE_MASK; // Clearing cmd_done flag for previous cmd.
   
  pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_IND_WDATA_REG__ADDR, data);
  pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_IND_CMD_REG__ADDR, ind_addr_cmd); // Write CMU_reg0 register

  do {
    cap_value = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_IND_CMD_REG__ADDR);
  } while((cap_value& FIELD_PCIE_SDS_IND_CMD_REG_CFG_IND_CMD_DONE_MASK) != FIELD_PCIE_SDS_IND_CMD_REG_CFG_IND_CMD_DONE_MASK);
  lprintf(7, "PHY CSR WRITE [0x%x] <= 0x%x \n", addr, data);
}  

uint32_t pcie_phy_csr_read(uint32_t pcie_core_id, uint32_t addr) {
  uint32_t cap_value;
  uint32_t ind_addr_cmd;
  uint32_t data;

  ind_addr_cmd =(addr << FIELD_PCIE_SDS_IND_CMD_REG_CFG_IND_ADDR_SHIFT_MASK) | FIELD_PCIE_SDS_IND_CMD_REG_CFG_IND_RD_CMD_MASK; // Setting the rd bit in the ind_cmd register.
  ind_addr_cmd |= FIELD_PCIE_SDS_IND_CMD_REG_CFG_IND_CMD_DONE_MASK; // Clearing cmd_done flag for previous cmd.
   
  pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_IND_CMD_REG__ADDR, ind_addr_cmd); // Write CMU_reg0 register

  do {
    cap_value = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_IND_CMD_REG__ADDR);
  } while((cap_value& FIELD_PCIE_SDS_IND_CMD_REG_CFG_IND_CMD_DONE_MASK) != FIELD_PCIE_SDS_IND_CMD_REG_CFG_IND_CMD_DONE_MASK);

  data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_IND_RDATA_REG__ADDR);
  lprintf(7, "PHY CSR READ [0x%x] => 0x%x \n", addr, data);
  return data;
}  
//

// **********************************************************************************
// function used to init ECC logic. 
// **********************************************************************************
void sm_pcie_init_ecc(uint32_t pcie_core_id) {
  uint32_t data;

  lprintf(5,"Inside function sm_pcie_init_ecc\n\r");

  pcie_csr_write(pcie_core_id, SM_GLBL_DIAG_CSR_CFG_MEM_RAM_SHUTDOWN__ADDR, 0);
  data = pcie_csr_read(pcie_core_id, SM_GLBL_DIAG_CSR_CFG_MEM_RAM_SHUTDOWN__ADDR);

  lprintf(5,"Data read from DIAG_MEM_RAM_SHUTDOWN register is "); putnum_pcie(data); lprintf(5,"\n\r");

  data = pcie_csr_read(pcie_core_id, SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY__ADDR);
  while (data != 0xFFFFFFFF) {
    data = pcie_csr_read(pcie_core_id, SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY__ADDR);
  } 
};

void set_ser_refclk(uint32_t pcie_core_id, uint32_t port_type, uint32_t ext_ref, uint32_t link_width) {
  uint32_t data;

  data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_CTL0__ADDR);
  // Reseting bit 12 of customer_pin_mode register.
  data = (data & 0xFFFFEFFF);
  data = data | 0x8;
  pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_CTL0__ADDR, data);

  if(ext_ref) {
    if(link_width == 8) {
      lprintf(5,"Selecting the external refclk for PCIEX8, requires additional programming of register inside SERDES at offset 0x0.\n\r");

      data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG0__ADDR);
      //Setting bit 13 of cmu reg 0 inside the SERDES, to select refclk from serdes 0.
      data = FIELD_CMU_REG0_PLL_REF_SEL_SET(data, 0x1);
      pcie_phy_csr_write(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG0__ADDR, data);
  
    }
  } else {
    clkmacro_cal(pcie_core_id);
    lprintf(5,"PLL lock achieved for CLK MACRO. Now, switching the refclk source.\n\r");
  //customer pin mode bit 12 is cleared due to PIPE bug, select REFCLK_CMOS_SEL using serdes register
   if(link_width == 8) {
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG1__ADDR);
    data = FIELD_CMU_REG1_REFCLK_CMOS_SEL_SET(data, 0x1);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG1__ADDR, data);
  
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG1__ADDR) ;
    data = FIELD_CMU_REG1_REFCLK_CMOS_SEL_SET(data, 0x1);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG1__ADDR, data);
   } else {
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG1__ADDR);
    data = FIELD_CMU_REG1_REFCLK_CMOS_SEL_SET(data, 0x1);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG1__ADDR, data);
   }
  }

/*
    data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_CTL0__ADDR);
    // Setting customer_pin_mode register field's bit 12 and setting bit 17 REFCLK_CMOS_SEL, will switch to internal refclk
    // mode.
    data = (data | FIELD_PCIE_SDS_CTL0_CFG_I_REFCLK_CMOS_SEL_MASK | 0x1000);
    pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_CTL0__ADDR, data);
  
  NOTT: need to check with KC on these
  lprintf(5,"Enabling the SSC for the SERDES\n\r");
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG36__ADDR);
  data |= FIELD_CMU_REG36_PLL_SSC_EN_MASK;
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG36__ADDR, data);

  if(link_width == 8) {
    lprintf(5,"Enabling the SSC for the SERDES2\n\r");
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG36__ADDR);
    data |= FIELD_CMU_REG36_PLL_SSC_EN_MASK;
    pcie_phy_csr_write(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG36__ADDR, data);
  }
*/
};  

void cmu_pd(int pcie_core_id, int link_width){
 int data;

    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG0__ADDR);
    data = FIELD_CMU_REG0_PDOWN_SET(data, 0x1);
    pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG0__ADDR, data);

	if(link_width > 4){
		data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG0__ADDR + 0x30000);
		data = FIELD_CMU_REG0_PDOWN_SET(data, 0x1);
		pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG0__ADDR + 0x30000, data);
	}
}

void cmu_reset(int pcie_core_id, int link_width){
 int data;

    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG0__ADDR);
    data = FIELD_CMU_REG0_RESETB_SET(data, 0x0);
    pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG0__ADDR, data);
    
	if(link_width >4) {
		data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG0__ADDR + 0x30000);
    	data = FIELD_CMU_REG0_RESETB_SET(data, 0x0);
    	pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG0__ADDR + 0x30000, data);
	}
}

void rxtx_pd(int pcie_core_id, int link_width){
 int data, ch;
 int local_width = (link_width >= 4)? 4: 1;

	for(ch=0; ch<local_width; ch++){
		data = pcie_phy_csr_read(pcie_core_id, (KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch)));
		data = FIELD_CH0_RXTX_REG2_TX_PDOWN_SET(data, 1);
		pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch), data);
		
		data = pcie_phy_csr_read(pcie_core_id, (KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch)));
		data = FIELD_CH0_RXTX_REG12_RX_PDOWN_SET(data, 1);
		pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch), data);
	}

	if (link_width > 4){
		for(ch=0; ch<local_width; ch++){
			data = pcie_phy_csr_read(pcie_core_id, (KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch)+ 0x30000));
			data = FIELD_CH0_RXTX_REG2_TX_PDOWN_SET(data, 1);
			pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + 0x30000, data);
			
			data = pcie_phy_csr_read(pcie_core_id, (KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch)+ 0x30000));
			data = FIELD_CH0_RXTX_REG12_RX_PDOWN_SET(data, 1);
			pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + 0x30000, data);
		}
	}
}

void rxtx_reset(int pcie_core_id, int link_width){
 int data, ch;
 int local_width = (link_width >= 4)? 4: 1;

	for(ch=0; ch<local_width; ch++){
	    data = pcie_phy_csr_read(pcie_core_id, (KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch)));
        data = FIELD_CH0_RXTX_REG2_RESETB_TXA_SET(data, 0);
        data = FIELD_CH0_RXTX_REG2_RESETB_TXD_SET(data, 0);
        pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch), data);
        
        data = pcie_phy_csr_read(pcie_core_id, (KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch)));
        data = FIELD_CH0_RXTX_REG7_RESETB_RXA_SET(data, 0);
        data = FIELD_CH0_RXTX_REG7_RESETB_RXD_SET(data, 0);
        pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch), data);
	}

	if (link_width > 4)
		for(ch=0; ch<local_width; ch++){
			data = pcie_phy_csr_read(pcie_core_id, (KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch)+ 0x30000));
			data = FIELD_CH0_RXTX_REG2_RESETB_TXA_SET(data, 0);
			data = FIELD_CH0_RXTX_REG2_RESETB_TXD_SET(data, 0);
			pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + 0x30000, data);
			
			data = pcie_phy_csr_read(pcie_core_id, (KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch)+ 0x30000));
			data = FIELD_CH0_RXTX_REG7_RESETB_RXA_SET(data, 0);
			data = FIELD_CH0_RXTX_REG7_RESETB_RXD_SET(data, 0);
			pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + 0x30000, data);
		}

}

void cmu_pup(int pcie_core_id, int link_width){
int data;

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG0__ADDR);
  data = FIELD_CMU_REG0_PDOWN_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG0__ADDR, data);

  if (link_width > 4) {
	  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG0__ADDR + 0x30000);
	  data = FIELD_CMU_REG0_PDOWN_SET(data, 0x0);
	  pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG0__ADDR + 0x30000, data);
  }
}

void cmu_reset_release(int pcie_core_id, int link_width){
int data;

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG0__ADDR);
  data = FIELD_CMU_REG0_RESETB_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG0__ADDR, data);

  if (link_width > 4) {
	  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG0__ADDR + 0x30000);
	  data = FIELD_CMU_REG0_RESETB_SET(data, 0x1);
	  pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG0__ADDR + 0x30000, data);
  }
}

void rxtx_pup(int pcie_core_id, int link_width){

int ch, data;
int local_width = (link_width >= 4)? 4: 1;

for (ch=0; ch<local_width; ch++){
    data = pcie_phy_csr_read(pcie_core_id, (KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch)));
    data = FIELD_CH0_RXTX_REG2_TX_PDOWN_SET(data, 0);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch), data);
    
    data = pcie_phy_csr_read(pcie_core_id, (KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch)));
    data = FIELD_CH0_RXTX_REG12_RX_PDOWN_SET(data, 0);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch), data);
}

if (link_width > 4) {
    for (ch=0; ch<local_width; ch++){
		data = pcie_phy_csr_read(pcie_core_id, (KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch)+ 0x30000));
		data = FIELD_CH0_RXTX_REG2_TX_PDOWN_SET(data, 0);
		pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + 0x30000, data);
		
		data = pcie_phy_csr_read(pcie_core_id, (KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch)+ 0x30000));
		data = FIELD_CH0_RXTX_REG12_RX_PDOWN_SET(data, 0);
		pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + 0x30000, data);
    }
  }
}

void rxtx_reset_release(int pcie_core_id, int link_width){
int ch, data;
int local_width = (link_width >= 4)? 4: 1;

for (ch=0; ch<local_width; ch++){
    data = pcie_phy_csr_read(pcie_core_id, (KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch)));
    data = FIELD_CH0_RXTX_REG2_RESETB_TXA_SET(data, 1);
    data = FIELD_CH0_RXTX_REG2_RESETB_TXD_SET(data, 1);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch), data);

    data = pcie_phy_csr_read(pcie_core_id, (KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch)));
    data = FIELD_CH0_RXTX_REG7_RESETB_RXA_SET(data, 1);
    data = FIELD_CH0_RXTX_REG7_RESETB_RXD_SET(data, 1);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch), data);
}

if (link_width > 4) {
    for (ch=0; ch<local_width; ch++){
		data = pcie_phy_csr_read(pcie_core_id, (KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch)+ 0x30000));
		data = FIELD_CH0_RXTX_REG2_RESETB_TXA_SET(data, 1);
		data = FIELD_CH0_RXTX_REG2_RESETB_TXD_SET(data, 1);
		pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + 0x30000, data);

		data = pcie_phy_csr_read(pcie_core_id, (KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch)+ 0x30000));
		data = FIELD_CH0_RXTX_REG7_RESETB_RXA_SET(data, 1);
		data = FIELD_CH0_RXTX_REG7_RESETB_RXD_SET(data, 1);
		pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + 0x30000, data);
    }
  }
}

void force_pvt_cal(int pcie_core_id, int link_width){
int sds2_offset, data;

 if(pcie_core_id == 2) {
  set_pvt_cal(pcie_core_id, 0);
 } else {
    if (link_width == 8){
      set_pvt_cal(pcie_core_id, 0);
      set_pvt_cal(pcie_core_id, 1);
    } else {
      set_pvt_cal(pcie_core_id, 0);
    }
 }
}

void set_pvt_cal(int pcie_core_id, int sds2){
int sds2_offset, data;

  if (sds2){
    sds2_offset = 0x30000;
  } else {
    sds2_offset = 0x0;
  }
  
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG32__ADDR + sds2_offset);
  data = FIELD_CMU_REG32_FORCE_PVT_CAL_START_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG32__ADDR + sds2_offset, data);
  
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG32__ADDR + sds2_offset);
  data = FIELD_CMU_REG32_FORCE_PVT_CAL_START_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG32__ADDR + sds2_offset, data);
}


int wait_pll_lock (uint32_t pcie_core_id, uint32_t full_width) {
  uint32_t data0, data1, pllrdy0, plllock0, vcocal0, vcofail0, vcofail0_bit0;
  uint32_t pllrdy1, plllock1, vcocal1, vcofail1, vcofail1_bit0, lock0, lock1 ;
  uint32_t count = 5;
  if (full_width) {
      do {
        data0 = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG7__ADDR);
        vcocal0 = FIELD_CMU_REG7_PLL_CALIB_DONE_RD(data0);
        vcofail0 = FIELD_CMU_REG7_VCO_CAL_FAIL_RD(data0) & 0x1;
        lock0 = vcocal0 && !vcofail0;
        
        data1 = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG7__ADDR + 0x30000);
        vcocal1 = FIELD_CMU_REG7_PLL_CALIB_DONE_RD(data1);
        vcofail1 = FIELD_CMU_REG7_VCO_CAL_FAIL_RD(data1) & 0x1;
        lock1 = vcocal1 && !vcofail1;
        
        lprintf(5,"Poll PLL lock on core 0x%x, serdes 0x%x, reg read data 0x%x \n\r", pcie_core_id, 0, data0);
        lprintf(5,"Poll PLL lock on core 0x%x, serdes 0x%x, reg read data 0x%x \n\r", pcie_core_id, 1, data1);
      } while (((lock0 && lock1) == 0)&&(--count != 0));
  } else {
      do {
        data0 = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG7__ADDR);
        vcocal0 = FIELD_CMU_REG7_PLL_CALIB_DONE_RD(data0);
        vcofail0 = FIELD_CMU_REG7_VCO_CAL_FAIL_RD(data0) & 0x1;
        lock0 = vcocal0 && !vcofail0;
        
        lprintf(5,"Poll PLL lock on core 0x%x, reg read data 0x%x \n\r", pcie_core_id, data0);
      } while ((lock0 == 0)&&(--count != 0));
  }
  return count;
}

void pipe_config(uint32_t pcie_core_id){
uint32_t data, i,CN0,CP1,CN1,CN2;

  //increase receiver detect timeout window between serdes and PIPE
  data = pcie_phy_csr_read(pcie_core_id, KC_PIPE_REGS_RECEIVE_DETECT_CONTROL__ADDR);
  data = FIELD_RECEIVE_DETECT_CONTROL_RX_PRES_ONE_CNT_TH_SET(data, 0xffff); //128us max value possible
  pcie_phy_csr_write(pcie_core_id, KC_PIPE_REGS_RECEIVE_DETECT_CONTROL__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_PIPE_REGS_USB_PCIE_CTRL__ADDR);
  data = FIELD_USB_PCIE_CTRL_RX_PRES_ONE_CNT_CMP_TH_SET(data, 0x50); //100ns min
  pcie_phy_csr_write(pcie_core_id, KC_PIPE_REGS_USB_PCIE_CTRL__ADDR, data);

  for (i = 0; i<8; i++){
    //CDR SEL override
    data = pcie_phy_csr_read(pcie_core_id, KC_PIPE_REGS_SERDES_DFE_CONTROL0__ADDR + (i *4));
    data = FIELD_SERDES_DFE_CONTROL0_P2S_I_SPD_SEL_CDR_OVR_LN_SET(data, 0x7);
    pcie_phy_csr_write(pcie_core_id, KC_PIPE_REGS_SERDES_DFE_CONTROL0__ADDR + (i *4), data);
  }

  //increase tx amp, channel 0 bit location is different from rest of channels
  data = pcie_phy_csr_read(pcie_core_id, KC_PIPE_REGS_SERDES_CONTROL3__ADDR);
  data = FIELD_SERDES_CONTROL3_P2S_I_TX_AMP_EN_LN0_SET(data, 0x1);
  data = FIELD_SERDES_CONTROL3_P2S_I_TX_AMP_LN0_SET(data, 0xf);
  pcie_phy_csr_write(pcie_core_id, KC_PIPE_REGS_SERDES_CONTROL3__ADDR, data);

  for (i = 0; i<7; i++){
    //increase tx amp
    data = pcie_phy_csr_read(pcie_core_id, KC_PIPE_REGS_SERDES_CONTROL4__ADDR + (i *4));
    data = FIELD_SERDES_CONTROL4_P2S_I_TX_AMP_EN_LN1_SET(data, 0x1);
    data = FIELD_SERDES_CONTROL4_P2S_I_TX_AMP_LN1_SET(data, 0xf);
    pcie_phy_csr_write(pcie_core_id, KC_PIPE_REGS_SERDES_CONTROL4__ADDR + (i *4) , data);
  }

  //daniel: 130830 added to remove SD glitch
  data = pcie_phy_csr_read(pcie_core_id, KC_PIPE_REGS_LOS_PARAM__ADDR);
  data = FIELD_LOS_PARAM_TH_CNTON_GEN12_SET(data, 0xf);
  data = FIELD_LOS_PARAM_TH_CNTOFF_GEN12_SET(data, 0x8);
  data = FIELD_LOS_PARAM_TH_CNTON_GEN3_SET(data, 0xf);
  data = FIELD_LOS_PARAM_TH_CNTOFF_GEN3_SET(data, 0x8);
  pcie_phy_csr_write(pcie_core_id, KC_PIPE_REGS_LOS_PARAM__ADDR, data);

  //EBUF setting change
  data = pcie_phy_csr_read(pcie_core_id,  KC_PIPE_REGS_EFIFO_CONTROL0__ADDR);
  if(pcie_core_id == 2)
    data = FIELD_EFIFO_CONTROL0_BUF_DEPTH_PCI_SET(data, 0xf);                       // BUG_41872
  else
    data = FIELD_EFIFO_CONTROL0_BUF_DEPTH_PCI_SET(data, 0x10);                       // BUG_41872
  pcie_phy_csr_write(pcie_core_id, KC_PIPE_REGS_EFIFO_CONTROL0__ADDR, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_PIPE_REGS_PIPE_CONTROL__ADDR);
  data = FIELD_PIPE_CONTROL_WMSELECT_SET(data, 0x6);
  pcie_phy_csr_write(pcie_core_id, KC_PIPE_REGS_PIPE_CONTROL__ADDR, data);
  
  //undocumented PIPE register, used for GEN1/GEN2 TX coefficient override
  // Specific to intermediate SLT Release done for Gen1 3.5dB de-emphasis
  pcie_phy_csr_write(pcie_core_id, (0x10000 | 0x0c), 0x0240); //0x0,0x9,0x0  : Gen1 x8 
  data = pcie_phy_csr_read(pcie_core_id, 0x1000c); 
  CN0  = data       & 0x3f;
  CP1  = (data>>6)  & 0x3f;
  CN1  = (data>>12) & 0x3f;

//CN2 setting
  data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_MISC_CTL__ADDR);
  data = FIELD_PCIE_SDS_MISC_CTL_CFG_I_TX_CN2_SET(data, 0x0); 
  pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_MISC_CTL__ADDR, data);

  //set bca no ack timer to 0 for infinite timoeut
  data = pcie_phy_csr_read(pcie_core_id, KC_PIPE_REGS_BCA_NO_ACK_TMR_SEL__ADDR);
  data = FIELD_BCA_NO_ACK_TMR_SEL_BCA_NO_ACK_TIMER_SEL_SET(data, 0x1); 
  pcie_phy_csr_write(pcie_core_id, KC_PIPE_REGS_BCA_NO_ACK_TMR_SEL__ADDR, data);

}

void serdes_config_LSPLL(uint32_t pcie_core_id, uint32_t sds2){
  uint32_t data, sds2_offset;
  lprintf(5,"Serdes PLL config, core 0x%x, serdes# 0x%x \n\r", pcie_core_id, sds2);
  if (sds2){
    sds2_offset = 0x30000;
  } else {
    sds2_offset = 0x0;
  }
  
  //pciegen3 control from PIPE is turned Off
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG0__ADDR + sds2_offset);
  data = FIELD_CMU_REG0_PCIEGEN3_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG0__ADDR + sds2_offset, data);
 
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG1__ADDR + sds2_offset);
  data = FIELD_CMU_REG1_PLL_CP_SET(data, 0xf);
  data = FIELD_CMU_REG1_PLL_CP_SEL_SET(data, 0xc);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG1__ADDR + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG3__ADDR + sds2_offset);
  data = FIELD_CMU_REG3_VCOVARSEL_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG3__ADDR + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG2__ADDR + sds2_offset);
  #ifdef REF_DIVIDE2
  data = FIELD_CMU_REG2_PLL_REFDIV_SET(data, 0x1); //divide referenc clock by 2
  data = FIELD_CMU_REG2_PLL_LFRES_SET(data, 0x2);
  data = FIELD_CMU_REG2_PLL_FBDIV_SET(data, 0x63); //adjust feedback to new reference clock
  #else
  data = FIELD_CMU_REG2_PLL_LFRES_SET(data, 0x2);
  data = FIELD_CMU_REG2_PLL_FBDIV_SET(data, 0x31); //control off from PIPE
  #endif
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG2__ADDR + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG5__ADDR + sds2_offset);
  data = FIELD_CMU_REG5_PLL_LFCAP_SET(data, 0);
  data = FIELD_CMU_REG5_PLL_LFSMCAP_SET(data, 0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG5__ADDR + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG4__ADDR + sds2_offset);
  data = FIELD_CMU_REG4_VCOVARSEL_PCIE_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG4__ADDR + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG32__ADDR + sds2_offset);
  data = FIELD_CMU_REG32_IREF_ADJ_SET(data, 0x2);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG32__ADDR + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG1__ADDR + sds2_offset);
  data = FIELD_CMU_REG1_PLL_MANUALCAL_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG1__ADDR + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG3__ADDR + sds2_offset);
  data = FIELD_CMU_REG3_VCO_MOMSEL_INIT_SET(data, 0x10);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG3__ADDR + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG4__ADDR + sds2_offset);
  data = FIELD_CMU_REG4_VCO_MOMSEL_INIT_PCIE_SET(data, 0x10);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG4__ADDR + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG34__ADDR + sds2_offset);
  data = FIELD_CMU_REG34_VCO_CAL_VTH_HI_MIN_SET(data, 0x2);
  data = FIELD_CMU_REG34_VCO_CAL_VTH_HI_MAX_SET(data, 0xa);
  data = FIELD_CMU_REG34_VCO_CAL_VTH_LO_MIN_SET(data, 0x2);
  data = FIELD_CMU_REG34_VCO_CAL_VTH_LO_MAX_SET(data, 0xa);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG34__ADDR + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG0__ADDR + sds2_offset);
  data = FIELD_CMU_REG0_CAL_COUNT_RESOL_SET(data, 0x7); //pll lock calibration
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG0__ADDR + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG16__ADDR + sds2_offset);
  data = FIELD_CMU_REG16_VCOCAL_WAIT_BTW_CODE_SET(data, 0x7); //VCO Calb wait time
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG16__ADDR + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG30__ADDR + sds2_offset);
  #ifdef REF_DIVIDE2_GEN3
  data = FIELD_CMU_REG30_PLL_REFDIV_GEN3_SET(data, 0x1); //divide refence clock by 2
  data = FIELD_CMU_REG30_LOCK_COUNT_SET(data, 0x3); //Lock count wait time
  data = FIELD_CMU_REG30_PLL_FBDIV_GEN3_SET(data, 0x4f);  //increase feedback divider for reduced reference clock
  #else
  data = FIELD_CMU_REG30_LOCK_COUNT_SET(data, 0x3); //Lock count wait time
  data = FIELD_CMU_REG30_PLL_FBDIV_GEN3_SET(data, 0x27);  //control turn off from PIPE
  #endif
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG30__ADDR + sds2_offset, data);

  //rate change delay setting
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG12__ADDR + sds2_offset);
  data = FIELD_CMU_REG12_STATE_DELAY9_SET(data, 0x2);  //ready_count top
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG12__ADDR + sds2_offset, data);
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG12__ADDR + sds2_offset);
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG13__ADDR + sds2_offset);
    
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG13__ADDR + sds2_offset);
  data = FIELD_CMU_REG13_STATE_DELAY1_SET(data, 0xf); //calib_start_count_stop
  data = FIELD_CMU_REG13_STATE_DELAY2_SET(data, 0x2);//channel_start_count_stop
  data = FIELD_CMU_REG13_STATE_DELAY3_SET(data, 0xd);//reset_count_stop
  data = FIELD_CMU_REG13_STATE_DELAY4_SET(data, 0xb);//start_ctle_cal_count
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG13__ADDR + sds2_offset, data);
  
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG14__ADDR + sds2_offset);
  data = FIELD_CMU_REG14_STATE_DELAY5_SET(data, 0x2); //float_tap_src_ena_count_stop
  data = FIELD_CMU_REG14_STATE_DELAY6_SET(data, 0x2); //float_tap_src_count_stop
  data = FIELD_CMU_REG14_STATE_DELAY7_SET(data, 0x7); //blwc_ena_count_stop
  data = FIELD_CMU_REG14_STATE_DELAY8_SET(data, 0xa); //ready_count_stop
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG14__ADDR + sds2_offset, data);
  //delay value encoding
  //4'hf:  // 2.56 ms (assume 10ns clock)
  //4'he:  // 1.28 ms
  //4'hd:  // 640us
  //4'hc:  // 320us
  //4'hb:  // 160us
  //4'ha:  // 80us
  //4'h9:  // 40us
  //4'h8:  // 20us
  //4'h7:  // 10us
  //4'h6:  // 5.12us
  //4'h5:  // 2.56us
  //4'h4:  // 1.28us
  //4'h3:  // 640ns
  //4'h2:  // 320ns
  //4'h1:  // 160ns
  //4'h0:  // 80ns
  ////////////////////////////////////////////////////////////////////////////////////
  
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG32__ADDR + sds2_offset);
  data = FIELD_CMU_REG32_PVT_CAL_WAIT_SEL_SET(data, 0x3);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG32__ADDR + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG31__ADDR + sds2_offset);
  data = FIELD_CMU_REG31_LOS_OVERRIDE_CH3_SET(data, 0x1);
  data = FIELD_CMU_REG31_LOS_OVERRIDE_CH2_SET(data, 0x1);
  data = FIELD_CMU_REG31_LOS_OVERRIDE_CH1_SET(data, 0x1);
  data = FIELD_CMU_REG31_LOS_OVERRIDE_CH0_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG31__ADDR + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG37__ADDR + sds2_offset);
  data = FIELD_CMU_REG37_CTLE_CAL_DONE_OVR_SET(data, 0xf);
  data = FIELD_CMU_REG37_FT_SEARCH_DONE_OVR_SET(data, 0xf);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG37__ADDR + sds2_offset, data);

  //PVT reference of 50 Ohm
 data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG27__ADDR + sds2_offset);
 data = FIELD_CMU_REG27_REF_VOLT_SEL_CH0_SET(data, 0x2);
 data = FIELD_CMU_REG27_REF_VOLT_SEL_CH1_SET(data, 0x2);
 data = FIELD_CMU_REG27_REF_VOLT_SEL_CH2_SET(data, 0x2);
 data = FIELD_CMU_REG27_REF_VOLT_SEL_CH3_SET(data, 0x2);
 pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG27__ADDR + sds2_offset, data);
 
}


void serdes_config_rxtx_control(uint32_t pcie_core_id, uint32_t ch, uint32_t sds2) {
  uint32_t data, sds2_offset;

  lprintf(5,"Serdes RX config, core 0x%x, channel# 0x%x, serdes# 0x%x \n\r", pcie_core_id, ch, sds2);
  if (sds2){
    sds2_offset = 0x30000;
  } else {
    sds2_offset = 0x0;
  }
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG147__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG147_STMC_OVERRIDE_SET(data, 0x6);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG147__ADDR + (0x200 * ch) + sds2_offset, data);

  //important: this is workaound for lack of reset after power state change bug
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG27__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG27_RXPD_CONFIG_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG27__ADDR + (0x200 * ch) + sds2_offset, data);

  //enable eye scan latch calibration
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG145__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG145_RXVWES_LATENA_SET(data, 1);
  data = FIELD_CH0_RXTX_REG145_RXES_ENA_SET(data, 1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG145__ADDR + (0x200 * ch) + sds2_offset, data);

  //RX control
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG2_RESETB_TERM_SET(data, 0x0);
  data = FIELD_CH0_RXTX_REG2_VTT_ENA_SET(data, 0x1);
  data = FIELD_CH0_RXTX_REG2_VTT_SEL_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG1__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG1_RXACVCM_SET(data, 0x7);
  data = FIELD_CH0_RXTX_REG1_RXVREG1_SET(data, 0x2);
  data = FIELD_CH0_RXTX_REG1_RXVREG1P2_SET(data, 0x0);
  data = FIELD_CH0_RXTX_REG1_RXIREF_ADJ_SET(data, 0x2);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG1__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG12_RX_DET_TERM_ENABLE_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG148__ADDR + (0x200 * ch) + sds2_offset);
  data = 0xffff; //rx bist word count 0 
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG148__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG149__ADDR + (0x200 * ch) + sds2_offset);
  data = 0xffff; //rx bist word count 1 
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG149__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG150__ADDR + (0x200 * ch) + sds2_offset);
  data = 0xffff; //rx bist word count 2 
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG150__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG151__ADDR + (0x200 * ch) + sds2_offset);
  data = 0xffff; //rx bist word count 3 
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG151__ADDR + (0x200 * ch) + sds2_offset, data);


  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG1__ADDR + (0x200 * ch) + sds2_offset);
  //data = FIELD_CH0_RXTX_REG1_RXVREG1_SET(data, 0x2);  //daniel, test code
  //data = FIELD_CH0_RXTX_REG1_RXIREF_ADJ_SET(data, 0x2); //daniel, test code
  data = FIELD_CH0_RXTX_REG1_CTLE_EQ_SET(data, ctle_eq[PLATFORM][ch+ (sds2 *4)]);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG1__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG0__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG0_CTLE_EQ_FR_SET(data, 0x10);
  data = FIELD_CH0_RXTX_REG0_CTLE_EQ_QR_SET(data, 0x10);
  data = FIELD_CH0_RXTX_REG0_CTLE_EQ_HR_SET(data, 0x10);
pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG0__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG12_LATCH_OFF_ENA_SET(data, 0x1);
pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG128__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG128_LATCH_CAL_WAIT_SEL_SET(data, 0x3);
pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG128__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG8__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG8_CDR_LOOP_ENA_SET(data, 0x1);
  data = FIELD_CH0_RXTX_REG8_CDR_BYPASS_RXLOS_SET(data, 0x0);
  data = FIELD_CH0_RXTX_REG8_SD_VREF_SET(data, 0x4); //130830, added to remove SD glitch
pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG8__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG125__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG125_PQ_REG_SET(data, pq[PLATFORM][ch+(sds2*4)]);  //140624: bertscope receiver test shows 0x11 is best result
//  data = FIELD_CH0_RXTX_REG125_PQ_REG_SET(data, pq_val);  //140624: bertscope receiver test shows 0x11 is best result
  data = FIELD_CH0_RXTX_REG125_PHZ_MANUAL_SET(data, 0x1);
pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG125__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG11__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG11_PHASE_ADJUST_LIMIT_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG11__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset);
  #ifdef RX_SSC_ENB
    data = FIELD_CH0_RXTX_REG61_LOADFREQ_SHIFT_SET(data, 0x0);
  #else 
    data = FIELD_CH0_RXTX_REG61_LOADFREQ_SHIFT_SET(data, 0x1);
  #endif
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG102__ADDR + (0x200 * ch) + sds2_offset);
  #ifdef RX_SSC_ENB
    data = FIELD_CH0_RXTX_REG102_FREQLOOP_LIMIT_SET(data, 0x0);
  #else
    data = FIELD_CH0_RXTX_REG102_FREQLOOP_LIMIT_SET(data, 0x3);
  #endif
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG102__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG8__ADDR + (0x200 * ch) + sds2_offset);
  #ifdef RX_SSC_ENB
    data = FIELD_CH0_RXTX_REG8_SSC_ENABLE_SET(data, 0x1);
  #else
    data = FIELD_CH0_RXTX_REG8_SSC_ENABLE_SET(data, 0x0);
  #endif
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG8__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG96__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG96_MU_FREQ1_SET(data, 0x10);
  data = FIELD_CH0_RXTX_REG96_MU_FREQ2_SET(data, 0x10);
  data = FIELD_CH0_RXTX_REG96_MU_FREQ3_SET(data, 0x10);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG96__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG97__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG97_MU_FREQ4_SET(data, 0x10);
  data = FIELD_CH0_RXTX_REG97_MU_FREQ5_SET(data, 0x10);
  data = FIELD_CH0_RXTX_REG97_MU_FREQ6_SET(data, 0x10);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG97__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG98__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG98_MU_FREQ7_SET(data, 0x10);
  data = FIELD_CH0_RXTX_REG98_MU_FREQ8_SET(data, 0x10);
  data = FIELD_CH0_RXTX_REG98_MU_FREQ9_SET(data, 0x10);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG98__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG99__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG99_MU_PHASE1_SET(data, 0x6); 
  data = FIELD_CH0_RXTX_REG99_MU_PHASE2_SET(data, 0x6); 
  data = FIELD_CH0_RXTX_REG99_MU_PHASE3_SET(data, 0x6);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG99__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG100__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG100_MU_PHASE4_SET(data, 0x6);
  data = FIELD_CH0_RXTX_REG100_MU_PHASE5_SET(data, 0x6);
  data = FIELD_CH0_RXTX_REG100_MU_PHASE6_SET(data, 0x6);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG100__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG101__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG101_MU_PHASE7_SET(data, 0x6);
  data = FIELD_CH0_RXTX_REG101_MU_PHASE8_SET(data, 0x6);
  data = FIELD_CH0_RXTX_REG101_MU_PHASE9_SET(data, 0x6);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG101__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG8__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG8_SD_DISABLE_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG8__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG26__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG26_BLWC_ENA_SET(data, 0x1); 
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG26__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG81__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG81_MU_DFE1_SET(data, 0xe);  //these are 0x6 for gen3
  data = FIELD_CH0_RXTX_REG81_MU_DFE2_SET(data, 0xe);
  data = FIELD_CH0_RXTX_REG81_MU_DFE3_SET(data, 0xe);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG81__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG82__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG82_MU_DFE4_SET(data, 0xe);  //these are 0x6 for gen3
  data = FIELD_CH0_RXTX_REG82_MU_DFE5_SET(data, 0xe);
  data = FIELD_CH0_RXTX_REG82_MU_DFE6_SET(data, 0xe);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG82__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG83__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG83_MU_DFE7_SET(data, 0xe); //these are 0x6 for gen3
  data = FIELD_CH0_RXTX_REG83_MU_DFE8_SET(data, 0xe);
  data = FIELD_CH0_RXTX_REG83_MU_DFE9_SET(data, 0xe);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG83__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG84__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG84_MU_PH1_SET(data, 0xe); //these are 0x6 for gen3
  data = FIELD_CH0_RXTX_REG84_MU_PH2_SET(data, 0xe);
  data = FIELD_CH0_RXTX_REG84_MU_PH3_SET(data, 0xe);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG84__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG85__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG85_MU_PH4_SET(data, 0xe);//these are 0x6 for gen3
  data = FIELD_CH0_RXTX_REG85_MU_PH5_SET(data, 0xe);
  data = FIELD_CH0_RXTX_REG85_MU_PH6_SET(data, 0xe);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG85__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG86__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG86_MU_PH7_SET(data, 0xe);//these are 0x6 for gen3
  data = FIELD_CH0_RXTX_REG86_MU_PH8_SET(data, 0xe);
  data = FIELD_CH0_RXTX_REG86_MU_PH9_SET(data, 0xe);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG86__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG87__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG87_MU_TH1_SET(data, 0xe);//these are 0x6 for gen3
  data = FIELD_CH0_RXTX_REG87_MU_TH2_SET(data, 0xe);
  data = FIELD_CH0_RXTX_REG87_MU_TH3_SET(data, 0xe);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG87__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG88__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG88_MU_TH4_SET(data, 0xe);//these are 0x6 for gen3
  data = FIELD_CH0_RXTX_REG88_MU_TH5_SET(data, 0xe);
  data = FIELD_CH0_RXTX_REG88_MU_TH6_SET(data, 0xe);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG88__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG89__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG89_MU_TH7_SET(data, 0xe);//these are 0x6 for gen3
  data = FIELD_CH0_RXTX_REG89_MU_TH8_SET(data, 0xe);
  data = FIELD_CH0_RXTX_REG89_MU_TH9_SET(data, 0xe);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG89__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG90__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG90_MU_BCA1_SET(data, 0xb);
  data = FIELD_CH0_RXTX_REG90_MU_BCA2_SET(data, 0xb);
  data = FIELD_CH0_RXTX_REG90_MU_BCA3_SET(data, 0xb);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG90__ADDR + (0x200 * ch) + sds2_offset, data);
  
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG91__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG91_MU_BCA4_SET(data, 0xb);
  data = FIELD_CH0_RXTX_REG91_MU_BCA5_SET(data, 0xb);
  data = FIELD_CH0_RXTX_REG91_MU_BCA6_SET(data, 0xb);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG91__ADDR + (0x200 * ch) + sds2_offset, data);
  
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG92__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG92_MU_BCA7_SET(data, 0xb);
  data = FIELD_CH0_RXTX_REG92_MU_BCA8_SET(data, 0xb);
  data = FIELD_CH0_RXTX_REG92_MU_BCA9_SET(data, 0xb);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG92__ADDR + (0x200 * ch) + sds2_offset, data);


  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG145__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG145_RXDFE_CONFIG_SET(data, 0x3);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG145__ADDR + (0x200 * ch) + sds2_offset, data);

  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG28__ADDR + (0x200 * ch) + sds2_offset, rxdfe[PLATFORM][ch+(sds2*4)]);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG7_RESETB_RXD_SET(data, 0x1);
  data = FIELD_CH0_RXTX_REG7_LOOP_BACK_ENA_CTLE_SET(data, 0x0);
  data = FIELD_CH0_RXTX_REG7_BIST_ENA_RX_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG12_RX_INV_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG2_TX_FIFO_ENA_SET(data, 0x1);
  data = FIELD_CH0_RXTX_REG2_RESETB_TXD_SET(data, 0x1);
  data = FIELD_CH0_RXTX_REG2_BIST_ENA_TX_SET(data, 0x0);
  data = FIELD_CH0_RXTX_REG2_TX_INV_SET(data, 0x0);
  data = FIELD_CH0_RXTX_REG2_TX_RCVDET_SEL_SET(data , 3); //20130732: receiver detect change
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (0x200 * ch) + sds2_offset, data);

  //130212
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG6__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG6_TXAMP_ENA_SET(data, 0x1);
  data = FIELD_CH0_RXTX_REG6_TXAMP_CNTL_SET(data, 0xf);
  data = FIELD_CH0_RXTX_REG6_TX_IDLE_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG6__ADDR + (0x200 * ch) + sds2_offset, data);

  //130212
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG5__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG5_TX_CN2_SET(data, 0x2);  //130307, value of 2 better for gen3 and good enough for gen2
  data = FIELD_CH0_RXTX_REG5_TX_CP1_SET(data, 0xf);
  data = FIELD_CH0_RXTX_REG5_TX_CN1_SET(data, 0x2);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG5__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG4_TX_LOOPBACK_BUF_EN_SET(data, 0x0);
  data = FIELD_CH0_RXTX_REG4_COUNTER_TIME_SEL_CP_SET(data, 0x7); //140626: BCA ack timerout counter
  data = FIELD_CH0_RXTX_REG4_COUNTER_TIME_SEL_CN_SET(data, 0x7);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR + (0x200 * ch) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG145__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG145_TX_IDLE_SATA_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG145__ADDR + (0x200 * ch) + sds2_offset, data);

}

void manual_cal(uint32_t pcie_core_id, uint32_t link_width){
uint32_t data, i, momsel_gen3, momsel, ref_2_gen3, ref_2_gen1;
uint64_t temp;
    #ifdef REF_DIVIDE2
     ref_2_gen1 = 1;
    #else
     ref_2_gen1 = 0;
    #endif 

    #ifdef REF_DIVIDE2_GEN3
     ref_2_gen3 = 1;
    #else
     ref_2_gen3 = 0;
    #endif 

    #ifdef MOMSEL_AUTO
    momsel = get_momsel(pcie_core_id, 0, 0, ref_2_gen1);
    momsel_gen3 = get_momsel(pcie_core_id, 0, 1, ref_2_gen3);
    printf("MOMSEL 0x%x, MOMSEL_8G 0x%x, pcie_core_id 0x%x, serdes 0 \n\r", momsel, momsel_gen3, pcie_core_id);
    #else
    momsel = 0xa;
    //momsel_pcie = 0x1b;
    momsel_gen3 = 0x19;
    #endif

   // lprintf(5,"pcie_core_id 0x%x,PLL manual calibration on serdes 0 \n\r", pcie_core_id);
    //PLL manual calibration
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG4__ADDR);
    data = FIELD_CMU_REG4_VCO_MANMOMSEL_PCIE_SET(data, momsel_gen3);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG4__ADDR, data);

    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG3__ADDR);
    data = FIELD_CMU_REG3_VCO_MANMOMSEL_SET(data, momsel);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG3__ADDR, data);
    
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG1__ADDR);
    data = FIELD_CMU_REG1_PLL_MANUALCAL_SET(data, 0x1);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG1__ADDR, data);
    
    if (link_width == 8){
        #ifdef MOMSEL_AUTO
        momsel = get_momsel(pcie_core_id, 1, 0, ref_2_gen1);
        momsel_gen3 = get_momsel(pcie_core_id, 1, 1, ref_2_gen3);
        printf("MOMSEL 0x%x, MOMSEL_8G 0x%x, pcie_core_id 0x%x, serdes 1 \n\r", momsel, momsel_gen3, pcie_core_id);
        #endif
        
       // lprintf(5,"pcie_core_id 0x%x,PLL manual calibration on serdes 1 \n\r", pcie_core_id);
        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG4__ADDR);
        data = FIELD_CMU_REG4_VCO_MANMOMSEL_PCIE_SET(data, momsel_gen3);
        pcie_phy_csr_write(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG4__ADDR, data);

        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG3__ADDR);
        data = FIELD_CMU_REG3_VCO_MANMOMSEL_SET(data, momsel);
        pcie_phy_csr_write(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG3__ADDR, data);
        
        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG1__ADDR);
        data = FIELD_CMU_REG1_PLL_MANUALCAL_SET(data, 0x1);
        pcie_phy_csr_write(pcie_core_id, KC_SERDES2_CMU_REGS_CMU_REG1__ADDR, data);

    }

}


uint32_t get_momsel(uint32_t pcie_core_id, uint32_t sds, uint32_t pll_8g, uint32_t div2){
  int sds_offset, data, cal_done=0;
  int pll_refdiv, pll_fbdiv, default_pll_refdiv, default_pll_fbdiv;
  uint32_t momsel;

  if (sds){
    sds_offset = 0x30000;
  } else {
    sds_offset = 0x0;
  }

  //set pll reference clock divider and feedback divider
  // div2 is reference clock divide by 2 option
  if (pll_8g){
      if (div2) {pll_refdiv = 0x1; pll_fbdiv  = 0x4f;}
      else      {pll_refdiv = 0x0; pll_fbdiv  = 0x27;}
  } else {
     if (div2) {pll_refdiv = 0x1; pll_fbdiv = 0x63;}
     else      {pll_refdiv = 0x0; pll_fbdiv = 0x31;}
  }
  
  //reset PLL to clear any previous status flag
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG5__ADDR + sds_offset);
  data = FIELD_CMU_REG5_PLL_RESETB_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG5__ADDR + sds_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG5__ADDR + sds_offset);
  data = FIELD_CMU_REG5_PLL_RESETB_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG5__ADDR + sds_offset, data);

  //lprintf(5,"Getting MOMSEL on pcie_core 0x%x, serdes 0x%x, 8G_PLL 0x%x, REF/2 0x%x \n\r", pcie_core_id, sds, pll_8g, div2);
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG33__ADDR + sds_offset);
  data = FIELD_CMU_REG33_CUSTOMER_MODE_INV_SET(data, 0xffff);
  pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG33__ADDR + sds_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG30__ADDR + sds_offset);
  data = FIELD_CMU_REG30_PCIE_MODE_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG30__ADDR + sds_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG1__ADDR + sds_offset);
  data = FIELD_CMU_REG1_PLL_MANUALCAL_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG1__ADDR + sds_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG2__ADDR + sds_offset);
  default_pll_refdiv = FIELD_CMU_REG2_PLL_REFDIV_RD(data);
  default_pll_fbdiv  = FIELD_CMU_REG2_PLL_FBDIV_RD(data);
  data = FIELD_CMU_REG2_PLL_REFDIV_SET(data, pll_refdiv);
  data = FIELD_CMU_REG2_PLL_FBDIV_SET(data, pll_fbdiv);
  pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG2__ADDR + sds_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG9__ADDR + sds_offset);
  data = FIELD_CMU_REG9_PLL_POST_DIVBY2_SET(data, 0x1);
  data = FIELD_CMU_REG9_VBG_BYPASSB_SET(data, 0x0);
  data = FIELD_CMU_REG9_IGEN_BYPASS_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG9__ADDR + sds_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG10__ADDR + sds_offset);
  data = FIELD_CMU_REG10_VREG_REFSEL_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG10__ADDR + sds_offset, data);  

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG34__ADDR + sds_offset);
  data = FIELD_CMU_REG34_VCO_CAL_VTH_LO_MAX_SET(data, 0x8);
  data = FIELD_CMU_REG34_VCO_CAL_VTH_HI_MAX_SET(data, 0x8);
  data = FIELD_CMU_REG34_VCO_CAL_VTH_LO_MIN_SET(data, 0x5);
  data = FIELD_CMU_REG34_VCO_CAL_VTH_HI_MIN_SET(data, 0x5);
  pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG34__ADDR + sds_offset, data);

data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG0__ADDR + sds_offset);
data = FIELD_CMU_REG0_CAL_COUNT_RESOL_SET(data, 0x7);
pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG0__ADDR + sds_offset, data);

//do VCO Calibration until calibration is successsful
while (1) {
data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG32__ADDR + sds_offset);
data = FIELD_CMU_REG32_FORCE_VCOCAL_START_SET(data, 0x1);
pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG32__ADDR + sds_offset, data);

data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG32__ADDR + sds_offset);
data = FIELD_CMU_REG32_FORCE_VCOCAL_START_SET(data, 0x0);
pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG32__ADDR + sds_offset, data);

do {
data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG7__ADDR + sds_offset);
cal_done = FIELD_CMU_REG7_PLL_CALIB_DONE_RD(data); 
} while (!cal_done);

if (FIELD_CMU_REG7_VCO_CAL_FAIL_RD(data) == 0x0){
    //calibration successful, record momsel value and reset PLL to clear VCO calibration status
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG19__ADDR + sds_offset);
    momsel = FIELD_CMU_REG19_PLL_VCOMOMSEL_RD(data);
    
    break;
} else {
    //if calibration failed, power down and reset PLL. do calibration again
    printf("MOMSEL CAL failed, retry ..... \n");
	data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG0__ADDR + sds_offset);
    data = FIELD_CMU_REG0_PDOWN_SET(data, 0x1);
    pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG0__ADDR + sds_offset, data);

    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG0__ADDR + sds_offset);
    data = FIELD_CMU_REG0_PDOWN_SET(data, 0x0);
    pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG0__ADDR + sds_offset, data);
    
    USDELAY(1);
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG5__ADDR + sds_offset);
    data = FIELD_CMU_REG5_PLL_RESETB_SET(data, 0x0);
    pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG5__ADDR + sds_offset, data);

    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG5__ADDR + sds_offset);
    data = FIELD_CMU_REG5_PLL_RESETB_SET(data, 0x1);
    pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG5__ADDR + sds_offset, data);
}
}


//restore GEN1/GEN2 pll div setting
data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG2__ADDR + sds_offset);
data = FIELD_CMU_REG2_PLL_REFDIV_SET(data, default_pll_refdiv);
data = FIELD_CMU_REG2_PLL_FBDIV_SET(data, default_pll_fbdiv);
pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG2__ADDR + sds_offset, data);

data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG9__ADDR + sds_offset);
data = FIELD_CMU_REG9_PLL_POST_DIVBY2_SET(data, 0x1);
pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG9__ADDR + sds_offset, data);

data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG33__ADDR + sds_offset);
data = FIELD_CMU_REG33_CUSTOMER_MODE_INV_SET(data, 0x0);
pcie_phy_csr_write(pcie_core_id,  KC_SERDES_CMU_REGS_CMU_REG33__ADDR + sds_offset, data);

return momsel;
}


void sm_pcie_release_phy_reset(uint32_t pcie_core_id){
  uint32_t data;

  lprintf(5,"Deasserting the PHY reset now.\n\r");
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_SRST__ADDR);
  data = FIELD_PCIE_SRST_PHY_SDS_RESET_SET(data, 0);
  pcie_csr_write(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_SRST__ADDR, data);
}  

void sm_pcie_wait_phy_rdy(uint32_t pcie_core_id){
  uint32_t data;

  lprintf(5,"Waiting for the PHY to be ready\n\r");
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_PCIECORE_CTLANDSTATUS__ADDR);
  data = data & FIELD_PCIECORE_CTLANDSTATUS_PIPE_PHY_STATUS_MASK;
  while(data != 0) {
    data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS0_CMU_STATUS0__ADDR);
    lprintf(5,"PLL lock status is "); putnum_pcie(data); lprintf(5,"\n\r");

    data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_PCIECORE_CTLANDSTATUS__ADDR);
    data = data & FIELD_PCIECORE_CTLANDSTATUS_PIPE_PHY_STATUS_MASK;
    lprintf(5," Inside while--- polling for PHY_STATUS to be deasserted\n\r");
  }

  lprintf(5," PHY_STATUS deasserted. PHY is ready now. \n\r");
};  

void sm_pcie_init_csr_clkrst(uint32_t pcie_core_id) {
  uint32_t data;
  uint32_t i;
 
  lprintf(5,"First putting everything in reset\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_SRST__ADDR, 0xFFFFFFFF);
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_SRST__ADDR);

  lprintf(5,"Now, disabling the clks\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_CLKEN__ADDR, 0);
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_CLKEN__ADDR);

  MSDELAY(1);

  lprintf(5,"Enabling the CSR, axi_core and apb_core clocks, to enable PCIE controller as well as subsystem register access.\n\r");
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_CLKEN__ADDR);
  data = FIELD_PCIE_CLKEN_CSR_CLKEN_SET(data, 1);
  data = FIELD_PCIE_CLKEN_AXI_CORE_CLKEN_SET(data, 1);
  data = FIELD_PCIE_CLKEN_APB_CORE_CLKEN_SET(data, 1);
  pcie_csr_write(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_CLKEN__ADDR, data);

  lprintf(5,"Deasserting the corresponding resets now.\n\r");
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_SRST__ADDR);
  data = FIELD_PCIE_SRST_CSR_RESET_SET(data, 0);
  data = FIELD_PCIE_SRST_AXI_CORE_RESET_SET(data, 0);
  data = FIELD_PCIE_SRST_APB_CORE_RESET_SET(data, 0);
  pcie_csr_write(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_SRST__ADDR, data);
};

void sm_pcie_init_core_clkrst(uint32_t pcie_core_id) {
  uint32_t data;
  
  lprintf(5,"Enabling the core clock, to enable the link up.\n\r");
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_CLKEN__ADDR);
  data = FIELD_PCIE_CLKEN_CORE_CLKEN_SET(data, 1);
  pcie_csr_write(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_CLKEN__ADDR, data);

  lprintf(5,"Deasserting the core reset.\n\r");
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_SRST__ADDR);
  data = FIELD_PCIE_SRST_CORE_RESET_SET(data, 0);
  pcie_csr_write(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_SRST__ADDR, data);
};  

void sm_pcie_assert_core_reset(uint32_t pcie_core_id) {
  uint32_t data;

  lprintf(5,"Asserting the core reset.\n\r");
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_SRST__ADDR);
  data = FIELD_PCIE_SRST_CORE_RESET_SET(data, 0x1); 
  pcie_csr_write(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_SRST__ADDR, data);
};  

void sm_pcie_disable_core_clk(uint32_t pcie_core_id) {
  uint32_t data;

  lprintf(5,"Disabling the core clock.\n\r");
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_CLKEN__ADDR);
  data = FIELD_PCIE_CLKEN_CORE_CLKEN_SET(data, 0);
  pcie_csr_write(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_CLKEN__ADDR, data);
};

void sm_pcie_assert_phy_reset(uint32_t pcie_core_id) {
  uint32_t data;

  lprintf(5,"Asserting the Serdes reset.\n\r");
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_SRST__ADDR);
  data = FIELD_PCIE_SRST_PHY_SDS_RESET_SET(data, 1);
  pcie_csr_write(pcie_core_id, SM_PCIE_CLKRST_CSR_PCIE_SRST__ADDR, data);
};


uint32_t extract_max_payload_size(uint32_t pcie_core_id) {
// max payload size 256B(core2) or 512B
  return (pcie_core_id == 2 ? 1 : 2);
}

void sm_pcie_init_ctrl_rc(uint32_t pcie_core_id, uint32_t gen) {
  uint32_t data;

  //Writing Class Code for Host Bridge [31:9] = 24'h06_0000
  lprintf(5," Configuring class code \n\r");
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_63_32__ADDR)); //Default 0x00001104 from .h
  data = data & ~FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_63_32_CFG_CONSTANTS_CLASS_CODE_MASK; //Clearing [31:9]
  data = data | 0x06000000; //Class Code for Host Bridge [31:9] = 24'h06_0000
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_63_32__ADDR), data);
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_63_32__ADDR));


// force link to loopbcak only
#if 0 
     data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR);
      data &= ~(0xFFF7FFFF);    // Get value of 19th bit

      if(data)
         data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR) & 0xFFF7FFFF;
      else
    	 data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR) | ~(0xFFF7FFFF);

      pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR, data);

      data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR);
      data &= ~(0xFFF7FFFF);    // Get value of 20th bit
      lprintf(5,"Direct to Loopback LTSSM state Bit 0x%x \n\r",data);

#endif

  //NWL core RP config
  //mgmt_sw_mode[459]=1; mgmt_rp_mode[456]=0;
  //Def value of NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR is 0x00014000
  lprintf(5," Configuring switch mode[459]=1 and RP mode [456]=0\n\r");
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR));
  data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_SWITCH_PORT_MODE_MASK;
  data = data & ~FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_PM_FORCE_RP_MODE_MASK;
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR), data);
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR));

  lprintf(5," Programming cfg 479_448 for rc GEN%1d\n\r", gen+1);
  if(gen == 0) {
    data = data & ~FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_SUPPORT_5GTS_MASK;
    data = data & ~FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_SUPPORT_8GTS_MASK;
  } else if (gen == 1) {
    data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_SUPPORT_5GTS_MASK;
    data = data & ~FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_SUPPORT_8GTS_MASK;
    data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_DIRECT_TO_5GTS_MASK;
    data = data & ~FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_DIRECT_TO_8GTS_MASK;
  } else {
    data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_SUPPORT_5GTS_MASK;
    data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_SUPPORT_8GTS_MASK;
    data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_DIRECT_TO_5GTS_MASK;
    data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_DIRECT_TO_8GTS_MASK;

}
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR), data);

  lprintf(5," Advertising actual credits as its RP, Bit[457]=0, bit 9 of this reg \n\r");
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR));
  
//Vv: Advertise infinite credits from RC
// Needs to check with DV team, since this is not reflecting in InitFC state of link 
// initlization  
  //  data = data & ~FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_ADVERTISE_INFINITE_CH_CD_CREDITS_AS_ROOT_PORT_MASK;
  //data = data | 0x80000000;
  data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_ADVERTISE_INFINITE_CH_CD_CREDITS_AS_ROOT_PORT_MASK;

  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR), data);
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR));
   
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0__ADDR));
  data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0_CFG_8G_CONSTANTS_MGMT_DS_PORT_TX_PRESET_SET(data, local_preset[PLATFORM]);
  data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0_CFG_8G_CONSTANTS_MGMT_US_PORT_TX_PRESET_SET(data, remote_preset[PLATFORM]);
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0__ADDR), data);
   
  #ifdef SKIP_BCA
    lprintf(5,"Skipping equalization phase 2-3 through 8g constants Bit[16] =1\n\r");
    data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0__ADDR));
    data = data | FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0_CFG_8G_CONSTANTS_DOWNSTREAM_EQ_SKIP_PHASE_2_3_MASK;
    pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0__ADDR), data);
  #endif

    //RC mode phase 3 and endpoint mode phase 2, USE_PRESET bit is set by default. select PRESET 7 for remote transmitter
    
    data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_287_256__ADDR);
    data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_287_256_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE0_SET(data, remote_bca_preset[PLATFORM]);
    data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_287_256_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE1_SET(data, remote_bca_preset[PLATFORM]);
    pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_287_256__ADDR, data);
   
    data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_319_288__ADDR);
    data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_319_288_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE2_SET(data, remote_bca_preset[PLATFORM]);
    data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_319_288_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE3_SET(data, remote_bca_preset[PLATFORM]);
    pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_319_288__ADDR, data);
    
    data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_351_320__ADDR);
    data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_351_320_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE4_SET(data, remote_bca_preset[PLATFORM]);
    data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_351_320_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE5_SET(data, remote_bca_preset[PLATFORM]);
    pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_351_320__ADDR, data);

    data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_383_352__ADDR);
    data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_383_352_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE6_SET(data, remote_bca_preset[PLATFORM]);
    data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_383_352_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE7_SET(data, remote_bca_preset[PLATFORM]);
    pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_383_352__ADDR, data);
    

    //change UP/DN step size to 2 (encoding 0 --> 1, 1--> 2, 2--> 4, 3--> 8)
    data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_159_128__ADDR);
    data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_159_128_CFG_8G_CONSTANTS_EQ_UPDN_POST_STEP_SET(data, 0x0);
    data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_159_128_CFG_8G_CONSTANTS_EQ_UPDN_PRE_STEP_SET(data, 0x0);
    pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_159_128__ADDR, data);
    

  lprintf(5,"Setting Device port type [185:182] = 4'h4 and SLOT_IMPLEMENTED [186]=1  through CFG_CONTROL\n\r");
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_191_160__ADDR));
  data = data & ~FIELD_EXPRESSO_CFG_CONTROL_CFG_CONTROL_191_160_CFG_CONTROL_PCIE_CAP_DEVICE_PORT_TYPE_MASK;
  data = data | 0x05000000; //Device port type [185:182] = 4'h4, SLOT_IMPLEMENTED [186]=1
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_191_160__ADDR), data);
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_191_160__ADDR));

// Add initlization specific to functional validation here
// Following configuraiton is not  related to PCIE link
// this is specific to initilization required for PCIE validation

  lprintf(5,"Enabling ASPM L0s and L1 support\n\r");
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_95_64__ADDR));
  data |= 2 << 26;

  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_95_64__ADDR,data);
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_95_64__ADDR));

  lprintf(5,"Enabling ASPM L1 power management\n\r");
  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_415_384__ADDR);
  data |= FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_415_384_CFG_CONSTANTS_ENABLE_L1S_POWER_MGMT_MASK;
  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_415_384__ADDR, data);

  lprintf(5,"Make ignore_poison bit to 0 to test AER \n\r");

  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_511_480__ADDR);
  data &= ~FIELD_NWL_PCIE_DMA_CFG_CONSTANTS_511_480_IGNORE_POISON_MASK;
  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_511_480__ADDR, data);

#ifdef Change4
//#ifdef PERF_MEASURMENT
  // Enable Cut through mode

  lprintf(5,"Enabling cut through settings \n\r");
  data=pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_PCIE_TX_CUT_THROUGH__ADDR));
  data = data | 0x1;
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_PCIE_TX_CUT_THROUGH__ADDR), data);

  data=pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_PCIE_TX_CUT_THROUGH__ADDR));
  lprintf(5,"CUT THROUGH");putnum_pcie(data);lprintf(5,"\n\r");

  data=pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_M_MAX__ADDR));
  data=0x00;
  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_M_MAX__ADDR, data);

  data=pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_M_MAX__ADDR));
  lprintf(5,"CFG_M_MAX");putnum_pcie(data);lprintf(5,"\n\r");

#ifdef Change5

  data=pcie_csr_read(pcie_core_id, (SM_PCIE_CSR_REGS_PCIECORE_LTSSM__ADDR));
//  data = data | (0x5<<24);
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PCIECORE_LTSSM__ADDR,data);
#endif

  data=pcie_csr_read(pcie_core_id, (SM_PCIE_CSR_REGS_PCIECORE_LTSSM__ADDR));
  lprintf(5,"LTSSM");putnum_pcie(data);lprintf(5,"\n\r");

#endif

 // pcie_csr_write(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_63_32__ADDR,3);

  config_ib_regs(pcie_core_id, RC);
};

void sm_pcie_init_ctrl_ep(uint32_t pcie_core_id, uint32_t gen){
  uint32_t data;

//NWL core EP config
//mgmt_sw_mode[459]=0; mgmt_rp_mode[456]=0;
//Def value of NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR is 0x00014000

//  pcie_csr_write(pcie_core_id,  NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_31_0__ADDR, EP_DEV_VEN_ID);

  lprintf(5," Configuring switch mode[459]=0 and RP mode [456]=0\n\r");
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR));
  data = data & ~FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_SWITCH_PORT_MODE_MASK;
  data = data & ~FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_PM_FORCE_RP_MODE_MASK;
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR), data);
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR));

  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR));
  lprintf(5," Programming cfg 479_448 for ep GEN%1d\n\r", gen+1);
  if(gen == 0) {
    data = data & ~FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_SUPPORT_5GTS_MASK;
    data = data & ~FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_SUPPORT_8GTS_MASK;
  } else if (gen == 1) {
    data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_SUPPORT_5GTS_MASK;
    data = data & ~FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_SUPPORT_8GTS_MASK;
  } else {
    data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_SUPPORT_5GTS_MASK;
    data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_SUPPORT_8GTS_MASK;
  }
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR), data);
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR));
   
  lprintf(5," Advertising Infinite credits as its EP, Bit[457]=1, bit 9 of this reg \n\r");
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR));
  data = data | FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_ADVERTISE_INFINITE_CH_CD_CREDITS_AS_ROOT_PORT_MASK;
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR), data);
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR));

  lprintf(5," For EP Setting Device port type [185:182] = 4'h0 and SLOT_IMPLEMENTED [186]=0  through CFG_CONTROL\n\r");
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_191_160__ADDR));
  data = data & ~FIELD_EXPRESSO_CFG_CONTROL_CFG_CONTROL_191_160_CFG_CONTROL_PCIE_CAP_DEVICE_PORT_TYPE_MASK;
  data = data & ~FIELD_EXPRESSO_CFG_CONTROL_CFG_CONTROL_191_160_CFG_CONTROL_PCIE_CAP_SLOT_IMPLEMENTED_MASK; 
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_191_160__ADDR), data);
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_191_160__ADDR));

  // Enable this and program for genrating  INTx supprt interrupts.

  lprintf(5,"Programming for Int Support :  EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_159_128 \n\r");

  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_159_128__ADDR));
  data = data | 0x00000001;         // Currently supported only INTx

  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_159_128__ADDR), data);
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_159_128__ADDR));

#ifdef Change4
//#ifdef PERF_MEASURMENT
  // Enable Cut through mode

  lprintf(5,"Enabling cut through settings \n\r");
  data=pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_PCIE_TX_CUT_THROUGH__ADDR));
  data = data | 0x1;
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_PCIE_TX_CUT_THROUGH__ADDR), data);

  data=pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_PCIE_TX_CUT_THROUGH__ADDR));
  lprintf(5,"CUT THROUGH");putnum_pcie(data);lprintf(5,"\n\r");

  data=pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_M_MAX__ADDR));
  data=0x00;
  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_M_MAX__ADDR, data);

  data=pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_M_MAX__ADDR));
  lprintf(5,"CFG_M_MAX");putnum_pcie(data);lprintf(5,"\n\r");


#ifdef Change5

  data=pcie_csr_read(pcie_core_id, (SM_PCIE_CSR_REGS_PCIECORE_LTSSM__ADDR));
//  data = data | (0x5<<24);
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PCIECORE_LTSSM__ADDR,data);
#endif

#endif

  lprintf(5,"Enabling ASPM L0s and L1 support\n\r");
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_95_64__ADDR));
  data |= 2 << 26;

  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_95_64__ADDR,data);
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_95_64__ADDR));

  lprintf(5,"Enabling L1 power management\n\r");
  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_415_384__ADDR);
  data |= FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_415_384_CFG_CONSTANTS_ENABLE_L1S_POWER_MGMT_MASK;
  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_415_384__ADDR, data);
  lprintf(5,"Enabling D3_Cold power management\n\r");
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_POWERMANAGEMENTREG__ADDR);
   data |= 0x1000000;
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_POWERMANAGEMENTREG__ADDR, data);


  lprintf(5,"Make ignore_poison bit to 0 to test AER \n\r");

  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_511_480__ADDR);
  data &= ~FIELD_NWL_PCIE_DMA_CFG_CONSTANTS_511_480_IGNORE_POISON_MASK;
  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_511_480__ADDR, data);

 // lprintf(5," Enabling #PERST for GPIO as Interrupt \n\r");
 // InitPERST_EP(pcie_core_id);

//  pcie_csr_write(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_63_32__ADDR,3);
  config_ib_regs(pcie_core_id, EP);
};  


unsigned int wait_linkup(int pcie_core_id, int speed, int width){
 int data, link_speed, link_width;
  int status = 0;
  int linkup = 0;
  int cnt=100;
  
  do {
	  if(cnt==0){
  		printf("LINKUP timeout \n\r");
	    return (NO_LINK);                               // Return 0 to indicate linkup Fail and make exit from here
		break;
	  }
	  MSDELAY(100);
      //polling for DL LinkUp
      data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_PCIECORE_CTLANDSTATUS__ADDR);
      linkup = FIELD_PCIECORE_CTLANDSTATUS_S_LINK_UP_RD(data);        
	  cnt--;
	 } while (!linkup);

  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_31_0__ADDR);
  link_speed = (data & 0x03000000) >> 24;
  link_width = (data & 0xfc000000) >> 26;
  if (link_speed != speed || link_width != width){
    printf("link width/gen mismatch, current width %d, gen %d \n\r", link_width, link_speed+1);
	return(WRONG_LINK);                             // Return 2 to indicate Link up is there but with incorrect negotiation.
  } else {
#ifndef BLT_TEST  
    printf("link up GOOD \n\r")
    printf("current width %d, gen %d \n\r", link_width, link_speed+1);
#endif    
    return CORRECT_LINK;
  }
};

void sm_pcie_init_ven_msg_capture(uint32_t pcie_core_id) {
  uint32_t data;

  lprintf(5,"Programming the message capture and mask registers for vendor defined messages\n\r");
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_MESSAGECODEREG__ADDR);
  data = (0x7e & FIELD_MESSAGECODEREG_MESSAGECODECAPTREG_MASK);
  data = FIELD_MESSAGECODEREG_MESSAGECODEMASKREG_SET(data, 0x1);

  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_MESSAGECODEREG__ADDR, data);

  lprintf(5,"Enabling the support for vendor defined messages as well as capture of them.\n\r");
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_RXMESSAGESTATUSREG__ADDR);

  data |= FIELD_RXMESSAGESTATUSREG_MESSAGECAPTURE_ENABLE_MASK;
  data |= FIELD_RXMESSAGESTATUSREG_SUPPORTVENDORDEFINEDMESSAGES_MASK;

  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_RXMESSAGESTATUSREG__ADDR, data);
};  

void pcie_ddr_remap(void)
{
#define DDR_SIZE    0x200000000   //8GB
  static int ddr_remap = 0;
  int i;

#ifdef VBIOS    //temp fix for DDR
  if(ddr_remap == 0) {
//    mmu_unmap(0xe000000000, DDR_SIZE);           //to remove existing direct VA->PA mapping during boot
//    mmu_map(0xe000000000, 0xe00000000, DDR_SIZE); //to remap PA to new 36 bit virtual addr 0xe00000000, 
    flat_map(0xA000000000,DDR_SIZE, 0);           //0x500000,0);  //PCIe 3 5MB
    ddr_remap = 3;
  }
#endif
}



void clkmacro_cal(uint32_t pcie_core_id) {
 uint32_t data, pvt_done;

 data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_CLK_MACRO_REG__ADDR); //Hardcoding address as Define needs change
 data = FIELD_PCIE_CLK_MACRO_REG_I_RESET_B_SET(data, 0x0);
 data = FIELD_PCIE_CLK_MACRO_REG_I_PLL_FBDIV_SET(data, 0x27);
 data = FIELD_PCIE_CLK_MACRO_REG_I_CUSTOMEROV_SET(data, 0x0);
 data = FIELD_PCIE_CLK_MACRO_REG_I_OE_SET(data, 0x3);
 pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_CLK_MACRO_REG__ADDR, data);
 

 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG34__ADDR );
 data = FIELD_CMU_REG34_VCO_CAL_VTH_LO_MAX_SET(data, 0x7);
 data = FIELD_CMU_REG34_VCO_CAL_VTH_HI_MAX_SET(data, 0xd);
 data = FIELD_CMU_REG34_VCO_CAL_VTH_LO_MIN_SET(data, 0x2);
 data = FIELD_CMU_REG34_VCO_CAL_VTH_HI_MIN_SET(data, 0x8);
 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG34__ADDR , data);

 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG0__ADDR);
 data =  FIELD_CMU_REG0_CAL_COUNT_RESOL_SET(data, 0x6);
 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG0__ADDR, data);

 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG1__ADDR);
 data =  FIELD_CMU_REG1_PLL_CP_SET(data, 0x1);     
 data =  FIELD_CMU_REG1_PLL_CP_SEL_SET(data, 0x1);
 data = FIELD_CMU_REG1_PLL_MANUALCAL_SET(data, 0x0);
 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG1__ADDR, data);

 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG2__ADDR);
 data =  FIELD_CMU_REG2_PLL_LFRES_SET(data, 0x1);
 data = FIELD_CMU_REG2_PLL_REFDIV_SET(data, 0x1);
 data = FIELD_CMU_REG2_PLL_FBDIV_SET(data, 0x4f);
 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG2__ADDR, data); 

 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG3__ADDR);
 data = FIELD_CMU_REG3_VCOVARSEL_SET(data,0xf);
 data = FIELD_CMU_REG3_VCO_MOMSEL_INIT_SET(data,0x10); 
 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG3__ADDR, data);

 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG26__ADDR);
 data = FIELD_CMU_REG26_FORCE_PLL_LOCK_SET(data,0x0);
 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG26__ADDR, data);


 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG5__ADDR);
 data = FIELD_CMU_REG5_PLL_LFSMCAP_SET(data,0x0); 
 data = FIELD_CMU_REG5_PLL_LFCAP_SET(data,0x3); 
 data = FIELD_CMU_REG5_PLL_LOCK_RESOLUTION_SET(data,0x7);
 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG5__ADDR, data);

 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG6__ADDR);
 data = FIELD_CMU_REG6_PLL_VREGTRIM_SET(data,0x0); 
 data = FIELD_CMU_REG6_MAN_PVT_CAL_SET(data,0x1); 
 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG6__ADDR, data);

 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR);
 data = FIELD_CMU_REG16_CALIBRATION_DONE_OVERRIDE_SET(data,0x1);
 data = FIELD_CMU_REG16_BYPASS_PLL_LOCK_SET(data,0x1); 
 data = FIELD_CMU_REG16_VCOCAL_WAIT_BTW_CODE_SET(data,0x6);
 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR, data);

 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG30__ADDR);
 data = FIELD_CMU_REG30_PCIE_MODE_SET(data,0x0); 
 data = FIELD_CMU_REG30_LOCK_COUNT_SET(data,0x3); 
 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG30__ADDR, data);

 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG31__ADDR, 0xF);

 data = pcie_phy_csr_read(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG32__ADDR);
 data |= 0x0006 | 0x0180;
 data = FIELD_CMU_REG32_PVT_CAL_WAIT_SEL_SET(data,0x3);
 data = FIELD_CMU_REG32_IREF_ADJ_SET(data,0x2); 
 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG32__ADDR, data);

 pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG34__ADDR, 0x8d27);

 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG37__ADDR);
 pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG37__ADDR, 0xF00F);

  data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG12__ADDR);
  data = FIELD_CMU_REG12_STATE_DELAY9_SET(data, 0x0);  //ready_count top
  pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG12__ADDR, data);
    
  data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG13__ADDR);
  data = FIELD_CMU_REG13_STATE_DELAY1_SET(data, 0xf); //calib_start_count_stop
  data = FIELD_CMU_REG13_STATE_DELAY2_SET(data, 0x0);//channel_start_count_stop
  data = FIELD_CMU_REG13_STATE_DELAY3_SET(data, 0x0);//reset_count_stop
  data = FIELD_CMU_REG13_STATE_DELAY4_SET(data, 0x0);//start_ctle_cal_count
  pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG13__ADDR, data);
  
  data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG14__ADDR);
  data = FIELD_CMU_REG14_STATE_DELAY5_SET(data, 0x0); //float_tap_src_ena_count_stop
  data = FIELD_CMU_REG14_STATE_DELAY6_SET(data, 0x0); //float_tap_src_count_stop
  data = FIELD_CMU_REG14_STATE_DELAY7_SET(data, 0x0); //blwc_ena_count_stop
  data = FIELD_CMU_REG14_STATE_DELAY8_SET(data, 0x0); //ready_count_stop
  pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG14__ADDR, data);
 
 data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_CLK_MACRO_REG__ADDR); //Hardcoding address as Define needs change
 data = FIELD_PCIE_CLK_MACRO_REG_I_RESET_B_SET(data, 0x1);
 pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_CLK_MACRO_REG__ADDR, data);
 
 MSDELAY(100);
 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG0__ADDR); //Hardcoding address as Define needs change
 data = FIELD_CMU_REG0_RESETB_SET(data, 0x0);
 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG0__ADDR , data);

 MSDELAY(50);
 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG0__ADDR); //Hardcoding address as Define needs change
 data = FIELD_CMU_REG0_RESETB_SET(data, 0x1);
 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG0__ADDR, data);
 
 /* NOTE: not sure where to insert this when we need it
   lprintf(5,"Enabling the SSC for the CLKMACRO\n\r");
    data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG36__ADDR);
    data |= FIELD_CMU_REG36_PLL_SSC_EN_MASK;
    pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG36__ADDR, data);
   */

pvt_done = 0;
//do {
//pvt_cal(pcie_core_id);
    lprintf(5,"wait for CMU CALIB done \n\r");
    data = 0;
    do {
    data = pcie_phy_csr_read(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG7__ADDR);
    } while(!FIELD_CMU_REG7_PLL_CALIB_DONE_RD(data));

    pvt_done = !FIELD_CMU_REG7_VCO_CAL_FAIL_RD(data);
    if(!pvt_done) {
        lprintf(5,"CMU VCO CALIB FAIL \n\r");
        
        data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_CLK_MACRO_REG__ADDR); //Hardcoding address as Define needs change
        data = FIELD_PCIE_CLK_MACRO_REG_I_RESET_B_SET(data, 0x0);
        pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_CLK_MACRO_REG__ADDR, data);
 
        data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_CLK_MACRO_REG__ADDR); //Hardcoding address as Define needs change
        data = FIELD_PCIE_CLK_MACRO_REG_I_RESET_B_SET(data, 0x1);
        pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_CLK_MACRO_REG__ADDR, data);
        vco_restart(pcie_core_id);
        
    }
//} while(!pvt_done);
lprintf(5,"clkmacro calibration done \n\r");
/*
 lprintf(5,"clkmacro waiting PLL lock.... \n\r");
    do {
        data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_CLK_MACRO_REG__ADDR);
       // lprintf(5,"Read data is"); putnum(data); lprintf(5,"Polling pll lock for CLK MACRO\n\r");
    } while (!(FIELD_PCIE_CLK_MACRO_REG_O_PLL_LOCK_RD(data) && FIELD_PCIE_CLK_MACRO_REG_O_PLL_READY_RD(data)));
*/
    MSDELAY(800);
}


int vco_pd(int argc, char *argv[]){
  uint32_t core, i=0;
  if (argc < 1) {
    lprintf(3,"not enough argument: core_id \n\r");
    return i;
  } 

  core = atoi(argv[0]);
  vco_restart(core);
}

void  vco_restart (uint32_t pcie_core_id) {
    unsigned int data;
  
     data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG0__ADDR);
     data = FIELD_CMU_REG0_PDOWN_SET(data, 1);
     pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG0__ADDR, data);

    data = pcie_phy_csr_read (pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG5__ADDR);
    data = FIELD_CMU_REG5_PLL_RESETB_SET(data,0);
    pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG5__ADDR, data);
 
    MSDELAY(800);
    data = pcie_phy_csr_read (pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG5__ADDR);
    data = FIELD_CMU_REG5_PLL_RESETB_SET(data,1);
    pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG5__ADDR, data);
 
     data = pcie_phy_csr_read (pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG0__ADDR);
     data = FIELD_CMU_REG0_PDOWN_SET(data, 0);
     pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG0__ADDR, data);

     data = pcie_phy_csr_read (pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG32__ADDR);
     data = FIELD_CMU_REG32_FORCE_VCOCAL_START_SET(data, 1);
     pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG32__ADDR, data);
    MSDELAY(800);
     
     data = pcie_phy_csr_read (pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG32__ADDR);
     data =  FIELD_CMU_REG32_FORCE_VCOCAL_START_SET(data, 0);
     pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG32__ADDR, data);
}

void pvt_cal(uint32_t pcie_core_id){
uint32_t data;

// ********************
// TERM CALIBRATION 
// ********************
 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR);
 data = FIELD_CMU_REG17_PVT_CODE_R2A_SET(data,0x0d);
 data = FIELD_CMU_REG17_RESERVED_7_SET(data,0x0); 
 pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR, data);

 data = pcie_phy_csr_read(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR);
 data = FIELD_CMU_REG17_PVT_TERM_MAN_ENA_SET(data,0x1);
 pcie_phy_csr_write(pcie_core_id, KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR, data);
 
 data = pcie_phy_csr_read(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR);
 data = FIELD_CMU_REG17_PVT_TERM_MAN_ENA_SET(data,0x0);
 pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR, data);

// *********************
// DOWN CALIBRATION
// *********************
    data = pcie_phy_csr_read(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR);
    data = FIELD_CMU_REG17_PVT_CODE_R2A_SET(data,0x26);
    data = FIELD_CMU_REG17_RESERVED_7_SET(data,0x0); 
    pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR, data);

    data = pcie_phy_csr_read(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR);
    data = FIELD_CMU_REG16_PVT_DN_MAN_ENA_SET(data,0x1);
    pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR, data);

    data = pcie_phy_csr_read(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR);
    data = FIELD_CMU_REG16_PVT_DN_MAN_ENA_SET(data,0x0);
    pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR, data);

 // *********************
// UP CALIBRATION
// *********************
    data = pcie_phy_csr_read(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR);
    data = FIELD_CMU_REG17_PVT_CODE_R2A_SET(data,0x28);
    data = FIELD_CMU_REG17_RESERVED_7_SET(data,0x0); 
    pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR, data);

    data = pcie_phy_csr_read(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR);
    data = FIELD_CMU_REG16_PVT_UP_MAN_ENA_SET(data,0x1);
    pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR, data);

    data = pcie_phy_csr_read(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR);
    data = FIELD_CMU_REG16_PVT_UP_MAN_ENA_SET(data,0x0);
    pcie_phy_csr_write(pcie_core_id,  KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR, data);
}


void set_sds_rxd_reset(int pcie_core_id, int ch, int sds2) {
int sds2_offset, data, timeout;

  if (sds2){
    sds2_offset = 0x30000;
  } else {
    sds2_offset = 0x0;
  }
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG7_RESETB_RXD_SET(data, 0x0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset, data);
  MSDELAY(10);
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG7_RESETB_RXD_SET(data, 0x1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (0x200 * ch) + sds2_offset, data);

}



void lat_summer_cal (int pcie_core_id, int ch, int sds2) {

    int data, dfe_preset, dfe;
    int sum_cal_done, lat_cal_done, sum_cal_err;
    int timeout = 0;
    int loop = 10;
    int try = 10;
    int sds2_offset = 0;
    int fail_odd = 0;
    int fail_even = 0;
    int lat_do  = 0;
    int lat_xo  = 0;
    int lat_eo  = 0;
    int lat_so  = 0;
    int lat_de  = 0;
    int lat_xe  = 0;
    int lat_ee  = 0;
    int lat_se  = 0;
    int sum_cal = 0;
    int lat_do_tmp;
    int lat_xo_tmp;
    int lat_eo_tmp;
    int lat_so_tmp;
    int lat_de_tmp;
    int lat_xe_tmp;
    int lat_ee_tmp;
    int lat_se_tmp;
    int sum_cal_tmp;
    if(sds2)
        sds2_offset = 0x30000;
    else 
        sds2_offset = 0;
    
   lprintf(5,"Manual latch/summer calibration core # 0x%x, ch #0x%x...\n\r", pcie_core_id, ch);
    
    //enable RX Hi-Z termination enable
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + sds2_offset);
    data = FIELD_CH0_RXTX_REG12_RX_DET_TERM_ENABLE_SET(data,0x0);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + sds2_offset, data);

    //clear CDR loop enable
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG8__ADDR + (0x200 * ch) + sds2_offset);
    data = FIELD_CH0_RXTX_REG8_CDR_LOOP_ENA_SET(data,0x0);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG8__ADDR + (0x200 * ch) + sds2_offset, data);

    //turn off DFE
    dfe = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG28__ADDR + (0x200 * ch) + sds2_offset);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG28__ADDR + (0x200 * ch) + sds2_offset, 0);

    //DFE presets to zero
    dfe_preset = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG31__ADDR + (0x200 * ch) + sds2_offset);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG31__ADDR + (0x200 * ch) + sds2_offset, 0);

    while (loop > 0){
        for(timeout=0; timeout<0x40000; ++timeout);
        //toggle summer cal 
        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * ch) + sds2_offset);
        data = FIELD_CH0_RXTX_REG127_FORCE_SUM_CAL_START_SET(data,0x1);
        pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * ch) + sds2_offset, data);

        for(timeout=0; timeout<0x40000; ++timeout);
        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * ch) + sds2_offset);
        data = FIELD_CH0_RXTX_REG127_FORCE_SUM_CAL_START_SET(data,0x0);
        pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * ch) + sds2_offset, data);

        do {
            data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG158__ADDR + (0x200 * ch) + sds2_offset);
            sum_cal_done =  FIELD_CH0_RXTX_REG158_SUM_CALIB_DONE_RD(data);
            sum_cal_err = FIELD_CH0_RXTX_REG158_SUM_CALIB_ERR_RD(data);
            MSDELAY(1);
        }while(!sum_cal_done && try--);
        
        data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG121__ADDR + (0x200 * ch) + sds2_offset);
        sum_cal_tmp = FIELD_CH0_RXTX_REG121_SUMOS_CAL_CODE_RD(data);

        if(sum_cal_done && !sum_cal_err){
          //  lprintf(5,"summer cal 0x%x \n\r", sum_cal_tmp);
            sum_cal += sum_cal_tmp;
            loop--;
        } else{lprintf(3,"summer cal error  done 0x%x err 0x%x \n\r", sum_cal_done, sum_cal_err);}
        set_sds_rxd_reset(pcie_core_id, ch, sds2); //digital reset only
    }

    //update SUMMER CAL value
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG14__ADDR + (0x200 * ch) + sds2_offset);
    data = FIELD_CH0_RXTX_REG14_CLTE_LATCAL_MAN_PROG_SET(data, (sum_cal/10));
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG14__ADDR + (0x200 * ch) + sds2_offset, data);

    //manual summer cal enable
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG14__ADDR + (0x200 * ch) + sds2_offset);
    data = FIELD_CH0_RXTX_REG14_CTLE_LATCAL_MAN_ENA_SET(data, 1);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG14__ADDR + (0x200 * ch) + sds2_offset, data);

    loop = 10;
    while (loop > 0){
     //toggle latch cal
     for(timeout=0; timeout<0x40000; ++timeout);
     data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * ch) + sds2_offset);
     data = FIELD_CH0_RXTX_REG127_FORCE_LAT_CAL_START_SET(data,0x1);
     pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * ch) + sds2_offset, data);

     for(timeout=0; timeout<0x40000; ++timeout);
     data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * ch) + sds2_offset);
     data = FIELD_CH0_RXTX_REG127_FORCE_LAT_CAL_START_SET(data,0x0);
     pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * ch) + sds2_offset, data);
     
     try = 200;  //this gives 200ms, should be enough for latch cal to be done
     do {
         data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG158__ADDR + (0x200 * ch) + sds2_offset);
         lat_cal_done =  FIELD_CH0_RXTX_REG158_LAT_CALIB_DONE_RD(data);
         MSDELAY(1);
     }while(!lat_cal_done && try--);
     
     //read cal value
     data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG21__ADDR + (0x200 * ch) + sds2_offset);
     lat_do_tmp = FIELD_CH0_RXTX_REG21_DO_LATCH_CALOUT_RD(data);
     lat_xo_tmp = FIELD_CH0_RXTX_REG21_XO_LATCH_CALOUT_RD(data);
     fail_odd = FIELD_CH0_RXTX_REG21_LATCH_CAL_FAIL_ODD_RD(data);

     data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG22__ADDR + (0x200 * ch) + sds2_offset);
     lat_eo_tmp = FIELD_CH0_RXTX_REG22_EO_LATCH_CALOUT_RD(data);
     lat_so_tmp = FIELD_CH0_RXTX_REG22_SO_LATCH_CALOUT_RD(data);
     fail_even = FIELD_CH0_RXTX_REG22_LATCH_CAL_FAIL_EVEN_RD(data);
     
     data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG23__ADDR + (0x200 * ch) + sds2_offset);
     lat_de_tmp = FIELD_CH0_RXTX_REG23_DE_LATCH_CALOUT_RD(data);
     lat_xe_tmp = FIELD_CH0_RXTX_REG23_XE_LATCH_CALOUT_RD(data);
     
     data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG24__ADDR + (0x200 * ch) + sds2_offset);
     lat_ee_tmp = FIELD_CH0_RXTX_REG24_EE_LATCH_CALOUT_RD(data);
     lat_se_tmp = FIELD_CH0_RXTX_REG24_SE_LATCH_CALOUT_RD(data);

     if((fail_even ==0) && (fail_odd == 0)){
        //lprintf(5,"ch 0x%x sds 0x%x ...\n\r", ch, sds2);
        //lprintf(5,"do = 0x%x de = 0x%x...\n\r", lat_do_tmp, lat_de_tmp);
        //lprintf(5,"eo = 0x%x ee = 0x%x...\n\r", lat_eo_tmp, lat_ee_tmp);
        //lprintf(5,"xo = 0x%x xe = 0x%x...\n\r", lat_xo_tmp, lat_xe_tmp);
        //lprintf(5,"so = 0x%x se = 0x%x...\n\r", lat_so_tmp, lat_se_tmp);
         lat_do += lat_do_tmp;
         lat_xo += lat_xo_tmp;
         lat_eo += lat_eo_tmp;
         lat_so += lat_so_tmp;
         lat_de += lat_de_tmp;
         lat_xe += lat_xe_tmp;
         lat_ee += lat_ee_tmp;
         lat_se += lat_se_tmp;
         loop--;
     } //else {lprintf(5,"\n iteration failed fail_even 0x%x, fail_odd 0x%x\r\n", fail_even, fail_odd);}

    set_sds_rxd_reset(pcie_core_id, ch, sds2); //digital reset only
    }

    //update LATCH
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * ch) + sds2_offset);
    data = FIELD_CH0_RXTX_REG127_DO_LATCH_MANCAL_SET(data, (lat_do/10));
    data = FIELD_CH0_RXTX_REG127_XO_LATCH_MANCAL_SET(data, (lat_xo/10));
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * ch) + sds2_offset, data);

    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG128__ADDR + (0x200 * ch) + sds2_offset);
    data = FIELD_CH0_RXTX_REG128_EO_LATCH_MANCAL_SET(data, (lat_eo/10));
    data = FIELD_CH0_RXTX_REG128_SO_LATCH_MANCAL_SET(data, (lat_so/10));
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG128__ADDR + (0x200 * ch) + sds2_offset, data);

    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG129__ADDR + (0x200 * ch) + sds2_offset);
    data = FIELD_CH0_RXTX_REG129_DE_LATCH_MANCAL_SET(data, (lat_de/10));
    data = FIELD_CH0_RXTX_REG129_XE_LATCH_MANCAL_SET(data, (lat_xe/10));
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG129__ADDR + (0x200 * ch) + sds2_offset, data);
    
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG130__ADDR + (0x200 * ch) + sds2_offset);
    data = FIELD_CH0_RXTX_REG130_EE_LATCH_MANCAL_SET(data, (lat_ee/10));
    data = FIELD_CH0_RXTX_REG130_SE_LATCH_MANCAL_SET(data, (lat_se/10));
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG130__ADDR + (0x200 * ch) + sds2_offset, data);

    //manual latch cal enable
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * ch) + sds2_offset);
    data = FIELD_CH0_RXTX_REG127_LATCH_MAN_CAL_ENA_SET(data, 1);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * ch) + sds2_offset, data);

    //restore settings
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + sds2_offset);
    data = FIELD_CH0_RXTX_REG12_RX_DET_TERM_ENABLE_SET(data,0x0);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (0x200 * ch) + sds2_offset, data);

    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG28__ADDR + (0x200 * ch) + sds2_offset, dfe);

    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG8__ADDR + (0x200 * ch) + sds2_offset);
    data = FIELD_CH0_RXTX_REG8_CDR_LOOP_ENA_SET(data,0x1);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG8__ADDR + (0x200 * ch) + sds2_offset, data);

    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG31__ADDR + (0x200 * ch) + sds2_offset, dfe_preset);
}

void lat_summer_average_cal (int pcie_core_id, int link_width){

  lprintf(5,"Force LATCH/SUMER calibration\n\r");
    if (pcie_core_id == 2) {
        lat_summer_cal(pcie_core_id, 0, 0);
    } else {
        //core 0, 1, 3, 4 will use serder 0 all the time
        //core 0, 3 has option of programing second serdes if link_width is 8
        lat_summer_cal(pcie_core_id, 0, 0);
        lat_summer_cal(pcie_core_id, 1, 0);
        lat_summer_cal(pcie_core_id, 2, 0);
        lat_summer_cal(pcie_core_id, 3, 0);
        if(link_width == 8) {
            lat_summer_cal(pcie_core_id, 0, 1);
            lat_summer_cal(pcie_core_id, 1, 1);
            lat_summer_cal(pcie_core_id, 2, 1);
            lat_summer_cal(pcie_core_id, 3, 1);
        }
    }
}

int sm_pcie_init_phy(uint32_t pcie_core_id, uint32_t port_type, uint32_t gen, uint32_t ext_ref, uint32_t link_width, uint32_t en_lpbk){
  uint32_t data, i, j, full_width = 0;
  uint32_t pll_err=1;

  //set IO PAD for MDIO  address 'h17001398, data : 1e1e1e
  cpu_write(0x17001398, 0x1e1e1e);

  set_ser_refclk(pcie_core_id, port_type, ext_ref, link_width);

  // First clear the TX_PARAMS_VALID bit of the PIPECTLREG.
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_PIPECTLREG__ADDR);
  data = FIELD_PIPECTLREG_PHY_EQ_TX_PARAMS_VALID_SET(data, 0);
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIPECTLREG__ADDR, data);

  //FS/LF adjustment from KC
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_PIPECTLREG__ADDR);
  data = FIELD_PIPECTLREG_PHY_EQ_TX_FS_SET(data, 0x36);   
  data = FIELD_PIPECTLREG_PHY_EQ_TX_LF_SET(data, 0x10);   

  data = FIELD_PIPECTLREG_PHY_EQ_TX_MAX_PRE_SET(data, 0x6); 
  data = FIELD_PIPECTLREG_PHY_EQ_TX_MAX_POST_SET(data, 0xf);
  data = FIELD_PIPECTLREG_PHY_EQ_TX_PARAMS_VALID_SET(data, 1);
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIPECTLREG__ADDR, data);
  
  //customer pin mode setting
  data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_CTL0__ADDR);
  //turn off bit 12 to give control to serdes, to correct pll feedback value
  //turn off bit 2 and 3 to correct tx amplitue and cp1/cn1/cn2  value (130212)
  #ifdef SDS_TX_CTRL
    data = FIELD_PCIE_SDS_CTL0_CFG_I_CUSTOMER_PIN_MODE_SET(data, 0x0d29); 
  #else
    data = FIELD_PCIE_SDS_CTL0_CFG_I_CUSTOMER_PIN_MODE_SET(data, 0x0d2d);
  #endif
  pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_CTL0__ADDR, data);

  pipe_config(pcie_core_id);
  printf("Modified PCIE initialization \n");
  if (((pcie_core_id == 0) || (pcie_core_id == 3)) && (link_width == 8))
     full_width = 1;

  /* power down and reset CMU */
  /* reset rxtx channel, do not power down each channel */
  /* Note: if remote end do receiver detect while channel is powered down, */
  /*       remote end will get response of no receiver presetnt and shut down lanes */
  cmu_pd(pcie_core_id, link_width);
  cmu_reset(pcie_core_id, link_width); 
  rxtx_reset(pcie_core_id, link_width); 
  
  /* release gloabl serdes reset, so CMU and RXTX block can do calibration */
  sm_pcie_release_phy_reset(pcie_core_id);

  serdes_config_LSPLL(pcie_core_id, 0);  
  if(link_width == 8)
    serdes_config_LSPLL(pcie_core_id, 1);

  /* power up CMU, wait 1ms and release CMU reset */
  cmu_pup(pcie_core_id, link_width);
  MSDELAY(1);
  cmu_reset_release(pcie_core_id, link_width);

  /* wait pll lock before do calibration, this step might not be necessary */
  wait_pll_lock(pcie_core_id, full_width); 
//  if(wait_pll_lock(pcie_core_id, full_width)==0) 
//      return 1;            
  /* calibrate gen1/2 and gen3 pll before programming each channel */
  manual_cal(pcie_core_id, link_width);
  force_pvt_cal(pcie_core_id, link_width);

  if (pcie_core_id == 2) {
    serdes_config_rxtx_control(pcie_core_id, 0, 0);
  } else {
    for (i=0;i<=full_width;i++) {
      for (j=0;j<=3;j++) {
        serdes_config_rxtx_control(pcie_core_id, j, i);
      }
    }
  }
  
  /* release reset to each channel */
  rxtx_reset_release(pcie_core_id, link_width);
  
  lat_summer_average_cal(pcie_core_id, link_width);

  #if 0
  //NOT USE, but keep as record
  if(en_lpbk) {
    switch (pcie_core_id) {
     case (0):  // X8 port, uses 2 X4 serdes
                serdes_config_x4_fr_lpbk(pcie_core_id);
                
                serdes2_config_x4_fr_lpbk(pcie_core_id);
               break;
     case (1):  // X4 port, uses 1 X4 serdes
                serdes_config_x4_fr_lpbk(pcie_core_id);
               break;
     case (2): // x1 port, use 1 x1 serdes 
                serdes_config_x1_fr_lpbk(pcie_core_id);
               break;
     case (3): // X8 port, uses 2 X4 serdes
                 serdes_config_x4_fr_lpbk(pcie_core_id);
                
                 serdes2_config_x4_fr_lpbk(pcie_core_id);
               break;
     case (4): // X4 port, uses 1 X4 serdes
                serdes_config_x4_fr_lpbk(pcie_core_id);
               break;
    }
  }
  #endif
  return 0;  
}

void pcie_inhibt_rxdet(uint32_t pcie_core_id){
int data;
  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR);
  data = FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_INHIBIT_RX_DET_SET(data, 0x1);
  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR, data);
}

void pcie_g2_35db(uint32_t pcie_core_id){
int data;
   lprintf(5,"GEN2: set endpoint to 3.5db \n");
   data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_LINK_CTRL_2__ADDR);
   pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_LINK_CTRL_2__ADDR, data | (1<<6));
   //data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_LINK_CTRL_2__ADDR); //memory barrier
}

void pcie_rcvr_det_bypass(uint32_t pcie_core_id){
int data;
#ifdef RCV_DET_BYPASS
  lprintf(5,"Bypassing the receiver detection.\n\r");
  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR);
  data = FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352_CFG_CONSTANTS_BYPASS_RECEIVER_DETECTION_SET(data, 0x1);
  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR, data);
  
  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR);
  data = FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448_CFG_CONSTANTS_INHIBIT_RX_DET_SET(data, 0x0);
  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_479_448__ADDR, data);
#endif
}

int sm_pcie_init(uint32_t pcie_core_id, uint32_t port_type, uint32_t en_lpbk, uint32_t gen, uint32_t ext_ref, uint32_t link_width, uint32_t poll) {
uint32_t data, full_width, i, print_state;
uint32_t act_link_width, exp_link_width;
uint32_t act_link_speed, exp_link_speed;
uint32_t  pllnoerr = 1, count = 0;
uint32_t pll_err=0;

  act_link_width = 0;
  exp_link_width = link_width;
  act_link_speed = 0;
  exp_link_speed = gen;


//  pcie_ddr_remap();   //DDR remap, not used as 40bit DDR map works now
  if (((pcie_core_id == 0) || (pcie_core_id == 3)) && (link_width == 8))
    full_width = 1;
  else
    full_width = 0;

    lprintf(5,"Initializing the clkrst module to enable the csr clks and deassert the csr resets.\n\r");
    sm_pcie_init_csr_clkrst(pcie_core_id);
  
  #ifdef ENB_DEBUG_HOOK
    sm_pcie_setup_cntlr_pcie_debug_hooks(pcie_core_id, 0, 4);
    //sm_pcie_setup_generic_debug_hooks(pcie_core_id, 0, 0, 2);
    sm_pcie_setup_generic_debug_hooks(pcie_core_id, 0, 0, 1);  //NWL core diagbus
  #endif  
  
    if((pcie_core_id == 0) || (pcie_core_id == 3)){
      if (full_width) {
        lprintf(5,"setting PCIEX8 full width\n\r");
        //setting this bit will allow reset from core 0 to reset serdes of core 1
        data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_MUX__ADDR);
        data = FIELD_PCIE_SDS_MUX_SEL_PCIE_FULL_WIDTH_SET(data, 0x1);
        pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_MUX__ADDR, data);
      }
      else {
        lprintf(5,"Clearing PCIEX8 full width\n\r");
        //setting this bit will allow reset from core 0 to reset serdes of core 1
        data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_MUX__ADDR);
        data = FIELD_PCIE_SDS_MUX_SEL_PCIE_FULL_WIDTH_SET(data, 0x0);
        pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_MUX__ADDR, data);      
      }
    }
  
    sm_pcie_init_phy(pcie_core_id, port_type, gen, ext_ref, link_width, en_lpbk);
//    if(sm_pcie_init_phy(pcie_core_id, port_type, gen, ext_ref, link_width, en_lpbk)==1) {
//        printf("PLL Lock failure...");    
//        return 0;
//    }
    sm_pcie_init_ecc(pcie_core_id);
    lprintf(5,"ECC init done\n\r");
  
  #ifdef SIMULATION  
    sm_pcie_hack_for_sim(pcie_core_id, gen);
  #endif
  
    if(en_lpbk == 1)
      sm_pcie_en_self_crslink(pcie_core_id);

   en_event_int(pcie_core_id); 
 
   sm_pcie_wait_phy_rdy(pcie_core_id);

  if(port_type == EP) {
	  lprintf(5,"Initializing the controller for EP mode\n\r");
	  sm_pcie_init_ctrl_ep(pcie_core_id, gen);
  } else {
	  lprintf(5,"Initializing the controller for RC mode\n\r");
	  sm_pcie_init_ctrl_rc(pcie_core_id, gen);
	  sm_pcie_init_ven_msg_capture(pcie_core_id);
      sm_pcie_setup_ob_space(pcie_core_id, RC); 
  }
  
  //to set remote end to be 3.5db in GEN2, core reset must be release to program link control2 register
  //receiver detect inhibit is set first to prevent controller entering polling stage
  //once link control2 register is programmed, receiver detect bypass is set and inhibit is cleared
  pcie_inhibt_rxdet(pcie_core_id);
  sm_pcie_init_core_clkrst(pcie_core_id);
  if (port_type == RC){
    sm_pcie_setup_ob_cfg(pcie_core_id, RC);             
    pcie_g2_35db(pcie_core_id);
  }
  pcie_rcvr_det_bypass(pcie_core_id);

  if (port_type == RC)
    wait_linkup(pcie_core_id, gen, link_width);
}
