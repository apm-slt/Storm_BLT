/*
 * Copyright (c) 2014 AppliedMicro.  All rights reserved.
 * Author : Vaibhav Vaidya 
 * program brief: margin_cmd.c: User commands for margin tool
 * Lists out all command used in marginig.
 * history: v0.1 2014.11.8 <Supports only RX characteristics from RC mode>
 */
 //Tinh-SLT
#include "../include/margin.h"

 
uint32_t X_AXIS, Y_AXIS;
uint32_t duration=1;
extern char *Rx_serdes_param[];

/*
Fcn description : This command takes four argument from user to run pcie margin tool, arguments are
1st: PCIE core id
2nd : Gen
3rd : Link width
4th argument is serdes characteristics argumnet
0: Transmitter tuning
1: Recevier tunning
2: BCA parameter tunning

Release v 0.1 supports only receiver parameter tunning.
Dependecy : Call config_rx_data
            call config_x_y			
*/ 
uint32_t g_wdth=0,g_gen=0;
int opt_pcie(int argc, char *argv[])
{
	int i=argc, j=0,res=0,itr=0;
	uint32_t data, current_rate, gen_match,addr=0,coeff_cursr=0;
	uint32_t status = 0,success=0;
	uint32_t linkup;
	uint32_t printGEN[4] = {0,1,2};
	signed int cnt=1000;
	int error=0;
	uint32_t rc_slot=0,pcie_core_id,gen,link_width,link_speed;
	uint32_t ext_ref = 1,length=0x3fffffc,test_id=2,phase=1,itr_cnt =0,param=0,count=1 ;


	if (i<3)
		error=1;
	else
	{
		rc_slot = atoi(argv[j]);
		gen = atoi(argv[j+1]);
		link_width = atoi(argv[j+2]);
		param =atoi(argv[j+3]);
	}

	g_wdth=link_width;
	g_gen=gen;
	
	if (error) {
		printf("pcie_margin: argument error %1d-%d. Usage: rc_slot gen link_width param tx-rx\n", error, i);
		printf("usage:       pcie_core_id=0~2, gen=0-1-2, width, param : 0 - Tx 1 : - Rx and 2 : BCA \n");

		return error;
	}
  //   sm_pcie_init(rc_slot,1, 0, gen,1, link_width, 0);
       sm_tune_pcie(rc_slot,1,0,gen,1, link_width, 0); 
		 
	   MSDELAY(3000);
	   data = pcie_csr_read(rc_slot,SM_PCIE_CSR_REGS_BUSCTLREG__ADDR);
       data|=0x28080; 
       pcie_csr_write(rc_slot,SM_PCIE_CSR_REGS_BUSCTLREG__ADDR,data);
//     printf( " BUSCTRL__REG := 0x%x \n\r",pcie_csr_read(rc_slot,SM_PCIE_CSR_REGS_BUSCTLREG__ADDR));	
       data = pcie_csr_read(rc_slot, NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_31_0__ADDR);
	   link_width = (data & 0xfc000000) >> 26;
       link_speed = (data & 0x03000000)>>24 ;
	   
       printf("Current Link @ Gen%dx%d \n",(link_speed+1),link_width);
       get_margin[param](rc_slot);  // Call function here
	          	
}

/*
Fcn description : This command takes constant argument which is not varying during tuninig
1st: PCIE core id
2nd : Gen
3rd : Link width
4th argument is serdes characteristics argumnet
0: Transmitter tuning
1: Recevier tunning
2: BCA parameter tunning

Release v 0.1 supports only receiver parameter tunning.
Dependecy : Call config_rx_data
            call config_x_y			
*/ 
#include <cmd.h>
int config_rx_data(int argc, char *argv[])
{

	int i=argc, j=0,res=0,itr=0,a=0;
	uint32_t data, current_rate, gen_match,addr=0,coeff_cursr=0;
	uint32_t status = 0,success=0;
	uint32_t linkup;
	uint32_t printGEN[4] = {0,1,2};
	signed int cnt=1000;
	int error=0;
	uint32_t rc_slot,pcie_core_id,gen,link_width,link_speed;
	uint32_t ext_ref = 1,length=0x3fffffc,test_id=2,phase=1,itr_cnt =0,param=0,count=1 ;

	if(i < MAX_SUPPRTED_RX_PARAM)
    { 
		printf("config_rx_data: argument error %1d-%d. Usage: serdes receiver parameter \n", error, i);
		printf("parameters programmed to be constant Please refer configuration command doc. \n");
		return error;
	}	
	else
	{
		Ch_RxTxParam[CTLE_AC_IDX][0]=atoi(argv[CTLE_AC_IDX]);
		Ch_RxTxParam[CTLE_DC_IDX][0]=atoi(argv[CTLE_DC_IDX]);
		Ch_RxTxParam[CTLE_EQ_FR_IDX][0] = atoi(argv[CTLE_EQ_FR_IDX]);
		Ch_RxTxParam[CTLE_EQ_QR_IDX][0] = atoi(argv[CTLE_EQ_QR_IDX]);
		Ch_RxTxParam[CTLE_EQ_HR_IDX][0]=atoi(argv[CTLE_EQ_HR_IDX]);
		Ch_RxTxParam[CTLE_EQ_IDX][0]=atoi(argv[CTLE_EQ_IDX]);
		
		Ch_RxTxParam[DFE_IDX][0]=atoi(argv[DFE_IDX]);
		
		Ch_RxTxParam[PQ_SIGN_IDX][0]=atoi(argv[PQ_SIGN_IDX]);
		Ch_RxTxParam[PQ_VALUE_IDX][0]=atoi(argv[PQ_VALUE_IDX]);

		Ch_RxTxParam[LOCAL_PRESET_IDX][0]=atoi(argv[LOCAL_PRESET_IDX]);
		Ch_RxTxParam[REMOTE_PRESET_IDX][0]=atoi(argv[REMOTE_PRESET_IDX]);
	    Ch_RxTxParam[REMOTE_BCA_PRESET_IDX][0]=atoi(argv[REMOTE_BCA_PRESET_IDX]);
	
		Ch_RxTxParam[MU_PHASE1_IDX][0]=atoi(argv[MU_PHASE1_IDX]);
		Ch_RxTxParam[MU_PHASE2_IDX][0]=atoi(argv[MU_PHASE2_IDX]);
		Ch_RxTxParam[MU_PHASE3_IDX][0]=atoi(argv[MU_PHASE3_IDX]);
		
	    Ch_RxTxParam[MU_PHASE4_IDX][0]=atoi(argv[MU_PHASE4_IDX]);
		Ch_RxTxParam[MU_PHASE5_IDX][0]=atoi(argv[MU_PHASE5_IDX]);
		Ch_RxTxParam[MU_PHASE6_IDX][0]=atoi(argv[MU_PHASE6_IDX]);
		
	    Ch_RxTxParam[MU_PHASE7_IDX][0]=atoi(argv[MU_PHASE7_IDX]);
		Ch_RxTxParam[MU_PHASE8_IDX][0]=atoi(argv[MU_PHASE8_IDX]);
		Ch_RxTxParam[MU_PHASE9_IDX][0]=atoi(argv[MU_PHASE9_IDX]);

		for(a=0;a<=MAX_SUPPRTED_RX_PARAM;a++)
		{
		  printf("%s %d\n",Rx_serdes_param[a],Ch_RxTxParam[a][0]);
		}
	} 
}         	
cmd_decl(config_rx_data, config_rx_data);


/*
Fcn description : This command takes X-Axis and Y-Axis parameter and plot shmoo
1st: X-AXIS PARAM
2nd :Y-AXIS PARAM

Release v 0.1 supports only receiver parameter tunning.
Dependecy : Call config_rx_data
           		
*/ 

int config_x_y(int argc, char *argv[])
{

	int i=argc,error,j=0;
	
	if (i<2)
	{
		error=1;
		printf("config_x_y: argument error %1d-%d. Usage: X & Y-Axis Patam Index\n", error, i);
	    return 0;
	}
	else
	{
		X_AXIS = atoi(argv[0]);
		Y_AXIS =atoi(argv[1]);
		
    }
	
    printf("X-Axis %s Default %d range %d to %d \n",Rx_serdes_param[X_AXIS],Ch_RxTxParam[X_AXIS][0],Ch_RxTxParam[X_AXIS][1],Ch_RxTxParam[X_AXIS][2]);
	printf("Y-Axis %s Default %d range %d to %d \n",Rx_serdes_param[Y_AXIS],Ch_RxTxParam[Y_AXIS][0],Ch_RxTxParam[Y_AXIS][1],Ch_RxTxParam[Y_AXIS][2]);
}

/*
Fcn description : This command returns default link serdes parameters used in initilization
Dependecy : None.
           		
*/ 

int verify_param(int argc, char *argv[])
{

	int k=argc,error,j=0,i=0;
	uint32_t port_id=0,param,full_width=0,pcie_core_id=0;
	uint32_t link_width=0,gen=0;

	if (k<4)
	{
		error=1;
		printf("lnk_param: argument error %1d-%d. Usage: Port ID Param width gen\n", error, i);
	    return 0;
	}
	else
	{
		port_id = atoi(argv[0]);
		param =atoi(argv[1]);
		link_width=atoi(argv[2]);
		gen=atoi(argv[3]);
    }
	
    pcie_core_id=port_id;
		
switch(param)
{
   case 1 :  printf("Rx Paramerter used On Port: %d : \n\r",port_id); 

             if (port_id == 2) {
			 if(gen>1)
			 {
              Rd_Ctle_G3(port_id,0,0);
             }
			 else{
			   Rd_Ctle_G1G2(port_id,0,0); 
			 }
			  Rd_DFE(port_id,0,0);	
		      Rd_PQ(port_id,0,0);
			  Rd_Phase(port_id,0,0);
			  Rd_presetPhase1(port_id);
			 } 
			 else 
			 {
               if (((pcie_core_id == 0) || (pcie_core_id == 3)) && (link_width == 8))
               {
			     full_width=1;
			     for (i=0;i<=full_width;i++) 
			     {
                   for (j=0;j<=3;j++)
				  {
                    if(gen>1)
                     Rd_Ctle_G3(port_id,j,i);
				
                    else Rd_Ctle_G1G2(port_id,j,i);
					
					Rd_DFE(port_id,j,i);
					Rd_PQ(port_id,j,i);	
					Rd_Phase(port_id,j,i);
                    printf("\n");	
                  }	
                 printf("\n");
				  
			     }
		       Rd_presetPhase1(port_id);
			   }
			   
             }
			 
		
		   
   break;
   
   case 2:   
   break;
   
   default:
   break;

}

}


int set_time(int argc, char *argv[])
{
	int i=argc, error=0;

	if (i<1)
		error=1;
	else
	{
		duration = atoi(argv[0]);
		printf("Rx Error monitor time set to %d min",duration);
	}	

	if (error) {
		printf("set_time: argument error %1d-%d. Usage: time in min\n", error, i);
		printf("usage:      set_time <in min> \n");
		return error;
	}

}

int init_pcie(int argc, char *argv[])
{
	int i=argc, j=0,res=0,itr=0;
	uint32_t data, current_rate, gen_match,addr=0,coeff_cursr=0;
	uint32_t status = 0,success=0;
	uint32_t linkup;
	uint32_t printGEN[4] = {0,1,2};
	signed int cnt=1000;
	int error=0;
	uint32_t rc_slot=0,pcie_core_id,gen,link_width,link_speed;
	uint32_t ext_ref = 1,length=0x3fffffc,test_id=2,phase=1,itr_cnt =0,param=0,count=1 ;


	if (i<2)
		error=1;
	else
	{
		rc_slot = atoi(argv[j]);
		gen = atoi(argv[j+1]);
		link_width = atoi(argv[j+2]);
	}

	g_wdth=link_width;
	g_gen=gen;
	
	if (error) {
		printf("init_pcie: argument error %1d-%d. Usage: rc_slot gen link_width \n", error, i);
		printf("usage:       pcie_core_id=0~2, gen=0-1-2, width \n");

		return error;
	}

       sm_tune_pcie(rc_slot,1,0,gen,1, link_width, 0); 
		 
	   MSDELAY(3000);
	   data = pcie_csr_read(rc_slot,SM_PCIE_CSR_REGS_BUSCTLREG__ADDR);
       data|=0x28080; 
       pcie_csr_write(rc_slot,SM_PCIE_CSR_REGS_BUSCTLREG__ADDR,data);
//     printf( " BUSCTRL__REG := 0x%x \n\r",pcie_csr_read(rc_slot,SM_PCIE_CSR_REGS_BUSCTLREG__ADDR));	
       data = pcie_csr_read(rc_slot, NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_31_0__ADDR);
	   link_width = (data & 0xfc000000) >> 26;
       link_speed = (data & 0x03000000)>>24 ;
	   
       printf("Current Link @ Gen%dx%d \n",(link_speed+1),link_width);
}
