/*
This file is origionallyl taken from src/pcie_base.c file, 
for making seperate initilization code for margning tool.

Release 1: Targeted only for taking RX serdes parameters 
*/

#include <types.h>
#include <stdio.h>
#include <common.h>
//Tinh-SLT
#include "../include/pcie_base.h"
#include "../include/pcie_ib_test.h"
#define SKIP_BCA

//set to program PVT cal value manually
//#define manual_PVT

//set to bypass receiver detect
#define RCV_DET_BYPASS

//set to allow serdes control TX amplitude and pre/post cursor
//if not set, PIPE controls TX amplitude and pre/post cursor
//#define SDS_TX_CTRL

//set to use reference clock / 2 for serdes workaround on gen1/2
//#define REF_DIVIDE2

//set to use reference clock / 2 for serdes workaround on gen3
#define REF_DIVIDE2_GEN3

//set to use MOMSEL auto calibration
#define MOMSEL_AUTO

//use hot reset for linkup
//#define ENB_HOTRESET

//set to enable debug hook. 
//#define ENB_DEBUG_HOOK

void tune_phy(uint32_t pcie_core_id, uint32_t port_type, uint32_t gen, uint32_t ext_ref, uint32_t link_width, uint32_t en_lpbk)
{
 uint32_t data, i, j, full_width = 0;

  //set IO PAD for MDIO  address 'h17001398, data : 1e1e1e
  cpu_write(0x17001398, 0x1e1e1e);
  set_ser_refclk(pcie_core_id, port_type, ext_ref, link_width);
  // First clear the TX_PARAMS_VALID bit of the PIPECTLREG.
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_PIPECTLREG__ADDR);
  data = FIELD_PIPECTLREG_PHY_EQ_TX_PARAMS_VALID_SET(data, 0);
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIPECTLREG__ADDR, data);

  //FS/LF adjustment from KC
  data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_PIPECTLREG__ADDR);
  data = FIELD_PIPECTLREG_PHY_EQ_TX_FS_SET(data, 0x36);   
  data = FIELD_PIPECTLREG_PHY_EQ_TX_LF_SET(data, 0x10);   
//   data = FIELD_PIPECTLREG_PHY_EQ_TX_FS_SET(data, 0x1F);  // Mellanix card req 
//  data = FIELD_PIPECTLREG_PHY_EQ_TX_LF_SET(data, 0x15);

  data = FIELD_PIPECTLREG_PHY_EQ_TX_MAX_PRE_SET(data, 0x6); 
  data = FIELD_PIPECTLREG_PHY_EQ_TX_MAX_POST_SET(data, 0xf);
  //data = FIELD_PIPECTLREG_PHY_EQ_TX_MAX_PRE_SET(data, 0x12); 
  //data = FIELD_PIPECTLREG_PHY_EQ_TX_MAX_POST_SET(data, 0xa);
  data = FIELD_PIPECTLREG_PHY_EQ_TX_PARAMS_VALID_SET(data, 1);
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIPECTLREG__ADDR, data);
  
  //customer pin mode setting
  data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_CTL0__ADDR);
  //turn off bit 12 to give control to serdes, to correct pll feedback value
  //turn off bit 2 and 3 to correct tx amplitue and cp1/cn1/cn2  value (130212)
  #ifdef SDS_TX_CTRL
    data = FIELD_PCIE_SDS_CTL0_CFG_I_CUSTOMER_PIN_MODE_SET(data, 0x0d29); 
  #else
    data = FIELD_PCIE_SDS_CTL0_CFG_I_CUSTOMER_PIN_MODE_SET(data, 0x0d2d);
  #endif
  pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_CTL0__ADDR, data);

  pipe_config(pcie_core_id);

  if (pcie_core_id == 2) {
    serdes_config_LSPLL(pcie_core_id, 0);  
    tune_rx_control(pcie_core_id, 0, 0);
    serdes_config_rxtx_control(pcie_core_id, 0, 0);
  } else {
    if (((pcie_core_id == 0) || (pcie_core_id == 3)) && (link_width == 8))
      full_width = 1;
    for (i=0;i<=full_width;i++) {
      serdes_config_LSPLL(pcie_core_id, i);
      for (j=0;j<=3;j++) {
        tune_rx_control(pcie_core_id, j, i);
		serdes_config_rxtx_control(pcie_core_id, j, i);
      }
    }
  }

  if(en_lpbk) {
    switch (pcie_core_id) {
     case (0):  // X8 port, uses 2 X4 serdes
                serdes_config_x4_fr_lpbk(pcie_core_id);
                
                serdes2_config_x4_fr_lpbk(pcie_core_id);
               break;
     case (1):  // X4 port, uses 1 X4 serdes
                serdes_config_x4_fr_lpbk(pcie_core_id);
               break;
     case (2): // x1 port, use 1 x1 serdes 
                serdes_config_x1_fr_lpbk(pcie_core_id);
               break;
     case (3): // X8 port, uses 2 X4 serdes
                 serdes_config_x4_fr_lpbk(pcie_core_id);
                
                 serdes2_config_x4_fr_lpbk(pcie_core_id);
               break;
     case (4): // X4 port, uses 1 X4 serdes
                serdes_config_x4_fr_lpbk(pcie_core_id);
               break;
    }
  }
    lprintf(5, "Equalization Control 0x%x \n\r",pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_63_32__ADDR));
   // data=  pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_63_32__ADDR);
   // data=FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_63_32_CFG_8G_CONSTANTS_EQ_PRESET_USE_COEF_SET(data);
}

