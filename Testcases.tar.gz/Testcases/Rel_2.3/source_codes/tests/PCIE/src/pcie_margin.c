//Tinh-SLT
#include "../include/margin.h"
//End of Tinh-SLT

// In Phase-0 DS communicates tx_preset and rx_hint to US port

typedef struct {
   uint32_t tx_preset;
   uint32_t rx_hint;
} ctrl_phase0 ;

// In phase-1 link operational and fine tune Tx and Rx
// this phase, DS port communicates TX preset,LS-FS and Post Coeff value to US port 
typedef struct {
   uint32_t tx_preset;
   uint32_t fsv;
   uint32_t lsv;
   uint32_t post_coeff;
} ctrl_phase1;

typedef struct {
   
   uint32_t tx_preset;
   uint32_t eq_coeff[3];
   uint32_t pre_coeff_ctrl;

} ctrl_phase2;

typedef struct {

   uint32_t tx_preset;
   uint32_t eq_coeff[3];
   uint32_t pre_coeff_ctrl;
} ctrl_phase3;

typedef struct {
   uint32_t tx_amp;
} ctrl_tx;

typedef struct {
  uint32_t PRESET;  
  uint32_t PQ_REG;
  uint32_t CTLE;
  uint32_t DFE; 
} ctrl_rx;

typedef struct {
  ctrl_phase2 p2;
  ctrl_phase3 p3;
} eq_ctrl;

uint32_t tune_tx(uint32_t tx);
uint32_t tune_rx(uint32_t rx);
uint32_t fine_tune_bca(uint32_t phase);

extern int pcie_serdes_tuning(uint32_t pcie_core_id, uint32_t CTLE,uint32_t PQ_REG,uint32_t DFE, uint32_t PRESET);
extern int wait_min(uint64_t usec_duration, uint64_t start_time);
	
ctrl_rx serdes;
get_margin_t get_margin[3]= {
                               tune_tx,       // tune TX  
                               tune_rx,       // tune RX  
                               fine_tune_bca  // BCA param tuning  
                             };


uint32_t tune_tx(uint32_t tx)
{
  printf(" NOT-SUPPORTED YET \n\r") ;
}


extern uint32_t g_wdth,g_gen;
extern uint32_t duration;

uint32_t tune_rx(uint32_t rx)
{

	uint32_t pcie_core_id=rx,res=0,rc_id=0,stime,ms=0;
	uint32_t recovery_cnt=0,data=0,link_width,link_speed;
    uint32_t Xlimit,Ylimit,st_value=0,Yst_value=0;
	
	printf("\n");
	printf("\n");
	print_rx_data(pcie_core_id);
	printf("X-Axis %s Range : %d to %d V/S Y-Axis %s Range : %d to %d \n",
	        Rx_serdes_param[X_AXIS],Ch_RxTxParam[X_AXIS][1],Ch_RxTxParam[X_AXIS][2],
	        Rx_serdes_param[Y_AXIS],Ch_RxTxParam[Y_AXIS][1],Ch_RxTxParam[Y_AXIS][2]);
    
    printf("\n");
	printf("\n");
	
	Xlimit= Ch_RxTxParam[X_AXIS][2];
	Ylimit= Ch_RxTxParam[Y_AXIS][2];
	
	// Print X-Axis here
	printf("%s   ",Rx_serdes_param[X_AXIS]);
    for ( st_value=Ch_RxTxParam[X_AXIS][1]; st_value <= Xlimit; st_value++) printf(" %02d ", st_value);
	printf("\n");
	for ( Yst_value=Ch_RxTxParam[Y_AXIS][1]; Yst_value <= Ylimit; Yst_value++)
	{	
		printf("%s = %02d:",Rx_serdes_param[Y_AXIS],Yst_value);   
		for ( st_value=Ch_RxTxParam[X_AXIS][1]; st_value <= Xlimit; ++st_value)
		{
		   pcie_reset_mellanox(rx); 
	      
	  // X- Axis
          Ch_RxTxParam[X_AXIS][0]=st_value;
	  // Y- Axis
    	  Ch_RxTxParam[Y_AXIS][0]=Yst_value;
      // printf("X = %d Y = %d ",Ch_RxTxParam[X_AXIS][0],Ch_RxTxParam[Y_AXIS][0]);
		  sm_tune_pcie(rx,1,0,g_gen,1, g_wdth, 0);             
      //  sm_pcie_init(rx,1,0, g_gen,1, g_wdth, 0);    			 
          MSDELAY(2000);
		   recovery_cnt = pcie_config_read(rx,duration);	
		   lprintf(5," %02d", recovery_cnt);
		   if(recovery_cnt == 99) 
		   {
			 res=wait_linkup(rx,2,8);
			 if((res==0) || (res==2)){     
			 printf("NL");
			 break;
		   }
		     else printf(" %02d" , recovery_cnt);	

		   }
		   else{
  				  printf(" %02d" , recovery_cnt);	
				}	
			
		 }
	   	 printf("\n");  
	 } // PQ_REG Change		   
	} // CTLE Change 
	
uint32_t fine_tune_bca(uint32_t phase)
{

  printf("BCA NOT-SUPPORTED-YET \n\r ");
}



uint32_t Rd_Ctle_G1G2(uint32_t pcie_core_id, uint32_t ch, uint32_t sds2)
{
  uint32_t data, sds2_offset;

  //lprintf(5,"Serdes RX config, core 0x%x, channel# 0x%x, serdes# 0x%x \n\r", pcie_core_id, ch, sds2);
  if (sds2){
    sds2_offset = 0x30000;
  } else {
    sds2_offset = 0x0;
  }
  
  data=pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG0__ADDR + (0x200 * ch) + sds2_offset);
  printf(" Lane %d CTLE_EQ_HR AC Gain :%d DC Gain :%d \n\r" ,ch,FIELD_CH0_RXTX_REG0_CTLE_EQ_HR_RD(data) >> 2,
  FIELD_CH0_RXTX_REG0_CTLE_EQ_HR_RD(data) & 0x3 );
  printf(" Lane %d CTLE_EQ_QR AC Gain :%d DC Gain :%d \n\r",ch, FIELD_CH0_RXTX_REG0_CTLE_EQ_HR_RD(data) >> 2,
  FIELD_CH0_RXTX_REG0_CTLE_EQ_HR_RD(data)& 0x3);
  printf(" Lane %d CTLE_EQ_FR AC Gain :%d DC Gain :%d \n\r",ch, FIELD_CH0_RXTX_REG0_CTLE_EQ_HR_RD(data) >> 2,
  FIELD_CH0_RXTX_REG0_CTLE_EQ_HR_RD(data)& 0x3);
}

uint32_t Rd_Ctle_G3(uint32_t pcie_core_id, uint32_t ch, uint32_t sds2) 
{
  uint32_t data, sds2_offset;

  //lprintf(5,"Serdes RX config, core 0x%x, channel# 0x%x, serdes# 0x%x \n\r", pcie_core_id, ch, sds2);
  if (sds2){
    sds2_offset = 0x30000;
  } else {
    sds2_offset = 0x0;
  }
  
  data=pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG1__ADDR + (0x200 * ch) + sds2_offset);
  printf(" Lane %d CTLE_EQ_G3 AC Gain : %d DC Gain : %d \n\r",ch,FIELD_CH0_RXTX_REG1_CTLE_EQ_RD(data) >> 2 ,
  FIELD_CH0_RXTX_REG1_CTLE_EQ_RD(data) & 3);
}

uint32_t Rd_DFE(uint32_t pcie_core_id, uint32_t ch, uint32_t sds2) 
{
  uint32_t data, sds2_offset;

  //lprintf(5,"Serdes RX config, core 0x%x, channel# 0x%x, serdes# 0x%x \n\r", pcie_core_id, ch, sds2);
  if (sds2){
    sds2_offset = 0x30000;
  } else {
    sds2_offset = 0x0;
  }
  
  data=pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG28__ADDR + (0x200 * ch) + sds2_offset);
  printf(" Lane %d DFE_tap_ena %d \n\r",ch,FIELD_CH0_RXTX_REG28_DFE_TAP_ENA_RD(data));
}

uint32_t Rd_PQ(uint32_t pcie_core_id, uint32_t ch, uint32_t sds2) 
{
  uint32_t data, sds2_offset;

  //lprintf(5,"Serdes RX config, core 0x%x, channel# 0x%x, serdes# 0x%x \n\r", pcie_core_id, ch, sds2);
  if (sds2){
    sds2_offset = 0x30000;
  } else {
    sds2_offset = 0x0;
  }
  
  data=pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG125__ADDR + (0x200 * ch) + sds2_offset);
  printf(" Lane %d sign_PQ %d PQ skew %d \n\r",
           ch,
           FIELD_CH0_RXTX_REG125_SIGN_PQ_RD(data),
           FIELD_CH0_RXTX_REG125_PQ_REG_RD(data));
}

uint32_t Rd_Phase(uint32_t pcie_core_id, uint32_t ch, uint32_t sds2) 
{
  uint32_t data, sds2_offset;

  //lprintf(5,"Serdes RX config, core 0x%x, channel# 0x%x, serdes# 0x%x \n\r", pcie_core_id, ch, sds2);
  if (sds2){
    sds2_offset = 0x30000;
  } else {
    sds2_offset = 0x0;
  }
  
  data=pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG99__ADDR + (0x200 * ch) + sds2_offset);
  printf(" Lane %d Phase-1:%d Phase-2:%d Phase-3:%d \n\r",
           ch,
           FIELD_CH2_RXTX_REG99_MU_PHASE1_RD(data),
           FIELD_CH2_RXTX_REG99_MU_PHASE2_RD(data),
		   FIELD_CH2_RXTX_REG99_MU_PHASE3_RD(data));

  data=pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG100__ADDR + (0x200 * ch) + sds2_offset);
  
  printf(" Lane %d Phase-4:%d Phase-5:%d Phase-6:%d \n\r",
           ch,
           FIELD_CH2_RXTX_REG100_MU_PHASE4_RD(data),
           FIELD_CH2_RXTX_REG100_MU_PHASE5_RD(data),
		   FIELD_CH2_RXTX_REG100_MU_PHASE6_RD(data));
		   
		   
  data=pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG101__ADDR + (0x200 * ch) + sds2_offset);
  printf(" Lane %d Phase-7:%d Phase-8:%d Phase-9:%d \n\r",
           ch,
           FIELD_CH2_RXTX_REG101_MU_PHASE7_RD(data),
           FIELD_CH2_RXTX_REG101_MU_PHASE8_RD(data),
		   FIELD_CH2_RXTX_REG101_MU_PHASE9_RD(data));
  	
}
uint32_t Rd_presetPhase1(uint32_t pcie_core_id)
{
  uint32_t data, sds2_offset;
    
  data=pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0__ADDR));
  
  printf("Phase-1 DS_PORT_TX_PRESET = %d \nUS_PORT_TX_PRESET = %d \n\r ",
  FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0_CFG_8G_CONSTANTS_MGMT_DS_PORT_TX_PRESET_RD(data),
  FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0_CFG_8G_CONSTANTS_MGMT_US_PORT_TX_PRESET_RD(data));
}

