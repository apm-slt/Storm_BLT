#include <types.h>
#include <stdio.h>
#include <common.h>
//Tinh-SLT
#include "../include/pcie_base.h"
#include "../include/pcie_base_test.h"
//End of Tinh-SLT
extern int wait_min(uint64_t usec_duration, uint64_t start_time);

int chk_prbs(int argc, char *argv[])
{
    int p0_ch0_r;
    int p0_ch1_r;
    int p0_ch2_r;
    int p0_ch3_r;
    int p0_ch4_r;
    int p0_ch5_r;
    int p0_ch6_r;
    int p0_ch7_r;
    int p3_ch0_r;
    int p3_ch1_r;
    int p3_ch2_r;
    int p3_ch3_r;
    int p3_ch4_r;
    int p3_ch5_r;
    int p3_ch6_r;
    int p3_ch7_r;
    int p0_pass, p3_pass;
    int ii, gen,temp=0,eye=0;
	uint32_t pcie_core_id=0,lane=0,delay=0;
	uint32_t duration=1,stime=0,width=0;
	uint32_t msb_cnt=0,lsb_cnt=0,data=0,ch=0;
	
 
    if (argc < 5){
       print("not enough argument gen \n\r");
	   printf("Command Type <core id >< gen >< width >< duration min >< eye ON > ");
       return -1;
    } else {
        
		pcie_core_id = atoi(argv[0]);
		gen = atoi(argv[1]);
		width=atoi(argv[2]);
		duration=atoi(argv[3]);
		eye=atoi(argv[4]);
    }


    printf("PCIE SLT PRBS test: on Port %d for %d lanes \n\r ",pcie_core_id,width);
	
    sm_pcie_init(pcie_core_id, 1, 0, gen, 1, width, 0);
	MSDELAY(3000);
    change_ltssm_state(pcie_core_id,0); 
	MSDELAY(1000);
    temp = (unsigned char )(pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_1023_992__ADDR) >> 4 );
	
    if(( (pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_31_0__ADDR) & 0xFC) >> 2) == 0x6 )
	{
		printf("lts_state = %d \n\r", (pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_31_0__ADDR) & 0xFC) >> 2);
		printf("Link Entered into Loopback \n\r" );
		//printf(" 0x%x Active 8-1 lanes in loopback 1: Active 0 : Not Active  = %7b \n\r",
	    //pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_1023_992__ADDR ),
		//temp);
		printf("active lane = %7b \n\r", temp);

	}
	else
	{
		printf("lts_state = %d \n\r", (pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_31_0__ADDR) & 0xFC) >> 2);
		printf("FAILED TO ENTER IN LOOPBACK \n\r" );
         	printf(" 0x%x Active 8-1 lanes in loopback 1: Active 0 : Not Active  = %7b \n\r",
			pcie_csr_read(pcie_core_id,NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_1023_992__ADDR ),temp);

	}
	
    //set TX PRBS pattern on both port
    set_tx_prbs(pcie_core_id, 31);

    //set RX PRBS pattern on both port
    set_rx_prbs(pcie_core_id, 31);
	
 //Reset counter result
    p0_ch0_r = bert_check_sub(pcie_core_id, 0,0,1);
    p0_ch1_r = bert_check_sub(pcie_core_id, 1,0,1);
    p0_ch2_r = bert_check_sub(pcie_core_id, 2,0,1);
    p0_ch3_r = bert_check_sub(pcie_core_id, 3,0,1);
    p0_ch4_r = bert_check_sub(pcie_core_id, 4,0,1);
    p0_ch5_r = bert_check_sub(pcie_core_id, 5,0,1);
    p0_ch6_r = bert_check_sub(pcie_core_id, 6,0,1);
    p0_ch7_r = bert_check_sub(pcie_core_id, 7,0,1);
    
    chk_bert_active (pcie_core_id, 0);
    chk_bert_active (pcie_core_id, 1);
    chk_bert_active (pcie_core_id, 2);
    chk_bert_active (pcie_core_id, 3);
    chk_bert_active (pcie_core_id, 4);
    chk_bert_active (pcie_core_id, 5);
    chk_bert_active (pcie_core_id, 6);
    chk_bert_active (pcie_core_id, 7);

	if(eye)
    {
     for(lane=0; lane < (width-1); lane++){
        eyescan_sub(pcie_core_id, lane);
     }
    } 

    SYNC();
	__asm__ volatile ("mrs %0, cntpct_el0": "=r"(stime));
	printf("Duration Set = %d Min \n\r",duration);   
	do{
       printf("Test Runnning ***** \r"); 
	   SYNC();
    }while(wait_min(duration,stime));
	printf("\n");
	
    //checking port 0 result
    p0_ch0_r = bert_check_sub(pcie_core_id, 0,1,0);
    p0_ch1_r = bert_check_sub(pcie_core_id, 1,1,0);
    p0_ch2_r = bert_check_sub(pcie_core_id, 2,1,0);
    p0_ch3_r = bert_check_sub(pcie_core_id, 3,1,0);
    p0_ch4_r = bert_check_sub(pcie_core_id, 4,1,0);
    p0_ch5_r = bert_check_sub(pcie_core_id, 5,1,0);
    p0_ch6_r = bert_check_sub(pcie_core_id, 6,1,0);
    p0_ch7_r = bert_check_sub(pcie_core_id, 7,1,0);
          
    p0_pass = (p0_ch0_r + p0_ch1_r + p0_ch2_r + p0_ch3_r + p0_ch4_r + p0_ch5_r + p0_ch6_r + p0_ch7_r) == 0;
  
    if(p0_pass ) { print("PRBS PASS\n\r");}
    else {
	print("PRBS FAIL  port %d \n\r", pcie_core_id);
    if (p0_ch0_r) {print("CH 0 failed "); bert_cnt_sub(pcie_core_id, 0);}
    if (p0_ch1_r) {print("CH 1 failed "); bert_cnt_sub(pcie_core_id, 1);}
    if (p0_ch2_r) {print("CH 2 failed "); bert_cnt_sub(pcie_core_id, 2);}
    if (p0_ch3_r) {print("CH 3 failed "); bert_cnt_sub(pcie_core_id, 3);}
    if (p0_ch4_r) {print("CH 4 failed "); bert_cnt_sub(pcie_core_id, 4);}
    if (p0_ch5_r) {print("CH 5 failed "); bert_cnt_sub(pcie_core_id, 5);}
    if (p0_ch6_r) {print("CH 6 failed "); bert_cnt_sub(pcie_core_id, 6);}
    if (p0_ch7_r) {print("CH 7 failed "); bert_cnt_sub(pcie_core_id, 7);}
   }
    return 0;
}
