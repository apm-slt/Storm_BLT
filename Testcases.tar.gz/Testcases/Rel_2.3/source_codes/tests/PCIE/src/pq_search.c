/*
 */
#include <types.h>
#include <stdio.h>
#include <common.h>
//Tinh-SLT
#include "../include/pcie_base.h"
#include "../include/pcie_ib_test.h"
//End of Tinh-SLT

#define VM_SKIP 1
#define PQ_SKIP 1
#define VM_RANGE 64
#define PQ_RANGE 128
#define VM_MID (VM_RANGE/2)
#define PQ_MID (PQ_RANGE/2)

static int  read_data = 0x00000000;
int es_diff[33];
static long long eye_data_base_addr;
static   long long *es_data_ptr, *est_data_ptr, *es_data_store_ptr; 
// +++++++++++++++++++++++
// +++++++++++++++++++++++
void write_ddr( u64 addr, u32 data)
{
u64 *addr_int;
addr_int = addr;
*addr_int = data;
}
//Tinh-SLT
//int read_ddr(unsigned int *addr)
int read_ddr_pcie(unsigned int *addr)
{
    unsigned int *addr_int;
    int          rdata;
    addr_int     = addr;
    rdata        = *addr_int;
    return(rdata);
}

void es_singlephase_pqs(int vRange, int vskip, int pcie_core_id, int ch) {

   int vm,c_tmp=0;
   int fullFlag;
   int es_data;
   int es_data1;
   int es_data2;
   int est_data;
   int est_data1;
   int est_data2;
   int sds2_offset, data;
  long long es_data_addr, est_data_addr, es_data_store_addr;

   
   es_data_addr = (long long)(eye_data_base_addr + (8*128*64)*sizeof(int));
   es_data_store_addr = (long long)(eye_data_base_addr + (8*128*64)*sizeof(int) * 8); //8 ch

   es_data_ptr = (long long *) es_data_addr;
   for (vm=0; vm < vRange; vm = vm +VM_SKIP) {
	  *(es_data_ptr + vm/VM_SKIP) = 0;
   }


   if(ch>=4){
    sds2_offset = 0x30000;
    ch = ch -4;
   } else {
    sds2_offset = 0;
   }


   // function to sweep voltage level
   //for (vm=0; vm < vRange; vm = vm + vskip) {
    for (vm=0; vm < 4; vm = vm + VM_SKIP) {
      // set vmargin to new value
   //   WriteReg('escan_vmargin',vm) 
      
      data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG19__ADDR + (0x200 * ch) + sds2_offset);
      data = FIELD_CH0_RXTX_REG19_ESCAN_VMARGIN_SET(data, vm);
      pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG19__ADDR + (0x200 * ch) + sds2_offset, data);
      // toggle resetb
      data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset);
      data = FIELD_CH3_RXTX_REG61_EYE_ACC_RESETB_SET(data, 0);
      pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset, data);
      
      data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset);
      data = FIELD_CH3_RXTX_REG61_EYE_ACC_RESETB_SET(data, 1);
      pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset, data);
      // poll for data full flag
      
      do {
         data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG118__ADDR + (0x200 * ch) + sds2_offset);
	     fullFlag = FIELD_CH0_RXTX_REG118_ACC_FULL_FLAG_RD(data);
         //printf("waiting full flag \n");
     } while (fullFlag == 0);

      // trigger data capture
      data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset);
      data = FIELD_CH0_RXTX_REG61_EYE_MONITOR_CAPTURE_SET(data, 1);
      pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset, data);
      
      data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset);
      data = FIELD_CH0_RXTX_REG61_EYE_MONITOR_CAPTURE_SET(data, 0);
      pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset, data);

      // read data to string
      es_data1 = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG123__ADDR + (0x200 * ch) + sds2_offset);
      es_data2 = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG124__ADDR + (0x200 * ch) + sds2_offset);
      //es_data = es_data1*(2**16)+es_data2;
      es_data = es_data1*65536+es_data2;
      est_data1 = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG161__ADDR + (0x200 * ch) + sds2_offset);
      est_data2 = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG162__ADDR + (0x200 * ch) + sds2_offset);
      //est_data = est_data1*(2**16)+est_data2;
      est_data = est_data1*65536+est_data2;
      
      est_data = est_data1*65536+est_data2;
      //printf("%d\t", es_data);
      *(es_data_ptr + vm/VM_SKIP + 2/VM_SKIP + 1- c_tmp) = (long long)es_data;
      c_tmp+=2;
      //printf ("es_str: %d \n", es_data);
      //printf ("est_str: %d \n", est_data);
   }
    for (vm=32; vm < 36; vm = vm + VM_SKIP) {
      // set vmargin to new value
   //   WriteReg('escan_vmargin',vm) 
      
      data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG19__ADDR + (0x200 * ch) + sds2_offset);
      data = FIELD_CH0_RXTX_REG19_ESCAN_VMARGIN_SET(data, vm);
      pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG19__ADDR + (0x200 * ch) + sds2_offset, data);
      // toggle resetb
      data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset);
      data = FIELD_CH3_RXTX_REG61_EYE_ACC_RESETB_SET(data, 0);
      pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset, data);
      
      data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset);
      data = FIELD_CH3_RXTX_REG61_EYE_ACC_RESETB_SET(data, 1);
      pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset, data);
      // poll for data full flag
      
      do {
         data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG118__ADDR + (0x200 * ch) + sds2_offset);
	     fullFlag = FIELD_CH0_RXTX_REG118_ACC_FULL_FLAG_RD(data);
         //printf("waiting full flag \n");
     } while (fullFlag == 0);

      // trigger data capture
      data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset);
      data = FIELD_CH0_RXTX_REG61_EYE_MONITOR_CAPTURE_SET(data, 1);
      pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset, data);
      
      data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset);
      data = FIELD_CH0_RXTX_REG61_EYE_MONITOR_CAPTURE_SET(data, 0);
      pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset, data);

      // read data to string
      es_data1 = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG123__ADDR + (0x200 * ch) + sds2_offset);
      es_data2 = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG124__ADDR + (0x200 * ch) + sds2_offset);
      //es_data = es_data1*(2**16)+es_data2;
      es_data = es_data1*65536+es_data2;
      est_data1 = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG161__ADDR + (0x200 * ch) + sds2_offset);
      est_data2 = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG162__ADDR + (0x200 * ch) + sds2_offset);
      //est_data = est_data1*(2**16)+est_data2;
      est_data = est_data1*65536+est_data2;
      
      *(es_data_ptr + (vm-32+4)/VM_SKIP) = (long long)es_data;
      //printf ("es_str: %d \n", es_data);
      //printf ("est_str: %d \n", est_data);
   }
}   

void pq_search_sub (int pcie_core_id, int ch){
   int vRange;
   int qinit;
   int qend;
   int qskip;
   int num_of_steps;
   int increment;
   int barVal;
   int sds2_offset;
   int ch_adj, data, qi;
   int pqsign, pqval, i;
    
    int val;
    int lval=0;
    int rval=0;
    int center_val=0;
    int width=0;
    int pq_opt=0;
    int center_opt_val=0;
    int uval=0;
    int dval=0;
    int hight=0;
    int vtg=0;

   
   if(ch>=4){
    sds2_offset = 0x30000;
    ch_adj = ch-4;
   } else {
    sds2_offset = 0;
    ch_adj = ch;
   }

   vRange = 64;
   qinit = -64;
   qend = 64;
   qskip = 1;
 
  long long eye_addr = 0x4000000000+0x80000000;
  memset((u8 *)eye_addr, 0xFF, sizeof(int)*128*64*8*4);//Read Modify Write with 0xFF


  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG145__ADDR + (0x200 * ch_adj) + sds2_offset);
  data = FIELD_CH0_RXTX_REG145_RXVWES_LATENA_SET(data, 1);
  data = FIELD_CH0_RXTX_REG145_RXES_ENA_SET(data, 1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG145__ADDR + (0x200 * ch_adj) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG62__ADDR + (0x200 * ch_adj) + sds2_offset);
  data = FIELD_CH1_RXTX_REG62_PERIOD_H1_QLATCH_SET(data, 2);
  data = FIELD_CH1_RXTX_REG62_SWITCH_H1_QLATCH_SET(data, 1);
  data = FIELD_CH1_RXTX_REG62_H1_QLATCH_SIGN_INV_SET(data, 0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG62__ADDR + (0x200 * ch_adj) + sds2_offset, data);
  
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch_adj) + sds2_offset);
  data = FIELD_CH1_RXTX_REG61_EYE_COUNT_WIDTH_SEL_SET(data, 2);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch_adj) + sds2_offset, data);
  


//   for qi from qinit to qend 
   printf("CHANNEL %d START \n", ch);
   for (qi = qinit ; qi < qend; qi= qi+qskip) 
   {
      
      data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG126__ADDR + (0x200 * ch_adj) + sds2_offset);
      if(qi<0){
        pqsign = 1;
        pqval = qi * -1;
      } else {
        pqsign = 0;
        pqval = qi;
      };
      data = FIELD_CH0_RXTX_REG126_SIGN_QI_REG_SET(data, pqsign);
      data = FIELD_CH0_RXTX_REG126_QI_REG_SET(data, pqval);
      //printf("qi %d sign_qi %d\n", pqval, pqsign);
      pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG126__ADDR + (0x200 * ch_adj) + sds2_offset, data);
      
      es_singlephase_pqs(vRange, qskip, pcie_core_id, ch);
      for(i=0; i<8; i= i+VM_SKIP)
        {
           // printf ("%d\n", (*(es_data_ptr + i)));
            (*(es_data_ptr + i/VM_SKIP))-=(*(es_data_ptr + i/VM_SKIP+1));
            //printf ("es_str: %d\n", (*(es_data_ptr + i)) - (*(es_data_ptr + i+1))  );
            //printf ("%d\n", (*(es_data_ptr + i)));
            val = *(es_data_ptr + i/VM_SKIP);
            //printf("%d\t", val);
            write_ddr((eye_addr+ 4*VM_RANGE*(qi/PQ_SKIP+PQ_MID/PQ_SKIP) + i/VM_SKIP*4), val);
            printf("%d\t", read_ddr_pcie((eye_addr+ 4*VM_RANGE*(PQ_MID/PQ_SKIP+qi/PQ_SKIP) + i/VM_SKIP *4)));
           // printf("(0x%x,%d)\t", (eye_addr+ 4*VM_RANGE*(PQ_MID/PQ_SKIP+qi/PQ_SKIP) + i/VM_SKIP *4), read_ddr((eye_addr+ 4*VM_RANGE*(PQ_MID/PQ_SKIP+qi/PQ_SKIP) + i/VM_SKIP *4)));
        }
        printf("\n");
   }
   printf("CHANNEL %d END \n", ch);
   
   /* computing pq value */
   //  printf("-64=============================================================0=============================================================63\n");
   //center_val = read_ddr(eye_addr +4*(VM_MID-2) + 4*PQ_MID*(PQ_RANGE/(2*PQ_SKIP)));
   center_val = read_ddr_pcie(eye_addr +4*(4-2) + 4*PQ_MID*(PQ_RANGE/(2*PQ_SKIP)));
    if( center_val < 10000)
    { 
        //printf(" center_val < 10000\n");
        for(i=(PQ_MID); i>0; i=i - PQ_SKIP )
        { //printf("Here\n");
           // printf("%d\t",read_ddr(eye_addr +4*(VM_MID-2) + PQ_MID*4*i/PQ_SKIP));
            //if (read_ddr(eye_addr +4*(VM_MID/VM_SKIP) + PQ_MID*4*i/PQ_SKIP) <10000) lval++;  else    break;
            //if (read_ddr(eye_addr +4*((4-2)/VM_SKIP) + PQ_MID*4*i/PQ_SKIP) <10000) lval++;  else    break;
            if (read_ddr_pcie(eye_addr +4*((4)/VM_SKIP) + PQ_MID*4*i/PQ_SKIP) <10000) lval++;  else    break;
           // 8 + 64*4*64
        }  
        for(i=(PQ_MID); i>0; i=i - PQ_SKIP )
        { //printf("Here\n");
           // printf("%d\t",read_ddr(eye_addr +4*(VM_MID-2) + PQ_MID*4*i/PQ_SKIP));
            //if (read_ddr(eye_addr +4*(VM_MID/VM_SKIP) + PQ_MID*4*i/PQ_SKIP) <10000) lval++;  else    break;
            if (read_ddr_pcie(eye_addr +4*((4-2)/VM_SKIP) + PQ_MID*4*i/PQ_SKIP) <10000) lval++;  else    break;
            //if (read_ddr(eye_addr +4*((4)/VM_SKIP) + PQ_MID*4*i/PQ_SKIP) <10000) lval++;  else    break;
           // 8 + 64*4*64
        }
        for(i=(PQ_MID); i<(PQ_RANGE); i=i+PQ_SKIP)
        {
            //printf("%d\t",read_ddr(eye_addr +4*(VM_MID-2) + PQ_MID*4*i/PQ_SKIP));
            //if (read_ddr(eye_addr  +4*(VM_MID/VM_SKIP) + PQ_MID*4*i/PQ_SKIP) <10000) rval++;   else           break;
            //if (read_ddr(eye_addr  +4*((4-2)/VM_SKIP) + PQ_MID*4*i/PQ_SKIP) <10000) rval++;   else           break;
            if (read_ddr_pcie(eye_addr  +4*((4)/VM_SKIP) + PQ_MID*4*i/PQ_SKIP) <10000) rval++;   else           break;
        }
         for(i=(PQ_MID); i<(PQ_RANGE); i=i+PQ_SKIP)
        {
            //printf("%d\t",read_ddr(eye_addr +4*(VM_MID-2) + PQ_MID*4*i/PQ_SKIP));
            //if (read_ddr(eye_addr  +4*(VM_MID/VM_SKIP) + PQ_MID*4*i/PQ_SKIP) <10000) rval++;   else           break;
            if (read_ddr_pcie(eye_addr  +4*((4-2)/VM_SKIP) + PQ_MID*4*i/PQ_SKIP) <10000) rval++;   else           break;
            //if (read_ddr(eye_addr  +4*((4)/VM_SKIP) + PQ_MID*4*i/PQ_SKIP) <10000) rval++;   else           break;
        }

        width = (lval + rval)/2;
        pq_opt = (width/2) - lval/2;
        pq_opt = pq_opt * PQ_SKIP + 1;
      //  printf("lval = %d\n\n", lval);
       // printf("rval = %d\n\n", rval);
       // printf("pq_opt = %d\n\n", pq_opt);
    }
    else
    {
        // printf("TODO: Code is still not implemented\n");
        //for(i=64; i<127; i=i+PQ_SKIP)
        for(i=(PQ_MID); i<(PQ_RANGE); i=i+PQ_SKIP)
        { 
            //if (read_ddr(eye_addr + 4*(VM_MID/VM_SKIP) + PQ_MID*4*i/PQ_SKIP) >10000)       lval++;       else      break;
            //if (read_ddr(eye_addr + 4*((4-2)/VM_SKIP) + PQ_MID*4*i/PQ_SKIP) >10000)       lval++;       else      break;
            if (read_ddr_pcie(eye_addr + 4*((4)/VM_SKIP) + PQ_MID*4*i/PQ_SKIP) >10000)       lval++;       else      break;
        }
         for(i=(PQ_MID); i<(PQ_RANGE); i=i+PQ_SKIP)
        { 
            //if (read_ddr(eye_addr + 4*(VM_MID/VM_SKIP) + PQ_MID*4*i/PQ_SKIP) >10000)       lval++;       else      break;
            if (read_ddr_pcie(eye_addr + 4*((4-2)/VM_SKIP) + PQ_MID*4*i/PQ_SKIP) >10000)       lval++;       else      break;
            //if (read_ddr(eye_addr + 4*((4)/VM_SKIP) + PQ_MID*4*i/PQ_SKIP) >10000)       lval++;       else      break;
        }

        //for(i=64; i<127; i=i+PQ_SKIP)
        for(i=(PQ_MID); i<(PQ_RANGE); i=i+PQ_SKIP)
        {
           // if (read_ddr(eye_addr  +4*(VM_MID/VM_SKIP) + PQ_MID*4*i/PQ_SKIP) <10000)        rval++;       else    break;
           // if (read_ddr(eye_addr  +4*((4-2)/VM_SKIP) + PQ_MID*4*i/PQ_SKIP) <10000)        rval++;       else    break;
            if (read_ddr_pcie(eye_addr  +4*((4)/VM_SKIP) + PQ_MID*4*i/PQ_SKIP) <10000)        rval++;       else    break;
        }
          for(i=(PQ_MID); i<(PQ_RANGE); i=i+PQ_SKIP)
        {
           // if (read_ddr(eye_addr  +4*(VM_MID/VM_SKIP) + PQ_MID*4*i/PQ_SKIP) <10000)        rval++;       else    break;
            if (read_ddr_pcie(eye_addr  +4*((4-2)/VM_SKIP) + PQ_MID*4*i/PQ_SKIP) <10000)        rval++;       else    break;
            //if (read_ddr(eye_addr  +4*((4)/VM_SKIP) + PQ_MID*4*i/PQ_SKIP) <10000)        rval++;       else    break;
        }

        width = (lval + rval)/2;
        pq_opt = (width/2) + lval/2 ;
        pq_opt = pq_opt * PQ_SKIP + 1;
    }
    printf("Eye Sampling point = pq = %d\n\n", pq_opt);

    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG126__ADDR + (0x200 * ch_adj) + sds2_offset, data);
  
  /*
    printf("programming new pq \n");
   data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG125__ADDR + (0x200 * ch_adj) + sds2_offset);
   data = FIELD_CH0_RXTX_REG125_PQ_REG_SET(data, pq_opt);
   pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG125__ADDR + (0x200 * ch_adj) + sds2_offset, data);
   */

   data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG19__ADDR + (0x200 * ch_adj) + sds2_offset);
   data = FIELD_CH2_RXTX_REG19_ESCAN_VMARGIN_SET(data, 0);
   pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG19__ADDR + (0x200 * ch_adj) + sds2_offset, data);
     
}


int pq_search(int argc, char *argv[]) {
   int pcie_core_id, ch;

  if (argc < 2){
    printf("not enough argument, pcie_id, ch# \n\r");
    return -1;
  } else {
    pcie_core_id = atoi(argv[0]);
    ch = atoi(argv[1]);
  }

   pq_search_sub(pcie_core_id, ch);
} 

int pq_search_all(int argc, char *argv[]) {
   int pcie_core_id, ch, i;

  if (argc < 1){
    printf("not enough argument, pcie_id \n\r");
    return -1;
  } else {
    pcie_core_id = atoi(argv[0]);
  }

  if(pcie_core_id == 0 || pcie_core_id == 3){
    for(i=0; i < 8; i++){
        pq_search_sub(pcie_core_id, i);
    }
  } else if (pcie_core_id == 1 || pcie_core_id == 4){
    for(i=0; i < 4; i++){
        pq_search_sub(pcie_core_id, i);
    }
  } else
        pq_search_sub(pcie_core_id, 0);
} 


void set_bw_capture_sub(int pcie_core_id){
 int data;

  pcie_csr_write(pcie_core_id, SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR, 0x0);
  pcie_csr_write(pcie_core_id, SM_GLBL_DIAG_CSR_CFG_BW_SLV_STOP_CNT__ADDR, 0x10000);
  pcie_csr_write(pcie_core_id, SM_GLBL_DIAG_CSR_CFG_READ_BW_LAT_ADDR_MASK__ADDR, 0xffffffff);
  pcie_csr_write(pcie_core_id, SM_GLBL_DIAG_CSR_CFG_READ_BW_LAT_ADDR_PAT__ADDR, 0xe0c0010000 >> 10); 
  pcie_csr_write(pcie_core_id, SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR, 0x108);
}

int bw_cap(int argc, char *argv[]) {
   int pcie_core_id, ch;

  if (argc < 1){
    printf("not enough argument, pcie_id \n\r");
    return -1;
  } else {
    pcie_core_id = atoi(argv[0]);
  }

   set_bw_capture_sub(pcie_core_id);
} 

