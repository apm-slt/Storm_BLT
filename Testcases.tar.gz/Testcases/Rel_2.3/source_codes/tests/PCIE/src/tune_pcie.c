#include <types.h>
#include <stdio.h>
#include <common.h>
//Tinh-SLT
#include "../include/pcie_base.h"
#include "../include/pcie_ib_test.h"
#include "../include/margin.h"
//End of Tinh-SLT
//
#define SKIP_BCA

//set to program PVT cal value manually
//#define manual_PVT

//set to bypass receiver detect
#define RCV_DET_BYPASS

//set to allow serdes control TX amplitude and pre/post cursor
//if not set, PIPE controls TX amplitude and pre/post cursor
//#define SDS_TX_CTRL

//set to use reference clock / 2 for serdes workaround on gen1/2
//#define REF_DIVIDE2

//set to use reference clock / 2 for serdes workaround on gen3
#define REF_DIVIDE2_GEN3

//set to use MOMSEL auto calibration
#define MOMSEL_AUTO

//use hot reset for linkup
//#define ENB_HOTRESET

//set to enable debug hook. 
//#define ENB_DEBUG_HOOK

void sm_tune_pcie(uint32_t pcie_core_id, uint32_t port_type, uint32_t en_lpbk, uint32_t gen, uint32_t ext_ref, uint32_t link_width, uint32_t poll) {
uint32_t data, full_width, i, print_state;
uint32_t act_link_width, exp_link_width;
uint32_t act_link_speed, exp_link_speed;
uint32_t  pllnoerr = 1, count = 0;

  act_link_width = 0;
  exp_link_width = link_width;
  act_link_speed = 0;
  exp_link_speed = gen;

#ifndef SM_SOC_SIM
  lprintf(5,"Initializing the Chipscope Pro to bring out PCLK and TC signals on chipscope bus\n\r");
  cpu_write(0x17040000, 0x03000000);
  cpu_read(0x17040000);
#endif  

//  pcie_ddr_remap();   //DDR remap, not used as 40bit DDR map works now
  if (((pcie_core_id == 0) || (pcie_core_id == 3)) && (link_width == 8))
    full_width = 1;
  else
    full_width = 0;

  do {
    lprintf(5,"Initializing the clkrst module to enable the csr clks and deassert the csr resets.\n\r");
    sm_pcie_init_csr_clkrst(pcie_core_id);
  
  #ifdef ENB_DEBUG_HOOK
    sm_pcie_setup_cntlr_pcie_debug_hooks(pcie_core_id, 0, 4);
    //sm_pcie_setup_generic_debug_hooks(pcie_core_id, 0, 0, 2);
    sm_pcie_setup_generic_debug_hooks(pcie_core_id, 0, 0, 1);  //NWL core diagbus
  #endif  
  
    if((pcie_core_id == 0) || (pcie_core_id == 3)){
      if (full_width) {
        lprintf(5,"setting PCIEX8 full width\n\r");
        //setting this bit will allow reset from core 0 to reset serdes of core 1
        data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_MUX__ADDR);
        data = FIELD_PCIE_SDS_MUX_SEL_PCIE_FULL_WIDTH_SET(data, 0x1);
        pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_MUX__ADDR, data);
      }
      else {
        lprintf(5,"Clearing PCIEX8 full width\n\r");
        //setting this bit will allow reset from core 0 to reset serdes of core 1
        data = pcie_csr_read(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_MUX__ADDR);
        data = FIELD_PCIE_SDS_MUX_SEL_PCIE_FULL_WIDTH_SET(data, 0x0);
        pcie_csr_write(pcie_core_id, SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_MUX__ADDR, data);      
      }
    }
  
    tune_phy(pcie_core_id, port_type, gen, ext_ref, link_width, en_lpbk);
  //  sm_pcie_init_phy(pcie_core_id, port_type, gen, ext_ref, link_width, en_lpbk);

    sm_pcie_init_ecc(pcie_core_id);
    lprintf(5,"ECC init done\n\r");
  
  #ifdef SIMULATION  
    sm_pcie_hack_for_sim(pcie_core_id, gen);
  #endif
  
    if(en_lpbk == 1)
      sm_pcie_en_self_crslink(pcie_core_id);
  
    sm_pcie_release_phy_reset(pcie_core_id);
    #ifdef REF_DIVIDE2
      //reference clock divide by 2 doesn't have pll lock set
    #else
      pllnoerr = wait_pll_lock(pcie_core_id, full_width);
    #endif
  } while ((!pllnoerr)&&(++count < 5));
  if (!pllnoerr)
    lprintf(5,"PLL lock failed\n");
  else
    lprintf(5,"PLL lock ok at %d try\n", count);

  sm_pcie_wait_phy_rdy(pcie_core_id);
#ifndef SIMULATION  
  manual_cal(pcie_core_id, link_width);
  force_pvt_cal(pcie_core_id, link_width);
  lat_summer_average_cal(pcie_core_id, link_width);
#endif


#ifdef RCV_DET_BYPASS
  lprintf(5,"Bypassing the receiver detection.\n\r");
  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR);
  data = FIELD_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352_CFG_CONSTANTS_BYPASS_RECEIVER_DETECTION_SET(data, 0x1);
  pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR, data);
#endif

  if(port_type == EP) {
	  lprintf(5,"Initializing the controller for EP mode\n\r");
	  sm_pcie_init_ctrl_ep(pcie_core_id, gen);
  } else {
	  lprintf(5,"Initializing the controller for RC mode\n\r");
	  sm_pcie_init_ctrl_rc(pcie_core_id, gen);

	 data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0__ADDR)); 
  
      data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0_CFG_8G_CONSTANTS_MGMT_DS_PORT_TX_PRESET_SET(data, Ch_RxTxParam[LOCAL_PRESET_IDX][0]);
      data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0_CFG_8G_CONSTANTS_MGMT_US_PORT_TX_PRESET_SET(data, 
      Ch_RxTxParam[REMOTE_PRESET_IDX][0]);

	 pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0__ADDR), data);  

  //RC mode phase 3 and endpoint mode phase 2, USE_PRESET bit is set by default. select PRESET 7 for remote transmitter
    data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_287_256__ADDR);
    data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_287_256_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE0_SET(data, Ch_RxTxParam[REMOTE_BCA_PRESET_IDX][0]);
    data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_287_256_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE1_SET(data, Ch_RxTxParam[REMOTE_BCA_PRESET_IDX][0]);
    pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_287_256__ADDR, data);
   
    data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_319_288__ADDR);
    data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_319_288_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE2_SET(data, Ch_RxTxParam[REMOTE_BCA_PRESET_IDX][0]);
    data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_319_288_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE3_SET(data, Ch_RxTxParam[REMOTE_BCA_PRESET_IDX][0]);
    pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_319_288__ADDR, data);
    
    data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_351_320__ADDR);
    data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_351_320_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE4_SET(data, Ch_RxTxParam[REMOTE_BCA_PRESET_IDX][0]);
    data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_351_320_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE5_SET(data, Ch_RxTxParam[REMOTE_BCA_PRESET_IDX][0]);
    pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_351_320__ADDR, data);

    data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_383_352__ADDR);
    data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_383_352_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE6_SET(data, Ch_RxTxParam[REMOTE_BCA_PRESET_IDX][0]);
    data = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_383_352_CFG_8G_CONSTANTS_EQ_PRE_CURSOR_LANE7_SET(data, Ch_RxTxParam[REMOTE_BCA_PRESET_IDX][0]);
    pcie_csr_write(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_383_352__ADDR, data);

	
	sm_pcie_init_ven_msg_capture(pcie_core_id);
  }
  
  sm_pcie_init_core_clkrst(pcie_core_id);

#ifdef BUG_44393


  data=pcie_csr_read(pcie_core_id,SM_GLBL_ERR_CSR_GLBL_TRANS_ERR__ADDR);
  if(data)
  {
	  lprintf(5,"Transaction Error =  0x%x \n\r",data);
	  pcie_csr_write(pcie_core_id,SM_GLBL_ERR_CSR_GLBL_TRANS_ERR__ADDR,data); 
  } 

  data=pcie_csr_read(pcie_core_id, SM_SLAVE_SHIM_CSR_INT_SLV_TMO__ADDR );
  if(data)
  {
	  lprintf(5,"Slave Error =  0x%x \n\r",data);
	  pcie_csr_write(pcie_core_id,SM_SLAVE_SHIM_CSR_INT_SLV_TMO__ADDR,data); 
  } 

  data=pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_SLVRDERRATTRIBUTES__ADDR );
    if(data)
    {
  	  lprintf(5,"SlaveReadAtt =  0x%x \n\r",data);
  	  pcie_csr_write(pcie_core_id,SM_PCIE_CSR_REGS_SLVRDERRATTRIBUTES__ADDR,data);
    }

//	pcie_csr_write(pcie_core_id,SM_SLAVE_SHIM_CSR_CFG_SLV_RESP_TMO_CNTR__ADDR,1);    // to timeout Pcie
	
#endif

  if (poll) {
	  wait_linkup(pcie_core_id, gen, link_width);

	  MSDELAY(1000);
	  data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_31_0__ADDR);
	  act_link_width = data >> 26;
	  act_link_speed = (data >> 24) & 0x3;
	  printf("Actual link width : %d Actual link speed Gen : %d",act_link_width,act_link_speed+1); lprintf(3,"\n\r");
  }
  }
