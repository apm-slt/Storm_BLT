/*
 */
#include <types.h>
#include <stdio.h>
#include <common.h>
#include "../include/pcie_base.h"
#include "../include/pcie_ib_test.h"


void qi_move_pcie (int pqtarget, int pqstepmag, int pcie_core_id, int ch)
{

   int currpqsign;
   int currpq;
   int step;
   int i, data;
   int sds2_offset;
   int vRange;
   int qinit;
   int qend;
   int qskip, newpq;
   int pqsign, pqval;

   printf("qi move %d, %d, \n", pqtarget, pqstepmag);
   // This function to smoothly move QI to target
   
   if(ch>=4){
    sds2_offset = 0x30000;
   } else {
    sds2_offset = 0;
   }

   data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG126__ADDR + (0x200 * ch) + sds2_offset);
   currpqsign = FIELD_CH0_RXTX_REG126_SIGN_QI_REG_RD(data);
   currpq = FIELD_CH0_RXTX_REG126_QI_REG_RD(data);

   if (currpqsign==1)
      currpq = currpq * -1;

   if (pqtarget >= currpq)
      step = pqstepmag;
   else
      step= pqstepmag * -1;

   //printf("currpq %d \n", currpq);
   newpq = currpq;
   for(newpq = currpq; newpq <= pqtarget; newpq = newpq +step){
      if (newpq >= 0) {
         pqsign = 0;
         pqval = newpq;
      }
      else {
         pqsign = 1;
         pqval = newpq * -1;
      }
      //WriteReg('sign_qi_reg', pqsign)
      //WriteReg('qi_reg', pqval)
      data = FIELD_CH0_RXTX_REG126_SIGN_QI_REG_SET(data, pqsign);
      data = FIELD_CH0_RXTX_REG126_QI_REG_SET(data, pqval);
      printf("qi %d sign_qi %d\n", pqval, pqsign);
      pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG126__ADDR + (0x200 * ch) + sds2_offset, data);
      newpq = newpq + step;
      //printf("newpq %d \n", newpq);
   };// while (newpq < pqtarget);
}
//Tinh-SLT
//void es_singlephase(int vRange, int vskip, int pcie_core_id, int ch) {
void es_singlephase_pcie(int vRange, int vskip, int pcie_core_id, int ch) {

   int vm;
   int fullFlag;
   int es_data;
   int es_data1;
   int es_data2;
   int est_data;
   int est_data1;
   int est_data2;
   int sds2_offset, data;

   if(ch>=4){
    sds2_offset = 0x30000;
    ch = ch -4;
   } else {
    sds2_offset = 0;
   }


   // function to sweep voltage level
   for (vm=0; vm < vRange; vm = vm + vskip) {
      // set vmargin to new value
   //   WriteReg('escan_vmargin',vm) 
      
      data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG19__ADDR + (0x200 * ch) + sds2_offset);
      data = FIELD_CH0_RXTX_REG19_ESCAN_VMARGIN_SET(data, vm);
      pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG19__ADDR + (0x200 * ch) + sds2_offset, data);
      // toggle resetb
      data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset);
      data = FIELD_CH3_RXTX_REG61_EYE_ACC_RESETB_SET(data, 0);
      pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset, data);
      
      data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset);
      data = FIELD_CH3_RXTX_REG61_EYE_ACC_RESETB_SET(data, 1);
      pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset, data);
      // poll for data full flag
      
      do {
         data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG118__ADDR + (0x200 * ch) + sds2_offset);
	     fullFlag = FIELD_CH0_RXTX_REG118_ACC_FULL_FLAG_RD(data);
         //printf("waiting full flag \n");
     } while (fullFlag == 0);

      // trigger data capture
      data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset);
      data = FIELD_CH0_RXTX_REG61_EYE_MONITOR_CAPTURE_SET(data, 1);
      pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset, data);
      
      data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset);
      data = FIELD_CH0_RXTX_REG61_EYE_MONITOR_CAPTURE_SET(data, 0);
      pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset, data);

      // read data to string
      es_data1 = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG123__ADDR + (0x200 * ch) + sds2_offset);
      es_data2 = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG124__ADDR + (0x200 * ch) + sds2_offset);
      //es_data = es_data1*(2**16)+es_data2;
      es_data = es_data1*65536+es_data2;
      est_data1 = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG161__ADDR + (0x200 * ch) + sds2_offset);
      est_data2 = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG162__ADDR + (0x200 * ch) + sds2_offset);
      //est_data = est_data1*(2**16)+est_data2;
      est_data = est_data1*65536+est_data2;
      
      printf ("es_str: %d \n", es_data);
      printf ("est_str: %d \n", est_data);

   }
}   

void eyescan_sub (int pcie_core_id, int ch){
   int vRange;
   int qinit;
   int qend;
   int qskip;
   int num_of_steps;
   int increment;
   int barVal;
   int sds2_offset;
   int ch_adj, data, qi;
   int pqsign, pqval;
   
   if(ch>=4){
    sds2_offset = 0x30000;
    ch_adj = ch-4;
   } else {
    sds2_offset = 0;
    ch_adj = ch;
   }

   vRange = 64;
   qinit = -64;
   qend = 64;
   qskip = 1;


  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG145__ADDR + (0x200 * ch_adj) + sds2_offset);
  data = FIELD_CH0_RXTX_REG145_RXVWES_LATENA_SET(data, 1);
  data = FIELD_CH0_RXTX_REG145_RXES_ENA_SET(data, 1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG145__ADDR + (0x200 * ch_adj) + sds2_offset, data);

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG62__ADDR + (0x200 * ch_adj) + sds2_offset);
  data = FIELD_CH1_RXTX_REG62_PERIOD_H1_QLATCH_SET(data, 2);
  data = FIELD_CH1_RXTX_REG62_SWITCH_H1_QLATCH_SET(data, 1);
  data = FIELD_CH1_RXTX_REG62_H1_QLATCH_SIGN_INV_SET(data, 0);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG62__ADDR + (0x200 * ch_adj) + sds2_offset, data);
  
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch_adj) + sds2_offset);
  data = FIELD_CH1_RXTX_REG61_EYE_COUNT_WIDTH_SEL_SET(data, 2);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch_adj) + sds2_offset, data);
  

   //qi_move(qinit,2, pcie_core_id, ch); // Move to qinit from current qi in step of 2

//   for qi from qinit to qend 
   printf("CHANNEL %d START \n", ch);
   for (qi = qinit ; qi < qend; qi= qi+qskip) 
   {
     // qi_move(qi,qskip, pcie_core_id, ch);
      
      data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG126__ADDR + (0x200 * ch_adj) + sds2_offset);
      if(qi<0){
        pqsign = 1;
        pqval = qi * -1;
      } else {
        pqsign = 0;
        pqval = qi;
      };
      data = FIELD_CH0_RXTX_REG126_SIGN_QI_REG_SET(data, pqsign);
      data = FIELD_CH0_RXTX_REG126_QI_REG_SET(data, pqval);
      printf("qi %d sign_qi %d\n", pqval, pqsign);
      pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG126__ADDR + (0x200 * ch_adj) + sds2_offset, data);
      
      es_singlephase_pcie(vRange, qskip, pcie_core_id, ch);
      printf("endscan \n");
   }
   //qi_move(0,2, pcie_core_id, ch);
   printf("CHANNEL %d END \n", ch);
   
   data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG19__ADDR + (0x200 * ch_adj) + sds2_offset);
   data = FIELD_CH2_RXTX_REG19_ESCAN_VMARGIN_SET(data, 0);
   pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG19__ADDR + (0x200 * ch_adj) + sds2_offset, data);
     
}

int eyescan(int argc, char *argv[]) {
   int pcie_core_id, ch;

  if (argc < 2){
    printf("not enough argument, pcie_id, ch# \n\r");
    return -1;
  } else {
    pcie_core_id = atoi(argv[0]);
    ch = atoi(argv[1]);
  }

   eyescan_sub(pcie_core_id, ch);
} 


int eyescan_all(int argc, char *argv[]) {
   int pcie_core_id, ch, i;

  if (argc < 1){
    printf("not enough argument, pcie_id \n\r");
    return -1;
  } else {
    pcie_core_id = atoi(argv[0]);
  }

  if(pcie_core_id == 0 || pcie_core_id == 3){
    for(i=0; i < 8; i++){
        eyescan_sub(pcie_core_id, i);
    }
  } else if (pcie_core_id == 1 || pcie_core_id == 4){
    for(i=0; i < 4; i++){
        eyescan_sub(pcie_core_id, i);
    }
  } else
        eyescan_sub(pcie_core_id, 0);
} 

