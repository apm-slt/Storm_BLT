//Tinh-SLT
#include "../include/pcie_ob_test.h"
//End of Tinh-SLT
//#define Change2
#define SNOOP_ENABLE 0x00000000
void config_pom_regs(uint32_t pcie_core_id, uint64_t pcie_pom1, uint64_t pcie_pom2, uint64_t pcie_pom3) {
  uint32_t data;

  data = (uint32_t) pcie_pom1;
  lprintf(5,"Configuring SM_PCIE_CSR_REGS_POM1L__ADDR reg with "); putnum_pcie(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_POM1L__ADDR,data);
  
  data = pcie_pom1 >> 32;
  lprintf(5,"Configuring SM_PCIE_CSR_REGS_POM1H__ADDR reg with "); putnum_pcie(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_POM1H__ADDR,data);
  
  data = (uint32_t) pcie_pom2;
  lprintf(5,"Configuring SM_PCIE_CSR_REGS_POM2L__ADDR reg with "); putnum_pcie(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_POM2L__ADDR,data);
  
  data = pcie_pom2 >> 32;
  lprintf(5,"Configuring SM_PCIE_CSR_REGS_POM2H__ADDR reg with "); putnum_pcie(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_POM2H__ADDR,data);
  
  data = (uint32_t) pcie_pom3;
  lprintf(5,"Configuring SM_PCIE_CSR_REGS_POM3L__ADDR reg with "); putnum_pcie(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_POM3L__ADDR,data);
  
  data = pcie_pom3 >> 32;
  lprintf(5,"Configuring SM_PCIE_CSR_REGS_POM3H__ADDR reg with "); putnum_pcie(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_POM3H__ADDR,data);
}

void sm_pcie_setup_omr1(uint32_t pcie_core_id) {
  uint32_t data;
  uint64_t PCIE_OMR1;

  PCIE_OMR1 = ret_omr1_base(pcie_core_id);

  data = (uint32_t) PCIE_OMR1;
//  lprintf(5,"Configuring SM_PCIE_CSR_REGS_OMR1BARL__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_OMR1BARL__ADDR,data);
  
  data = PCIE_OMR1 >> 32;
  data|=SNOOP_ENABLE;
//  lprintf(5,"Configuring SM_PCIE_CSR_REGS_OMR1BARH__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_OMR1BARH__ADDR,data);

  data = (uint32_t) OMR1_MASK | 1; // set bit 0, to indicate that the region is valid.
//  lprintf(5,"Configuring SM_PCIE_CSR_REGS_OMR1MSKL__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_OMR1MSKL__ADDR,data);
  
  data = OMR1_MASK >> 32;
//  lprintf(5,"Configuring SM_PCIE_CSR_REGS_OMR1MSKH__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_OMR1MSKH__ADDR,data);
}  

void sm_pcie_setup_omr2(uint32_t pcie_core_id) {
  uint32_t data;
  uint64_t PCIE_OMR2;

  PCIE_OMR2 = ret_omr2_base(pcie_core_id);

  data = (uint32_t) PCIE_OMR2;
//  lprintf(5,"Configuring SM_PCIE_CSR_REGS_OMR2BARL__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_OMR2BARL__ADDR,data);
  
  data = PCIE_OMR2 >> 32;
  data|=SNOOP_ENABLE;
//  lprintf(5,"Configuring SM_PCIE_CSR_REGS_OMR2BARH__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_OMR2BARH__ADDR,data);

  data = (uint32_t) OMR2_MASK | 1; // set bit 0, to indicate that the region is valid.
//  lprintf(5,"Configuring SM_PCIE_CSR_REGS_OMR2MSKL__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_OMR2MSKL__ADDR,data);
  
  data = OMR2_MASK >> 32;
//  lprintf(5,"Configuring SM_PCIE_CSR_REGS_OMR2MSKH__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_OMR2MSKH__ADDR,data);
}

void sm_pcie_setup_omr3(uint32_t pcie_core_id, uint32_t port_type) {
  uint32_t data;
  uint64_t PCIE_OMR3;

  PCIE_OMR3 = ret_omr3_base(pcie_core_id);

  data = (uint32_t) PCIE_OMR3;
//  lprintf(5,"Configuring SM_PCIE_CSR_REGS_OMR3BARL__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_OMR3BARL__ADDR,data);
  
  data = PCIE_OMR3 >> 32;
  data|=SNOOP_ENABLE;
//  lprintf(5,"Configuring SM_PCIE_CSR_REGS_OMR3BARH__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_OMR3BARH__ADDR,data);

  data = (uint32_t) OMR3_MASK | 1; // set bit 0, to indicate that the region is valid.

  // For RC DUT, OMR3 region is marked as io region. So, need to set bit 1 of the mask.
  if(port_type == RC)
    data |= 2; 

//  lprintf(5,"Configuring SM_PCIE_CSR_REGS_OMR3MSKL__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_OMR3MSKL__ADDR,data);
  
  data = OMR3_MASK >> 32;
//  lprintf(5,"Configuring SM_PCIE_CSR_REGS_OMR3MSKH__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_OMR3MSKH__ADDR,data);
}

void sm_pcie_setup_ob_cfg(uint32_t pcie_core_id, uint32_t port_type){
  uint32_t data;
  uint64_t SM_ADDR_MAP_PCIE_OB_CFG_BASE;
  uint32_t mps;

  SM_ADDR_MAP_PCIE_OB_CFG_BASE = ret_ob_cfg_base(pcie_core_id);

  data = SM_ADDR_MAP_PCIE_OB_CFG_BASE >> 32;
  data|=SNOOP_ENABLE; 
//  data = data | 0x240000000;              // Enable this Attribute field, in outbound traffic
                                            // When validating Snoop/ordering OR MSI

  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_CFGBARH__ADDR, data);
  //lprintf(5,"CFGBARH is 0x%0x \n\r", data);

  data = (uint32_t) SM_ADDR_MAP_PCIE_OB_CFG_BASE;
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_CFGBARL__ADDR, data);  
  //lprintf(5,"CFGBARL is 0x%0x \n\r", data);

  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_CFGCTL__ADDR, 1);
  
  if(port_type == RC) {
    data = 0x100; //bn 1, dn and fn is 0
    pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_RTDID__ADDR, data);
  
    //Daniel: set primary, secondary, sub-ord bus number
    //lprintf(5,"Programming the bus number register\n\r");
    data = 0x40030100;
    pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_BUS_NUMBER__ADDR, data);
    //lprintf(5,"Programming the max payload size for RC\n\r");
    data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_DEV_CTRL__ADDR);
	if(data == 0xFFFFFFFF) lprintf(5,"First Cfg Acces : 0x%x \n\r",data);
	
    data &= 0xFFFFFF1F;
    mps = extract_max_payload_size(pcie_core_id);
    data = data | (mps << 5);
#ifdef Change2
    data = data | ((mps+1) << 12 );
#endif
    pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_DEV_CTRL__ADDR, data);  

    //lprintf(5,"Enabling the bus master in the RC\n\r");
    data = 0x147;
    pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_CMD__ADDR, data);
  }
};

void sm_pcie_setup_ob_msg(uint32_t pcie_core_id){
  uint32_t data;
  uint64_t PCIE_OB_MSGBAR;

  PCIE_OB_MSGBAR = ret_ob_msg_base(pcie_core_id);
  data = (uint32_t) PCIE_OB_MSGBAR;
//  lprintf(5,"Configuring SM_PCIE_CSR_REGS_MSGBARL__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_MSGBARL__ADDR,data);
  
  data = PCIE_OB_MSGBAR >> 32;
//  lprintf(5,"Configuring SM_PCIE_CSR_REGS_MSGBARH__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_MSGBARH__ADDR,data);
  
  data = 1;
//  lprintf(5,"Enabling MSGBAR by writing SM_PCIE_CSR_REGS_MSGCTL__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_MSGCTL__ADDR,data);

//  lprintf(5," MSGCTRL : %d \n\r",pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_MSGCTL__ADDR) );

}

void sm_pcie_setup_ob_space(uint32_t pcie_core_id, uint32_t port_type) {

  sm_pcie_setup_omr1(pcie_core_id);
  sm_pcie_setup_omr2(pcie_core_id);
  sm_pcie_setup_omr3(pcie_core_id, port_type);
  
  sm_pcie_setup_ob_msg(pcie_core_id);
}  

// This function writes all 1s to the BAR and reads it back. Depending on the value returned, 
// BAR will be programmed afterwards.
uint32_t sm_pcie_probe_ep_bar(uint32_t pcie_core_id, uint32_t bar_num) {
  uint32_t data;

  lprintf(5,"Probing for BAR "); putnum_pcie(bar_num); lprintf(5,"\n\r");
  data = 0xFFFFFFFF;
  pcie_ob_cfg_write(pcie_core_id, (SM_PCIE_CFG0_PCIE_CFG0_BAR0__ADDR + bar_num*4), data);

  data = pcie_ob_cfg_read(pcie_core_id, (SM_PCIE_CFG0_PCIE_CFG0_BAR0__ADDR + bar_num*4));

  return data;
};  

// This function reads device ID and vendor ID  first 
uint32_t sm_pcie_read_device_id(uint32_t pcie_core_id) {
  uint32_t data;

  lprintf(5,"Reading Device ID ");lprintf(5,"\n\r");

  data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR);
  lprintf(5,"Device ID : ");putnum_pcie(data);lprintf(5,"\n\r");
  return data;
}

// This function sets the BAR for PCIE.
void sm_pcie_set_ep_bar(uint32_t pcie_core_id, uint32_t bar_num, uint64_t base_addr, uint32_t bar_width) {
  uint32_t data;

  data = (uint32_t) base_addr;
  lprintf(5,"Setting BAR "); putnum_pcie(bar_num); lprintf(5," with base_addr = "); putnum_pcie(data); lprintf(5,"\n\r");
  pcie_ob_cfg_write(pcie_core_id, (SM_PCIE_CFG0_PCIE_CFG0_BAR0__ADDR + bar_num*4), data);

  if(bar_width) {
    data = (uint32_t) (base_addr >> 32);
    lprintf(5,"Setting BAR "); putnum_pcie(bar_num+1); lprintf(5," with base_addr = "); putnum_pcie(data); lprintf(5,"\n\r");
    pcie_ob_cfg_write(pcie_core_id, (SM_PCIE_CFG0_PCIE_CFG0_BAR0__ADDR + (bar_num+1)*4), data);
  }    
};  

void sort_bar_info(struct bar_info *bar_arr) {
  uint64_t temp_size;
  uint32_t temp_id;
  uint32_t i, j;

  for(i = 0; i <= 5; i++) {
    for(j = i+1; j <=5; j++) {
      if(bar_arr[i].bar_size < bar_arr[j].bar_size) {
        temp_size = bar_arr[i].bar_size;
        bar_arr[i].bar_size = bar_arr[j].bar_size;
        bar_arr[j].bar_size = temp_size;

        temp_id = bar_arr[i].bar_id;
        bar_arr[i].bar_id = bar_arr[j].bar_id;
        bar_arr[j].bar_id = temp_id;        
      }
    }
  }
}  

void sm_pcie_enum_ep(uint32_t pcie_core_id, struct ep_bar *ep_bars_ptr) { 
  uint32_t i;
  uint32_t io;
  uint32_t bar_width;
  uint32_t prefetch;
  uint32_t bar_info;
  uint32_t base_addrl, base_addrh;     
  uint64_t base_addr, bar_size;     

  uint64_t prefetch_mem_base, prefetch_mem_limit;
  uint32_t mem_base, mem_limit;
  uint32_t io_base, io_limit;
  uint32_t data;
  struct bar_info io_arr[6], mem_arr[6], pf_mem_arr[6];
  uint32_t io_arr_ptr, mem_arr_ptr, pf_mem_arr_ptr;

  prefetch_mem_base = PREFETCH_MEM_BASE;
  prefetch_mem_limit= PREFETCH_MEM_BASE;
  mem_base = MEM_BASE;
  mem_limit= MEM_BASE;
  io_base  = IO_BASE;
  io_limit = IO_BASE;

  
 
  
  for(i = 0; i <= 5; i++) {
    io_arr[i].bar_size = 0;
    io_arr[i].bar_id = 0;
    mem_arr[i].bar_size = 0;
    mem_arr[i].bar_id = 0;
    pf_mem_arr[i].bar_size = 0;
    pf_mem_arr[i].bar_id = 0;
  }

  bar_width = 0;
  io_arr_ptr = 0;
  mem_arr_ptr = 0;
  pf_mem_arr_ptr = 0;
  for(i = 0; i <= 5; i++) { 
    bar_info = sm_pcie_probe_ep_bar(pcie_core_id, i);
    
    if(bar_info == 0) {
      lprintf(5,"BAR "); putnum_pcie(i); lprintf(5," is disabled.\n\r");
      continue;
    }

    io = FIELD_PCIE_CFG0_BAR0_IO_TYPE_RD(bar_info);
    bar_width = FIELD_PCIE_CFG0_BAR0_BAR_WIDTH_RD(bar_info);
    prefetch  = FIELD_PCIE_CFG0_BAR0_PREFETCH_RD(bar_info);
    base_addrl= bar_info & FIELD_PCIE_CFG0_BAR0_BASE_ADDR_MASK;
    if(bar_width) {
      bar_info  = sm_pcie_probe_ep_bar(pcie_core_id, i+1);
      base_addrh= bar_info;
    }  
    else {
      base_addrh= 0xFFFF;
    }

    base_addr = ((uint64_t) base_addrh << 32) + base_addrl;
    bar_size = ~base_addr;

    lprintf(5,"BAR size for BAR "); putnum_pcie(i); lprintf(5," is "); putnum_pcie(bar_size); lprintf(5,"\n\r");

    if(io) {
      io_arr[io_arr_ptr].bar_size = bar_size;
      io_arr[io_arr_ptr].bar_id = i;
      io_arr_ptr++;
    }
    else {
      if(prefetch) {
        pf_mem_arr[pf_mem_arr_ptr].bar_size = bar_size;
        pf_mem_arr[pf_mem_arr_ptr].bar_id = i;
        pf_mem_arr_ptr++;
      }
      else {
        mem_arr[mem_arr_ptr].bar_size = bar_size;
        mem_arr[mem_arr_ptr].bar_id = i;
        mem_arr_ptr++;
      }        
    }
    if(bar_width)
      i++;
  }
  sort_bar_info(io_arr);
  sort_bar_info(mem_arr);
  sort_bar_info(pf_mem_arr);

  for(i = 0; i<=5; i++) {
    bar_size = io_arr[i].bar_size;
    if(bar_size == 0)
      break;

    base_addr = ~bar_size;
    base_addr &= ((uint64_t) io_limit + bar_size);
    io_limit = (uint32_t) (base_addr + bar_size);

    ep_bars_ptr[io_arr[i].bar_id].offset = (uint32_t)(base_addr - io_base);
    ep_bars_ptr[io_arr[i].bar_id].type = 0;
    ep_bars_ptr[io_arr[i].bar_id].valid = 1;

    sm_pcie_set_ep_bar(pcie_core_id, io_arr[i].bar_id, base_addr, 0);    
  }
//  data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_IO_BASE__ADDR);
//  data |= (io_base >> 12) & 0xF;


  for(i = 0; i<=5; i++) {
    bar_size = mem_arr[i].bar_size;
    if(bar_size == 0)
      break;

    base_addr = ~bar_size;
    base_addr &= ((uint64_t) mem_limit + bar_size);
    mem_limit = (uint32_t) (base_addr + bar_size);

    ep_bars_ptr[mem_arr[i].bar_id].offset = (uint32_t)(base_addr - mem_base);
    ep_bars_ptr[mem_arr[i].bar_id].type = 1;
    ep_bars_ptr[mem_arr[i].bar_id].valid = 1;
    
    sm_pcie_set_ep_bar(pcie_core_id, mem_arr[i].bar_id, base_addr, 0);    
  }

  for(i = 0; i<=5; i++) {
    bar_size = pf_mem_arr[i].bar_size;
    if(bar_size == 0)
      break;

    base_addr = ~bar_size;
    base_addr &= (prefetch_mem_limit + bar_size);
    prefetch_mem_limit = base_addr + bar_size;

    ep_bars_ptr[pf_mem_arr[i].bar_id].offset = (uint32_t)(base_addr - prefetch_mem_base);
    ep_bars_ptr[pf_mem_arr[i].bar_id+1].offset = (uint32_t)((base_addr - prefetch_mem_base)>>32);
    ep_bars_ptr[pf_mem_arr[i].bar_id].type = 2;
    ep_bars_ptr[pf_mem_arr[i].bar_id].valid = 1;
    ep_bars_ptr[pf_mem_arr[i].bar_id+1].valid = 0;

    sm_pcie_set_ep_bar(pcie_core_id, pf_mem_arr[i].bar_id, base_addr, 1);    
  }

  // To be on safer side, added some buffer range to the limits.
  io_limit = io_limit + 0x1000; 
  mem_limit = mem_limit + 0x100000; 
  prefetch_mem_limit = prefetch_mem_limit + 0x100000;

  data = (((io_base & 0xF000) >> 8) | 0x1);
  data |= ((io_limit & 0xF000) | 0x100);
  pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_IO_BASE__ADDR, data);

  data = (io_base & 0xFFFF0000) >> 16;
  data |= (io_limit & 0xFFFF0000);
  pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_IO_BASE_UPPER__ADDR, data);

  data = (mem_base & 0xFFF00000) >> 16;
  data |= (mem_limit & 0xFFF00000);
  pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_MEM_BASE__ADDR, data);

  data = (((prefetch_mem_base & 0xFFF00000) >> 16) | 0x1);
  data |= ((prefetch_mem_limit & 0xFFF00000) | 0x10000);
  pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_PREFETCH_MEM_BASE__ADDR, data);

  data = prefetch_mem_base >> 32;
  pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_PREFETCH_BASE_UPPER__ADDR, data);

  data = prefetch_mem_limit >> 32;
  pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_PREFETCH_BASE_LIMIT__ADDR, data);

  //do cfg0 write 0x4 and set memory enable bit to indicate config process is complete to endpoint
  data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_CMD__ADDR);
  data |= 0x7;
  pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_CMD__ADDR, data);

  config_pom_regs(pcie_core_id, prefetch_mem_base, mem_base, io_base);

};

void send_ob_msg(uint32_t pcie_core_id, uint32_t msg_code, uint32_t msg_routing_code, uint32_t msg_data) {
  uint64_t msg_addr;

  msg_addr = ret_ob_msg_base(pcie_core_id);
  msg_addr |= msg_code << 2;
  msg_addr |= (msg_routing_code << 8) << 2;

  msg_addr |= ((msg_data != 0) << 13);
  // msg_addr &= ~(1 << 13);
  // msg_addr |= (1 << 13);
  lprintf(5,"MSG_DATA : 0x%x\n\r",msg_data);
  cpu_write(msg_addr, msg_data);
};



