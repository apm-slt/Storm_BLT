/*
 * Copyright (c) 2013 AppliedMicro.  All rights reserved.
 *
 * program brief: pcie_dump.c: dump pcie mem setup after configured for Storm 
 * history: v0.1 2013.2 jodai@apm.com
 */

#include <stdio.h>
//Tinh-SLT
#include "../include/pcie_ib_test.h"
#include "../include/sm_addr_map.h"
#include "../include/pcie_x8_regs_addrmap.h"
#include "../include/pcie_base.h"
#include "../include/pcie_dma_test.h"
//End of Tinh-SLT
#define uint32_t unsigned int
#define uint64_t unsigned long long
//#define SM_PCIE_X8_SDS_CSR_REGS_PCIE_SDS_IND_CMD_REG__ADDR 0xa014
extern uint32_t csr_base_addr[5];

#define SHOWRW  1
#define REALRW	2
#define PARAMS  4
#if defined(CONFIG_VHP) | defined(CONFIG_BB1) | defined(CONFIG_BB2)
#define DEBUG 	(SHOWRW | REALRW | PARAMS)
#else
#define DEBUG 	(SHOWRW | PARAMS)
#endif

#if 1
uint32_t read(uint64_t address);
void write(uint64_t address, unsigned int data);
#else
uint32_t read(uint32_t address);
void write(uint32_t address, unsigned int data);
#endif
uint32_t read_csr(int iport, uint32_t offset);
void write_csr(int iport, uint32_t offset, uint32_t data);
uint32_t read_phy(int iport, uint32_t offset);
void write_phy(int iport, uint32_t offset, uint32_t data);
static void test_aspm(unsigned int core);

//void sm_pcie_init(uint32_t pcie_core_id, uint32_t port_type, uint32_t en_lpbk, uint32_t gen, uint32_t ext_ref, uint32_t link_width, uint32_t poll)
int pciinit(int argc, char *argv[])
{
  int i=argc+1, j=0;
  int error=0;
  uint32_t pcie_core_id,port_type,en_lpbk=0,gen,ext_ref=1,link_width;
  uint32_t data= 0;
  uint64_t SM_ADDR_MAP_PCIE_OB_CFG_BASE;

  SM_ADDR_MAP_PCIE_OB_CFG_BASE = ret_ob_cfg_base(pcie_core_id);

  if ((i<7)||(i>8)) 
    error=1;
  else {
    pcie_core_id = atoi(argv[j++]);
    port_type = atoi(argv[j++]);
    en_lpbk = atoi(argv[j++]);
    gen = atoi(argv[j++]);
    ext_ref = atoi(argv[j++]);
    link_width= atoi(argv[j++]);
    if ((i>7)&&(port_type)) 
      data= atoi(argv[j++]) & 1;
    if ((pcie_core_id>4)||(port_type>1)||(gen>2)||((link_width!=8)&&(link_width!=4)&&(link_width!=2)&&(link_width!=1)))
      error = 2;
  }
  if (error) {
    printf("pciinit argument error %d. Syntax: pcie_core_id port_type en_lpbk gen ext_ref link_width\n", error);
//      printf("pciinit argument error %d. Syntax: pcie_core_id port_type gen link_width\n", error);
    return error;
  }
  sm_pcie_init(pcie_core_id, port_type, en_lpbk, gen, ext_ref, link_width, data);
#if 0
  if (port_type==1) {
      data = SM_ADDR_MAP_PCIE_OB_CFG_BASE >> 32;
      pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_CFGBARH__ADDR, data);
      data = (uint32_t) SM_ADDR_MAP_PCIE_OB_CFG_BASE;
      pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_CFGBARL__ADDR, data);  
      pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_CFGCTL__ADDR, 1);
  }
#endif
  printf("pciinit completed\n");
  return 0;
}

void base_dump_bar(uint32_t iport, uint32_t ep_rc)
{
  uint32_t d1,d2,d3,d4,bar_num=0;
  uint64_t cfgbar64;

  cfgbar64 = read_csr(iport, SM_PCIE_CSR_REGS_CFGBARH__ADDR) & 0x3FF;   //high 10bit
  cfgbar64 = (cfgbar64<<32) | read_csr(iport, SM_PCIE_CSR_REGS_CFGBARL__ADDR);
//  if (cfgbar64==0) {
//    printf("CFGBARH-L are 0, cannot read CFG1\n");
//  }

  d1=read_csr(iport, SM_PCIE_CSR_REGS_CFGCTL__ADDR) & 1;
  write_csr(iport, SM_PCIE_CSR_REGS_CFGCTL__ADDR, 1);   //enable
  d2=read_csr(iport, SM_PCIE_CSR_REGS_RTDID__ADDR);
  printf("CFGBARH-L=%x-%8x,CFGCTL=%1d,RTDID=%x\n", cfgbar64>>32,cfgbar64&0xFFFFFFFF,d1,d2);

  if (cfgbar64) {  
    d1 = pcie_ob_cfg_read(iport, SM_PCIE_CFG1_PCIE_CFG1_BUS_NUMBER__ADDR);
    d2 = pcie_ob_cfg_read(iport, SM_PCIE_CFG1_PCIE_CFG1_DEV_CTRL__ADDR);
    d3 = pcie_ob_cfg_read(iport, SM_PCIE_CFG1_PCIE_CFG1_CMD__ADDR);
    printf("CFG1@PCIe: BUS#=%x,DEV_CTRL=%x, CMD=%x\n", d1,d2,d3);  
  }
  d1=read_csr(iport, SM_PCIE_CSR_REGS_MSGBARH__ADDR);
  d2=read_csr(iport, SM_PCIE_CSR_REGS_MSGBARL__ADDR);
  d3=read_csr(iport, SM_PCIE_CSR_REGS_MSGCTL__ADDR);
  printf("MSGBAR=%x-%8x, MSGCTL=%x\n\n", d1,d2,d3);  
//
  d1=read_csr(iport, SM_PCIE_CSR_REGS_OMR1BARH__ADDR);
  d2=read_csr(iport, SM_PCIE_CSR_REGS_OMR1BARL__ADDR);
  d3=read_csr(iport, SM_PCIE_CSR_REGS_OMR2BARH__ADDR);
  d4=read_csr(iport, SM_PCIE_CSR_REGS_OMR2BARL__ADDR);
  printf("OMRxBAR=%x-%8x, %x-%8x, ", d1,d2,d3,d4);  
  d1=read_csr(iport, SM_PCIE_CSR_REGS_OMR3BARH__ADDR);
  d2=read_csr(iport, SM_PCIE_CSR_REGS_OMR3BARL__ADDR);
  printf("%x-%8x\n", d1,d2);  

  d1=read_csr(iport, SM_PCIE_CSR_REGS_OMR1MSKH__ADDR);
  d2=read_csr(iport, SM_PCIE_CSR_REGS_OMR1MSKL__ADDR);
  d3=read_csr(iport, SM_PCIE_CSR_REGS_OMR2MSKH__ADDR);
  d4=read_csr(iport, SM_PCIE_CSR_REGS_OMR2MSKL__ADDR);
  printf("OMRxMSK=%x-%8x, %x-%8x, ", d1,d2,d3,d4);  
  d1=read_csr(iport, SM_PCIE_CSR_REGS_OMR3MSKH__ADDR);
  d2=read_csr(iport, SM_PCIE_CSR_REGS_OMR3MSKL__ADDR);
  printf("%x-%8x\n", d1,d2);  

  d1=read_csr(iport, SM_PCIE_CSR_REGS_POM1H__ADDR);
  d2=read_csr(iport, SM_PCIE_CSR_REGS_POM1L__ADDR);
  d3=read_csr(iport, SM_PCIE_CSR_REGS_POM2H__ADDR);
  d4=read_csr(iport, SM_PCIE_CSR_REGS_POM2L__ADDR);
  printf("POM1~3 %x-%8x, %x-%8x, ",d1,d2,d3,d4);
  d1=read_csr(iport, SM_PCIE_CSR_REGS_POM3H__ADDR);
  d2=read_csr(iport, SM_PCIE_CSR_REGS_POM3L__ADDR);
  printf("%x-%8x\n\n", d1,d2);
//
  d1=read_csr(iport, SM_PCIE_CSR_REGS_PIM1_1H__ADDR);
  d2=read_csr(iport, SM_PCIE_CSR_REGS_PIM1_1L__ADDR);
  d3=read_csr(iport, SM_PCIE_CSR_REGS_PIM1_2H__ADDR);
  d4=read_csr(iport, SM_PCIE_CSR_REGS_PIM1_2L__ADDR);
  printf("PIM1_1=%x-%8x, PIM1_2=%x-%8x, ", d1,d2,d3,d4);
  d1=read_csr(iport, SM_PCIE_CSR_REGS_PIM1SH__ADDR);
  d2=read_csr(iport, SM_PCIE_CSR_REGS_PIM1SL__ADDR);
  printf("PIM1S=%x-%8x\n", d1,d2);
  d1=read_csr(iport, SM_PCIE_CSR_REGS_PIM2_1H__ADDR);
  d2=read_csr(iport, SM_PCIE_CSR_REGS_PIM2_1L__ADDR);
  d3=read_csr(iport, SM_PCIE_CSR_REGS_PIM2_2H__ADDR);
  d4=read_csr(iport, SM_PCIE_CSR_REGS_PIM2_2L__ADDR);
  printf("PIM2_1=%x-%8x, PIM2_2=%x-%8x, ", d1,d2,d3,d4);
  d1=read_csr(iport, SM_PCIE_CSR_REGS_PIM2S__ADDR);
  printf("PIM2S=%0x\n",d1);
  d1=read_csr(iport, SM_PCIE_CSR_REGS_PIM3_1H__ADDR);
  d2=read_csr(iport, SM_PCIE_CSR_REGS_PIM3_1L__ADDR);
  d3=read_csr(iport, SM_PCIE_CSR_REGS_PIM3_2H__ADDR);
  d4=read_csr(iport, SM_PCIE_CSR_REGS_PIM3_2L__ADDR);
  printf("PIM3_1=%x-%8x, PIM3_2=%x-%8x, ", d1,d2,d3,d4);
  d1=read_csr(iport, SM_PCIE_CSR_REGS_PIM3SH__ADDR);
  d2=read_csr(iport, SM_PCIE_CSR_REGS_PIM3SL__ADDR);
  printf("PIM3S=%x-%8x\n",d1,d2);
//
  if (ep_rc) {  //rc
    d1=read_csr(iport, NWL_PCIE_APB_REGS_EXPRESSO_RP_STATUS_RP_STATUS_95_64__ADDR);
    d2=read_csr(iport, NWL_PCIE_APB_REGS_EXPRESSO_RP_STATUS_RP_STATUS_127_96__ADDR);
    d3=read_csr(iport, NWL_PCIE_APB_REGS_EXPRESSO_RP_STATUS_RP_STATUS_159_128__ADDR);
    d4=read_csr(iport, NWL_PCIE_APB_REGS_EXPRESSO_RP_STATUS_RP_STATUS_191_160__ADDR);
    printf("BAR0~1=0x%x-%8x, 0x%x-%8x\n", d1,d2,d3,d4);

    d3 = read_csr(iport, SM_PCIE_CSR_REGS_IBAR2__ADDR);
    d4 = read_csr(iport, SM_PCIE_CSR_REGS_IR2MSK__ADDR);
    printf("IBAR2/MSK=%x/%x, ", d1,d2,d3,d4);
    d1 = read_csr(iport, SM_PCIE_CSR_REGS_IBAR3H__ADDR);
    d2 = read_csr(iport, SM_PCIE_CSR_REGS_IBAR3L__ADDR);
    d3 = read_csr(iport, SM_PCIE_CSR_REGS_IR3MSKH__ADDR);
    d4 = read_csr(iport, SM_PCIE_CSR_REGS_IR3MSKL__ADDR);
    printf("IBAR3=%x-%8x, IR3MSK=%x-%8x\nBAR0~4:\n", d1,d2, d3,d4);   

    d1 = pcie_ob_cfg_read(iport, SM_PCIE_CFG0_PCIE_CFG0_BAR0__ADDR);
    d2 = pcie_ob_cfg_read(iport, SM_PCIE_CFG0_PCIE_CFG0_BAR0__ADDR + 4);
    d3 = pcie_ob_cfg_read(iport, SM_PCIE_CFG0_PCIE_CFG0_BAR0__ADDR + 8);
    d4 = pcie_ob_cfg_read(iport, SM_PCIE_CFG0_PCIE_CFG0_BAR0__ADDR + 12);
    bar_num = pcie_ob_cfg_read(iport, SM_PCIE_CFG0_PCIE_CFG0_BAR0__ADDR + 16);
  } else {
#if 1
    d1=read_csr(iport, NWL_PCIE_APB_REGS_EXPRESSO_CFG_STATUS_CFG_STATUS_159_128__ADDR);
    d2=read_csr(iport, NWL_PCIE_APB_REGS_EXPRESSO_CFG_STATUS_CFG_STATUS_191_160__ADDR);
    d3=read_csr(iport, NWL_PCIE_APB_REGS_EXPRESSO_CFG_STATUS_CFG_STATUS_223_192__ADDR);
    d4=read_csr(iport, NWL_PCIE_APB_REGS_EXPRESSO_CFG_STATUS_CFG_STATUS_255_224__ADDR);
    bar_num=read_csr(iport, NWL_PCIE_APB_REGS_EXPRESSO_CFG_STATUS_CFG_STATUS_287_256__ADDR);
    printf("EP BAR0~4=%x,%x,%x,%x,%x\n", d1,d2,d3,d4,bar_num);
#else
    if (cfgbar64) {  
      printf("CFG0_BAR0~5: ");
      for (d1=0;d1<5;d1++) {
        d2 = SM_PCIE_CFG0_PCIE_CFG0_BAR0__ADDR + bar_num<<2;
        write(cfgbar64 + d2, 0xFFFFFFFF);
        d3 = read_pcie(cfgbar64 + d2);
        printf("%08x ", d3);
      }
    }
#endif
  }  
  printf("\nCFG_CONSTANTS 159-128 LSW(INT_EN)=0x%x\n", d2 & 0xFFFF);
  printf("CFG_CONSTANTS BaseAddrMask0~5(rebuild from CFG_CONSTANTS_159_128~CONSTANTS_CFG_CONSTANTS_351_320):\n");
  for (d1=0;d1<=5;d1++) {
    d3 = read_csr(iport, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_191_160__ADDR + (d1<<2));
    d4 = (d2>>16)&0xFFFF | (d3<<16);
    printf("%08x ", d4);
    d2 = d3;
  }
  printf("\n"); 
}

uint32_t get_rc_width(uint32_t iport, uint32_t *status)
{
  uint32_t rc;

  *status = read_csr(iport, NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_31_0__ADDR);
  rc = read_csr(iport, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_191_160__ADDR);
  rc = FIELD_EXPRESSO_CFG_CONTROL_CFG_CONTROL_191_160_CFG_CONTROL_PCIE_CAP_DEVICE_PORT_TYPE_RD(rc);
//0=ep,1=legacy ep,4=rc,5=up,6=dp,7=pcie to pci bridge,8=pci to pcie bridge,9=rc intergrated ep,a=rc event collector
  return rc;
}

//PCIECORE_CTLANDSTATUS
void base_dump_port(uint32_t iport)
{
  uint32_t d1,rc;

  rc = get_rc_width(iport, &d1);
  printf("\niport%1d,type=%2d,phy link %2s,data link %2s,gen%1d,width%1d,lane lock=%08b-%2x\n", iport,rc,
      (d1&1?"up":"dn"),(d1&2?"up":"dn"),(d1>>24)&3,(d1>>26),(d1>>8)&0xFF,(d1>>8)&0xFF);
  base_dump_bar(iport, rc);
}
void base_dump(uint32_t slot)
{
  uint32_t pcie_core_id, data;
  uint64_t SM_ADDR_MAP_PCIE_OB_CFG_BASE;

  if (slot==0) {
    pcie_core_id = 0;
//    base_dump_port(1);
  } else if (slot==1) {
    pcie_core_id = 2;
  } else {
    pcie_core_id = 3;
//    base_dump_port(4);
  }

  SM_ADDR_MAP_PCIE_OB_CFG_BASE = ret_ob_cfg_base(pcie_core_id);

  data = SM_ADDR_MAP_PCIE_OB_CFG_BASE >> 32;
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_CFGBARH__ADDR, data);
  //print("CFGBARH is 0x%0x \n\r", data);

  data = (uint32_t) SM_ADDR_MAP_PCIE_OB_CFG_BASE;
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_CFGBARL__ADDR, data);  
  //print("CFGBARL is 0x%0x \n\r", data);

  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_CFGCTL__ADDR, 1);

  base_dump_port(pcie_core_id);
}

void dma_dump_ch(uint32_t iport, uint32_t ch_no)
{
  uint32_t d1,d2,d3,d4,bar_num=0;
  uint64_t cfgbar64;

  do {
    cfgbar64 = read_csr(iport, SM_PCIE_CSR_REGS_CFGBARH__ADDR) & 0x3FF;   //high 10bit
    cfgbar64 = (cfgbar64<<32) | read_csr(iport, SM_PCIE_CSR_REGS_CFGBARL__ADDR);
    if (!cfgbar64) 
       sm_pcie_setup_ob_cfg(iport, EP);  
       printf("CFGBAL/H is 0, force EP be programmed.\n");
  } while (!cfgbar64);
  printf("dma_dump_ch iport=%d ch_no=%d, CFG1BARH/L=%lx\n", iport, ch_no, cfgbar64);

#if 1
  printf("dma_dump_ch read offset [%x] get 64bit data \n", NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_SRC_Q_PTR_LO__ADDR | (ch_no * 0x40));
  d1 = pcie_ob_cfg_read(iport, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_SRC_Q_PTR_LO__ADDR | (ch_no * 0x40));
  d2 = pcie_ob_cfg_read(iport, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_SRC_Q_PTR_HI__ADDR | (ch_no * 0x40));
  d3 = pcie_ob_cfg_read(iport, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_SRC_Q_SIZE__ADDR | (ch_no * 0x40));
  d4 = pcie_ob_cfg_read(iport, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_SRC_Q_LIMIT__ADDR | (ch_no * 0x40));
  printf("DMA%1d SRC adr %x-%8x, size %x,limit %x\n", ch_no, d1,d2,d3,d4);

  d1 = pcie_ob_cfg_read(iport, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DST_Q_PTR_LO__ADDR | (ch_no * 0x40));
  d2 = pcie_ob_cfg_read(iport, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DST_Q_PTR_HI__ADDR | (ch_no * 0x40));
  d3 = pcie_ob_cfg_read(iport, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DST_Q_SIZE__ADDR | (ch_no * 0x40));
  d4 = pcie_ob_cfg_read(iport, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DST_Q_LIMIT__ADDR | (ch_no * 0x40));
  printf("DMA%1d DST adr %x-%8x, size %x,limit %x\n", ch_no, d1,d2,d3,d4);

  d1 = pcie_ob_cfg_read(iport, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_STA_Q_PTR_LO__ADDR | (ch_no * 0x40));
  d2 = pcie_ob_cfg_read(iport, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_STA_Q_PTR_HI__ADDR | (ch_no * 0x40));
  d3 = pcie_ob_cfg_read(iport, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_STA_Q_SIZE__ADDR | (ch_no * 0x40));
  d4 = pcie_ob_cfg_read(iport, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_STA_Q_LIMIT__ADDR | (ch_no * 0x40));
  printf("DMA%1d STA adr %x-%8x, size %x,limit %x\n", ch_no, d1,d2,d3,d4);

  d1 = pcie_ob_cfg_read(iport, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_SRC_Q_NEXT__ADDR | (ch_no * 0x40));
  d2 = pcie_ob_cfg_read(iport, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DST_Q_NEXT__ADDR | (ch_no * 0x40));
  d3 = pcie_ob_cfg_read(iport, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_STA_Q_NEXT__ADDR | (ch_no * 0x40));
  d4 = pcie_ob_cfg_read(iport, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (ch_no * 0x40));
  printf("DMA%1d SRC_NEXT %x, DST_NEXT %x, STA_NEXT %x, CTRL_CFGs %x\n", ch_no, d1,d2,d3,d4);

  d1 = read_csr(iport, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_191_160__ADDR);
  d1 = FIELD_EXPRESSO_CFG_CONTROL_CFG_CONTROL_191_160_CFG_CONTROL_ROOT_PORT_READ_COMPLETION_BOUNDARY_RD(d1);
  d2 = read_pcie(cfgbar64 + NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR);
  printf("DMA%1d RCB %1d, CTRL_STATUS %x\n\n", ch_no, d1, d2);
#else
  d1 = read_pcie(cfgbar64 + NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_SRC_Q_PTR_HI__ADDR);
  d2 = read_pcie(cfgbar64 + NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_SRC_Q_PTR_LO__ADDR);
  d3 = read_pcie(cfgbar64 + NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_SRC_Q_SIZE__ADDR);
  d4 = read_pcie(cfgbar64 + NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_SRC_Q_LIMIT__ADDR);
  printf("DMA%1d SRC adr %x-%8x, size %x,limit %x\n", ch_no, d1,d2,d3,d4);

  d1 = read_pcie(cfgbar64 + NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DST_Q_PTR_HI__ADDR);
  d2 = read_pcie(cfgbar64 + NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DST_Q_PTR_LO__ADDR);
  d3 = read_pcie(cfgbar64 + NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DST_Q_SIZE__ADDR);
  d4 = read_pcie(cfgbar64 + NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DST_Q_LIMIT__ADDR);
  printf("DMA%1d DST adr %x-%8x, size %x,limit %x\n", ch_no, d1,d2,d3,d4);
//
  d1 = read_pcie(cfgbar64 + NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_STA_Q_PTR_LO__ADDR);
  d2 = read_pcie(cfgbar64 + NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_STA_Q_PTR_LO__ADDR);
  d3 = read_pcie(cfgbar64 + NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_STA_Q_SIZE__ADDR);
  d4 = read_pcie(cfgbar64 + NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_STA_Q_LIMIT__ADDR);
  printf("DMA%1d STA adr %x-%8x, size %x,limit %x\n", ch_no, d1,d2,d3,d4);
 
  d1 = read_pcie(cfgbar64 + NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_SRC_Q_NEXT__ADDR);
  d2 = read_pcie(cfgbar64 + NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DST_Q_NEXT__ADDR);
  d3 = read_pcie(cfgbar64 + NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_STA_Q_NEXT__ADDR);
  d4 = read_pcie(cfgbar64 + NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR);
  printf("DMA%1d SRC_NEXT %x, DST_NEXT %x, STA_NEXT %x, CTRL_CFGs %x\n", ch_no, d1,d2,d3,d4);

  d1 = read_csr(iport, NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_191_160__ADDR);
  d1 = FIELD_EXPRESSO_CFG_CONTROL_CFG_CONTROL_191_160_CFG_CONTROL_ROOT_PORT_READ_COMPLETION_BOUNDARY_RD(d1);
  d2 = read_pcie(cfgbar64 + NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR);
  printf("DMA%1d RCB %1d, CTRL_STATUS %x\n\n", ch_no, d1, d2);
#endif
}

//support slot0~2, so IP1/4 not supported for now
void dma_dump(uint32_t slot)
{
  uint32_t i=0,j;

  if (slot==1) i=2;
  else if (slot==2) i=3;
  for (j=0;j<3;j++)
    dma_dump_ch(i, j);
}

void clk_dump(uint32_t slot)
{
  uint32_t data, iport=0;

  if (slot==1) iport=2;
  else if (slot==2) iport=3;
//  data = read_phy(iport, KC_SERDES2_CMU_REGS_CMU_REG0__ADDR);   //SERDES CMU read
  data = pcie_phy_csr_read(iport, KC_SERDES_CMU_REGS_CMU_REG0__ADDR);
//  printf("CLK: slot%1d, iport%1d, clk=%3s,", slot,iport,(FIELD_CMU_REG0_PLL_REF_SEL_RD(data)? "ext":"int"));
  printf("CLK: slot%1d, iport%1d, CMU_reg0=%x,", slot,iport,data);
}


#if defined(CONFIG_VHP) | defined(CONFIG_BB1) | defined(CONFIG_BB2) //Storm test
int pcidump(int argc, char *argv[])
{
  int i=argc+1, j=0;
#else
int main(int argc, char *argv[])
{
  int i=argc, j=1;
#endif
  int dumpmd=0, error=0;
  uint32_t cfgl,cfgh,slot;

  if (i<2) 
    error=1;  
  else {
    if ((slot = atoi(argv[j]))>2)
      error|=2;
    if (i==3) {
      if (strncmp(argv[j+1],"dma",3)==0)
        dumpmd |= 1;
      else if (strncmp(argv[j+1],"clk",3)==0)
        dumpmd |= 2;
      else
        error|=4;
    } else if (i>3) {
      if (strncmp(argv[j+2],"dma",3)==0)
        dumpmd |= 1;
      else if (strncmp(argv[j+2],"clk",3)==0)
        dumpmd |= 2;
      else
        error|=8;
    }
  }
  if (error) {
    printf("pcie_dump: argument error %d. Syntax: slot#(0~2) [dma|clk]\n", error);
    return error;
  }

  base_dump(slot);
  if (dumpmd & 1)
    dma_dump(slot);
  if (dumpmd & 2)
    clk_dump(slot);
  return 0;
}

int print_setting (int argc, char *argv[]){
int pcie_core_id, link_width, i, sds2_offset, ch, data;
int ctle, pq, dfe, r_preset, ctle_fr, l_preset;

  if (argc < 2) {
    printf("Usage: pcie_core_id, ch #\n");
    return -1;
  }
 
  pcie_core_id = atoi(argv[0]);
  ch         = atoi(argv[1]);

  if (ch >= 4) {
      sds2_offset = 0x30000;
      ch = ch - 4;
  } else {
      sds2_offset = 0;
  }

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG1__ADDR + (0x200 * ch) + sds2_offset);
  ctle = FIELD_CH0_RXTX_REG1_CTLE_EQ_RD(data);
  
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG125__ADDR + (0x200 * ch) + sds2_offset);
  pq = FIELD_CH0_RXTX_REG125_PQ_REG_RD(data);
  
  dfe = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG28__ADDR + (0x200 * ch) + sds2_offset);

  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0__ADDR));
  l_preset = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0_CFG_8G_CONSTANTS_MGMT_DS_PORT_TX_PRESET_RD(data);
  r_preset = FIELD_EXPRESSO_CFG_8G_CONSTANTS_CFG_8G_CONSTANTS_31_0_CFG_8G_CONSTANTS_MGMT_US_PORT_TX_PRESET_RD(data);
  
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG0__ADDR + (0x200 * ch) + sds2_offset);
  ctle_fr = FIELD_CH0_RXTX_REG0_CTLE_EQ_FR_RD(data);
  printf("CTLE 0x%x, PQ 0x%x, DFE 0x%x, LOCAL PRESET 0x%x, REMOTE PRESET 0x%x CTLE_FR 0x%x \n", ctle, pq, dfe, l_preset, r_preset, ctle_fr);
}

int sds_dump (int argc, char *argv[]){
int pcie_core_id, link_width, i, sds2_offset, sds, ch, data;

  if (argc < 3) {
    printf("Usage: pcie_core_id, serdes #, ch #\n");
    return -1;
  }
 
  pcie_core_id = atoi(argv[0]);
  sds        = atoi(argv[1]);
  ch         = atoi(argv[2]);

  if (sds == 1) {
      sds2_offset = 0x30000;
  } else {
      sds2_offset = 0;
  }

  printf("CORE # 0x%x, Serdes # 0x%x, CMU REGISTERS \r\n", pcie_core_id, sds);
  for (i = 0; i < 39; i++){ 
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG0__ADDR + (i * 0x2)+ sds2_offset);
  }
  
  printf("CORE # 0x%x, Serdes # 0x%x, channel # 0x%x, RXTX REGISTERS \r\n", pcie_core_id, sds, ch);
  for (i = 0; i < 162; i++){ 
  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG0__ADDR + (0x200 * ch) + (i * 0x2) + sds2_offset);
  }
}

int dfe_dump (int argc, char *argv[]){
int pcie_core_id, link_width, i, sds2_offset, sds, ch, data;
int dfe_msb, dfe_lsb;

  if (argc < 3) {
    printf("Usage: pcie_core_id, serdes #, ch #\n");
    return -1;
  }
 
  pcie_core_id = atoi(argv[0]);
  sds        = atoi(argv[1]);
  ch         = atoi(argv[2]);

  if (sds == 1) {
      sds2_offset = 0x30000;
  } else {
      sds2_offset = 0;
  }

  data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset);
  data = FIELD_CH0_RXTX_REG61_DFE_TAB_ACCB_SET(data, 1);
  pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (0x200 * ch) + sds2_offset, data);
  
  for (i=0; i< 7; i++){
     //program tap select 
    data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG26__ADDR + (0x200 * ch) + sds2_offset);
    data = FIELD_CH0_RXTX_REG26_DFE_TAP_SELECT_SET(data, i);
    pcie_phy_csr_write(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG26__ADDR + (0x200 * ch) + sds2_offset, data);
    
    dfe_lsb = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG106__ADDR + (0x200 * ch) + sds2_offset);
    dfe_msb = pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG105__ADDR + (0x200 * ch) + sds2_offset);
    printf("TAP %d, value 0x%x \n\r", i, (dfe_msb<<16)|dfe_lsb);
  }
  
}

int ddr_search (int argc, char *argv[]){
uint32_t size, patt, data, datan, offset=0;
uint64_t addr=PCIE_0_PIM;
 
  size = strtol(argv[0], NULL, 16);
  patt = strtol(argv[1], NULL, 16);
  if (argc < 2) {
    printf("Usage: size, pattern\n");
    return -1;
  } else 
    printf("ddr_search from 0x%x size 0x%x pattern 0x%x\n", addr, size, patt);

//  addr+=size;
  do {
    data = read_pcie(addr+offset);
    datan = read_pcie(addr+offset+4);
    if ((data==patt)&&(data==datan)) 
      printf("found data at 0x%x\n", addr+offset);
    offset+=8;
  } while ((data != patt)&&(offset<=0xFFFFFFF8ULL));
  if (data!=patt) 
      printf("search stopped at 0x%lx without found\n", addr+offset);
}

int sds_reg_field_dump(int argc, char *argv[]) {
 unsigned int data, pcie_core_id;

if (argc < 1) {
printf("Usage: pcie_core_id, \n");
return -1;
}
 
 pcie_core_id = atoi(argv[0]);

if(pcie_core_id == 0 || pcie_core_id == 3){
    serdes_dump(pcie_core_id, 0);
    serdes_dump(pcie_core_id, 1);
} else {
    serdes_dump(pcie_core_id, 0);
}
}

void serdes_dump (int pcie_core_id, int sds2) {
int sds2_offset, num_ch, channel, data;

if(sds2) {
    sds2_offset = 0x30000;
} else {
    sds2_offset = 0x0;
}

if (pcie_core_id == 2) {
    num_ch = 1;
} else {
    num_ch = 4;
}

printf("\n");
printf("serdes dump for pcie core# 0x%d, serdes# 0x%d\n", pcie_core_id, sds2);

data = pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG0__ADDR + sds2_offset);
printf ("FIELD_CMU_REG0_RESETB_RD , 0x%x \n", FIELD_CMU_REG0_RESETB_RD(data));	
printf ("FIELD_CMU_REG0_PDOWN_RD , 0x%x \n", FIELD_CMU_REG0_PDOWN_RD(data));
printf ("FIELD_CMU_REG0_PLL_REF_SEL_RD , 0x%x \n", FIELD_CMU_REG0_PLL_REF_SEL_RD(data));	
printf ("FIELD_CMU_REG0_REF_CLKBUF_PDOWN1_RD , 0x%x \n", FIELD_CMU_REG0_REF_CLKBUF_PDOWN1_RD(data));	
printf ("FIELD_CMU_REG0_REF_CLKBUF_PDOWN0_RD , 0x%x \n", FIELD_CMU_REG0_REF_CLKBUF_PDOWN0_RD(data));	
printf ("FIELD_CMU_REG0_REF_CLKBUF_STREN_RD , 0x%x \n", FIELD_CMU_REG0_REF_CLKBUF_STREN_RD(data));	
printf ("FIELD_CMU_REG0_CAL_COUNT_RESOL_RD , 0x%x \n", FIELD_CMU_REG0_CAL_COUNT_RESOL_RD(data));	
printf ("FIELD_CMU_REG0_PDOWN_VCO_RD , 0x%x \n", FIELD_CMU_REG0_PDOWN_VCO_RD(data)); 	
printf ("FIELD_CMU_REG0_PDOWN_DIV_RD , 0x%x \n", FIELD_CMU_REG0_PDOWN_DIV_RD(data));	
printf ("FIELD_CMU_REG0_REFCLK_RPT_PDOWN_RD , 0x%x \n", FIELD_CMU_REG0_REFCLK_RPT_PDOWN_RD(data));	
printf ("FIELD_CMU_REG0_PCIEGEN3_RD , 0x%x \n", FIELD_CMU_REG0_PCIEGEN3_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG1__ADDR + sds2_offset);
printf ("FIELD_CMU_REG1_PLL_PDOWN_RD , 0x%x \n", FIELD_CMU_REG1_PLL_PDOWN_RD(data));	
printf ("FIELD_CMU_REG1_PLL_BYPASS_RD , 0x%x \n", FIELD_CMU_REG1_PLL_BYPASS_RD(data));	
printf ("FIELD_CMU_REG1_PLL_CP_RD , 0x%x \n", FIELD_CMU_REG1_PLL_CP_RD(data));	
printf ("FIELD_CMU_REG1_PLL_CP_SEL_RD , 0x%x \n", FIELD_CMU_REG1_PLL_CP_SEL_RD(data));	
printf ("FIELD_CMU_REG1_PLL_TESTCLK_SEL_RD , 0x%x \n", FIELD_CMU_REG1_PLL_TESTCLK_SEL_RD(data));	
printf ("FIELD_CMU_REG1_PLL_MANUALCAL_RD , 0x%x \n", FIELD_CMU_REG1_PLL_MANUALCAL_RD(data));	
printf ("FIELD_CMU_REG1_PLL_ENA_VCO_RD , 0x%x \n", FIELD_CMU_REG1_PLL_ENA_VCO_RD(data));	
printf ("FIELD_CMU_REG1_PLL_ENA_VCO_AAC_RD , 0x%x \n", FIELD_CMU_REG1_PLL_ENA_VCO_AAC_RD(data));	
printf ("FIELD_CMU_REG1_REFCLK_CMOS_SEL_RD , 0x%x \n", FIELD_CMU_REG1_REFCLK_CMOS_SEL_RD(data));

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG2__ADDR + sds2_offset);
printf ("FIELD_CMU_REG2_PLL_REFDIV_RD , 0x%x \n", FIELD_CMU_REG2_PLL_REFDIV_RD(data));	
printf ("FIELD_CMU_REG2_PLL_FBDIV_RD , 0x%x \n", FIELD_CMU_REG2_PLL_FBDIV_RD(data));	
printf ("FIELD_CMU_REG2_PLL_LFRES_RD , 0x%x \n", FIELD_CMU_REG2_PLL_LFRES_RD(data));	
printf ("FIELD_CMU_REG2_PLL_BND_SEL_RD , 0x%x \n", FIELD_CMU_REG2_PLL_BND_SEL_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG3__ADDR + sds2_offset);
printf ("FIELD_CMU_REG3_VCO_MANMOMSEL_RD , 0x%x \n", FIELD_CMU_REG3_VCO_MANMOMSEL_RD(data));	
printf ("FIELD_CMU_REG3_VCO_MOMSEL_INIT_RD , 0x%x \n", FIELD_CMU_REG3_VCO_MOMSEL_INIT_RD(data));	
printf ("FIELD_CMU_REG3_VCOVARSEL_RD , 0x%x \n", FIELD_CMU_REG3_VCOVARSEL_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG4__ADDR + sds2_offset);
printf ("FIELD_CMU_REG4_VCO_MANMOMSEL_PCIE_RD , 0x%x \n", FIELD_CMU_REG4_VCO_MANMOMSEL_PCIE_RD(data));	
printf ("FIELD_CMU_REG4_VCO_MOMSEL_INIT_PCIE_RD , 0x%x \n", FIELD_CMU_REG4_VCO_MOMSEL_INIT_PCIE_RD(data));	
printf ("FIELD_CMU_REG4_VCOVARSEL_PCIE_RD , 0x%x \n", FIELD_CMU_REG4_VCOVARSEL_PCIE_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG5__ADDR + sds2_offset);
printf ("FIELD_CMU_REG5_PLL_LFSMCAP_RD , 0x%x \n", FIELD_CMU_REG5_PLL_LFSMCAP_RD(data));	
printf ("FIELD_CMU_REG5_PLL_LFCAP_RD , 0x%x \n", FIELD_CMU_REG5_PLL_LFCAP_RD(data));	
printf ("FIELD_CMU_REG5_TERM_CAL_OS_RD , 0x%x \n", FIELD_CMU_REG5_TERM_CAL_OS_RD(data));	
printf ("FIELD_CMU_REG5_RESERVED_7_RD , 0x%x \n", FIELD_CMU_REG5_RESERVED_7_RD(data));	
printf ("FIELD_CMU_REG5_PLL_LOCK_RESOLUTION_RD , 0x%x \n", FIELD_CMU_REG5_PLL_LOCK_RESOLUTION_RD(data));	
printf ("FIELD_CMU_REG5_PLL_RESETB_RD , 0x%x \n", FIELD_CMU_REG5_PLL_RESETB_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG6__ADDR + sds2_offset);
printf ("FIELD_CMU_REG6_VCO_CALIB_ENA_RD , 0x%x \n", FIELD_CMU_REG6_VCO_CALIB_ENA_RD(data));	
printf ("FIELD_CMU_REG6_PLL_VCOCALSEL_RD , 0x%x \n", FIELD_CMU_REG6_PLL_VCOCALSEL_RD(data));	
printf ("FIELD_CMU_REG6_PLL_VREGTRIM_RD , 0x%x \n", FIELD_CMU_REG6_PLL_VREGTRIM_RD(data));	
printf ("FIELD_CMU_REG6_PLL_VCOBIAS_TRIM_RD , 0x%x \n", FIELD_CMU_REG6_PLL_VCOBIAS_TRIM_RD(data));	
printf ("FIELD_CMU_REG6_USR_CLK_BUF_ENA_RD , 0x%x \n", FIELD_CMU_REG6_USR_CLK_BUF_ENA_RD(data));	
printf ("FIELD_CMU_REG6_MAN_PVT_CAL_RD , 0x%x \n", FIELD_CMU_REG6_MAN_PVT_CAL_RD(data));	
printf ("FIELD_CMU_REG6_SER_CLKBUF_PDOWN_RD , 0x%x \n", FIELD_CMU_REG6_SER_CLKBUF_PDOWN_RD(data));	
printf ("FIELD_CMU_REG6_USR_CLKBY2_BYPASS_RD , 0x%x \n", FIELD_CMU_REG6_USR_CLKBY2_BYPASS_RD(data));

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG7__ADDR + sds2_offset);
printf ("FIELD_CMU_REG7_PLL_LOCK_RD , 0x%x \n", FIELD_CMU_REG7_PLL_LOCK_RD(data));	
printf ("FIELD_CMU_REG7_PLL_CALIB_DONE_RD , 0x%x \n", FIELD_CMU_REG7_PLL_CALIB_DONE_RD(data));	
printf ("FIELD_CMU_REG7_PLL_DET_RD , 0x%x \n", FIELD_CMU_REG7_PLL_DET_RD(data));	
printf ("FIELD_CMU_REG7_VCO_CAL_FAIL_RD , 0x%x \n", FIELD_CMU_REG7_VCO_CAL_FAIL_RD(data));	
printf ("FIELD_CMU_REG7_PVT_CAL_UP_OS_RD , 0x%x \n", FIELD_CMU_REG7_PVT_CAL_UP_OS_RD(data));	
printf ("FIELD_CMU_REG7_PVT_CAL_DN_OS_RD , 0x%x \n", FIELD_CMU_REG7_PVT_CAL_DN_OS_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG8__ADDR + sds2_offset);
printf ("FIELD_CMU_REG8_TX_DATA_RATE_CH3_RD , 0x%x \n", FIELD_CMU_REG8_TX_DATA_RATE_CH3_RD(data));	
printf ("FIELD_CMU_REG8_TX_DATA_RATE_CH2_RD , 0x%x \n", FIELD_CMU_REG8_TX_DATA_RATE_CH2_RD(data));	
printf ("FIELD_CMU_REG8_TX_DATA_RATE_CH1_RD , 0x%x \n", FIELD_CMU_REG8_TX_DATA_RATE_CH1_RD(data));	
printf ("FIELD_CMU_REG8_TX_DATA_RATE_CH0_RD , 0x%x \n", FIELD_CMU_REG8_TX_DATA_RATE_CH0_RD(data));	
printf ("FIELD_CMU_REG8_PLL_UCDIV_RD , 0x%x \n", FIELD_CMU_REG8_PLL_UCDIV_RD(data));	
printf ("FIELD_CMU_REG8_RESERVED_4_RD , 0x%x \n", FIELD_CMU_REG8_RESERVED_4_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG9__ADDR + sds2_offset);
printf ("FIELD_CMU_REG9_TX_WORD_MODE_CH3_RD , 0x%x \n", FIELD_CMU_REG9_TX_WORD_MODE_CH3_RD(data));	
printf ("FIELD_CMU_REG9_TX_WORD_MODE_CH2_RD , 0x%x \n", FIELD_CMU_REG9_TX_WORD_MODE_CH2_RD(data));	
printf ("FIELD_CMU_REG9_TX_WORD_MODE_CH1_RD , 0x%x \n", FIELD_CMU_REG9_TX_WORD_MODE_CH1_RD(data));	
printf ("FIELD_CMU_REG9_TX_WORD_MODE_CH0_RD , 0x%x \n", FIELD_CMU_REG9_TX_WORD_MODE_CH0_RD(data));	
printf ("FIELD_CMU_REG9_PLL_POST_DIVBY2_RD , 0x%x \n", FIELD_CMU_REG9_PLL_POST_DIVBY2_RD(data));	
printf ("FIELD_CMU_REG9_VBG_BYPASSB_RD , 0x%x \n", FIELD_CMU_REG9_VBG_BYPASSB_RD(data));	
printf ("FIELD_CMU_REG9_IGEN_BYPASS_RD , 0x%x \n", FIELD_CMU_REG9_IGEN_BYPASS_RD(data));	
printf ("FIELD_CMU_REG9_I_HSCLKBUF_PD_RD , 0x%x \n", FIELD_CMU_REG9_I_HSCLKBUF_PD_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG10__ADDR + sds2_offset);
printf ("FIELD_CMU_REG10_TX_PAR_CLKBUF_PDOWN_RD , 0x%x \n", FIELD_CMU_REG10_TX_PAR_CLKBUF_PDOWN_RD(data));	
printf ("FIELD_CMU_REG10_ATO_ENA_RD , 0x%x \n", FIELD_CMU_REG10_ATO_ENA_RD(data));	
printf ("FIELD_CMU_REG10_ATO_SEL_RD , 0x%x \n", FIELD_CMU_REG10_ATO_SEL_RD(data));	
printf ("FIELD_CMU_REG10_PLL_AMUX_SEL_RD , 0x%x \n", FIELD_CMU_REG10_PLL_AMUX_SEL_RD(data));	
printf ("FIELD_CMU_REG10_PLL_AMUX_EN_RD , 0x%x \n", FIELD_CMU_REG10_PLL_AMUX_EN_RD(data));	
printf ("FIELD_CMU_REG10_VREG_REFSEL_RD , 0x%x \n", FIELD_CMU_REG10_VREG_REFSEL_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG11__ADDR + sds2_offset);
printf ("FIELD_CMU_REG11_PLL_SPARE_OUT_RD , 0x%x \n", FIELD_CMU_REG11_PLL_SPARE_OUT_RD(data));	
printf ("FIELD_CMU_REG11_RESERVED_7_RD , 0x%x \n", FIELD_CMU_REG11_RESERVED_7_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG12__ADDR + sds2_offset);
printf ("FIELD_CMU_REG12_PLL_SPARE_IN_RD , 0x%x \n", FIELD_CMU_REG12_PLL_SPARE_IN_RD(data));	
printf ("FIELD_CMU_REG12_STATE_DELAY9_RD , 0x%x \n", FIELD_CMU_REG12_STATE_DELAY9_RD(data));	
printf ("FIELD_CMU_REG12_RESERVED_3_RD , 0x%x \n", FIELD_CMU_REG12_RESERVED_3_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG13__ADDR + sds2_offset);
printf ("FIELD_CMU_REG13_STATE_DELAY1_RD , 0x%x \n", FIELD_CMU_REG13_STATE_DELAY1_RD(data));	
printf ("FIELD_CMU_REG13_STATE_DELAY2_RD , 0x%x \n", FIELD_CMU_REG13_STATE_DELAY2_RD(data));	
printf ("FIELD_CMU_REG13_STATE_DELAY3_RD , 0x%x \n", FIELD_CMU_REG13_STATE_DELAY3_RD(data));	
printf ("FIELD_CMU_REG13_STATE_DELAY4_RD , 0x%x \n", FIELD_CMU_REG13_STATE_DELAY4_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG14__ADDR + sds2_offset);
printf ("FIELD_CMU_REG14_STATE_DELAY5_RD , 0x%x \n", FIELD_CMU_REG14_STATE_DELAY5_RD(data));	
printf ("FIELD_CMU_REG14_STATE_DELAY6_RD , 0x%x \n", FIELD_CMU_REG14_STATE_DELAY6_RD(data));	
printf ("FIELD_CMU_REG14_STATE_DELAY7_RD , 0x%x \n", FIELD_CMU_REG14_STATE_DELAY7_RD(data));	
printf ("FIELD_CMU_REG14_STATE_DELAY8_RD , 0x%x \n", FIELD_CMU_REG14_STATE_DELAY8_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG15__ADDR + sds2_offset);
printf ("FIELD_CMU_REG15_TX_READY_RD , 0x%x \n", FIELD_CMU_REG15_TX_READY_RD(data));	
printf ("FIELD_CMU_REG15_RX_READY_RD , 0x%x \n", FIELD_CMU_REG15_RX_READY_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG16__ADDR + sds2_offset);
printf ("FIELD_CMU_REG16_TX_RATE_CHANGE_ENA_CH0_RD , 0x%x \n", FIELD_CMU_REG16_TX_RATE_CHANGE_ENA_CH0_RD(data));	
printf ("FIELD_CMU_REG16_RX_RATE_CHANGE_ENA_CH0_RD , 0x%x \n", FIELD_CMU_REG16_RX_RATE_CHANGE_ENA_CH0_RD(data));	
printf ("FIELD_CMU_REG16_TX_RATE_CHANGE_ENA_CH1_RD , 0x%x \n", FIELD_CMU_REG16_TX_RATE_CHANGE_ENA_CH1_RD(data));	
printf ("FIELD_CMU_REG16_RX_RATE_CHANGE_ENA_CH1_RD , 0x%x \n", FIELD_CMU_REG16_RX_RATE_CHANGE_ENA_CH1_RD(data));	
printf ("FIELD_CMU_REG16_TX_RATE_CHANGE_ENA_CH2_RD , 0x%x \n", FIELD_CMU_REG16_TX_RATE_CHANGE_ENA_CH2_RD(data));	
printf ("FIELD_CMU_REG16_RX_RATE_CHANGE_ENA_CH2_RD , 0x%x \n", FIELD_CMU_REG16_RX_RATE_CHANGE_ENA_CH2_RD(data));	
printf ("FIELD_CMU_REG16_TX_RATE_CHANGE_ENA_CH3_RD , 0x%x \n", FIELD_CMU_REG16_TX_RATE_CHANGE_ENA_CH3_RD(data));	
printf ("FIELD_CMU_REG16_RX_RATE_CHANGE_ENA_CH3_RD , 0x%x \n", FIELD_CMU_REG16_RX_RATE_CHANGE_ENA_CH3_RD(data));	
printf ("FIELD_CMU_REG16_STATE_MC_BYPASS_RD , 0x%x \n", FIELD_CMU_REG16_STATE_MC_BYPASS_RD(data));	
printf ("FIELD_CMU_REG16_CALIBRATION_DONE_OVERRIDE_RD , 0x%x \n", FIELD_CMU_REG16_CALIBRATION_DONE_OVERRIDE_RD(data));	
printf ("FIELD_CMU_REG16_BYPASS_PLL_LOCK_RD , 0x%x \n", FIELD_CMU_REG16_BYPASS_PLL_LOCK_RD(data));	
printf ("FIELD_CMU_REG16_VCOCAL_WAIT_BTW_CODE_RD , 0x%x \n", FIELD_CMU_REG16_VCOCAL_WAIT_BTW_CODE_RD(data));	
printf ("FIELD_CMU_REG16_PVT_UP_MAN_ENA_RD , 0x%x \n", FIELD_CMU_REG16_PVT_UP_MAN_ENA_RD(data));	
printf ("FIELD_CMU_REG16_PVT_DN_MAN_ENA_RD , 0x%x \n", FIELD_CMU_REG16_PVT_DN_MAN_ENA_RD(data));

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG17__ADDR + sds2_offset);
printf ("FIELD_CMU_REG17_PVT_TERM_MAN_ENA_RD , 0x%x \n", FIELD_CMU_REG17_PVT_TERM_MAN_ENA_RD(data));	
printf ("FIELD_CMU_REG17_PVT_CODE_R2A_RD , 0x%x \n", FIELD_CMU_REG17_PVT_CODE_R2A_RD(data));	
printf ("FIELD_CMU_REG17_RESERVED_7_RD , 0x%x \n", FIELD_CMU_REG17_RESERVED_7_RD(data));	
printf ("FIELD_CMU_REG17_TERM_INIT_RD , 0x%x \n", FIELD_CMU_REG17_TERM_INIT_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG18__ADDR + sds2_offset);
printf ("FIELD_CMU_REG18_RST_SEQ_CURRENT_STATE_RD , 0x%x \n", FIELD_CMU_REG18_RST_SEQ_CURRENT_STATE_RD(data));	
printf ("FIELD_CMU_REG18_VCO_CAL_CURRENT_STATE_RD , 0x%x \n", FIELD_CMU_REG18_VCO_CAL_CURRENT_STATE_RD(data));	
printf ("FIELD_CMU_REG18_CMU_TERM_CURRENT_STATE_RD , 0x%x \n", FIELD_CMU_REG18_CMU_TERM_CURRENT_STATE_RD(data));	
printf ("FIELD_CMU_REG18_CHANNEL_SEL_RD , 0x%x \n", FIELD_CMU_REG18_CHANNEL_SEL_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG19__ADDR + sds2_offset);
printf ("FIELD_CMU_REG19_PLL_VCOMOMSEL_RD , 0x%x \n", FIELD_CMU_REG19_PLL_VCOMOMSEL_RD(data));	
printf ("FIELD_CMU_REG19_PLL_VCOMOMSEL_PCIE3_RD , 0x%x \n", FIELD_CMU_REG19_PLL_VCOMOMSEL_PCIE3_RD(data));	
printf ("FIELD_CMU_REG19_RESERVED_3_RD , 0x%x \n", FIELD_CMU_REG19_RESERVED_3_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG20__ADDR + sds2_offset);
printf ("FIELD_CMU_REG20_DRVUP_ERROR_FAIL_RD , 0x%x \n", FIELD_CMU_REG20_DRVUP_ERROR_FAIL_RD(data));	
printf ("FIELD_CMU_REG20_DRVDN_ERROR_FAIL_RD , 0x%x \n", FIELD_CMU_REG20_DRVDN_ERROR_FAIL_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG21__ADDR + sds2_offset);
printf ("FIELD_CMU_REG21_TERM_ERROR_FAIL_RD , 0x%x \n", FIELD_CMU_REG21_TERM_ERROR_FAIL_RD(data));	
printf ("FIELD_CMU_REG21_TERM_CH0_RD , 0x%x \n", FIELD_CMU_REG21_TERM_CH0_RD(data));	
printf ("FIELD_CMU_REG21_PVT_CAL_DONE_RD , 0x%x \n", FIELD_CMU_REG21_PVT_CAL_DONE_RD(data));	
printf ("FIELD_CMU_REG21_PVT_CALIB_DONE_OVR_RD , 0x%x \n", FIELD_CMU_REG21_PVT_CALIB_DONE_OVR_RD(data));	
printf ("FIELD_CMU_REG21_PLL_LOCK_DONE_RD , 0x%x \n", FIELD_CMU_REG21_PLL_LOCK_DONE_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG22__ADDR + sds2_offset);
printf ("FIELD_CMU_REG22_PVT_P_CH0_RD , 0x%x \n", FIELD_CMU_REG22_PVT_P_CH0_RD(data));	
printf ("FIELD_CMU_REG22_RESERVED_8_RD , 0x%x \n", FIELD_CMU_REG22_RESERVED_8_RD(data));	
printf ("FIELD_CMU_REG22_PVT_N_CH0_RD , 0x%x \n", FIELD_CMU_REG22_PVT_N_CH0_RD(data));	
printf ("FIELD_CMU_REG22_RESERVED_0_RD , 0x%x \n", FIELD_CMU_REG22_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG23__ADDR + sds2_offset);
printf ("FIELD_CMU_REG23_PVT_P_CH1_RD , 0x%x \n", FIELD_CMU_REG23_PVT_P_CH1_RD(data));	
printf ("FIELD_CMU_REG23_RESERVED_8_RD , 0x%x \n", FIELD_CMU_REG23_RESERVED_8_RD(data));	
printf ("FIELD_CMU_REG23_PVT_N_CH1_RD , 0x%x \n", FIELD_CMU_REG23_PVT_N_CH1_RD(data));	
printf ("FIELD_CMU_REG23_RESERVED_0_RD , 0x%x \n", FIELD_CMU_REG23_RESERVED_0_RD(data));

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG24__ADDR + sds2_offset);
printf ("FIELD_CMU_REG24_PVT_P_CH2_RD , 0x%x \n", FIELD_CMU_REG24_PVT_P_CH2_RD(data));	
printf ("FIELD_CMU_REG24_RESERVED_8_RD , 0x%x \n", FIELD_CMU_REG24_RESERVED_8_RD(data));	
printf ("FIELD_CMU_REG24_PVT_N_CH2_RD , 0x%x \n", FIELD_CMU_REG24_PVT_N_CH2_RD(data));	
printf ("FIELD_CMU_REG24_RESERVED_0_RD , 0x%x \n", FIELD_CMU_REG24_RESERVED_0_RD(data));

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG25__ADDR + sds2_offset);
printf ("FIELD_CMU_REG25_PVT_P_CH3_RD , 0x%x \n", FIELD_CMU_REG25_PVT_P_CH3_RD(data));	
printf ("FIELD_CMU_REG25_RESERVED_8_RD , 0x%x \n", FIELD_CMU_REG25_RESERVED_8_RD(data));	
printf ("FIELD_CMU_REG25_PVT_N_CH3_RD , 0x%x \n", FIELD_CMU_REG25_PVT_N_CH3_RD(data));	
printf ("FIELD_CMU_REG25_RESERVED_0_RD , 0x%x \n", FIELD_CMU_REG25_RESERVED_0_RD(data));

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG26__ADDR + sds2_offset);
printf ("FIELD_CMU_REG26_PVT_P_INIT_RD , 0x%x \n", FIELD_CMU_REG26_PVT_P_INIT_RD(data));	
printf ("FIELD_CMU_REG26_RESERVED_8_RD , 0x%x \n", FIELD_CMU_REG26_RESERVED_8_RD(data));	
printf ("FIELD_CMU_REG26_PVT_N_INIT_RD , 0x%x \n", FIELD_CMU_REG26_PVT_N_INIT_RD(data));	
printf ("FIELD_CMU_REG26_FORCE_PLL_LOCK_RD , 0x%x \n", FIELD_CMU_REG26_FORCE_PLL_LOCK_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG27__ADDR + sds2_offset);
printf ("FIELD_CMU_REG27_REF_VOLT_SEL_CH0_RD , 0x%x \n", FIELD_CMU_REG27_REF_VOLT_SEL_CH0_RD(data));	
printf ("FIELD_CMU_REG27_REF_VOLT_SEL_CH1_RD , 0x%x \n", FIELD_CMU_REG27_REF_VOLT_SEL_CH1_RD(data));	
printf ("FIELD_CMU_REG27_REF_VOLT_SEL_CH2_RD , 0x%x \n", FIELD_CMU_REG27_REF_VOLT_SEL_CH2_RD(data));	
printf ("FIELD_CMU_REG27_REF_VOLT_SEL_CH3_RD , 0x%x \n", FIELD_CMU_REG27_REF_VOLT_SEL_CH3_RD(data));	
printf ("FIELD_CMU_REG27_CLKBUF_STREN_RD , 0x%x \n", FIELD_CMU_REG27_CLKBUF_STREN_RD(data));	
printf ("FIELD_CMU_REG27_RESERVED_0_RD , 0x%x \n", FIELD_CMU_REG27_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG28__ADDR + sds2_offset);
printf ("FIELD_CMU_REG28_STATE_MC_OVERRIDE_CTRL_RD , 0x%x \n", FIELD_CMU_REG28_STATE_MC_OVERRIDE_CTRL_RD(data));

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG29__ADDR + sds2_offset);
printf ("FIELD_CMU_REG29_TERM_CH1_RD , 0x%x \n", FIELD_CMU_REG29_TERM_CH1_RD(data));	
printf ("FIELD_CMU_REG29_TERM_CH2_RD , 0x%x \n", FIELD_CMU_REG29_TERM_CH2_RD(data));	
printf ("FIELD_CMU_REG29_TERM_CH3_RD , 0x%x \n", FIELD_CMU_REG29_TERM_CH3_RD(data));	
printf ("FIELD_CMU_REG29_RESERVED_0_RD , 0x%x \n", FIELD_CMU_REG29_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG30__ADDR + sds2_offset);
printf ("FIELD_CMU_REG30_PLL_REFDIV_GEN3_RD , 0x%x \n", FIELD_CMU_REG30_PLL_REFDIV_GEN3_RD(data));	
printf ("FIELD_CMU_REG30_PLL_FBDIV_GEN3_RD , 0x%x \n", FIELD_CMU_REG30_PLL_FBDIV_GEN3_RD(data));	
printf ("FIELD_CMU_REG30_PLL_POST_DIVBY2_GEN3_RD , 0x%x \n", FIELD_CMU_REG30_PLL_POST_DIVBY2_GEN3_RD(data));	
printf ("FIELD_CMU_REG30_PCIE_MODE_RD , 0x%x \n", FIELD_CMU_REG30_PCIE_MODE_RD(data));	
printf ("FIELD_CMU_REG30_LOCK_COUNT_RD , 0x%x \n", FIELD_CMU_REG30_LOCK_COUNT_RD(data));	
printf ("FIELD_CMU_REG30_RESERVED_0_RD , 0x%x \n", FIELD_CMU_REG30_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG31__ADDR + sds2_offset);
printf ("FIELD_CMU_REG31_TXPCLKBUF_STREN_L0_RD , 0x%x \n", FIELD_CMU_REG31_TXPCLKBUF_STREN_L0_RD(data));	
printf ("FIELD_CMU_REG31_TXPCLKBUF_STREN_L1_RD , 0x%x \n", FIELD_CMU_REG31_TXPCLKBUF_STREN_L1_RD(data));	
printf ("FIELD_CMU_REG31_TXPCLKBUF_STREN_L2_RD , 0x%x \n", FIELD_CMU_REG31_TXPCLKBUF_STREN_L2_RD(data));	
printf ("FIELD_CMU_REG31_TXPCLKBUF_STREN_L3_RD , 0x%x \n", FIELD_CMU_REG31_TXPCLKBUF_STREN_L3_RD(data));	
printf ("FIELD_CMU_REG31_LOS_OVERRIDE_CH0_RD , 0x%x \n", FIELD_CMU_REG31_LOS_OVERRIDE_CH0_RD(data));	
printf ("FIELD_CMU_REG31_LOS_OVERRIDE_CH1_RD , 0x%x \n", FIELD_CMU_REG31_LOS_OVERRIDE_CH1_RD(data));	
printf ("FIELD_CMU_REG31_LOS_OVERRIDE_CH2_RD , 0x%x \n", FIELD_CMU_REG31_LOS_OVERRIDE_CH2_RD(data));	
printf ("FIELD_CMU_REG31_LOS_OVERRIDE_CH3_RD , 0x%x \n", FIELD_CMU_REG31_LOS_OVERRIDE_CH3_RD(data));

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG32__ADDR + sds2_offset);
printf ("FIELD_CMU_REG32_PIN_OVERRIDE_RD , 0x%x \n", FIELD_CMU_REG32_PIN_OVERRIDE_RD(data));	
printf ("FIELD_CMU_REG32_FORCE_VCOCAL_START_RD , 0x%x \n", FIELD_CMU_REG32_FORCE_VCOCAL_START_RD(data));	
printf ("FIELD_CMU_REG32_CLK_DIS_RD , 0x%x \n", FIELD_CMU_REG32_CLK_DIS_RD(data));	
printf ("FIELD_CMU_REG32_IDDTN_RD , 0x%x \n", FIELD_CMU_REG32_IDDTN_RD(data));	
printf ("FIELD_CMU_REG32_FORCE_PVT_CAL_START_RD , 0x%x \n", FIELD_CMU_REG32_FORCE_PVT_CAL_START_RD(data));	
printf ("FIELD_CMU_REG32_REFCLKDIV_RESETB_RD , 0x%x \n", FIELD_CMU_REG32_REFCLKDIV_RESETB_RD(data));	
printf ("FIELD_CMU_REG32_POST_DIVBY2_RESETB_RD , 0x%x \n", FIELD_CMU_REG32_POST_DIVBY2_RESETB_RD(data));	
printf ("FIELD_CMU_REG32_IREF_ADJ_RD , 0x%x \n", FIELD_CMU_REG32_IREF_ADJ_RD(data));	
printf ("FIELD_CMU_REG32_FORCE_RATE_CHANGE_RX_CH0_RD , 0x%x \n", FIELD_CMU_REG32_FORCE_RATE_CHANGE_RX_CH0_RD(data));	
printf ("FIELD_CMU_REG32_FORCE_RATE_CHANGE_TX_CH0_RD , 0x%x \n", FIELD_CMU_REG32_FORCE_RATE_CHANGE_TX_CH0_RD(data));	
printf ("FIELD_CMU_REG32_FORCE_RATE_CHANGE_RX_CH1_RD , 0x%x \n", FIELD_CMU_REG32_FORCE_RATE_CHANGE_RX_CH1_RD(data));	
printf ("FIELD_CMU_REG32_FORCE_RATE_CHANGE_TX_CH1_RD , 0x%x \n", FIELD_CMU_REG32_FORCE_RATE_CHANGE_TX_CH1_RD(data));	
printf ("FIELD_CMU_REG32_PVT_CAL_WAIT_SEL_RD , 0x%x \n", FIELD_CMU_REG32_PVT_CAL_WAIT_SEL_RD(data));	
printf ("FIELD_CMU_REG32_RESERVED_0_RD , 0x%x \n", FIELD_CMU_REG32_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG33__ADDR + sds2_offset);
printf ("FIELD_CMU_REG33_CUSTOMER_MODE_INV_RD , 0x%x \n", FIELD_CMU_REG33_CUSTOMER_MODE_INV_RD(data));

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG34__ADDR + sds2_offset);
printf ("FIELD_CMU_REG34_VCO_CAL_VTH_HI_MIN_RD , 0x%x \n", FIELD_CMU_REG34_VCO_CAL_VTH_HI_MIN_RD(data));	
printf ("FIELD_CMU_REG34_VCO_CAL_VTH_HI_MAX_RD , 0x%x \n", FIELD_CMU_REG34_VCO_CAL_VTH_HI_MAX_RD(data));	
printf ("FIELD_CMU_REG34_VCO_CAL_VTH_LO_MIN_RD , 0x%x \n", FIELD_CMU_REG34_VCO_CAL_VTH_LO_MIN_RD(data));	
printf ("FIELD_CMU_REG34_VCO_CAL_VTH_LO_MAX_RD , 0x%x \n", FIELD_CMU_REG34_VCO_CAL_VTH_LO_MAX_RD(data));

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG35__ADDR + sds2_offset);
printf ("FIELD_CMU_REG35_PLL_SSC_MOD_RD , 0x%x \n", FIELD_CMU_REG35_PLL_SSC_MOD_RD(data));	
printf ("FIELD_CMU_REG35_CORE_REVISION_RD , 0x%x \n", FIELD_CMU_REG35_CORE_REVISION_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG36__ADDR + sds2_offset);
printf ("FIELD_CMU_REG36_PLL_SSC_VSTEP_RD , 0x%x \n", FIELD_CMU_REG36_PLL_SSC_VSTEP_RD(data));	
printf ("FIELD_CMU_REG36_PLL_SSC_DSMSEL_RD , 0x%x \n", FIELD_CMU_REG36_PLL_SSC_DSMSEL_RD(data));	
printf ("FIELD_CMU_REG36_PLL_SSC_EN_RD , 0x%x \n", FIELD_CMU_REG36_PLL_SSC_EN_RD(data));	
printf ("FIELD_CMU_REG36_FORCE_RATE_CHANGE_RX_CH2_RD , 0x%x \n", FIELD_CMU_REG36_FORCE_RATE_CHANGE_RX_CH2_RD(data));	
printf ("FIELD_CMU_REG36_FORCE_RATE_CHANGE_TX_CH2_RD , 0x%x \n", FIELD_CMU_REG36_FORCE_RATE_CHANGE_TX_CH2_RD(data));	
printf ("FIELD_CMU_REG36_FORCE_RATE_CHANGE_RX_CH3_RD , 0x%x \n", FIELD_CMU_REG36_FORCE_RATE_CHANGE_RX_CH3_RD(data));	
printf ("FIELD_CMU_REG36_FORCE_RATE_CHANGE_TX_CH3_RD , 0x%x \n", FIELD_CMU_REG36_FORCE_RATE_CHANGE_TX_CH3_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG37__ADDR + sds2_offset);
printf ("FIELD_CMU_REG37_CTLE_CAL_DONE_OVR_RD , 0x%x \n", FIELD_CMU_REG37_CTLE_CAL_DONE_OVR_RD(data));	
printf ("FIELD_CMU_REG37_LATCH_CAL_DONE_OVR_RD , 0x%x \n", FIELD_CMU_REG37_LATCH_CAL_DONE_OVR_RD(data));	
printf ("FIELD_CMU_REG37_SUM_OFF_CAL_DONE_OVR_RD , 0x%x \n", FIELD_CMU_REG37_SUM_OFF_CAL_DONE_OVR_RD(data));	
printf ("FIELD_CMU_REG37_FT_SEARCH_DONE_OVR_RD , 0x%x \n", FIELD_CMU_REG37_FT_SEARCH_DONE_OVR_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG38__ADDR + sds2_offset);
printf ("FIELD_CMU_REG38_RX_SEQ_STATE_CH0_RD , 0x%x \n", FIELD_CMU_REG38_RX_SEQ_STATE_CH0_RD(data));	
printf ("FIELD_CMU_REG38_RX_SEQ_STATE_CH1_RD , 0x%x \n", FIELD_CMU_REG38_RX_SEQ_STATE_CH1_RD(data));	
printf ("FIELD_CMU_REG38_RX_SEQ_STATE_CH2_RD , 0x%x \n", FIELD_CMU_REG38_RX_SEQ_STATE_CH2_RD(data));	
printf ("FIELD_CMU_REG38_RX_SEQ_STATE_CH3_RD , 0x%x \n", FIELD_CMU_REG38_RX_SEQ_STATE_CH3_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_CMU_REGS_CMU_REG39__ADDR + sds2_offset);
printf ("FIELD_CMU_REG39_TX_SEQ_STATE_CH0_RD , 0x%x \n", FIELD_CMU_REG39_TX_SEQ_STATE_CH0_RD(data));	
printf ("FIELD_CMU_REG39_TX_SEQ_STATE_CH1_RD , 0x%x \n", FIELD_CMU_REG39_TX_SEQ_STATE_CH1_RD(data));	
printf ("FIELD_CMU_REG39_TX_SEQ_STATE_CH2_RD , 0x%x \n", FIELD_CMU_REG39_TX_SEQ_STATE_CH2_RD(data));	
printf ("FIELD_CMU_REG39_TX_SEQ_STATE_CH3_RD , 0x%x \n", FIELD_CMU_REG39_TX_SEQ_STATE_CH3_RD(data));

for (channel = 0; channel < num_ch; channel++){

printf ("CHANNEL 0x%x RXTX_REGS \n", channel);

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG0__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG0_CTLE_EQ_HR_RD , 0x%x \n", FIELD_CH0_RXTX_REG0_CTLE_EQ_HR_RD(data));	
printf ("FIELD_CH0_RXTX_REG0_CTLE_EQ_QR_RD , 0x%x \n", FIELD_CH0_RXTX_REG0_CTLE_EQ_QR_RD(data));	
printf ("FIELD_CH0_RXTX_REG0_CTLE_EQ_FR_RD , 0x%x \n", FIELD_CH0_RXTX_REG0_CTLE_EQ_FR_RD(data));	
printf ("FIELD_CH0_RXTX_REG0_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG0_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG1__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG1_RXACVCM_RD , 0x%x \n", FIELD_CH0_RXTX_REG1_RXACVCM_RD(data));	
printf ("FIELD_CH0_RXTX_REG1_CTLE_EQ_RD , 0x%x \n", FIELD_CH0_RXTX_REG1_CTLE_EQ_RD(data));	
printf ("FIELD_CH0_RXTX_REG1_RXVREG1_RD , 0x%x \n", FIELD_CH0_RXTX_REG1_RXVREG1_RD(data));	
printf ("FIELD_CH0_RXTX_REG1_RXVREG1P2_RD , 0x%x \n", FIELD_CH0_RXTX_REG1_RXVREG1P2_RD(data));	
printf ("FIELD_CH0_RXTX_REG1_RXIREF_ADJ_RD , 0x%x \n", FIELD_CH0_RXTX_REG1_RXIREF_ADJ_RD(data));	
printf ("FIELD_CH0_RXTX_REG1_PWR_BYPASS_RD , 0x%x \n", FIELD_CH0_RXTX_REG1_PWR_BYPASS_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG2__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG2_RESETB_RD , 0x%x \n", FIELD_CH0_RXTX_REG2_RESETB_RD(data));	
printf ("FIELD_CH0_RXTX_REG2_RESETB_TERM_RD , 0x%x \n", FIELD_CH0_RXTX_REG2_RESETB_TERM_RD(data));	
printf ("FIELD_CH0_RXTX_REG2_RESETB_TXA_RD , 0x%x \n", FIELD_CH0_RXTX_REG2_RESETB_TXA_RD(data));	
printf ("FIELD_CH0_RXTX_REG2_RESETB_TXD_RD , 0x%x \n", FIELD_CH0_RXTX_REG2_RESETB_TXD_RD(data));	
printf ("FIELD_CH0_RXTX_REG2_BIST_ENA_TX_RD , 0x%x \n", FIELD_CH0_RXTX_REG2_BIST_ENA_TX_RD(data));	
printf ("FIELD_CH0_RXTX_REG2_TX_INV_RD , 0x%x \n", FIELD_CH0_RXTX_REG2_TX_INV_RD(data));	
printf ("FIELD_CH0_RXTX_REG2_TX_PVT_BYPASS_RD , 0x%x \n", FIELD_CH0_RXTX_REG2_TX_PVT_BYPASS_RD(data));	
printf ("FIELD_CH0_RXTX_REG2_VTT_ENA_RD , 0x%x \n", FIELD_CH0_RXTX_REG2_VTT_ENA_RD(data));	
printf ("FIELD_CH0_RXTX_REG2_VTT_SEL_RD , 0x%x \n", FIELD_CH0_RXTX_REG2_VTT_SEL_RD(data));	
printf ("FIELD_CH0_RXTX_REG2_TX_FIFO_ENA_RD , 0x%x \n", FIELD_CH0_RXTX_REG2_TX_FIFO_ENA_RD(data));	
printf ("FIELD_CH0_RXTX_REG2_TX_PDOWN_RD , 0x%x \n", FIELD_CH0_RXTX_REG2_TX_PDOWN_RD(data));	
printf ("FIELD_CH0_RXTX_REG2_TX_RCVDET_SEL_RD , 0x%x \n", FIELD_CH0_RXTX_REG2_TX_RCVDET_SEL_RD(data));	
printf ("FIELD_CH0_RXTX_REG2_IDDTN_RD , 0x%x \n", FIELD_CH0_RXTX_REG2_IDDTN_RD(data));	
printf ("FIELD_CH0_RXTX_REG2_RXPDBIAS_RD , 0x%x \n", FIELD_CH0_RXTX_REG2_RXPDBIAS_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG3__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG3_RESERVED_15_RD , 0x%x \n", FIELD_CH0_RXTX_REG3_RESERVED_15_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG4__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG4_TX_DATA_RATE_RD , 0x%x \n", FIELD_CH0_RXTX_REG4_TX_DATA_RATE_RD(data));	
printf ("FIELD_CH0_RXTX_REG4_TX_WORD_MODE_RD , 0x%x \n", FIELD_CH0_RXTX_REG4_TX_WORD_MODE_RD(data));	
printf ("FIELD_CH0_RXTX_REG4_TX_PRBS_SEL_RD , 0x%x \n", FIELD_CH0_RXTX_REG4_TX_PRBS_SEL_RD(data));	
printf ("FIELD_CH0_RXTX_REG4_RX_TX_SER_LOOPBACK_RD , 0x%x \n", FIELD_CH0_RXTX_REG4_RX_TX_SER_LOOPBACK_RD(data));	
printf ("FIELD_CH0_RXTX_REG4_TX_LOOPBACK_BUF_EN_RD , 0x%x \n", FIELD_CH0_RXTX_REG4_TX_LOOPBACK_BUF_EN_RD(data));	
printf ("FIELD_CH0_RXTX_REG4_COUNTER_TIME_SEL_CP_RD , 0x%x \n", FIELD_CH0_RXTX_REG4_COUNTER_TIME_SEL_CP_RD(data));	
printf ("FIELD_CH0_RXTX_REG4_COUNTER_TIME_SEL_CN_RD , 0x%x \n", FIELD_CH0_RXTX_REG4_COUNTER_TIME_SEL_CN_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG5__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG5_TX_CN1_RD , 0x%x \n", FIELD_CH0_RXTX_REG5_TX_CN1_RD(data));	
printf ("FIELD_CH0_RXTX_REG5_TX_CP1_RD , 0x%x \n", FIELD_CH0_RXTX_REG5_TX_CP1_RD(data));	
printf ("FIELD_CH0_RXTX_REG5_TX_CN2_RD , 0x%x \n", FIELD_CH0_RXTX_REG5_TX_CN2_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG6__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG6_TX_CN1_INV_RD , 0x%x \n", FIELD_CH0_RXTX_REG6_TX_CN1_INV_RD(data));	
printf ("FIELD_CH0_RXTX_REG6_TX_CN2_INV_RD , 0x%x \n", FIELD_CH0_RXTX_REG6_TX_CN2_INV_RD(data));	
printf ("FIELD_CH0_RXTX_REG6_TX_CP1_INV_RD , 0x%x \n", FIELD_CH0_RXTX_REG6_TX_CP1_INV_RD(data));	
printf ("FIELD_CH0_RXTX_REG6_IDLE_RAW_RD , 0x%x \n", FIELD_CH0_RXTX_REG6_IDLE_RAW_RD(data));	
printf ("FIELD_CH0_RXTX_REG6_TX_DATA_REV_RD , 0x%x \n", FIELD_CH0_RXTX_REG6_TX_DATA_REV_RD(data));	
printf ("FIELD_CH0_RXTX_REG6_TXAMP_CNTL_RD , 0x%x \n", FIELD_CH0_RXTX_REG6_TXAMP_CNTL_RD(data));	
printf ("FIELD_CH0_RXTX_REG6_TXAMP_ENA_RD , 0x%x \n", FIELD_CH0_RXTX_REG6_TXAMP_ENA_RD(data));	
printf ("FIELD_CH0_RXTX_REG6_RXDET_ENA_RD , 0x%x \n", FIELD_CH0_RXTX_REG6_RXDET_ENA_RD(data));	
printf ("FIELD_CH0_RXTX_REG6_RXDET_CLR_RD , 0x%x \n", FIELD_CH0_RXTX_REG6_RXDET_CLR_RD(data));	
printf ("FIELD_CH0_RXTX_REG6_TX_IDLE_RD , 0x%x \n", FIELD_CH0_RXTX_REG6_TX_IDLE_RD(data));	
printf ("FIELD_CH0_RXTX_REG6_TXSYNC_RESETB_RD , 0x%x \n", FIELD_CH0_RXTX_REG6_TXSYNC_RESETB_RD(data));	
printf ("FIELD_CH0_RXTX_REG6_RX_BIST_RESYNC_RD , 0x%x \n", FIELD_CH0_RXTX_REG6_RX_BIST_RESYNC_RD(data));	
printf ("FIELD_CH0_RXTX_REG6_RX_BIST_ERRCNT_RD_RD , 0x%x \n", FIELD_CH0_RXTX_REG6_RX_BIST_ERRCNT_RD_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG7__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG7_RXREVLOOP_BACK_ENA_RD , 0x%x \n", FIELD_CH0_RXTX_REG7_RXREVLOOP_BACK_ENA_RD(data));	
printf ("FIELD_CH0_RXTX_REG7_LOOP_BACK_ENA_CTLE_RD , 0x%x \n", FIELD_CH0_RXTX_REG7_LOOP_BACK_ENA_CTLE_RD(data));	
printf ("FIELD_CH0_RXTX_REG7_RX_WORD_MODE_RD , 0x%x \n", FIELD_CH0_RXTX_REG7_RX_WORD_MODE_RD(data));	
printf ("FIELD_CH0_RXTX_REG7_RX_DATA_RATE_RD , 0x%x \n", FIELD_CH0_RXTX_REG7_RX_DATA_RATE_RD(data));	
printf ("FIELD_CH0_RXTX_REG7_RESETB_RXD_RD , 0x%x \n", FIELD_CH0_RXTX_REG7_RESETB_RXD_RD(data));	
printf ("FIELD_CH0_RXTX_REG7_RESETB_RXA_RD , 0x%x \n", FIELD_CH0_RXTX_REG7_RESETB_RXA_RD(data));	
printf ("FIELD_CH0_RXTX_REG7_BIST_ENA_RX_RD , 0x%x \n", FIELD_CH0_RXTX_REG7_BIST_ENA_RX_RD(data));	
printf ("FIELD_CH0_RXTX_REG7_RX_PRBS_SEL_RD , 0x%x \n", FIELD_CH0_RXTX_REG7_RX_PRBS_SEL_RD(data));	
printf ("FIELD_CH0_RXTX_REG7_BIST_WAIT_DELAY_RD , 0x%x \n", FIELD_CH0_RXTX_REG7_BIST_WAIT_DELAY_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG8__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG8_RXTX_REV_PAR_LPBK_RD , 0x%x \n", FIELD_CH0_RXTX_REG8_RXTX_REV_PAR_LPBK_RD(data));	
printf ("FIELD_CH0_RXTX_REG8_CDR_LOOP_ENA_RD , 0x%x \n", FIELD_CH0_RXTX_REG8_CDR_LOOP_ENA_RD(data));	
printf ("FIELD_CH0_RXTX_REG8_CDR_LOOP_ENA_FORCE_RD , 0x%x \n", FIELD_CH0_RXTX_REG8_CDR_LOOP_ENA_FORCE_RD(data));	
printf ("FIELD_CH0_RXTX_REG8_REV_UPDN_PHASE_RD , 0x%x \n", FIELD_CH0_RXTX_REG8_REV_UPDN_PHASE_RD(data));	
printf ("FIELD_CH0_RXTX_REG8_CDR_BYPASS_RXLOS_RD , 0x%x \n", FIELD_CH0_RXTX_REG8_CDR_BYPASS_RXLOS_RD(data));	
printf ("FIELD_CH0_RXTX_REG8_CDR_LOOP_SNAPSHOT_ENA_RD , 0x%x \n", FIELD_CH0_RXTX_REG8_CDR_LOOP_SNAPSHOT_ENA_RD(data));	
printf ("FIELD_CH0_RXTX_REG8_SSC_ENABLE_RD , 0x%x \n", FIELD_CH0_RXTX_REG8_SSC_ENABLE_RD(data));	
printf ("FIELD_CH0_RXTX_REG8_SD_DISABLE_RD , 0x%x \n", FIELD_CH0_RXTX_REG8_SD_DISABLE_RD(data));	
printf ("FIELD_CH0_RXTX_REG8_SD_VREF_RD , 0x%x \n", FIELD_CH0_RXTX_REG8_SD_VREF_RD(data));	
printf ("FIELD_CH0_RXTX_REG8_TX_BIST_INJECT_ERR_RD , 0x%x \n", FIELD_CH0_RXTX_REG8_TX_BIST_INJECT_ERR_RD(data));	
printf ("FIELD_CH0_RXTX_REG8_RESERVED_2_RD , 0x%x \n", FIELD_CH0_RXTX_REG8_RESERVED_2_RD(data));	
printf ("FIELD_CH0_RXTX_REG8_CDR_BW_TIMER_RESET_RD , 0x%x \n", FIELD_CH0_RXTX_REG8_CDR_BW_TIMER_RESET_RD(data));	
printf ("FIELD_CH0_RXTX_REG8_SWAP_LMSDATA_RD , 0x%x \n", FIELD_CH0_RXTX_REG8_SWAP_LMSDATA_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG9__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG9_FT_POS7_REG_RD , 0x%x \n", FIELD_CH0_RXTX_REG9_FT_POS7_REG_RD(data));	
printf ("FIELD_CH0_RXTX_REG9_FT_POS8_REG_RD , 0x%x \n", FIELD_CH0_RXTX_REG9_FT_POS8_REG_RD(data));	
printf ("FIELD_CH0_RXTX_REG9_RESERVED_3_RD , 0x%x \n", FIELD_CH0_RXTX_REG9_RESERVED_3_RD(data));

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG10__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG10_FT_POS9_REG_RD , 0x%x \n", FIELD_CH0_RXTX_REG10_FT_POS9_REG_RD(data));	
printf ("FIELD_CH0_RXTX_REG10_FT_POSA_REG_RD , 0x%x \n", FIELD_CH0_RXTX_REG10_FT_POSA_REG_RD(data));	
printf ("FIELD_CH0_RXTX_REG10_RESERVED_3_RD , 0x%x \n", FIELD_CH0_RXTX_REG10_RESERVED_3_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG11__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG11_PHASE_ADJUST_LIMIT_RD , 0x%x \n", FIELD_CH0_RXTX_REG11_PHASE_ADJUST_LIMIT_RD(data));	
printf ("FIELD_CH0_RXTX_REG11_CAPTURE_FTPOS_RD , 0x%x \n", FIELD_CH0_RXTX_REG11_CAPTURE_FTPOS_RD(data));	
printf ("FIELD_CH0_RXTX_REG11_FT_POS4_RD , 0x%x \n", FIELD_CH0_RXTX_REG11_FT_POS4_RD(data));	
printf ("FIELD_CH0_RXTX_REG11_CDR_ACCUMULATOR_SEL_RD , 0x%x \n", FIELD_CH0_RXTX_REG11_CDR_ACCUMULATOR_SEL_RD(data));	
printf ("FIELD_CH0_RXTX_REG11_RX_IGEN_PDOWN_RD , 0x%x \n", FIELD_CH0_RXTX_REG11_RX_IGEN_PDOWN_RD(data));

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG12__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG12_EYE_SCAN_ENA_RD , 0x%x \n", FIELD_CH0_RXTX_REG12_EYE_SCAN_ENA_RD(data));	
printf ("FIELD_CH0_RXTX_REG12_ERROR_LATCH_SWAP_RD , 0x%x \n", FIELD_CH0_RXTX_REG12_ERROR_LATCH_SWAP_RD(data));	
printf ("FIELD_CH0_RXTX_REG12_LATCH_OFF_ENA_RD , 0x%x \n", FIELD_CH0_RXTX_REG12_LATCH_OFF_ENA_RD(data));	
printf ("FIELD_CH0_RXTX_REG12_RX_PDOWN_RD , 0x%x \n", FIELD_CH0_RXTX_REG12_RX_PDOWN_RD(data));	
printf ("FIELD_CH0_RXTX_REG12_RX_INV_RD , 0x%x \n", FIELD_CH0_RXTX_REG12_RX_INV_RD(data));	
printf ("FIELD_CH0_RXTX_REG12_RX_DATA_REV_RD , 0x%x \n", FIELD_CH0_RXTX_REG12_RX_DATA_REV_RD(data));	
printf ("FIELD_CH0_RXTX_REG12_ENABLE_3POLE_RD , 0x%x \n", FIELD_CH0_RXTX_REG12_ENABLE_3POLE_RD(data));	
printf ("FIELD_CH0_RXTX_REG12_TX_P0_PD_RD , 0x%x \n", FIELD_CH0_RXTX_REG12_TX_P0_PD_RD(data));	
printf ("FIELD_CH0_RXTX_REG12_TX_P1_PD_RD , 0x%x \n", FIELD_CH0_RXTX_REG12_TX_P1_PD_RD(data));	
printf ("FIELD_CH0_RXTX_REG12_TX_P2_PD_RD , 0x%x \n", FIELD_CH0_RXTX_REG12_TX_P2_PD_RD(data));	
printf ("FIELD_CH0_RXTX_REG12_RX_P0_PD_RD , 0x%x \n", FIELD_CH0_RXTX_REG12_RX_P0_PD_RD(data));	
printf ("FIELD_CH0_RXTX_REG12_RX_P1_PD_RD , 0x%x \n", FIELD_CH0_RXTX_REG12_RX_P1_PD_RD(data));	
printf ("FIELD_CH0_RXTX_REG12_RX_P2_PD_RD , 0x%x \n", FIELD_CH0_RXTX_REG12_RX_P2_PD_RD(data));	
printf ("FIELD_CH0_RXTX_REG12_SUMOS_ENABLE_RD , 0x%x \n", FIELD_CH0_RXTX_REG12_SUMOS_ENABLE_RD(data));	
printf ("FIELD_CH0_RXTX_REG12_RX_DET_TERM_ENABLE_RD , 0x%x \n", FIELD_CH0_RXTX_REG12_RX_DET_TERM_ENABLE_RD(data));	
printf ("FIELD_CH0_RXTX_REG12_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG12_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG13__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG13_RX_SPARE_RD , 0x%x \n", FIELD_CH0_RXTX_REG13_RX_SPARE_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG14__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG14_TX_ATO_RD , 0x%x \n", FIELD_CH0_RXTX_REG14_TX_ATO_RD(data));	
printf ("FIELD_CH0_RXTX_REG14_RX_ATO_RD , 0x%x \n", FIELD_CH0_RXTX_REG14_RX_ATO_RD(data));	
printf ("FIELD_CH0_RXTX_REG14_CTLE_LATCAL_MAN_ENA_RD , 0x%x \n", FIELD_CH0_RXTX_REG14_CTLE_LATCAL_MAN_ENA_RD(data));	
printf ("FIELD_CH0_RXTX_REG14_CLTE_LATCAL_MAN_PROG_RD , 0x%x \n", FIELD_CH0_RXTX_REG14_CLTE_LATCAL_MAN_PROG_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG15__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG15_RESERVED_15_RD , 0x%x \n", FIELD_CH0_RXTX_REG15_RESERVED_15_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG16__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG16_RESERVED_15_RD , 0x%x \n", FIELD_CH0_RXTX_REG16_RESERVED_15_RD(data));

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG17__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG17_RESERVED_15_RD , 0x%x \n", FIELD_CH0_RXTX_REG17_RESERVED_15_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG18__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG18_CDR_PI_TAP_RD , 0x%x \n", FIELD_CH0_RXTX_REG18_CDR_PI_TAP_RD(data));	
printf ("FIELD_CH0_RXTX_REG18_RESERVED_8_RD , 0x%x \n", FIELD_CH0_RXTX_REG18_RESERVED_8_RD(data));	
printf ("FIELD_CH0_RXTX_REG18_CDR_PQ_TAP_RD , 0x%x \n", FIELD_CH0_RXTX_REG18_CDR_PQ_TAP_RD(data));	
printf ("FIELD_CH0_RXTX_REG18_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG18_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG19__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG19_ESCAN_TAP_RD , 0x%x \n", FIELD_CH0_RXTX_REG19_ESCAN_TAP_RD(data));	
printf ("FIELD_CH0_RXTX_REG19_RESERVED_8_RD , 0x%x \n", FIELD_CH0_RXTX_REG19_RESERVED_8_RD(data));	
printf ("FIELD_CH0_RXTX_REG19_ESCAN_VMARGIN_RD , 0x%x \n", FIELD_CH0_RXTX_REG19_ESCAN_VMARGIN_RD(data));	
printf ("FIELD_CH0_RXTX_REG19_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG19_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG20__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG20_RESERVED_15_RD , 0x%x \n", FIELD_CH0_RXTX_REG20_RESERVED_15_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG21__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG21_DO_LATCH_CALOUT_RD , 0x%x \n", FIELD_CH0_RXTX_REG21_DO_LATCH_CALOUT_RD(data));	
printf ("FIELD_CH0_RXTX_REG21_XO_LATCH_CALOUT_RD , 0x%x \n", FIELD_CH0_RXTX_REG21_XO_LATCH_CALOUT_RD(data));	
printf ("FIELD_CH0_RXTX_REG21_LATCH_CAL_FAIL_ODD_RD , 0x%x \n", FIELD_CH0_RXTX_REG21_LATCH_CAL_FAIL_ODD_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG22__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG22_EO_LATCH_CALOUT_RD , 0x%x \n", FIELD_CH0_RXTX_REG22_EO_LATCH_CALOUT_RD(data));	
printf ("FIELD_CH0_RXTX_REG22_SO_LATCH_CALOUT_RD , 0x%x \n", FIELD_CH0_RXTX_REG22_SO_LATCH_CALOUT_RD(data));	
printf ("FIELD_CH0_RXTX_REG22_LATCH_CAL_FAIL_EVEN_RD , 0x%x \n", FIELD_CH0_RXTX_REG22_LATCH_CAL_FAIL_EVEN_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG23__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG23_DE_LATCH_CALOUT_RD , 0x%x \n", FIELD_CH0_RXTX_REG23_DE_LATCH_CALOUT_RD(data));	
printf ("FIELD_CH0_RXTX_REG23_XE_LATCH_CALOUT_RD , 0x%x \n", FIELD_CH0_RXTX_REG23_XE_LATCH_CALOUT_RD(data));	
printf ("FIELD_CH0_RXTX_REG23_RESERVED_3_RD , 0x%x \n", FIELD_CH0_RXTX_REG23_RESERVED_3_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG24__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG24_EE_LATCH_CALOUT_RD , 0x%x \n", FIELD_CH0_RXTX_REG24_EE_LATCH_CALOUT_RD(data));	
printf ("FIELD_CH0_RXTX_REG24_SE_LATCH_CALOUT_RD , 0x%x \n", FIELD_CH0_RXTX_REG24_SE_LATCH_CALOUT_RD(data));	
printf ("FIELD_CH0_RXTX_REG24_TX_BC_CP1_UP_RD , 0x%x \n", FIELD_CH0_RXTX_REG24_TX_BC_CP1_UP_RD(data));	
printf ("FIELD_CH0_RXTX_REG24_TX_BC_CN1_UP_RD , 0x%x \n", FIELD_CH0_RXTX_REG24_TX_BC_CN1_UP_RD(data));	
printf ("FIELD_CH0_RXTX_REG24_TX_BC_CP1_DN_RD , 0x%x \n", FIELD_CH0_RXTX_REG24_TX_BC_CP1_DN_RD(data));	
printf ("FIELD_CH0_RXTX_REG24_TX_BC_CN1_DN_RD , 0x%x \n", FIELD_CH0_RXTX_REG24_TX_BC_CN1_DN_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG25__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG25_SWAP_XLATOUT_RD , 0x%x \n", FIELD_CH0_RXTX_REG25_SWAP_XLATOUT_RD(data));	
printf ("FIELD_CH0_RXTX_REG25_RESERVED_14_RD , 0x%x \n", FIELD_CH0_RXTX_REG25_RESERVED_14_RD(data));	
printf ("FIELD_CH0_RXTX_REG25_RESERVED_13_RD , 0x%x \n", FIELD_CH0_RXTX_REG25_RESERVED_13_RD(data));	
printf ("FIELD_CH0_RXTX_REG25_BIT_SLIP_RD , 0x%x \n", FIELD_CH0_RXTX_REG25_BIT_SLIP_RD(data));	
printf ("FIELD_CH0_RXTX_REG25_DCOFST_RD , 0x%x \n", FIELD_CH0_RXTX_REG25_DCOFST_RD(data));	
printf ("FIELD_CH0_RXTX_REG25_RESERVED_4_RD , 0x%x \n", FIELD_CH0_RXTX_REG25_RESERVED_4_RD(data));	
printf ("FIELD_CH0_RXTX_REG25_SD_OUT_RD , 0x%x \n", FIELD_CH0_RXTX_REG25_SD_OUT_RD(data));	
printf ("FIELD_CH0_RXTX_REG25_SD_FL_OUT_RD , 0x%x \n", FIELD_CH0_RXTX_REG25_SD_FL_OUT_RD(data));	
printf ("FIELD_CH0_RXTX_REG25_ERR_LAT_ODD_POL_INV_RD , 0x%x \n", FIELD_CH0_RXTX_REG25_ERR_LAT_ODD_POL_INV_RD(data));	
printf ("FIELD_CH0_RXTX_REG25_ERR_LAT_EVEN_POL_INV_RD , 0x%x \n", FIELD_CH0_RXTX_REG25_ERR_LAT_EVEN_POL_INV_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG26__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG26_SWITCH_ERROR_LATCH_RD , 0x%x \n", FIELD_CH0_RXTX_REG26_SWITCH_ERROR_LATCH_RD(data));	
printf ("FIELD_CH0_RXTX_REG26_PERIOD_ERROR_LATCH_RD , 0x%x \n", FIELD_CH0_RXTX_REG26_PERIOD_ERROR_LATCH_RD(data));	
printf ("FIELD_CH0_RXTX_REG26_DFE_TAP_SELECT_RD , 0x%x \n", FIELD_CH0_RXTX_REG26_DFE_TAP_SELECT_RD(data));	
printf ("FIELD_CH0_RXTX_REG26_RESERVED_6_RD , 0x%x \n", FIELD_CH0_RXTX_REG26_RESERVED_6_RD(data));	
printf ("FIELD_CH0_RXTX_REG26_BLWC_ENA_RD , 0x%x \n", FIELD_CH0_RXTX_REG26_BLWC_ENA_RD(data));	
printf ("FIELD_CH0_RXTX_REG26_RESERVED_2_RD , 0x%x \n", FIELD_CH0_RXTX_REG26_RESERVED_2_RD(data));	
printf ("FIELD_CH0_RXTX_REG26_H0_SIGN_REV_RD , 0x%x \n", FIELD_CH0_RXTX_REG26_H0_SIGN_REV_RD(data));	
printf ("FIELD_CH0_RXTX_REG26_DFE_TAP_WRITE_ENA_RD , 0x%x \n", FIELD_CH0_RXTX_REG26_DFE_TAP_WRITE_ENA_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG27__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG27_RXPD_CONFIG_RD , 0x%x \n", FIELD_CH0_RXTX_REG27_RXPD_CONFIG_RD(data));	
printf ("FIELD_CH0_RXTX_REG27_RXPD_BLOCK_RD , 0x%x \n", FIELD_CH0_RXTX_REG27_RXPD_BLOCK_RD(data));	
printf ("FIELD_CH0_RXTX_REG27_FLOATING_SRC_START_RD , 0x%x \n", FIELD_CH0_RXTX_REG27_FLOATING_SRC_START_RD(data));	
printf ("FIELD_CH0_RXTX_REG27_CTLE_CAL_HS_LEVEL_RD , 0x%x \n", FIELD_CH0_RXTX_REG27_CTLE_CAL_HS_LEVEL_RD(data));	
printf ("FIELD_CH0_RXTX_REG27_ALPHA_BLWC_RD , 0x%x \n", FIELD_CH0_RXTX_REG27_ALPHA_BLWC_RD(data));	
printf ("FIELD_CH0_RXTX_REG27_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG27_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG28__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG28_DFE_TAP_ENA_RD , 0x%x \n", FIELD_CH0_RXTX_REG28_DFE_TAP_ENA_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG29__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG29_RESERVED_15_RD , 0x%x \n", FIELD_CH0_RXTX_REG29_RESERVED_15_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG30__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG30_RESERVED_15_RD , 0x%x \n", FIELD_CH0_RXTX_REG30_RESERVED_15_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG31__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG31_DFE_PRESET_VALUE_H0_RD , 0x%x \n", FIELD_CH0_RXTX_REG31_DFE_PRESET_VALUE_H0_RD(data));	
printf ("FIELD_CH0_RXTX_REG31_RESERVED_8_RD , 0x%x \n", FIELD_CH0_RXTX_REG31_RESERVED_8_RD(data));	
printf ("FIELD_CH0_RXTX_REG31_DFE_PRESET_VALUE_H1_RD , 0x%x \n", FIELD_CH0_RXTX_REG31_DFE_PRESET_VALUE_H1_RD(data));	
printf ("FIELD_CH0_RXTX_REG31_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG31_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG32__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG32_DFE_PRESET_VALUE_H2_RD , 0x%x \n", FIELD_CH0_RXTX_REG32_DFE_PRESET_VALUE_H2_RD(data));	
printf ("FIELD_CH0_RXTX_REG32_RESERVED_8_RD , 0x%x \n", FIELD_CH0_RXTX_REG32_RESERVED_8_RD(data));	
printf ("FIELD_CH0_RXTX_REG32_DFE_PRESET_VALUE_H3_RD , 0x%x \n", FIELD_CH0_RXTX_REG32_DFE_PRESET_VALUE_H3_RD(data));	
printf ("FIELD_CH0_RXTX_REG32_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG32_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG33__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG33_DFE_PRESET_VALUE_H4_RD , 0x%x \n", FIELD_CH0_RXTX_REG33_DFE_PRESET_VALUE_H4_RD(data));	
printf ("FIELD_CH0_RXTX_REG33_RESERVED_8_RD , 0x%x \n", FIELD_CH0_RXTX_REG33_RESERVED_8_RD(data));	
printf ("FIELD_CH0_RXTX_REG33_DFE_PRESET_VALUE_H5_RD , 0x%x \n", FIELD_CH0_RXTX_REG33_DFE_PRESET_VALUE_H5_RD(data));	
printf ("FIELD_CH0_RXTX_REG33_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG33_RESERVED_0_RD(data));

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG34__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG34_DFE_PRESET_VALUE_H6_RD , 0x%x \n", FIELD_CH0_RXTX_REG34_DFE_PRESET_VALUE_H6_RD(data));	
printf ("FIELD_CH0_RXTX_REG34_RESERVED_8_RD , 0x%x \n", FIELD_CH0_RXTX_REG34_RESERVED_8_RD(data));	
printf ("FIELD_CH0_RXTX_REG34_DFE_PRESET_VALUE_H7_RD , 0x%x \n", FIELD_CH0_RXTX_REG34_DFE_PRESET_VALUE_H7_RD(data));	
printf ("FIELD_CH0_RXTX_REG34_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG34_RESERVED_0_RD(data));

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG35__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG35_DFE_PRESET_VALUE_H8_RD , 0x%x \n", FIELD_CH0_RXTX_REG35_DFE_PRESET_VALUE_H8_RD(data));	
printf ("FIELD_CH0_RXTX_REG35_RESERVED_8_RD , 0x%x \n", FIELD_CH0_RXTX_REG35_RESERVED_8_RD(data));	
printf ("FIELD_CH0_RXTX_REG35_DFE_PRESET_VALUE_H9_RD , 0x%x \n", FIELD_CH0_RXTX_REG35_DFE_PRESET_VALUE_H9_RD(data));	
printf ("FIELD_CH0_RXTX_REG35_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG35_RESERVED_0_RD(data));

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG36__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG36_DFE_PRESET_VALUE_H10_RD , 0x%x \n", FIELD_CH0_RXTX_REG36_DFE_PRESET_VALUE_H10_RD(data));	
printf ("FIELD_CH0_RXTX_REG36_RX_CLK_SLEW_CNTL_RD , 0x%x \n", FIELD_CH0_RXTX_REG36_RX_CLK_SLEW_CNTL_RD(data));	
printf ("FIELD_CH0_RXTX_REG36_EKBC_REV_RD , 0x%x \n", FIELD_CH0_RXTX_REG36_EKBC_REV_RD(data));	
printf ("FIELD_CH0_RXTX_REG36_SD_FL_PDOWN_RD , 0x%x \n", FIELD_CH0_RXTX_REG36_SD_FL_PDOWN_RD(data));	
printf ("FIELD_CH0_RXTX_REG36_RESERVED_5_RD , 0x%x \n", FIELD_CH0_RXTX_REG36_RESERVED_5_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG37__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG37_TX_SPARE_OUT_RD , 0x%x \n", FIELD_CH0_RXTX_REG37_TX_SPARE_OUT_RD(data));	
printf ("FIELD_CH0_RXTX_REG37_RX_SPARE_OUT_RD , 0x%x \n", FIELD_CH0_RXTX_REG37_RX_SPARE_OUT_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG38__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG38_CUSTOMER_PINMODE_INV_RD , 0x%x \n", FIELD_CH0_RXTX_REG38_CUSTOMER_PINMODE_INV_RD(data));	
printf ("FIELD_CH0_RXTX_REG38_TX_USER_PATT_SEL_RD , 0x%x \n", FIELD_CH0_RXTX_REG38_TX_USER_PATT_SEL_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG39__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG39_TX_USER_PATT16_RD , 0x%x \n", FIELD_CH0_RXTX_REG39_TX_USER_PATT16_RD(data));	
printf ("FIELD_CH0_RXTX_REG39_RESERVED_7_RD , 0x%x \n", FIELD_CH0_RXTX_REG39_RESERVED_7_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG40__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG40_TX_USER_PATT15_RD , 0x%x \n", FIELD_CH0_RXTX_REG40_TX_USER_PATT15_RD(data));

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG41__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG41_TX_USER_PATT14_RD , 0x%x \n", FIELD_CH0_RXTX_REG41_TX_USER_PATT14_RD(data));

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG42__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG42_TX_USER_PATT13_RD , 0x%x \n", FIELD_CH0_RXTX_REG42_TX_USER_PATT13_RD(data));

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG43__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG43_TX_USER_PATT12_RD , 0x%x \n", FIELD_CH0_RXTX_REG43_TX_USER_PATT12_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG44__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG44_TX_USER_PATT11_RD , 0x%x \n", FIELD_CH0_RXTX_REG44_TX_USER_PATT11_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG45__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG45_TX_USER_PATT10_RD , 0x%x \n", FIELD_CH0_RXTX_REG45_TX_USER_PATT10_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG46__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG46_TX_USER_PATT9_RD , 0x%x \n", FIELD_CH0_RXTX_REG46_TX_USER_PATT9_RD(data));

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG47__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG47_TX_USER_PATT8_RD , 0x%x \n", FIELD_CH0_RXTX_REG47_TX_USER_PATT8_RD(data));

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG48__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG48_TX_USER_PATT7_RD , 0x%x \n", FIELD_CH0_RXTX_REG48_TX_USER_PATT7_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG49__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG49_TX_USER_PATT6_RD , 0x%x \n", FIELD_CH0_RXTX_REG49_TX_USER_PATT6_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG50__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG50_TX_USER_PATT5_RD , 0x%x \n", FIELD_CH0_RXTX_REG50_TX_USER_PATT5_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG51__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG51_TX_USER_PATT4_RD , 0x%x \n", FIELD_CH0_RXTX_REG51_TX_USER_PATT4_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG52__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG52_TX_USER_PATT3_RD , 0x%x \n", FIELD_CH0_RXTX_REG52_TX_USER_PATT3_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG53__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG53_TX_USER_PATT2_RD , 0x%x \n", FIELD_CH0_RXTX_REG53_TX_USER_PATT2_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG54__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG54_TX_USER_PATT1_RD , 0x%x \n", FIELD_CH0_RXTX_REG54_TX_USER_PATT1_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG55__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG55_TX_USER_PATT0_RD , 0x%x \n", FIELD_CH0_RXTX_REG55_TX_USER_PATT0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG56__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG56_RX_USER_PATT4_RD , 0x%x \n", FIELD_CH0_RXTX_REG56_RX_USER_PATT4_RD(data));	
printf ("FIELD_CH0_RXTX_REG56_RESERVED_13_RD , 0x%x \n", FIELD_CH0_RXTX_REG56_RESERVED_13_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG57__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG57_RX_USER_PATT3_RD , 0x%x \n", FIELD_CH0_RXTX_REG57_RX_USER_PATT3_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG58__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG58_RX_USER_PATT2_RD , 0x%x \n", FIELD_CH0_RXTX_REG58_RX_USER_PATT2_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG59__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG59_RX_USER_PATT1_RD , 0x%x \n", FIELD_CH0_RXTX_REG59_RX_USER_PATT1_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG60__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG60_RX_USER_PATT0_RD , 0x%x \n", FIELD_CH0_RXTX_REG60_RX_USER_PATT0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG61__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG61_RX_HSLS_PLL_SELECT_RD , 0x%x \n", FIELD_CH0_RXTX_REG61_RX_HSLS_PLL_SELECT_RD(data));	
printf ("FIELD_CH0_RXTX_REG61_TX_HSLS_PLL_SELECT_RD , 0x%x \n", FIELD_CH0_RXTX_REG61_TX_HSLS_PLL_SELECT_RD(data));	
printf ("FIELD_CH0_RXTX_REG61_SPD_SEL_CDR_RD , 0x%x \n", FIELD_CH0_RXTX_REG61_SPD_SEL_CDR_RD(data));	
printf ("FIELD_CH0_RXTX_REG61_EYE_MONITOR_CAPTURE_RD , 0x%x \n", FIELD_CH0_RXTX_REG61_EYE_MONITOR_CAPTURE_RD(data));	
printf ("FIELD_CH0_RXTX_REG61_EYE_ACC_RESETB_RD , 0x%x \n", FIELD_CH0_RXTX_REG61_EYE_ACC_RESETB_RD(data));	
printf ("FIELD_CH0_RXTX_REG61_EYE_COUNT_WIDTH_SEL_RD , 0x%x \n", FIELD_CH0_RXTX_REG61_EYE_COUNT_WIDTH_SEL_RD(data));	
printf ("FIELD_CH0_RXTX_REG61_BERT_RESETB_RD , 0x%x \n", FIELD_CH0_RXTX_REG61_BERT_RESETB_RD(data));	
printf ("FIELD_CH0_RXTX_REG61_ISCAN_INBERT_RD , 0x%x \n", FIELD_CH0_RXTX_REG61_ISCAN_INBERT_RD(data));	
printf ("FIELD_CH0_RXTX_REG61_LOADFREQ_SHIFT_RD , 0x%x \n", FIELD_CH0_RXTX_REG61_LOADFREQ_SHIFT_RD(data));	
printf ("FIELD_CH0_RXTX_REG61_MU_TIMER_RESET_RD , 0x%x \n", FIELD_CH0_RXTX_REG61_MU_TIMER_RESET_RD(data));	
printf ("FIELD_CH0_RXTX_REG61_BLWC_MAN_ENA_RD , 0x%x \n", FIELD_CH0_RXTX_REG61_BLWC_MAN_ENA_RD(data));	
printf ("FIELD_CH0_RXTX_REG61_DFE_TAB_ACCB_RD , 0x%x \n", FIELD_CH0_RXTX_REG61_DFE_TAB_ACCB_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG62__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG62_RESERVED_15_RD , 0x%x \n", FIELD_CH0_RXTX_REG62_RESERVED_15_RD(data));	
printf ("FIELD_CH0_RXTX_REG62_H1_QLATCH_SIGN_INV_RD , 0x%x \n", FIELD_CH0_RXTX_REG62_H1_QLATCH_SIGN_INV_RD(data));	
printf ("FIELD_CH0_RXTX_REG62_PERIOD_H1_QLATCH_RD , 0x%x \n", FIELD_CH0_RXTX_REG62_PERIOD_H1_QLATCH_RD(data));	
printf ("FIELD_CH0_RXTX_REG62_SWITCH_H1_QLATCH_RD , 0x%x \n", FIELD_CH0_RXTX_REG62_SWITCH_H1_QLATCH_RD(data));	
printf ("FIELD_CH0_RXTX_REG62_EYE_COUNT_THRES_RD , 0x%x \n", FIELD_CH0_RXTX_REG62_EYE_COUNT_THRES_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG63__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG63_INITFREQ_SHIFT_MSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG63_INITFREQ_SHIFT_MSB_RD(data));	
printf ("FIELD_CH0_RXTX_REG63_RESERVED_4_RD , 0x%x \n", FIELD_CH0_RXTX_REG63_RESERVED_4_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG64__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG64_INITFREQ_SHIFT_LSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG64_INITFREQ_SHIFT_LSB_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG65__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG65_LOOPBW_TAP1_MSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG65_LOOPBW_TAP1_MSB_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG66__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG66_LOOPBW_TAP1_LSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG66_LOOPBW_TAP1_LSB_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG67__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG67_LOOPBW_TAP2_MSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG67_LOOPBW_TAP2_MSB_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG68__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG68_LOOPBW_TAP2_LSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG68_LOOPBW_TAP2_LSB_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG69__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG69_LOOPBW_TAP3_MSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG69_LOOPBW_TAP3_MSB_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG70__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG70_LOOPBW_TAP3_LSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG70_LOOPBW_TAP3_LSB_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG71__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG71_LOOPBW_TAP4_MSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG71_LOOPBW_TAP4_MSB_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG72__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG72_LOOPBW_TAP4_LSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG72_LOOPBW_TAP4_LSB_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG73__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG73_LOOPBW_TAP5_MSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG73_LOOPBW_TAP5_MSB_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG74__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG74_LOOPBW_TAP5_LSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG74_LOOPBW_TAP5_LSB_RD(data));

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG75__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG75_LOOPBW_TAP6_MSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG75_LOOPBW_TAP6_MSB_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG76__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG76_LOOPBW_TAP6_LSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG76_LOOPBW_TAP6_LSB_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG77__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG77_LOOPBW_TAP7_MSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG77_LOOPBW_TAP7_MSB_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG78__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG78_LOOPBW_TAP7_LSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG78_LOOPBW_TAP7_LSB_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG79__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG79_LOOPBW_TAP8_MSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG79_LOOPBW_TAP8_MSB_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG80__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG80_LOOPBW_TAP8_LSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG80_LOOPBW_TAP8_LSB_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG81__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG81_MU_DFE1_RD , 0x%x \n", FIELD_CH0_RXTX_REG81_MU_DFE1_RD(data));	
printf ("FIELD_CH0_RXTX_REG81_MU_DFE2_RD , 0x%x \n", FIELD_CH0_RXTX_REG81_MU_DFE2_RD(data));	
printf ("FIELD_CH0_RXTX_REG81_MU_DFE3_RD , 0x%x \n", FIELD_CH0_RXTX_REG81_MU_DFE3_RD(data));	
printf ("FIELD_CH0_RXTX_REG81_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG81_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG82__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG82_MU_DFE4_RD , 0x%x \n", FIELD_CH0_RXTX_REG82_MU_DFE4_RD(data));	
printf ("FIELD_CH0_RXTX_REG82_MU_DFE5_RD , 0x%x \n", FIELD_CH0_RXTX_REG82_MU_DFE5_RD(data));	
printf ("FIELD_CH0_RXTX_REG82_MU_DFE6_RD , 0x%x \n", FIELD_CH0_RXTX_REG82_MU_DFE6_RD(data));	
printf ("FIELD_CH0_RXTX_REG82_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG82_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG83__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG83_MU_DFE7_RD , 0x%x \n", FIELD_CH0_RXTX_REG83_MU_DFE7_RD(data));	
printf ("FIELD_CH0_RXTX_REG83_MU_DFE8_RD , 0x%x \n", FIELD_CH0_RXTX_REG83_MU_DFE8_RD(data));	
printf ("FIELD_CH0_RXTX_REG83_MU_DFE9_RD , 0x%x \n", FIELD_CH0_RXTX_REG83_MU_DFE9_RD(data));	
printf ("FIELD_CH0_RXTX_REG83_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG83_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG84__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG84_MU_PH1_RD , 0x%x \n", FIELD_CH0_RXTX_REG84_MU_PH1_RD(data));	
printf ("FIELD_CH0_RXTX_REG84_MU_PH2_RD , 0x%x \n", FIELD_CH0_RXTX_REG84_MU_PH2_RD(data));	
printf ("FIELD_CH0_RXTX_REG84_MU_PH3_RD , 0x%x \n", FIELD_CH0_RXTX_REG84_MU_PH3_RD(data));	
printf ("FIELD_CH0_RXTX_REG84_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG84_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG85__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG85_MU_PH4_RD , 0x%x \n", FIELD_CH0_RXTX_REG85_MU_PH4_RD(data));	
printf ("FIELD_CH0_RXTX_REG85_MU_PH5_RD , 0x%x \n", FIELD_CH0_RXTX_REG85_MU_PH5_RD(data));	
printf ("FIELD_CH0_RXTX_REG85_MU_PH6_RD , 0x%x \n", FIELD_CH0_RXTX_REG85_MU_PH6_RD(data));	
printf ("FIELD_CH0_RXTX_REG85_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG85_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG86__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG86_MU_PH7_RD , 0x%x \n", FIELD_CH0_RXTX_REG86_MU_PH7_RD(data));	
printf ("FIELD_CH0_RXTX_REG86_MU_PH8_RD , 0x%x \n", FIELD_CH0_RXTX_REG86_MU_PH8_RD(data));	
printf ("FIELD_CH0_RXTX_REG86_MU_PH9_RD , 0x%x \n", FIELD_CH0_RXTX_REG86_MU_PH9_RD(data));	
printf ("FIELD_CH0_RXTX_REG86_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG86_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG87__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG87_MU_TH1_RD , 0x%x \n", FIELD_CH0_RXTX_REG87_MU_TH1_RD(data));	
printf ("FIELD_CH0_RXTX_REG87_MU_TH2_RD , 0x%x \n", FIELD_CH0_RXTX_REG87_MU_TH2_RD(data));	
printf ("FIELD_CH0_RXTX_REG87_MU_TH3_RD , 0x%x \n", FIELD_CH0_RXTX_REG87_MU_TH3_RD(data));	
printf ("FIELD_CH0_RXTX_REG87_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG87_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG88__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG88_MU_TH4_RD , 0x%x \n", FIELD_CH0_RXTX_REG88_MU_TH4_RD(data));	
printf ("FIELD_CH0_RXTX_REG88_MU_TH5_RD , 0x%x \n", FIELD_CH0_RXTX_REG88_MU_TH5_RD(data));	
printf ("FIELD_CH0_RXTX_REG88_MU_TH6_RD , 0x%x \n", FIELD_CH0_RXTX_REG88_MU_TH6_RD(data));	
printf ("FIELD_CH0_RXTX_REG88_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG88_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG89__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG89_MU_TH7_RD , 0x%x \n", FIELD_CH0_RXTX_REG89_MU_TH7_RD(data));	
printf ("FIELD_CH0_RXTX_REG89_MU_TH8_RD , 0x%x \n", FIELD_CH0_RXTX_REG89_MU_TH8_RD(data));	
printf ("FIELD_CH0_RXTX_REG89_MU_TH9_RD , 0x%x \n", FIELD_CH0_RXTX_REG89_MU_TH9_RD(data));	
printf ("FIELD_CH0_RXTX_REG89_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG89_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG90__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG90_MU_BCA1_RD , 0x%x \n", FIELD_CH0_RXTX_REG90_MU_BCA1_RD(data));	
printf ("FIELD_CH0_RXTX_REG90_MU_BCA2_RD , 0x%x \n", FIELD_CH0_RXTX_REG90_MU_BCA2_RD(data));	
printf ("FIELD_CH0_RXTX_REG90_MU_BCA3_RD , 0x%x \n", FIELD_CH0_RXTX_REG90_MU_BCA3_RD(data));	
printf ("FIELD_CH0_RXTX_REG90_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG90_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG91__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG91_MU_BCA4_RD , 0x%x \n", FIELD_CH0_RXTX_REG91_MU_BCA4_RD(data));	
printf ("FIELD_CH0_RXTX_REG91_MU_BCA5_RD , 0x%x \n", FIELD_CH0_RXTX_REG91_MU_BCA5_RD(data));	
printf ("FIELD_CH0_RXTX_REG91_MU_BCA6_RD , 0x%x \n", FIELD_CH0_RXTX_REG91_MU_BCA6_RD(data));	
printf ("FIELD_CH0_RXTX_REG91_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG91_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG92__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG92_MU_BCA7_RD , 0x%x \n", FIELD_CH0_RXTX_REG92_MU_BCA7_RD(data));	
printf ("FIELD_CH0_RXTX_REG92_MU_BCA8_RD , 0x%x \n", FIELD_CH0_RXTX_REG92_MU_BCA8_RD(data));	
printf ("FIELD_CH0_RXTX_REG92_MU_BCA9_RD , 0x%x \n", FIELD_CH0_RXTX_REG92_MU_BCA9_RD(data));	
printf ("FIELD_CH0_RXTX_REG92_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG92_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG93__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG93_MU_BLWC1_RD , 0x%x \n", FIELD_CH0_RXTX_REG93_MU_BLWC1_RD(data));	
printf ("FIELD_CH0_RXTX_REG93_MU_BLWC2_RD , 0x%x \n", FIELD_CH0_RXTX_REG93_MU_BLWC2_RD(data));	
printf ("FIELD_CH0_RXTX_REG93_MU_BLWC3_RD , 0x%x \n", FIELD_CH0_RXTX_REG93_MU_BLWC3_RD(data));	
printf ("FIELD_CH0_RXTX_REG93_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG93_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG94__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG94_MU_BLWC4_RD , 0x%x \n", FIELD_CH0_RXTX_REG94_MU_BLWC4_RD(data));	
printf ("FIELD_CH0_RXTX_REG94_MU_BLWC5_RD , 0x%x \n", FIELD_CH0_RXTX_REG94_MU_BLWC5_RD(data));	
printf ("FIELD_CH0_RXTX_REG94_MU_BLWC6_RD , 0x%x \n", FIELD_CH0_RXTX_REG94_MU_BLWC6_RD(data));	
printf ("FIELD_CH0_RXTX_REG94_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG94_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG95__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG95_MU_BLWC7_RD , 0x%x \n", FIELD_CH0_RXTX_REG95_MU_BLWC7_RD(data));	
printf ("FIELD_CH0_RXTX_REG95_MU_BLWC8_RD , 0x%x \n", FIELD_CH0_RXTX_REG95_MU_BLWC8_RD(data));	
printf ("FIELD_CH0_RXTX_REG95_MU_BLWC9_RD , 0x%x \n", FIELD_CH0_RXTX_REG95_MU_BLWC9_RD(data));	
printf ("FIELD_CH0_RXTX_REG95_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG95_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG96__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG96_MU_FREQ1_RD , 0x%x \n", FIELD_CH0_RXTX_REG96_MU_FREQ1_RD(data));	
printf ("FIELD_CH0_RXTX_REG96_MU_FREQ2_RD , 0x%x \n", FIELD_CH0_RXTX_REG96_MU_FREQ2_RD(data));	
printf ("FIELD_CH0_RXTX_REG96_MU_FREQ3_RD , 0x%x \n", FIELD_CH0_RXTX_REG96_MU_FREQ3_RD(data));	
printf ("FIELD_CH0_RXTX_REG96_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG96_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG97__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG97_MU_FREQ4_RD , 0x%x \n", FIELD_CH0_RXTX_REG97_MU_FREQ4_RD(data));	
printf ("FIELD_CH0_RXTX_REG97_MU_FREQ5_RD , 0x%x \n", FIELD_CH0_RXTX_REG97_MU_FREQ5_RD(data));	
printf ("FIELD_CH0_RXTX_REG97_MU_FREQ6_RD , 0x%x \n", FIELD_CH0_RXTX_REG97_MU_FREQ6_RD(data));	
printf ("FIELD_CH0_RXTX_REG97_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG97_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG98__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG98_MU_FREQ7_RD , 0x%x \n", FIELD_CH0_RXTX_REG98_MU_FREQ7_RD(data));	
printf ("FIELD_CH0_RXTX_REG98_MU_FREQ8_RD , 0x%x \n", FIELD_CH0_RXTX_REG98_MU_FREQ8_RD(data));	
printf ("FIELD_CH0_RXTX_REG98_MU_FREQ9_RD , 0x%x \n", FIELD_CH0_RXTX_REG98_MU_FREQ9_RD(data));	
printf ("FIELD_CH0_RXTX_REG98_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG98_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG99__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG99_MU_PHASE1_RD , 0x%x \n", FIELD_CH0_RXTX_REG99_MU_PHASE1_RD(data));	
printf ("FIELD_CH0_RXTX_REG99_MU_PHASE2_RD , 0x%x \n", FIELD_CH0_RXTX_REG99_MU_PHASE2_RD(data));	
printf ("FIELD_CH0_RXTX_REG99_MU_PHASE3_RD , 0x%x \n", FIELD_CH0_RXTX_REG99_MU_PHASE3_RD(data));	
printf ("FIELD_CH0_RXTX_REG99_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG99_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG100__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG100_MU_PHASE4_RD , 0x%x \n", FIELD_CH0_RXTX_REG100_MU_PHASE4_RD(data));	
printf ("FIELD_CH0_RXTX_REG100_MU_PHASE5_RD , 0x%x \n", FIELD_CH0_RXTX_REG100_MU_PHASE5_RD(data));	
printf ("FIELD_CH0_RXTX_REG100_MU_PHASE6_RD , 0x%x \n", FIELD_CH0_RXTX_REG100_MU_PHASE6_RD(data));	
printf ("FIELD_CH0_RXTX_REG100_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG100_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG101__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG101_MU_PHASE7_RD , 0x%x \n", FIELD_CH0_RXTX_REG101_MU_PHASE7_RD(data));	
printf ("FIELD_CH0_RXTX_REG101_MU_PHASE8_RD , 0x%x \n", FIELD_CH0_RXTX_REG101_MU_PHASE8_RD(data));	
printf ("FIELD_CH0_RXTX_REG101_MU_PHASE9_RD , 0x%x \n", FIELD_CH0_RXTX_REG101_MU_PHASE9_RD(data));	
printf ("FIELD_CH0_RXTX_REG101_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG101_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG102__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG102_PIN_OVERRIDE_RD , 0x%x \n", FIELD_CH0_RXTX_REG102_PIN_OVERRIDE_RD(data));	
printf ("FIELD_CH0_RXTX_REG102_PUSH_PIACC_VAL_RD , 0x%x \n", FIELD_CH0_RXTX_REG102_PUSH_PIACC_VAL_RD(data));	
printf ("FIELD_CH0_RXTX_REG102_PUSH_PIACC_RD , 0x%x \n", FIELD_CH0_RXTX_REG102_PUSH_PIACC_RD(data));	
printf ("FIELD_CH0_RXTX_REG102_FREQLOOP_LIMIT_RD , 0x%x \n", FIELD_CH0_RXTX_REG102_FREQLOOP_LIMIT_RD(data));	
printf ("FIELD_CH0_RXTX_REG102_H1_SKEW_RD , 0x%x \n", FIELD_CH0_RXTX_REG102_H1_SKEW_RD(data));	
printf ("FIELD_CH0_RXTX_REG102_RESERVED_2_RD , 0x%x \n", FIELD_CH0_RXTX_REG102_RESERVED_2_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG103__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG103_MU_MAX_TIMER_MSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG103_MU_MAX_TIMER_MSB_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG104__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG104_MU_MAX_TIMER_LSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG104_MU_MAX_TIMER_LSB_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG105__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG105_DFE_TAP_SNAP_READOUT_MSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG105_DFE_TAP_SNAP_READOUT_MSB_RD(data));

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG106__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG106_DFE_TAP_SNAP_READOUT_LSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG106_DFE_TAP_SNAP_READOUT_LSB_RD(data));

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG107__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG107_DFE_TAP_WRITE_MSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG107_DFE_TAP_WRITE_MSB_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG108__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG108_DFE_TAP_WRITE_LSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG108_DFE_TAP_WRITE_LSB_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG109__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG109_EYE_SCAN_ERROR_RD , 0x%x \n", FIELD_CH0_RXTX_REG109_EYE_SCAN_ERROR_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG110__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG110_EYE_SCAN_SAMPLE_RD , 0x%x \n", FIELD_CH0_RXTX_REG110_EYE_SCAN_SAMPLE_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG111__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG111_CDR_BW_MAX_TIMER1_RD , 0x%x \n", FIELD_CH0_RXTX_REG111_CDR_BW_MAX_TIMER1_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG112__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG112_CDR_BW_MAX_TIMER0_RD , 0x%x \n", FIELD_CH0_RXTX_REG112_CDR_BW_MAX_TIMER0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG113__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG113_FT_SEARCH_TIMER_RD , 0x%x \n", FIELD_CH0_RXTX_REG113_FT_SEARCH_TIMER_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG114__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG114_FLOAT_SELECT_RD , 0x%x \n", FIELD_CH0_RXTX_REG114_FLOAT_SELECT_RD(data));	
printf ("FIELD_CH0_RXTX_REG114_FORCE_FT_POS0_RD , 0x%x \n", FIELD_CH0_RXTX_REG114_FORCE_FT_POS0_RD(data));	
printf ("FIELD_CH0_RXTX_REG114_FORCE_FT_POS1_RD , 0x%x \n", FIELD_CH0_RXTX_REG114_FORCE_FT_POS1_RD(data));	
printf ("FIELD_CH0_RXTX_REG114_FORCE_FT_POS2_RD , 0x%x \n", FIELD_CH0_RXTX_REG114_FORCE_FT_POS2_RD(data));	
printf ("FIELD_CH0_RXTX_REG114_FORCE_FT_POS3_RD , 0x%x \n", FIELD_CH0_RXTX_REG114_FORCE_FT_POS3_RD(data));	
printf ("FIELD_CH0_RXTX_REG114_FORCE_FT_POS4_RD , 0x%x \n", FIELD_CH0_RXTX_REG114_FORCE_FT_POS4_RD(data));	
printf ("FIELD_CH0_RXTX_REG114_FORCE_FT_WGT0_RD , 0x%x \n", FIELD_CH0_RXTX_REG114_FORCE_FT_WGT0_RD(data));	
printf ("FIELD_CH0_RXTX_REG114_FORCE_FT_WGT1_RD , 0x%x \n", FIELD_CH0_RXTX_REG114_FORCE_FT_WGT1_RD(data));	
printf ("FIELD_CH0_RXTX_REG114_FORCE_FT_WGT2_RD , 0x%x \n", FIELD_CH0_RXTX_REG114_FORCE_FT_WGT2_RD(data));	
printf ("FIELD_CH0_RXTX_REG114_FORCE_FT_WGT3_RD , 0x%x \n", FIELD_CH0_RXTX_REG114_FORCE_FT_WGT3_RD(data));	
printf ("FIELD_CH0_RXTX_REG114_FORCE_FT_WGT4_RD , 0x%x \n", FIELD_CH0_RXTX_REG114_FORCE_FT_WGT4_RD(data));	
printf ("FIELD_CH0_RXTX_REG114_MAN_WEIGHT_FT0_RD , 0x%x \n", FIELD_CH0_RXTX_REG114_MAN_WEIGHT_FT0_RD(data));	
printf ("FIELD_CH0_RXTX_REG114_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG114_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG115__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG115_MAN_POSITION_FT0_RD , 0x%x \n", FIELD_CH0_RXTX_REG115_MAN_POSITION_FT0_RD(data));	
printf ("FIELD_CH0_RXTX_REG115_MAN_WEIGHT_FT1_RD , 0x%x \n", FIELD_CH0_RXTX_REG115_MAN_WEIGHT_FT1_RD(data));	
printf ("FIELD_CH0_RXTX_REG115_MAN_POSITION_FT1_RD , 0x%x \n", FIELD_CH0_RXTX_REG115_MAN_POSITION_FT1_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG116__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG116_MAN_WEIGHT_FT2_RD , 0x%x \n", FIELD_CH0_RXTX_REG116_MAN_WEIGHT_FT2_RD(data));	
printf ("FIELD_CH0_RXTX_REG116_MAN_POSITION_FT2_RD , 0x%x \n", FIELD_CH0_RXTX_REG116_MAN_POSITION_FT2_RD(data));	
printf ("FIELD_CH0_RXTX_REG116_MAN_WEIGHT_FT3_RD , 0x%x \n", FIELD_CH0_RXTX_REG116_MAN_WEIGHT_FT3_RD(data));	
printf ("FIELD_CH0_RXTX_REG116_RESERVED_1_RD , 0x%x \n", FIELD_CH0_RXTX_REG116_RESERVED_1_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG117__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG117_MAN_POSITION_FT3_RD , 0x%x \n", FIELD_CH0_RXTX_REG117_MAN_POSITION_FT3_RD(data));	
printf ("FIELD_CH0_RXTX_REG117_MAN_WEIGHT_FT4_RD , 0x%x \n", FIELD_CH0_RXTX_REG117_MAN_WEIGHT_FT4_RD(data));	
printf ("FIELD_CH0_RXTX_REG117_MAN_POSITION_FT4_RD , 0x%x \n", FIELD_CH0_RXTX_REG117_MAN_POSITION_FT4_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG118__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG118_EYE_COUNT1_RD , 0x%x \n", FIELD_CH0_RXTX_REG118_EYE_COUNT1_RD(data));	
printf ("FIELD_CH0_RXTX_REG118_ACC_FULL_FLAG_RD , 0x%x \n", FIELD_CH0_RXTX_REG118_ACC_FULL_FLAG_RD(data));	
printf ("FIELD_CH0_RXTX_REG118_RX_BIST_CONT_DONE_RD , 0x%x \n", FIELD_CH0_RXTX_REG118_RX_BIST_CONT_DONE_RD(data));	
printf ("FIELD_CH0_RXTX_REG118_RESERVED_2_RD , 0x%x \n", FIELD_CH0_RXTX_REG118_RESERVED_2_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG119__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG119_EYE_COUNT0_RD , 0x%x \n", FIELD_CH0_RXTX_REG119_EYE_COUNT0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG120__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG120_CDR_ACCUM_RD_LSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG120_CDR_ACCUM_RD_LSB_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG121__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG121_CDR_ACCUM_RD_MSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG121_CDR_ACCUM_RD_MSB_RD(data));	
printf ("FIELD_CH0_RXTX_REG121_SUMOS_CAL_CODE_RD , 0x%x \n", FIELD_CH0_RXTX_REG121_SUMOS_CAL_CODE_RD(data));	
printf ("FIELD_CH0_RXTX_REG121_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG121_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG122__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG122_RESERVED_15_RD , 0x%x \n", FIELD_CH0_RXTX_REG122_RESERVED_15_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG123__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG123_EYE_ACCUMULATOR1_RD , 0x%x \n", FIELD_CH0_RXTX_REG123_EYE_ACCUMULATOR1_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG124__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG124_EYE_ACCUMULATOR0_RD , 0x%x \n", FIELD_CH0_RXTX_REG124_EYE_ACCUMULATOR0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG125__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG125_PQ_REG_RD , 0x%x \n", FIELD_CH0_RXTX_REG125_PQ_REG_RD(data));	
printf ("FIELD_CH0_RXTX_REG125_SIGN_PQ_RD , 0x%x \n", FIELD_CH0_RXTX_REG125_SIGN_PQ_RD(data));	
printf ("FIELD_CH0_RXTX_REG125_SIGN_PQ_2C_RD , 0x%x \n", FIELD_CH0_RXTX_REG125_SIGN_PQ_2C_RD(data));	
printf ("FIELD_CH0_RXTX_REG125_PHZ_MANUALCODE_RD , 0x%x \n", FIELD_CH0_RXTX_REG125_PHZ_MANUALCODE_RD(data));	
printf ("FIELD_CH0_RXTX_REG125_PHZ_MANUAL_RD , 0x%x \n", FIELD_CH0_RXTX_REG125_PHZ_MANUAL_RD(data));	
printf ("FIELD_CH0_RXTX_REG125_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG125_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG126__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG126_QI_REG_RD , 0x%x \n", FIELD_CH0_RXTX_REG126_QI_REG_RD(data));	
printf ("FIELD_CH0_RXTX_REG126_RESERVED_8_RD , 0x%x \n", FIELD_CH0_RXTX_REG126_RESERVED_8_RD(data));	
printf ("FIELD_CH0_RXTX_REG126_SIGN_QI_REG_RD , 0x%x \n", FIELD_CH0_RXTX_REG126_SIGN_QI_REG_RD(data));	
printf ("FIELD_CH0_RXTX_REG126_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG126_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG127_DO_LATCH_MANCAL_RD , 0x%x \n", FIELD_CH0_RXTX_REG127_DO_LATCH_MANCAL_RD(data));	
printf ("FIELD_CH0_RXTX_REG127_XO_LATCH_MANCAL_RD , 0x%x \n", FIELD_CH0_RXTX_REG127_XO_LATCH_MANCAL_RD(data));	
printf ("FIELD_CH0_RXTX_REG127_LATCH_MAN_CAL_ENA_RD , 0x%x \n", FIELD_CH0_RXTX_REG127_LATCH_MAN_CAL_ENA_RD(data));	
printf ("FIELD_CH0_RXTX_REG127_FORCE_LAT_CAL_START_RD , 0x%x \n", FIELD_CH0_RXTX_REG127_FORCE_LAT_CAL_START_RD(data));	
printf ("FIELD_CH0_RXTX_REG127_FORCE_SUM_CAL_START_RD , 0x%x \n", FIELD_CH0_RXTX_REG127_FORCE_SUM_CAL_START_RD(data));	
printf ("FIELD_CH0_RXTX_REG127_FORCE_CTLE_CAL_START_RD , 0x%x \n", FIELD_CH0_RXTX_REG127_FORCE_CTLE_CAL_START_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG128__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG128_EO_LATCH_MANCAL_RD , 0x%x \n", FIELD_CH0_RXTX_REG128_EO_LATCH_MANCAL_RD(data));	
printf ("FIELD_CH0_RXTX_REG128_SO_LATCH_MANCAL_RD , 0x%x \n", FIELD_CH0_RXTX_REG128_SO_LATCH_MANCAL_RD(data));	
printf ("FIELD_CH0_RXTX_REG128_LATCH_CAL_WAIT_SEL_RD , 0x%x \n", FIELD_CH0_RXTX_REG128_LATCH_CAL_WAIT_SEL_RD(data));	
printf ("FIELD_CH0_RXTX_REG128_RESERVED_1_RD , 0x%x \n", FIELD_CH0_RXTX_REG128_RESERVED_1_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG129__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG129_DE_LATCH_MANCAL_RD , 0x%x \n", FIELD_CH0_RXTX_REG129_DE_LATCH_MANCAL_RD(data));	
printf ("FIELD_CH0_RXTX_REG129_XE_LATCH_MANCAL_RD , 0x%x \n", FIELD_CH0_RXTX_REG129_XE_LATCH_MANCAL_RD(data));	
printf ("FIELD_CH0_RXTX_REG129_RESERVED_3_RD , 0x%x \n", FIELD_CH0_RXTX_REG129_RESERVED_3_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG130__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG130_EE_LATCH_MANCAL_RD , 0x%x \n", FIELD_CH0_RXTX_REG130_EE_LATCH_MANCAL_RD(data));	
printf ("FIELD_CH0_RXTX_REG130_SE_LATCH_MANCAL_RD , 0x%x \n", FIELD_CH0_RXTX_REG130_SE_LATCH_MANCAL_RD(data));	
printf ("FIELD_CH0_RXTX_REG130_RESERVED_3_RD , 0x%x \n", FIELD_CH0_RXTX_REG130_RESERVED_3_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG131__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG131_INITFREQRAMPN_MSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG131_INITFREQRAMPN_MSB_RD(data));	
printf ("FIELD_CH0_RXTX_REG131_LOADFREQRAMP_RD , 0x%x \n", FIELD_CH0_RXTX_REG131_LOADFREQRAMP_RD(data));	
printf ("FIELD_CH0_RXTX_REG131_RESERVED_3_RD , 0x%x \n", FIELD_CH0_RXTX_REG131_RESERVED_3_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG132__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG132_INITFREQRAMPN_LSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG132_INITFREQRAMPN_LSB_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG133__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG133_INITFREQRAMPP_MSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG133_INITFREQRAMPP_MSB_RD(data));	
printf ("FIELD_CH0_RXTX_REG133_RESERVED_4_RD , 0x%x \n", FIELD_CH0_RXTX_REG133_RESERVED_4_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG134__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG134_INITFREQRAMPP_LSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG134_INITFREQRAMPP_LSB_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG135__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG135_RAMPREGN_MSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG135_RAMPREGN_MSB_RD(data));	
printf ("FIELD_CH0_RXTX_REG135_RESERVED_4_RD , 0x%x \n", FIELD_CH0_RXTX_REG135_RESERVED_4_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG136__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG136_RAMPREGN_LSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG136_RAMPREGN_LSB_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG137__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG137_RAMPREGP_MSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG137_RAMPREGP_MSB_RD(data));	
printf ("FIELD_CH0_RXTX_REG137_RESERVED_4_RD , 0x%x \n", FIELD_CH0_RXTX_REG137_RESERVED_4_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG138__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG138_RAMPREGP_LSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG138_RAMPREGP_LSB_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG139__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG139_ISCAN_ODD_EVEN_RD , 0x%x \n", FIELD_CH0_RXTX_REG139_ISCAN_ODD_EVEN_RD(data));	
printf ("FIELD_CH0_RXTX_REG139_ISCAN_DSEL_RD , 0x%x \n", FIELD_CH0_RXTX_REG139_ISCAN_DSEL_RD(data));	
printf ("FIELD_CH0_RXTX_REG139_RX_DATA_SEL_RD , 0x%x \n", FIELD_CH0_RXTX_REG139_RX_DATA_SEL_RD(data));	
printf ("FIELD_CH0_RXTX_REG139_ISCAN_SEL_RD , 0x%x \n", FIELD_CH0_RXTX_REG139_ISCAN_SEL_RD(data));	
printf ("FIELD_CH0_RXTX_REG139_ISCAN_START_RD , 0x%x \n", FIELD_CH0_RXTX_REG139_ISCAN_START_RD(data));	
printf ("FIELD_CH0_RXTX_REG139_ISCAN_STOP_RD , 0x%x \n", FIELD_CH0_RXTX_REG139_ISCAN_STOP_RD(data));	
printf ("FIELD_CH0_RXTX_REG139_ISCAN_PD_RD , 0x%x \n", FIELD_CH0_RXTX_REG139_ISCAN_PD_RD(data));	
printf ("FIELD_CH0_RXTX_REG139_ISCAN_CNT_SEL_RD , 0x%x \n", FIELD_CH0_RXTX_REG139_ISCAN_CNT_SEL_RD(data));	
printf ("FIELD_CH0_RXTX_REG139_ISCAN_RESOLUTION_RD , 0x%x \n", FIELD_CH0_RXTX_REG139_ISCAN_RESOLUTION_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG140__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG140_QUALIFY_SAMPLE_RD , 0x%x \n", FIELD_CH0_RXTX_REG140_QUALIFY_SAMPLE_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG141__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG141_MASK_SAMPLE_RD , 0x%x \n", FIELD_CH0_RXTX_REG141_MASK_SAMPLE_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG142__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG142_ISCAN_COMP_DSEL_RD , 0x%x \n", FIELD_CH0_RXTX_REG142_ISCAN_COMP_DSEL_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG143__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG143_MEANFREQSHIFT_RD , 0x%x \n", FIELD_CH0_RXTX_REG143_MEANFREQSHIFT_RD(data));	
printf ("FIELD_CH0_RXTX_REG143_RESERVED_1_RD , 0x%x \n", FIELD_CH0_RXTX_REG143_RESERVED_1_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG144__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG144_TX_SPARE_RD , 0x%x \n", FIELD_CH0_RXTX_REG144_TX_SPARE_RD(data));	
printf ("FIELD_CH0_RXTX_REG144_FORCE_SD_RD , 0x%x \n", FIELD_CH0_RXTX_REG144_FORCE_SD_RD(data));	
printf ("FIELD_CH0_RXTX_REG144_SKIP_SD_ON_RD , 0x%x \n", FIELD_CH0_RXTX_REG144_SKIP_SD_ON_RD(data));	
printf ("FIELD_CH0_RXTX_REG144_USE_RAWSD_RD , 0x%x \n", FIELD_CH0_RXTX_REG144_USE_RAWSD_RD(data));	
printf ("FIELD_CH0_RXTX_REG144_BYPASS_RXLOS_RD , 0x%x \n", FIELD_CH0_RXTX_REG144_BYPASS_RXLOS_RD(data));	
printf ("FIELD_CH0_RXTX_REG144_RXJTAGOS_RD , 0x%x \n", FIELD_CH0_RXTX_REG144_RXJTAGOS_RD(data));	
printf ("FIELD_CH0_RXTX_REG144_RESERVED_1_RD , 0x%x \n", FIELD_CH0_RXTX_REG144_RESERVED_1_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG145__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG145_RXDFE_CONFIG_RD , 0x%x \n", FIELD_CH0_RXTX_REG145_RXDFE_CONFIG_RD(data));	
printf ("FIELD_CH0_RXTX_REG145_RXDFE_FLT_CONFIG_RD , 0x%x \n", FIELD_CH0_RXTX_REG145_RXDFE_FLT_CONFIG_RD(data));	
printf ("FIELD_CH0_RXTX_REG145_RXDFETAP_ADJ_RD , 0x%x \n", FIELD_CH0_RXTX_REG145_RXDFETAP_ADJ_RD(data));	
printf ("FIELD_CH0_RXTX_REG145_RXDFEBUF_VCM_RD , 0x%x \n", FIELD_CH0_RXTX_REG145_RXDFEBUF_VCM_RD(data));	
printf ("FIELD_CH0_RXTX_REG145_RXLATCALIB_ADJ_RD , 0x%x \n", FIELD_CH0_RXTX_REG145_RXLATCALIB_ADJ_RD(data));	
printf ("FIELD_CH0_RXTX_REG145_RXVWES_LATENA_RD , 0x%x \n", FIELD_CH0_RXTX_REG145_RXVWES_LATENA_RD(data));	
printf ("FIELD_CH0_RXTX_REG145_RXES_ENA_RD , 0x%x \n", FIELD_CH0_RXTX_REG145_RXES_ENA_RD(data));	
printf ("FIELD_CH0_RXTX_REG145_TX_IDLE_SATA_RD , 0x%x \n", FIELD_CH0_RXTX_REG145_TX_IDLE_SATA_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG146__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG146_CLK_RATE_RXLOSFT_RD , 0x%x \n", FIELD_CH0_RXTX_REG146_CLK_RATE_RXLOSFT_RD(data));	
printf ("FIELD_CH0_RXTX_REG146_SAMPLERATE_RXLOSFT_RD , 0x%x \n", FIELD_CH0_RXTX_REG146_SAMPLERATE_RXLOSFT_RD(data));	
printf ("FIELD_CH0_RXTX_REG146_THRESHOLDCOUNT_OFF_RD , 0x%x \n", FIELD_CH0_RXTX_REG146_THRESHOLDCOUNT_OFF_RD(data));	
printf ("FIELD_CH0_RXTX_REG146_THRESHOLDCOUNT_ON_RD , 0x%x \n", FIELD_CH0_RXTX_REG146_THRESHOLDCOUNT_ON_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG147__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG147_STMC_OVERRIDE_RD , 0x%x \n", FIELD_CH0_RXTX_REG147_STMC_OVERRIDE_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG148__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG148_RX_BIST_WORD_CNT_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG148_RX_BIST_WORD_CNT_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG149__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG149_RX_BIST_WORD_CNT_1_RD , 0x%x \n", FIELD_CH0_RXTX_REG149_RX_BIST_WORD_CNT_1_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG150__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG150_RX_BIST_WORD_CNT_2_RD , 0x%x \n", FIELD_CH0_RXTX_REG150_RX_BIST_WORD_CNT_2_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG151__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG151_RX_BIST_WORD_CNT_3_RD , 0x%x \n", FIELD_CH0_RXTX_REG151_RX_BIST_WORD_CNT_3_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG152__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG152_RX_BIST_ERR_CNT_MSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG152_RX_BIST_ERR_CNT_MSB_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG153__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG153_RX_BIST_ERR_CNT_LSB_RD , 0x%x \n", FIELD_CH0_RXTX_REG153_RX_BIST_ERR_CNT_LSB_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG154__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG154_RESERVED_15_RD , 0x%x \n", FIELD_CH0_RXTX_REG154_RESERVED_15_RD(data));	
printf ("FIELD_CH0_RXTX_REG154_BLWC_GAIN_MAN_PROG_RD , 0x%x \n", FIELD_CH0_RXTX_REG154_BLWC_GAIN_MAN_PROG_RD(data));	
printf ("FIELD_CH0_RXTX_REG154_BC_TAP_ENA_RD , 0x%x \n", FIELD_CH0_RXTX_REG154_BC_TAP_ENA_RD(data));	
printf ("FIELD_CH0_RXTX_REG154_RESERVED_3_RD , 0x%x \n", FIELD_CH0_RXTX_REG154_RESERVED_3_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG155__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG155_MU_FRAMP1_RD , 0x%x \n", FIELD_CH0_RXTX_REG155_MU_FRAMP1_RD(data));	
printf ("FIELD_CH0_RXTX_REG155_MU_FRAMP2_RD , 0x%x \n", FIELD_CH0_RXTX_REG155_MU_FRAMP2_RD(data));	
printf ("FIELD_CH0_RXTX_REG155_MU_FRAMP3_RD , 0x%x \n", FIELD_CH0_RXTX_REG155_MU_FRAMP3_RD(data));	
printf ("FIELD_CH0_RXTX_REG155_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG155_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG156__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG156_MU_FRAMP4_RD , 0x%x \n", FIELD_CH0_RXTX_REG156_MU_FRAMP4_RD(data));	
printf ("FIELD_CH0_RXTX_REG156_MU_FRAMP5_RD , 0x%x \n", FIELD_CH0_RXTX_REG156_MU_FRAMP5_RD(data));	
printf ("FIELD_CH0_RXTX_REG156_MU_FRAMP6_RD , 0x%x \n", FIELD_CH0_RXTX_REG156_MU_FRAMP6_RD(data));	
printf ("FIELD_CH0_RXTX_REG156_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG156_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG157__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG157_MU_FRAMP7_RD , 0x%x \n", FIELD_CH0_RXTX_REG157_MU_FRAMP7_RD(data));	
printf ("FIELD_CH0_RXTX_REG157_MU_FRAMP8_RD , 0x%x \n", FIELD_CH0_RXTX_REG157_MU_FRAMP8_RD(data));	
printf ("FIELD_CH0_RXTX_REG157_MU_FRAMP9_RD , 0x%x \n", FIELD_CH0_RXTX_REG157_MU_FRAMP9_RD(data));	
printf ("FIELD_CH0_RXTX_REG157_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG157_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG158__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG158_SUM_CALIB_DONE_RD , 0x%x \n", FIELD_CH0_RXTX_REG158_SUM_CALIB_DONE_RD(data));	
printf ("FIELD_CH0_RXTX_REG158_SUM_CALIB_ERR_RD , 0x%x \n", FIELD_CH0_RXTX_REG158_SUM_CALIB_ERR_RD(data));	
printf ("FIELD_CH0_RXTX_REG158_CTLE_CALIB_DONE_RD , 0x%x \n", FIELD_CH0_RXTX_REG158_CTLE_CALIB_DONE_RD(data));	
printf ("FIELD_CH0_RXTX_REG158_CTLE_CALIB_ERROR_RD , 0x%x \n", FIELD_CH0_RXTX_REG158_CTLE_CALIB_ERROR_RD(data));	
printf ("FIELD_CH0_RXTX_REG158_LAT_CALIB_DONE_RD , 0x%x \n", FIELD_CH0_RXTX_REG158_LAT_CALIB_DONE_RD(data));	
printf ("FIELD_CH0_RXTX_REG158_FT_SRC_DONE_RD , 0x%x \n", FIELD_CH0_RXTX_REG158_FT_SRC_DONE_RD(data));	
printf ("FIELD_CH0_RXTX_REG158_BCK_ACK_CN_RD , 0x%x \n", FIELD_CH0_RXTX_REG158_BCK_ACK_CN_RD(data));	
printf ("FIELD_CH0_RXTX_REG158_BCK_ACK_CP_RD , 0x%x \n", FIELD_CH0_RXTX_REG158_BCK_ACK_CP_RD(data));	
printf ("FIELD_CH0_RXTX_REG158_RX_BIST_PASS_RD , 0x%x \n", FIELD_CH0_RXTX_REG158_RX_BIST_PASS_RD(data));	
printf ("FIELD_CH0_RXTX_REG158_RX_BIST_FAIL_RD , 0x%x \n", FIELD_CH0_RXTX_REG158_RX_BIST_FAIL_RD(data));	
printf ("FIELD_CH0_RXTX_REG158_RESERVED_5_RD , 0x%x \n", FIELD_CH0_RXTX_REG158_RESERVED_5_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG159__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG159_DFE_PRESET_VALUE_BCTAP0_RD , 0x%x \n", FIELD_CH0_RXTX_REG159_DFE_PRESET_VALUE_BCTAP0_RD(data));	
printf ("FIELD_CH0_RXTX_REG159_RESERVED_8_RD , 0x%x \n", FIELD_CH0_RXTX_REG159_RESERVED_8_RD(data));	
printf ("FIELD_CH0_RXTX_REG159_DFE_PRESET_VALUE_BCTAP1_RD , 0x%x \n", FIELD_CH0_RXTX_REG159_DFE_PRESET_VALUE_BCTAP1_RD(data));	
printf ("FIELD_CH0_RXTX_REG159_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG159_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG160__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG160_DFE_PRESET_VALUE_BLW_RD , 0x%x \n", FIELD_CH0_RXTX_REG160_DFE_PRESET_VALUE_BLW_RD(data));	
printf ("FIELD_CH0_RXTX_REG160_RESERVED_8_RD , 0x%x \n", FIELD_CH0_RXTX_REG160_RESERVED_8_RD(data));	
printf ("FIELD_CH0_RXTX_REG160_DFE_PRESET_VALUE_PHTAP_RD , 0x%x \n", FIELD_CH0_RXTX_REG160_DFE_PRESET_VALUE_PHTAP_RD(data));	
printf ("FIELD_CH0_RXTX_REG160_RESERVED_0_RD , 0x%x \n", FIELD_CH0_RXTX_REG160_RESERVED_0_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG161__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG161_EYE_T_ACCUMULATOR1_RD , 0x%x \n", FIELD_CH0_RXTX_REG161_EYE_T_ACCUMULATOR1_RD(data));	

data =pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG162__ADDR + (channel*0x200) + sds2_offset);
printf ("FIELD_CH0_RXTX_REG162_EYE_T_ACCUMULATOR0_RD , 0x%x \n", FIELD_CH0_RXTX_REG162_EYE_T_ACCUMULATOR0_RD(data));
}
}

int aspm (int argc, char *argv[])
{
  int i=argc+1, j=0;
  int error=1;
  uint32_t pcie_core_id,port_type,en_lpbk=0,gen,ext_ref=1,link_width;
  uint32_t data= 0;
  uint64_t SM_ADDR_MAP_PCIE_OB_CFG_BASE;

  if (i==2)
	  pcie_core_id = atoi(argv[j++]);
  else {
	      printf("PCIE ACPM : argument error %d. Syntax: pcie_core_id port_type en_lpbk gen ext_ref link_width\n", error);
          return(error);
       }

  test_aspm(pcie_core_id);
  return 0;
}

void pipe_reg (int argc, char *argv[])
{ int op_wr = 0;
  int offset = 0;
  int wrdata = 0;
  int core_id;

    if (argc < 3){
        lprintf(3,"argument: core, w|r, reg offset, wrdata \n\r");
        return -1;
    }
    else {
        core_id = atoi(argv[0]);
        if (strncmp(argv[1],"w",1)==0) op_wr = 1;
        if (strncmp(argv[2],"0x",2)!=0) 
            offset = strtol(argv[2], NULL, 16);
        else
            offset = strtol(argv[2], NULL, 0);
        
        if(argc>3)
            if (strncmp(argv[3],"0x",2)!=0) 
                wrdata = strtol(argv[3], NULL, 16);
            else
                wrdata = strtol(argv[3], NULL, 0);
 
    }
   if(op_wr)
     pcie_phy_csr_write(core_id, offset | 0x10000, wrdata);
   else
     printf("offset 0x%x, data 0x%x \n\r", offset,  pcie_phy_csr_read(core_id,  offset | 0x10000));
}
  

void rxtx_reg (int argc, char *argv[])
{ int op_wr = 0;
  int offset = 0;
  int wrdata = 0;
  int lane = 0;
  int sds2 = 0;
  int core_id;
  int phy_addr;

    if (argc < 4){
        lprintf(3,"argument: core, lane, w|r, reg offset, wrdata \n\r");
        return -1;
    }
    else {
        core_id = atoi(argv[0]);
        lane = atoi(argv[1]);
        if (strncmp(argv[2],"w",1)==0) op_wr = 1;
        if (strncmp(argv[3],"0x",2)!=0) 
            offset = strtol(argv[3], NULL, 16);
        else
            offset = strtol(argv[3], NULL, 0);
        
        if(argc>4)
            if (strncmp(argv[4],"0x",2)!=0) 
                wrdata = strtol(argv[4], NULL, 16);
            else
                wrdata = strtol(argv[4], NULL, 0);
 
    }
    if (lane >3)
        lane = lane - 4;
    if (lane > 3)
        sds2 = 0x30000;
    
    phy_addr = offset + (0x200 * lane) + sds2;
    
    if(op_wr)
      pcie_phy_csr_write(core_id, phy_addr, wrdata);
    else
      printf("obsolute address  0x%x, data 0x%x \n\r", phy_addr,  pcie_phy_csr_read(core_id,  phy_addr));
}

void cmu_reg (int argc, char *argv[])
{ int op_wr = 0;
  int offset = 0;
  int wrdata = 0;
  int sds2 = 0;
  int core_id = 0;
  int phy_addr;

    if (argc < 3){
        lprintf(3,"argument: core, sds2, w|r, reg offset, wrdata \n\r");
        return -1;
    }
    else {
        core_id = atoi(argv[0]);
        sds2 = atoi(argv[1]);
        if (strncmp(argv[2],"w",1)==0) op_wr = 1;
        if (strncmp(argv[3],"0x",2)!=0) 
            offset = strtol(argv[3], NULL, 16);
        else
            offset = strtol(argv[3], NULL, 0);
        
        if(argc>4)
            if (strncmp(argv[4],"0x",2)!=0) 
                wrdata = strtol(argv[4], NULL, 16);
            else
                wrdata = strtol(argv[4], NULL, 0);
 
    }

    if (sds2)
        phy_addr = offset + 0x30000;
    else
        phy_addr = offset;
    if(op_wr)
      pcie_phy_csr_write(core_id, phy_addr, wrdata);
    else
      printf("offset 0x%x, data 0x%x \n\r", offset,  pcie_phy_csr_read(core_id,  phy_addr));
}

static void test_aspm(unsigned int core)
{

  unsigned int pcie_core_id=core;
  uint32_t test_pattern = 1,length=2048;
  uint32_t extended_addr = 0;
  uint32_t test_name=15;

  printf(" Active State Power Management (ASPM) On %d \n\r",core);

  sm_pcie_test_rc(pcie_core_id,
		          test_name,
		          test_pattern,
		          length,
		          extended_addr );
}

int dump_pcie_err_sub(int pcie_core_id){
  printf("RP_STATUS_31_0     0x%x \n\r",  pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_RP_STATUS_RP_STATUS_31_0__ADDR));
  printf("RP_STATUS_63_32    0x%x \n\r",  pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_RP_STATUS_RP_STATUS_63_32__ADDR));
  printf("PCIE_status_63_32  0x%x \n\r", pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_63_32__ADDR));
  printf("PCIE_status_95_64  0x%x \n\r", pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_95_64__ADDR));
  printf("PCIE_status_127_96 0x%x \n\r", pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_EXPRESSO_PCIE_STATUS_PCIE_STATUS_127_96__ADDR));
}

int dump_err(int argc, char *argv[]){
u32 val, pin, core_id;
    
if (argc < 1){
    lprintf(3,"argument: core_id\n\r");
    return -1;
}
else
    core_id = atoi(argv[0]);
    dump_pcie_err_sub(core_id);
}


int gpiods_set(int argc, char *argv[]){
u32 val, pin;
    
if (argc < 1){
    lprintf(3,"argument: pin# \n\r");
    return -1;
}
else
    pin = atoi(argv[0]);

    gpiods_set_sub(pin);
}

int gpiods_clr(int argc, char *argv[]){
u32 val, pin;

if (argc < 1){
    lprintf(5,"argument: pin# \n\r");
    return -1;
}
else
    pin = atoi(argv[0]);

    gpiods_clr_sub(pin);
}

int latch_dump(int argc, char *argv[]){
u32 val, pin, core_id;
    
if (argc < 1){
    lprintf(3,"argument: core_id\n\r");
    return -1;
}
else
    core_id = atoi(argv[0]);
    
	if (core_id == 0 || core_id == 3){
		dump_latch_sub(core_id, 0, 0);
		dump_latch_sub(core_id, 1, 0);
		dump_latch_sub(core_id, 2, 0);
		dump_latch_sub(core_id, 3, 0);
		dump_latch_sub(core_id, 0, 1);
		dump_latch_sub(core_id, 1, 1);
		dump_latch_sub(core_id, 2, 1);
		dump_latch_sub(core_id, 3, 1);
	} else if (core_id == 2) {
		dump_latch_sub(core_id, 0, 0);
	} else if (core_id == 1 || core_id == 4){
		dump_latch_sub(core_id, 0, 0);
		dump_latch_sub(core_id, 1, 0);
		dump_latch_sub(core_id, 2, 0);
		dump_latch_sub(core_id, 3, 0);
	}
}


int dump_latch_sub(int pcie_core_id, int ch, int sds2){
int sds2_offset;

	if(sds2)
        sds2_offset = 0x30000;
    else 
        sds2_offset = 0;
 
    printf("SUMMER 0x%x \n", FIELD_CH0_RXTX_REG14_CLTE_LATCAL_MAN_PROG_RD( pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG14__ADDR + (0x200 * ch) + sds2_offset)));
    
    printf("do = 0x%x de = 0x%x...\n\r", FIELD_CH0_RXTX_REG127_DO_LATCH_MANCAL_RD(pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * ch) + sds2_offset)),
	                                     FIELD_CH0_RXTX_REG129_DE_LATCH_MANCAL_RD(pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG129__ADDR + (0x200 * ch) + sds2_offset)));

    printf("eo = 0x%x ee = 0x%x...\n\r", FIELD_CH0_RXTX_REG128_EO_LATCH_MANCAL_RD(pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG128__ADDR + (0x200 * ch) + sds2_offset)),
	                                     FIELD_CH0_RXTX_REG130_EE_LATCH_MANCAL_RD(pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG130__ADDR + (0x200 * ch) + sds2_offset)));
    
	printf("xo = 0x%x xe = 0x%x...\n\r", FIELD_CH0_RXTX_REG127_XO_LATCH_MANCAL_RD(pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG127__ADDR + (0x200 * ch) + sds2_offset)),
	                                     FIELD_CH0_RXTX_REG129_XE_LATCH_MANCAL_RD(pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG129__ADDR + (0x200 * ch) + sds2_offset)));

    printf("so = 0x%x se = 0x%x...\n\r", FIELD_CH0_RXTX_REG128_SO_LATCH_MANCAL_RD(pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG128__ADDR + (0x200 * ch) + sds2_offset)),
	                                     FIELD_CH0_RXTX_REG130_SE_LATCH_MANCAL_RD(pcie_phy_csr_read(pcie_core_id, KC_SERDES_X4_RXTX_REGS_CH0_RXTX_REG130__ADDR + (0x200 * ch) + sds2_offset)));
}


