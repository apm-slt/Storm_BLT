//Tinh-SLT
#include "../include/pcie_ib_test.h"
//end of Tinh-SLT
#define COHERENCY_ENABLE 0xF0000000

uint64_t ret_pim_base(uint32_t pcie_core_id) {
  uint64_t PCIE_PIM;

  switch(pcie_core_id) {
    case 0: PCIE_PIM = PCIE_0_PIM;
            break;

    case 1: PCIE_PIM = PCIE_1_PIM;
            break;

    case 2: PCIE_PIM = PCIE_2_PIM;
            break;

    case 3: PCIE_PIM = PCIE_3_PIM;
            break;

    case 4: PCIE_PIM = PCIE_4_PIM;
            break;
  }

  return PCIE_PIM;
}

uint64_t ret_pim1_base(uint32_t pcie_core_id) {
  uint64_t PCIE_PIM;
  uint64_t PCIE_PIM1;

  PCIE_PIM = ret_pim_base(pcie_core_id);
  PCIE_PIM1= PCIE_PIM + (uint64_t) PCIE_PIM1_OFFSET;
  lprintf(5,"Virtual Addr PIM1=0x%x",PCIE_PIM1);
  return PCIE_PIM1;
}

uint64_t ret_pim2_base(uint32_t pcie_core_id) {
  uint64_t PCIE_PIM;
  uint64_t PCIE_PIM2;

  PCIE_PIM = ret_pim_base(pcie_core_id);
  PCIE_PIM2 = PCIE_PIM + (uint64_t) PCIE_PIM2_OFFSET;
  lprintf(5,"Virtual Addr PIM2=0x%x",PCIE_PIM2);
  return PCIE_PIM2;
}

uint64_t ret_pim3_base(uint32_t pcie_core_id) {
  uint64_t PCIE_PIM;
  uint64_t PCIE_PIM3;

  PCIE_PIM = ret_pim_base(pcie_core_id);
  PCIE_PIM3= PCIE_PIM + (uint64_t) PCIE_PIM3_OFFSET;
  lprintf(5,"Virtual Addr PIM3=0x%x",PCIE_PIM3);
  return PCIE_PIM3;
}


uint64_t ret_pim_base_pa(uint32_t pcie_core_id) {
  uint64_t PCIE_PIM;

  switch(pcie_core_id) {
    case 0: PCIE_PIM = PCIE_0_PIM_PA;
            break;

    case 1: PCIE_PIM = PCIE_1_PIM_PA;
            break;

    case 2: PCIE_PIM = PCIE_2_PIM_PA;
            break;

    case 3: PCIE_PIM = PCIE_3_PIM_PA;
            break;

    case 4: PCIE_PIM = PCIE_4_PIM_PA;
            break;
  }

  return PCIE_PIM;
}


uint64_t ret_pim1_base_pa(uint32_t pcie_core_id) {
  uint64_t PCIE_PIM;
  uint64_t PCIE_PIM1;

  PCIE_PIM = ret_pim_base_pa(pcie_core_id);
  PCIE_PIM1= PCIE_PIM + (uint64_t) PCIE_PIM1_OFFSET;
  lprintf(5,"Physical Addr PIM1=0x%x",PCIE_PIM1);
  return PCIE_PIM1;
}

uint64_t ret_pim2_base_pa(uint32_t pcie_core_id) {
  uint64_t PCIE_PIM;
  uint64_t PCIE_PIM2;

  PCIE_PIM = ret_pim_base_pa(pcie_core_id);
  PCIE_PIM2 = PCIE_PIM + (uint64_t) PCIE_PIM2_OFFSET;
  lprintf(5,"Physical Addr PIM2=0x%x",PCIE_PIM2);
  return PCIE_PIM2;
}

uint64_t ret_pim3_base_pa(uint32_t pcie_core_id) {
  uint64_t PCIE_PIM;
  uint64_t PCIE_PIM3;

  PCIE_PIM = ret_pim_base_pa(pcie_core_id);
  PCIE_PIM3= PCIE_PIM + (uint64_t) PCIE_PIM3_OFFSET;
  lprintf(5,"Physical Addr PIM3=0x%x",PCIE_PIM3);
  return PCIE_PIM3;
}

void config_ib_regs(uint32_t pcie_core_id, uint32_t port_type) {
  uint32_t data;
  uint32_t ib_bar0_mask, ib_bar1_mask;
  uint32_t ib_bar2_mask, ib_bar3_mask;
  uint32_t ib_bar4_mask, ib_bar5_mask;
  uint32_t mps;
  uint64_t PCIE_PIM1, PCIE_PIM2, PCIE_PIM3;

  PCIE_PIM1 = (uint64_t)ret_pim1_base_pa(pcie_core_id);
  PCIE_PIM2 = (uint64_t)ret_pim2_base_pa(pcie_core_id);
  PCIE_PIM3 = (uint64_t)ret_pim3_base_pa(pcie_core_id);
  
  lprintf(5," PIM1 0x%x \n PIM2 0x%x PIM3 0x%x \n \r",PCIE_PIM1,PCIE_PIM2,PCIE_PIM3 );
  mps = extract_max_payload_size(pcie_core_id);

  //lprintf(5,"Enabling the MSI-X capabilities\n\r");
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_447_416__ADDR));
  data = data & ~FIELD_EXPRESSO_CFG_CONTROL_CFG_CONTROL_447_416_CFG_CONTROL_MSI_CAPABILITY_DISABLE_MASK;
  data = data & ~FIELD_EXPRESSO_CFG_CONTROL_CFG_CONTROL_447_416_CFG_CONTROL_MSI_X_CAPABILITY_DISABLE_MASK;
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_447_416__ADDR), data);

  //lprintf(5,"Starting inbound registers configuration\n\r");

  ib_bar1_mask = 0x00000000; ib_bar0_mask = 0xF0000000;
  ib_bar3_mask = 0x00000000; ib_bar2_mask = 0xFF800000;
  ib_bar5_mask = 0x00000000; ib_bar4_mask = 0xF0000000;

  // Enable this settings for BAR0-64/ BAR-4 as 64 bit
  /* Ref.bug :[Bug 38228]
   *[Bug 38228] STORM Ax post-silicon: PCIE : when BAR0-1 and BAR4-5 is 64bit mode BAR4 to PIM3 translation doesn't work

   ib_bar1_mask = 0xFFFFFFFF; ib_bar0_mask = 0xF000000c;
   ib_bar3_mask = 0x00000000; ib_bar2_mask = 0xFF800000;
   ib_bar5_mask = 0xFFFFFFFF; ib_bar4_mask = 0xF000000c;
 */

  lprintf(5,"Initial max payload size configuration to "); putnum_pcie(128 << mps); lprintf(5,"B\n\r");
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_63_32__ADDR));
  data = data & ~FIELD_EXPRESSO_CFG_CONTROL_CFG_CONTROL_63_32_CFG_CONTROL_PCIE_DEV_CAP_MAX_PAYLOAD_SIZE_SUPPORTED_MASK;
  data = data | mps; 
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_63_32__ADDR), data); 

  //lprintf(5,"################################################################\n\r");
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_159_128__ADDR));
  //lprintf(5,"Initial bar 0 mask configuration\n\r");
  data = data & ~FIELD_NWL_PCIE_DMA_CFG_CONSTANTS_159_128_BASE_ADDRESS_CFG0_R0_MASK;
  data = data | (ib_bar0_mask << 16);
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_159_128__ADDR), data); 

  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_191_160__ADDR));
  //lprintf(5,"Initial bar 1 & 0 mask configuration\n\r");
  data = data & ~FIELD_NWL_PCIE_DMA_CFG_CONSTANTS_191_160_BASE_ADDRESS_CFG0_R1_MASK;
  data = data & ~FIELD_NWL_PCIE_DMA_CFG_CONSTANTS_191_160_BASE_ADDRESS_CFG1_R0_MASK;

  data = data | (ib_bar0_mask >> 16);
  data = data | (ib_bar1_mask << 16);
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_191_160__ADDR), data); 
  //lprintf(5,"bar 0 configuration (mask) programmed\n\r");
  //lprintf(5,"################################################################\n\r");
  
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_223_192__ADDR));
  //lprintf(5,"Initial bar 1 & 2 mask configuration \n\r");
  data = data & ~FIELD_NWL_PCIE_DMA_CFG_CONSTANTS_223_192_BASE_ADDRESS_CFG1_R1_MASK;
  data = data & ~FIELD_NWL_PCIE_DMA_CFG_CONSTANTS_223_192_BASE_ADDRESS_CFG2_R0_MASK;

  data = data | (ib_bar1_mask >> 16);

  if(port_type == EP)
    data = data | (ib_bar2_mask << 16);

  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_223_192__ADDR), data); 
  //lprintf(5,"bar 1 & 2 (mask) configuration programmed\n\r");
  //lprintf(5,"################################################################\n\r");
  
  if(port_type == EP) {
    data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_255_224__ADDR));
    //lprintf(5,"Initial bar 2 & 3 mask configuration \n\r");
    data = data & ~FIELD_NWL_PCIE_DMA_CFG_CONSTANTS_255_224_BASE_ADDRESS_CFG2_R1_MASK;
    data = data & ~FIELD_NWL_PCIE_DMA_CFG_CONSTANTS_255_224_BASE_ADDRESS_CFG3_R0_MASK;

    data = data | (ib_bar2_mask >> 16);
    data = data | (ib_bar3_mask << 16);
    pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_255_224__ADDR), data); 
    //lprintf(5,"bar 2 & 3 (mask) configuration programmed\n\r");
    //lprintf(5,"################################################################\n\r");
    
    data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_287_256__ADDR));
    //lprintf(5,"Initial bar 3 & 4 mask configuration \n\r");
    data = data & ~FIELD_NWL_PCIE_DMA_CFG_CONSTANTS_287_256_BASE_ADDRESS_CFG3_R1_MASK;
    data = data & ~FIELD_NWL_PCIE_DMA_CFG_CONSTANTS_287_256_BASE_ADDRESS_CFG4_R0_MASK;

    data = data | (ib_bar3_mask >> 16);
    data = data | (ib_bar4_mask << 16);
    pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_287_256__ADDR), data); 
    //lprintf(5,"bar 3 & 4 (mask) configuration programmed\n\r");
    //lprintf(5,"################################################################\n\r");
    
    data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_319_288__ADDR));
    //lprintf(5,"Initial bar 4 & 5 mask configuration \n\r");
    data = data & ~FIELD_NWL_PCIE_DMA_CFG_CONSTANTS_319_288_BASE_ADDRESS_CFG4_R1_MASK;
    data = data & ~FIELD_NWL_PCIE_DMA_CFG_CONSTANTS_319_288_BASE_ADDRESS_CFG5_R0_MASK;

    data = data | (ib_bar4_mask >> 16);
    data = data | (ib_bar5_mask << 16);  
    pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_319_288__ADDR), data); 
    //lprintf(5,"bar 4 & 5 (mask) configuration programmed\n\r");
    //lprintf(5,"################################################################\n\r");
  }
  else {
    //lprintf(5,"Setting IBAR2 and 3 masks for RC\n\r");

    data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_IR2MSK__ADDR);

    data = (ib_bar2_mask & FIELD_IR2MSK_BAM_MASK);
    data |= FIELD_IR2MSK_VAL_MASK; // set the valid bit.

    pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_IR2MSK__ADDR, data);

    data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_IR3MSKH__ADDR);

    data = (ib_bar5_mask & FIELD_IR3MSKH_BAMH_MASK);

    pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_IR3MSKH__ADDR, data);    

    data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_IR3MSKL__ADDR);

    data = (ib_bar4_mask & FIELD_IR3MSKL_BAML_MASK);
    data |= FIELD_IR3MSKL_VAL_MASK;

    pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_IR3MSKL__ADDR, data);
  }

  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_351_320__ADDR));
  //lprintf(5,"Initial bar 5 & EROM bar mask configuration \n\r");
  data = data & ~FIELD_NWL_PCIE_DMA_CFG_CONSTANTS_351_320_BASE_ADDRESS_CFG5_R1_MASK;
  data = data & ~FIELD_NWL_PCIE_DMA_CFG_CONSTANTS_351_320_EXPANSION_ROM_CFG_R0_MASK;

  if(port_type == EP)
    data = data | (ib_bar5_mask >> 16);
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_351_320__ADDR), data); 
  //lprintf(5,"bar 5 & EROM bar mask configuration programmed\n\r");
  //lprintf(5,"################################################################\n\r");
  
  data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR));
  //lprintf(5,"Initial EROM bar mask configuration \n\r");
  
  data = data & ~FIELD_NWL_PCIE_DMA_CFG_CONSTANTS_383_352_EXPANSION_ROM_CFG_R1_MASK;
  pcie_csr_write(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONSTANTS_CFG_CONSTANTS_383_352__ADDR), data); 
  //lprintf(5,"EROM bar disabled\n\r");
  //lprintf(5,"################################################################\n\r");
  
  data = (uint32_t )(PCIE_PIM1_SIZE >> 32);
  //lprintf(5,"Configuring SM_PCIE_CSR_REGS_PIM1SH__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIM1SH__ADDR,data);
  
  data = (uint32_t )PCIE_PIM1_SIZE;
  //lprintf(5,"Configuring SM_PCIE_CSR_REGS_PIM1SL__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIM1SL__ADDR,data);
  
  data = (uint32_t )PCIE_PIM1;
 // lprintf(5,"Configuring SM_PCIE_CSR_REGS_PIM1_1L__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIM1_1L__ADDR,data);
  
  data = (uint32_t )(PCIE_PIM1 >> 32);
  data |= COHERENCY_ENABLE;
  //lprintf(5,"Configuring SM_PCIE_CSR_REGS_PIM1_1H__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIM1_1H__ADDR,data);
  
  data = (uint32_t )PCIE_PIM1;
  //lprintf(5,"Configuring SM_PCIE_CSR_REGS_PIM1_2L__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIM1_2L__ADDR,data);
  
  data = (uint32_t )(PCIE_PIM1 >> 32);
  data |= COHERENCY_ENABLE;
  //lprintf(5,"Configuring SM_PCIE_CSR_REGS_PIM1_2H__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIM1_2H__ADDR,data);
  
  data = (uint32_t )PCIE_PIM2;
  //lprintf(5,"Configuring SM_PCIE_CSR_REGS_PIM2_1L__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIM2_1L__ADDR,data);
  
  data = (uint32_t )(PCIE_PIM2 >> 32);
  data |= COHERENCY_ENABLE;
  //lprintf(5,"Configuring SM_PCIE_CSR_REGS_PIM2_1H__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIM2_1H__ADDR,data);
  
  data = (uint32_t )PCIE_PIM2;
  //lprintf(5,"Configuring SM_PCIE_CSR_REGS_PIM2_2L__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIM2_2L__ADDR,data);
  
  data = (uint32_t )(PCIE_PIM2 >> 32);
  data |= COHERENCY_ENABLE;
  //lprintf(5,"Configuring SM_PCIE_CSR_REGS_PIM2_2H__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIM2_2H__ADDR,data);
  
  data = (uint32_t )PCIE_PIM2_SIZE;
 // lprintf(5,"Configuring SM_PCIE_CSR_REGS_PIM2S__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIM2S__ADDR,data);
  
  data = (uint32_t )PCIE_PIM3;
  //lprintf(5,"Configuring SM_PCIE_CSR_REGS_PIM3_1L__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIM3_1L__ADDR,data);
  
  data = (uint32_t )(PCIE_PIM3 >> 32);
  data |= COHERENCY_ENABLE;
  //lprintf(5,"Configuring SM_PCIE_CSR_REGS_PIM3_1H__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIM3_1H__ADDR,data);
  
  data = (uint32_t )PCIE_PIM3;
 // lprintf(5,"Configuring SM_PCIE_CSR_REGS_PIM3_2L__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIM3_2L__ADDR,data);
  
  data = (uint32_t )(PCIE_PIM3 >> 32);
  data |= COHERENCY_ENABLE;
  //lprintf(5,"Configuring SM_PCIE_CSR_REGS_PIM3_2H__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIM3_2H__ADDR,data);
  
  data = (uint32_t )PCIE_PIM3_SIZE;
  //lprintf(5,"Configuring SM_PCIE_CSR_REGS_PIM3SL__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIM3SL__ADDR,data);
  
  data = (uint32_t )(PCIE_PIM3_SIZE >> 32);
  //lprintf(5,"Configuring SM_PCIE_CSR_REGS_PIM3SH__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIM3SH__ADDR,data);
  
  data = 0;
  //lprintf(5,"Configuring SM_PCIE_CSR_REGS_PIM4L__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIM4L__ADDR,data);
  
  data = 0;
  data |= COHERENCY_ENABLE;
  //lprintf(5,"Configuring SM_PCIE_CSR_REGS_PIM4H__ADDR reg with "); putnum(data); lprintf(5,"\n\r");
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIM4H__ADDR,data);


  data = pcie_csr_read(pcie_core_id,SM_PCIE_CSR_REGS_BUSCTLREG__ADDR);
  data|=0x20000; 
  pcie_csr_write(pcie_core_id,SM_PCIE_CSR_REGS_BUSCTLREG__ADDR,data);
  lprintf( " BUSCTRL__REG := 0x%x \n\r",pcie_csr_read(pcie_core_id,SM_PCIE_CSR_REGS_BUSCTLREG__ADDR));
  //lprintf(5,"Finished inbound registers configuration\n\r");
}

void sm_pcie_setup_rc_bars(uint32_t pcie_core_id) {
  uint32_t data;
  //lprintf(5,"Programming the BARs for RC mode\n\r");

  data = (uint32_t) RC_BAR0;
  pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_BAR0__ADDR, data);

  data = ((uint64_t)RC_BAR0) >> 32;
  pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_BAR1__ADDR, data);

  data = (uint32_t) RC_BAR2;
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_IBAR2__ADDR, data);

  data = (uint32_t) RC_BAR4;
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_IBAR3L__ADDR, data);

  data = ((uint64_t)RC_BAR4) >> 32;
  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_IBAR3H__ADDR, data);

  //lprintf(5,"Finished programming the BARs for RC mode\n\r");
}  
