//Tinh-SLT
#include "../include/pcie_base_test.h"
//End of Tinh-SLT
#include "armv8.h"
#include <common.h>
#define DEBUG 1
extern void Config_AER(uint32_t rc_slot);
extern void Config_AER_EP(uint32_t ep_slot);
uint32_t WR_BW_g=0,RD_BW_g=0;
extern struct error_log itr_summ;

#ifdef STRESS_TEST
extern uint32_t Stress_TestOnGng ;
#endif

void Cfg_MSI_AddrData(pcie_core_id);
// Initialize the memory
void init_memory(uint64_t addr, uint32_t length, uint32_t test_pattern) {
  uint32_t wr_data;
  uint32_t i;
  uint32_t addr_pattern = 0;

  switch(test_pattern){
    case 0 : lprintf(5,"Initializing the memory with the addr itself\n\r");
             addr_pattern = 1;
             break;

    case 1 : lprintf(5,"Initializing the memory with all 5s data pattern\n\r");
             wr_data = 0x55555555;
             break;

    case 2 : lprintf(5,"Initializing the memory with all A's data pattern\n\r");
             wr_data = 0xAAAAAAAA;
             break;             

    case 3 : lprintf(5,"Initializing the memory with all 1s data pattern\n\r");
             wr_data = 0xFFFFFFFF;
             break;

    default : lprintf(5," Fill Memory locations with test pattern");putnum_pcie(test_pattern);lprintf(5,"\n\r");
             wr_data = test_pattern;             
             break;             

  }
  
#ifndef DBG_3
  lprintf(5,"****  MEMORY INITIALIZATION **** \n\r");
  lprintf(5," Address : 0x%lx\n\r",addr);
  lprintf(5,"Length: ");putnum_pcie(length);lprintf(5,"\n\r");

  for(i = 0; i < length; ) {
    if(addr_pattern) {
       wr_data = (addr & 0xFF);
       wr_data |= ((addr + 1) & 0xFF)<<8; 
       wr_data |= ((addr + 2) & 0xFF)<<16; 
       wr_data |= ((addr + 3) & 0xFF)<<24; 
    }  
    cpu_write(addr, wr_data);
    addr = addr + 4;
    i = i + 4;
  }
#endif

};

// Compare memory vs test pattern
uint32_t compare_memory(uint64_t addr, uint32_t length, uint32_t test_pattern){
  uint32_t data = 0,lnk_status;
  uint32_t exp_data;
  uint32_t i;
  uint32_t err = 0;
  uint32_t addr_pattern = 0;
  uint64_t start_addr =addr;

 #if 1
  
  switch(test_pattern){
    case 0 : lprintf(5,"expecting memory pattern : addr itself\n\r");
             addr_pattern = 1;
             break;

    case 1 : lprintf(5,"expecting memory pattern : all 5s \n\r");
             exp_data = 0x55555555;
             break;

    case 2 : lprintf(5,"expecting memory pattern : all A's\n\r");
             exp_data = 0xAAAAAAAA;
             break;             

    case 3 : lprintf(5,"expecting memory pattern: all 1s \n\r");
             exp_data = 0xFFFFFFFF;
             break; 
    default :lprintf(5,"expecting memory pattern 0x:%lx \n\r",test_pattern); 
             exp_data = test_pattern;                   

  }


//  data_cache_flush_all();

  lprintf(5,"Comparing the memory at 0x%lx, length 0x%x against the test pattern 0x%lx - \n", addr, length, test_pattern);
  for(i = 0; i < length; ) {
    if(addr_pattern) {
      exp_data = (addr & 0xFF);
      exp_data |= ((addr + 1) & 0xFF)<<8; 
      exp_data |= ((addr + 2) & 0xFF)<<16; 
      exp_data |= ((addr + 3) & 0xFF)<<24; 
    }
    data = cpu_read(addr);
    
    if(data != exp_data)
    {
      err++;
   //   lprintf(5,"Wrong data = 0x%x \n\r @Addrees =0x%x \n\r",data,addr);
    }
    addr = addr + 4;
    i = i + 4;
  }
  if(err)
    lprintf(3,"TEST FAIL Err/Tot <0x%x/0x%x> \n\r",err,length);
  else
    lprintf(3,"TEST PASSED\n\r");

#ifdef STRESS_TEST
// Clear Memory for next iteration
  init_memory(start_addr, length, 0xFFFFFFFF);
#endif  


  return (err != 0);
#endif
//return(0);
};

uint32_t sm_pcie_poll_go_ahead(uint32_t pcie_core_id) {
  volatile uint32_t data;
  uint32_t msg_data,count=1000;
   
  data = 0;
  lprintf(5,"waiting vendor defined message\n\r");
  do{
    data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_RXMESSAGESTATUSREG__ADDR);
  //  count --;
  //  if(count==0)
  //  break;	
  }while((data & FIELD_RXMESSAGESTATUSREG_RXMESSAGEVALID_MASK) != FIELD_RXMESSAGESTATUSREG_RXMESSAGEVALID_MASK);
 
  msg_data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_MESSAGEDATA4__ADDR);

  data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_RXMESSAGESTATUSREG__ADDR);

  data |= FIELD_RXMESSAGESTATUSREG_MSG_FIFO_INCR_RD_PTR_MASK;

  pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_RXMESSAGESTATUSREG__ADDR, data);
  
  lprintf(5,"received vendor defined message 0x%x \n\r", msg_data);
  return msg_data;
};  

uint32_t sm_pcie_chk_eq_result(uint32_t pcie_core_id) {
  uint32_t data;

//  data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_LINK_CTRL_2__ADDR);
  data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_LINK_CTRL_2__ADDR);
  data = (data & 0x00ff0000) >>16;

  if(data == 0x1e)
    return 1;
  else
    return 0;
};  

uint32_t gen_test_sig(uint32_t test_name, uint32_t test_pattern, uint32_t length, uint32_t extended_addr) {
  uint32_t test_sig;

  test_sig = 1;
  test_sig |= (test_name << 1);
  test_sig |= (test_pattern << 5);
  test_sig |= (length << 7);
  test_sig |= (extended_addr << 31);

  return test_sig;
}

void sm_pcie_clear_ep_test_sig(uint32_t pcie_core_id) {
  uint64_t PCIE_PIM2;
  uint64_t addr;

  PCIE_PIM2 = (uint64_t)ret_pim2_base(pcie_core_id);
  lprintf(5,"Clearing the TEST_LOC in PIM2 @ 0x%x\n\r",PCIE_PIM2);
  addr = PCIE_PIM2+TEST_LOC;

  cpu_write(addr, 0);
}

uint64_t EP_BAR_AXI_ADDR[6];

uint32_t sm_pcie_test_rc(uint32_t pcie_core_id, uint32_t test_name, uint32_t test_pattern, uint32_t length, uint32_t extended_addr) {
  uint32_t data, len,itr,cap_address=0,lnk_status=0;
  uint64_t start_addr;
  uint32_t result = 0, fail = 0;
  uint32_t src_axi;
  uint32_t dst_axi;
  uint32_t mult_ch;
  uint32_t intlv;
  uint64_t PCIE_OMR;
  static uint64_t PCIE_PIM1, PCIE_PIM1_PA;
  static uint64_t PCIE_PIM3;
  uint32_t success;
  struct ep_bar ep_bars[6];
  static uint64_t EP_BAR0, EP_BAR2, EP_BAR4;
  uint64_t offset;
  uint32_t i, test_sig, mps;
  uint32_t ASPMSupported=0,pwr_dwn,linkup;
  uint32_t total_q=0;
  uint32_t full_duplx=0;

#ifdef STRESS_TEST
if( ! Stress_TestOnGng)
#endif
{
  sm_pcie_setup_ob_cfg(pcie_core_id, RC);             
  sm_pcie_setup_ob_space(pcie_core_id, RC);             

  extended_addr=0;
  
#ifdef PCIE_EXERCISER
  test_name=3   ;                                     // Only for exerciser to execute sepcific test
  length=0x80000;
#endif

//  MSDELAY(1000);
  success = sm_pcie_chk_eq_result(pcie_core_id);
  if(success)
  {
	lprintf(5,"Equalization successful\n\r");	
#ifdef STRESS_TEST
    itr_summ.eq_status=0;                              // Applicable for link stress test
#endif
  }
  else 
  {
	lprintf(5,"Equalization failed\n\r");
#ifdef STRESS_TEST
    itr_summ.eq_status=1;
#endif

  }
#ifndef SIMULATION
  // Exerciser needs to send vendor defined message indicating that it is ready for the enumeration.
  #ifdef PCIE_EXERCISER

    data = sm_pcie_poll_go_ahead(pcie_core_id);
  #endif
#endif

  sm_pcie_enum_ep(pcie_core_id, ep_bars);
 
  lprintf(5,"Programming the max payload size for EP\n\r");
  data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_CTRL__ADDR);
  data &= 0xFFFFFF1F;
  mps = extract_max_payload_size(pcie_core_id);
  data = data | (mps << 5);


#ifdef DBG_1
  data = data | ( (mps+1) << 12 );
#endif
  pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_CTRL__ADDR, data);

  sm_pcie_setup_rc_bars(pcie_core_id);   

  for(i = 0; i < 6; i++){
    EP_BAR_AXI_ADDR[i] = 0;

    if(ep_bars[i].valid == 0)
      continue;

    switch(ep_bars[i].type){
      case 0:
        EP_BAR_AXI_ADDR[i] = ret_omr3_base(pcie_core_id);
        offset = (uint64_t ) ep_bars[i].offset;
        break;

      case 1: 
        EP_BAR_AXI_ADDR[i] = ret_omr2_base(pcie_core_id);
        offset = (uint64_t ) ep_bars[i].offset;
        break;

      case 2: 
        EP_BAR_AXI_ADDR[i] = ret_omr1_base(pcie_core_id);
        offset = (uint64_t ) ep_bars[i].offset;
        offset |= ((uint64_t ) ep_bars[i+1].offset << 32);
        break;
    }
    EP_BAR_AXI_ADDR[i] += offset;
  }

  EP_BAR0 = EP_BAR_AXI_ADDR[0];
  EP_BAR2 = EP_BAR_AXI_ADDR[2];
  EP_BAR4 = EP_BAR_AXI_ADDR[4];

  lprintf(5,"EP BAR0 0x%x \n\r EP BAR2 0x%x \n\r EP BAR4 0x%x \n\r ",EP_BAR0,EP_BAR2,EP_BAR4);

  //do cfg0 write 0x4 and set memory enable bit to indicate config process is complete to endpoint
  pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_CMD__ADDR, 0x7);
  data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_CMD__ADDR);

  // Convey the RC BAR0 location to EP, by writing to EP BAR2 offset 0xF0.
  lprintf(5,"CPU Write [0x%x] <= 0x%x\n\r", EP_BAR2 + RC_BAR0_LOC, RC_BAR0);
  data = (uint32_t ) RC_BAR0;
  cpu_write(EP_BAR2 + RC_BAR0_LOC, data);
  data = (uint32_t ) (RC_BAR0 >> 32);
  cpu_write(EP_BAR2 + RC_BAR1_LOC, data);

#ifdef EN_AER
    Config_AER(pcie_core_id);
    EnECRCGen(pcie_core_id,RC);
#ifndef PCIE_EXERCISER
    EnECRCGen(pcie_core_id,EP);
#endif
    en_event_int(pcie_core_id);
//   en_intx_int(pcie_core_id);
#endif
}    // Closing brace for not to repeat above steps for Stress test ends here.

   PCIE_PIM1 = ret_pim1_base(pcie_core_id);
   PCIE_PIM3 = ret_pim3_base(pcie_core_id);

  switch(test_name){
    case 0 : 
	         #ifdef PCIE_EXERCISER
                 // Inbound testing for RC with Exerciser Set up
	            lprintf(4,"**** INBOUND RC TEST CASE WITH PCIE_EXERCISER **** \n\r");
                 // After following message is recived by exerciser
                 // exerciser starts sending data
                cpu_write(EP_BAR2 + TEST_LOC, data);
                init_memory(PCIE_PIM1,length,0x80000001);
	            fail=0;
      	     #else

                 // Inbound testing for RC
                 // Send the 32-bit OB_PTR to EP, which EP will use to send outbound traffic from EP,
                 // which will be inbound traffic for RC.
                 data = (((uint32_t)RANDOM()) % (0x00002000)) * 4;
                 cpu_write(EP_BAR2 + OB_PTR_LOC, data);

                 lprintf(5,"Uncorrectable Error Status Register  : 0x%x \n\r",pcie_ob_cfg_read(pcie_core_id, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+4)));
                 lprintf(5,"Uncorrectable Error Mask Register  : 0x%x \n\r",pcie_ob_cfg_read(pcie_core_id, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR + 8)));
                 lprintf(5,"Uncorrectable Error Severity Register  : 0x%x \n\r",pcie_ob_cfg_read(pcie_core_id, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR + 0x0C)));
                 // Formulate the test signature and write it along with
                 // the relevant information into the EP's memory space.
                 test_sig = gen_test_sig(test_name, test_pattern, length, extended_addr);
                 lprintf(5,"RC testname=%d, pattern=%d, length=0x%x, add=0x%x sent to EP\n", test_name, test_pattern, length, extended_addr);

                 data = test_sig;
                 cpu_write(EP_BAR2 + TEST_LOC, data);
                 fail = 0;
              #endif
             break;

    case 1 : // Outbound testing for RC
             offset = (((uint32_t)RANDOM()) % (0x00002000)) * 4;
             start_addr = EP_BAR0 + offset;

             // Outbound traffic from RC means inbound traffic for EP. 
             // EP needs to be communicated the offset.
             cpu_write(EP_BAR2 + IB_PTR_LOC, offset);

             init_memory(start_addr, length, test_pattern);
             lprintf(5,"Doing outbound reads to the same addresses and comparing\n\r");
             fail = compare_memory(start_addr, length, test_pattern);

             // Formulate the test signature and write it along with 
             // the relevant information into the EP's memory space.
             test_sig = gen_test_sig(test_name, test_pattern, length, extended_addr);

             data = test_sig;
             cpu_write(EP_BAR2 + TEST_LOC, data);
             break;

    // Testcases 2-6 are for RC DMA testing.             
    case 2 : lprintf(4,"This is Single channel RC-DMA for AXI-to-PCIE (PCIE OB Write)\n\r");
             src_axi = 1;
             dst_axi = 0;
             mult_ch = 0;
             intlv   = 0;

#ifdef MULTIPLE_FILES
             total_q= MAX_FILES;
#endif

             break;

    case 3 : lprintf(4,"This is single channel RC-DMA for PCIE-to-AXI (PCIE OB Read):\n\r");
             src_axi = 0;
             dst_axi = 1;
             mult_ch = 0;
             intlv   = 0;
             break;

    case 4 : src_axi = 1;
             dst_axi = 0;
             mult_ch = 1;
             intlv   = 0;
             full_duplx=0;
             lprintf(4,"This is Multichannel RC-DMA for AXI-to-PCIE (PCIE OB Write) & FULL_DUPLEX : %d \n\r",full_duplx);
             break;

    case 5 : src_axi = 0;
             dst_axi = 1;
             mult_ch = 1;
             full_duplx=0;
             intlv   = 0;
             lprintf(4,"This is Multichannel RC-DMA for PCIE-to-AXI (PCIE OB Read) & FULL_DUPLEX : %d \n\r",full_duplx);
             break;

    case 6 : lprintf(4,"This is multichannel RC-DMA interleaved\n\r");
             src_axi = 1;
             dst_axi = 0;
             mult_ch = 1;
             intlv   = 1;
             break;             

    // Testcases 8-12 are for EP DMA testing.             
    case 8 : lprintf(4,"This is Single channel EP DMA for AXI-to-PCIE (PCIE OB Write)\n\r");
             src_axi = 1;
             dst_axi = 0;
             mult_ch = 0;
             intlv   = 0;
       //      init_memory(PCIE_PIM1,length,test_pattern);                  // Clear DDR memory location other than
                                                                          // test pattern       
             break;

    case 9 : lprintf(4,"This is single channel EP DMA for PCIE-to-AXI (PCIE OB Read) \n\r");
             src_axi = 0;
             dst_axi = 1;
             mult_ch = 0;
             intlv   = 0;
             break;

    case 10: lprintf(4,"This is multichannel EP DMA for AXI-to-PCIE (PCIE OB Write)\n\r");
             src_axi = 1;
             dst_axi = 0;
             mult_ch = 1;
             intlv   = 0;
             full_duplx=1;
             break;

    case 11: lprintf(4,"This is multichannel EP DMA for PCIE-to-AXI (PCIE OB Read)\n\r");
             src_axi = 0;
             dst_axi = 1;
             mult_ch = 1;
             intlv   = 0;
             full_duplx=1;
             break;

    case 12: lprintf(4,"This is multichannel EP DMA interleaved\n\r");
             src_axi = 1;
             dst_axi = 0;
             mult_ch = 1;
             intlv   = 1;
             break;

    case 13: lprintf(4,"Enabling the L1 power management control\n\r");

             en_l1_pwr_mgmt(pcie_core_id);
             fail=0;

             data=0x10000;
               for(i=0 ;i<= 67; i++)
               {
               // Analyse this on analyser
                 data =data + 4 ;
                 pcie_ob_cfg_read(pcie_core_id, data);
               }


             for(itr=0;itr<=10;itr++)

             {
#ifdef Dgb_38227
               lprintf(5,"Bug 38227: PIPE_REGS_LOS_PARAM @ B4L1 = 0x%x \n\r" ,
            	                     pcie_phy_csr_read(pcie_core_id, KC_PIPE_REGS_LOS_PARAM__ADDR) );
               lprintf(5,"Bug 38227: EP_CFG_STATUS_CFG_STATUS_1087_1056 @ B4L1 = 0x%x \n\r" ,
            	                     pcie_csr_read(0, NWL_PCIE_APB_REGS_EXPRESSO_CFG_STATUS_CFG_STATUS_1087_1056__ADDR) );
               lprintf(5,"Bug 38227: EP_POWERMANAGEMENTREG @ B4L1 = 0x%x  \n\r" ,
            	                     pcie_csr_read(0, SM_PCIE_CSR_REGS_POWERMANAGEMENTREG__ADDR));
#endif

             lprintf(5,"Sending the link in L1 state\n\r");
             send_link_to_l1(pcie_core_id);
             lprintf(5,"Polling to make sure link went into L1 state\n\r");
             poll_link_to_l1(pcie_core_id);
             lprintf(5,"Link went into L1 state. Will now wait for some time, before initiating wake from L1\n\r");
             for(i = 0; i < 20000; i++);

             lprintf(5,"POll from RC whether it went to L1\n\r");
             lprintf(5,"After waiting for some time, now, will wake up the system back\n\r");

//#define EN_AER_U     // Enable to test UR request scenario
#ifdef EN_AER_UR
             // generate some traffic as negative scenario of UR request
                lprintf(5,"Will generate some outbound traffic to genrate negative scenario of UR\n\r");

                offset = (((uint32_t)RANDOM()) % (0x00200000)) * 4;
                start_addr = EP_BAR0 + offset;
                init_memory(start_addr, length, test_pattern);

                // check the integrity of the EP memory.
                lprintf(5,"Doing outbound reads to the same addresses and comparing\n\r");
                fail |= compare_memory(start_addr, length, test_pattern);
#endif
 /*
             lprintf(5,"After waiting for some time, now, will wake up the system back\n\r");
             wake_frm_l1(pcie_core_id);

#ifdef Dgb_38227

              lprintf(5,"Bug 38227: PIPE_REGS_LOS_PARAM @ AfterL1 0x%x  = \n\r" ,
                                           pcie_phy_csr_read(pcie_core_id, KC_PIPE_REGS_LOS_PARAM__ADDR) );
              lprintf(5,"Bug 38227: EP_CFG_STATUS_CFG_STATUS_1087_1056 @ AfterL1 0x%x  = \n\r" ,
                                           pcie_csr_read(0, NWL_PCIE_APB_REGS_EXPRESSO_CFG_STATUS_CFG_STATUS_1087_1056__ADDR) );
              lprintf(5,"Bug 38227: EP_POWERMANAGEMENTREG @ AfterL1 0x%x = \n\r" ,
                                           pcie_csr_read(0, SM_PCIE_CSR_REGS_POWERMANAGEMENTREG__ADDR));

              data= pcie_csr_read(0, SM_PCIE_CSR_REGS_POWERMANAGEMENTREG__ADDR) ;
              pcie_csr_write(0, SM_PCIE_CSR_REGS_POWERMANAGEMENTREG__ADDR,data);

#endif

             // generate some traffic 
             lprintf(5,"Will generate some outbound traffic to make sure that the link health is good\n\r");
             offset = (((uint32_t)RANDOM()) % (0x00200000)) * 4;
             start_addr = EP_BAR0 + offset;
             init_memory(start_addr, length, test_pattern);

             // check the integrity of the EP memory.
             lprintf(5,"Doing outbound reads to the same addresses and comparing\n\r");
             fail |= compare_memory(start_addr, length, test_pattern);
*/

             }
             break;

    case 14: lprintf(5,"Enabling the L2 power management control\n\r");             
             en_l1l2_pwr_mgmt(pcie_core_id); 
             lprintf(5,"Sending the link in L2 state\n\r");
             send_link_to_l2(pcie_core_id);
             lprintf(5,"Polling to make sure link went into L2 state\n\r");
             poll_link_to_l2(pcie_core_id);

 //            wake_frm_l2(pcie_core_id,0,2,8); // bug : Bug 40236
             break;             

    case 15: lprintf(4," ##################################################################################\n\r");
             lprintf(4,"                  Support for Active State Power Management                        \n\r");
             lprintf(4," ##################################################################################\n\r");
              data=0x10000;
               for(i=0 ;i<= 67; i++)
               {
               // Analyse this on analyser
                 data =data + 4 ;
                 pcie_ob_cfg_read(pcie_core_id, data);
               }

    	     data = pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG0_PCIE_CFG0_DEV_ID__ADDR) & 0xffff ;

             lprintf(4,"  READING DEVICE ID OF DUT \n\r");
             switch(data)
             {

              case 0x15b3: lprintf(4,"  * Mellanox Technology Vendor ID 0x%x \n\r",data ); break;
              case 0x8086: lprintf(4,"  * Intel Corporation Vendor ID 0x%x\n\r",data); break;
              case 0x8087: lprintf(4,"  * Intel Vendor ID 0x%x\n\r",data); break;
              case 0x1000: lprintf(4,"  * LSI Logic Vendor ID 0x%x\n\r",data); break;
              default : lprintf(4,"     * Unknown Vendor ID 0x%x \n\r",data); break;

             }

             // Check for ASPM support

             data = pcie_ob_cfg_read(pcie_core_id,SM_PCIE_CFG0_PCIE_CFG0_CAP_PTR__ADDR);
             data |=0x0C;
             ASPMSupported=0;

             cap_address=SM_PCIE_CFG0_PCIE_CFG0_LINK_CAP__ADDR;
             cap_address &= 0xFFFFFF00;
             cap_address |= data;

             data = pcie_ob_cfg_read(pcie_core_id,cap_address);
             lprintf(5,"  * Data read from Link Cap register is 0x%x\n\r", data);
             ASPMSupported = ( ( pcie_ob_cfg_read(pcie_core_id,cap_address) ) &  0xC00 ) >> 10 ;

             switch(ASPMSupported)
             {
               case 0 : lprintf(5,"  * NO ASPM Support \n\r",data);
                        return(1);
                        break;
               case 1 : lprintf(5,"  * L0s Supported \n\r",data);   break;
               case 2 : lprintf(5,"  * L1 Supported \n\r", data);   break;
               case 3:  lprintf(5,"  * L0s and L1 Supported \n\r",data);break;
             }

             if(ASPMSupported!=3)
             {
                 lprintf(5,"Enabling ASPM in RC\n\r");
                 data = pcie_ob_cfg_read(pcie_core_id,SM_PCIE_CFG1_PCIE_CFG1_LINK_CTRL__ADDR);
                 data |= ASPMSupported;
                 pcie_ob_cfg_write(pcie_core_id,SM_PCIE_CFG1_PCIE_CFG1_LINK_CTRL__ADDR,data);
                 data = pcie_ob_cfg_read(pcie_core_id,SM_PCIE_CFG1_PCIE_CFG1_LINK_CTRL__ADDR);
                 if((data & ASPMSupported) != 0)
                   lprintf(5,"Enabled ASPM in RC\n\r");
                 else {
                   lprintf(5,"Error: Could not enable ASPM in RC. Data from link control register is = 0x%x\n\r", data);
                   fail = 1;
                 }

                 lprintf(5,"Enabling ASPM in EP\n\r");
                 data = pcie_ob_cfg_read(pcie_core_id,SM_PCIE_CFG0_PCIE_CFG0_LINK_CTRL__ADDR);
                 data |= ASPMSupported;
                 pcie_ob_cfg_write(pcie_core_id,SM_PCIE_CFG0_PCIE_CFG0_LINK_CTRL__ADDR,data);
                 data = pcie_ob_cfg_read(pcie_core_id,SM_PCIE_CFG0_PCIE_CFG0_LINK_CTRL__ADDR);
                 if((data & ASPMSupported) != 0)
                   lprintf(5,"Enabled ASPM in EP\n\r");
                 else {
                   lprintf(5,"Error: Could not enable ASPM in EP. Data from link control register is = 0x%x\n\r", data);
                   fail = 1;
                 }
             }

             else{
                if(test_pattern)  
                  lprintf(5,"Enabling ASPM L1 in RC\n\r");
                else
                  lprintf(5,"Enabling ASPM L0s in RC\n\r");

                 data = pcie_ob_cfg_read(pcie_core_id,SM_PCIE_CFG1_PCIE_CFG1_LINK_CTRL__ADDR);
                 data |= (1 << test_pattern);
                 pcie_ob_cfg_write(pcie_core_id,SM_PCIE_CFG1_PCIE_CFG1_LINK_CTRL__ADDR,data);

                if(test_pattern)  
                  lprintf(5,"Enabling ASPM L1 in EP\n\r");
                else
                  lprintf(5,"Enabling ASPM L0s in EP\n\r");

                 data = pcie_ob_cfg_read(pcie_core_id,SM_PCIE_CFG0_PCIE_CFG0_LINK_CTRL__ADDR);
                 data |= (1 << test_pattern);
                 pcie_ob_cfg_write(pcie_core_id,SM_PCIE_CFG0_PCIE_CFG0_LINK_CTRL__ADDR,data);

#ifdef BUG_40392
               MSDELAY(1000);
               MSDELAY(5000);
#endif
			   
                 MSDELAY(1);
                 ltssm_sub(pcie_core_id,lnk_status);

/*               lprintf(5,"Will generate some Outbound  to check if wakes up \n\r");

                 offset = (((uint32_t)RANDOM()) % (0x00200000)) * 4;
                 start_addr = EP_BAR0 + offset;
                 init_memory(start_addr, length, 0xBADBABAE);
                 fail |= compare_memory(start_addr, length, test_pattern);


                 ltssm_sub(pcie_core_id,lnk_status);
*/
             }

             break;
#ifdef EN_AER
    case 16 : lprintf(4,"TESTING WITH EXERCISER FOR AER \n\r ");

			lprintf(5,"PIM1_ADDR : = 0x%x \n\r",  ret_pim1_base(pcie_core_id) );
			lprintf(5,"PIM2_ADDR : = 0x%x \n\r",  ret_pim2_base(pcie_core_id) );
			lprintf(5,"PIM3_ADDR : = 0x%x \n\r",  ret_pim3_base(pcie_core_id) );

            lprintf(5,"Uncorrectable Error Status Register  : 0x%x \n\r",pcie_ob_cfg_read(pcie_core_id, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR+4)));
            lprintf(5,"Uncorrectable Error Mask Register  : 0x%x \n\r",pcie_ob_cfg_read(pcie_core_id, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR + 8)));
            lprintf(5,"Uncorrectable Error Severity Register  : 0x%x \n\r",pcie_ob_cfg_read(pcie_core_id, (SM_PCIE_CFG1_PCIE_CFG1_AER_ENH_CAP__ADDR + 0x0C)));


            // generate some traffic
#if 0       // Test for ECRC
             lprintf(5,"Will generate some Outbound  traffic ECRC ARE enabled \n\r");

             offset = (((uint32_t)RANDOM()) % (0x00200000)) * 4;
             start_addr = EP_BAR0 + offset;
             init_memory(start_addr, length, 0xBADBABAE);
             fail |= compare_memory(start_addr, length, test_pattern);

             lprintf(5,"Device Control Reg.:  : 0x%x \n\r",pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_DEV_CTRL__ADDR));
             pcie_ob_cfg_write(pcie_core_id,(SM_PCIE_CFG1_PCIE_CFG1_DEV_CTRL__ADDR),
                		                   (pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_DEV_CTRL__ADDR) | 0x8));
#endif
             break;


    case 17: lprintf(5,"Enabling MSI ISR for Termination \n\r ");

             Cfg_MSI_AddrData(pcie_core_id);
             En_MSI_ISR(pcie_core_id);

             lprintf(5,"MSI ISR are Initialized please send Message Now \n\r ");

    	     break;
#endif
    default: lprintf(5,"Please send the correct signature, for testing in RC mode.\n\r");
             break;
  }

  if(test_name >= 8 && test_name <= 12) {

    lprintf(5,"Will setup DMA of external EP\n\r");
    uint32_t test_sig;
    uint32_t src_dst;
    uint64_t element_ptr;
    uint64_t q_param_loc;
    uint64_t addr;
    uint32_t src2_axi, dst2_axi;


    if(mult_ch) {
      if(intlv == 0) {
        src2_axi = src_axi;
        dst2_axi = dst_axi;
      } else {
        src2_axi = (~src_axi & 0x1);
        dst2_axi = (~dst_axi & 0x1);
      }
    } else {
      src2_axi = 0;
      dst2_axi = 0;
    }

    if(src_axi == 0) {
      // Allocate some memory for DMA testing of channel1 in PIM1 region. 
      // Initialize the memory according to the test pattern.
      init_memory(PCIE_PIM1+DMA_SRC_AXI, length, test_pattern);
    }

    if(mult_ch) {
      if(src2_axi == 0) {
        // Allocate some memory for DMA testing of channel2 in PIM3 region. 
        // Initialize the memory according to the test pattern.
        init_memory(PCIE_PIM3+DMA_SRC_AXI, length, test_pattern);
      }
    }

    addr = RC_BAR0;
    src_dst = (src_axi == 0) ? SRC : DST;
    element_ptr = (src_axi == 0) ? (EP_BAR4 + DMA_SRC_ELE)  : (EP_BAR4 + DMA_DST_ELE);
    q_param_loc = (src_axi == 0) ? (EP_BAR2 + DMA_SRC_Q_PTR): (EP_BAR2 + DMA_DST_Q_PTR);
    // Create the DMA elements and write them @BAR4 + offset.
    setup_src_dst_elements(addr, 0, element_ptr, length, q_param_loc);

    if(mult_ch) {
      addr = RC_BAR4;
      src_dst = (src2_axi == 0) ? SRC : DST;
      element_ptr = (src2_axi == 0) ? (EP_BAR4 + DMA_SRC2_ELE)  : (EP_BAR4 + DMA_DST2_ELE);
      q_param_loc = (src2_axi == 0) ? (EP_BAR2 + DMA_SRC2_Q_PTR): (EP_BAR2 + DMA_DST2_Q_PTR);
      // Create the DMA elements and write them @BAR4 + offset.
      setup_src_dst_elements(addr, 0, element_ptr, length, q_param_loc);
    }

    // Formulate the test signature and write it along with 
    // the relevant information into the EP's memory space.
    test_sig = gen_test_sig(test_name, test_pattern, length, extended_addr);

    lprintf(5,"Test Signature to EP : 0x%x \n\r",test_sig);
    data = test_sig;
    cpu_write(EP_BAR2 + TEST_LOC, data);
    fail = 0;
  }

  if(test_name >= 2 && test_name <= 6) {
    uint64_t mem_addr;
    uint64_t dma_addr, dma_addr2;
    uint32_t src2_axi, dst2_axi;
    uint32_t i=0;

#ifdef MULTIPLE_FILES
  for(i=0;i<=total_q;i++)
#endif
  {
    if(mult_ch) {
      if(intlv == 0) {
    	  if(!full_duplx)
    	  {
    	    src2_axi = src_axi;
    	    dst2_axi = dst_axi;
    	    length = length/2;

    	  }
    	  else
    	  {
    	    src2_axi = dst_axi;
    	    dst2_axi = src_axi;
    	    length = length/2;
    	  }
      } else {
        src2_axi = (~src_axi & 0x1);
        dst2_axi = (~dst_axi & 0x1);
      }
    } else {
      src2_axi = 0;
      dst2_axi = 0;
    }

    lprintf(5,"Will do some DMA testing in RC mode \n\r");
    
    if(src_axi) {
      mem_addr = PCIE_PIM1+DMA_SRC_AXI;
    }
    else {
      if(extended_addr) 
        mem_addr = ret_omr1_base(pcie_core_id);
      else
        mem_addr = ret_omr2_base(pcie_core_id);

      mem_addr += DMA_SRC_PCIE; 
    }

    // In DMA testing, it is only source memory that needs to be initialized.
    lprintf(5,"Initializing the SRC data at addr=0x%lx, pattern=%1d\n\r", mem_addr, test_pattern);
    init_memory(mem_addr, length, test_pattern);    

    if(mult_ch) {
      if(src2_axi) {
        mem_addr = PCIE_PIM1+DMA_SRC2_AXI;
      } 
      else {
        if(extended_addr)
          mem_addr = ret_omr1_base(pcie_core_id);
      else
        mem_addr = ret_omr2_base(pcie_core_id);

      mem_addr += DMA_SRC2_PCIE;
      }
      lprintf(5,"Initializing the SRC2 data at addr=0x%lx, pattern=%1d\n\r", mem_addr, test_pattern);
      init_memory(mem_addr, length, test_pattern);
    }

    if(src_axi) {
	  PCIE_PIM1_PA = ret_pim1_base_pa(pcie_core_id);
      dma_addr = PCIE_PIM1_PA+DMA_SRC_AXI;
    }
    else {
      if(extended_addr) 
        dma_addr = PREFETCH_MEM_BASE;
      else
        dma_addr = MEM_BASE;

      dma_addr += DMA_SRC_PCIE; 
    }

    if(mult_ch) {
      if(src2_axi) {
	    PCIE_PIM1_PA = ret_pim1_base_pa(pcie_core_id);
        dma_addr2 = PCIE_PIM1_PA+DMA_SRC2_AXI;
      } 
      else {
        if(extended_addr)
          dma_addr2 = PREFETCH_MEM_BASE;
        else
          dma_addr2 = MEM_BASE;

        dma_addr2 += DMA_SRC2_PCIE;
      }
    }
    else 
      dma_addr2 = 0;

    init_dma_src_dst_elements(pcie_core_id, dma_addr, dma_addr2, src_axi, src2_axi, SRC, length);

    if(dst_axi) {
      dma_addr = PCIE_PIM1+DMA_DST_AXI;
    }
    else {
      if(extended_addr) 
        dma_addr = PREFETCH_MEM_BASE;
      else
        dma_addr = MEM_BASE;

      dma_addr += DMA_DST_PCIE; 
    }

    if(mult_ch) {
      if(dst2_axi) {
        dma_addr2 = PCIE_PIM1+DMA_DST2_AXI;
      } 
      else {
        if(extended_addr)
          dma_addr2 = PREFETCH_MEM_BASE;
        else
          dma_addr2 = MEM_BASE;

        dma_addr2 += DMA_DST2_PCIE;
      }
    }
    else 
      dma_addr2 = 0;

    init_dma_src_dst_elements(pcie_core_id, dma_addr, dma_addr2, dst_axi, dst2_axi, DST, length);
    init_dma_sta_elements(pcie_core_id, mult_ch, 1);
#ifdef PERF_MEASURMENT
if( ( (!full_duplx) && (mult_ch) ) )
{
	length=length*2;
    prep_diag_mode(pcie_core_id,length);   // Start Measurement
}
else
	prep_diag_mode(pcie_core_id,length);   // Start Measurement
#endif
  }  // end for multiple fiels to be sent
    /*
    // For DMA completion on PCIE side
    data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_PCIE_INT_AXI_PCIE_N__ADDR);
	data &= 0xFFFFFFE;
	data |=0x1;
	pcie_csr_write(pcie_core_id,NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_PCIE_INT_AXI_PCIE_N__ADDR,data);

    data = pcie_ob_cfg_read(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (0 * 0x40));
    data &= 0xFFFEFFFF;   //  Enable DMA and INT to AXI : Turn 16th to 1 only for PCIE INTx Interrupt
    pcie_ob_cfg_write(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (0 * 0x40), data);
    en_intx_int(pcie_core_id);
 */

    sm_pcie_setup_dma(pcie_core_id, src_axi, dst_axi, mult_ch, intlv);
    fail = 0;

#ifndef DMA_INT_ENABLE
    result = poll_dma_cmpl(pcie_core_id, mult_ch);

#elif !defined (PERF_2_PORTS)
   result = evt_dma_cmpl(pcie_core_id, mult_ch);
#endif

#ifndef PERF_2_PORTS

#ifdef PERF_MEASURMENT

if( (test_name==2) || (test_name==4) )
{
	if(!full_duplx)
	{
	 lprintf(5,"CFG START_STOP_STATUS := 0x%x \n\r",
	    	    pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR)));
     while( ( pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR) ) & 0x4 ));
              lprintf(5,"CFG START_STOP_STATUS := 0x%x \n\r",
     pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR)));
     print_M_AXI_WR_RD(pcie_core_id,RD);
    itr_summ.rc_wr_perf=RD_BW_g;

	}
	else
	{

	   lprintf(5,"CFG START_STOP_STATUS := 0x%x \n\r",
			   pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR)));
       while( ( pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR) ) & 0x4 ));
		       lprintf(5,"CFG START_STOP_STATUS := 0x%x \n\r",
       pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR)));
  lprintf(3, "Clock Count  := 0x%x \n\r",
  pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_STS_AXI_MRD_BW_CLK_CNT__ADDR)));
	   print_M_AXI_WR_RD(pcie_core_id,RD);
	    itr_summ.rc_wr_perf=RD_BW_g;

      lprintf(5,"CFG START_STOP_STATUS := 0x%x \n\r",
		   pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR)));
	     while( ( pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR) ) & 0x1 ));
	              lprintf(5,"CFG START_STOP_STATUS := 0x%x \n\r",
	     pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR)));
	     print_M_AXI_WR_RD(pcie_core_id,WR);

	    itr_summ.rc_wr_perf=WR_BW_g;


	}

}
else if( (test_name==3) || (test_name==5) )
{
  if(!full_duplx)
  {
   while( ( pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR) ) & 0x1 ));
    print_M_AXI_WR_RD(pcie_core_id,WR);

    itr_summ.rc_rd_perf= WR_BW_g;

  }
  else
  {

	  lprintf(5,"CFG START_STOP_STATUS := 0x%x \n\r",
               pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR)));
      while( ( pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR) ) & 0x1 ));
	  lprintf(5,"CFG START_STOP_STATUS := 0x%x \n\r",
		       pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR)));
	  print_M_AXI_WR_RD(pcie_core_id,WR);


      itr_summ.rc_wr_perf=WR_BW_g;
	  lprintf(5,"CFG START_STOP_STATUS := 0x%x \n\r",
			   pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR)));
	  while( ( pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR) ) & 0x4 ));
	  lprintf(5,"CFG START_STOP_STATUS := 0x%x \n\r",
			  pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR)));
      print_M_AXI_WR_RD(pcie_core_id,RD);

	     itr_summ.rc_wr_perf=RD_BW_g;

  }
}
#endif

#endif

    fail |= result;

    if(dst_axi) {
      mem_addr = PCIE_PIM1+DMA_DST_AXI;
    }
    else {
      if(extended_addr) 
        mem_addr = ret_omr1_base(pcie_core_id);
      else
        mem_addr = ret_omr2_base(pcie_core_id);

      mem_addr += DMA_DST_PCIE; 
    }
#ifndef BUG_37105
 lprintf(5,"Compare_memory DST addr=0x%lx, length 0x%x, pattern %1d\n\r", mem_addr, length, test_pattern);
#endif
 if(mult_ch) {
      if(!full_duplx)
      {
      	length=length/2;
      }
 }
#if !defined ( PCIE_EXERCISER) && ! defined (PERF_RC_OB_WR)   // prefer to monitor on exerciser
    result = compare_memory(mem_addr, length, test_pattern);
#endif
    fail |= result;

    if(mult_ch) {
      if(dst2_axi) {
        mem_addr = PCIE_PIM1+DMA_DST2_AXI;
      }
      else {
        if(extended_addr) 
          mem_addr = ret_omr1_base(pcie_core_id);
        else
          mem_addr = ret_omr2_base(pcie_core_id);

        mem_addr += DMA_DST2_PCIE; 
      }

      lprintf(5,"Compare_memory DST2 addr=0x%lx, length 0x%x, pattern %1d\n\r", mem_addr, length, test_pattern);
      result = compare_memory(mem_addr, length, test_pattern);
      fail |= result;
    }
  }
#ifdef PCIE_EXERCISER
  if(test_name==0)
  {


	volatile uint64_t end_pattern=0,end_id=0;

	lprintf(5,"PIM1_ADDR : = 0x%x \n\r",  ret_pim1_base(pcie_core_id) );
	lprintf(5,"PIM2_ADDR : = 0x%x \n\r",  ret_pim2_base(pcie_core_id) );
	lprintf(5,"PIM3_ADDR : = 0x%x \n\r",  ret_pim3_base(pcie_core_id) );



    // 0X718 is location from where exerciser script RC_IB_TEST.peg will start writing

    start_addr= ( ret_pim1_base(pcie_core_id) + 0x718 );

    // test_pattern= be32_to_cpu(*((uint32_t*)(start_addr)));

    test_pattern= (*((uint32_t*)(start_addr)));
    length=be16_to_cpu ( *(((uint32_t*)start_addr) + 1 ) >> 16 );
    start_addr += 8;                                                   // On 1st Address locaton we get,
                                                                       // length and pattern to be compared


    lprintf(5,"Waiting for Exerciser to Finish Write Data for Len= %d \n\r" ,length);

    do
    {
    	end_id = (ret_pim1_base(pcie_core_id) + 0x710 );
        end_pattern= cpu_read(end_id);

        lprintf(5,"End Pattern =0x%x \n\r @Add : 0x%x \n\r ",end_pattern, end_id);
    } while(end_pattern != 0x0BADCAFE);

    length=length/4;    // Length filed is in bytes comparison length in DWORDS


    result = compare_memory(start_addr, length, test_pattern);

    if(result==0)
    { 
      lprintf(5,"RC I/B WITH EXERCISER PASSED\n\r");
    }
    else
    {
      lprintf(5,"RC I/B WITH EXERCISER FAILED\n\r");
 
    }

    lprintf( "CFG START_STOP_STATUS := 0x%x \n\r",
         	    pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR)));
  }
  if(test_name==1)
  {

	  lprintf(5,"RC O/B WITH EXERCISER PLEASE VERIFY RESULT ON EXERCISER\n\r");
  }
#else
  if((result == 0) && (fail == 0))
    lprintf(5,"RC MODE TEST PASSED\n\r");
  else
    lprintf(5,"RC MODE TEST FAILED\n\r");

#endif
  return fail;
};  

void sm_pcie_test_ep(uint32_t pcie_core_id){

  uint32_t full_duplx=0;
  uint32_t valid;
  uint32_t test_name;
  uint32_t test_pattern;
  uint32_t length;
  uint32_t extended_addr;
  uint64_t addr;
  uint32_t data;
  uint64_t start_addr;
  uint32_t result, fail;
  uint32_t src_axi;
  uint32_t dst_axi;
  uint32_t mult_ch;
  uint32_t intlv;
  uint64_t PCIE_OMR1;
  uint64_t PCIE_POM1;
  uint64_t PCIE_POM2;
  uint64_t PCIE_POM3;
  uint64_t PCIE_PIM1;
  uint64_t PCIE_PIM2;
  uint64_t PCIE_PIM3;
  uint32_t rc_bar0;
  uint32_t rc_bar1;
  uint32_t i,bar_idx;
  uint32_t msg_code, msg_routing_code, msg_data;

  uint64_t cnt=0;

  PCIE_PIM1 = (uint64_t)ret_pim1_base(pcie_core_id);
  PCIE_PIM2 = (uint64_t)ret_pim2_base(pcie_core_id);
  PCIE_PIM3 = (uint64_t)ret_pim3_base(pcie_core_id);


  lprintf(5,"PCIE_PIM1=> 0x%x\n",PCIE_PIM1);
  lprintf(5,"PCIE_PIM2=> 0x%x\n",PCIE_PIM2);
  lprintf(5,"PCIE_PIM3=> 0x%x\n",PCIE_PIM3);

#ifdef PCIE_EXERCISER

  lprintf(5,"Outbound Testing With Exercsier Starts \n\r");
  lprintf(5,"Polling for the signature from external exerciser to know testing: \n\r");
  start_addr=PCIE_PIM2+TEST_LOC;
  init_memory(start_addr, 0x100, 0x11110000);   // Prepare for iteration
                                               // Test Loc =0x40 Random length  

  i = 2000000000;
  do {
      data = cpu_read(PCIE_PIM2+TEST_LOC);
      i--;
     } while( ( (data & 0x1) != 1 ) && (i)  );

  if (i)
  {
    lprintf(5,"TEST SIGN =>0x%x\n", cpu_read(PCIE_PIM2+TEST_LOC));
	start_addr=PCIE_PIM2+TEST_LOC;

	test_name = (data & 0xff000000) >> 24;
   // test_pattern=be32_to_cpu ( *(((uint32_t*)start_addr) + 1 )  );
	test_name=3;
	test_pattern= ( *(((uint32_t*)start_addr) + 1 )  );
	length=be32_to_cpu ( *(((uint32_t*)start_addr) + 2 )  );


	lprintf(5,"TEST NAME =>%d\n",  test_name);
	lprintf(5,"TEST PATTERN TO SEND.=>0x%x\n", test_pattern);
	lprintf(5,"TEST LENGTH. =>%d\n", length);

  }
  else
  {
    lprintf(5,"TEST CASE DETAILS NOT RECEIVED :TIME OUT.\n\r");
    lprintf(5,"Use Script : EP_MODE_TEST.peg & Debug \n\r");
    return(0);
  }

#else
  lprintf(5,"Polling for the signature from external RC to know testing: ");
  i = 2000000;
  do {
    data = cpu_read(PCIE_PIM2+TEST_LOC);
#ifdef SIMULATION
    sm_host_delay_ns(1000);
#endif
  } while(!(data & 1)&&(--i));
  if (i) 
  {
	lprintf(5,"Pass! [0x%x]=>0x%x\n", PCIE_PIM2+TEST_LOC, data);
#ifdef STRESS_TEST	
	cpu_write((PCIE_PIM2+TEST_LOC),0);
#endif 
  }
  else
      lprintf(5,"Failed.\n");
  
  test_name = (data & 0x1E) >> 1;
  test_pattern = (data & 0x60) >> 5;
  length = (data & 0x7FFFFF80) >> 7;

#ifdef STRESS_TEST
  length=STRESS_TEST_LEN;              // Gen_sig needs modification so temp fix

#endif
  extended_addr = (data & 0x80000000) >> 31;
  lprintf(5,"TEST NAME =>%d\n",  test_name);
  lprintf(5,"TEST PATTERN TO SEND.=>0x%x\n", test_pattern);
  lprintf(5,"TEST LENGTH. =>0x%x\n", length);
#endif

  rc_bar0 = cpu_read(PCIE_PIM2+RC_BAR0_LOC);
  rc_bar1 = cpu_read(PCIE_PIM2+RC_BAR1_LOC);

  PCIE_POM1 = ((uint64_t) rc_bar1 << 32) | ((uint64_t) rc_bar0);

#ifdef PCIE_EXERCISER

  lprintf(5,"RC_BAR0 =>0x%x\n", cpu_read(PCIE_PIM2+RC_BAR0_LOC));
  lprintf(5,"RC_BAR1 =>0x%x\n", cpu_read(PCIE_PIM2+RC_BAR1_LOC));



  PCIE_POM1 = ((uint64_t) cpu_read(PCIE_PIM2+RC_BAR0_LOC) << 32)
		    | ((uint64_t) cpu_read(PCIE_PIM2+RC_BAR1_LOC));

#if 0
  PCIE_POM2 = ((uint64_t) cpu_read(PCIE_PIM2+RC_BAR2_LOC) << 32)
		    | ((uint64_t) cpu_read(PCIE_PIM2+RC_BAR3_LOC));

  PCIE_POM3 = ((uint64_t) cpu_read(PCIE_PIM2+RC_BAR4_LOC) << 32)
		    | ((uint64_t) cpu_read(PCIE_PIM2+RC_BAR5_LOC));
#endif

#else
  PCIE_POM2 = (uint64_t) RC_BAR2;
  PCIE_POM3 = (uint64_t) RC_BAR4;
#endif

  config_pom_regs(pcie_core_id, PCIE_POM1, PCIE_POM2, PCIE_POM3);
  sm_pcie_setup_ob_cfg(pcie_core_id, EP);
  sm_pcie_setup_ob_space(pcie_core_id, EP);

#ifndef PCIE_EXERCISER

  lprintf(5,"First clear INTA~D related to previous iterations\n\r");
  msg_routing_code = 4;
  msg_data = 0;
  for (msg_code=0x24; msg_code<=0x27; msg_code++)
  send_ob_msg(pcie_core_id, msg_code, msg_routing_code, msg_data);

#endif

#ifdef DMA_INT_ENABLE
 en_event_int(pcie_core_id);
// en_intx_int(pcie_core_id);
#endif

 length=0x2000000;
  switch(test_name){
    case 0 : // In the outbound testing, external RC will communicate the 32-bit offset of the starting location for the outbound traffic.
             // EP will always use OMR1 region as a target for outbound traffic.

#ifdef PCIE_EXERCISER
           // Outbound testing for EP with Exerciser Set up
            lprintf("****EP OUTBOUND TEST CASE WITH PCIE_EXERCISER **** \n\r");

#endif
             addr = PCIE_PIM2+OB_PTR_LOC;
             lprintf(5,"PCIE OB ADDR : 0x%x \n\r",addr);
             start_addr = cpu_read(addr);
             msg_data   = start_addr;
             PCIE_OMR1  = ret_omr1_base(pcie_core_id); 
             start_addr = PCIE_OMR1 | start_addr;

             lprintf(5,"EP doing some outbound writes\n\r");
             init_memory(start_addr, length, test_pattern);
             lprintf(5,"EP doing outbound reads to the same addresses and comparing\n\r");
             result = compare_memory(start_addr, length, test_pattern);
             lprintf(5,"EP sending outbound intx message to signal the end of the test\n\r");
             outbound_intx_msg(pcie_core_id, result);
             msg_code = 0x7F;
             msg_routing_code = 0;
             send_ob_msg(pcie_core_id, msg_code, msg_routing_code, msg_data);
			 
	     break;

    case 1 : // In the inbound testing, external RC will communicate the 32-bit offset of the starting location for the inbound traffic. 
             // External RC will target the inbound traffic towards the BAR0, which will be redirected towards PIM1.

      		 addr = PCIE_PIM2+IB_PTR_LOC;                               // Indicate which BAR is used to send data
             start_addr = cpu_read(addr);
             start_addr = PCIE_PIM1 | start_addr;

#ifdef PCIE_EXERCISER
             outbound_intx_msg(pcie_core_id, 0);

             lprintf("************************************************** \n\r");
             lprintf(5,"RCBAR used for data txr: 0x%x @ Add: 0x%x \n\r", cpu_read(addr),addr);
             lprintf(5,"BAR%d is used for data transfer \n\r",cpu_read(addr));
             lprintf("************************************************** \n\r");
             bar_idx=cpu_read(addr);

             switch(bar_idx)
             {
               case 0 : start_addr =ret_pim1_base(pcie_core_id); break;
               case 1 : start_addr =ret_pim1_base(pcie_core_id);  break;
               case 2:  start_addr =ret_pim2_base(pcie_core_id);  break;
               case 3:  start_addr =ret_pim3_base(pcie_core_id);  break;
               default : lprintf(5,"  ###    INVALID BAR    ### \n\r ")  ;break;
             }

             start_addr += (IB_PTR_LOC + 4) ;
#endif
             lprintf(5,"Comparing the results for inbound traffic\n\r");
             result = compare_memory(start_addr,length , test_pattern);
             lprintf(5,"Send outbound intx message to signal the end of the test\n\r");
             outbound_intx_msg(pcie_core_id, 0);
             break;

    case 2 : lprintf(5,"Generate INTA, through legacy intx generation mechanism\n\r");
             disable_msi_support(pcie_core_id);
             gen_int(pcie_core_id);
             break;

    case 3 : lprintf(5,"Generate INTA, through MSI generation mechanism\n\r");
             disable_msi_support(pcie_core_id);
             gen_msi(pcie_core_id);
             break;

    case 4 : lprintf(5,"Generate MSI, through MSI generation mechanism\n\r");
             gen_msi(pcie_core_id);
             break;

    case 5 : lprintf(5,"Generate MSI, through legacy intx generation mechanism\n\r");
             gen_int(pcie_core_id);
             break;             

    case 8 : lprintf(5,"This is Single channel DMA for AXI-to-PCIE (PCIE OB Write)\n\r");
             src_axi = 1;
             dst_axi = 0;
             mult_ch = 0;
             intlv   = 0;

#ifdef PCIE_EXERCISER
            // Outbound testing for EP with Exerciser Set up
            lprintf("****EP OUTBOUND TEST CASE WITH PCIE_EXERCISER DMA (AXI to PCIE)**** \n\r");
#endif
             
             break;

    case 9 : lprintf(5,"This is single channel DMA for PCIE-to-AXI (PCIE OB Read)\n\r");
             src_axi = 0;
             dst_axi = 1;
             mult_ch = 0;
             intlv   = 0;
             // initialized pcie memory
    //         start_addr= ret_omr1_base(pcie_core_id);
     //        init_memory(start_addr,length,test_pattern);

             break;

    case 10: lprintf(5,"This is multichannel DMA for AXI-to-PCIE (PCIE OB Write)\n\r");
             src_axi = 1;
             dst_axi = 0;
             mult_ch = 1;
             intlv   = 0;
             full_duplx=0;
             break;

    case 11: lprintf(5,"This is multichannel DMA for PCIE-to-AXI (PCIE OB Read)\n\r");
             src_axi = 0;
             dst_axi = 1;
             mult_ch = 1;
             intlv   = 0;
             full_duplx=0;
             break;

    case 12: lprintf(5,"This is multichannel DMA interleaved\n\r");
             src_axi = 1;
             dst_axi = 0;
             mult_ch = 1;
             intlv   = 1;
             break;

#ifdef EN_AER

    case 13 : lprintf(5,"TESTING WITH EXERCISER FOR AER ");
              lprintf(5,"Will generate some outbound traffic to genrate negative scenario of UR\n\r");

           // NON-FATAL ERROR
           //   pcie_ob_cfg_read(pcie_core_id, 0x200);
              lprintf(5,"Address DDR PIM2: 0x%x \n\r" ,(PCIE_PIM2));
              lprintf(5,"Address DDR PIM1: 0x%x \n\r" ,(PCIE_PIM1));
    	      break;
#endif

    default: lprintf(5,"Please send the correct signature, for testing in EP mode.\n\r");
             break;
  }

  if(test_name >= 8 && test_name <= 12) {
    uint64_t dma_addr, dma_addr2;
    uint32_t src2_axi, dst2_axi;

    if(mult_ch) {
      if(intlv == 0) {
    	if(!full_duplx)
    	{
        src2_axi = src_axi;
        dst2_axi = dst_axi;
    	}
    	else
    	{
    	  src2_axi = dst_axi;
          dst2_axi = src_axi;
    	}
    } else {
        src2_axi = (~src_axi & 0x1);
        dst2_axi = (~dst_axi & 0x1);
      }
    } else {
      src2_axi = 0;
      dst2_axi = 0;
    }    

    lprintf(5,"Will do some DMA testing in EP mode\n\r");
    
    // In DMA testing, it is only source memory that needs to be initialized.
    // Further, the source memory needs to be initialized only for OB writes from EP side.
    if(src_axi) {
      lprintf(5,"Initializing the source memory, since it is OB DMA write\n\r");
      init_memory(PCIE_PIM1+DMA_SRC_AXI, length, test_pattern);

      if(mult_ch && (intlv == 0)){
        lprintf(5,"Initializing the source memory, since it is multichannel OB DMA write\n\r");
        init_memory(PCIE_PIM1+DMA_SRC2_AXI, length, test_pattern);
      }
    }

    if(src_axi)
      dma_addr = PCIE_PIM1+DMA_SRC_AXI;
    else
      dma_addr = 0;

    if(src2_axi)
      dma_addr2 = PCIE_PIM1+DMA_SRC2_AXI;
    else
      dma_addr2 = 0;

    init_dma_src_dst_elements(pcie_core_id, dma_addr, dma_addr2, src_axi, src2_axi, SRC, length);

    if(dst_axi)
      dma_addr = PCIE_PIM1+DMA_DST_AXI;
    else
      dma_addr = 0;

    if(dst2_axi)
      dma_addr2 = PCIE_PIM1+DMA_DST2_AXI;
    else
      dma_addr2 = 0;


    init_dma_src_dst_elements(pcie_core_id, dma_addr, dma_addr2, dst_axi, dst2_axi, DST, length);
    init_dma_sta_elements(pcie_core_id, mult_ch, 1);

#ifdef PERF_MEASURMENT
    prep_diag_mode(pcie_core_id,length);   // Start Measurement
#endif

/*
    lprintf( " DMA specific to Int on PCIE side \n\r");
    data = pcie_csr_read(pcie_core_id, NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_PCIE_INT_AXI_PCIE_N__ADDR);
	pcie_csr_write(pcie_core_id,NWL_PCIE_APB_REGS_MC_DMA_MC_DMA_CFG_CFG_PCIE_INT_AXI_PCIE_N__ADDR,data);

    data = pcie_ob_cfg_read(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (0 * 0x40));
    data = 0x8000;
    data |= 0x10000;   //  Enable DMA and INT to AXI : Turn 16th to 1 only for PCIE INTx Interrupt
    pcie_ob_cfg_write(pcie_core_id, NWL_PCIE_AXI_REGS_MC_DMA_DMA_CHAN0_DMA_CONTROL_STATUS__ADDR | (0 * 0x40), data);
    en_intx_int(pcie_core_id);
*/
    pcie_ob_cfg_write(0,0x110, 0xFFFFFFFF);  //clear correctable error
    pcie_ob_cfg_write(0,0x10110, 0xFFFFFFFF);  //clear correctable error
    sm_pcie_setup_dma(pcie_core_id, src_axi, dst_axi, mult_ch, intlv);

    fail = 0;
#ifndef DMA_INT_ENABLE
    result = poll_dma_cmpl(pcie_core_id, mult_ch);

#elif !defined(PERF_2_PORTS)
 result = evt_dma_cmpl(pcie_core_id, mult_ch);
#endif

    fail |= result;

    if(dst_axi) {
      lprintf(5,"Testing the destination memory against the test pattern, since the DMA was setup for OB read\n\r");
      result = compare_memory(PCIE_PIM1+DMA_DST_AXI, length, test_pattern);
      fail |= result;

      if(mult_ch && (intlv == 0)){
        lprintf(5,"Testing the destination memory against the test pattern, since the DMA was setup for multichannel OB read\n\r");
        result = compare_memory(PCIE_PIM1+DMA_DST2_AXI, length, test_pattern);
        fail |= result;
      }
    }
/*  // when want to compare data from PCIE  
    if(src_axi) 
    {
      start_addr= ret_omr1_base(pcie_core_id);
      compare_memory(start_addr,length,test_pattern); 
    }
*/
    outbound_intx_msg(pcie_core_id, fail);

#ifndef PERF_2_PORTS

#ifdef PERF_MEASURMENT

if( (test_name==8) ||(test_name==10) )
{
	 lprintf(5,"CFG START_STOP_STATUS := 0x%x \n\r",
	    	    pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR)));


    while( ( pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR) ) & 0x4 ));
     lprintf(5,"CFG START_STOP_STATUS := 0x%x \n\r",
    	    pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR)));
    
    print_M_AXI_WR_RD(pcie_core_id,RD);

    itr_summ.ep_wr_perf= RD_BW_g;

}
else if( (test_name==9) ||(test_name==11) )
{
   while( ( pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR) ) & 0x1 ));
  lprintf(5,"CFG START_STOP_STATUS := 0x%x \n\r",
      	    pcie_csr_read(pcie_core_id,(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP__ADDR)));
    print_M_AXI_WR_RD(pcie_core_id,WR);

    itr_summ.ep_rd_perf=WR_BW_g;

}
#endif
#endif

    outbound_intx_msg(pcie_core_id, fail);

  }
}

uint32_t chk_intx_status(uint32_t pcie_core_id){
  uint32_t data, success, i;
  

  success = 2000000;
  do {
    data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_INTXSTATUS__ADDR);
    data = data & 0xF;
#ifdef SIMULATION
    sm_host_delay_ns(1000);
#endif
  } while((data == 0)&&(--success));

  if (data & 1) {
    success = 1;
    lprintf(5,"chk_intx_status() passed at the EP end, ");
  } else {
    success = 0;
    lprintf(5,"chk_intx_status() failed at the EP end, "); 
  }
  for (i=0;i<4;i++) {
    if (data & 1) 
      lprintf(5,"INT%1c ", 0x41+i);
    data >>= 1; 
  }
  lprintf(5,"received.\n");
  return success;
}

uint32_t sm_pcie_chk_results(uint32_t pcie_core_id, uint32_t test_id, uint32_t test_pattern, uint32_t len){
  uint32_t data=0;
  uint32_t success, err=0;
  uint64_t start_addr;
   
  uint32_t test_pattern_in=test_pattern;
  lprintf(5,"Comparing the results at RC end for TID : %d %d \n\r",test_id,test_pattern_in);
  success = chk_intx_status(pcie_core_id);
  lprintf(5,"Comparing the results at EP end for TID : %d %d \n\r",test_id,test_pattern_in);

  data=0;
  switch(test_id){
    case 0:  start_addr = ret_pim1_base(pcie_core_id);
             data = sm_pcie_poll_go_ahead(pcie_core_id);
             start_addr = start_addr | (uint64_t) data;
        
             lprintf(5,"Comparing the results for inbound traffic at RC end\n\r");
             err = compare_memory(start_addr, len, test_pattern);
             break;

    case 8:  start_addr = ret_pim1_base(pcie_core_id);
    	     start_addr = start_addr | (uint64_t) data;
    	     lprintf(5,"Comparing the results for Inbound traffic at RC end\n\r");
             data_cache_flush_all();
             dcache_flush_all();     
             err = compare_memory(start_addr, len, test_pattern);
             break;             

    case 12: start_addr = ret_pim1_base(pcie_core_id);
             err = compare_memory(start_addr, len, test_pattern);
             break;            

  }

  if((success == 1) && (err == 0))
    return 0;
  else
    return 1;

}
 
uint32_t pcie_chk_results(int argc, char *argv[]){
uint32_t pcie_core_id, test_id, test_pattern, len;

  if (argc < 3) {
    lprintf(5,"Usage: rc_core_id test_id length\n");
    return -1;
  }
 
  pcie_core_id = atoi(argv[0]);
  test_id      = atoi(argv[1]);
  len          = atoi(argv[2]);
  sm_pcie_chk_results(pcie_core_id, test_id, test_pattern, len);
}


void pwr_ctrl(int argc, char *argv[]){

uint32_t data,pcie_core_id=0;
pcie_core_id = atoi(argv[0]);

data = pcie_csr_read(pcie_core_id, (NWL_PCIE_APB_REGS_EXPRESSO_CFG_CONTROL_CFG_CONTROL_191_160__ADDR));
lprintf(5,"Power Control Stat: = 0x%x\n\r",data);

data = pcie_csr_read(pcie_core_id, SM_PCIE_CSR_REGS_EVENTINTERRUPTSTATUS__ADDR);

lprintf(5,"POWER_MANAGEMENT_STAT: = 0x%x\n\r",data);

}

void Cfg_MSI_AddrData(pcie_core_id)
{
	uint32_t data=0;

	data=pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_MSI_CAP__ADDR);

	data |= 1 << 16;
    data|=(0x5 << 0x14 );

	pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_MSI_CAP__ADDR,data);

	lprintf(5,"Message Control  : 0x%x \n\r",pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_MSI_CAP__ADDR));

	data=pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_MSI_LOW_ADDR__ADDR);
	data=RC_BAR0 << 2;
	pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_MSI_LOW_ADDR__ADDR,data);
	lprintf(5,"Message Address  : 0x%x \n\r",pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_MSI_LOW_ADDR__ADDR));

	data=pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_MSI_UPP_ADDR__ADDR);
    data=RC_BAR0 << 2;
	pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_MSI_UPP_ADDR__ADDR,data);

	lprintf(5,"Message Upper Address : 0x%x \n\r",pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_MSI_UPP_ADDR__ADDR));

	data=pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_MSI_DATA__ADDR);
    data|=0xf000;
    pcie_ob_cfg_write(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_MSI_DATA__ADDR,data);

    lprintf(5,"Message Data : 0x%x \n\r",pcie_ob_cfg_read(pcie_core_id, SM_PCIE_CFG1_PCIE_CFG1_MSI_DATA__ADDR));

    data = (uint32_t )(MSI_TER_SIZE >> 32);
    lprintf(5,"Configuring SM_PCIE_CSR_REGS_PIM1SH__ADDR reg with "); putnum_pcie(data); lprintf(5,"\n\r");
    pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIM1SH__ADDR,data);

    data = (uint32_t )MSI_TER_SIZE;
    lprintf(5,"Configuring SM_PCIE_CSR_REGS_PIM1SL__ADDR reg with "); putnum_pcie(data); lprintf(5,"\n\r");
    pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIM1SL__ADDR,data);

    data = (uint32_t )MSI_INDX_REG;
    lprintf(5,"Configuring SM_PCIE_CSR_REGS_PIM1_1L__ADDR reg with "); putnum_pcie(data); lprintf(5,"\n\r");
    pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIM1_1L__ADDR,data);

    data = (uint32_t )0;
    lprintf(5,"Configuring SM_PCIE_CSR_REGS_PIM1_1H__ADDR reg with "); putnum_pcie(data); lprintf(5,"\n\r");
    pcie_csr_write(pcie_core_id, SM_PCIE_CSR_REGS_PIM1_1H__ADDR,data);


}


