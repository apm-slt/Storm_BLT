#ifndef __vOCM_macros_H__
#define __vOCM_macros_H__

#include "global.h"
#include "sm_addr_map.h"
#include "vOCM_defines.h"
#include "vOCM_regs.h"
#include "sm_common_reg_offset.h"
sm_ret_t ocm_init()
{
	unsigned int rdata;
	unsigned int timeout=0;
	printf("Enable clock\n");
	write(SM_ADDR_MAP_OCM_CSR_BASE+SM_OCM_CLK_RST_CSR_CRCSR_OCM_CLKEN__ADDR,OCM_CLKEN);
	read(SM_ADDR_MAP_OCM_CSR_BASE+SM_OCM_CLK_RST_CSR_CRCSR_OCM_CLKEN__ADDR);
	printf("Soft reset\n");
	write(SM_ADDR_MAP_OCM_CSR_BASE+SM_OCM_CLK_RST_CSR_CRCSR_OCM_SRST__ADDR,OCM_SRST);
	read(SM_ADDR_MAP_OCM_CSR_BASE+SM_OCM_CLK_RST_CSR_CRCSR_OCM_SRST__ADDR);
	printf("Mem shutdown enable\n");
	write(SM_ADDR_MAP_OCM_CSR_BASE+SM_GLBL_DIAG_CSR_CFG_MEM_RAM_SHUTDOWN__ADDR,OCM_MEM_SHTDWN);
	read(SM_ADDR_MAP_OCM_CSR_BASE+SM_GLBL_DIAG_CSR_CFG_MEM_RAM_SHUTDOWN__ADDR);
	printf("Check block mem ready\n");
	rdata=read(SM_ADDR_MAP_OCM_CSR_BASE+SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY__ADDR);
	while(rdata!=BLOCK_MEM_READY){
		timeout++;
		rdata=read(SM_ADDR_MAP_OCM_CSR_BASE+SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY__ADDR);
		if(timeout>1000){
			printf("Block mem not ready\n");
			return SM_FAIL;
			}
	}
	printf("OCM memory is ready to use\n");
	return SM_OK;

}

int ocm_read_write(u32 address, u32 wordcount)
{
	int i;
	int j;
	int err=0;
	u32 *addr;
	u32 data;
	addr=(u32*)address;
	int pattern;

	for (j=0;j<2;j++){

		if (j==0) pattern=0xa5a5a5a5;
		else if(j==1) pattern =0x5a5a5a5a;

	if((addr<OCM_MEM_BASE)||(addr>OCM_MEM_MAX)){
		printf("Out of OCM memory!!\n");
		return SM_FAIL;
	}
	else{
		printf("OCM write... pattern =0x%08x to address 0x%08x\n",pattern,addr);
		for(i=0;i<wordcount;i++){
			WRITE32(addr,pattern);
			addr++;                        //Because addr is a 32bit pointer, every increase is 4byte
			if(addr>(OCM_MEM_MAX-4)){
				printf("Out of memory!\n");
				return SM_FAIL;
			}
		}

		printf("Compare read data and pattern\n");
		addr =(u32*)address;
		for (i=0;i<wordcount;i++){
			data =READ32(addr);
//			printf("Data=0x%08x\n",data);
//			printf("Address=0x%08x\n",addr);
			addr++;							 //Because addr is a 32bit pointer, every increase is 4byte
			if(data!=pattern) err++;
		}

		if(!err) printf("All comparisons are matched\n");

		printf("OCM read ...\n");
		addr =(u32*)address;
		mem_dump(addr,wordcount);

		}
	}
	printf("ERROR = %d\n",err);
	return err;
}



#endif /*__vOCM_macros_H__*/

