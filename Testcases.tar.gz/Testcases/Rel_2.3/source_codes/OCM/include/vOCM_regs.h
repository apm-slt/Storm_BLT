#ifndef __vOCM_regs_H__
#define __vOCM_regs_H__

#define SM_OCM_CSR_CSR_IOF_CH_WT__ADDR                     0x0
#define SM_OCM_CSR_CSR_COP_CH_WT__ADDR                     0x4
#define SM_OCM_CSR_CSR_MEM_BANK_0__ADDR                    0x8
#define SM_OCM_CSR_CSR_MEM_BANK_1__ADDR                    0x1c
#define SM_OCM_CSR_CSR_COP_FIFO_FULL_THRESHOLD__ADDR       0x20
#define SM_OCM_CSR_CSR_IOF_FIFO_FULL_THRESHOLD__ADDR       0x24
#define SM_OCM_CSR_CSR_DBG__ADDR                           0x28
#define SM_OCM_CSR_COP_CH_FIFO_INTR__ADDR                  0x30
#define SM_OCM_CSR_COP_CH_FIFO_INTRMASK__ADDR              0x34
#define SM_OCM_CSR_IOF_CH_FIFO_INTR__ADDR                  0x40
#define SM_OCM_CSR_IOF_CH_FIFO_INTRMASK__ADDR              0x44
#define SM_OCM_CSR_CFG_RAM_DS__ADDR                        0x50
#define SM_OCM_CSR_FIFO_EMPTY_STATUS__ADDR                 0x54
#define SM_OCM_CSR_INT_WR_PROTECT_ERR__ADDR                0x58
#define SM_OCM_CSR_INT_WR_PROTECT_ERRMASK__ADDR            0x5c
#define SM_OCM_CSR_WR_PROTECT_ERR_ADDR__ADDR               0x60
#define SM_OCM_CSR_WR_PROTECT_ERR__ADDR                    0x64
#define SM_OCM_CSR_FIFO_FULL_STATUS__ADDR                  0x70


#define SM_OCM_CLK_RST_CSR_CRCSR_OCM_SRST__ADDR            0xc000
#define SM_OCM_CLK_RST_CSR_CRCSR_OCM_CLKEN__ADDR           0xc004




#endif /*__vOCM_regs_H__*/
