/*
 * global.h
 *
 *  Created on: Jan 4, 2013
 *      Author: lxpham
 */

#ifndef GLOBAL_H_
#define GLOBAL_H_

//#include <clib/PDMA/vPDMA_defines.h>

//Tinh-SLT:
//function defined here
#define mem_dump mem_dump_ocm
#define print print_ocm
#define putnum putnum_ocm
#define read read_ocm
#define write write_ocm
//End of Tinh-SLT

#ifdef ZZZVBIOS
#include <armv8.h>
#endif /*ZZZVBIOS*/
#define  READ8(add)         (*(volatile unsigned char *)(add))
#define  READ16(add)         (*(volatile unsigned short *)(add))
#define  READ32(add)        (*(volatile unsigned *)(add))
#define  WRITE8(add, data)     *(unsigned char *)(add) = (unsigned char)(data)
#define  WRITE16(add, data)    *(unsigned short *)(add) = (unsigned short  )(data)
#define  WRITE32(add, data)    *(unsigned *)(add) = (unsigned )(data)


#define  READ64(add)        (*(volatile unsigned long long *)(add))
#define  WRITE64(add, data)    *(unsigned long long *)(add) = (unsigned long long )(data)

typedef unsigned char u8;

#ifndef u32
#define u32 unsigned int
#endif /*u32*/

#ifndef u64
#define u64 unsigned long long
#endif /*u64*/

#define in_le32		arm_in_le32
#define out_le32	arm_out_le32

#ifndef NULL
#define NULL ((void *)0)
#endif /*NULL*/

#define SM_CHK_PTR(p) \
		{if(!p) {{printf("%s, %s, line=%d, Null Ptr Passed.\n",\
				__FILE__, __FUNCTION__, __LINE__);}; return SM_FAIL;}}

#define SM_CHK_RET(ret)							\
  {if (ret != SM_OK) {printf("SM_CHK_RET:: %s\n", ret);return ret;}}


typedef enum{
    SM_OK,
    SM_INVALID_PARAM,
    SM_NO_RSC,
    SM_TIMEOUT,
    SM_FATAL,
    SM_FAIL

} sm_ret_t;

#ifdef ZZZVBIOS

void *mem_set(void *s, int c, int n);
void putnum(int num);
void print (const char* str);
int read(unsigned int *address);
void write(unsigned int *address, int data);
void reg_dump(unsigned int addr, unsigned int wordcount);
void mem_dump(unsigned int addr, unsigned int wordcount);
void mem_dump_64(u64 addr, unsigned int wordcount);

void msg_dump(u32* addr, u32 size);
void mdump(u32* addr, u32 size) ;

#endif /*ZZZVBIOS*/

#ifndef ZZZVBIOS

void *mem_set(void *s, int c, int n)
{
    unsigned char* p=s;
    while(n--)
        *p++ = (unsigned char)c;
    return s;
}


void putnum(int num) {
  printf("%08x", num);
  return;
}

void print (const char* str) {
  printf(str);
  return;
}
int read(unsigned int *address){
  unsigned int *addr_int;
  int rdata;
  addr_int = address;
  rdata = *addr_int;
	print("Read32  @ 0x:"); putnum(addr_int); print(" is 0x");  putnum(rdata);  print("\n\r");
	return(rdata);
}

void write(unsigned int *address, int data){
  unsigned int *addr_int;
  addr_int = address;
	*addr_int = data;
	print("Write32 @ 0x:"); putnum(address); print(" is 0x");  putnum(data);  print("\n\r");
}



void reg_dump(unsigned int addr, unsigned int wordcount)
{

	int i;
	 unsigned int *address;
	address =(unsigned int*)addr;
	if(!wordcount){
		printf("Invalid size\n");
	}
	for(i=0;i<wordcount;i++){
		if(!(i%4)){
			if(i>0) 	printf("\n");
			printf("%08x:  ",address+i);
		}
		printf("0x%08x    ",*(address+i));
	}
	printf("\n");
}

/*Memdump pass value*/
void mem_dump(unsigned int addr, unsigned int wordcount)
{

	int i;
	 unsigned int *address;
	address =(unsigned int*)addr;
	if(!wordcount){
		printf("Invalid size\n");
	}
	for(i=0;i<wordcount;i++){
		if(!(i%4)){
			if(i>0) 	printf("\n");
			printf("%08x:  ",address+i);
		}
		printf("0x%08x    ",*(address+i));
	}
	printf("\n");
}
/*Memdump pass value*/
void mem_dump_64(u64 addr, unsigned int wordcount)
{

	int i;
	 u64 *address;
	address =(u64*)addr;
	if(!wordcount){
		printf("Invalid size\n");
	}
	for(i=0;i<wordcount;i++){
		if(!(i%4)){
			if(i>0) 	printf("\n");
			printf("%16x:  ",address+i);
		}
		printf("0x%08x    ",*(address+i));
	}
	printf("\n");
}

void msg_dump(u32* addr, u32 size) {
	u32 *ptr,*end_addr;
	u32 word0,word1;
	int error = 0;
	end_addr = (u32*) addr+size;
	ptr = addr;
	while(ptr<end_addr) {
		printf("0x%08x:\t0x%08x_0x%08x:\n",ptr,*ptr++,*ptr++);
	}
}

/*memdump pass poiter*/
void mdump(u32* addr, u32 size) {
	u32* ptr,end_addr;
	int error = 0;
	end_addr = (u32*) addr+size;
	ptr = addr;
	while(ptr<end_addr) {
		printf("0x%08x:\t",ptr);
		printf("0x%08x\t0x%08x\t0x%08x\t0x%08x\n",*ptr++,*ptr++,*ptr++,*ptr++);
	}
}

#endif /*ZZZVBIOS*/

#endif /* GLOBAL_H_ */
