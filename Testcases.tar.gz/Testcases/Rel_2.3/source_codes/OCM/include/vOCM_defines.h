#ifndef __vOCM_defines_H__
#define __vOCM_defines_H__

#define OCM_CLKEN 			0x3
#define OCM_SRST 			0x0
#define OCM_MEM_SHTDWN 		0x0
#define BLOCK_MEM_READY		0xFFFFFFFF

#define OCM_MEM_BASE		0x1D000000
#define OCM_MEM_MAX			0x1D0FFFFF
#endif /*__vOCM_defines_H__*/
