
#ifndef __ETH_SERDES_H_
#define __ETH_SERDES_H_
#include <stdio.h>
#include <common.h>
#include "eth_common.h"
#include "eth_xg_csr.h"
#include "sm_xxx_serdes.h"

extern void  serdes_pdown_force_vco (int port, int display) ;
extern void enet_sds_CMU_cfg(int port, int display);
extern void enet_sds_rxtx_cfg(int port,int display);
extern void sm_enet_module_program_all_regs(int port, int display) ;
extern void serdes_clkmacro(int port);
extern void serdes_reset_rxd_rxa (int port, int display) ;
extern void serdes_reset_rxd (int port, int display) ;
extern void serdes_reset_rxa (int port) ;
extern void force_lat_summer_cal (int eth_type, int port, int display) ;
extern void serdes_calib(int port, int display);
extern int sm_enet_module_init_enet_serdes(int intf, uint32_t refclk, uint32_t tx2rx_serdes_lb) ;
extern void sata_enet_bist();
extern void sata_enet_bist_port(int eth_type,int port, int display);
extern int kc_serdes_rd(int offset,int port);
extern void kc_serdes_wr(int offset, int wr_data,int port);
extern int kc_macro_cfg(int port);
extern int kc_macro_pvt_and_calib_ready_check(int port) ;
extern void  kc_macro_pdown_force_vco (int port) ;
//XG

extern void  serdes_pdown_force_vco_xg (int port, int display) ;
extern void serdes_reset_rxd_rxa_xg (int eth_type, int port, int display) ;
extern void serdes_reset_rxd_xg (int eth_type, int port, int display) ;
extern void serdes_reset_rxa_xg (int eth_type, int port, int display) ;
extern void force_lat_summer_cal_xg (int eth_type, int port, int display) ;
extern void serdes_calib_xg(int eth_type, int port, int display);
extern void sm_xgenet_module_program_all_regs(uint32_t infmode,int eth_type, int port, int display) ;
extern void xgenet_sds_CMU_cfg(uint32_t infmode,int eth_type, int port, int display) ;
extern void xgenet_sds_rxtx_cfg(uint32_t infmode,int eth_type, int port, int display) ;
extern int sm_xgenet_module_init_enet_serdes( uint32_t infmode, uint32_t refclk_cmos_sel, uint32_t tx2rx_serdes_lb,int eth_type, int port, int display) ;
extern void xfi_bist();
extern void xfi_bist_port(int eth_type,int port, int display);

#endif 
