#ifndef __ETH_SLT_TX2RX_H_
#define __ETH_SLT_TX2RX_H_

#include <stdio.h>
#include <common.h>
#include "eth_common.h"
#include "qm_drv.h" 
#include "qm_misc.h"
#include "qm_vfw.h"

extern void total_err_count_result() ;
extern int pkt_compare(int tx_port, int rx_port, u32 pn);
extern int eth_tx2rx_lpbk_test_sata_1g_ext_lpbk() ;
extern int eth_tx2rx_lpbk_test_sata_1g_int_lpbk() ;
extern int eth_tx2rx_1g_sata();
extern void mac_stat_1g_sata();
extern qm_ret_t sys_alloc_enet_buf(u8 qmid, u32 fpqid, int mn, qm_buf_t *p_buf);
extern enq_req_t *sys_enet_enq_cfg(u64 da, unsigned int len);
extern enq_req_t *sys_enet_enq_cfg32(u64 da, unsigned int len);
extern enq_req_t *sys_enet_enq_cfg33(u64 da, unsigned int len);
extern enq_req_t *sys_enet_enq_cfg34(u64 da, unsigned int len);
extern enq_req_t *sys_enet_enq_cfg_xfi(u64 da, u32 len);
extern enq_req_t *sys_enet_enq_cfg32_xfi(u64 da, u32 len);
extern enq_req_t *sys_enet_enq_cfg33_xfi(u64 da, u32 len);
extern enq_req_t *sys_enet_enq_cfg34_xfi(u64 da, u32 len);
extern void total_err_count_result_xfi() ;
extern int pkt_compare_xfi(int tx_port, int rx_port, u32 pn);
extern int eth_tx2rx_lpbk_test_xfi_1g_ext_lpbk() ;
extern int eth_tx2rx_lpbk_test_xfi_1g_int_lpbk() ;
extern int eth_tx2rx_1g_xfi() ;
extern void mac_stat_1g_xfi();

#endif // __ETH_SLT_TX2RX_H_
