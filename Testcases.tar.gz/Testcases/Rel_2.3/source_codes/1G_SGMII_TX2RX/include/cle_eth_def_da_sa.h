/*******************************************************************************************************
 * cle_def.h
 *
 *  Created on: August 14, 2013
 *      Author:	HuuHoang Nguyen
 *      Email : hhnguyen@apm.com
 *
 *
 *******************************************************************************************************/
#ifndef __CLE_DEF_H__
#define __CLE_DEF_H__

/*===================================================================================================*/
#include "cle_com.h"
#include "cle_db.h"


/*===================================================================================================*/
/*Define DBRAM DEFAULT */
/*===================================================================================================*/
cle_db_ram_entry_t 	cle_db_ram_df =
{
	/*word32b 0*/
	.split_boundary					= 0,		//8 bits
	.mirror_nxtfpsel				= 0,		//4 bits
	.mirror_fpsel					= 0,		//4 bits
	.mirror_dstqid					= 0,		//12 bits
	.drop							= 0,		//1 bits
	.mirror							= 0,		//1 bits
	.hdr_data_split					= 0,		//1 bits
	.hopinfomsbs					= 0,		//48 bits

	/*word32b 2*/
	.dr								= 0,		//1 bits
	.hr								= 1,		//1 bits
	.hopinfolsbs			 	 	= 0,		//48 bits

	.henqnum						= 0,		//12 bits
	.hfpsel							= 0,		//4 bits
	.nxtfpsel						= 0,		//4 bits
	.fpsel							= 0,		//4 bits
	.dstqid							= 0,		//12 bits

	/*word32b 5*/
	.priority						= 0,		//3 bits
	.flowgroup						= 0,		//4 bits
	.perflow						= 0,		//6 bits
	.insert_timestamp				= 0,		//1 bits
	.stash							= 0,		//2 bits
	.in								= 0,		//1 bits
	.PerPrioEn						= 0,		//1 bits
	.PerFlowGroupEn					= 0,		//1 bits
	.PerFlowEn						= 0,		//1 bits
	.SelHash						= 0,		//1 bits
	.SelHdrExt						= 0,		//1 bits
	.unused							= 0,		//5 bits
};



/*===================================================================================================*/
/*  CONFIGURED CLE_LITE*/
/*===================================================================================================*/
#if CLE_LITE_ENABLE

/*=================================*/
/*==========  USER NOTE  ==========*/
/*=================================*/
/* 
	1. User need to define node.  Before is the example of define node #0, 1, 2, 3, 4, and 11.
	2. After defining the node, insert the node into "cle_cfg_ptram_dn ptram_dn_lite[]" array.
	3. Define the Keynote
	4. Insert the Keynote into the "cle_cfg_ptram_kn ptram_kn_lite[]" array.
	5. Set start node to parser0, Synthesis Decision node and Keynode in "cle_cfg_ptram_t ptram_cfg_lite"
	6. Define array of HInfo field in entries of DBRAM.
	7. Define array of entries in DBram, have insert HInfo from step 6.
	8. Synthesis DBRam in "cle_cfg_dbram_t cle_cfg_db_lite"
	9. Insert configure table of PTram and DBram (ptram_cfg_lite, cle_cfg_db_lite) to "cle_cfg_pt_db_t cle_cfg_pt_db[]" array.

*/

/*=================================*/
/*========== Define Node ==========*/
/*=================================*/

/* STEP 1 */

/*---------------------------------------------------------------------------------*/
// DN  (Node type - 2bits)   : 0->3  ([ 0: Invalid Node],  [1: Key Node],  [2 : Decision Node], [3: Reserved]
// LN  (Last Node - 1bits)   : 0->1  ([ 0: Start/Middle Node],   [1: Last node]
// HS  (Header Store)	     : 0->3  ([ 0: Not store],   [1 : Store byte 0],   [2: Store byte],     [3: Store both Bytes])
// HE  (Header Extract- 2bit): 0->3  ([ 0: Not extract], [1 : extract byte 0], [2: extract byte 1], [3: Extract Both Bytes])
// BS  (Byte Store - 2bits)  : 0->3  ([ 0: Not store],   [1 : Store byte 0],   [2: Store byte],     [3: Store both Bytes])
// SBS (Search Byte Store)   : 0->3  ([ 0: Not store],   [1 : Store byte 0],   [2: Store byte], 	[3: Store both Bytes])
// DefPtr :  Default Result Pointer to read out the Result/DB RAM.
// V   (Valid branch)		 : 0->1  ([1b0  = 0: branch not valid ],[1b1  = 1: branch valid]
// P2B (Pointer 2 Byte)		 : Pointer point to 2byte in incoming packet that used to compare with CMPDATA
// jr  (Relative Jump)		 : 0->1  ([0 Next 2-Byte Data/Packet Pointer] is an absolute pointer)
//							 : 		 ([1 Next 2-Byte Data/Packet Pointer] relative to the Pointer of the previous node)
// jb  (Jump Backward)		 : It is only meaningful if �Relative Jump� is set to 1
//							  0->1
//                            0 : the Next 2-Byte Data Pointer will be used to add to the Pointer of the previous node
//                            1: Next 2 -Byte Data Pointer will be used to subtract from the Pointer of the previous node
// Op (operation_type - 3bit) : 0->5) ([0: Equal], [1: Not Equal], [2: Less than Equal], [3: Greater than Equal], [4: Bitwise AND]), [5: Bitwise NAND]
// Node ()
// CMPDAT (Compare Data)	: Is stored in PTRAM and used to compared with 2byte in incoming packet is pointed in P2B.
// R    (Reserved)
//-------------------------------------------------------------------------------------------
// Node0 - Checks MAC Destination Address
cle_ptree_dn_t ptram_dn0_lite =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,   R
	  2,    0,      0,   0,   0,	3,	  0,      0,        0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    2,      0,   1,   0,    0,    1,      0,   0x1100,   0xffff},
	 {1,    2,      0,   1,   0,    0,    2,      0,   0x3322,   0xffff},
	 {1,    16,     0,   0,   0,    1,    0,      0,   0x5544,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};


// Node1 - Checks for VLAN ID
cle_ptree_dn_t ptram_dn1_lite =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,     DefPtr,   R
	  2,    0,      0,   0,   0,	0,	  0,     0,        0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    4,      0,   1,   0,    1,    0,      0,   0x0081,   0x0000},		//VLAN Tag
	 {1,    4,      0,   1,   0,    1,    0,      0,   0x0091,   0x0000},		//VLAN Q-Q
	 {1,    0,      0,   1,   0,    2,    0,      0,   0x0000,   0xffff},		//Not VLAN
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};


// Node2 - Checks for EtherType i.e. IPv4/IPv6
cle_ptree_dn_t ptram_dn2_lite =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    0,      0,   0,   0,	0,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    2,      0,   1,   0,    3,    0,      0,   0x0008,   0x0000},		//IPv4
	 {1,    2,      0,   1,   0,    3,    1,      0,   0xdd86,   0x0000},		//IPv6
	 {1,    280,    0,   0,   0,    11,   0,      0,   0x0000,   0xffff},		//Non-IP
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};


// Node3 - Checks CoS
cle_ptree_dn_t ptram_dn3_lite =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    0,      0,   3,   0,	0,	  0,      0,       0,
	//V,    P2B,  	jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    8,      0,   1,   0,    4,    0,      0,   0x0000,   0x0fff},		//IPv4
	 {1,    6,      0,   1,   0,    4,    3,      0,   0x0000,   0xffff},		//IPv6
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};


// Node4 - Checks for Protocol
cle_ptree_dn_t ptram_dn4_lite =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    0,      0,   0,   0,	0,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    256,    0,   0,   0,    11,   1,      0,   0x0600,   0x00ff},		//IPv4-TCP
	 {1,    260,    0,   0,   0,    11,   2,      0,   0x1100,   0x00ff},		//IPv4-UDP
	 {1,    264,    0,   0,   0,    11,   3,      0,   0x0000,   0xffff},		//IPv4-Others
	 {1,    258,    0,   0,   0,    11,   4,      0,   0x0006,   0xff00},		//IPv6-TCP
	 {1,    262,    0,   0,   0,    11,   5,      0,   0x0011,   0xff00},		//IPv6-UDP
	 {1,    266,    0,   0,   0,    11,   6,      0,   0x0000,   0xffff},		//IPv6-Others
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};


// Node11 - LastNode. Updates Side-band signals
cle_ptree_dn_t ptram_dn11_lite =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    1,      1,   0,   0,	0,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    0,      0,   0,   0,    127,  0,      0,   0x0000,   0xffff},		//Non-IP
	 {1,    0,      0,   0,   0,    127,  1,      0,   0x0000,   0xffff},		//IPv4-TCP
	 {1,    0,      0,   0,   0,    127,  2,      0,   0x0000,   0xffff},		//IPv4-UDP
	 {1,    0,      0,   0,   0,    127,  3,      0,   0x0000,   0xffff},		//IPv4-Others
	 {1,    0,      0,   0,   0,    127,  4,      0,   0x0000,   0xffff},		//IPv6-UDP
	 {1,    0,      0,   0,   0,    127,  5,      0,   0x0000,   0xffff},		//IPv6-Others
	 {1,    0,      0,   0,   0,    127,  6,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};

/*=================================*/
/*==========  Node Array ==========*/
/*=================================*/

/* STEP 2 - insert the node into array */

/*---------------------------------------------------------------------------------*/
cle_cfg_ptram_dn ptram_dn_lite[] =
{
		{0,  (cle_ptree_dn_t*)&ptram_dn0_lite},
		{1,  (cle_ptree_dn_t*)&ptram_dn1_lite},
		{2,  (cle_ptree_dn_t*)&ptram_dn2_lite},
		{3,  (cle_ptree_dn_t*)&ptram_dn3_lite},
		{4,  (cle_ptree_dn_t*)&ptram_dn4_lite},
		{11, (cle_ptree_dn_t*)&ptram_dn11_lite},
};

/*=================================*/
/*====== Keynote Define  ==========*/
/*=================================*/

/* STEP 3 */

/*---------------------------------------------------------------------------------*/
// KN (KeyNode)   : 0->2 ( [0: Invalid Node], [1: Key Node], [2: Decision Node]
// P (Priority)   : 0->7 (0: Lowest, 7: highest)
// RAdr(Result address): 0->1024: This is a Result Pointer point a entry in DBRAM.
// R: Reserved.

//Key Index Classification:
//0-Non-IP, 1-IPv4, 2-IPv6
cle_ptree_keynote_t ptram_kn127_lite =
{
	//KN, R
	  1, 0,
	//P,   RAdr, R     P,   RAdr, R     P,   RAdr, R    P,   RAdr, R
	{{2,   1,    0},  {2,   2,    0},  {2,   3,    0},  {2,   4,    0},
	 {2,   5,    0},  {2,   6,    0},  {2,   7,    0},  {0,   0,    0},
	 {0,   0,    0},  {0,   0,    0},  {0,   0,    0},  {0,   0,    0},
	 {0,   0,    0},  {0,   0,    0},  {0,   0,    0},  {0,   0,    0},
	 {0,   0,    0},  {0,   0,    0},  {0,   0,    0},  {0,   0,    0},
	 {0,   0,    0},  {0,   0,    0},  {0,   0,    0},  {0,   0,    0},
	 {0,   0,    0},  {0,   0,    0},  {0,   0,    0},  {0,   0,    0},
	 {0,   0,    0},  {0,   0,    0},  {0,   0,    0},  {0,   0,    0}}
};

/*=================================*/
/*========= Keynote Array =========*/
/*=================================*/

/* STEP 4 - Insert the Keynote into array*/

/*---------------------------------------------------------------------------------*/
cle_cfg_ptram_kn ptram_kn_lite[] =
{		//Nodeindex				//node
		{127,                   (cle_ptree_keynote_t*) &ptram_kn127_lite}
};

/*===================================================================================*/
/*========== Set start node to parser0, synthesis Decision node and Keynode ==========*/
/*===================================================================================*/

/* STEP 5 - Set start node, Synthesis Decision node and Keynode */

/*---------------------------------------------------------------------------------*/
cle_cfg_ptram_t ptram_cfg_lite =
{
		0,						//Start node 0
		CLE_VAL_NONE,			//Don't care
		CLE_VAL_NONE,			//Don't care
		sizeof(ptram_dn_lite)/sizeof(cle_cfg_ptram_dn),
		sizeof(ptram_kn_lite)/sizeof(cle_cfg_ptram_kn),
		ptram_dn_lite,
		ptram_kn_lite
};

/*===================================================================================================*/
/*============== DEFINE DATA BASE RESULT OF CLE LITE ================================================*/
/*===================================================================================================*/

/* STEP 6 -Define Hinfo in entries of DBRAM*/

cle_eth_mode_t 	cle_def_eth_mode_lite[] =
{
//	TCPH  IPH  eH    MSS  EC   TSO  PRO  IPV  RV3  RV5  VLAN  CRC  RV8  TYPE RV10  RV38/TST
	{0x0, 0x0, 0xe,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// NONE-IP
	{0x5, 0x5, 0xe,  0x0, 0x1, 0x0, 0x1, 0x0, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP4-20B-TCP
	{0x2, 0x5, 0xe,  0x0, 0x1, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP4-20B-UDP
	{0x0, 0x5, 0xe,  0x0, 0x1, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP4-20B-Others
	{0x5, 0xa, 0xe,  0x0, 0x1, 0x0, 0x1, 0x1, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP6-40B-TCP
	{0x2, 0xa, 0xe,  0x0, 0x1, 0x0, 0x0, 0x1, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP6-40B-UDP
	{0x0, 0xa, 0xe,  0x0, 0x1, 0x0, 0x0, 0x1, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP6-40B-others
#if 0
	{0x5, 0x8, 0xe,  0x0, 0x1, 0x0, 0x1, 0x0, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP4-32B-TCP
	{0x2, 0x8, 0xe,  0x0, 0x1, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP4-32B-UDP
	{0x0, 0x8, 0xe,  0x0, 0x1, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP4-32B-Others
	{0x5, 0xc, 0xe,  0x0, 0x1, 0x0, 0x1, 0x1, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP6-48B-TCP
	{0x2, 0xc, 0xe,  0x0, 0x1, 0x0, 0x0, 0x1, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP6-48B-UDP
	{0x0, 0xc, 0xe,  0x0, 0x1, 0x0, 0x0, 0x1, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP6-48B-Others
#endif

#if 0	//VLAN
//	TCPH  IPH  eH    MSS  EC   TSO  PRO  IPV  RV3  RV5  VLAN  CRC  RV8  TYPE RV10  RV38/TST
	{0x0, 0x0, 0x12, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// NONE-IP
	{0x5, 0x5, 0x12, 0x0, 0x1, 0x0, 0x1, 0x0, 0x0, 0x0, 0x1,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP4-20B-TCP-VLAN
	{0x2, 0x5, 0x12, 0x0, 0x1, 0x0, 0x0, 0x0, 0x0, 0x0, 0x1,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP4-20B-UDP-VLAN
	{0x0, 0x5, 0x12, 0x0, 0x1, 0x0, 0x0, 0x0, 0x0, 0x0, 0x1,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP4-20B-Others-VLAN
	{0x5, 0xa, 0x12, 0x0, 0x1, 0x0, 0x1, 0x1, 0x0, 0x0, 0x1,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP6-40B-TCP-VLAN
	{0x2, 0xa, 0x12, 0x0, 0x1, 0x0, 0x0, 0x1, 0x0, 0x0, 0x1,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP6-40B-UDP-VLAN
	{0x0, 0xa, 0x12, 0x0, 0x1, 0x0, 0x0, 0x1, 0x0, 0x0, 0x1,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP6-40B-others-VLAN
	{0x5, 0x8, 0x12, 0x0, 0x1, 0x0, 0x1, 0x0, 0x0, 0x0, 0x1,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP4-32B-TCP-VLAN
	{0x2, 0x8, 0x12, 0x0, 0x1, 0x0, 0x0, 0x0, 0x0, 0x0, 0x1,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP4-32B-UDP-VLAN
	{0x0, 0x8, 0x12, 0x0, 0x1, 0x0, 0x0, 0x0, 0x0, 0x0, 0x1,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP4-32B-Others-VLAN
	{0x5, 0xc, 0x12, 0x0, 0x1, 0x0, 0x1, 0x1, 0x0, 0x0, 0x1,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP6-48B-TCP-VLAN
	{0x2, 0xc, 0x12, 0x0, 0x1, 0x0, 0x0, 0x1, 0x0, 0x0, 0x1,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP6-48B-UDP-VLAN
	{0x0, 0xc, 0x12, 0x0, 0x1, 0x0, 0x0, 0x1, 0x0, 0x0, 0x1,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP6-48B-Others-VLAN
#endif
};

/*===================================================================================================*/

/* STEP 7 - Define array of entries in DBram, have insert HInfo from step 6*/

/*===================================================================================================*/
//- Entry : Number of Entry in DBRAM. It's get from cle_eth_mode_t 	cle_def_eth_mode_2inline[];
//- HINFO : Define structure HINFO to this entry.
//- FP, DES, HENQ: Freepoll slot, destination's qid, henqnum's qid in dbram at this entry which CLE use to enqueue when 'E' is enabled (E = 1).
//- E : Enable write FP, DES, HENQ to this entry in DBRAM
//	+ 0: Disable : FP slot, dest's id, henqnum's id are writen this entry in dbram which is get from enq_qids{fp, dst, henq}
//		of function cle_until(port, enq_qids )
//	+ 1: Enable: FP slot, dest's id, henqnum's id are write this entry in dbram whict is get from the fields : FP, DES, HENQ of
//	   structure "cle_def_dbram_t"
//-  flow,  group, P : are the field perflow, flowgroup, priority in dbram, when want modify to test, change these values.
cle_def_dbram_t cle_def_db_lite[] =
{
//   Entry                Hinfo                       FP  Des Henq E   flow  group P
	{1,  (cle_eth_mode_t*)&cle_def_eth_mode_lite[0],  {0, 74, 74}, 0, {0x15, 0xa, 0x2} },
	{2,  (cle_eth_mode_t*)&cle_def_eth_mode_lite[1],  {0, 74, 74}, 0, {0x15, 0xa, 0x2} },
	{3,  (cle_eth_mode_t*)&cle_def_eth_mode_lite[2],  {0, 74, 74}, 0, {0x15, 0xa, 0x2} },
	{4,  (cle_eth_mode_t*)&cle_def_eth_mode_lite[3],  {0, 74, 74}, 0, {0x15, 0xa, 0x2} },
	{5,  (cle_eth_mode_t*)&cle_def_eth_mode_lite[4],  {0, 74, 74}, 0, {0x15, 0xa, 0x2} },
	{6,  (cle_eth_mode_t*)&cle_def_eth_mode_lite[5],  {0, 74, 74}, 0, {0x15, 0xa, 0x2} },
	{7,  (cle_eth_mode_t*)&cle_def_eth_mode_lite[6],  {0, 74, 74}, 0, {0x15, 0xa, 0x2} },


};

/*===================================================================================================*/

/* STEP 8 - Synthesis DBRam */

/*===================================================================================================*/
cle_cfg_dbram_t cle_cfg_db_lite =
{
	sizeof(cle_def_db_lite)/sizeof(cle_def_dbram_t),
	cle_def_db_lite
};

/*===================================================================================================*/
#endif






/*===================================================================================================*/
/*  CONFIGURED CLE_2INLINE*/
/*===================================================================================================*/

/*=================================*/
/*==========  USER NOTE  ==========*/
/*=================================*/
/*
	1. User need to define node.  Before is the example of define node #0, 16, 1, 2, 3, 4, 11, 12, and 13.
	2. After defining the node, insert the node into "cle_cfg_ptram_dn ptram_dn_2inline[]" array.
	3. Define the Keynote
	4. Insert the Keynote into the "cle_cfg_ptram_kn ptram_kn_2inline[]" array.
	5. Set start node to parser0, parser1, Synthesis Decision node and Keynode in "cle_cfg_ptram_t ptram_cfg_2inline"
	6. Define array of HInfo field in entries of DBRAM.
	7. Define array of entries in DBram, have insert HInfo from step 6.
	8. Synthesis DBRam in "cle_cfg_dbram_t cle_cfg_db_2inline"
	9. Insert configure table of PTram and DBram (ptram_cfg_2inline, cle_cfg_db_2inline) to "cle_cfg_pt_db_t cle_cfg_pt_db[]" array.

*/

/*=================================*/
/*========== Define Node ==========*/
/*=================================*/

/* STEP 1 */

#if CLE_2INLINE_ENABLE

/*---------------------------------------------------------------------------------*/
// DN  (Node type - 2bits)   : 0->3  ([ 0: Invalid Node],  [1: Key Node],  [2 : Decision Node], [3: Reserved]
// LN  (Last Node - 1bits)   : 0->1  ([ 0: Start/Middle Node],   [1: Last node]
// HS  (Header Store)	     : 0->3  ([ 0: Not store],   [1 : Store byte 0],   [2: Store byte],     [3: Store both Bytes])
// HE  (Header Extract- 2bit): 0->3  ([ 0: Not extract], [1 : extract byte 0], [2: extract byte 1], [3: Extract Both Bytes])
// BS  (Byte Store - 2bits)  : 0->3  ([ 0: Not store],   [1 : Store byte 0],   [2: Store byte],     [3: Store both Bytes])
// SBS (Search Byte Store)   : 0->3  ([ 0: Not store],   [1 : Store byte 0],   [2: Store byte], 	[3: Store both Bytes])
// DefPtr :  Default Result Pointer to read out the Result/DB RAM.
// V   (Valid branch)		 : 0->1  ([1b0  = 0: branch not valid ],[1b1  = 1: branch valid]
// P2B (Pointer 2 Byte)		 : Pointer point to 2byte in incoming packet that used to compare with CMPDATA
// jr  (Relative Jump)		 : 0->1  ([0 Next 2-Byte Data/Packet Pointer] is an absolute pointer)
//							 : 		 ([1 Next 2-Byte Data/Packet Pointer] relative to the Pointer of the previous node)
// jb  (Jump Backward)		 : It is only meaningful if �Relative Jump� is set to 1
//							  0->1
//                            0 : the Next 2-Byte Data Pointer will be used to add to the Pointer of the previous node
//                            1: Next 2 -Byte Data Pointer will be used to subtract from the Pointer of the previous node
// Op (operation_type - 3bit) : 0->5) ([0: Equal], [1: Not Equal], [2: Less than Equal], [3: Greater than Equal], [4: Bitwise AND]), [5: Bitwise NAND]
// Node ()
// CMPDAT (Compare Data)	: Is stored in PTRAM and used to compared with 2byte in incoming packet is pointed in P2B.
// R    (Reserved)
//-----------------------------------------------------------------------------
// Node0 - Checks MAC Destination Address
//

// Node0 - Checks MAC Destination Address
cle_ptree_dn_t	ptram_dn0_2inline =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    0,      0,   0,   0,	0,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    4,      0,   1,   0,    0,     1,      0,   0x0000,   0x0000},
	 {1,    2,      0,   1,   0,    0,     2,      0,   0x0000,   0x0000},
	 {1,    2,      0,   1,   0,    0,     3,      0,   0x0000,   0x0000},
     {1,    0,      0,   1,   0,    16,    0,      0,   0x0100,   0x0000},
	 {1,    0,      0,   1,   0,    16,    0,      0,   0x0200,   0x0000},
     {1,    0,      0,   1,   0,    16,    0,      0,   0x0300,   0x0000},
	 {1,    0,      0,   1,   0,    16,    0,      0,   0x0400,   0x0000},
	 {0,    0,      0,   0,   0,    0,     0,      0,   0x0000,   0xffff}}
};

cle_ptree_dn_t	ptram_dn16_2inline =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    0,      0,   0,   0,	0,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    4,      0,   1,   0,    16,    1,      0,   0x0000,   0x0000},
     {1,    0,      0,   1,   0,    1,     0,      0,   0x0100,   0x0000},
	 {1,    0,      0,   1,   0,    1,     1,      0,   0x0200,   0x0000},
     {1,    0,      0,   1,   0,    1,     2,      0,   0x0300,   0x0000},
	 {1,    0,      0,   1,   0,    1,     3,      0,   0x0400,   0x0000},
	 {0,    0,      0,   0,   0,    0,     0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,     0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,     0,      0,   0x0000,   0xffff}}
};


cle_ptree_dn_t	ptram_dn1_2inline =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    1,      0,   0,   0,	0,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    0,      0,   1,   0,    11,    0,      0,   0x0000,   0xffff},
	 {1,    0,      0,   1,   0,    11,    1,      0,   0x0000,   0xffff},
	 {1,    0,      0,   1,   0,    11,    2,      0,   0x0000,   0xffff},
	 {1,    0,      0,   1,   0,    11,    3,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};


/*=================================*/
/*==========  Node Array ==========*/
/*=================================*/

/* STEP 2 - insert the node into array */

/*---------------------------------------------------------------------------------*/
cle_cfg_ptram_dn ptram_dn_2inline[] =
{
		{0,		(cle_ptree_dn_t*)&ptram_dn0_2inline},
		{16,		(cle_ptree_dn_t*)&ptram_dn16_2inline},
		{1,		(cle_ptree_dn_t*)&ptram_dn1_2inline}
		}; 

/*=================================*/
/*====== Keynote Define  ==========*/
/*=================================*/

/* STEP 3 */

/*---------------------------------------------------------------------------------*/
// KN (KeyNode)   : 0->2 ( [0: Invalid Node], [1: Key Node], [2: Decision Node]
// P (Priority)   : 0->7 (0: Lowest, 7: highest)
// RAdr(Result address): 0->1024: This is a Result Pointer point a entry in DBRAM.
// R: Reserved.
//----------------------------------------------------
// Node11 - Key Node
// Port0
//Key Index Classification:
//DA
cle_ptree_keynote_t ptram_kn11_2inline =
{
	//KN, R
	  1, 0,
	//P,   RAdr, R     P,   RAdr, R     P,   RAdr, R    P,   RAdr, R
	{{2,   1,    0},  {2,   2,    0},  {2,   3,    0},  {2,   4,    0},
	 {0,   0,    0},  {0,   0,    0},  {0,   0,    0},  {0,   0,    0},
	 {0,   0,    0},  {0,   0,    0},  {0,   0,    0},  {0,   0,    0},
	 {0,   0,    0},  {0,   0,    0},  {0,   0,    0},  {0,   0,    0},
	 {0,   0,    0},  {0,   0,    0},  {0,   0,    0},  {0,   0,    0},
	 {0,   0,    0},  {0,   0,    0},  {0,   0,    0},  {0,   0,    0},
	 {0,   0,    0},  {0,   0,    0},  {0,   0,    0},  {0,   0,    0},
	 {0,   0,    0},  {0,   0,    0},  {0,   0,    0},  {0,   0,    0}}
};

/*=================================*/
/*========= Keynote Array =========*/
/*=================================*/

/* STEP 4 - Insert the Keynote into array*/

/*---------------------------------------------------------------------------------*/
cle_cfg_ptram_kn ptram_kn_2inline[] =
{
		{11, 	(cle_ptree_keynote_t*)&ptram_kn11_2inline}
};
/*===================================================================================*/
/*========== Set start node to parser0, synthesis Decision node and Keynode ==========*/
/*===================================================================================*/
/* STEP 5  */

/*---------------------------------------------------------------------------------*/
cle_cfg_ptram_t ptram_cfg_2inline =
{
		0,						//start node 0
	    CLE_VAL_NONE,
        CLE_VAL_NONE,			//don't care
		sizeof(ptram_dn_2inline)/sizeof(cle_cfg_ptram_dn),
		sizeof(ptram_kn_2inline)/sizeof(cle_cfg_ptram_kn),
		ptram_dn_2inline,
		ptram_kn_2inline
};

/*===================================================================================================*/
/*============== DEFINE DATA BASE RESULT OF CLE 2INLINE =============================================*/
/*===================================================================================================*/

/* STEP 6 -Define Hinfo in entries of DBRAM*/

/*===================================================================================================*/

cle_eth_mode_t 	cle_def_eth_mode_2inline[] =
{
	//from parser 0
//	TCPH  IPH  eH    MSS  EC   TSO  PRO  IPV  RV3  RV5  VLAN  CRC  RV8  TYPE RV10  RV38/TST
	{0x0, 0x0, 0xe,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// NONE-IP
	{0x0, 0x0, 0xe,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// NONE-IP
	{0x0, 0x0, 0xe,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// NONE-IP
	{0x0, 0x0, 0xe,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0}	// NONE-IP
};


/*===================================================================================================*/

/* STEP 7 - Define array of entries in DBram, have insert HInfo from step 6*/

/*===================================================================================================*/
//- Entry : Number of Entry in DBRAM. It's get from cle_eth_mode_t 	cle_def_eth_mode_2inline[];
//- HINFO : Define structure HINFO to this entry.
//- FP, DES, HENQ: Freepoll slot, destination's qid, henqnum's qid in dbram at this entry which CLE use to enqueue when 'E' is enabled (E = 1).
//- E : Enable write FP, DES, HENQ to this entry in DBRAM
//	+ 0: Disable : FP slot, dest's id, henqnum's id are writen this entry in dbram which is get from enq_qids{fp, dst, henq}
//		of function cle_until(port, enq_qids )
//	+ 1: Enable: FP slot, dest's id, henqnum's id are write this entry in dbram whict is get from the fields : FP, DES, HENQ of
//	   structure "cle_def_dbram_t"
//-  flow,  group, P : are the field perflow, flowgroup, priority in dbram, when want modify to test, change these values.

cle_def_dbram_t cle_def_db_2inline[] =
{
//	Entry					HINFO                        FP  DES HENQ E  flow group  P
	{1,  (cle_eth_mode_t*)&cle_def_eth_mode_2inline[0],  {0, 32, 32}, 1, {0x0, 0x0, 0x0} },
	{2,  (cle_eth_mode_t*)&cle_def_eth_mode_2inline[1],  {1, 33, 33}, 1, {0x0, 0x0, 0x0} },
	{3,  (cle_eth_mode_t*)&cle_def_eth_mode_2inline[2],  {2, 34, 34}, 1, {0x0, 0x0, 0x0} },
	{4,  (cle_eth_mode_t*)&cle_def_eth_mode_2inline[3],  {3, 35, 35}, 1, {0x0, 0x0, 0x0} }
	                                                           
};
/*===================================================================================================*/

/* STEP 8 - Synthesis DBRam */
/*===================================================================================================*/
cle_cfg_dbram_t cle_cfg_db_2inline =
{
	sizeof(cle_def_db_2inline)/sizeof(cle_def_dbram_t),
	cle_def_db_2inline
};

#endif

/*===================================================================================================*/
/*Define PTRAM of CLE 3INLINE*/
/*===================================================================================================*/
#if CLE_3INLINE_ENABLE
// Node0 - Checks MAC Destination Address
cle_ptree_dn_t	ptram_dn0_3inline =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    0,      0,   0,   0,	0,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    4,      0,   1,   0,    0,    1,      0,   0x0000,   0x0000},
     {1,    0,      0,   1,   0,    1,    0,      0,   0x0100,   0x0000},
     {1,    0,      0,   1,   0,    1,    1,      0,   0x0200,   0x0000},
     {1,    0,      0,   1,   0,    1,    2,      0,   0x0300,   0x0000},
	 {1,    0,      0,   1,   0,    1,    3,      0,   0x0400,   0x0000},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};


cle_ptree_dn_t	ptram_dn1_3inline =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    1,      0,   0,   0,	0,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    0,      0,   1,   0,    11,    0,      0,   0x0000,   0xffff},
	 {1,    0,      0,   1,   0,    11,    1,      0,   0x0000,   0xffff},
	 {1,    0,      0,   1,   0,    11,    2,      0,   0x0000,   0xffff},
	 {1,    0,      0,   1,   0,    11,    3,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};


/*=================================*/
/*==========  Node Array ==========*/
/*=================================*/

/* STEP 2 - insert the node into array */

/*---------------------------------------------------------------------------------*/
cle_cfg_ptram_dn ptram_dn_3inline[] =
{
		{0,		(cle_ptree_dn_t*)&ptram_dn0_3inline},
		{1,		(cle_ptree_dn_t*)&ptram_dn1_3inline}
		}; 

/*=================================*/
/*====== Keynote Define  ==========*/
/*=================================*/

/* STEP 3 */

/*---------------------------------------------------------------------------------*/
// KN (KeyNode)   : 0->2 ( [0: Invalid Node], [1: Key Node], [2: Decision Node]
// P (Priority)   : 0->7 (0: Lowest, 7: highest)
// RAdr(Result address): 0->1024: This is a Result Pointer point a entry in DBRAM.
// R: Reserved.
//----------------------------------------------------
// Node11 - Key Node
// Port0
//Key Index Classification:
//DA
cle_ptree_keynote_t ptram_kn11_3inline =
{
	//KN, R
	  1, 0,
	//P,   RAdr, R     P,   RAdr, R     P,   RAdr, R    P,   RAdr, R
	{{2,   1,    0},  {2,   2,    0},  {2,   3,    0},  {2,   4,    0},
	 {0,   0,    0},  {0,   0,    0},  {0,   0,    0},  {0,   0,    0},
	 {0,   0,    0},  {0,   0,    0},  {0,   0,    0},  {0,   0,    0},
	 {0,   0,    0},  {0,   0,    0},  {0,   0,    0},  {0,   0,    0},
	 {0,   0,    0},  {0,   0,    0},  {0,   0,    0},  {0,   0,    0},
	 {0,   0,    0},  {0,   0,    0},  {0,   0,    0},  {0,   0,    0},
	 {0,   0,    0},  {0,   0,    0},  {0,   0,    0},  {0,   0,    0},
	 {0,   0,    0},  {0,   0,    0},  {0,   0,    0},  {0,   0,    0}}
};

/*=================================*/
/*========= Keynote Array =========*/
/*=================================*/

/* STEP 4 - Insert the Keynote into array*/

/*---------------------------------------------------------------------------------*/
cle_cfg_ptram_kn ptram_kn_3inline[] =
{
		{11, 	(cle_ptree_keynote_t*)&ptram_kn11_3inline}
};
/*===================================================================================*/
/*========== Set start node to parser0, synthesis Decision node and Keynode ==========*/
/*===================================================================================*/
/* STEP 5  */

/*---------------------------------------------------------------------------------*/
cle_cfg_ptram_t ptram_cfg_3inline =
{
		0,						//start node 0
	    CLE_VAL_NONE,
        CLE_VAL_NONE,			//don't care
		sizeof(ptram_dn_3inline)/sizeof(cle_cfg_ptram_dn),
		sizeof(ptram_kn_3inline)/sizeof(cle_cfg_ptram_kn),
		ptram_dn_3inline,
		ptram_kn_3inline
};

/*===================================================================================================*/
/*============== DEFINE DATA BASE RESULT OF CLE 3INLINE =============================================*/
/*===================================================================================================*/

/* STEP 6 -Define Hinfo in entries of DBRAM*/

/*===================================================================================================*/

cle_eth_mode_t 	cle_def_eth_mode_3inline[] =
{
	//from parser 0
//	TCPH  IPH  eH    MSS  EC   TSO  PRO  IPV  RV3  RV5  VLAN  CRC  RV8  TYPE RV10  RV38/TST
	{0x0, 0x0, 0xe,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// NONE-IP
	{0x0, 0x0, 0xe,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// NONE-IP
	{0x0, 0x0, 0xe,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// NONE-IP
	{0x0, 0x0, 0xe,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0}	// NONE-IP
};


/*===================================================================================================*/

/* STEP 7 - Define array of entries in DBram, have insert HInfo from step 6*/

/*===================================================================================================*/
//- Entry : Number of Entry in DBRAM. It's get from cle_eth_mode_t 	cle_def_eth_mode_3inline[];
//- HINFO : Define structure HINFO to this entry.
//- FP, DES, HENQ: Freepoll slot, destination's qid, henqnum's qid in dbram at this entry which CLE use to enqueue when 'E' is enabled (E = 1).
//- E : Enable write FP, DES, HENQ to this entry in DBRAM
//	+ 0: Disable : FP slot, dest's id, henqnum's id are writen this entry in dbram which is get from enq_qids{fp, dst, henq}
//		of function cle_until(port, enq_qids )
//	+ 1: Enable: FP slot, dest's id, henqnum's id are write this entry in dbram whict is get from the fields : FP, DES, HENQ of
//	   structure "cle_def_dbram_t"
//-  flow,  group, P : are the field perflow, flowgroup, priority in dbram, when want modify to test, change these values.

cle_def_dbram_t cle_def_db_3inline[] =
{
//	Entry					HINFO                        FP  DES HENQ E  flow group  P
	{1,  (cle_eth_mode_t*)&cle_def_eth_mode_3inline[0],  {0, 32, 32}, 1, {0x0, 0x0, 0x0} },
	{2,  (cle_eth_mode_t*)&cle_def_eth_mode_3inline[1],  {1, 33, 33}, 1, {0x0, 0x0, 0x0} },
	{3,  (cle_eth_mode_t*)&cle_def_eth_mode_3inline[2],  {0, 32, 32}, 1, {0x0, 0x0, 0x0} },
	{4,  (cle_eth_mode_t*)&cle_def_eth_mode_3inline[3],  {1, 33, 33}, 1, {0x0, 0x0, 0x0} }
	                                                           
};
/*===================================================================================================*/

/* STEP 8 - Synthesis DBRam */
/*===================================================================================================*/
cle_cfg_dbram_t cle_cfg_db_3inline =
{
	sizeof(cle_def_db_3inline)/sizeof(cle_def_dbram_t),
	cle_def_db_3inline
};
#endif

/*===================================================================================================*/
/*===================================================================================================*/
/*Define database of CLE_LOOK-ASIDE*/
/*===================================================================================================*/
#if CLE_LOOKASIDE_ENABLE


/*=================================*/
/*==========  USER NOTE  ==========*/
/*=================================*/
/*
	1. User need to define node.
	2. After defining the node, insert the node into "cle_cfg_ptram_dn ptram_dn_la[]" array.
	3. Define the Keynote
	4. Insert the Keynote into the "cle_cfg_ptram_kn ptram_kn_la[]" array.
	5. Set start node to paser2, Synthesis Decision node and Keynode in "cle_cfg_ptram_t ptram_cfg_la"
	6. Define array of HInfo field in entries of DBRAM.
	7. Define array of entries in DBram, have insert HInfo from step 6.
	8. Synthesis DBRam in "cle_cfg_dbram_t cle_cfg_db_la"
	9. Insert configure table of PTram and DBram (ptram_cfg_la, cle_cfg_db_la) to "cle_cfg_pt_db_t cle_cfg_pt_db[]" array.

*/

/*=================================*/
/*========== Define Node ==========*/
/*=================================*/

/* STEP 1 */


/*---------------------------------------------------------------------------------*/
// DN  (Node type - 2bits)   : 0->3  ([ 0: Invalid Node],  [1: Key Node],  [2 : Decision Node], [3: Reserved]
// LN  (Last Node - 1bits)   : 0->1  ([ 0: Start/Middle Node],   [1: Last node]
// HS  (Header Store)	     : 0->3  ([ 0: Not store],   [1 : Store byte 0],   [2: Store byte],     [3: Store both Bytes])
// HE  (Header Extract- 2bit): 0->3  ([ 0: Not extract], [1 : extract byte 0], [2: extract byte 1], [3: Extract Both Bytes])
// BS  (Byte Store - 2bits)  : 0->3  ([ 0: Not store],   [1 : Store byte 0],   [2: Store byte],     [3: Store both Bytes])
// SBS (Search Byte Store)   : 0->3  ([ 0: Not store],   [1 : Store byte 0],   [2: Store byte], 	[3: Store both Bytes])
// DefPtr :  Default Result Pointer to read out the Result/DB RAM.
// V   (Valid branch)		 : 0->1  ([1b0  = 0: branch not valid ],[1b1  = 1: branch valid]
// P2B (Pointer 2 Byte)		 : Pointer point to 2byte in incoming packet that used to compare with CMPDATA
// jr  (Relative Jump)		 : 0->1  ([0 Next 2-Byte Data/Packet Pointer] is an absolute pointer)
//							 : 		 ([1 Next 2-Byte Data/Packet Pointer] relative to the Pointer of the previous node)
// jb  (Jump Backward)		 : It is only meaningful if �Relative Jump� is set to 1
//							  0->1
//                            0 : the Next 2-Byte Data Pointer will be used to add to the Pointer of the previous node
//                            1: Next 2 -Byte Data Pointer will be used to subtract from the Pointer of the previous node
// Op (operation_type - 3bit) : 0->5) ([0: Equal], [1: Not Equal], [2: Less than Equal], [3: Greater than Equal], [4: Bitwise AND]), [5: Bitwise NAND]
// Node ()
// CMPDAT (Compare Data)	: Is stored in PTRAM and used to compared with 2byte in incoming packet is pointed in P2B.
// R    (Reserved)

cle_ptree_dn_t 	ptram_dn0_la =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    0,      0,   0,   2,	0,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    2,      0,   1,   0,    0,    1,      0,   0x1100,   0xffff},
	 {1,    2,      0,   1,   0,    0,    2,      0,   0x3322,   0xffff},
	 {1,    8,      0,   1,   0,    1,    0,      0,   0x5544,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};

/*---------------------------------------------------------------------------------*/
// Node1 - Checks for VLAN Tag + EtherType
cle_ptree_dn_t 	ptram_dn1_la =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    0,      0,   0,   0,	3,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    4,      0,   1,   0,    1,    4,      0,   0x0081,   0x0000},		//VLAN Tag
	 {1,    14,     0,   1,   0,    3,    0,      0,   0x0008,   0x0000},		//IPv4
	 {1,    10,     0,   1,   0,    5,    0,      0,   0xdd86,   0x0000},		//IPv6
	 {1,    380,    0,   0,   0,    95,   0,      0,   0x0000,   0xffff},		//Non-IP
	 {1,    14,     0,   1,   0,    3,    4,      0,   0x0008,   0x0000},		//IPv4
	 {1,    10,     0,   1,   0,    5,    4,      0,   0xdd86,   0x0000},		//IPv6
	 {1,    382,    0,   0,   0,    95,   4,      0,   0x0000,   0xffff},		//Non-IP
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};

/*---------------------------------------------------------------------------------*/
// Node2 - Checks CoS
cle_ptree_dn_t 	ptram_dn2_la =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    0,      0,   3,   0,	1,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    6,      0,   1,   0,    12,   0,      0,   0x0080,   0xff0f},		//IPv4-32B
	 {1,    6,      0,   1,   0,    7,    0,      0,   0x0000,   0xffff},		//IPv4-20B
	 {1,    6,      0,   1,   0,    10,   0,      0,   0x0000,   0xffff},		//IPv6
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {1,    6,      0,   1,   0,    12,   4,      0,   0x0080,   0xff0f},		//IPv4-32B
	 {1,    6,      0,   1,   0,    7,    4,      0,   0x0000,   0xffff},		//IPv4-20B
	 {1,    6,      0,   1,   0,    10,   4,      0,   0x0000,   0xffff},		//IPv6
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};

/*---------------------------------------------------------------------------------*/
// Node3 - Checks Source IPv4 Address bytes
cle_ptree_dn_t 	ptram_dn3_la =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    0,      0,   0,   0,	0,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    2,      0,   1,   0,    3,    1,      0,   0x0000,   0xffff},		//SimpleMAC
	 {1,    2,      0,   1,   0,    4,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {1,    2,      0,   1,   0,    3,    5,      0,   0x0000,   0xffff},		//MAC+1VLAN
	 {1,    2,      0,   1,   0,    4,    4,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};

/*---------------------------------------------------------------------------------*/
// Node4 - Checks Destination IPv4 Address bytes
cle_ptree_dn_t 	ptram_dn4_la =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    0,      0,   0,   0,	0,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    2,      0,   1,   0,    4,    1,      0,   0x0000,   0xffff},		//SimpleMAC
	 {1,    18,     1,   0,   0,    2,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {1,    2,      0,   1,   0,    4,    5,      0,   0x0000,   0xffff},		//MAC+1VLAN
	 {1,    18,     1,   0,   0,    2,    4,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};

/*---------------------------------------------------------------------------------*/
// Node5 - Checks Source IPv6 Address bytes
cle_ptree_dn_t 	ptram_dn5_la =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    0,      0,   0,   0,	0,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    2,      0,   1,   0,    5,    1,      0,   0x0000,   0xffff},		//SimpleMAC
	 {1,    2,      0,   1,   0,    5,    2,      0,   0x0000,   0xffff},
	 {1,    2,      0,   1,   0,    5,    3,      0,   0x0000,   0xffff},
	 {1,    10,     0,   1,   0,    6,    0,      0,   0x0000,   0xffff},
	 {1,    2,      0,   1,   0,    5,    5,      0,   0x0000,   0xffff},		//MAC+1VLAN
	 {1,    2,      0,   1,   0,    5,    6,      0,   0x0000,   0xffff},
	 {1,    2,      0,   1,   0,    5,    7,      0,   0x0000,   0xffff},
	 {1,    10,     0,   1,   0,    6,    4,      0,   0x0000,   0xffff}}
};

/*---------------------------------------------------------------------------------*/
// Node6 - Checks Destination IPv6 Address bytes
cle_ptree_dn_t 	ptram_dn6_la =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    0,      0,   0,   0,	0,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    2,      0,   1,   0,    6,    1,      0,   0x0000,   0xffff},		//SimpleMAC
	 {1,    2,      0,   1,   0,    6,    2,      0,   0x0000,   0xffff},
	 {1,    2,      0,   1,   0,    6,    3,      0,   0x0000,   0xffff},
	 {1,    30,     1,   0,   0,    2,    2,      0,   0x0000,   0xffff},
	 {1,    2,      0,   1,   0,    6,    5,      0,   0x0000,   0xffff},		//MAC+1VLAN
	 {1,    2,      0,   1,   0,    6,    6,      0,   0x0000,   0xffff},
	 {1,    2,      0,   1,   0,    6,    7,      0,   0x0000,   0xffff},
	 {1,    30,     1,   0,   0,    2,    6,      0,   0x0000,   0xffff}}
};

/*---------------------------------------------------------------------------------*/
// Node7 - Checks for IPv4-20B Packet Fragmentation
cle_ptree_dn_t 	ptram_dn7_la =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    0,      0,   0,   0,	0,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    2,      0,   1,   4,    8,    0,      0,   0xfffc,   0x0003},		//SimpleMAC
	 {1,    2,      0,   1,   0,    9,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {1,    2,      0,   1,   4,    8,    4,      0,   0xfffc,   0x0003},		//MAC+1VLAN
	 {1,    2,      0,   1,   0,    9,    4,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};

/*---------------------------------------------------------------------------------*/
// Node8 - Checks for IPv4-20B(Fragmented) Protocol
cle_ptree_dn_t 	ptram_dn8_la =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    0,      0,   0,   0,	2,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    268,    0,   0,   0,    94,   0,      0,   0x0600,   0x00ff},		//TCP
	 {1,    272,    0,   0,   0,    93,   0,      0,   0x1100,   0x00ff},		//UDP
	 {1,    276,    0,   0,   0,    92,   0,      0,   0x0000,   0xffff},		//Others
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {1,    270,    0,   0,   0,    94,   4,      0,   0x0600,   0x00ff},		//TCP
	 {1,    274,    0,   0,   0,    93,   4,      0,   0x1100,   0x00ff},		//UDP
	 {1,    278,    0,   0,   0,    92,   4,      0,   0x0000,   0xffff},		//Others
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};

/*---------------------------------------------------------------------------------*/
// Node9 - Checks for IPv4-20B(Unfragmented) Protocol
cle_ptree_dn_t 	ptram_dn9_la =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    0,      0,   0,   0,	2,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    256,    0,   0,   0,    94,   0,      0,   0x0600,   0x00ff},		//TCP
	 {1,    260,    0,   0,   0,    93,   0,      0,   0x1100,   0x00ff},		//UDP
	 {1,    264,    0,   0,   0,    92,   0,      0,   0x0000,   0xffff},		//Others
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {1,    258,    0,   0,   0,    94,   4,      0,   0x0600,   0x00ff},		//TCP
	 {1,    262,    0,   0,   0,    93,   4,      0,   0x1100,   0x00ff},		//UDP
	 {1,    266,    0,   0,   0,    92,   4,      0,   0x0000,   0xffff},		//Others
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};

/*---------------------------------------------------------------------------------*/
// Node10 - Checks for IPv6 Extensions(Fragmented) & Protocol
// Fragment, TCP, UDP & Others
cle_ptree_dn_t 	ptram_dn10_la =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    0,      0,   0,   0,	1,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    34,     0,   1,   0,    11,   0,      0,   0x0044,   0xff00},		//Fragment
	 {1,    304,    0,   0,   0,    91,   0,      0,   0x0006,   0xff00},		//TCP
	 {1,    308,    0,   0,   0,    90,   0,      0,   0x0011,   0xff00},		//UDP
	 {1,    312,    0,   0,   0,    89,   0,      0,   0x0000,   0xffff},		//Others
	 {1,    34,     0,   1,   0,    11,   4,      0,   0x0044,   0xff00},		//Fragment
	 {1,    306,    0,   0,   0,    91,   4,      0,   0x0006,   0xff00},		//TCP
	 {1,    310,    0,   0,   0,    90,   4,      0,   0x0011,   0xff00},		//UDP
	 {1,    314,    0,   0,   0,    89,   4,      0,   0x0000,   0xffff}}		//Others
};

/*---------------------------------------------------------------------------------*/
// Node11 - Checks for IPv6 Protocol only
// TCP, UDP & Others
cle_ptree_dn_t 	ptram_dn11_la =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    0,      0,   0,   0,	1,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    316,    0,   0,   0,    88,   0,      0,   0x0006,   0xff00},		//TCP
	 {1,    320,    0,   0,   0,    87,   0,      0,   0x0011,   0xff00},		//UDP
	 {1,    324,    0,   0,   0,    86,   0,      0,   0x0000,   0xffff},		//Others
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {1,    318,    0,   0,   0,    88,   4,      0,   0x0006,   0xff00},		//TCP
	 {1,    322,    0,   0,   0,    87,   4,      0,   0x0011,   0xff00},		//UDP
	 {1,    326,    0,   0,   0,    86,   4,      0,   0x0000,   0xffff},		//Others
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};

/*---------------------------------------------------------------------------------*/
// Node12 - Checks for IPv4-32B Packet Fragmentation
cle_ptree_dn_t 	ptram_dn12_la =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    0,      0,   0,   0,	0,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    2,      0,   1,   4,    13,   0,      0,   0xfffc,   0x0003},		//SimpleMAC
	 {1,    2,      0,   1,   0,    14,   0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {1,    2,      0,   1,   4,    13,   4,      0,   0xfffc,   0x0003},		//MAC+1VLAN
	 {1,    2,      0,   1,   0,    14,   4,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};

/*---------------------------------------------------------------------------------*/
// Node13 - Checks for IPv4-32B(Fragmented) Protocol
cle_ptree_dn_t 	ptram_dn13_la =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    0,      0,   0,   0,	2,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    292,    0,   0,   0,    85,   0,      0,   0x0600,   0x00ff},		//TCP
	 {1,    296,    0,   0,   0,    84,   0,      0,   0x1100,   0x00ff},		//UDP
	 {1,    300,    0,   0,   0,    83,   0,      0,   0x0000,   0xffff},		//Others
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {1,    294,    0,   0,   0,    85,   4,      0,   0x0600,   0x00ff},		//TCP
	 {1,    298,    0,   0,   0,    84,   4,      0,   0x1100,   0x00ff},		//UDP
	 {1,    302,    0,   0,   0,    83,   4,      0,   0x0000,   0xffff},		//Others
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};

/*---------------------------------------------------------------------------------*/
// Node14 - Checks for IPv4-32B(Unfragmented) Protocol
cle_ptree_dn_t 	ptram_dn14_la =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    0,      0,   0,   0,	2,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    280,    0,   0,   0,    85,   0,      0,   0x0600,   0x00ff},		//TCP
	 {1,    284,    0,   0,   0,    84,   0,      0,   0x1100,   0x00ff},		//UDP
	 {1,    288,    0,   0,   0,    83,   0,      0,   0x0000,   0xffff},		//Others
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {1,    282,    0,   0,   0,    85,   4,      0,   0x0600,   0x00ff},		//TCP
	 {1,    286,    0,   0,   0,    84,   4,      0,   0x1100,   0x00ff},		//UDP
	 {1,    290,    0,   0,   0,    83,   4,      0,   0x0000,   0xffff},		//Others
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};


/*---------------------------------------------------------------------------------*/
// ----- Writing Last Nodes -----
// Updates Side-band signals
/*---------------------------------------------------------------------------------*/
// LN00 - LastNode. Non-IP
cle_ptree_dn_t 	ptram_dn_ln00_la =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    1,      1,   0,   0,	2,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    0,      0,   0,   0,    127,  1,      0,   0x0000,   0x00ff},		//P0
	 {1,    0,      0,   0,   0,    126,  1,      0,   0x0100,   0x00ff},		//P1
	 {1,    0,      0,   0,   0,    125,  1,      0,   0x0200,   0x00ff},		//P2
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {1,    0,      0,   0,   0,    127,  17,     0,   0x0000,   0x00ff},		//P0
	 {1,    0,      0,   0,   0,    126,  17,     0,   0x0100,   0x00ff},		//P1
	 {1,    0,      0,   0,   0,    125,  17,     0,   0x0200,   0x00ff},		//P2
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};

/*---------------------------------------------------------------------------------*/
// LN01 - LastNode. IPv4-20B-TCP
cle_ptree_dn_t 	ptram_dn_ln01_la =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    1,      1,   0,   0,	2,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    0,      0,   0,   0,    127,  2,      0,   0x0000,   0x00ff},		//P0
	 {1,    0,      0,   0,   0,    126,  2,      0,   0x0100,   0x00ff},		//P1
	 {1,    0,      0,   0,   0,    125,  2,      0,   0x0200,   0x00ff},		//P2
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {1,    0,      0,   0,   0,    127,  18,     0,   0x0000,   0x00ff},		//P0
	 {1,    0,      0,   0,   0,    126,  18,     0,   0x0100,   0x00ff},		//P1
	 {1,    0,      0,   0,   0,    125,  18,     0,   0x0200,   0x00ff},		//P2
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};

/*---------------------------------------------------------------------------------*/
// LN02 - LastNode. IPv4-20B-UDP
cle_ptree_dn_t 	ptram_dn_ln02_la =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    1,      1,   0,   0,	2,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    0,      0,   0,   0,    127,  3,      0,   0x0000,   0x00ff},		//P0
	 {1,    0,      0,   0,   0,    126,  3,      0,   0x0100,   0x00ff},		//P1
	 {1,    0,      0,   0,   0,    125,  3,      0,   0x0200,   0x00ff},		//P2
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {1,    0,      0,   0,   0,    127,  19,     0,   0x0000,   0x00ff},		//P0
	 {1,    0,      0,   0,   0,    126,  19,     0,   0x0100,   0x00ff},		//P1
	 {1,    0,      0,   0,   0,    125,  19,     0,   0x0200,   0x00ff},		//P2
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};

/*---------------------------------------------------------------------------------*/
// LN03 - LastNode. IPv4-20B-Others
cle_ptree_dn_t 	ptram_dn_ln03_la =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    1,      1,   0,   0,	2,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    0,      0,   0,   0,    127,  4,      0,   0x0000,   0x00ff},		//P0
	 {1,    0,      0,   0,   0,    126,  4,      0,   0x0100,   0x00ff},		//P1
	 {1,    0,      0,   0,   0,    125,  4,      0,   0x0200,   0x00ff},		//P2
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {1,    0,      0,   0,   0,    127,  20,     0,   0x0000,   0x00ff},		//P0
	 {1,    0,      0,   0,   0,    126,  20,     0,   0x0100,   0x00ff},		//P1
	 {1,    0,      0,   0,   0,    125,  20,     0,   0x0200,   0x00ff},		//P2
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};

/*---------------------------------------------------------------------------------*/
// LN04 - LastNode. IPv6-40B-Unfragmented-TCP
cle_ptree_dn_t 	ptram_dn_ln04_la =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    1,      1,   0,   0,	2,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    0,      0,   0,   0,    127,  5,      0,   0x0000,   0x00ff},		//P0
	 {1,    0,      0,   0,   0,    126,  5,      0,   0x0100,   0x00ff},		//P1
	 {1,    0,      0,   0,   0,    125,  5,      0,   0x0200,   0x00ff},		//P2
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {1,    0,      0,   0,   0,    127,  21,     0,   0x0000,   0x00ff},		//P0
	 {1,    0,      0,   0,   0,    126,  21,     0,   0x0100,   0x00ff},		//P1
	 {1,    0,      0,   0,   0,    125,  21,     0,   0x0200,   0x00ff},		//P2
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};

/*---------------------------------------------------------------------------------*/
// LN05 - LastNode. IPv6-40B-Unfragmented-UDP
cle_ptree_dn_t 	ptram_dn_ln05_la =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    1,      1,   0,   0,	2,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    0,      0,   0,   0,    127,  6,      0,   0x0000,   0x00ff},		//P0
	 {1,    0,      0,   0,   0,    126,  6,      0,   0x0100,   0x00ff},		//P1
	 {1,    0,      0,   0,   0,    125,  6,      0,   0x0200,   0x00ff},		//P2
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {1,    0,      0,   0,   0,    127,  22,     0,   0x0000,   0x00ff},		//P0
	 {1,    0,      0,   0,   0,    126,  22,     0,   0x0100,   0x00ff},		//P1
	 {1,    0,      0,   0,   0,    125,  22,     0,   0x0200,   0x00ff},		//P2
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};

/*---------------------------------------------------------------------------------*/
// LN06 - LastNode. IPv6-40B-Unfragmented-Others
cle_ptree_dn_t 	ptram_dn_ln06_la =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    1,      1,   0,   0,	2,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    0,      0,   0,   0,    127,  7,      0,   0x0000,   0x00ff},		//P0
	 {1,    0,      0,   0,   0,    126,  7,      0,   0x0100,   0x00ff},		//P1
	 {1,    0,      0,   0,   0,    125,  7,      0,   0x0200,   0x00ff},		//P2
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {1,    0,      0,   0,   0,    127,  23,     0,   0x0000,   0x00ff},		//P0
	 {1,    0,      0,   0,   0,    126,  23,     0,   0x0100,   0x00ff},		//P1
	 {1,    0,      0,   0,   0,    125,  23,     0,   0x0200,   0x00ff},		//P2
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};

/*---------------------------------------------------------------------------------*/
// LN07 - LastNode. IPv6-48B-Fragmented-TCP
cle_ptree_dn_t 	ptram_dn_ln07_la =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    1,      1,   0,   0,	2,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    0,      0,   0,   0,    127,  13,     0,   0x0000,   0x00ff},		//P0
	 {1,    0,      0,   0,   0,    126,  13,     0,   0x0100,   0x00ff},		//P1
	 {1,    0,      0,   0,   0,    125,  13,     0,   0x0200,   0x00ff},		//P2
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {1,    0,      0,   0,   0,    127,  29,     0,   0x0000,   0x00ff},		//P0
	 {1,    0,      0,   0,   0,    126,  29,     0,   0x0100,   0x00ff},		//P1
	 {1,    0,      0,   0,   0,    125,  29,     0,   0x0200,   0x00ff},		//P2
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};

/*---------------------------------------------------------------------------------*/
// LN08 - LastNode. IPv6-48B-Fragmented-UDP
cle_ptree_dn_t 	ptram_dn_ln08_la =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    1,      1,   0,   0,	2,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    0,      0,   0,   0,    127,  14,     0,   0x0000,   0x00ff},		//P0
	 {1,    0,      0,   0,   0,    126,  14,     0,   0x0100,   0x00ff},		//P1
	 {1,    0,      0,   0,   0,    125,  14,     0,   0x0200,   0x00ff},		//P2
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {1,    0,      0,   0,   0,    127,  30,     0,   0x0000,   0x00ff},		//P0
	 {1,    0,      0,   0,   0,    126,  30,     0,   0x0100,   0x00ff},		//P1
	 {1,    0,      0,   0,   0,    125,  30,     0,   0x0200,   0x00ff},		//P2
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};

/*---------------------------------------------------------------------------------*/
// LN09 - LastNode. IPv6-48B-Fragmented-Others
cle_ptree_dn_t 	ptram_dn_ln09_la =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    1,      1,   0,   0,	2,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    0,      0,   0,   0,    127,  15,     0,   0x0000,   0x00ff},		//P0
	 {1,    0,      0,   0,   0,    126,  15,     0,   0x0100,   0x00ff},		//P1
	 {1,    0,      0,   0,   0,    125,  15,     0,   0x0200,   0x00ff},		//P2
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {1,    0,      0,   0,   0,    127,  31,     0,   0x0000,   0x00ff},		//P0
	 {1,    0,      0,   0,   0,    126,  31,     0,   0x0100,   0x00ff},		//P1
	 {1,    0,      0,   0,   0,    125,  31,     0,   0x0200,   0x00ff},		//P2
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};


/*---------------------------------------------------------------------------------*/
// LN10 - LastNode. IPv4-32B-TCP
cle_ptree_dn_t 	ptram_dn_ln10_la =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    1,      1,   0,   0,	2,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    0,      0,   0,   0,    127,  10,     0,   0x0000,   0x00ff},		//P0
	 {1,    0,      0,   0,   0,    126,  10,     0,   0x0100,   0x00ff},		//P1
	 {1,    0,      0,   0,   0,    125,  10,     0,   0x0200,   0x00ff},		//P2
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {1,    0,      0,   0,   0,    127,  26,     0,   0x0000,   0x00ff},		//P0
	 {1,    0,      0,   0,   0,    126,  26,     0,   0x0100,   0x00ff},		//P1
	 {1,    0,      0,   0,   0,    125,  26,     0,   0x0200,   0x00ff},		//P2
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};

/*---------------------------------------------------------------------------------*/
// LN11 - LastNode. IPv4-32B-UDP
cle_ptree_dn_t 	ptram_dn_ln11_la =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    1,      1,   0,   0,	2,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    0,      0,   0,   0,    127,  11,     0,   0x0000,   0x00ff},		//P0
	 {1,    0,      0,   0,   0,    126,  11,     0,   0x0100,   0x00ff},		//P1
	 {1,    0,      0,   0,   0,    125,  11,     0,   0x0200,   0x00ff},		//P2
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {1,    0,      0,   0,   0,    127,  27,     0,   0x0000,   0x00ff},		//P0
	 {1,    0,      0,   0,   0,    126,  27,     0,   0x0100,   0x00ff},		//P1
	 {1,    0,      0,   0,   0,    125,  27,     0,   0x0200,   0x00ff},		//P2
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};

/*---------------------------------------------------------------------------------*/
// LN12 - LastNode. IPv4-32B-Others
cle_ptree_dn_t 	ptram_dn_ln12_la =
{
	//DN,   LN,     HS,  HE,  BS,   SBS,  R,      DefPtr,  R
	  2,    1,      1,   0,   0,	2,	  0,      0,       0,
	//V,    P2B,    jb,  jr,  Op,   Node, BrKy,   R,   CMPDAT,   MASK
	{{1,    0,      0,   0,   0,    127,  12,     0,   0x0000,   0x00ff},		//P0
	 {1,    0,      0,   0,   0,    126,  12,     0,   0x0100,   0x00ff},		//P1
	 {1,    0,      0,   0,   0,    125,  12,     0,   0x0200,   0x00ff},		//P2
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff},
	 {1,    0,      0,   0,   0,    127,  28,     0,   0x0000,   0x00ff},		//P0
	 {1,    0,      0,   0,   0,    126,  28,     0,   0x0100,   0x00ff},		//P1
	 {1,    0,      0,   0,   0,    125,  28,     0,   0x0200,   0x00ff},		//P2
	 {0,    0,      0,   0,   0,    0,    0,      0,   0x0000,   0xffff}}
};


/*---------------------------------------------------------------------------------*/
/*=================================*/
/*==========  Node Array ==========*/
/*=================================*/

/* STEP 2 - insert the node into array */

/*---------------------------------------------------------------------------------*/
cle_cfg_ptram_dn ptram_dn_la[] =
{
	{0,		(cle_ptree_dn_t*)&ptram_dn0_la},
	{1,		(cle_ptree_dn_t*)&ptram_dn1_la},
	{2,		(cle_ptree_dn_t*)&ptram_dn2_la},
	{3,		(cle_ptree_dn_t*)&ptram_dn3_la},
	{4,		(cle_ptree_dn_t*)&ptram_dn4_la},
	{5,		(cle_ptree_dn_t*)&ptram_dn5_la},
	{6,		(cle_ptree_dn_t*)&ptram_dn6_la},
	{7,		(cle_ptree_dn_t*)&ptram_dn7_la},
	{8,		(cle_ptree_dn_t*)&ptram_dn8_la},
	{9,		(cle_ptree_dn_t*)&ptram_dn9_la},
	{10,	(cle_ptree_dn_t*)&ptram_dn10_la},
	{11,	(cle_ptree_dn_t*)&ptram_dn11_la},
	{12,	(cle_ptree_dn_t*)&ptram_dn12_la},
	{13,	(cle_ptree_dn_t*)&ptram_dn13_la},
	{14,	(cle_ptree_dn_t*)&ptram_dn14_la},

	{95,	(cle_ptree_dn_t*)&ptram_dn_ln00_la},
	{94,	(cle_ptree_dn_t*)&ptram_dn_ln01_la},
	{93,	(cle_ptree_dn_t*)&ptram_dn_ln02_la},
	{92,	(cle_ptree_dn_t*)&ptram_dn_ln03_la},
	{91,	(cle_ptree_dn_t*)&ptram_dn_ln04_la},
	{90,	(cle_ptree_dn_t*)&ptram_dn_ln05_la},
	{89,	(cle_ptree_dn_t*)&ptram_dn_ln06_la},
	{88,	(cle_ptree_dn_t*)&ptram_dn_ln07_la},
	{87,	(cle_ptree_dn_t*)&ptram_dn_ln08_la},
	{86,	(cle_ptree_dn_t*)&ptram_dn_ln09_la},
	{85,	(cle_ptree_dn_t*)&ptram_dn_ln10_la},
	{84,	(cle_ptree_dn_t*)&ptram_dn_ln11_la},
	{83,	(cle_ptree_dn_t*)&ptram_dn_ln12_la},
};


/*---------------------------------------------------------------------------------*/
/*=================================*/
/*====== Keynote Define  ==========*/
/*=================================*/

/* STEP 3 */

/*---------------------------------------------------------------------------------*/
// KN (KeyNode)   : 0->2 ( [0: Invalid Node], [1: Key Node], [2: Decision Node]
// P (Priority)   : 0->7 (0: Lowest, 7: highest)
// RAdr(Result address): 0->1024: This is a Result Pointer point a entry in DBRAM.
// R: Reserved.
//----------------------------------------------------

// ----- Writing Key Nodes -----
// KN0 - Key Node. Port0
cle_ptree_keynote_t 	ptram_kn0_la =
{
	//KN, R
	  1, 0,
	//P,   RAdr, R     P,   RAdr, R     P,   RAdr, R    P,   RAdr, R
	{{2,   0,    0},  {2,   1,    0},  {2,   2,    0},  {2,   3,    0},
	 {2,   4,    0},  {2,   5,    0},  {2,   6,    0},  {2,   7,    0},
	 {2,   8,    0},  {2,   9,    0},  {2,   10,   0},  {2,   11,   0},
	 {2,   12,   0},  {2,   13,   0},  {2,   14,   0},  {2,   15,   0},
	 {2,   16,   0},  {2,   17,   0},  {2,   18,   0},  {2,   19,   0},
	 {2,   20,   0},  {2,   21,   0},  {2,   22,   0},  {2,   23,   0},
	 {2,   24,   0},  {2,   25,   0},  {2,   26,   0},  {2,   27,   0},
	 {2,   28,   0},  {2,   29,   0},  {2,   30,   0},  {2,   31,   0}}
};

/*---------------------------------------------------------------------------------*/
// KN1 - Key Node. Port1
cle_ptree_keynote_t 	ptram_kn1_la =
{
	//KN, R
	  1, 0,
	//P,   RAdr, R     P,   RAdr, R     P,   RAdr, R    P,   RAdr, R
	{{2,   32,   0},  {2,   33,   0},  {2,   34,   0},  {2,   35,   0},
	 {2,   36,   0},  {2,   37,   0},  {2,   38,   0},  {2,   39,   0},
	 {2,   40,   0},  {2,   41,   0},  {2,   42,   0},  {2,   43,   0},
	 {2,   44,   0},  {2,   45,   0},  {2,   46,   0},  {2,   47,   0},
	 {2,   48,   0},  {2,   49,   0},  {2,   50,   0},  {2,   51,   0},
	 {2,   52,   0},  {2,   53,   0},  {2,   54,   0},  {2,   55,   0},
	 {2,   56,   0},  {2,   57,   0},  {2,   58,   0},  {2,   59,   0},
	 {2,   60,   0},  {2,   61,   0},  {2,   62,   0},  {2,   63,   0}}
};

/*---------------------------------------------------------------------------------*/
// KN2 - Key Node. Port2
cle_ptree_keynote_t 	ptram_kn2_la =
{
	//KN, R
	  1, 0,
	//P,   RAdr, R     P,   RAdr, R     P,   RAdr, R    P,   RAdr, R
	{{2,   64,   0},  {2,   65,   0},  {2,   66,   0},  {2,   67,   0},
	 {2,   68,   0},  {2,   69,   0},  {2,   70,   0},  {2,   71,   0},
	 {2,   72,   0},  {2,   73,   0},  {2,   74,   0},  {2,   75,   0},
	 {2,   76,   0},  {2,   77,   0},  {2,   78,   0},  {2,   79,   0},
	 {2,   80,   0},  {2,   81,   0},  {2,   82,   0},  {2,   83,   0},
	 {2,   84,   0},  {2,   85,   0},  {2,   86,   0},  {2,   87,   0},
	 {2,   88,   0},  {2,   89,   0},  {2,   90,   0},  {2,   91,   0},
	 {2,   92,   0},  {2,   93,   0},  {2,   94,   0},  {2,   95,   0}}
};


/*---------------------------------------------------------------------------------*/
/*=================================*/
/*========= Keynote Array =========*/
/*=================================*/

/* STEP 4 - Insert the Keynote into array*/
/*---------------------------------------------------------------------------------*/
cle_cfg_ptram_kn ptram_kn_la[] =
{
		{127, 	(cle_ptree_keynote_t*)&ptram_kn0_la},
		{126, 	(cle_ptree_keynote_t*)&ptram_kn1_la},
		{125, 	(cle_ptree_keynote_t*)&ptram_kn2_la}
};



/*===================================================================================*/
/*========== Set start node to paser0, synthesis Decision node and Keynode ==========*/
/*===================================================================================*/

/* STEP 5 - Set start node, Synthesis Decision node and Keynode */
/*---------------------------------------------------------------------------------*/
cle_cfg_ptram_t ptram_cfg_la =
{
		CLE_VAL_NONE,			// don't care
		CLE_VAL_NONE,			// don't care
		0,						// start node to parser 2
		sizeof(ptram_dn_la)/sizeof(cle_cfg_ptram_dn),
		sizeof(ptram_kn_la)/sizeof(cle_cfg_ptram_kn),
		ptram_dn_la,
		ptram_kn_la
};

/*===================================================================================================*/
/*============== DEFINE DATA BASE RESULT OF CLE LITE ================================================*/
/*===================================================================================================*/

/* STEP 6 -Define Hinfo in entries of DBRAM*/


cle_eth_mode_t 	cle_def_eth_mode_la[] =
{
//	TCPH  IPH  eH    MSS  EC   TSO  PRO  IPV  RV3  RV5  VLAN  CRC  RV8  TYPE RV10  RV38/TST
	{0x0, 0x0, 0xe,  0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// NONE-IP
	{0x5, 0x5, 0xe,  0x0, 0x1, 0x0, 0x1, 0x0, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP4-20B-TCP
	{0x2, 0x5, 0xe,  0x0, 0x1, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP4-20B-UDP
	{0x0, 0x5, 0xe,  0x0, 0x1, 0x0, 0x3, 0x0, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP4-20B-Others
	{0x5, 0xa, 0xe,  0x0, 0x1, 0x0, 0x1, 0x1, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP6-40B-TCP
	{0x2, 0xa, 0xe,  0x0, 0x1, 0x0, 0x0, 0x1, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP6-40B-UDP
	{0x0, 0xa, 0xe,  0x0, 0x1, 0x0, 0x3, 0x1, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP6-40B-others
	{0x5, 0x8, 0xe,  0x0, 0x1, 0x0, 0x1, 0x0, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP4-32B-TCP
	{0x2, 0x8, 0xe,  0x0, 0x1, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP4-32B-UDP
	{0x0, 0x8, 0xe,  0x0, 0x1, 0x0, 0x3, 0x0, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP4-32B-Others
	{0x5, 0xc, 0xe,  0x0, 0x1, 0x0, 0x1, 0x1, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP6-48B-TCP
	{0x2, 0xc, 0xe,  0x0, 0x1, 0x0, 0x0, 0x1, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP6-48B-UDP
	{0x0, 0xc, 0xe,  0x0, 0x1, 0x0, 0x3, 0x1, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP6-48B-Others

//	TCPH  IPH  eH    MSS  EC   TSO  PRO  IPV  RV3  RV5  VLAN  CRC  RV8  TYPE RV10  RV38/TST
	{0x0, 0x0, 0x12, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,  0x0, 0x0, 0x0, 0x0,  0x0},	// NONE-IP
	{0x5, 0x5, 0x12, 0x0, 0x1, 0x0, 0x1, 0x0, 0x0, 0x0, 0x1,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP4-20B-TCP-VLAN
	{0x2, 0x5, 0x12, 0x0, 0x1, 0x0, 0x0, 0x0, 0x0, 0x0, 0x1,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP4-20B-UDP-VLAN
	{0x0, 0x5, 0x12, 0x0, 0x1, 0x0, 0x3, 0x0, 0x0, 0x0, 0x1,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP4-20B-Others-VLAN
	{0x5, 0xa, 0x12, 0x0, 0x1, 0x0, 0x1, 0x1, 0x0, 0x0, 0x1,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP6-40B-TCP-VLAN
	{0x2, 0xa, 0x12, 0x0, 0x1, 0x0, 0x0, 0x1, 0x0, 0x0, 0x1,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP6-40B-UDP-VLAN
	{0x0, 0xa, 0x12, 0x0, 0x1, 0x0, 0x3, 0x1, 0x0, 0x0, 0x1,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP6-40B-others-VLAN
	{0x5, 0x8, 0x12, 0x0, 0x1, 0x0, 0x1, 0x0, 0x0, 0x0, 0x1,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP4-32B-TCP-VLAN
	{0x2, 0x8, 0x12, 0x0, 0x1, 0x0, 0x0, 0x0, 0x0, 0x0, 0x1,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP4-32B-UDP-VLAN
	{0x0, 0x8, 0x12, 0x0, 0x1, 0x0, 0x3, 0x0, 0x0, 0x0, 0x1,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP4-32B-Others-VLAN
	{0x5, 0xc, 0x12, 0x0, 0x1, 0x0, 0x1, 0x1, 0x0, 0x0, 0x1,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP6-48B-TCP-VLAN
	{0x2, 0xc, 0x12, 0x0, 0x1, 0x0, 0x0, 0x1, 0x0, 0x0, 0x1,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP6-48B-UDP-VLAN
	{0x0, 0xc, 0x12, 0x0, 0x1, 0x0, 0x3, 0x1, 0x0, 0x0, 0x1,  0x0, 0x0, 0x0, 0x0,  0x0},	// IP6-48B-Others-VLAN
};


/*===================================================================================================*/

/* STEP 7 - Define array of entries in DBram, have insert HInfo from step 6*/

/*===================================================================================================*/
//- Entry : Number of Entry in DBRAM. It's get from cle_eth_mode_t 	cle_def_eth_mode_2inline[];
//- HINFO : Define structure HINFO to this entry.
//- FP, DES, HENQ: Freepoll slot, destination's qid, henqnum's qid in dbram at this entry which CLE use to enqueue when 'E' is enabled (E = 1).
//- E : Enable write FP, DES, HENQ to this entry in DBRAM
//	+ 0: Disable : FP slot, dest's id, henqnum's id are writen this entry in dbram which is get from enq_qids{fp, dst, henq}
//		of function cle_until(port, enq_qids )
//	+ 1: Enable: FP slot, dest's id, henqnum's id are write this entry in dbram whict is get from the fields : FP, DES, HENQ of
//	   structure "cle_def_dbram_t"
//-  flow,  group, P : are the field perflow, flowgroup, priority in dbram, when want modify to test, change these values.

cle_def_dbram_t cle_def_db_la[] =
{
//	Entry					HINFO                   FP  DES HENQ E  flow group  P
	{65, (cle_eth_mode_t*)&cle_def_eth_mode_la[0],  {4, 10, 10}, 1, {0xa, 0x6, 0x1} },
	{66, (cle_eth_mode_t*)&cle_def_eth_mode_la[1],  {4, 10, 10}, 1, {0xa, 0x6, 0x1} },
	{67, (cle_eth_mode_t*)&cle_def_eth_mode_la[2],  {4, 10, 10}, 1, {0xa, 0x6, 0x1} },
	{68, (cle_eth_mode_t*)&cle_def_eth_mode_la[3],  {4, 10, 10}, 1, {0xa, 0x6, 0x1} },
	{69, (cle_eth_mode_t*)&cle_def_eth_mode_la[4],  {4, 10, 10}, 1, {0xa, 0x6, 0x1} },
	{70, (cle_eth_mode_t*)&cle_def_eth_mode_la[5],  {4, 10, 10}, 1, {0xa, 0x6, 0x1} },
	{71, (cle_eth_mode_t*)&cle_def_eth_mode_la[6],  {4, 10, 10}, 1, {0xa, 0x6, 0x1} },
	{74, (cle_eth_mode_t*)&cle_def_eth_mode_la[7],  {4, 10, 10}, 1, {0xa, 0x6, 0x1} },
	{75, (cle_eth_mode_t*)&cle_def_eth_mode_la[8],  {4, 10, 10}, 1, {0xa, 0x6, 0x1} },
	{76, (cle_eth_mode_t*)&cle_def_eth_mode_la[9],  {4, 10, 10}, 1, {0xa, 0x6, 0x1} },
	{77, (cle_eth_mode_t*)&cle_def_eth_mode_la[10], {4, 10, 10}, 1, {0xa, 0x6, 0x1} },
	{78, (cle_eth_mode_t*)&cle_def_eth_mode_la[11], {4, 10, 10}, 1, {0xa, 0x6, 0x1} },
	{79, (cle_eth_mode_t*)&cle_def_eth_mode_la[12], {4, 10, 10}, 1, {0xa, 0x6, 0x1} },

	{81, (cle_eth_mode_t*)&cle_def_eth_mode_la[13], {4, 10, 10}, 1, {0xa, 0x6, 0x1} },
	{82, (cle_eth_mode_t*)&cle_def_eth_mode_la[14], {4, 10, 10}, 1, {0xa, 0x6, 0x1} },
	{83, (cle_eth_mode_t*)&cle_def_eth_mode_la[15], {4, 10, 10}, 1, {0xa, 0x6, 0x1} },
	{84, (cle_eth_mode_t*)&cle_def_eth_mode_la[16], {4, 10, 10}, 1, {0xa, 0x6, 0x1} },
	{85, (cle_eth_mode_t*)&cle_def_eth_mode_la[17], {4, 10, 10}, 1, {0xa, 0x6, 0x1} },
	{86, (cle_eth_mode_t*)&cle_def_eth_mode_la[18], {4, 10, 10}, 1, {0xa, 0x6, 0x1} },
	{87, (cle_eth_mode_t*)&cle_def_eth_mode_la[19], {4, 10, 10}, 1, {0xa, 0x6, 0x1} },
	{90, (cle_eth_mode_t*)&cle_def_eth_mode_la[20], {4, 10, 10}, 1, {0xa, 0x6, 0x1} },
	{91, (cle_eth_mode_t*)&cle_def_eth_mode_la[21], {4, 10, 10}, 1, {0xa, 0x6, 0x1} },
	{92, (cle_eth_mode_t*)&cle_def_eth_mode_la[22], {4, 10, 10}, 1, {0xa, 0x6, 0x1} },
	{93, (cle_eth_mode_t*)&cle_def_eth_mode_la[23], {4, 10, 10}, 1, {0xa, 0x6, 0x1} },
	{94, (cle_eth_mode_t*)&cle_def_eth_mode_la[24], {4, 10, 10}, 1, {0xa, 0x6, 0x1} },
	{95, (cle_eth_mode_t*)&cle_def_eth_mode_la[25], {4, 10, 10}, 1, {0xa, 0x6, 0x1} },
};

/*===================================================================================================*/

/* STEP 8 - Synthesis DBRam */

/*===================================================================================================*/

/*===================================================================================================*/
cle_cfg_dbram_t cle_cfg_db_la =
{
	sizeof(cle_def_db_la)/sizeof(cle_def_dbram_t),
	cle_def_db_la
};

/*---------------------------------------------------------------------------------*/
#endif	//#if CLE_LOOKASIDE_ENABLE





/*===================================================================================================*/

/* STEP 9 - Insert configure table of PTram and DBram to "cle_cfg_pt_db_t cle_cfg_pt_db[]" array. */

/*===================================================================================================*/
/*===================================================================================================*/
cle_cfg_pt_db_t cle_cfg_pt_db[] =
{
#if CLE_LITE_ENABLE
		{CLE_TYPE_LITE, 	 &ptram_cfg_lite, 	 &cle_cfg_db_lite},
#endif

#if CLE_2INLINE_ENABLE
		{CLE_TYPE_2INLINE,	 &ptram_cfg_2inline, &cle_cfg_db_2inline},
#endif

#if CLE_3INLINE_ENABLE
		{CLE_TYPE_3INLINE,	 &ptram_cfg_3inline, &cle_cfg_db_3inline},
#endif

#if CLE_LOOKASIDE_ENABLE
		{CLE_TYPE_LOOKASIDE, &ptram_cfg_la,      &cle_cfg_db_la},
#endif
};

/*===================================================================================================*/
cle_cfg_t cle_cfg =
{
		sizeof(cle_cfg_pt_db)/sizeof(cle_cfg_pt_db_t),
		cle_cfg_pt_db
};

/*===================================================================================================*/
/*===================================================================================================*/
/*===================================================================================================*/
/*===================================================================================================*/
/*===================================================================================================*/
/*===================================================================================================*/
/*===================================================================================================*/
/*===================================================================================================*/
/*===================================================================================================*/
/*===================================================================================================*/
#endif
