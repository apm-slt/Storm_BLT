//////////////////////////////////////////////////////////////////////////////////////////
//file name:    sm_cle_3inline.c
//create date:  1/9/2013
//description:  cle three inline configure functions.
//////////////////////////////////////////////////////////////////////////////////////////

#include "cle_drv.h"
#include "eth_cle_drv.h"

/// CLE Debug Routine Start 
cle_ret_t sm_get_cle_trace(u8 ethPort, u8 clePort, struct sm_cle_trace *cle_trace)
{
	int i, rc = CLE_OK;
	u32 data = 0;

	//printf("%s %d %s :\n ",  __FILE__, __LINE__, __FUNCTION__);
	MB_CHK_PTR (cle_trace);
	cle_get_cle_ctrl(ethPort); //cb
	
	switch(clePort) {
		case 0:
			//PCE_REG_RD(ethPort, LSTNVST0_ADDR, &data);   //orig
			cle_reg_rd_print("CLE_LSTNVST0_ADDR", CLE_LSTNVST0_ADDR, &data);//cb
			//cle_trace->last_node_visited = LSTNVST0_RD(data);
			cle_trace->last_node_visited = data & 0x3fff;
			printf("Winner DB RAM = %d\n", cle_trace->last_node_visited);
#if 1 // This dump is for latest last 16 nodes e.g. starting from data_base, key_node, last_node, N+1)_data_node,N_data_node......start_node           
			for (i=0; i< MAX_LAST_NODES_TRACE; i++) {
					//PCE_REG_RD (ethPort, LSTTRCNVST0_0_ADDR + (i<<2), &data);//orig
					cle_reg_rd_print("CLE_LSTTRCNVST0_0_ADDR", CLE_LSTTRCNVST0_0_ADDR + (i<<2), &data);//cb
					//cle_trace->last_visited_node_trace[i] = LTRCNVST0_RD(data);//ori
					//cle_trace->last_visited_node_trace[i] = (data & 0x3fff);//cb
                    cle_trace->last_visited_node_trace[i] = data & 0x1ff;//cb
		        	cle_trace->last_visited_branch_trace[i] = ((data & 0x3e00)>>9);//cb
                    printf("Winner NODE idx:%d = %d \t Branch = %d\n", i, cle_trace->last_visited_node_trace[i], cle_trace->last_visited_branch_trace[i]);
			}
#endif            
#if 0 // This is dump for only first 16 nodes e.g. starting from start_node, N_data_node, (N+1)_data_node .....,last_node, key_node, data_base           
			for (i=0; i< MAX_FIRST_NODES_TRACE; i++) {
					//PCE_REG_RD (ethPort, FTRCNVST0_0_ADDR + (i<<2), &data);//orig
					cle_reg_rd_print ("CLE_FTRCNVST0_0_ADDR",CLE_FTRCNVST0_0_ADDR + (i<<2), &data);//cb
					//cle_trace->first_visited_node_trace[i] = FTRCNVST0_RD(data);//ori
					//cle_trace->first_visited_node_trace[i] = (data & 0x3fff);//cb
                    cle_trace->first_visited_node_trace[i] = data & 0x1ff;//cb
		        	cle_trace->first_visited_branch_trace[i] = ((data & 0x3e00)>>9);//cb
                    printf("Winner NODE = %d \t Branch = %d\n", cle_trace->first_visited_node_trace[i], cle_trace->first_visited_branch_trace[i]);
			}
#endif            
		break;
		case 1:
			/*PCE_REG_RD(ethPort, LSTNVST1_ADDR, &data);   
			cle_trace->last_node_visited = LSTNVST1_RD(data);
			
			for (i=0; i< MAX_LAST_NODES_TRACE; i++) {
					PCE_REG_RD (ethPort, LSTTRCNVST1_0_ADDR + (i<<2), &data);
					cle_trace->last_visited_node_trace[i] =
							LTRCNVST1_RD(data);
			}
			for (i=0; i< MAX_FIRST_NODES_TRACE; i++) {
					PCE_REG_RD (ethPort, FTRCNVST1_0_ADDR + (i<<2), &data);
					cle_trace->first_visited_node_trace[i] =
							FTRCNVST1_RD(data);
			} */
			cle_reg_rd_print("CLE_LSTNVST1_ADDR", CLE_LSTNVST1_ADDR, &data);//cb
			cle_trace->last_node_visited = data & 0x3fff;//cb
				printf("Winner DB RAM = %d\n", cle_trace->last_node_visited);

#if 1 // This dump is for latest last 16 nodes e.g. starting from data_base, key_node, last_node, N+1)_data_node,N_data_node......start_node           
			for (i=0; i< MAX_LAST_NODES_TRACE; i++) {
					cle_reg_rd_print("CLE_LSTTRCNVST1_0_ADDR", CLE_LSTTRCNVST1_0_ADDR + (i<<2), &data);//cb
                    cle_trace->last_visited_node_trace[i] = data & 0x1ff;//cb
		        	cle_trace->last_visited_branch_trace[i] = ((data & 0x3e00)>>9);//cb
                    printf("Winner NODE = %d \t Branch = %d\n", cle_trace->last_visited_node_trace[i], cle_trace->last_visited_branch_trace[i]);

			}
#endif
#if 0 // This is dump for only first 16 nodes e.g. starting from start_node, N_data_node, (N+1)_data_node .....,last_node, key_node, data_base           
			for (i=0; i< MAX_FIRST_NODES_TRACE; i++) {
					cle_reg_rd_print ("CLE_FTRCNVST1_0_ADDR",CLE_FTRCNVST1_0_ADDR + (i<<2), &data);//cb
                     cle_trace->first_visited_node_trace[i] = data & 0x1ff;//cb
		        	cle_trace->first_visited_branch_trace[i] = ((data & 0x3e00)>>9);//cb
                    printf("Winner NODE = %d \t Branch = %d\n", cle_trace->first_visited_node_trace[i], cle_trace->first_visited_branch_trace[i]);

			}
#endif            
		break;
		case 2:
			//chandra
			cle_reg_rd_print("CLE_LSTNVST2_ADDR", CLE_LSTNVST2_ADDR, &data);//cb
			cle_trace->last_node_visited = data & 0x3fff;//cb
				printf("Winner DB RAM = %d\n", cle_trace->last_node_visited);

#if 1 // This dump is for latest last 16 nodes e.g. starting from data_base, key_node, last_node, N+1)_data_node,N_data_node......start_node           
			for (i=0; i< MAX_LAST_NODES_TRACE; i++) {
					cle_reg_rd_print("CLE_LSTTRCNVST2_0_ADDR", CLE_LSTTRCNVST2_0_ADDR + (i<<2), &data);//cb
                    cle_trace->last_visited_node_trace[i] = data & 0x1ff;//cb
		        	cle_trace->last_visited_branch_trace[i] = ((data & 0x3e00)>>9);//cb
                    printf("Winner NODE = %d \t Branch = %d\n", cle_trace->last_visited_node_trace[i], cle_trace->last_visited_branch_trace[i]);

			}
#endif
#if 0 // This dump is for latest last 16 nodes e.g. starting from data_base, key_node, last_node, N+1)_data_node,N_data_node......start_node           
			for (i=0; i< MAX_FIRST_NODES_TRACE; i++) {
					cle_reg_rd_print ("CLE_FTRCNVST2_0_ADDR",CLE_FTRCNVST2_0_ADDR + (i<<2), &data);//cb
                     cle_trace->first_visited_node_trace[i] = data & 0x1ff;//cb
		        	cle_trace->first_visited_branch_trace[i] = ((data & 0x3e00)>>9);//cb
                    printf("Winner NODE = %d \t Branch = %d\n", cle_trace->first_visited_node_trace[i], cle_trace->first_visited_branch_trace[i]);

			}
#endif			
		break;
		default:
		break;
	}

	return (rc);
}


cle_ret_t sm_cle_pktram_read(cle_zone_t zone, u32 *pktdata)
{
	int i, rc = CLE_OK;
	u32 ptram_dn10_dump;
	u32 ptram_dn1_dump;
	u32 ptram_kn11_dump;
	//cle_zone_t zone;
#if 1
    printf("Entered in the cle_pktram------->\n");	
	for (i = 0 ; i < 64 ; i++)
	//for (i = 0 ; i < 74 ; i++)
	{
			rc = cle_rw_ind(i, &pktdata, zone, CLE_OPT_CMD_RD);
	}
#endif
#if 0    
    printf("Reading PT RAM---------------->\n");
    printf("Reading PT RAM NODE 10---------------->\n");
	rc = cle_rw_ind(10, ptram_dn10_dump, CLE_ZONE_PT_RAM, CLE_OPT_CMD_RD);
    printf("Reading PT RAM NODE 1---------------->\n");
    rc = cle_rw_ind(1, ptram_dn1_dump, CLE_ZONE_PT_RAM, CLE_OPT_CMD_RD);
    printf("Reading PT RAM NODE 11---------------->\n");
	rc = cle_rw_ind(11, ptram_kn11_dump, CLE_ZONE_PT_RAM, CLE_OPT_CMD_RD);
#endif
    return (rc);
}
/// CLE Debug Routine End


#if 0
int mirror = 0;
int ip_hdr,eth_hdr,ipprot_hdr,ip_ver,ip_prot,ip_frag,chksum; 
unsigned long long hinfo = 0x0;
void cle_indcmd_opr(unsigned int opr) {
  int indcmd_sts;
  int counter = 0;

  eth_wr(SM_CLE_3INLINE_CSR_INDCMD__ADDR, opr,ENET,0,0);
  do {
    indcmd_sts = eth_rd(SM_CLE_3INLINE_CSR_INDCMD_STATUS__ADDR,ENET,0,0);
    indcmd_sts &= opr;
    counter++;
  } while((indcmd_sts != opr) && (counter != MAX_INDCMD_DONE_COUNTER));
  if (indcmd_sts != opr) {printf("ERROR : XGENET_CLE_INDCMD_OPR timeout");printf("\n\r");}
}

// ----- PT RAM -----

void cle_wr_ptram(unsigned int *pt_ptr, unsigned int pt_addr) {
  unsigned int addr;

  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM0__ADDR , *pt_ptr,ENET,0,0); pt_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM1__ADDR , *pt_ptr,ENET,0,0); pt_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM2__ADDR , *pt_ptr,ENET,0,0); pt_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM3__ADDR , *pt_ptr,ENET,0,0); pt_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM4__ADDR , *pt_ptr,ENET,0,0); pt_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM5__ADDR , *pt_ptr,ENET,0,0); pt_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM6__ADDR , *pt_ptr,ENET,0,0); pt_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM7__ADDR , *pt_ptr,ENET,0,0); pt_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM8__ADDR , *pt_ptr,ENET,0,0); pt_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM9__ADDR , *pt_ptr,ENET,0,0); pt_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM10__ADDR, *pt_ptr,ENET,0,0); pt_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM11__ADDR, *pt_ptr,ENET,0,0); pt_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM12__ADDR, *pt_ptr,ENET,0,0); pt_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM13__ADDR, *pt_ptr,ENET,0,0); pt_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM14__ADDR, *pt_ptr,ENET,0,0); pt_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM15__ADDR, *pt_ptr,ENET,0,0); pt_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM16__ADDR, *pt_ptr,ENET,0,0);

  addr = (0xc0000000 + (pt_addr & 0x000001ff));
  eth_wr(SM_CLE_3INLINE_CSR_INDADDR__ADDR, addr);

  cle_indcmd_opr(INDCMD_WR);

  printf("PT Node Written: "); putnum(pt_addr); printf("\n");
}

void cfg_cle_ptram() {
  // ----- Writing Decision Nodes -----
  printf("\n ++++Writing Decsion Nodes ++++++\n");
  // Node0 - Checks MAC Destination Address
  printf("\n---- Node0 - Checks MAC Destination Address------\n");
  {
    struct cle_pt_dn ptram_dn = {
    //DN, LN, HS, HE, BS, SBS, R, DefPtr, R
       2,  0,  0,  0,  2,   0, 0,      0, 0,
    //V, P2B, jb, jr, Op, Node, BrKy, R, CMPDAT, MASK
    {{1,   2,  0,  1,  0,    0,    1, 0, 0x1100, 0xffff},
     {1,   2,  0,  1,  0,    0,    2, 0, 0x3322, 0xffff},
     {1,   8,  0,  1,  0,    1,    0, 0, 0x5544, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff}}};
    cle_wr_ptram((unsigned int *) &ptram_dn, 0);
  }

  // Node1 - Checks for VLAN ID
  printf("\n ------ Node1 - Checks for VLAN ID ------\n");
  {
    struct cle_pt_dn ptram_dn = {
    //DN, LN, HS, HE, BS, SBS, R, DefPtr, R
       2,  0,  0,  0,  0,   0, 0,      0, 0,
    //V, P2B, jb, jr, Op, Node, BrKy, R, CMPDAT, MASK
    {{1,   4,  0,  1,  0,    1,    0, 0, 0x0081, 0x0000},  //VLAN Tag
     {1,   4,  0,  1,  0,    1,    0, 0, 0x0091, 0x0000},  //VLAN Q-Q
     {1,   0,  0,  1,  0,    2,    0, 0, 0x0000, 0xffff},  //Not VLAN
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff}}};
    cle_wr_ptram((unsigned int *) &ptram_dn, 1);
  }

  // Node2 - Checks for EtherType i.e. IPv4/IPv6
  printf("\n ----- Node2 - Checks for EtherType i.e. IPv4/IPv6 ----\n");
  {
    struct cle_pt_dn ptram_dn = {
    //DN, LN, HS, HE, BS, SBS, R, DefPtr, R
       2,  0,  0,  0,  0,   0, 0,      0, 0,
    //V, P2B, jb, jr, Op, Node, BrKy, R, CMPDAT, MASK
    {{1,  14,  0,  1,  0,    5,    0, 0, 0x0008, 0x0000},  //IPv4
     {1,  10,  0,  1,  0,    7,    0, 0, 0xdd86, 0x0000},  //IPv6
     {1, 280,  0,  0,  0,   11,    0, 0, 0x0000, 0xffff},  //Non-IP
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff}}};
    cle_wr_ptram((unsigned int *) &ptram_dn, 2);
  }

  // Node3 - Checks CoS
  printf("\n ------ Node3 - Checks CoS ------\n");
  {
    struct cle_pt_dn ptram_dn = {
    //DN, LN, HS, HE, BS, SBS, R, DefPtr, R
       2,  0,  0,  3,  0,   0, 0,      0, 0,
    //V, P2B, jb, jr, Op, Node, BrKy, R, CMPDAT, MASK
    {{1,   8,  0,  1,  0,    4,    0, 0, 0x0000, 0xffff},  //IPv4
     {1,   6,  0,  1,  0,    4,    3, 0, 0x0000, 0xffff},  //IPv6
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff}}};
    cle_wr_ptram((unsigned int *) &ptram_dn, 3);
  }

  // Node4 - Checks for Protocol
  printf("\n ------ Node4 - Checks for Protocol ------\n");
  {
    struct cle_pt_dn ptram_dn = {
    //DN, LN, HS, HE, BS, SBS, R, DefPtr, R
       2,  0,  0,  0,  0,   0, 0,      0, 0,
    //V, P2B, jb, jr, Op, Node, BrKy, R, CMPDAT, MASK
    {{1, 256,  0,  0,  0,   12,    0, 0, 0x0600, 0x00ff},  //IPv4-TCP
     {1, 260,  0,  0,  0,   13,    0, 0, 0x1100, 0x00ff},  //IPv4-UDP
     {1, 264,  0,  0,  0,   14,    0, 0, 0x0000, 0xffff},  //IPv4-Others
     {1, 258,  0,  0,  0,   12,    4, 0, 0x0006, 0xff00},  //IPv6-TCP
     {1, 262,  0,  0,  0,   13,    4, 0, 0x0011, 0xff00},  //IPv6-UDP
     {1, 266,  0,  0,  0,   14,    4, 0, 0x0000, 0xffff},  //IPv6-Others
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff}}};
    cle_wr_ptram((unsigned int *) &ptram_dn, 4);
  }

  // Node5 - Checks Source IPv4 Address bytes
  printf("\n ------ Node5 - Checks Source IPv4 Address bytes ------\n");
  {
    struct cle_pt_dn ptram_dn = {
    //DN, LN, HS, HE, BS, SBS, R, DefPtr, R
       2,  0,  0,  0,  0,   0, 0,      0, 0,
    //V, P2B, jb, jr, Op, Node, BrKy, R, CMPDAT, MASK
    {{1,   2,  0,  1,  0,    5,    1, 0, 0x0000, 0xffff},
     {1,   2,  0,  1,  0,    6,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff}}};
    cle_wr_ptram((unsigned int *) &ptram_dn, 5);
  }

  // Node6 - Checks Destination IPv4 Address bytes
  printf("\n----- Node6 - Checks Destination IPv4 Address bytes ------\n");
  {
    struct cle_pt_dn ptram_dn = {
    //DN, LN, HS, HE, BS, SBS, R, DefPtr, R
       2,  0,  0,  0,  0,   0, 0,      0, 0,
    //V, P2B, jb, jr, Op, Node, BrKy, R, CMPDAT, MASK
    {{1,   2,  0,  1,  0,    6,    1, 0, 0x0000, 0xffff},
     {1,  18,  1,  0,  0,    3,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff}}};
    cle_wr_ptram((unsigned int *) &ptram_dn, 6);
  }

  // Node7 - Checks Source IPv6 Address bytes
  printf("\n ------ Node7 - Checks Source IPv6 Address bytes ------\n");
  {
    struct cle_pt_dn ptram_dn = {
    //DN, LN, HS, HE, BS, SBS, R, DefPtr, R
       2,  0,  0,  0,  0,   0, 0,      0, 0,
    //V, P2B, jb, jr, Op, Node, BrKy, R, CMPDAT, MASK
    {{1,   2,  0,  1,  0,    7,    1, 0, 0x0000, 0xffff},
     {1,   2,  0,  1,  0,    7,    2, 0, 0x0000, 0xffff},
     {1,   2,  0,  1,  0,    7,    3, 0, 0x0000, 0xffff},
     {1,   2,  0,  1,  0,    7,    4, 0, 0x0000, 0xffff},
     {1,   2,  0,  1,  0,    7,    5, 0, 0x0000, 0xffff},
     {1,   2,  0,  1,  0,    7,    6, 0, 0x0000, 0xffff},
     {1,   2,  0,  1,  0,    7,    7, 0, 0x0000, 0xffff},
     {1,   2,  0,  1,  0,    8,    0, 0, 0x0000, 0xffff}}};
    cle_wr_ptram((unsigned int *) &ptram_dn, 7);
  }

  // Node8 - Checks Destination IPv6 Address bytes
  printf("\n ------ Node8 - Checks Destination IPv6 Address bytes ------\n");
  {
    struct cle_pt_dn ptram_dn = {
    //DN, LN, HS, HE, BS, SBS, R, DefPtr, R
       2,  0,  0,  0,  0,   0, 0,      0, 0,
    //V, P2B, jb, jr, Op, Node, BrKy, R, CMPDAT, MASK
    {{1,   2,  0,  1,  0,    8,    1, 0, 0x0000, 0xffff},
     {1,   2,  0,  1,  0,    8,    2, 0, 0x0000, 0xffff},
     {1,   2,  0,  1,  0,    8,    3, 0, 0x0000, 0xffff},
     {1,   2,  0,  1,  0,    8,    4, 0, 0x0000, 0xffff},
     {1,   2,  0,  1,  0,    8,    5, 0, 0x0000, 0xffff},
     {1,   2,  0,  1,  0,    8,    6, 0, 0x0000, 0xffff},
     {1,   2,  0,  1,  0,    8,    7, 0, 0x0000, 0xffff},
     {1,  38,  1,  0,  0,    3,    1, 0, 0x0000, 0xffff}}};
    cle_wr_ptram((unsigned int *) &ptram_dn, 8);
  }

  //// Node9 - Checks TCP Port - Source
  //cle_wr_ptram((unsigned int *) &ptram_dn, 9);

  //// Node10 - Checks TCP Port - Destination
  //cle_wr_ptram((unsigned int *) &ptram_dn, 10);

  // Node11 - LastNode. Updates Side-band signals
  printf("\n ----- Node11 - LastNode. Updates Side-band signals ------\n");
  {  // Non-IP
    struct cle_pt_dn ptram_dn = {
    //DN, LN, HS, HE, BS, SBS, R, DefPtr, R
       2,  1,  1,  0,  0,   0, 0,      0, 0,
    //V, P2B, jb, jr, Op, Node, BrKy, R, CMPDAT, MASK
    {{1,   0,  0,  0,  0,  511,    0, 0, 0x0000, 0x00ff},  //P0
     {1,   0,  0,  0,  0,  510,    0, 0, 0x0100, 0x00ff},  //P1
     {1,   0,  0,  0,  0,  509,    0, 0, 0x0200, 0x00ff},  //P2
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff}}};
    cle_wr_ptram((unsigned int *) &ptram_dn, 11);
  }

  // Node12 - LastNode. Updates Side-band signals
  printf("\n ------ Node12 - LastNode. Updates Side-band signals ------\n");
  {  // TCP
    struct cle_pt_dn ptram_dn = {
    //DN, LN, HS, HE, BS, SBS, R, DefPtr, R
       2,  1,  1,  0,  0,   0, 0,      0, 0,
    //V, P2B, jb, jr, Op, Node, BrKy, R, CMPDAT, MASK
    {{1,   0,  0,  0,  0,  511,    1, 0, 0x0000, 0x00ff},  //P0-IPv4
     {1,   0,  0,  0,  0,  510,    1, 0, 0x0100, 0x00ff},  //P1-IPv4
     {1,   0,  0,  0,  0,  509,    1, 0, 0x0200, 0x00ff},  //P2-IPv4
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {1,   0,  0,  0,  0,  511,    4, 0, 0x0000, 0x00ff},  //P0-IPv6
     {1,   0,  0,  0,  0,  510,    4, 0, 0x0100, 0x00ff},  //P1-IPv6
     {1,   0,  0,  0,  0,  509,    4, 0, 0x0200, 0x00ff},  //P2-IPv6
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff}}};
    cle_wr_ptram((unsigned int *) &ptram_dn, 12);
  }

  // Node13 - LastNode. Updates Side-band signals
  printf("\n ----- Node13 - LastNode. Updates Side-band signals -----\n");
  {  // UDP
    struct cle_pt_dn ptram_dn = {
    //DN, LN, HS, HE, BS, SBS, R, DefPtr, R
       2,  1,  1,  0,  0,   0, 0,      0, 0,
    //V, P2B, jb, jr, Op, Node, BrKy, R, CMPDAT, MASK
    {{1,   0,  0,  0,  0,  511,    2, 0, 0x0000, 0x00ff},  //P0-IPv4
     {1,   0,  0,  0,  0,  510,    2, 0, 0x0100, 0x00ff},  //P1-IPv4
     {1,   0,  0,  0,  0,  509,    2, 0, 0x0200, 0x00ff},  //P2-IPv4
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {1,   0,  0,  0,  0,  511,    5, 0, 0x0000, 0x00ff},  //P0-IPv6
     {1,   0,  0,  0,  0,  510,    5, 0, 0x0100, 0x00ff},  //P1-IPv6
     {1,   0,  0,  0,  0,  509,    5, 0, 0x0200, 0x00ff},  //P2-IPv6
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff}}};
    cle_wr_ptram((unsigned int *) &ptram_dn, 13);
  }

  // Node14 - LastNode. Updates Side-band signals
  printf("\n ------ Node14 - LastNode. Updates Side-band signals ------\n");
  {  // Others
    struct cle_pt_dn ptram_dn = {
    //DN, LN, HS, HE, BS, SBS, R, DefPtr, R
       2,  1,  1,  0,  0,   0, 0,      0, 0,
    //V, P2B, jb, jr, Op, Node, BrKy, R, CMPDAT, MASK
    {{1,   0,  0,  0,  0,  511,    3, 0, 0x0000, 0x00ff},  //P0-IPv4
     {1,   0,  0,  0,  0,  510,    3, 0, 0x0100, 0x00ff},  //P1-IPv4
     {1,   0,  0,  0,  0,  509,    3, 0, 0x0200, 0x00ff},  //P2-IPv4
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff},
     {1,   0,  0,  0,  0,  511,    6, 0, 0x0000, 0x00ff},  //P0-IPv6
     {1,   0,  0,  0,  0,  510,    6, 0, 0x0100, 0x00ff},  //P1-IPv6
     {1,   0,  0,  0,  0,  509,    6, 0, 0x0200, 0x00ff},  //P2-IPv6
     {0,   0,  0,  0,  0,    0,    0, 0, 0x0000, 0xffff}}};
    cle_wr_ptram((unsigned int *) &ptram_dn, 14);
  }

  printf("\n+++++ Writing Key Nodes ++++++\n");

  printf("\n -----Node511 - Key Node -----\n");
  {  // Port0
    //Key Index Classification:
    //0-Non-IP, 1-IPv4, 4-IPv6
    struct cle_pt_kn ptram_kn = {
    //KN, R
       1, 0,
    //P, RAdr, R
    {{2,    1, 0}, {2,    2, 0}, {2,    3, 0}, {2,    4, 0},
     {2,    5, 0}, {2,    6, 0}, {2,    7, 0}, {0,    0, 0},
     {0,    0, 0}, {0,    0, 0}, {0,    0, 0}, {0,    0, 0},
     {0,    0, 0}, {0,    0, 0}, {0,    0, 0}, {0,    0, 0},
     {0,    0, 0}, {0,    0, 0}, {0,    0, 0}, {0,    0, 0},
     {0,    0, 0}, {0,    0, 0}, {0,    0, 0}, {0,    0, 0},
     {0,    0, 0}, {0,    0, 0}, {0,    0, 0}, {0,    0, 0},
     {0,    0, 0}, {0,    0, 0}, {0,    0, 0}, {0,    0, 0}}};
    cle_wr_ptram((unsigned int *) &ptram_kn, 511);
  }

  printf("\n ------ Node510 - Key Node ------\n");
  {  // Port1
    //Key Index Classification:
    //0-Non-IP, 1-IPv4, 4-IPv6
    struct cle_pt_kn ptram_kn = {
    //KN, R
       1, 0,
    //P, RAdr, R
    {{2,    9, 0}, {2,   10, 0}, {2,   11, 0}, {2,   12, 0},
     {2,   13, 0}, {2,   14, 0}, {2,   15, 0}, {0,    0, 0},
     {0,    0, 0}, {0,    0, 0}, {0,    0, 0}, {0,    0, 0},
     {0,    0, 0}, {0,    0, 0}, {0,    0, 0}, {0,    0, 0},
     {0,    0, 0}, {0,    0, 0}, {0,    0, 0}, {0,    0, 0},
     {0,    0, 0}, {0,    0, 0}, {0,    0, 0}, {0,    0, 0},
     {0,    0, 0}, {0,    0, 0}, {0,    0, 0}, {0,    0, 0},
     {0,    0, 0}, {0,    0, 0}, {0,    0, 0}, {0,    0, 0}}};
    cle_wr_ptram((unsigned int *) &ptram_kn, 510);
  }

  printf ("\n ------- Node509 - Key Node ------\n");
  {  // Port2
    //Key Index Classification:
    //0-Non-IP, 1-IPv4, 4-IPv6
    struct cle_pt_kn ptram_kn = {
    //KN, R
       1, 0,
    //P, RAdr, R
    {{2,   17, 0}, {2,   18, 0}, {2,   19, 0}, {2,   20, 0},
     {2,   21, 0}, {2,   22, 0}, {2,   23, 0}, {0,    0, 0},
     {0,    0, 0}, {0,    0, 0}, {0,    0, 0}, {0,    0, 0},
     {0,    0, 0}, {0,    0, 0}, {0,    0, 0}, {0,    0, 0},
     {0,    0, 0}, {0,    0, 0}, {0,    0, 0}, {0,    0, 0},
     {0,    0, 0}, {0,    0, 0}, {0,    0, 0}, {0,    0, 0},
     {0,    0, 0}, {0,    0, 0}, {0,    0, 0}, {0,    0, 0},
     {0,    0, 0}, {0,    0, 0}, {0,    0, 0}, {0,    0, 0}}};
    cle_wr_ptram((unsigned int *) &ptram_kn, 509);
  }
}

// ----- AVL RAM -----

void cle_avladd(unsigned int *avl_ptr, unsigned int avl_addr) {
  unsigned int addr;

  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM0__ADDR, *avl_ptr,ENET,0,0); avl_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM1__ADDR, *avl_ptr,ENET,0,0); avl_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM2__ADDR, *avl_ptr,ENET,0,0); avl_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM3__ADDR, *avl_ptr,ENET,0,0); avl_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM4__ADDR, *avl_ptr,ENET,0,0); avl_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM5__ADDR, *avl_ptr,ENET,0,0); avl_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM6__ADDR, *avl_ptr,ENET,0,0); avl_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM7__ADDR, *avl_ptr,ENET,0,0); avl_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM8__ADDR, *avl_ptr,ENET,0,0); avl_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM9__ADDR, *avl_ptr,ENET,0,0); avl_ptr++;//???
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM10__ADDR, *avl_ptr);

  addr = (0xd0000000 + (avl_addr & 0x000007ff)); 
  eth_wr(SM_CLE_3INLINE_CSR_INDADDR__ADDR, addr,ENET,0,0);

  cle_indcmd_opr(INDCMD_AVL_ADD);

  printf("AVL Node Added\n");
}

void cfg_cle_avlram() {
  unsigned int i;
  struct cle_avl_node avlram = {
  //SrchStr
  {0, 0, 0, 0, 0, 0, 0, 0},
  //DBPtr, R
        0, 0,
  //P, R
    7, 0,
  //V, Bal, RPtr, LPtr, R
    0,   0,    0,    0, 0};

  // Add required/true AVL Nodes
  avlram.srch_str[0] = 0x33221100;
  avlram.srch_str[1] = 0x00005544;
  avlram.dbptr    = 0;
  avlram.priority = 4;
  cle_avladd((unsigned int *) &avlram, 0);

  // Stuff AVL Nodes to achieve targetted Tree Depth searches
  avlram.srch_str[1] = 0;
  avlram.srch_str[2] = 0;
  avlram.srch_str[3] = 0;
  avlram.srch_str[4] = 0;
  avlram.srch_str[5] = 0;
  avlram.srch_str[6] = 0;
  avlram.srch_str[7] = 0;
  avlram.dbptr    = 0;
  avlram.priority = 7;
  for(i = 0; i < 1023 ; i++) {
    avlram.srch_str[0] = i;
    cle_avladd((unsigned int *) &avlram, i+1);
  }
}

// ----- DB RAM -----

void cle_wr_dbram(unsigned int *db_ptr, unsigned int db_addr) {
  unsigned int addr;

  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM0__ADDR, *db_ptr,ENET,0,0); db_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM1__ADDR, *db_ptr,ENET,0,0); db_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM2__ADDR, *db_ptr,ENET,0,0); db_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM3__ADDR, *db_ptr,ENET,0,0); db_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM4__ADDR, *db_ptr,ENET,0,0); db_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM5__ADDR, *db_ptr,ENET,0,0);

  addr = (0xe0000000 + (db_addr & 0x000003ff));
  eth_wr(SM_CLE_3INLINE_CSR_INDADDR__ADDR, addr,ENET,0,0);

  cle_indcmd_opr(INDCMD_WR);

  printf("DB RAM Entry Written: "); putnum(db_addr); printf("\n");
}

void cfg_cle_dbram() {
  struct cle_dbram db_ram = {
  //Word0
  0, 0, 0, 0, 0, 0, 0, 0,
  //Word1
  0,
  //Word2
  0, 0, 0, 0,
  // Word3
  0,
  //Word4
  0, 0, 0, 0, 0, 0,
  //Word5
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

  /* ----- For Error/Miss packets ----- */

  db_ram.hr       = 1;
  db_ram.mirror   = mirror;
  // Entry 0 - Default Result
  cle_wr_dbram((unsigned int *) &db_ram, 0);

  /* ----- For Port0 packets ----- */

  db_ram.fpsel    = 0;
  db_ram.nxtfpsel = 0;
  db_ram.dstqid0  = 0xc04 & 0x7f;
  db_ram.dstqid1  = 0xc04 >> 7;
  db_ram.henqnum  = 0xc00;

  db_ram.perflow   = 0x15;
  db_ram.flowgroup = 0xa;
  db_ram.priority  = 0x2;

  // Entry 1 - Non-IP Packet Result
  eth_hdr = 0xe;ip_hdr = 0x0; ipprot_hdr = 0x0;chksum = 0x0;ip_ver = 0x0;ip_prot = 3;
  set_hinfo();
  db_ram.hopinfolsbs0 = (hinfo & 0x7fff);
  db_ram.hopinfolsbs1 = (hinfo >> 15);
  db_ram.hopinfolsbs2 = (hinfo >> 47);
  cle_wr_dbram((unsigned int *) &db_ram, 1);

  // Entry 2 - IPv4-TCP Packet Result
  eth_hdr = 0xe;ip_hdr = 0x5; ipprot_hdr = 0x5;chksum = 0x1;ip_ver = 0x0;ip_prot = 0;
  set_hinfo();
  db_ram.hopinfolsbs0 = (hinfo & 0x7fff);
  db_ram.hopinfolsbs1 = (hinfo >> 15);
  db_ram.hopinfolsbs2 = (hinfo >> 47);
  cle_wr_dbram((unsigned int *) &db_ram, 2);

  // Entry 3 - IPv4-UDP Packet Result
  eth_hdr = 0xe;ip_hdr = 0x5; ipprot_hdr = 0x2;chksum = 0x1;ip_ver = 0x0;ip_prot = 1;
  set_hinfo();
  db_ram.hopinfolsbs0 = (hinfo & 0x7fff);
  db_ram.hopinfolsbs1 = (hinfo >> 15);
  db_ram.hopinfolsbs2 = (hinfo >> 47);
  cle_wr_dbram((unsigned int *) &db_ram, 3);

  // Entry 4 - IPv4-Others Packet Result
  eth_hdr = 0xe;ip_hdr = 0x5; ipprot_hdr = 0x0;chksum = 0x1;ip_ver = 0x0;ip_prot = 3;
  set_hinfo();
  db_ram.hopinfolsbs0 = (hinfo & 0x7fff);
  db_ram.hopinfolsbs1 = (hinfo >> 15);
  db_ram.hopinfolsbs2 = (hinfo >> 47);
  cle_wr_dbram((unsigned int *) &db_ram, 4);

  // Entry 5 - IPv6-TCP Packet Result
  eth_hdr = 0xe;ip_hdr = 0xa; ipprot_hdr = 0x5;chksum = 0x1;ip_ver = 0x1;ip_prot = 0;
  set_hinfo();
  db_ram.hopinfolsbs0 = (hinfo & 0x7fff);
  db_ram.hopinfolsbs1 = (hinfo >> 15);
  db_ram.hopinfolsbs2 = (hinfo >> 47);
  cle_wr_dbram((unsigned int *) &db_ram, 5);

  // Entry 6 - IPv6-UDP Packet Result
  eth_hdr = 0xe;ip_hdr = 0xa; ipprot_hdr = 0x2;chksum = 0x1;ip_ver = 0x1;ip_prot = 1;
  set_hinfo();
  db_ram.hopinfolsbs0 = (hinfo & 0x7fff);
  db_ram.hopinfolsbs1 = (hinfo >> 15);
  db_ram.hopinfolsbs2 = (hinfo >> 47);
  cle_wr_dbram((unsigned int *) &db_ram, 6);

  // Entry 7 - IPv6-Others Packet Result
  eth_hdr = 0xe;ip_hdr = 0xa; ipprot_hdr = 0x0;chksum = 0x1;ip_ver = 0x1;ip_prot = 3;
  set_hinfo();
  db_ram.hopinfolsbs0 = (hinfo & 0x7fff);
  db_ram.hopinfolsbs1 = (hinfo >> 15);
  db_ram.hopinfolsbs2 = (hinfo >> 47);
  cle_wr_dbram((unsigned int *) &db_ram, 7);

  /* ----- For Port1 packets ----- */

  db_ram.fpsel    = 1;
  db_ram.nxtfpsel = 0;
  db_ram.dstqid0  = 0xc05 & 0x7f;
  db_ram.dstqid1  = 0xc05 >> 7;
  db_ram.henqnum  = 0xc00;

  db_ram.perflow   = 0x5;
  db_ram.flowgroup = 0x4;
  db_ram.priority  = 0x3;

  // Entry 9 - Non-IP Packet Result
  eth_hdr = 0xe;ip_hdr = 0x0; ipprot_hdr = 0x0;chksum = 0x0;ip_ver = 0x0;ip_prot = 3;
  set_hinfo();
  db_ram.hopinfolsbs0 = (hinfo & 0x7fff);
  db_ram.hopinfolsbs1 = (hinfo >> 15);
  db_ram.hopinfolsbs2 = (hinfo >> 47);
  cle_wr_dbram((unsigned int *) &db_ram, 9);

  // Entry 10 - IPv4-TCP Packet Result
  eth_hdr = 0xe;ip_hdr = 0x5; ipprot_hdr = 0x5;chksum = 0x1;ip_ver = 0x0;ip_prot = 0;
  set_hinfo();
  db_ram.hopinfolsbs0 = (hinfo & 0x7fff);
  db_ram.hopinfolsbs1 = (hinfo >> 15);
  db_ram.hopinfolsbs2 = (hinfo >> 47);
  cle_wr_dbram((unsigned int *) &db_ram, 10);

  // Entry 11 - IPv4-UDP Packet Result
  eth_hdr = 0xe;ip_hdr = 0x5; ipprot_hdr = 0x2;chksum = 0x1;ip_ver = 0x0;ip_prot = 1;
  set_hinfo();
  db_ram.hopinfolsbs0 = (hinfo & 0x7fff);
  db_ram.hopinfolsbs1 = (hinfo >> 15);
  db_ram.hopinfolsbs2 = (hinfo >> 47);
  cle_wr_dbram((unsigned int *) &db_ram, 11);

  // Entry 12 - IPv4-Others Packet Result
  eth_hdr = 0xe;ip_hdr = 0x5; ipprot_hdr = 0x0;chksum = 0x1;ip_ver = 0x0;ip_prot = 3;
  set_hinfo();
  db_ram.hopinfolsbs0 = (hinfo & 0x7fff);
  db_ram.hopinfolsbs1 = (hinfo >> 15);
  db_ram.hopinfolsbs2 = (hinfo >> 47);
  cle_wr_dbram((unsigned int *) &db_ram, 12);

  // Entry 13 - IPv6-TCP Packet Result
  eth_hdr = 0xe;ip_hdr = 0xa; ipprot_hdr = 0x5;chksum = 0x1;ip_ver = 0x1;ip_prot = 0;
  set_hinfo();
  db_ram.hopinfolsbs0 = (hinfo & 0x7fff);
  db_ram.hopinfolsbs1 = (hinfo >> 15);
  db_ram.hopinfolsbs2 = (hinfo >> 47);
  cle_wr_dbram((unsigned int *) &db_ram, 13);

  // Entry 14 - IPv6-UDP Packet Result
  eth_hdr = 0xe;ip_hdr = 0xa; ipprot_hdr = 0x2;chksum = 0x1;ip_ver = 0x1;ip_prot = 1;
  set_hinfo();
  db_ram.hopinfolsbs0 = (hinfo & 0x7fff);
  db_ram.hopinfolsbs1 = (hinfo >> 15);
  db_ram.hopinfolsbs2 = (hinfo >> 47);
  cle_wr_dbram((unsigned int *) &db_ram, 14);

  // Entry 15 - IPv6-Others Packet Result
  eth_hdr = 0xe;ip_hdr = 0xa; ipprot_hdr = 0x0;chksum = 0x1;ip_ver = 0x1;ip_prot = 3;
  set_hinfo();
  db_ram.hopinfolsbs0 = (hinfo & 0x7fff);
  db_ram.hopinfolsbs1 = (hinfo >> 15);
  db_ram.hopinfolsbs2 = (hinfo >> 47);
  cle_wr_dbram((unsigned int *) &db_ram, 15);

  /* ----- For Port2 packets ----- */

  db_ram.fpsel    = 2;
  db_ram.nxtfpsel = 0;
  db_ram.dstqid0  = 0xc06 & 0x7f;
  db_ram.dstqid1  = 0xc06 >> 7;
  db_ram.henqnum  = 0xc00;

  db_ram.perflow   = 0xa;
  db_ram.flowgroup = 0x6;
  db_ram.priority  = 0x1;

  // Entry 17 - Non-IP Packet Result
  eth_hdr = 0xe;ip_hdr = 0x0; ipprot_hdr = 0x0;chksum = 0x0;ip_ver = 0x0;ip_prot = 3;
  set_hinfo();
  db_ram.hopinfolsbs0 = (hinfo & 0x7fff);
  db_ram.hopinfolsbs1 = (hinfo >> 15);
  db_ram.hopinfolsbs2 = (hinfo >> 47);
  cle_wr_dbram((unsigned int *) &db_ram, 17);

  // Entry 18 - IPv4-TCP Packet Result
  eth_hdr = 0xe;ip_hdr = 0x5; ipprot_hdr = 0x5;chksum = 0x1;ip_ver = 0x0;ip_prot = 0;
  set_hinfo();
  db_ram.hopinfolsbs0 = (hinfo & 0x7fff);
  db_ram.hopinfolsbs1 = (hinfo >> 15);
  db_ram.hopinfolsbs2 = (hinfo >> 47);
  cle_wr_dbram((unsigned int *) &db_ram, 18);

  // Entry 19 - IPv4-UDP Packet Result
  eth_hdr = 0xe;ip_hdr = 0x5; ipprot_hdr = 0x2;chksum = 0x1;ip_ver = 0x0;ip_prot = 1;
  set_hinfo();
  db_ram.hopinfolsbs0 = (hinfo & 0x7fff);
  db_ram.hopinfolsbs1 = (hinfo >> 15);
  db_ram.hopinfolsbs2 = (hinfo >> 47);
  cle_wr_dbram((unsigned int *) &db_ram, 19);

  // Entry 20 - IPv4-Others Packet Result
  eth_hdr = 0xe;ip_hdr = 0x5; ipprot_hdr = 0x0;chksum = 0x1;ip_ver = 0x0;ip_prot = 3;
  set_hinfo();
  db_ram.hopinfolsbs0 = (hinfo & 0x7fff);
  db_ram.hopinfolsbs1 = (hinfo >> 15);
  db_ram.hopinfolsbs2 = (hinfo >> 47);
  cle_wr_dbram((unsigned int *) &db_ram, 20);

  // Entry 21 - IPv6-TCP Packet Result
  eth_hdr = 0xe;ip_hdr = 0xa; ipprot_hdr = 0x5;chksum = 0x1;ip_ver = 0x1;ip_prot = 0;
  set_hinfo();
  db_ram.hopinfolsbs0 = (hinfo & 0x7fff);
  db_ram.hopinfolsbs1 = (hinfo >> 15);
  db_ram.hopinfolsbs2 = (hinfo >> 47);
  cle_wr_dbram((unsigned int *) &db_ram, 21);

  // Entry 22 - IPv6-UDP Packet Result
  eth_hdr = 0xe;ip_hdr = 0xa; ipprot_hdr = 0x2;chksum = 0x1;ip_ver = 0x1;ip_prot = 1;
  set_hinfo();
  db_ram.hopinfolsbs0 = (hinfo & 0x7fff);
  db_ram.hopinfolsbs1 = (hinfo >> 15);
  db_ram.hopinfolsbs2 = (hinfo >> 47);
  cle_wr_dbram((unsigned int *) &db_ram, 22);

  // Entry 23 - IPv6-Others Packet Result
  eth_hdr = 0xe;ip_hdr = 0xa; ipprot_hdr = 0x0;chksum = 0x1;ip_ver = 0x1;ip_prot = 3;
  set_hinfo();
  db_ram.hopinfolsbs0 = (hinfo & 0x7fff);
  db_ram.hopinfolsbs1 = (hinfo >> 15);
  db_ram.hopinfolsbs2 = (hinfo >> 47);
  cle_wr_dbram((unsigned int *) &db_ram, 23);
}

// ----- Packet RAM -----

void cle_wr_pktram(unsigned int *pkt_ptr, \
                   unsigned int port,     \
                   unsigned int pkt_addr)
{
  unsigned int base, addr;

  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM0__ADDR, *pkt_ptr,ENET,0,0); pkt_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM1__ADDR, *pkt_ptr,ENET,0,0); pkt_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM2__ADDR, *pkt_ptr,ENET,0,0); pkt_ptr++;
  eth_wr(SM_CLE_3INLINE_CSR_DATA_RAM3__ADDR, *pkt_ptr,ENET,0,0);

  base = (port == 0) ? 0x00000000 :
         (port == 1) ? 0x40000000 :
                       0x80000000;

  addr = (base + (pkt_addr & 0x0000003f));
  eth_wr(SM_CLE_3INLINE_CSR_INDADDR__ADDR, addr,ENET,0,0);

  cle_indcmd_opr(INDCMD_WR);

  printf("PktRAM");     putnum(port);
  printf(" Written: "); putnum(pkt_addr);
  printf("\n\n");
}

void cfg_cle_userdata() {
  unsigned int user_data[4] = {0, 0, 0, 0};

  // UserData 0
  printf("\n ---- UserData 0 ------\n");
  user_data[0] = 0x1ca81c50;  //{IPv6, IPv4} - TCP
  cle_wr_pktram((unsigned int *) user_data, 0, 0);
  cle_wr_pktram((unsigned int *) user_data, 1, 0);
  cle_wr_pktram((unsigned int *) user_data, 2, 0);

  // UserData 1
  printf("\n ---- UserData 1 ------\n");
  user_data[0] = 0x1caa1c52;  //{IPv6, IPv4} - UDP
  cle_wr_pktram((unsigned int *) user_data, 0, 1);
  cle_wr_pktram((unsigned int *) user_data, 1, 1);
  cle_wr_pktram((unsigned int *) user_data, 2, 1);

  // UserData 2
  printf("\n ---- UserData 2 ------\n");
  user_data[0] = 0x1cae1c56;  //{IPv6, IPv4} - Others
  cle_wr_pktram((unsigned int *) user_data, 0, 2);
  cle_wr_pktram((unsigned int *) user_data, 1, 2);
  cle_wr_pktram((unsigned int *) user_data, 2, 2);

  // UserData 6
  printf("\n ---- UserData 6 ------\n");
  user_data[0] = 0x1c001c00;  //Non-IP
  cle_wr_pktram((unsigned int *) user_data, 0, 6);
  cle_wr_pktram((unsigned int *) user_data, 1, 6);
  cle_wr_pktram((unsigned int *) user_data, 2, 6);
}

// ----- CLE CSR Configuration -----

void cfg_cle_csr() {
  // Program AVL Configuration CSR
  // Default Value is fine
//eth_wr(SM_CLE_3INLINE_CSR_AVL_CONFIG__ADDR, 0x3ffd7fc,ENET,0,0);

  // Program Start Node & Packet Pointers
  // Default Value is fine
//eth_wr(SM_CLE_3INLINE_CSR_SNPTR0__ADDR, 0x0,ENET,0,0);
//eth_wr(SM_CLE_3INLINE_CSR_SNPTR1__ADDR, 0x0,ENET,0,0);
//eth_wr(SM_CLE_3INLINE_CSR_SNPTR2__ADDR, 0x0,ENET,0,0);
  eth_wr(SM_CLE_3INLINE_CSR_SPPTR0__ADDR, 8,ENET,0,0);  //0);
  eth_wr(SM_CLE_3INLINE_CSR_SPPTR1__ADDR, 8,ENET,0,0);  //0);
  eth_wr(SM_CLE_3INLINE_CSR_SPPTR2__ADDR, 8,ENET,0,0);  //0);

  // Program Default DB Pointer
  // Default Value is fine
//eth_wr(SM_CLE_3INLINE_CSR_DFCLSRESDBPTR0__ADDR, 0x1c0,ENET,0,00);
//eth_wr(SM_CLE_3INLINE_CSR_DFCLSRESDBPTR1__ADDR, 0x1c00,ENET,0,0);
//eth_wr(SM_CLE_3INLINE_CSR_DFCLSRESDBPTR2__ADDR, 0x1c00,ENET,0,0);

  printf("CLE-Lite CSRs Configured\n");
}

// ----- CLE Configuration sequence -----

void cfg_cle() {
  printf("\n ====== Entering CLE Configuration ======\n");

  // Bring CLE CSR Clock-Reset up

  // Configure PT RAM
  cfg_cle_ptram();

  // Configure AVL RAM
  cfg_cle_avlram();

  // Configure DB RAM
  cfg_cle_dbram();

  // Configure UserData of PktRAM
  cfg_cle_userdata();

  // Configure CLE CSRs
  cfg_cle_csr();

  // Bring CLE Core Clocks-Resets up

  // Disabled CLE bypass in ENET/XGENET/MENET for CLE-InLines
  // Configure QMI for CLE-LA

  printf("Exiting CLE Configuration\n");
}
#endif // if 0
