//////////////////////////////////////////////////////////////////////////////////////////
//file name:    xgenet_mac.c
//create date:  1/9/2013
//description:  indirectory routine to access serdes.
//              configure xgenet serdes in storm
//////////////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <common.h>
#include "eth_common.h"
#include "eth_slt_tx2rx.h"
#include "eth_1g_csr.h"
#include "eth_xg_csr.h"
#include "eth_mg_csr.h"
#include "sm_xxx_serdes.h"

#include "qm_drv.h" 
#include "qm_misc.h"
#include "qm_vfw.h"

static int  read_data = 0x00000000;
static int  pemstat1_addr_reg;
static int  pemstat1_cmd_reg;
static int  pemstat1_read_reg;
static int  pemstat1_stat_reg;
static int  pemstat1_address  = 0x00000020;

static int  pemstat2_addr_reg;
static int  pemstat2_cmd_reg;
static int  pemstat2_read_reg;
static int  pemstat2_stat_reg;
static int  pemstat2_address  = 0x00000020;
static int  read_command = 0x40000000;
int  enet_base_addr_1 = ENET_01_BASE_ADDR;
static int terminal_server_serial_port = 0;  //1=Terminal Server; 0=Minicom

int xgbaser_ind_read(int addr, int port, int display){  // md: for 10gig mode
  int read_data;
  int counter = 0;

//  int port, display = 0;
  eth_wr(SM_XGENET_XGBASER_PCS_IND_CSR_IND_ADDR_0__ADDR,addr,XGENET,port,display);
  eth_wr(SM_XGENET_XGBASER_PCS_IND_CSR_IND_COMMAND_0__ADDR,0x40000000,XGENET,port,display);
  // wait till command done
  do {
     read_data = eth_rd(SM_XGENET_XGBASER_PCS_IND_CSR_IND_COMMAND_DONE_0__ADDR,XGENET,port,display);
     counter++;
  } while (read_data != 0x00000001 && counter != MAX_INDCMD_DONE_COUNTER);

  if(read_data != 0x1) { printf("ERROR : XGENET_INDIRECT XGBASER RD timeout");printf("\n\r"); }

  read_data = eth_rd(SM_XGENET_XGBASER_PCS_IND_CSR_IND_RDATA_0__ADDR,XGENET,port,display);
  eth_wr(SM_XGENET_XGBASER_PCS_IND_CSR_IND_COMMAND_0__ADDR,0x00000000,XGENET,port,display);

  printf("XGENET_INDIRECT XGBASER RD -- [0x");putnum(addr);printf("] -> [0x");putnum(read_data);printf("]\n\r");
  return read_data;
}

void xgbaser_ind_write (int addr, int data, int port, int display) {  // md: for 10gig mode
  int read_data;
  int counter = 0;
//  int port = 0;
//  int display =0;

  eth_wr(SM_XGENET_XGBASER_PCS_IND_CSR_IND_ADDR_0__ADDR,addr,XGENET,port,display);
  eth_wr(SM_XGENET_XGBASER_PCS_IND_CSR_IND_WDATA_0__ADDR,data,XGENET,port,display);
  eth_wr(SM_XGENET_XGBASER_PCS_IND_CSR_IND_COMMAND_0__ADDR,0x80000000,XGENET,port,display);
  // wait till command done
  do {
    read_data = eth_rd(SM_XGENET_XGBASER_PCS_IND_CSR_IND_COMMAND_DONE_0__ADDR,XGENET,port,display);
    counter++;
  } while (read_data != 0x00000001 && counter != MAX_INDCMD_DONE_COUNTER);

  if(read_data != 0x1) { printf("ERROR : XGENET_INDIRECT XGBASER WR timeout");printf("\n\r"); }

  //printf("XGENET_INDIRECT XGBASER WR @ 0x:"); putnum(addr); printf(" is 0x");  putnum(data);  printf("\n\r");
  eth_wr(SM_XGENET_XGBASER_PCS_IND_CSR_IND_COMMAND_0__ADDR, 0x00000000,XGENET,port,display);
}

//----------------------------------------------------------------------------------------------------------------------


void set_serdes_lpbk() {
    int intf,port,display=0; 
    uint32_t wr_val, rd_val;
    uint32_t inst, inst_base;

    printf("SATA-SGMII SERDES Tx2Rx Loopback\n");
    for (intf = 0; intf < 3;  intf+=2) {
        port = intf;
        printf("Tx2Rx loopback bit set before write\n");
        for (inst = 0; inst < 2;  inst++) {
            inst_base = 0x0400 + inst*0x0200;
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,ENET,port,display);
            printf("rx2tx_reg4 inst:%d inst_base:0x%xrd_val:0x%x\n",inst,inst_base,rd_val);
        }

        for (inst = 0; inst < 2;  inst++) {
            inst_base = 0x0400 + inst*0x0200;
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,ENET,port,display);
            wr_val = sm_enet_set(rd_val, 1, 6, 6);
            enet_sds_ind_csr_reg_wr("rxtx_reg4",  inst_base + 0x4*2, wr_val,ENET,port,display);

            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,ENET,port,display);
            wr_val = sm_enet_set(rd_val, 1, 14, 14);
            enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,ENET,port,display);
        }

        printf("Tx2Rx loopback bit set after write\n");
        for (inst = 0; inst < 2;  inst++) {
            inst_base = 0x0400 + inst*0x0200;
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,ENET,port,display);
            printf("rx2tx_reg4 inst:%d inst_base:0x%xrd_val:0x%x\n",inst,inst_base,rd_val);
        }
    }
#if 0
    printf("XFI-SGMII SERDES Tx2Rx Loopback\n");
    for (port = 0; port < 4; port++) {
        printf("Tx2Rx loopback bit set before write\n");
        for (inst = 0; inst < 1;  inst++) {
            inst_base = 0x0400 + inst*0x0200;
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,XGENET,port,display);
            printf("rx2tx_reg4 inst:%d inst_base:0x%xrd_val:0x%x\n",inst,inst_base,rd_val);
        }

        for (inst = 0; inst < 1;  inst++) {
            inst_base = 0x0400 + inst*0x0200;
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,XGENET,port,display);
            wr_val = sm_enet_set(rd_val, 1, 6, 6);
            enet_sds_ind_csr_reg_wr("rxtx_reg4",  inst_base + 0x4*2, wr_val,XGENET,port,display);

            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,XGENET,port,display);
            wr_val = sm_enet_set(rd_val, 1, 14, 14);
            enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,XGENET,port,display);
        }

        printf("Tx2Rx loopback bit set after write\n");
        for (inst = 0; inst < 1;  inst++) {
            inst_base = 0x0400 + inst*0x0200;
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,XGENET,port,display);
            printf("rx2tx_reg4 inst:%d inst_base:0x%xrd_val:0x%x\n",inst,inst_base,rd_val);
        }
    }
#endif
}

void reset_serdes_lpbk() {
    int intf,port,display=0; 
    uint32_t wr_val, rd_val;
    uint32_t inst, inst_base;

    printf("SATA-SGMII SERDES Tx2Rx Loopback\n");
    for (intf = 0; intf < 3;  intf+=2) {
        port = intf;
        printf("Tx2Rx loopback bit set before write\n");
        for (inst = 0; inst < 2;  inst++) {
            inst_base = 0x0400 + inst*0x0200;
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,ENET,port,display);
            printf("rx2tx_reg4 inst:%d inst_base:0x%xrd_val:0x%x\n",inst,inst_base,rd_val);
        }

        for (inst = 0; inst < 2;  inst++) {
            inst_base = 0x0400 + inst*0x0200;
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,ENET,port,display);
            wr_val = sm_enet_set(rd_val, 0, 6, 6);
            enet_sds_ind_csr_reg_wr("rxtx_reg4",  inst_base + 0x4*2, wr_val,ENET,port,display);

            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,ENET,port,display);
            wr_val = sm_enet_set(rd_val, 0, 14, 14);
            enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,ENET,port,display);
        }

        printf("Tx2Rx loopback bit set after write\n");
        for (inst = 0; inst < 2;  inst++) {
            inst_base = 0x0400 + inst*0x0200;
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,ENET,port,display);
            printf("rx2tx_reg4 inst:%d inst_base:0x%xrd_val:0x%x\n",inst,inst_base,rd_val);
        }
    }
#if 0 
    printf("XFI-SGMII SERDES Tx2Rx Loopback\n");
    for (port = 0; port < 4; port++) {
        printf("Tx2Rx loopback bit set before write\n");
        for (inst = 0; inst < 1;  inst++) {
            inst_base = 0x0400 + inst*0x0200;
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,XGENET,port,display);
            printf("rx2tx_reg4 inst:%d inst_base:0x%xrd_val:0x%x\n",inst,inst_base,rd_val);
        }

        for (inst = 0; inst < 1;  inst++) {
            inst_base = 0x0400 + inst*0x0200;
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,XGENET,port,display);
            wr_val = sm_enet_set(rd_val, 0, 6, 6);
            enet_sds_ind_csr_reg_wr("rxtx_reg4",  inst_base + 0x4*2, wr_val,XGENET,port,display);

            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,XGENET,port,display);
            wr_val = sm_enet_set(rd_val, 0, 14, 14);
            enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,XGENET,port,display);
        }

        printf("Tx2Rx loopback bit set after write\n");
        for (inst = 0; inst < 1;  inst++) {
            inst_base = 0x0400 + inst*0x0200;
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,XGENET,port,display);
            printf("rx2tx_reg4 inst:%d inst_base:0x%xrd_val:0x%x\n",inst,inst_base,rd_val);
        }
    }
#endif
}


void xfi_sgmii_serdes_reg_dump() {

    int inst_base_temp , port ,k , rd_reg_val , display_val ;
    inst_base_temp = 0x0400;
    display_val = 0;

    printf("\n\nXFI-SGMII SERDES CMU REG Values (0x0000 to 0x004e): \n");
    printf("\t\t\tGE-0\t\tGE-1\t\t\tGE-2\t\t\tGE-3");
    for(k=0; k<=39; k++) {
        printf("\nCMU_REG_%d :", k);
        for(port=0; port<=3; port++) {
            rd_reg_val = enet_sds_ind_csr_reg_rd("CMU_reg0", CMU + 2*k , XGENET , port , display_val); 
            printf("\t[0x0000%08x]", rd_reg_val);
        }
    }

    printf("\n\nXFI-SGMII SERDES RXTX REG Values (0x0400 to 0x0544): \n");
    printf("\t\t\tGE-0\t\t\tGE-1\t\t\tGE-2\t\t\tGE-3");

    for(k=0; k<=162; k++) {
        printf("\nRXTX_REG_%d :", k);
        for(port=0; port<=3; port++) {
            rd_reg_val = enet_sds_ind_csr_reg_rd("rxtx_reg0", inst_base_temp + 2*k , XGENET , port , display_val);
            printf("\t[0x0000%08x]", rd_reg_val);
        }
    }

    printf("\n\n");
}


void sata_sgmii_serdes_reg_dump() {

    int inst_base_temp , port ,k , rd_reg_val , display_val,inst ;
    display_val = 0;

    printf("\n\nSATA-SGMII SERDES CMU REG Values (0x0000 to 0x004e): \n");
    printf("\t\t\tGE-0/1 \t\t\t GE-2/3");
    for(k=0; k<=39; k++) {
        printf("\nCMU_REG_%d :", k);
        for(port=0; port<=3; port+=2) {
            rd_reg_val = enet_sds_ind_csr_reg_rd("CMU_reg0", CMU + 2*k , ENET , port , display_val); 
            printf("\t[0x0000%08x]", rd_reg_val);
        }
    }

    printf("\n\nSATA-SGMII SERDES RXTX REG Values (0x0400 to 0x0540 & 0x0600 to 0x740): \n");
    printf("\t\t\tGE-0\t\t\tGE-1\t\t\tGE-2\t\t\tGE-3");

    for(k=0; k<=162; k++) {
        printf("\nRXTX_REG_%d :", k);
        for(port=0; port<=3; port+=2) {
            for (inst = 0; inst < 2;  inst++) {
                inst_base_temp = 0x0400 + inst*0x0200;
                rd_reg_val = enet_sds_ind_csr_reg_rd("rxtx_reg0", inst_base_temp + 2*k , ENET , port , display_val);
                printf("\t[0x0000%08x]", rd_reg_val);
            }
        }
    }

    printf("\n\nSATA-SGMII SERDES CMU REG Values (0x20000 to 0x2004e): \n");
    printf("\t\t\tGE-0/1 \t\t\tGE-2/3");
    for(k=0; k<=39; k++) {
        printf("\nCMU_REG_%d :", k);
        for(port=0; port<=3; port+=2) {
            inst_base_temp = 0x20000;
            rd_reg_val = enet_sds_ind_csr_reg_rd("CMU_reg0", inst_base_temp + 2*k , ENET , port , display_val); 
            printf("\t[0x0000%08x]", rd_reg_val);
        }
    }
    printf("\n\n");
}

int myread(int *address, int display){
    int *addr_int;
    addr_int = address;
    int rdata = *addr_int;
    if(display_all|display){ printf("Read32 addr:0x%x data:0x%x\n",addr_int,rdata);}
    return(rdata);
}

void mywrite(int *address, int data){
    int *addr_int;
    addr_int = address;
    *addr_int = data;
    if(display_all){ printf("write2 addr:0x%x data:0x%x\n",addr_int,data);}
}

int my_get_val(char *str){
    int val;
    printf(str);
    val = get_val();
    printf("\n\r");
    return val;
}

void enet_init_ecc(int port, int display) {
    uint32_t rd_data;
    int i;

    eth_wr(SM_GLBL_DIAG_CSR_CFG_MEM_RAM_SHUTDOWN__ADDR, 0x0,ENET,port,display);
    rd_data = eth_rd(SM_GLBL_DIAG_CSR_CFG_MEM_RAM_SHUTDOWN__ADDR,ENET,port,display);

    rd_data = eth_rd(SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY__ADDR,ENET,port,display);
    while (rd_data != 0xFFFFFFFF) {
        rd_data = eth_rd(SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY__ADDR,ENET,port,display);
    }

    for (i = 0; i < 5; i++) {
        rd_data = eth_rd(SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY__ADDR,ENET,port,display);
    }
}

void enet_clkcfg_1(int port, int display){
    eth_wr(SM_ENET_CLKRST_CSR_ENET_CLKEN__ADDR,0x00000000,ENET,port,display); 

    eth_wr(SM_ENET_CLKRST_CSR_ENET_SRST__ADDR ,0xFFFFFFFF,ENET,port,display); 
    USDELAY(10);

    eth_wr(SM_ENET_CLKRST_CSR_ENET_CLKEN__ADDR,0xFFFFFFFF,ENET,port,display); 
    USDELAY(10);

    eth_wr(SM_ENET_CLKRST_CSR_ENET_SRST__ADDR ,0x00000002,ENET,port,display); 
    USDELAY(10);
}

void enet_clkcfg_2(int port, int display){
    USDELAY(10);
    eth_wr(SM_ENET_CLKRST_CSR_ENET_SRST__ADDR ,0x00000000,ENET,port,display); 

    enet_init_ecc(port, display);
}

void read_statistics(int port){
    int i,j;
    int display = 0;
    printf("\n\r MACOUT reg ");putnum(eth_rd(SM_ENET_CSR_MACOUT_ENET_STAT_REG_PORT0__ADDR,ENET,port,display));
    printf("\n\r MACIN reg ");putnum(  eth_rd(SM_ENET_CSR_MACIN_ENET_STAT_REG_PORT0__ADDR,ENET,port,display));
    printf("\n\r RXBIN reg ");putnum(  eth_rd(SM_ENET_CSR_RXBIN_ENET_STAT_REG_PORT0__ADDR,ENET,port,display));
    printf("\n\r Port0: RSIF CNTR reg ");putnum(  eth_rd(SM_ENET_CSR_RSIF_STS_CNTR_REG0__ADDR,ENET,port,display));
    printf("\n\r Port1: RSIF CNTR reg ");putnum(  eth_rd(SM_ENET_CSR_RSIF_STS_CNTR_REG1__ADDR,ENET,port,display));

    printf("\n\r Port0: RSIF STS CLE Drop CNTR reg0 ");putnum(  eth_rd(SM_ENET_CSR_RSIF_STS_CLE_DROP_CNTR_REG0__ADDR,ENET,port,display));
    printf("\n\r {Port1, Port0}: RSIF FP Timeout counter ");putnum(  eth_rd(SM_ENET_CSR_RSIF_FPBUFF_TIMEOUT_STSREG0__ADDR,ENET,port,display));
    printf("\n\r {Port1, Port0}: RSIF FP Partial drop Timeout counter ");putnum(  eth_rd(SM_ENET_CSR_RSIF_FPBUFF_TIMEOUT_PARTIALDROP_STSREG0__ADDR,ENET,port,display));
    printf("\n\r {Port1, Port0}: TSIF CNTR reg ");putnum(  eth_rd(SM_ENET_CSR_TSIF_STS_REG1__ADDR,ENET,port,display));
    printf("\n\r {Port1, Port0}: TSIF Dealloc message cntr reg ");putnum(  eth_rd(SM_ENET_CSR_TSIF_STS_REG2__ADDR,ENET,port,display));
    printf("\n\r {Port1, Port0}: TSIF Bad message cntr reg ");putnum(  eth_rd(SM_ENET_CSR_TSIF_STS_REG3__ADDR,ENET,port,display));

    printf("\n\r RX_TX_BUF_STS reg ");putnum(  eth_rd(SM_ENET_CSR_RX_TX_BUF_STS_REG0__ADDR,ENET,port,display));
    printf("\n\r RSIF FIFO STS reg ");putnum(  eth_rd(SM_ENET_CSR_RSIF_FIFO_EMPTYSTS0__ADDR,ENET,port,display));
    printf("\n\r TSIF FIFO STS reg ");putnum(  eth_rd(SM_ENET_CSR_TSIF_FIFO_EMPTYSTS0__ADDR,ENET,port,display));
    printf("\n\r MAC FIFO STS reg ");putnum(  eth_rd(SM_ENET_MAC_CSR_MAC_FIFO_STS_REG0__ADDR,ENET,port,display));
    printf("\n\r RX DV GATE reg0 ");putnum(  eth_rd(SM_ENET_MAC_CSR_RX_DV_GATE_REG_0__ADDR,ENET,port,display));
    printf("\n\r RX DV GATE reg1 ");putnum(  eth_rd(SM_ENET_MAC_CSR_RX_DV_GATE_REG_1__ADDR,ENET,port,display));
    printf("\n\r LINK STS SEL reg ");putnum(  eth_rd(SM_ENET_CSR_CFG_LINK_STS_SEL__ADDR,ENET,port,display));
    printf("\n\r LINK AGGR RESUMEreg ");putnum(  eth_rd(SM_ENET_CSR_CFG_LINK_AGGR_RESUME_0__ADDR,ENET,port,display));
    printf("\n\r LINK AGGR ");putnum(  eth_rd(SM_ENET_CSR_CFG_LINK_AGGR__ADDR,ENET,port,display));
    printf("\n\r LINK STATUS ");putnum(  eth_rd(SM_ENET_CSR_LINK_STATUS__ADDR,ENET,port,display));
    printf("\n\r CLKEN ");putnum(  eth_rd(SM_ENET_CLKRST_CSR_ENET_CLKEN__ADDR,ENET,port,display));
    printf("\n\r SRST ");putnum(  eth_rd(SM_ENET_CLKRST_CSR_ENET_SRST__ADDR,ENET,port,display));
    printf("\n\r CFG_BYPASS ");putnum(  eth_rd(SM_ENET_CSR_CFG_BYPASS__ADDR,ENET,port,display));
    printf("\n\r TXB STAT ");putnum(  eth_rd(SM_ENET_CSR_TXB_ENET_STAT_REG_PORT0__ADDR,ENET,port,display));
    printf("\n\r RGMII REG 0 ");putnum(  eth_rd(SM_ENET_CSR_RGMII_REG_0__ADDR,ENET,port,display));
    printf("\n\r ICM_ECM_DROP_COUNT_REG_0 ");putnum(  eth_rd(SM_ENET_MAC_CSR_ICM_ECM_DROP_COUNT_REG_0__ADDR,ENET,port,display));
    printf("\n\r ICM_ECM_DROP_COUNT_REG_1 ");putnum(  eth_rd(SM_ENET_MAC_CSR_ICM_ECM_DROP_COUNT_REG_1__ADDR,ENET,port,display));
    printf("\nTSIF/RSIF Interrupt Status Register Dumps:\n");
    printf("\n\r SM_ENET_CSR_RSIF_INT_REG0__ADDR ");putnum(  eth_rd(SM_ENET_CSR_RSIF_INT_REG0__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_RSIF_FINT_REG0__ADDR ");putnum(  eth_rd(SM_ENET_CSR_RSIF_FINT_REG0__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_RSIF_INT_REG1__ADDR ");putnum(  eth_rd(SM_ENET_CSR_RSIF_INT_REG1__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_RSIF_FINT_REG1__ADDR ");putnum(  eth_rd(SM_ENET_CSR_RSIF_FINT_REG1__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_RSIF_INT_REG0MASK__ADDR ");putnum(  eth_rd(SM_ENET_CSR_RSIF_INT_REG0MASK__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_RSIF_INT_REG1MASK__ADDR ");putnum(  eth_rd(SM_ENET_CSR_RSIF_INT_REG1MASK__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_RSIF_FINT_REG0MASK__ADDR ");putnum(  eth_rd(SM_ENET_CSR_RSIF_FINT_REG0MASK__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_RSIF_FINT_REG1MASK__ADDR ");putnum(  eth_rd(SM_ENET_CSR_RSIF_FINT_REG1MASK__ADDR,ENET,port,display));

    printf("\n\r SM_ENET_CSR_TSIF_INT_REG0__ADDR ");putnum(  eth_rd(SM_ENET_CSR_TSIF_INT_REG0__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_TSIF_FINT_REG0__ADDR ");putnum(  eth_rd(SM_ENET_CSR_TSIF_FINT_REG0__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_TSIF_INT_REG0MASK__ADDR ");putnum(  eth_rd(SM_ENET_CSR_TSIF_INT_REG0MASK__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_TSIF_INT_REG0__ADDR ");putnum(  eth_rd(SM_ENET_CSR_TSIF_INT_REG0__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_TSIF_FINT_REG0MASK__ADDR ");putnum(  eth_rd(SM_ENET_CSR_TSIF_FINT_REG0MASK__ADDR,ENET,port,display));

    printf("\n\r SM_ENET_CSR_TSIF_STS_REG0__ADDR ");putnum(  eth_rd(SM_ENET_CSR_TSIF_STS_REG0__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_TSIF_STS_REG1__ADDR ");putnum(  eth_rd(SM_ENET_CSR_TSIF_STS_REG1__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_TSIF_STS_REG2__ADDR ");putnum(  eth_rd(SM_ENET_CSR_TSIF_STS_REG2__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_TSIF_STS_REG3__ADDR ");putnum(  eth_rd(SM_ENET_CSR_TSIF_STS_REG3__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_RSIF_STS_REG0__ADDR ");putnum(  eth_rd(SM_ENET_CSR_RSIF_STS_REG0__ADDR,ENET,port,display));
    printf("\n");
    printf("\nQMI Interrupt Status Register Dumps:\n");

    printf("\n\r SM_ENET_CSR_STS_ECM_SOF0_CNTRL_WORD_0__ADDR  ");putnum(eth_rd(SM_ENET_CSR_STS_ECM_SOF0_CNTRL_WORD_0__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_STS_ECM_SOF1_CNTRL_WORD_1__ADDR  ");putnum(eth_rd(SM_ENET_CSR_STS_ECM_SOF1_CNTRL_WORD_0__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_STS_ECM_SOF2_CNTRL_WORD_2__ADDR  ");putnum(eth_rd(SM_ENET_CSR_STS_ECM_SOF2_CNTRL_WORD_0__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_STS_ECM_SOF3_CNTRL_WORD_3__ADDR  ");putnum(eth_rd(SM_ENET_CSR_STS_ECM_SOF3_CNTRL_WORD_0__ADDR,ENET,port,display));
    printf("\n\r SM_ENET_CSR_STS_ECM_EOF1_CNTRL_WORD_3__ADDR  ");putnum(eth_rd(SM_ENET_CSR_STS_ECM_EOF1_CNTRL_WORD_0__ADDR,ENET,port,display));

    pemstat1_addr_reg = enet_base_addr_1 + SM_ENET_MACIP_IND_CSR_STAT_IND_ADDR_0__ADDR;
    pemstat1_cmd_reg  = enet_base_addr_1 + SM_ENET_MACIP_IND_CSR_STAT_IND_COMMAND_0__ADDR;
    pemstat1_read_reg = enet_base_addr_1 + SM_ENET_MACIP_IND_CSR_STAT_IND_RDATA_0__ADDR;
    pemstat1_stat_reg = enet_base_addr_1 + SM_ENET_MACIP_IND_CSR_STAT_IND_COMMAND_DONE_0__ADDR;
    pemstat1_address  = 0x00000020;

    pemstat2_addr_reg = enet_base_addr_1 + SM_ENET_MACIP_IND_CSR_STAT_IND_ADDR_1__ADDR;
    pemstat2_cmd_reg  =  enet_base_addr_1 + SM_ENET_MACIP_IND_CSR_STAT_IND_COMMAND_1__ADDR;
    pemstat2_read_reg = enet_base_addr_1 + SM_ENET_MACIP_IND_CSR_STAT_IND_RDATA_1__ADDR;
    pemstat2_stat_reg = enet_base_addr_1 + SM_ENET_MACIP_IND_CSR_STAT_IND_COMMAND_DONE_1__ADDR;
    pemstat2_address  = 0x00000020;

    //port0 pemstat
    i = 0;
    printf("\r\nPort-0 Pemstats:\n\r");
    for (j=0; j<48; j++)
    {
        i = i + 1;
        mywrite(pemstat1_addr_reg,pemstat1_address + j);
        mywrite(pemstat1_cmd_reg,read_command);
        //		xil_printf("entered in pemstat 0 loop command written.. waiting for read");
        do
        {
            read_data = myread(pemstat1_stat_reg,0);
        } while (read_data != 0x00000001);
        mywrite(pemstat1_cmd_reg,0x00000000);
        read_data = myread(pemstat1_read_reg,0);
        printf("0x");putnum(pemstat1_address + j);printf(" = 0x");putnum(read_data);printf(" \t");

        if(i==4)
        {
            i = 0;
            printf("\n\r");
        }
    }

    //port1 pemstat
    i = 0;
    printf("\r\n Port-1 Pemstats:\n\r");
    for (j=0; j<48; j++)
    {
        i = i + 1;
        mywrite(pemstat2_addr_reg,pemstat2_address + j);
        mywrite(pemstat2_cmd_reg,read_command);
        //		xil_printf("entered in pemstat 0 loop command written.. waiting for read");
        do
        {
            read_data = myread(pemstat2_stat_reg,0);
        } while (read_data != 0x00000001);
        mywrite(pemstat2_cmd_reg,0x00000000);
        read_data = myread(pemstat2_read_reg,0);
        printf("0x");putnum(pemstat2_address + j);printf(" = 0x");putnum(read_data);printf(" \t");

        if(i==4)
        {
            i = 0;
            printf("\n\r");
        }
    }
}

void print_stat_sgmii_sata() {
    int temp,port,intf;
    temp = my_get_val("select port 0/1/2/3");
    port = temp & 0x3;
    intf = temp & 0x2;
    enet_base_addr_1 =  intf ? ENET_23_BASE_ADDR : ENET_01_BASE_ADDR; 
    read_statistics(port);
}

//-------------------------------------------------------------------------------------------------------------
// for MENENT Port   
void menet_init_ecc() {
    uint32_t rd_data;
    int i;
    eth_wr(SM_GLBL_DIAG_CSR_CFG_MEM_RAM_SHUTDOWN__ADDR, 0x0,MENET,0,0);
    rd_data = eth_rd(SM_GLBL_DIAG_CSR_CFG_MEM_RAM_SHUTDOWN__ADDR,MENET,0,0);
    rd_data = eth_rd(SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY__ADDR,MENET,0,0);
    while (rd_data != 0xFFFFFFFF) {
        rd_data = eth_rd(SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY__ADDR,MENET,0,0);
    }
    for (i = 0; i < 5; i++) {
        rd_data = eth_rd(SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY__ADDR,MENET,0,0);
    }
}

void menet_clkcfg() {
    int timeout;

    eth_wr(SM_MENET_CLKRST_CSR_ENET_CLKEN__ADDR,0x00000000,MENET,0,0); 
    eth_wr(SM_MENET_CLKRST_CSR_ENET_SRST__ADDR ,0xFFFFFFFF,MENET,0,0); 
    for(timeout=0;timeout<8000;timeout++);

    eth_wr(SM_MENET_CLKRST_CSR_ENET_CLKEN__ADDR,0xFFFFFFFF,MENET,0,0); 
    for(timeout=0;timeout<8000;timeout++);

    eth_wr(SM_MENET_CLKRST_CSR_ENET_SRST__ADDR ,0x00000002,MENET,0,0); 
    for(timeout=0;timeout<8000;timeout++);

    eth_wr(SM_MENET_CLKRST_CSR_ENET_SRST__ADDR ,0x00000000,MENET,0,0);

    menet_init_ecc();
}

void mgmt_mac_config() {
    int rd_data;

    rd_data = mcxmac_ind_rd(PE_MCXMAC_MAC_CONFIG_1__ADDR, MENET,0, 0);

    rd_data = 0x35; // release reset; tx/rx enable; tx/rx flow enable
    mcxmac_ind_wr(PE_MCXMAC_MAC_CONFIG_1__ADDR,rd_data,MENET, 0, 0);

    rd_data = mcxmac_ind_rd(PE_MCXMAC_MAC_CONFIG_1__ADDR, MENET, 0, 0);
}

/*
   SGMII-SATA PHY Address=0x11 to 0x14
   SGMII-XFI  PHY Address=0x15 to 0x18
 */
u32 mdio_sgmii_phyId_regression_test(int phy_addr, int phy_reg, int count) {

    u32 fail_count=0,tmp;
    int ind_address,ind_data;

    tmp = count;

    printf("\nSGMII Port MDIO PHY_Addr:0x%x PHY-ID Read RegressionTest Started ... TotalIteration:%d\n",phy_addr,tmp);

    ind_address = ((phy_addr << 8) | phy_reg);
    while (count) {
        ind_data = mdio_rd(ind_address,MENET,0,0);
        if(ind_data != 0x141) {
            fail_count++;
            //printf("0x%08x ",ind_data);
        }
        count--;
    }
    if(fail_count)
        printf("MDIO PHY-ID Read RegressionTest for PHY_Addr:0x%x PHY_ID:0x%x Fail, FailCount:%d/%d Iteration\n",phy_addr,ind_data,fail_count, tmp);
    else
        printf("MDIO PHY-ID Read RegressionTest for PHY_Addr:0x%x PHY_ID:0x%x Pass\n",phy_addr,ind_data);
}

/*
   RGMII PHY Address=2
 */
u32 mdio_rgmii_phyId_regression_test(int phy_addr, int phy_reg, int count) {

    u32 fail_count=0,tmp;
    int ind_address,ind_data;

    tmp = count;

    printf("\nRGMII Port MDIO PHY_Addr:0x%x PHY-ID Read RegressionTest Started ... TotalIteration:%d\n",phy_addr,tmp);

    ind_address = ((phy_addr << 8) | phy_reg);
    while (count) {
        ind_data = mdio_rd(ind_address,MENET,0,0);
        if(ind_data != 0x1c) {
            fail_count++;
            //printf("0x%08x ",ind_data);
        }
        count--;
    }
    if(fail_count)
        printf("MDIO PHY-ID Read RegressionTest for PHY_Addr:0x%x PHY_ID:0x%x Fail, FailCount:%d/%d Iteration\n",phy_addr,ind_data,fail_count, tmp);
    else
        printf("MDIO PHY-ID Read RegressionTest for PHY_Addr:0x%x PHY_ID:0x%x Pass\n",phy_addr,ind_data);
}

void clk_reset_cfg(int port, int display) {
    int read_data;
    eth_wr(SM_XGENET_CLKRST_CSR_XGENET_CLKEN__ADDR, 0x0,XGENET,port,display);

    eth_wr(SM_XGENET_CLKRST_CSR_XGENET_SRST__ADDR, 0xFFFFFFFF,XGENET,port,display);
    USDELAY(10);

    eth_wr(SM_XGENET_CLKRST_CSR_XGENET_CONFIG_REG__ADDR,0x01,XGENET,port,display); // use AXI clock in CLE//SGMII
    eth_wr(SM_XGENET_CLKRST_CSR_XGENET_CLKEN__ADDR, 0x3,XGENET,port,display);//core blk clk & csr clk enable
    USDELAY(10);

    eth_wr(SM_XGENET_CLKRST_CSR_XGENET_SRST__ADDR, 0x3,XGENET,port,display);//rst core &csr blk
    USDELAY(10);

    eth_wr(SM_XGENET_CLKRST_CSR_XGENET_SRST__ADDR, 0x2,XGENET,port,display);
    USDELAY(10);
}

void xgenet_init_ecc(int port, int display) {
    uint32_t rd_data;
    int i;

    eth_wr(SM_GLBL_DIAG_CSR_CFG_MEM_RAM_SHUTDOWN__ADDR, 0x0,XGENET,port,display);
    rd_data = eth_rd(SM_GLBL_DIAG_CSR_CFG_MEM_RAM_SHUTDOWN__ADDR,XGENET,port,display);

    rd_data = eth_rd(SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY__ADDR,XGENET,port,display);
    while (rd_data != 0xFFFFFFFF) {
        rd_data = eth_rd(SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY__ADDR,XGENET,port,display);
    }

    for (i = 0; i < 5; i++) {
        rd_data = eth_rd(SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY__ADDR,XGENET,port,display);
    }
}

void read_common_statistics(int port){
    int i,j;
    int display =1;
    printf("\nMACOUT reg ");
    eth_rd(SM_XGENET_CSR_MACOUT_ENET_STAT_REG__ADDR,XGENET,port,display);//0x2444: byte_cnt, pht_cnt
    printf("\nMACIN reg ");
    eth_rd(SM_XGENET_CSR_MACIN_ENET_STAT_REG__ADDR,XGENET,port,display);//0x2440: byte_cnt, pkt_cnt
    printf("\nRXBIN reg ");
    eth_rd(SM_XGENET_CSR_RXBIN_ENET_STAT_REG__ADDR,XGENET,port,display);//0x2448: byt_cnt, pkt_cnt
    printf("\nRSIF CNTR reg ");
    eth_rd(SM_XGENET_CSR_RSIF_STS_CNTR_REG0__ADDR,XGENET,port,display);//0x212c: mirror_pkt_cnt, pkt_cnt
    printf("\nRX_TX_BUF_STS reg ");
    eth_rd(SM_XGENET_CSR_RX_TX_BUF_STS_REG0__ADDR,XGENET,port,display);//0x2360: Tx, Rx buf_empty
    printf("\nRSIF FIFO STS reg ");
    eth_rd(SM_XGENET_CSR_RSIF_FIFO_EMPTYSTS0__ADDR,XGENET,port,display);//0x2104: Rx all fifo_empty stat
    printf("\nTSIF FIFO STS reg ");
    eth_rd(SM_XGENET_CSR_TSIF_FIFO_EMPTYSTS0__ADDR,XGENET,port,display);//0x22c0: Tx all fiof_empty stat
    printf("\nTSIF STS reg0 "); 
    eth_rd(SM_XGENET_CSR_TSIF_STS_REG0__ADDR,XGENET,port,display);//0x22c4: no of valid wk msg processed by tsif
    printf("\nTSIF STS reg1 ");
    eth_rd(SM_XGENET_CSR_TSIF_STS_REG1__ADDR,XGENET,port,display);//0x22c8: no of valid wk msg processed by tsif
    printf("\nTSIF STS reg2 ");
    eth_rd(SM_XGENET_CSR_TSIF_STS_REG2__ADDR,XGENET,port,display);//0x22d0: no of valid wk msg processed by tsif
    printf("\nTSIF STS reg3 ");
    eth_rd(SM_XGENET_CSR_TSIF_STS_REG3__ADDR,XGENET,port,display);//0x22d4: no of valid wk msg processed by tsif

    printf("\nCFG_LINK_STS reg ");
    eth_rd(SM_XGENET_CSR_CFG_LINK_STS__ADDR,XGENET,port,display);//0x2210 link stat
    printf("\nLINK AGGR RESUMEreg ");
    eth_rd(SM_XGENET_CSR_CFG_LINK_AGGR_RESUME_0__ADDR,XGENET,port,display);//0x2214:Tx_port:1=traffic can resume on port0
    printf("\nLINK AGGR ");
    eth_rd(SM_XGENET_CSR_CFG_LINK_AGGR__ADDR,XGENET,port,display);//0x2200: arb_sel, link_ggr_feature_en, revert traffic
    printf("\nLINK STATUS ");
    eth_rd(SM_XGENET_CSR_LINK_STATUS__ADDR,XGENET,port,display);//2228 link stat
    printf("\nCLKEN ");
    eth_rd(SM_XGENET_CLKRST_CSR_XGENET_CLKEN__ADDR,XGENET,port,display);//0xc008: xgenet_clken, csr_clken
    printf("\nSRST ");
    eth_rd(SM_XGENET_CLKRST_CSR_XGENET_SRST__ADDR,XGENET,port,display);//0xc000: xgenet_sds_rst, xgenet_rst, csr_rst
    printf("\nCFG_BYPASS ");
    eth_rd(SM_XGENET_CSR_CFG_BYPASS__ADDR,XGENET,port,display);//0x2204: resume_tx
    printf("\nTXB STAT ");
    eth_rd(SM_XGENET_CSR_TXB_ENET_STAT_REG__ADDR,XGENET,port,display);//0x243c: byte_cnt, pkt_cnt

}

void read_statistics_mcxmac(int port){
    int read_data;
    int i,j;
    int counter = 0;
    int display = 1;
    read_common_statistics(port);

    printf("MCXMAC FIFO STS reg ");
    eth_rd(SM_XGENET_MCXMAC_CSR_ICM_ECM_FIFO_STS_0__ADDR,XGENET,port,display);
    printf("MCXMAC RX DV GATE reg ");
    eth_rd(SM_XGENET_MCXMAC_CSR_RX_DV_GATE_REG_0__ADDR,XGENET,port,display);

    i = 0; display=0;
    printf("MCXMAC Pemstats 0\n\r");
    for (j=0; j<48; j++) {
        i = i + 1;
        eth_wr(SM_XGENET_MCXMACIP_IND_CSR_STAT_IND_ADDR_0__ADDR, 0x00000020 + j,XGENET,port,display);
        eth_wr(SM_XGENET_MCXMACIP_IND_CSR_STAT_IND_COMMAND_0__ADDR, 0x40000000,XGENET,port,display);
        do {
            read_data = eth_rd(SM_XGENET_MCXMACIP_IND_CSR_STAT_IND_COMMAND_DONE_0__ADDR,XGENET,port,display);
            counter++;
        } while (read_data != 0x00000001 && counter != MAX_INDCMD_DONE_COUNTER);

        if(read_data != 0x1) { printf("ERROR : XGENET_INDIRECT AXGMAC WR timeout");printf("\n\r"); }

        eth_wr(SM_XGENET_MCXMACIP_IND_CSR_STAT_IND_COMMAND_0__ADDR, 0x0,XGENET,port,display);
        read_data = eth_rd(SM_XGENET_MCXMACIP_IND_CSR_STAT_IND_RDATA_0__ADDR,XGENET,port,display); 
        printf("0x");putnum(0x00000020 + j);printf(" = 0x");putnum(read_data);printf(" \t");

        if(i==4) {
            i = 0;
            printf("\n\r");
        }   
    }
}   

void print_stat_sgmii_xfi() {
    printf("Select Port :");
    read_statistics_mcxmac(get_val());
}

int xgene_phy_get_avg(int accum, int samples)
{
	return (accum / samples);
}

int xgene_phy_gen_avg_val(int port)
{
	int max_loop = 10,timeout=50;
	int avg_loop = 0;
	int lat_do = 0, lat_xo = 0, lat_eo = 0, lat_so = 0;
	int lat_de = 0, lat_xe = 0, lat_ee = 0, lat_se = 0;
	int sum_cal = 0;
	int lat_do_itr, lat_xo_itr, lat_eo_itr, lat_so_itr;
	int lat_de_itr, lat_xe_itr, lat_ee_itr, lat_se_itr;
	int sum_cal_itr = 0;
	int fail_even;
	int fail_odd;
	u32 val;
	u32 dfepreset_old;
	u32 dfe_tap;
	int loop;
	uint32_t inst, inst_base;
	unsigned int  wr_val, rd_val;
	int data32,data;
	int display =0;
	
	inst = 0;
	inst_base = 0x0400 + inst*0x0200;

    // Moved this from eyescan_sub function gen_avg_val() code ==> as per Chidvilas's discussion with Poly on [28-Aug-2014]   
    data = enet_sds_ind_csr_reg_rd("RXTX_REG145", inst_base + 145*2,XGENET,port,display);
    data = FIELD_RXTX_REG145_RXVWES_LATENA_SET(data, 1);
    data = FIELD_RXTX_REG145_RXES_ENA_SET(data, 1);
    enet_sds_ind_csr_reg_wr("RXTX_REG145", inst_base + 145*2, data,XGENET,port,display);

	lprintf(3,"\nGenerating avg calibration value for lane %d\n",port);

	/* Enable RX Hi-Z termination */
	rd_val = enet_sds_ind_csr_reg_rd("RXTX_REG12", inst_base + 12*2,XGENET,port,display);
	wr_val = FIELD_RXTX_REG12_RX_DET_TERM_ENABLE_SET(rd_val,1);
	enet_sds_ind_csr_reg_wr("RXTX_REG12", inst_base + 12*2, wr_val,XGENET,port,display);

	/* Turn off DFE */
	rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg28", inst_base + 28*2,XGENET,port,display);
	enet_sds_ind_csr_reg_wr("rxtx_reg28", inst_base + 28*2, 0x0000,XGENET,port,display);

	/* DFE Presets to zero */
	rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg31", inst_base + 31*2,XGENET,port,display);
	enet_sds_ind_csr_reg_wr("rxtx_reg31", inst_base + 31*2, 0x0000,XGENET,port,display);

	/*
	 * Receiver Offset Calibration:
	 * Calibrate the receiver signal path offset in two steps - summar
	 * and latch calibration.
	 * Runs the "Receiver Offset Calibration multiple times to determine
	 * the average value to use.
	 */
    timeout=50;
	while (avg_loop < max_loop) {
		/* Start SUMMER calibration */
		rd_val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,XGENET,port,display);
		wr_val = FIELD_RXTX_REG127_FORCE_SUM_CAL_START_SET(rd_val,1);
		enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, wr_val,XGENET,port,display);

		/*
		 * As per PHY design spec, the Summer calibration requires a minimum
		 * of 100us to complete.
		 */
		USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500
		rd_val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,XGENET,port,display);
		wr_val = FIELD_RXTX_REG127_FORCE_SUM_CAL_START_SET(rd_val,0);
		enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, wr_val,XGENET,port,display);

		/*
		 * As per PHY design spec, the auto calibration requires a minimum
		 * of 100us to complete.
		 */
		USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500
		
		loop = 100;
		do {
			val = enet_sds_ind_csr_reg_rd("rxtx_reg158", inst_base + 158*2,XGENET,port,display);
			if (FIELD_RXTX_REG158_SUM_CALIB_DONE_RD(val) && (FIELD_RXTX_REG158_SUM_CALIB_ERR_RD(val) == 0))
				break;

			USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500
		} while (--loop > 0);

		val = enet_sds_ind_csr_reg_rd("rxtx_reg158", inst_base + 158*2,XGENET,port,display);

		if (FIELD_RXTX_REG158_SUM_CALIB_DONE_RD(val) && (FIELD_RXTX_REG158_SUM_CALIB_ERR_RD(val) == 0))  {
			lprintf(4,"rxtx_channel%d  summer calib pass \n", port);
			val = enet_sds_ind_csr_reg_rd("rxtx_reg121", inst_base + 121*2,XGENET,port,display);

			sum_cal_itr = FIELD_RXTX_REG121_SUMOS_CAL_CODE_RD(val);
			sum_cal += sum_cal_itr;
			++avg_loop;
            timeout=50;
		}  
        else {
            timeout--;
            if(timeout == 0) {
			    printf("Receiver summer calibration failed at %d loop\n",avg_loop);
                return -1;
            }
            else {
                printf("!");
            }
		}
		serdes_reset_rxd_xg(XGENET,port,0);
	}

	/* Update SUMMER calibration with average value */
	rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg14", inst_base + 14*2,XGENET,port,display);
	wr_val = FIELD_RXTX_REG14_CLTE_LATCAL_MAN_PROG_SET(rd_val,xgene_phy_get_avg(sum_cal, max_loop));
	enet_sds_ind_csr_reg_wr("RXTX_REG14", inst_base + 14*2,wr_val,XGENET,port,display);
	lprintf(4,"SUM 0x%x\n",xgene_phy_get_avg(sum_cal, max_loop));

	rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg14", inst_base + 14*2,XGENET,port,display);
	wr_val = FIELD_RXTX_REG14_CTLE_LATCAL_MAN_ENA_SET(rd_val, 0x1);
	enet_sds_ind_csr_reg_wr("RXTX_REG14", inst_base + 14*2,wr_val,XGENET,port,display);
	lprintf(4,"Enable Manual Summer calibration\n");

	avg_loop = 0;
    timeout=50;
	while (avg_loop < max_loop) {
		/* Start latch calibration */
		rd_val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,XGENET,port,display);
		wr_val = FIELD_RXTX_REG127_FORCE_LAT_CAL_START_SET(rd_val,1);
		enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, wr_val,XGENET,port,display);

		/*
		 * As per PHY design spec, the latch calibration requires a minimum
		 * of 100us to complete.
		 */
		USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500

		rd_val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,XGENET,port,display);
		wr_val = FIELD_RXTX_REG127_FORCE_LAT_CAL_START_SET(rd_val,0);
		enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, wr_val,XGENET,port,display);

		/* check lat calib, 
		 * The lat_calib is take about 200ms to be done 
		 * after release serdes reset. 
		 * It only occured 1time
		 */
		USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500
		loop = 1000;
		do {
			val = enet_sds_ind_csr_reg_rd("rxtx_reg158", inst_base + 158*2,XGENET,port,display);

			if (FIELD_RXTX_REG158_LAT_CALIB_DONE_RD(val))
				break;
			USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500

		} while (--loop > 0);

		val = enet_sds_ind_csr_reg_rd("rxtx_reg158", inst_base + 158*2,XGENET,port,display);

		if (FIELD_RXTX_REG158_LAT_CALIB_DONE_RD(val)) 
			lprintf(4,"rxtx_channel%d  lat calib pass and time taken =%dms \n",port, (1000-loop)*2);
		else 
			lprintf(4,"rxtx_channel%d  lat calib failed even after %d loops\n",port, (1000-loop));

		val = enet_sds_ind_csr_reg_rd("rxtx_reg21", inst_base + 21*2,XGENET,port,display);
		lat_do_itr = FIELD_RXTX_REG21_DO_LATCH_CALOUT_RD(val);
		lat_xo_itr = FIELD_RXTX_REG21_XO_LATCH_CALOUT_RD(val);
		fail_odd = FIELD_RXTX_REG21_LATCH_CAL_FAIL_ODD_RD(val);

		val = enet_sds_ind_csr_reg_rd("rxtx_reg22", inst_base + 22*2,XGENET,port,display);
		lat_eo_itr = FIELD_RXTX_REG22_EO_LATCH_CALOUT_RD(val);
		lat_so_itr = FIELD_RXTX_REG22_SO_LATCH_CALOUT_RD(val);
		fail_even = FIELD_RXTX_REG22_LATCH_CAL_FAIL_EVEN_RD(val);

		val = enet_sds_ind_csr_reg_rd("rxtx_reg23", inst_base + 23*2,XGENET,port,display);
		lat_de_itr = FIELD_RXTX_REG23_DE_LATCH_CALOUT_RD(val);
		lat_xe_itr = FIELD_RXTX_REG23_XE_LATCH_CALOUT_RD(val);

		val = enet_sds_ind_csr_reg_rd("rxtx_reg24", inst_base + 24*2,XGENET,port,display);
		lat_ee_itr = FIELD_RXTX_REG24_EE_LATCH_CALOUT_RD(val);
		lat_se_itr = FIELD_RXTX_REG24_SE_LATCH_CALOUT_RD(val);

		/* Check for failure. If passed, sum them for averaging */
		if ((fail_even == 0 || fail_even == 1) && (fail_odd == 0 || fail_odd == 1)) {
			lat_do += lat_do_itr;
			lat_xo += lat_xo_itr;
			lat_eo += lat_eo_itr;
			lat_so += lat_so_itr;
			lat_de += lat_de_itr;
			lat_xe += lat_xe_itr;
			lat_ee += lat_ee_itr;
			lat_se += lat_se_itr;

			lprintf(4,"Iteration %d:\n", avg_loop);
			lprintf(4,"DO 0x%x XO 0x%x EO 0x%x SO 0x%x\n",lat_do_itr, lat_xo_itr, lat_eo_itr,lat_so_itr);
			lprintf(4,"DE 0x%x XE 0x%x EE 0x%x SE 0x%x\n",lat_de_itr, lat_xe_itr, lat_ee_itr,lat_se_itr);
			lprintf(4,"SUM 0x%x\n", sum_cal_itr);
			++avg_loop;
            timeout=50;
		} 
        else {
            timeout--;
            if(timeout == 0) {
			    printf("Receiver latch calibration failed at %d loop\n",avg_loop);
                return -2;
            }
            else {
                printf("!");
            }
		}
		serdes_reset_rxd_xg(XGENET,port,0);
	}

	/* Update latch manual calibration with average value */
	val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,XGENET,port,display);
	val = FIELD_RXTX_REG127_DO_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_do, max_loop));
	val = FIELD_RXTX_REG127_XO_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_xo, max_loop));
	enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, val,XGENET,port,display);

	val = enet_sds_ind_csr_reg_rd("RXTX_REG128", inst_base + 128*2,XGENET,port,display);
	val = FIELD_RXTX_REG128_EO_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_eo, max_loop));
	val = FIELD_RXTX_REG128_SO_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_so, max_loop));
	enet_sds_ind_csr_reg_wr("RXTX_REG128", inst_base + 128*2, val,XGENET,port,display);

	val = enet_sds_ind_csr_reg_rd("RXTX_REG129", inst_base + 129*2,XGENET,port,display);
	val = FIELD_RXTX_REG129_DE_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_de, max_loop));
	val = FIELD_RXTX_REG129_XE_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_xe, max_loop));
	enet_sds_ind_csr_reg_wr("RXTX_REG129", inst_base + 129*2, val,XGENET,port,display);

	val = enet_sds_ind_csr_reg_rd("RXTX_REG130", inst_base + 130*2,XGENET,port,display);
	val = FIELD_RXTX_REG130_EE_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_ee, max_loop));
	val = FIELD_RXTX_REG130_SE_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_se, max_loop));
	enet_sds_ind_csr_reg_wr("RXTX_REG130", inst_base + 130*2, val,XGENET,port,display);

	lprintf(4,"Average Value:\n");
	lprintf(4,"DO 0x%x XO 0x%x EO 0x%x SO 0x%x\n",
			xgene_phy_get_avg(lat_do, max_loop),
			xgene_phy_get_avg(lat_xo, max_loop),
			xgene_phy_get_avg(lat_eo, max_loop),
			xgene_phy_get_avg(lat_so, max_loop));
	lprintf(4,"DE 0x%x XE 0x%x EE 0x%x SE 0x%x\n",
			xgene_phy_get_avg(lat_de, max_loop),
			xgene_phy_get_avg(lat_xe, max_loop),
			xgene_phy_get_avg(lat_ee, max_loop),
			xgene_phy_get_avg(lat_se, max_loop));
	val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,XGENET,port,display);
	val = FIELD_RXTX_REG127_LATCH_MAN_CAL_ENA_SET(val, 0x1);
	lprintf(4,"Enable Manual Latch calibration\n");
	enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, val,XGENET,port,display);
	USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500

	/* Disable RX Hi-Z termination */
	val = enet_sds_ind_csr_reg_rd("RXTX_REG12", inst_base + 12*2,XGENET,port,display);
	val = FIELD_RXTX_REG12_RX_DET_TERM_ENABLE_SET(val, 0);
	enet_sds_ind_csr_reg_wr("RXTX_REG12", inst_base + 12*2, val,XGENET,port,display);

	/* Turn on/off DFE */
    //enet_sds_ind_csr_reg_wr("RXTX_REG28", inst_base + 28*2, 0x7,XGENET,port,display);
    enet_sds_ind_csr_reg_wr("RXTX_REG28", inst_base + 28*2, 0x0,XGENET,port,display);   //10-09-2014 BLT Debug Jitu/Satish

	enet_sds_ind_csr_reg_wr("RXTX_REG31", inst_base + 31*2, val,XGENET,port,display);

    return 0;
}


int xgene_phy_gen_avg_val_sata_sgmii(int port)
{
	int max_loop = 10,timeout=50;
	int avg_loop = 0;
	int lat_do = 0, lat_xo = 0, lat_eo = 0, lat_so = 0;
	int lat_de = 0, lat_xe = 0, lat_ee = 0, lat_se = 0;
	int sum_cal = 0;
	int lat_do_itr, lat_xo_itr, lat_eo_itr, lat_so_itr;
	int lat_de_itr, lat_xe_itr, lat_ee_itr, lat_se_itr;
	int sum_cal_itr = 0;
	int fail_even;
	int fail_odd;
	u32 val;
	u32 dfepreset_old;
	u32 dfe_tap;
	int loop;
	uint32_t inst, inst_base;
	unsigned int  wr_val, rd_val;
	int data32,data;
	int display =0;
	
	//inst = 0;
    inst = port & 0x1;
	inst_base = 0x0400 + inst*0x0200;


    // Moved this from eyescan_sub function gen_avg_val() code ==> as per Chidvilas's discussion with Poly on [28-Aug-2014]   
    data = enet_sds_ind_csr_reg_rd("RXTX_REG145", inst_base + 145*2,ENET,port,display);
    data = FIELD_RXTX_REG145_RXVWES_LATENA_SET(data, 1);
    data = FIELD_RXTX_REG145_RXES_ENA_SET(data, 1);
    enet_sds_ind_csr_reg_wr("RXTX_REG145", inst_base + 145*2, data,ENET,port,display);

	lprintf(3,"\nGenerating avg calibration value for lane %d\n",port);

	/* Enable RX Hi-Z termination */
	rd_val = enet_sds_ind_csr_reg_rd("RXTX_REG12", inst_base + 12*2,ENET,port,display);
	wr_val = FIELD_RXTX_REG12_RX_DET_TERM_ENABLE_SET(rd_val,1);
	enet_sds_ind_csr_reg_wr("RXTX_REG12", inst_base + 12*2, wr_val,ENET,port,display);

	/* Turn off DFE */
	rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg28", inst_base + 28*2,ENET,port,display);
	enet_sds_ind_csr_reg_wr("rxtx_reg28", inst_base + 28*2, 0x0000,ENET,port,display);

	/* DFE Presets to zero */
	rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg31", inst_base + 31*2,ENET,port,display);
	enet_sds_ind_csr_reg_wr("rxtx_reg31", inst_base + 31*2, 0x0000,ENET,port,display);

	/*
	 * Receiver Offset Calibration:
	 * Calibrate the receiver signal path offset in two steps - summar
	 * and latch calibration.
	 * Runs the "Receiver Offset Calibration multiple times to determine
	 * the average value to use.
	 */
    timeout=50;
	while (avg_loop < max_loop) {
		/* Start SUMMER calibration */
		rd_val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,ENET,port,display);
		wr_val = FIELD_RXTX_REG127_FORCE_SUM_CAL_START_SET(rd_val,1);
		enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, wr_val,ENET,port,display);

		/*
		 * As per PHY design spec, the Summer calibration requires a minimum
		 * of 100us to complete.
		 */
		USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500
		rd_val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,ENET,port,display);
		wr_val = FIELD_RXTX_REG127_FORCE_SUM_CAL_START_SET(rd_val,0);
		enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, wr_val,ENET,port,display);

		/*
		 * As per PHY design spec, the auto calibration requires a minimum
		 * of 100us to complete.
		 */
		USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500
		
		loop = 100;
		do {
			val = enet_sds_ind_csr_reg_rd("rxtx_reg158", inst_base + 158*2,ENET,port,display);
			if (FIELD_RXTX_REG158_SUM_CALIB_DONE_RD(val) && (FIELD_RXTX_REG158_SUM_CALIB_ERR_RD(val) == 0))
				break;

			USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500
		} while (--loop > 0);

		val = enet_sds_ind_csr_reg_rd("rxtx_reg158", inst_base + 158*2,ENET,port,display);

		if (FIELD_RXTX_REG158_SUM_CALIB_DONE_RD(val) && (FIELD_RXTX_REG158_SUM_CALIB_ERR_RD(val) == 0))  {
			//lprintf(3,"rxtx_channel%d  summer calib pass \n", port);
			val = enet_sds_ind_csr_reg_rd("rxtx_reg121", inst_base + 121*2,ENET,port,display);

			sum_cal_itr = FIELD_RXTX_REG121_SUMOS_CAL_CODE_RD(val);
			sum_cal += sum_cal_itr;
			++avg_loop;
            timeout=50;
			lprintf(4,"rxtx_channel%d  summer calib pass sum_cal_itr:%d \n", port,sum_cal_itr);
		}
        else {
            timeout--;
            if(timeout == 0) {
			    printf("Receiver summer calibration failed at %d loop\n",avg_loop);
                return -1;
            }
            else {
                printf("!");
            }
		}        
		serdes_reset_rxd(port,0);
	}

	/* Update SUMMER calibration with average value */
	rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg14", inst_base + 14*2,ENET,port,display);
	wr_val = FIELD_RXTX_REG14_CLTE_LATCAL_MAN_PROG_SET(rd_val,xgene_phy_get_avg(sum_cal, max_loop));
	enet_sds_ind_csr_reg_wr("RXTX_REG14", inst_base + 14*2,wr_val,ENET,port,display);
	lprintf(4,"SUM 0x%x\n",xgene_phy_get_avg(sum_cal, max_loop));

	rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg14", inst_base + 14*2,ENET,port,display);
	wr_val = FIELD_RXTX_REG14_CTLE_LATCAL_MAN_ENA_SET(rd_val, 0x1); // auto=0
	enet_sds_ind_csr_reg_wr("RXTX_REG14", inst_base + 14*2,wr_val,ENET,port,display);
	lprintf(4,"Enable Manual Summer calibration\n");

	avg_loop = 0;
    timeout=50;
	while (avg_loop < max_loop) {
		/* Start latch calibration */
		rd_val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,ENET,port,display);
		wr_val = FIELD_RXTX_REG127_FORCE_LAT_CAL_START_SET(rd_val,1);
		enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, wr_val,ENET,port,display);

		/*
		 * As per PHY design spec, the latch calibration requires a minimum
		 * of 100us to complete.
		 */
		USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500

		rd_val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,ENET,port,display);
		wr_val = FIELD_RXTX_REG127_FORCE_LAT_CAL_START_SET(rd_val,0);
		enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, wr_val,ENET,port,display);

		/* check lat calib, 
		 * The lat_calib is take about 200ms to be done 
		 * after release serdes reset. 
		 * It only occured 1time
		 */
		USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500
		loop = 1000;
		do {
			val = enet_sds_ind_csr_reg_rd("rxtx_reg158", inst_base + 158*2,ENET,port,display);

			if (FIELD_RXTX_REG158_LAT_CALIB_DONE_RD(val))
				break;
			USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500

		} while (--loop > 0);

		val = enet_sds_ind_csr_reg_rd("rxtx_reg158", inst_base + 158*2,ENET,port,display);

		if (FIELD_RXTX_REG158_LAT_CALIB_DONE_RD(val)) 
			lprintf(4,"rxtx_channel%d  lat calib pass and time taken =%dms \n",port, (1000-loop)*2);
		else 
			lprintf(4,"rxtx_channel%d  lat calib failed even after %d loops\n",port, (1000-loop));

		val = enet_sds_ind_csr_reg_rd("rxtx_reg21", inst_base + 21*2,ENET,port,display);
		lat_do_itr = FIELD_RXTX_REG21_DO_LATCH_CALOUT_RD(val);
		lat_xo_itr = FIELD_RXTX_REG21_XO_LATCH_CALOUT_RD(val);
		fail_odd = FIELD_RXTX_REG21_LATCH_CAL_FAIL_ODD_RD(val);

		val = enet_sds_ind_csr_reg_rd("rxtx_reg22", inst_base + 22*2,ENET,port,display);
		lat_eo_itr = FIELD_RXTX_REG22_EO_LATCH_CALOUT_RD(val);
		lat_so_itr = FIELD_RXTX_REG22_SO_LATCH_CALOUT_RD(val);
		fail_even = FIELD_RXTX_REG22_LATCH_CAL_FAIL_EVEN_RD(val);

		val = enet_sds_ind_csr_reg_rd("rxtx_reg23", inst_base + 23*2,ENET,port,display);
		lat_de_itr = FIELD_RXTX_REG23_DE_LATCH_CALOUT_RD(val);
		lat_xe_itr = FIELD_RXTX_REG23_XE_LATCH_CALOUT_RD(val);

		val = enet_sds_ind_csr_reg_rd("rxtx_reg24", inst_base + 24*2,ENET,port,display);
		lat_ee_itr = FIELD_RXTX_REG24_EE_LATCH_CALOUT_RD(val);
		lat_se_itr = FIELD_RXTX_REG24_SE_LATCH_CALOUT_RD(val);

		/* Check for failure. If passed, sum them for averaging */
		if ((fail_even == 0 || fail_even == 1) && (fail_odd == 0 || fail_odd == 1)) {
			lat_do += lat_do_itr;
			lat_xo += lat_xo_itr;
			lat_eo += lat_eo_itr;
			lat_so += lat_so_itr;
			lat_de += lat_de_itr;
			lat_xe += lat_xe_itr;
			lat_ee += lat_ee_itr;
			lat_se += lat_se_itr;

			lprintf(4,"Iteration %d:\n", avg_loop);
			lprintf(4,"DO 0x%x XO 0x%x EO 0x%x SO 0x%x\n",lat_do_itr, lat_xo_itr, lat_eo_itr,lat_so_itr);
			lprintf(4,"DE 0x%x XE 0x%x EE 0x%x SE 0x%x\n",lat_de_itr, lat_xe_itr, lat_ee_itr,lat_se_itr);
			lprintf(4,"SUM 0x%x\n", sum_cal_itr);
			++avg_loop;
            timeout=50;
		} 
        else {
            timeout--;
            if(timeout == 0) {
			    printf("Receiver latch calibration failed at %d loop\n",avg_loop);
                return -2;
		    }
            else {
                printf("!");
            }
        }
		serdes_reset_rxd(port,0);
	}

	/* Update latch manual calibration with average value */
	val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,ENET,port,display);
	val = FIELD_RXTX_REG127_DO_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_do, max_loop));
	val = FIELD_RXTX_REG127_XO_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_xo, max_loop));
	enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, val,ENET,port,display);

	val = enet_sds_ind_csr_reg_rd("RXTX_REG128", inst_base + 128*2,ENET,port,display);
	val = FIELD_RXTX_REG128_EO_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_eo, max_loop));
	val = FIELD_RXTX_REG128_SO_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_so, max_loop));
	enet_sds_ind_csr_reg_wr("RXTX_REG128", inst_base + 128*2, val,ENET,port,display);

	val = enet_sds_ind_csr_reg_rd("RXTX_REG129", inst_base + 129*2,ENET,port,display);
	val = FIELD_RXTX_REG129_DE_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_de, max_loop));
	val = FIELD_RXTX_REG129_XE_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_xe, max_loop));
	enet_sds_ind_csr_reg_wr("RXTX_REG129", inst_base + 129*2, val,ENET,port,display);

	val = enet_sds_ind_csr_reg_rd("RXTX_REG130", inst_base + 130*2,ENET,port,display);
	val = FIELD_RXTX_REG130_EE_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_ee, max_loop));
	val = FIELD_RXTX_REG130_SE_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_se, max_loop));
	enet_sds_ind_csr_reg_wr("RXTX_REG130", inst_base + 130*2, val,ENET,port,display);

	lprintf(4,"Average Value:\n");
	lprintf(4,"DO 0x%x XO 0x%x EO 0x%x SO 0x%x\n",
			xgene_phy_get_avg(lat_do, max_loop),
			xgene_phy_get_avg(lat_xo, max_loop),
			xgene_phy_get_avg(lat_eo, max_loop),
			xgene_phy_get_avg(lat_so, max_loop));
    lprintf(4,"DE 0x%x XE 0x%x EE 0x%x SE 0x%x\n",
            xgene_phy_get_avg(lat_de, max_loop),
            xgene_phy_get_avg(lat_xe, max_loop),
            xgene_phy_get_avg(lat_ee, max_loop),
            xgene_phy_get_avg(lat_se, max_loop));
    val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,ENET,port,display);
    val = FIELD_RXTX_REG127_LATCH_MAN_CAL_ENA_SET(val, 0x1); //auto=0
    lprintf(4,"Enable Manual Latch calibration\n");
    enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, val,ENET,port,display);
    USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500

    /* Disable RX Hi-Z termination */
    val = enet_sds_ind_csr_reg_rd("RXTX_REG12", inst_base + 12*2,ENET,port,display);
    val = FIELD_RXTX_REG12_RX_DET_TERM_ENABLE_SET(val, 0);
    enet_sds_ind_csr_reg_wr("RXTX_REG12", inst_base + 12*2, val,ENET,port,display);

    /* Turn on/off DFE */
    //enet_sds_ind_csr_reg_wr("RXTX_REG28", inst_base + 28*2, 0x7,ENET,port,display);
    enet_sds_ind_csr_reg_wr("RXTX_REG28", inst_base + 28*2, 0x0,ENET,port,display); //10-09-2014 BLT Debug Jitu/Satish

    enet_sds_ind_csr_reg_wr("RXTX_REG31", inst_base + 31*2, val,ENET,port,display);

    return 0;
}

void init_mcxmac(int eth_type, int port, int display) {
    int read_data;
    mcxmac_ind_wr(PE_MCXMAC_MAC_CONFIG_1__ADDR,0x00000035,eth_type,port,display);
    mcxmac_ind_wr(PE_MCXMAC_MAC_CONFIG_2__ADDR, 0x00005231,eth_type,port,display);
    mcxmac_ind_wr(PE_MCXMAC_MAX_FRAME_LEN__ADDR,0x00002580,eth_type,port,display);
}

void bypass_resume_cfg(int port, int display) {
    eth_wr(SM_XGENET_CSR_CFG_BYPASS__ADDR, 0x1,XGENET,port,display);
    eth_wr(SM_XGENET_CSR_ENET_SPARE_CFG_REG__ADDR, 0x22407040,XGENET,port,display);
}


void set_phy_level_lpbk_sgmii(int eth_type) {

    int phy_addr=0,phy_reg=0,rd_data,ind_address,ind_data,port,phy_start_addr,phy_end_addr;

    /* 
        PHY_ADDR = 0x11 to 0x14 for SATA-SGMII PHY
        PHY_ADDR = 0x15 to 0x18 for XFI-SGMII  PHY
    */
    if(eth_type == ENET) {
        lprintf(4,"\nConfigure SATA-SGMII PHY level Tx-2-Rx loopback mode for all 4 Ports\n");
        phy_start_addr = 0x11;
        phy_end_addr   = 0x14;
    }
    else if(eth_type == XGENET) {
        lprintf(4,"\nConfigure XFI-SGMII PHY level Tx-2-Rx loopback mode for all 4 Ports\n");        
        phy_start_addr = 0x15;
        phy_end_addr   = 0x18;
    }
         
    for (phy_addr=phy_start_addr; phy_addr<=phy_end_addr; phy_addr++) {
        phy_reg=0;
        ind_address = ((phy_addr << 8) | phy_reg);
        ind_data = mdio_rd(ind_address,MENET,0,0);
        lprintf(4,"Before phy_addr:0x%x phy_reg:0x%x ind_address:0x%x ind_data:0x%x \n",phy_addr,phy_reg,ind_address,ind_data);

        ind_data = ind_data | 0x4000;
        mdio_wr(ind_address,ind_data,MENET,0,0); // Enable 
        USDELAY(2000);

        ind_address = ((phy_addr << 8) | phy_reg);
        ind_data = mdio_rd(ind_address,MENET,0,0);
        lprintf(4,"After  phy_addr:0x%x phy_reg:0x%x ind_address:0x%x ind_data:0x%x \n",phy_addr,phy_reg,ind_address,ind_data);
    }
}

int phy_rd_wr() {
    int ind_data, ind_address, phy_addr=0,phy_reg=0,val; 

    while(1) {
        printf("\n0 - PHY Read \n");
        printf("1 - PHY Write\n");
        printf("3 - QUIT\n");

        printf("\nSelect Option:");
        val = get_val();
        printf("\n");
        
        if (val == 3) {
            break;
        }
        printf("\nEnter PHY Address (hex): \n");
        phy_addr = get_val();
        printf("\nEnter Reg Address (hex): \n");
        phy_reg = get_val();

        if(val == 0) {
            printf("Read From PHY\n"); 
            ind_address = ((phy_addr << 8) | phy_reg);
            ind_data = mdio_rd(ind_address,MENET,0,0);
            printf("\nphy_addr:0x%x phy_reg:0x%x ind_address:0x%x ind_data:0x%x \n",phy_addr,phy_reg,ind_address,ind_data);
        } else if(val == 1) {

            printf("\nEnter Write Value (hex): \n");
            ind_data = get_val();
            ind_address = ((phy_addr << 8) | phy_reg);
            mdio_wr(ind_address,ind_data,MENET,0,0);
        }
    }
    return 0;
}

void sgmii_read_prbs_err_cnt(int port, int lpbk_mode, int eth_type) {

    uint32_t inst, inst_base;
    unsigned int  wr_val, rd_val, rd_val1, temp;
    int display = 0;
    int ret_val=0;
    int rx_port,val;
    inst = 0;
    inst_base = 0x0400 + inst*0x0200;

    if(lpbk_mode == 0) { // self level lpbk mode
        if(port == 0) rx_port = 0;
        if(port == 1) rx_port = 1;
        if(port == 2) rx_port = 2;
        if(port == 3) rx_port = 3;
    }
    /*
    else if(lpbk_mode == 1) { // port to port lpbk mode
        if(port == 0) rx_port = 1; 
        if(port == 1) rx_port = 0; 
        if(port == 2) rx_port = 3;
        if(port == 3) rx_port = 2;
    }
    */

    USDELAY(2000);
    //Reset BERT_RESET_B in RXTX_REG61
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg61", inst_base + 61*2 , eth_type , rx_port , display);
    wr_val = sm_enet_set(rd_val,0x0, 5, 5);
    enet_sds_ind_csr_reg_wr("rxtx_reg61", inst_base + 61*2, wr_val , eth_type , rx_port , display);
    USDELAY(2000);
    //Reset BERT_RESET_B in RXTX_REG61
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg61", inst_base + 61*2 , eth_type , rx_port , display);
    wr_val = sm_enet_set(rd_val,0x1, 5, 5);
    enet_sds_ind_csr_reg_wr("rxtx_reg61", inst_base + 61*2, wr_val , eth_type , rx_port , display);

    USDELAY(2000);
    //Toggel RX_BIST_RESYNC in RXTX_REG6
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2 , eth_type , rx_port , display);
    wr_val = sm_enet_set(rd_val,0x1, 1, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val , eth_type , rx_port , display);
    USDELAY(2000);
    //Toggel RX_BIST_RESYNC in RXTX_REG6
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2 , eth_type , rx_port , display);
    wr_val = sm_enet_set(rd_val,0x0, 1, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val , eth_type , rx_port , display);
    USDELAY(2000);

    //RX_BIST_ERRCNT_RD in RXTX_REG6
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2 , eth_type , rx_port , display);
    wr_val = sm_enet_set(rd_val,0x1, 0, 0);
    enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val , eth_type , rx_port , display);

    //RX_BIST_ERRCNT_RD in RXTX_REG6
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2 , eth_type , rx_port , display);
    wr_val = sm_enet_set(rd_val,0x0, 0, 0);
    enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val , eth_type , rx_port , display);

    //RX_BIST_ERRCNT_MSB in RXTX_REG152
    rd_val1 = enet_sds_ind_csr_reg_rd("rxtx_reg152", inst_base + 152*2 , eth_type , rx_port , display);
    temp = rd_val1 << 16;

    //RX_BIST_ERRCNT_LSB in RXTX_REG153
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg153", inst_base + 153*2 , eth_type , rx_port , display);
    temp = temp | rd_val;
    printf("\t\nPort-%d Error Counter:0x%x   rxtx_reg153 MSB:0x%x LSB:0x%0x\n",rx_port,temp,rd_val1,rd_val);
    
    //RX_BIST_PASS RX_BIST_FAIL in RXTX_REG158
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg158", inst_base + 158*2 , eth_type , rx_port , display);
    if(rd_val & 0x0040) { 
        printf("\tPort-%d BIST Test FAIL   rxtx_reg158:0x%x\n",rx_port,rd_val);
    }
    else if(rd_val & 0x0080) { 
        printf("\tPort-%d BIST Test PASS   rxtx_reg158:0x%x\n",rx_port,rd_val);
    }
}

int sgmii_serdes_prbs_test(int eth_type) {

    uint32_t inst, inst_base;
    unsigned int  wr_val, rd_val;
    int display = 0;
    int ret_val=0;
    int rx_port,tx_val,rx_val,port,i;
    inst = 0;
    inst_base = 0x0400 + inst*0x0200;
    int lpbk_mode=0;

    printf("\n0 - PRBS-7\n");
    printf("1 - PRBS-9\n");
    printf("2 - PRBS-11\n");
    printf("3 - PRBS-23\n");
    printf("4 - PRBS-31\n");

    printf("\nSelect TX PRBS No:");
    tx_val = get_val();
    printf("\n");
    
    printf("\nSelect RX PRBS No:");
    rx_val = get_val();
    printf("\n");
   
    for(port=0; port<4; port++) {

        if(lpbk_mode == 0) { // self level lpbk mode
            if(port == 0) rx_port = 0;
            if(port == 1) rx_port = 1;
            if(port == 2) rx_port = 2;
            if(port == 3) rx_port = 3;
            if(eth_type == XGENET)
                printf("\nPort-%d XFI-SGMII SERDES-PRBS Self level SERDES Tx-Rx lpbk Test ",port);
            else if(eth_type == ENET)
                printf("\nPort-%d SATA-SGMII SERDES-PRBS Self level SERDES Tx-Rx lpbk Test ",port);
        }
        /*
        else if (lpbk_mode == 1) { // port to port lpbk mode
            if(port == 0) rx_port = 1;
            if(port == 1) rx_port = 0;
            if(port == 2) rx_port = 3;
            if(port == 3) rx_port = 2;
            printf("\nPort%d_to_Port%d XFI-SGMII SERDES-PRBS External lpbk Test ",port,rx_port);
        }
        */

        //TX PRBS SELECT in RXTX_REG4
        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 4*2 , eth_type , port , display);
        if(tx_val == 0) {
            wr_val = sm_enet_set(rd_val,0x0, 10, 8); // PRBS-7
            printf("Tx PRBS-7 ");
        }
        else if(tx_val == 1) {
            wr_val = sm_enet_set(rd_val,0x1, 10, 8); // PRBS-9
            printf("Tx PRBS-9 ");
        }        
        else if(tx_val == 2) {
            wr_val = sm_enet_set(rd_val,0x2, 10, 8); // PRBS-11
            printf("Tx PRBS-11 ");
        }        
        else if(tx_val == 3) {
            wr_val = sm_enet_set(rd_val,0x3, 10, 8); // PRBS-23
            printf("Tx PRBS-23 ");
        }        
        else if(tx_val == 4) {
            wr_val = sm_enet_set(rd_val,0x4, 10, 8); // PRBS-31
            printf("Tx PRBS-31 ");
        }
        enet_sds_ind_csr_reg_wr("rxtx_reg4", inst_base + 4*2, wr_val , eth_type , port , 0);

        //RX PRBS SELECT in RXTX_REG7
        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 7*2 , eth_type , rx_port , display);
        if(rx_val == 0) {
            wr_val = sm_enet_set(rd_val,0x0, 5, 3); // PRBS-7
            printf("Rx PRBS-7\n");
        }
        else if(rx_val == 1) {
            wr_val = sm_enet_set(rd_val,0x1, 5, 3); // PRBS-9
            printf("Rx PRBS-9\n");
        }        
        else if(rx_val == 2) {
            wr_val = sm_enet_set(rd_val,0x2, 5, 3); // PRBS-11
            printf("Rx PRBS-11\n");
        }        
        else if(rx_val == 3) {
            wr_val = sm_enet_set(rd_val,0x3, 5, 3); // PRBS-23
            printf("Rx PRBS-23\n");
        }        
        else if(rx_val == 4) {
            wr_val = sm_enet_set(rd_val,0x4, 5, 3); // PRBS-31
            printf("Rx PRBS-31\n");
        }
        enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 7*2, wr_val , eth_type , rx_port , 0);

        //BIST_EN_TX in RXTX_REG2
        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2 , eth_type , port , display);
        wr_val = sm_enet_set(rd_val,0x1, 11, 11);
        enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, wr_val , eth_type , port , display);

        //BIST_EN_RX in RXTX_REG7
        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 7*2 , eth_type , rx_port , display);
        wr_val = sm_enet_set(rd_val,0x1, 6, 6);
        enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 7*2, wr_val , eth_type , rx_port , display);

        printf("\n2 Sec Delay Dummy Read (Clear the Error Counter) Ignore FAIL,");
        USDELAY(2000000); //8-Sec Delay
        printf("Done\n");
        for(i=0; i<1; i++) {
            USDELAY(1000000); sgmii_read_prbs_err_cnt(port,lpbk_mode,eth_type);
        }

        printf("\n8 Sec Delay Before Actual Error Count Read,");
        USDELAY(8000000); //8-Sec Delay
        printf("Done\n");
        for(i=0; i<3; i++) {
            USDELAY(1000000); sgmii_read_prbs_err_cnt(port,lpbk_mode,eth_type);
        }

        //BIST_EN_TX in RXTX_REG2 -- DISABLE
        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2 , eth_type , port , display);
        wr_val = sm_enet_set(rd_val,0x0, 11, 11);
        enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, wr_val , eth_type , port , display);

        //BIST_EN_RX in RXTX_REG7 -- DISABLE
        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 7*2 , eth_type , rx_port , display);
        wr_val = sm_enet_set(rd_val,0x0, 6, 6);
        enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 7*2, wr_val , eth_type, rx_port , display);
    }
}

int xfi_sgmii_serdes_prbs_test() {
    sgmii_serdes_prbs_test(XGENET);
}

int sata_sgmii_serdes_prbs_test() {
    sgmii_serdes_prbs_test(ENET);
}

void send_pause_packet_xfi(int tx_port, u32 pn) {
    int temp,i;
    u32 dots;

    dots=pn/20;
    printf("\nSending %d Pasue Frames [",pn);
    for(i=0; i<pn; i++) {
        eth_wr(SM_XGENET_MCXMAC_CSR_CSR_ECM_CFG_0__ADDR, 0x08000005,XGENET,tx_port,0);
        USDELAY(1);
        eth_wr(SM_XGENET_MCXMAC_CSR_CSR_ECM_CFG_0__ADDR, 0x00000005,XGENET,tx_port,0);
        if ((i%dots==0)) printf(".");
    }
    printf("]\n");
}

void send_pause_packet_sata(int tx_port, u32 pn) {
    int temp,i;
    u32 dots;

    dots=pn/20;
    printf("\nSending %d Pasue Frames [",pn);
    for(i=0; i<pn; i++) {
	if(tx_port==0)
        	eth_wr(SM_ENET_MAC_CSR_CSR_ECM_CFG_0__ADDR, 0x08000005,ENET,tx_port,0);
	if(tx_port==1)
        	eth_wr(SM_ENET_MAC_CSR_CSR_ECM_CFG_1__ADDR, 0x08000005,ENET,tx_port,0);
        USDELAY(1);
        //temp = eth_rd(SM_ENET_MAC_CSR_CSR_ECM_CFG_0__ADDR,ENET,tx_port,1);
	if(tx_port==0)
        	eth_wr(SM_ENET_MAC_CSR_CSR_ECM_CFG_0__ADDR, 0x00000005,ENET,tx_port,0);
	if(tx_port==1)
        	eth_wr(SM_ENET_MAC_CSR_CSR_ECM_CFG_1__ADDR, 0x00000005,ENET,tx_port,0);
        if ((i%dots==0)) printf(".");
    }
    printf("]\n");
}

void send_pause_frame_xfi() {

    u32 pn;
    int port;
    printf("\nEnter No of packets in hex : 0x");pn = get_val(); //pn = get_val(); 

    printf("\nEnter Port No: "); 
    port = get_val();

    printf("\nPort:%d No Packets:%d",port,pn);

    send_pause_packet_xfi(port, pn);
}

void send_pause_frame_sata() {

    u32 pn;
    int port;
    printf("\nEnter No of packets in hex : 0x");pn = get_val(); //pn = get_val(); 

    printf("\nEnter Port No: "); 
    port = get_val();

    printf("\nPort:%d No Packets:%d",port,pn);

    send_pause_packet_sata(port, pn);
}

void send_pause_frame_p0() {
//void s0() {

    u32 pn;
    int port;
    printf("\nEnter No of packets in hex : 0x");pn = get_val(); //pn = get_val(); 

    printf("\nEnter Port No: ");
    //port = get_val();
    port=0;

    printf("\nPort:%d No Packets:%d",port,pn);

    send_pause_packet_sata(port, pn);
}

void send_pause_frame_p1() {
//void s1() {

    u32 pn;
    int port;
    printf("\nEnter No of packets in hex : 0x");pn = get_val(); //pn = get_val(); 

    printf("\nEnter Port No: ");
    //port = get_val();
    port=1;

    printf("\nPort:%d No Packets:%d",port,pn);

    send_pause_packet_sata(port, pn);
}


void mac_stat_sgmii_xfi() {
    int port = 0;
    for(port=FIRST_PORT; port <= LAST_PORT; port++){
        printf("-------Port%d----------\n",port);
        printf("Tx-Pkt = %d :: ",mcxmac_stat_rd(PEMSTAT_TPKT__ADDR,port));
        printf("Rx-Pkt = %d\n",mcxmac_stat_rd(PEMSTAT_RPKT__ADDR,port));
        printf("Tx-Byt = %d :: ",mcxmac_stat_rd(PEMSTAT_TBYT__ADDR,port));
        printf("Rx-Byt = %d\n",mcxmac_stat_rd(PEMSTAT_RBYT__ADDR,port));
        printf("Tx-FCS = %d :: ",mcxmac_stat_rd(PEMSTAT_TFCS__ADDR,port));
        printf("Rx-FCS = %d \n",mcxmac_stat_rd(PEMSTAT_RFCS__ADDR,port));
        printf("Tx-UND = %d :: ",mcxmac_stat_rd(PEMSTAT_TUND__ADDR,port));
        printf("Rx-UND = %d \n",mcxmac_stat_rd(PEMSTAT_RUND__ADDR,port));
        printf("Tx-OVR = %d :: ",mcxmac_stat_rd(PEMSTAT_TOVR__ADDR,port));
        printf("Rx-OVR = %d \n",mcxmac_stat_rd(PEMSTAT_ROVR__ADDR,port));
        printf("Tx-FRG = %d :: ",mcxmac_stat_rd(PEMSTAT_TFRG__ADDR,port));
        printf("Rx-FRG = %d \n",mcxmac_stat_rd(PEMSTAT_RFRG__ADDR,port));
        printf("\n");
    }
}

void mac_stat_sgmii_sata() {
    int port = 0;
    for(port = FIRST_PORT; port <= LAST_PORT ; port++){
        printf("-------Port%d----------\n",port);
        printf("Tx-Pkt = %d :: ",mac_stat_rd(PEMSTAT_TPKT__ADDR,port));
        printf("Rx-Pkt = %d \n",mac_stat_rd(PEMSTAT_RPKT__ADDR,port));
        printf("Tx-Byt = %d :: ",mac_stat_rd(PEMSTAT_TBYT__ADDR,port));
        printf("Rx-Byt = %d \n",mac_stat_rd(PEMSTAT_RBYT__ADDR,port));
        printf("Tx-FCS = %d :: ",mac_stat_rd(PEMSTAT_TFCS__ADDR,port));
        printf("Rx-FCS = %d \n",mac_stat_rd(PEMSTAT_RFCS__ADDR,port));
        printf("Tx-UND = %d :: ",mac_stat_rd(PEMSTAT_TUND__ADDR,port));
        printf("Rx-UND = %d \n",mac_stat_rd(PEMSTAT_RUND__ADDR,port));
        printf("Tx-OVR = %d :: ",mac_stat_rd(PEMSTAT_TOVR__ADDR,port));
        printf("Rx-OVR = %d \n",mac_stat_rd(PEMSTAT_ROVR__ADDR,port));
        printf("Tx-FRG = %d :: ",mac_stat_rd(PEMSTAT_TFRG__ADDR,port));
        printf("Rx-FRG = %d \n",mac_stat_rd(PEMSTAT_RFRG__ADDR,port));
        printf("\n");
    }
}

//mac_stat_dump function for sata_sgmii ports P0-P1 of Mustang
void sd() {
    int port = 0;
    //for(port = FIRST_PORT; port <= LAST_PORT ; port++){
    for(port = 0; port <= 1 ; port++){
        printf("-------Port%d----------\n",port);
        printf("Tx-Pkt = %d :: ",mac_stat_rd(PEMSTAT_TPKT__ADDR,port));
        printf("Rx-Pkt = %d \n",mac_stat_rd(PEMSTAT_RPKT__ADDR,port));
        printf("Tx-Byt = %d :: ",mac_stat_rd(PEMSTAT_TBYT__ADDR,port));
        printf("Rx-Byt = %d \n",mac_stat_rd(PEMSTAT_RBYT__ADDR,port));
        printf("Tx-FCS = %d :: ",mac_stat_rd(PEMSTAT_TFCS__ADDR,port));
        printf("Rx-FCS = %d \n",mac_stat_rd(PEMSTAT_RFCS__ADDR,port));
        printf("Tx-UND = %d :: ",mac_stat_rd(PEMSTAT_TUND__ADDR,port));
        printf("Rx-UND = %d \n",mac_stat_rd(PEMSTAT_RUND__ADDR,port));
        printf("Tx-OVR = %d :: ",mac_stat_rd(PEMSTAT_TOVR__ADDR,port));
        printf("Rx-OVR = %d \n",mac_stat_rd(PEMSTAT_ROVR__ADDR,port));
        printf("Tx-FRG = %d :: ",mac_stat_rd(PEMSTAT_TFRG__ADDR,port));
        printf("Rx-FRG = %d \n",mac_stat_rd(PEMSTAT_RFRG__ADDR,port));
        printf("\n");
    }
}


int margin_util_sgmii_xfi() {
    uint32_t inst, inst_base;
    unsigned int wr_val, rd_val;
    int tx_port, display=0;
    int pq_reg_start_val, pq_reg_end_val, iter_pq_reg, pq_reg_sign, rfcs, k, dummy;
    int ctle_eq_start_val, ctle_eq_end_val, iter_ctle_eq;
    int read_tpkt_as_xg[4] = {0, 0, 0, 0}; 
    int read_rpkt_as_xg[4] = {0, 0, 0, 0}; 
    int read_tfcs_as_xg[4] = {0, 0, 0, 0}; 
    int read_rfcs_as_xg[4] = {0, 0, 0, 0}; 

    int read_tpkt_as_xg_bak[4] = {0, 0, 0, 0}; 
    int read_rpkt_as_xg_bak[4] = {0, 0, 0, 0}; 
    int read_tfcs_as_xg_bak[4] = {0, 0, 0, 0}; 
    int read_rfcs_as_xg_bak[4] = {0, 0, 0, 0};   

    int ctle_eq, pq_reg;
    int count_tmp,prbs_tx_port,rx_port, prbs_rx_port , prbs_pattern=7;
    int err_iter_count=0;
    int result_vector[8][64];//[CTLE_EQ][PQ_REG]
    int prbs_test_ret_val=0,i,j;
    unsigned int pn,CTLE_REG,PQ_REG;
    int ch;
    u32 TotalPackets=100000000; //500000000; //200000000; //2000000;

    inst = 0;
    inst_base = 0x0400 + inst*0x0200;
    /*
       if (xfi_sgmii_init_done == 0) {
       printf("\nXFI-SGMII Ports are in initialized\n");
       return 0;
       }
     */
    printf("\n--------------------------------------------------------------------\n");
    printf("\tXFI-SGMII Margning Utility\n");
    printf("--------------------------------------------------------------------\n");

#if 1    
    printf("\nEnter No of packets in hex : 0x");
    if(terminal_server_serial_port==1) pn = get_val(); pn = get_val(); 

    printf("\nEnter Total No of CLTE_REG val in hex : 0x");  
    if(terminal_server_serial_port==1) CTLE_REG = get_val(); CTLE_REG = get_val(); 

    printf("\nEnter Total No of PQ_REG val in hex : 0x");  
    if(terminal_server_serial_port==1) PQ_REG = get_val(); PQ_REG = get_val(); 

    printf("\nEnter PQ_REG Sign [0-Positive 1-Negative: 0x");  
    if(terminal_server_serial_port==1) pq_reg_sign = get_val(); pq_reg_sign = get_val(); 

    printf("\nEnter Tx Port No: "); 
    if(terminal_server_serial_port==1) tx_port = get_val(); tx_port = get_val();

    printf("\nEnter Rx Port No: "); 
    if(terminal_server_serial_port==1) rx_port = get_val(); rx_port = get_val();

    printf("\nEnter CTLE_EQ[ac_gain] sweep range start val (0x0-0x1C Total=8) : 0x");	
    if(terminal_server_serial_port==1) ctle_eq_start_val = get_val(); ctle_eq_start_val = get_val();

    printf("\nEnter CTLE_EQ[ac_gain] sweep range end val : 0x");	
    if(terminal_server_serial_port==1) ctle_eq_end_val   = get_val(); ctle_eq_end_val   = get_val();

    printf("\nEnter pq_reg sweep range start val (0x0-0x40 Total=64) : 0x");	
    if(terminal_server_serial_port==1) pq_reg_start_val  = get_val(); pq_reg_start_val  = get_val();

    printf("\nEnter pq_reg sweep range end val   : 0x");	
    if(terminal_server_serial_port==1) pq_reg_end_val    = get_val(); pq_reg_end_val    = get_val();
#endif
#if 0
    pn = TotalPackets;
    CTLE_REG = 8;  
    PQ_REG = 0x10;  
    tx_port = 1;
    rx_port = 1;
    ctle_eq_start_val = 0x0;
    ctle_eq_end_val   = 0x1c;
    pq_reg_start_val  = 0x1;
    pq_reg_end_val    = 0xd;
    pq_reg_sign = 0;
#endif      

    printf("\n\nEntered Values: ");
    printf("\nTx-Port:%d Rx-Port:%d",tx_port,rx_port);
    printf("\nNo CTLE_REG:%d No PQ_REG:%d PQ_REG_SIGN:%d No Packets:%d",CTLE_REG,PQ_REG,pq_reg_sign,pn);
    printf("\nRange Entered:[CTLE_EQ:0x%x-0x%x][PQ_REG:0x%x-0x%x]",ctle_eq_start_val,ctle_eq_end_val,pq_reg_start_val,pq_reg_end_val);
    printf("\nHit EnterKey to Continue, 1 to quit\n");
    ch=get_val();  
    printf("\n\n");
    if(ch == 1)
        return 0;

    ctle_eq=0;
    for(i=0; i<CTLE_REG; i++) {     // CTLE
        for(j=0; j<PQ_REG; j++) {   // PQ_REG
            result_vector[i][j]=0;  // Clear result_vector
        }
    }

    for(iter_ctle_eq=ctle_eq_start_val; iter_ctle_eq<=ctle_eq_end_val; iter_ctle_eq+=0x4) {

        // Write to CTLE_EQ
        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg1", inst_base + 1*2,XGENET,rx_port,display);
        wr_val = sm_enet_set(rd_val, iter_ctle_eq , 11, 7); // (CTLE_EQ) (AC=iter_ctle_eq/DC=0)
        enet_sds_ind_csr_reg_wr("rxtx_reg1", inst_base + 1*2, wr_val,XGENET,rx_port,display);
        USDELAY(1000);

        pq_reg=0;
        for(iter_pq_reg=pq_reg_start_val; iter_pq_reg<=pq_reg_end_val; iter_pq_reg++) {
            printf("\n-------------------------------------------------------------------------------------------------------------");
            printf("\nUsing CTLE_EQ : 0x%x \tUsing pq_reg : 0x%x \t",iter_ctle_eq,iter_pq_reg);

            // Write to PQ_REG
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg125", inst_base + 125*2,XGENET,rx_port,display);
            wr_val = sm_enet_set(rd_val, iter_pq_reg , 15, 9);  //(pq_reg=iter_pq_reg) (programmable PQ skew)
            wr_val = sm_enet_set(wr_val, pq_reg_sign, 8, 8);    //(sign_pq=pq_reg_sign)
            wr_val = sm_enet_set(wr_val, 1, 1, 1);              //(phz_manual) = 0x1
            enet_sds_ind_csr_reg_wr("rxtx_reg125", inst_base + 125*2, wr_val,XGENET,rx_port,display);
            USDELAY(1000);

            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg1", inst_base + 1*2,XGENET,rx_port,display);
            printf("rxtx_reg1:0x%x", rd_val);

            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg125", inst_base + 125*2,XGENET,rx_port,display);
            printf(" \trxtx_reg125:0x%x\n", rd_val);

            USDELAY(1000);
            serdes_reset_rxd_xg(XGENET , tx_port , display); 
            USDELAY(1000);
            serdes_reset_rxd_xg(XGENET , rx_port , display); 
            USDELAY(1000);

#if 1 // with tx2rx lpbk test
            send_pause_packet_xfi(tx_port,pn);

            read_tpkt_as_xg[tx_port] = mcxmac_stat_rd(PEMSTAT_TPKT__ADDR,tx_port);
            read_rpkt_as_xg[rx_port] = mcxmac_stat_rd(PEMSTAT_RPKT__ADDR,rx_port);
            read_tfcs_as_xg[tx_port] = mcxmac_stat_rd(PEMSTAT_TFCS__ADDR,tx_port);
            read_rfcs_as_xg[rx_port] = mcxmac_stat_rd(PEMSTAT_RFCS__ADDR,rx_port);

            if((read_tpkt_as_xg[tx_port] == 0)) {
                printf("\nPackets are Not Sent Because of Some Issue\n");
                printf("Tx-PortNo:%d Rx-PortNo:%d TPKT:%d RPKT:%d\n",tx_port,rx_port,read_tpkt_as_xg[tx_port],read_rpkt_as_xg[rx_port]);
                break;
            }

            if((read_tpkt_as_xg[tx_port] != read_rpkt_as_xg[rx_port])) {

                printf("\nFAIL => ");
                printf("Tx-PortNo:%d Rx-PortNo:%d TPKT:%d RPKT:%d ",tx_port,rx_port,read_tpkt_as_xg[tx_port],read_rpkt_as_xg[rx_port]);
                printf("TFCS:%d RFCS:%d\n",read_tfcs_as_xg[tx_port],read_rfcs_as_xg[rx_port]);
                /* // checking with TFCS & RX Error Packets 
                result_vector[ctle_eq][pq_reg] = ((read_tpkt_as_xg[tx_port]-read_tfcs_as_xg[tx_port]) - read_rpkt_as_xg[rx_port]); 
                if(result_vector[ctle_eq][pq_reg] < 0)  
                    result_vector[ctle_eq][pq_reg] = (result_vector[ctle_eq][pq_reg] * -1);
                */

                // cheking only with RX RFCS
                result_vector[ctle_eq][pq_reg] = read_rfcs_as_xg[rx_port]; 
            }
            else {
                //result_vector[ctle_eq][pq_reg] = 0;
                printf("\nPASS => ");
                printf("Tx-PortNo:%d Rx-PortNo:%d TPKT:%d RPKT:%d ",tx_port,rx_port,read_tpkt_as_xg[tx_port],read_rpkt_as_xg[rx_port]);
                printf("TFCS:%d RFCS:%d\n",read_tfcs_as_xg[tx_port],read_rfcs_as_xg[rx_port]);
            }
#endif // with tx2rx lpbk test

#if 0 // with rx2tx lpbk test
            printf("\nClear the Stat Counter,");
            read_tpkt_as_xg[rx_port] = mcxmac_stat_rd(PEMSTAT_TPKT__ADDR,rx_port);
            read_rpkt_as_xg[rx_port] = mcxmac_stat_rd(PEMSTAT_RPKT__ADDR,rx_port);
            read_tfcs_as_xg[rx_port] = mcxmac_stat_rd(PEMSTAT_TFCS__ADDR,rx_port);
            read_rfcs_as_xg[rx_port] = mcxmac_stat_rd(PEMSTAT_RFCS__ADDR,rx_port);
            read_tpkt_as_xg_bak[rx_port] = 0; 
            read_rpkt_as_xg_bak[rx_port] = 0; 
            read_tfcs_as_xg_bak[rx_port] = 0; 
            read_rfcs_as_xg_bak[rx_port] = 0;   
            printf("Done\n");

            printf("\nWaiting for %d Packets to Send/Receive from IXIA:\n",TotalPackets);
            while(1) {
                read_rpkt_as_xg[rx_port] = mcxmac_stat_rd(PEMSTAT_RPKT__ADDR,rx_port);
                read_rpkt_as_xg_bak[rx_port] += read_rpkt_as_xg[rx_port]; 
                if(read_rpkt_as_xg_bak[rx_port] >= TotalPackets)
                    break;
            }

            printf("\nCheck for CRC Error Packets\n");
            read_tpkt_as_xg[rx_port] = mcxmac_stat_rd(PEMSTAT_TPKT__ADDR,rx_port);
            //read_rpkt_as_xg[rx_port] = mcxmac_stat_rd(PEMSTAT_RPKT__ADDR,rx_port);
            read_tfcs_as_xg[rx_port] = mcxmac_stat_rd(PEMSTAT_TFCS__ADDR,rx_port);
            read_rfcs_as_xg[rx_port] = mcxmac_stat_rd(PEMSTAT_RFCS__ADDR,rx_port);

            if( (read_tfcs_as_xg[rx_port] > 0) || (read_rfcs_as_xg[rx_port] > 0)) {
                printf("\nFAIL => ");
                printf("Rx-PortNo:%d TPKT:%d RPKT:%d ",rx_port,read_tpkt_as_xg[rx_port],read_rpkt_as_xg_bak[rx_port]);
                printf("TFCS:%d RFCS:%d\n",read_tfcs_as_xg[rx_port],read_rfcs_as_xg[rx_port]);
                result_vector[ctle_eq][pq_reg] = read_rfcs_as_xg[rx_port]; 
            }
            else { // 200M
                printf("\nPASS => ");
                printf("Rx-PortNo:%d TPKT:%d RPKT:%d ",rx_port,read_tpkt_as_xg[rx_port],read_rpkt_as_xg_bak[rx_port]);
                printf("TFCS:%d RFCS:%d\n",read_tfcs_as_xg[rx_port],read_rfcs_as_xg[rx_port]);
                result_vector[ctle_eq][pq_reg] = read_rfcs_as_xg[rx_port];                     
            }
           
            /*             
            printf("Press 1 to Continue: \n");
            while(1) {
                ch=get_val();  
                if(ch == 1)
                    break;
            }
            */            

#endif  // with rx2tx lpbk test

            //read_rpkt_as_bak_xg[rx_port] = 0; // clear the counter
            USDELAY(100000);
            printf("-------------------------------------------------------------------------------------------------------------\n");
            pq_reg++;
        } // pq_reg

#if 1 // tx2rx lpbk test
        if((read_tpkt_as_xg[tx_port] == 0)) {
            printf("\nPackets are Not Sent Because of Some Issue\n");
            printf("Tx-PortNo:%d Rx-PortNo:%d TPKT:%d RPKT:%d\n",tx_port,rx_port,read_tpkt_as_xg[tx_port],read_rpkt_as_xg[rx_port]);
            break;
        }
#endif        
        ctle_eq++;
    } // ctle_eq

    // Print Result Vector
    printf("\n\n---------------------------------------------------------------\n");
    printf("\tNumber of Packets Transmited & Received:%d\n",pn);
    printf("-------------------------------------------------------------------");
    printf("\n\t          ==================================");
    printf("\n\t          Result Vector for XFI-SGMII GE-%d ",rx_port);
    printf("\n\t          ==================================");
    printf("\n\n\t\tCTLE_EQ[AC_GAIN]");
    printf("\n");
    for(iter_ctle_eq=ctle_eq_start_val; iter_ctle_eq<=ctle_eq_end_val; iter_ctle_eq+=4)
        printf("\t0x%x",iter_ctle_eq);

    printf("\nPQ_REG (SIGN:%d)",pq_reg_sign);

    for(pq_reg=0;pq_reg<PQ_REG;pq_reg++) {	// pq_reg[17]
        printf("\n0x%x",(pq_reg+pq_reg_start_val));
        for(ctle_eq=0;ctle_eq<CTLE_REG;ctle_eq++)	{ // CTLE_EQ[8]
            printf("\t%d",result_vector[ctle_eq][pq_reg]);
        }
    }
    printf("\n");
}

int margin_util_sgmii_sata() {
    uint32_t inst, inst_base;
    unsigned int wr_val, rd_val;
    int tx_port, display=0;
    int pq_reg_start_val, pq_reg_end_val, iter_pq_reg, pq_reg_sign, rfcs, k, dummy;
    int ctle_eq_start_val, ctle_eq_end_val, iter_ctle_eq;
    int read_tpkt_as_xg[4] = {0, 0, 0, 0}; 
    int read_rpkt_as_xg[4] = {0, 0, 0, 0}; 
    int read_tfcs_as_xg[4] = {0, 0, 0, 0}; 
    int read_rfcs_as_xg[4] = {0, 0, 0, 0};

    int read_tpkt_as_xg_bak[4] = {0, 0, 0, 0}; 
    int read_rpkt_as_xg_bak[4] = {0, 0, 0, 0}; 
    int read_tfcs_as_xg_bak[4] = {0, 0, 0, 0}; 
    int read_rfcs_as_xg_bak[4] = {0, 0, 0, 0};   

    int ctle_eq, pq_reg;
    int count_tmp,prbs_tx_port,rx_port, prbs_rx_port , prbs_pattern=7;
    int err_iter_count=0;
    int result_vector[8][64];//[CTLE_EQ][PQ_REG]
    int prbs_test_ret_val=0,i,j;
    unsigned int pn,CTLE_REG,PQ_REG;
    int ch;
    u32 TotalPackets=100000000; //500000000; //200000000; //2000000;

    //inst = 0;
    //inst_base = 0x0400 + inst*0x0200;
    /*
       if (sata_sgmii_init_done == 0) {
       printf("\nXFI-SGMII Ports are in initialized\n");
       return 0;
       }
     */
    printf("\n--------------------------------------------------------------------\n");
    printf("\tSATA-SGMII Margning Utility\n");
    printf("--------------------------------------------------------------------\n");

#if 1    
    printf("\nEnter No of packets in hex : 0x");
    if(terminal_server_serial_port==1) pn = get_val(); pn = get_val(); 

    printf("\nEnter Total No of CLTE_REG val in hex : 0x");  
    if(terminal_server_serial_port==1) CTLE_REG = get_val(); CTLE_REG = get_val(); 

    printf("\nEnter Total No of PQ_REG val in hex : 0x");  
    if(terminal_server_serial_port==1) PQ_REG = get_val(); PQ_REG = get_val(); 

    printf("\nEnter PQ_REG Sign [0-Positive 1-Negative: 0x");  
    if(terminal_server_serial_port==1) pq_reg_sign = get_val(); pq_reg_sign = get_val(); 

    printf("\nEnter Tx Port No: "); 
    if(terminal_server_serial_port==1) tx_port = get_val(); tx_port = get_val();

    printf("\nEnter Rx Port No: "); 
    if(terminal_server_serial_port==1) rx_port = get_val(); rx_port = get_val();

    printf("\nEnter CTLE_EQ[ac_gain] sweep range start val (0x0-0x1C Total=8) : 0x");	
    if(terminal_server_serial_port==1) ctle_eq_start_val = get_val(); ctle_eq_start_val = get_val();

    printf("\nEnter CTLE_EQ[ac_gain] sweep range end val : 0x");	
    if(terminal_server_serial_port==1) ctle_eq_end_val   = get_val(); ctle_eq_end_val   = get_val();

    printf("\nEnter pq_reg sweep range start val (0x0-0x40 Total=64) : 0x");	
    if(terminal_server_serial_port==1) pq_reg_start_val  = get_val(); pq_reg_start_val  = get_val();

    printf("\nEnter pq_reg sweep range end val   : 0x");	
    if(terminal_server_serial_port==1) pq_reg_end_val    = get_val(); pq_reg_end_val    = get_val();
#endif
#if 0
    pn = TotalPackets;
    CTLE_REG = 8;  
    PQ_REG = 0x10;  
    tx_port = 0;
    rx_port = 1;
    ctle_eq_start_val = 0x0;
    ctle_eq_end_val   = 0x1c;
    pq_reg_start_val  = 0x1;
    pq_reg_end_val    = 0xd;
    pq_reg_sign = 0;
#endif      
    inst = rx_port & 0x1;
    inst_base = 0x0400 + inst*0x0200;

    printf("\n\nEntered Values: ");
    printf("\nTx-Port:%d Rx-Port:%d",tx_port,rx_port);
    printf("\nNo CTLE_REG:%d No PQ_REG:%d PQ_REG_SIGN:%d No Packets:%d",CTLE_REG,PQ_REG,pq_reg_sign,pn);
    printf("\nRange Entered:[CTLE_EQ:0x%x-0x%x][PQ_REG:0x%x-0x%x]",ctle_eq_start_val,ctle_eq_end_val,pq_reg_start_val,pq_reg_end_val);
    printf("\nHit EnterKey to Continue, 1 to quit\n");
    ch=get_val();  
    printf("\n\n");
    if(ch == 1)
        return 0;

    ctle_eq=0;
    for(i=0; i<CTLE_REG; i++) {     // CTLE
        for(j=0; j<PQ_REG; j++) {   // PQ_REG
            result_vector[i][j]=0;  // Clear result_vector
        }
    }

    for(iter_ctle_eq=ctle_eq_start_val; iter_ctle_eq<=ctle_eq_end_val; iter_ctle_eq+=0x4) {

        // Write to CTLE_EQ
        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg1", inst_base + 1*2,ENET,rx_port,display);
        wr_val = sm_enet_set(rd_val, iter_ctle_eq , 11, 7); // (CTLE_EQ) (AC=iter_ctle_eq/DC=0)
        wr_val = sm_enet_set(wr_val, 0, 6, 5);              //(rvxreg1=0,bios_cur=105%) 
        enet_sds_ind_csr_reg_wr("rxtx_reg1", inst_base + 1*2, wr_val,ENET,rx_port,display);
        USDELAY(1000);

        pq_reg=0;
        for(iter_pq_reg=pq_reg_start_val; iter_pq_reg<=pq_reg_end_val; iter_pq_reg++) {
            printf("\n-------------------------------------------------------------------------------------------------------------");
            printf("\nUsing CTLE_EQ : 0x%x \tUsing pq_reg : 0x%x \t",iter_ctle_eq,iter_pq_reg);

            // Write to PQ_REG
            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg125", inst_base + 125*2,ENET,rx_port,display);
            wr_val = sm_enet_set(rd_val, iter_pq_reg , 15, 9);  //(pq_reg=iter_pq_reg) (programmable PQ skew)
            wr_val = sm_enet_set(wr_val, pq_reg_sign, 8, 8);    //(sign_pq=pq_reg_sign)
            wr_val = sm_enet_set(wr_val, 1, 1, 1);              //(phz_manual) = 0x1
            enet_sds_ind_csr_reg_wr("rxtx_reg125", inst_base + 125*2, wr_val,ENET,rx_port,display);
            USDELAY(1000);

            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg1", inst_base + 1*2,ENET,rx_port,display);
            printf("rxtx_reg1:0x%x", rd_val);

            rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg125", inst_base + 125*2,ENET,rx_port,display);
            printf(" \trxtx_reg125:0x%x\n", rd_val);

            USDELAY(1000);
            serdes_reset_rxd(tx_port , display); 
            USDELAY(1000);
            serdes_reset_rxd(rx_port , display); 
            USDELAY(1000);

#if 1 // with tx2rx lpbk test
            send_pause_packet_sata(tx_port,pn);

            read_tpkt_as_xg[tx_port] = mac_stat_rd(PEMSTAT_TPKT__ADDR,tx_port);
            read_rpkt_as_xg[rx_port] = mac_stat_rd(PEMSTAT_RPKT__ADDR,rx_port);
            read_tfcs_as_xg[tx_port] = mac_stat_rd(PEMSTAT_TFCS__ADDR,tx_port);
            read_rfcs_as_xg[rx_port] = mac_stat_rd(PEMSTAT_RFCS__ADDR,rx_port);

            if((read_tpkt_as_xg[tx_port] == 0)) {
                printf("\nPackets are Not Sent Because of Some Issue\n");
                printf("Tx-PortNo:%d Rx-PortNo:%d TPKT:%d RPKT:%d\n",tx_port,rx_port,read_tpkt_as_xg[tx_port],read_rpkt_as_xg[rx_port]);
                break;
            }

            if((read_tpkt_as_xg[tx_port] != read_rpkt_as_xg[rx_port])) {

                printf("\nFAIL => ");
                printf("Tx-PortNo:%d Rx-PortNo:%d TPKT:%d RPKT:%d ",tx_port,rx_port,read_tpkt_as_xg[tx_port],read_rpkt_as_xg[rx_port]);
                printf("TFCS:%d RFCS:%d\n",read_tfcs_as_xg[tx_port],read_rfcs_as_xg[rx_port]);
                /* // checking with TFCS & RX Error Packets 
                result_vector[ctle_eq][pq_reg] = ((read_tpkt_as_xg[tx_port]-read_tfcs_as_xg[tx_port]) - read_rpkt_as_xg[rx_port]); 
                if(result_vector[ctle_eq][pq_reg] < 0)  
                    result_vector[ctle_eq][pq_reg] = (result_vector[ctle_eq][pq_reg] * -1);
                */

                // cheking only with RX RFCS
                result_vector[ctle_eq][pq_reg] = read_rfcs_as_xg[rx_port]; 
            }
            else {
                //result_vector[ctle_eq][pq_reg] = 0;
                printf("\nPASS => ");
                printf("Tx-PortNo:%d Rx-PortNo:%d TPKT:%d RPKT:%d ",tx_port,rx_port,read_tpkt_as_xg[tx_port],read_rpkt_as_xg[rx_port]);
                printf("TFCS:%d RFCS:%d\n",read_tfcs_as_xg[tx_port],read_rfcs_as_xg[rx_port]);
            }
#endif // with tx2rx lpbk test
            //read_rpkt_as_bak_xg[rx_port] = 0; // clear the counter
            USDELAY(100000);
            printf("-------------------------------------------------------------------------------------------------------------\n");
            pq_reg++;
        } // pq_reg

#if 1 // tx2rx lpbk test
        if((read_tpkt_as_xg[tx_port] == 0)) {
            printf("\nPackets are Not Sent Because of Some Issue\n");
            printf("Tx-PortNo:%d Rx-PortNo:%d TPKT:%d RPKT:%d\n",tx_port,rx_port,read_tpkt_as_xg[tx_port],read_rpkt_as_xg[rx_port]);
            break;
        }
#endif        
        ctle_eq++;
    } // ctle_eq

    // Print Result Vector
    printf("\n\n---------------------------------------------------------------\n");
    printf("\tNumber of Packets Transmited & Received:%d\n",pn);
    printf("-------------------------------------------------------------------");
    printf("\n\t          ==================================");
    printf("\n\t          Result Vector for SATA-SGMII GE-%d ",rx_port);
    printf("\n\t          ==================================");
    printf("\n\n\t\tCTLE_EQ[AC_GAIN]");
    printf("\n");
    for(iter_ctle_eq=ctle_eq_start_val; iter_ctle_eq<=ctle_eq_end_val; iter_ctle_eq+=4)
        printf("\t0x%x",iter_ctle_eq);

    printf("\nPQ_REG (SIGN:%d)",pq_reg_sign);

    for(pq_reg=0;pq_reg<PQ_REG;pq_reg++) {	// pq_reg[17]
        printf("\n0x%x",(pq_reg+pq_reg_start_val));
        for(ctle_eq=0;ctle_eq<CTLE_REG;ctle_eq++)	{ // CTLE_EQ[8]
            printf("\t%d",result_vector[ctle_eq][pq_reg]);
        }
    }
    printf("\n");
}

int check_phy_autoneg_bypass_sts(int phy_addr) {

    int phy_reg = 27, retval;
    int ind_address,ind_data;
    int count=10000;

    while(count) {
        ind_address = ((phy_addr << 8) | phy_reg);
        ind_data = mdio_rd(ind_address,MENET,0,0);
        if(ind_data & 0x0800) { 
            retval = 1;
        }
        else 
            retval = 0 ;
        count--;
    }

    printf("\nPHY-Addr:0x%x Reg-Addr:0x%x Serial Interface AutoNegotiation Bypass Status:0x%x\n",phy_addr,phy_reg,ind_data);

    return retval;
}

void set_serial_interface_autoneg_bypass(int phy_addr) {
    int ind_data, ind_address, phy_reg=0,val; 

    phy_reg=27;
    ind_address = ((phy_addr << 8) | phy_reg);
    ind_data = mdio_rd(ind_address,MENET,0,0);
    lprintf(3,"\nBefore phy_addr:0x%x phy_reg:0x%x ind_data:0x%x \n",phy_addr,phy_reg,ind_data);

    ind_data = ind_data | 0x0800;
    mdio_wr(ind_address,ind_data,MENET,0,0); //serial interface auto neg bypass enable 
    USDELAY(8000);

    phy_reg=0;
    ind_address = ((phy_addr << 8) | phy_reg);
    ind_data = mdio_rd(ind_address,MENET,0,0);
    lprintf(3,"Before phy_addr:0x%x phy_reg:0x%x ind_data:0x%x \n",phy_addr,phy_reg,ind_data);

    ind_data = ind_data | 0x8000;
    mdio_wr(ind_address,ind_data,MENET,0,0); // s/w reset
    USDELAY(8000);

    phy_reg=27;
    ind_address = ((phy_addr << 8) | phy_reg);
    ind_data = mdio_rd(ind_address,MENET,0,0);
    lprintf(3,"After  phy_addr:0x%x phy_reg:0x%x ind_data:0x%x \n",phy_addr,phy_reg,ind_data);

    phy_reg=0;
    ind_address = ((phy_addr << 8) | phy_reg);
    ind_data = mdio_rd(ind_address,MENET,0,0);
    lprintf(3,"After  phy_addr:0x%x phy_reg:0x%x ind_data:0x%x \n",phy_addr,phy_reg,ind_data);
}

int debug_gen_avg_val_xfi_sgmii(int port)
{
	int max_loop = 10,timeout=50;
	int avg_loop = 0;
	int lat_do = 0, lat_xo = 0, lat_eo = 0, lat_so = 0;
	int lat_de = 0, lat_xe = 0, lat_ee = 0, lat_se = 0;
	int sum_cal = 0;
	int lat_do_itr, lat_xo_itr, lat_eo_itr, lat_so_itr;
	int lat_de_itr, lat_xe_itr, lat_ee_itr, lat_se_itr;
	int sum_cal_itr = 0;
	int fail_even;
	int fail_odd;
	u32 val;
	u32 dfepreset_old;
	u32 dfe_tap;
	int loop;
	uint32_t inst, inst_base;
	unsigned int  wr_val, rd_val;
	int data32,data;
	int display =0;
	
	inst = 0;
	inst_base = 0x0400 + inst*0x0200;

    // Moved this from eyescan_sub function gen_avg_val() code ==> as per Chidvilas's discussion with Poly on [28-Aug-2014]   
    data = enet_sds_ind_csr_reg_rd("RXTX_REG145", inst_base + 145*2,XGENET,port,display);
    data = FIELD_RXTX_REG145_RXVWES_LATENA_SET(data, 1);
    data = FIELD_RXTX_REG145_RXES_ENA_SET(data, 1);
    enet_sds_ind_csr_reg_wr("RXTX_REG145", inst_base + 145*2, data,XGENET,port,display);

	lprintf(3,"\nGenerating avg calibration value for lane %d\n",port);

	/* Enable RX Hi-Z termination */
	rd_val = enet_sds_ind_csr_reg_rd("RXTX_REG12", inst_base + 12*2,XGENET,port,display);
	wr_val = FIELD_RXTX_REG12_RX_DET_TERM_ENABLE_SET(rd_val,1);
	enet_sds_ind_csr_reg_wr("RXTX_REG12", inst_base + 12*2, wr_val,XGENET,port,display);

	/* Turn off DFE */
	rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg28", inst_base + 28*2,XGENET,port,display);
	enet_sds_ind_csr_reg_wr("rxtx_reg28", inst_base + 28*2, 0x0000,XGENET,port,display);

	/* DFE Presets to zero */
	rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg31", inst_base + 31*2,XGENET,port,display);
	enet_sds_ind_csr_reg_wr("rxtx_reg31", inst_base + 31*2, 0x0000,XGENET,port,display);

	/*
	 * Receiver Offset Calibration:
	 * Calibrate the receiver signal path offset in two steps - summar
	 * and latch calibration.
	 * Runs the "Receiver Offset Calibration multiple times to determine
	 * the average value to use.
	 */
	rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg14", inst_base + 14*2,XGENET,port,display);
	wr_val = FIELD_RXTX_REG14_CTLE_LATCAL_MAN_ENA_SET(rd_val, 0x0); // auto=0
	enet_sds_ind_csr_reg_wr("RXTX_REG14", inst_base + 14*2,wr_val,XGENET,port,display);    
	lprintf(3,"Enable Auto Summer calibration\n");

	val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,XGENET,port,display);
	val = FIELD_RXTX_REG127_LATCH_MAN_CAL_ENA_SET(val, 0x0); //auto=0
	lprintf(3,"Enable Auto Latch calibration\n");
	enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, val,XGENET,port,display);
	USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500

    timeout=50;
	while (avg_loop < max_loop) {
		/* Start SUMMER calibration */
		rd_val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,XGENET,port,display);
		wr_val = FIELD_RXTX_REG127_FORCE_SUM_CAL_START_SET(rd_val,1);
		enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, wr_val,XGENET,port,display);

		/*
		 * As per PHY design spec, the Summer calibration requires a minimum
		 * of 100us to complete.
		 */
		USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500
		rd_val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,XGENET,port,display);
		wr_val = FIELD_RXTX_REG127_FORCE_SUM_CAL_START_SET(rd_val,0);
		enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, wr_val,XGENET,port,display);

		/*
		 * As per PHY design spec, the auto calibration requires a minimum
		 * of 100us to complete.
		 */
		USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500
		
		loop = 100;
		do {
			val = enet_sds_ind_csr_reg_rd("rxtx_reg158", inst_base + 158*2,XGENET,port,display);
			if (FIELD_RXTX_REG158_SUM_CALIB_DONE_RD(val) && (FIELD_RXTX_REG158_SUM_CALIB_ERR_RD(val) == 0))
				break;

			USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500
		} while (--loop > 0);

		val = enet_sds_ind_csr_reg_rd("rxtx_reg158", inst_base + 158*2,XGENET,port,display);

		if (FIELD_RXTX_REG158_SUM_CALIB_DONE_RD(val) && (FIELD_RXTX_REG158_SUM_CALIB_ERR_RD(val) == 0))  {
			//lprintf(3,"rxtx_channel%d  summer calib pass \n", port);
			val = enet_sds_ind_csr_reg_rd("rxtx_reg121", inst_base + 121*2,XGENET,port,display);

			sum_cal_itr = FIELD_RXTX_REG121_SUMOS_CAL_CODE_RD(val);
			sum_cal += sum_cal_itr;
			++avg_loop;
            timeout=50;
			lprintf(3,"rxtx_channel%d  summer calib pass sum_cal_itr:%d \n", port,sum_cal_itr);
		}  
        else {
            timeout--;
            if(timeout == 0) {
			    printf("Receiver summer calibration failed at %d loop\n",avg_loop);
                return -1;
            }
            else {
                printf("!");
            }
		}
		serdes_reset_rxd_xg(XGENET,port,0);
	}

	/* Update SUMMER calibration with average value */
	rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg14", inst_base + 14*2,XGENET,port,display);
	wr_val = FIELD_RXTX_REG14_CLTE_LATCAL_MAN_PROG_SET(rd_val,xgene_phy_get_avg(sum_cal, max_loop));
	enet_sds_ind_csr_reg_wr("RXTX_REG14", inst_base + 14*2,wr_val,XGENET,port,display);
	lprintf(3,"SUM 0x%x\n",xgene_phy_get_avg(sum_cal, max_loop));

	rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg14", inst_base + 14*2,XGENET,port,display);
	wr_val = FIELD_RXTX_REG14_CTLE_LATCAL_MAN_ENA_SET(rd_val, 0x1);
	enet_sds_ind_csr_reg_wr("RXTX_REG14", inst_base + 14*2,wr_val,XGENET,port,display);
	lprintf(3,"Enable Manual Summer calibration\n");

	avg_loop = 0;
    timeout=50;
	while (avg_loop < max_loop) {
		/* Start latch calibration */
		rd_val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,XGENET,port,display);
		wr_val = FIELD_RXTX_REG127_FORCE_LAT_CAL_START_SET(rd_val,1);
		enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, wr_val,XGENET,port,display);

		/*
		 * As per PHY design spec, the latch calibration requires a minimum
		 * of 100us to complete.
		 */
		USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500

		rd_val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,XGENET,port,display);
		wr_val = FIELD_RXTX_REG127_FORCE_LAT_CAL_START_SET(rd_val,0);
		enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, wr_val,XGENET,port,display);

		/* check lat calib, 
		 * The lat_calib is take about 200ms to be done 
		 * after release serdes reset. 
		 * It only occured 1time
		 */
		USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500
		loop = 1000;
		do {
			val = enet_sds_ind_csr_reg_rd("rxtx_reg158", inst_base + 158*2,XGENET,port,display);

			if (FIELD_RXTX_REG158_LAT_CALIB_DONE_RD(val))
				break;
			USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500

		} while (--loop > 0);

		val = enet_sds_ind_csr_reg_rd("rxtx_reg158", inst_base + 158*2,XGENET,port,display);

		if (FIELD_RXTX_REG158_LAT_CALIB_DONE_RD(val)) 
			lprintf(3,"rxtx_channel%d  lat calib pass and time taken =%dms \n",port, (1000-loop)*2);
		else 
			lprintf(3,"rxtx_channel%d  lat calib failed even after %d loops\n",port, (1000-loop));

		val = enet_sds_ind_csr_reg_rd("rxtx_reg21", inst_base + 21*2,XGENET,port,display);
		lat_do_itr = FIELD_RXTX_REG21_DO_LATCH_CALOUT_RD(val);
		lat_xo_itr = FIELD_RXTX_REG21_XO_LATCH_CALOUT_RD(val);
		fail_odd = FIELD_RXTX_REG21_LATCH_CAL_FAIL_ODD_RD(val);

		val = enet_sds_ind_csr_reg_rd("rxtx_reg22", inst_base + 22*2,XGENET,port,display);
		lat_eo_itr = FIELD_RXTX_REG22_EO_LATCH_CALOUT_RD(val);
		lat_so_itr = FIELD_RXTX_REG22_SO_LATCH_CALOUT_RD(val);
		fail_even = FIELD_RXTX_REG22_LATCH_CAL_FAIL_EVEN_RD(val);

		val = enet_sds_ind_csr_reg_rd("rxtx_reg23", inst_base + 23*2,XGENET,port,display);
		lat_de_itr = FIELD_RXTX_REG23_DE_LATCH_CALOUT_RD(val);
		lat_xe_itr = FIELD_RXTX_REG23_XE_LATCH_CALOUT_RD(val);

		val = enet_sds_ind_csr_reg_rd("rxtx_reg24", inst_base + 24*2,XGENET,port,display);
		lat_ee_itr = FIELD_RXTX_REG24_EE_LATCH_CALOUT_RD(val);
		lat_se_itr = FIELD_RXTX_REG24_SE_LATCH_CALOUT_RD(val);

		/* Check for failure. If passed, sum them for averaging */
		if ((fail_even == 0 || fail_even == 1) && (fail_odd == 0 || fail_odd == 1)) {
			lat_do += lat_do_itr;
			lat_xo += lat_xo_itr;
			lat_eo += lat_eo_itr;
			lat_so += lat_so_itr;
			lat_de += lat_de_itr;
			lat_xe += lat_xe_itr;
			lat_ee += lat_ee_itr;
			lat_se += lat_se_itr;

			lprintf(3,"Iteration %d:\n", avg_loop);
			lprintf(3,"DO 0x%x XO 0x%x EO 0x%x SO 0x%x\n",lat_do_itr, lat_xo_itr, lat_eo_itr,lat_so_itr);
			lprintf(3,"DE 0x%x XE 0x%x EE 0x%x SE 0x%x\n",lat_de_itr, lat_xe_itr, lat_ee_itr,lat_se_itr);
			lprintf(3,"SUM 0x%x\n", sum_cal_itr);
			++avg_loop;
            timeout=50;
		} 
        else {
            timeout--;
            if(timeout == 0) {
			    printf("Receiver latch calibration failed at %d loop\n",avg_loop);
                return -2;
            }
            else {
                printf("!");
            }
		}
		serdes_reset_rxd_xg(XGENET,port,0);
	}

	/* Update latch manual calibration with average value */
	val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,XGENET,port,display);
	val = FIELD_RXTX_REG127_DO_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_do, max_loop));
	val = FIELD_RXTX_REG127_XO_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_xo, max_loop));
	enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, val,XGENET,port,display);

	val = enet_sds_ind_csr_reg_rd("RXTX_REG128", inst_base + 128*2,XGENET,port,display);
	val = FIELD_RXTX_REG128_EO_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_eo, max_loop));
	val = FIELD_RXTX_REG128_SO_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_so, max_loop));
	enet_sds_ind_csr_reg_wr("RXTX_REG128", inst_base + 128*2, val,XGENET,port,display);

	val = enet_sds_ind_csr_reg_rd("RXTX_REG129", inst_base + 129*2,XGENET,port,display);
	val = FIELD_RXTX_REG129_DE_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_de, max_loop));
	val = FIELD_RXTX_REG129_XE_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_xe, max_loop));
	enet_sds_ind_csr_reg_wr("RXTX_REG129", inst_base + 129*2, val,XGENET,port,display);

	val = enet_sds_ind_csr_reg_rd("RXTX_REG130", inst_base + 130*2,XGENET,port,display);
	val = FIELD_RXTX_REG130_EE_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_ee, max_loop));
	val = FIELD_RXTX_REG130_SE_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_se, max_loop));
	enet_sds_ind_csr_reg_wr("RXTX_REG130", inst_base + 130*2, val,XGENET,port,display);

	lprintf(3,"Average Value:\n");
	lprintf(3,"DO 0x%x XO 0x%x EO 0x%x SO 0x%x\n",
			xgene_phy_get_avg(lat_do, max_loop),
			xgene_phy_get_avg(lat_xo, max_loop),
			xgene_phy_get_avg(lat_eo, max_loop),
			xgene_phy_get_avg(lat_so, max_loop));
	lprintf(3,"DE 0x%x XE 0x%x EE 0x%x SE 0x%x\n",
			xgene_phy_get_avg(lat_de, max_loop),
			xgene_phy_get_avg(lat_xe, max_loop),
			xgene_phy_get_avg(lat_ee, max_loop),
			xgene_phy_get_avg(lat_se, max_loop));
	val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,XGENET,port,display);
	val = FIELD_RXTX_REG127_LATCH_MAN_CAL_ENA_SET(val, 0x1);
	lprintf(3,"Enable Manual Latch calibration\n");
	enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, val,XGENET,port,display);
	USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500

	/* Disable RX Hi-Z termination */
	val = enet_sds_ind_csr_reg_rd("RXTX_REG12", inst_base + 12*2,XGENET,port,display);
	val = FIELD_RXTX_REG12_RX_DET_TERM_ENABLE_SET(val, 0);
	enet_sds_ind_csr_reg_wr("RXTX_REG12", inst_base + 12*2, val,XGENET,port,display);

	/* Turn on/off DFE */
    //enet_sds_ind_csr_reg_wr("RXTX_REG28", inst_base + 28*2, 0x7,XGENET,port,display);
    enet_sds_ind_csr_reg_wr("RXTX_REG28", inst_base + 28*2, 0x0,XGENET,port,display);  //10-09-2014 BLT Debug Jitu/Satish

	enet_sds_ind_csr_reg_wr("RXTX_REG31", inst_base + 31*2, val,XGENET,port,display);

    return 0;
}

int debug_gen_avg_val_sata_sgmii(int port)
{
	int max_loop = 10,timeout=50;
	int avg_loop = 0;
	int lat_do = 0, lat_xo = 0, lat_eo = 0, lat_so = 0;
	int lat_de = 0, lat_xe = 0, lat_ee = 0, lat_se = 0;
	int sum_cal = 0;
	int lat_do_itr, lat_xo_itr, lat_eo_itr, lat_so_itr;
	int lat_de_itr, lat_xe_itr, lat_ee_itr, lat_se_itr;
	int sum_cal_itr = 0;
	int fail_even;
	int fail_odd;
	u32 val;
	u32 dfepreset_old;
	u32 dfe_tap;
	int loop;
	uint32_t inst, inst_base;
	unsigned int  wr_val, rd_val;
	int data32,data;
	int display =0;
	
	//inst = 0;
    inst = port & 0x1;
	inst_base = 0x0400 + inst*0x0200;

    // Moved this from eyescan_sub function gen_avg_val() code ==> as per Chidvilas's discussion with Poly on [28-Aug-2014]   
    data = enet_sds_ind_csr_reg_rd("RXTX_REG145", inst_base + 145*2,ENET,port,display);
    data = FIELD_RXTX_REG145_RXVWES_LATENA_SET(data, 1);
    data = FIELD_RXTX_REG145_RXES_ENA_SET(data, 1);
    enet_sds_ind_csr_reg_wr("RXTX_REG145", inst_base + 145*2, data,ENET,port,display);

	lprintf(3,"\nGenerating avg calibration value for lane %d\n",port);

	/* Enable RX Hi-Z termination */
	rd_val = enet_sds_ind_csr_reg_rd("RXTX_REG12", inst_base + 12*2,ENET,port,display);
	wr_val = FIELD_RXTX_REG12_RX_DET_TERM_ENABLE_SET(rd_val,1);
	enet_sds_ind_csr_reg_wr("RXTX_REG12", inst_base + 12*2, wr_val,ENET,port,display);

	/* Turn off DFE */
	rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg28", inst_base + 28*2,ENET,port,display);
	enet_sds_ind_csr_reg_wr("rxtx_reg28", inst_base + 28*2, 0x0000,ENET,port,display);

	/* DFE Presets to zero */
	rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg31", inst_base + 31*2,ENET,port,display);
	enet_sds_ind_csr_reg_wr("rxtx_reg31", inst_base + 31*2, 0x0000,ENET,port,display);

	/*
	 * Receiver Offset Calibration:
	 * Calibrate the receiver signal path offset in two steps - summar
	 * and latch calibration.
	 * Runs the "Receiver Offset Calibration multiple times to determine
	 * the average value to use.
	 */

	rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg14", inst_base + 14*2,ENET,port,display);
	wr_val = FIELD_RXTX_REG14_CTLE_LATCAL_MAN_ENA_SET(rd_val, 0x0); // auto=0
	enet_sds_ind_csr_reg_wr("RXTX_REG14", inst_base + 14*2,wr_val,ENET,port,display);
	lprintf(3,"Enable Auto Summer calibration\n");

	val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,ENET,port,display);
	val = FIELD_RXTX_REG127_LATCH_MAN_CAL_ENA_SET(val, 0x0); //auto=0
	lprintf(3,"Enable Auto Latch calibration\n");
	enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, val,ENET,port,display);
	USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500

    timeout=50;
	while (avg_loop < max_loop) {
		/* Start SUMMER calibration */
		rd_val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,ENET,port,display);
		wr_val = FIELD_RXTX_REG127_FORCE_SUM_CAL_START_SET(rd_val,1);
		enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, wr_val,ENET,port,display);

		/*
		 * As per PHY design spec, the Summer calibration requires a minimum
		 * of 100us to complete.
		 */
		USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500
		rd_val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,ENET,port,display);
		wr_val = FIELD_RXTX_REG127_FORCE_SUM_CAL_START_SET(rd_val,0);
		enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, wr_val,ENET,port,display);

		/*
		 * As per PHY design spec, the auto calibration requires a minimum
		 * of 100us to complete.
		 */
		USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500
		
		loop = 100;
		do {
			val = enet_sds_ind_csr_reg_rd("rxtx_reg158", inst_base + 158*2,ENET,port,display);
			if (FIELD_RXTX_REG158_SUM_CALIB_DONE_RD(val) && (FIELD_RXTX_REG158_SUM_CALIB_ERR_RD(val) == 0))
				break;

			USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500
		} while (--loop > 0);

		val = enet_sds_ind_csr_reg_rd("rxtx_reg158", inst_base + 158*2,ENET,port,display);

		if (FIELD_RXTX_REG158_SUM_CALIB_DONE_RD(val) && (FIELD_RXTX_REG158_SUM_CALIB_ERR_RD(val) == 0))  {
			//lprintf(3,"rxtx_channel%d  summer calib pass \n", port);
			val = enet_sds_ind_csr_reg_rd("rxtx_reg121", inst_base + 121*2,ENET,port,display);

			sum_cal_itr = FIELD_RXTX_REG121_SUMOS_CAL_CODE_RD(val);
			sum_cal += sum_cal_itr;
			++avg_loop;
            timeout=50;
			lprintf(3,"rxtx_channel%d  summer calib pass sum_cal_itr:%d \n", port,sum_cal_itr);
		}
        else {
            timeout--;
            if(timeout == 0) {
			    printf("Receiver summer calibration failed at %d loop\n",avg_loop);
                return -1;
            }
            else {
                printf("!");
            }
		}        
		serdes_reset_rxd(port,0);
	}

	/* Update SUMMER calibration with average value */
	rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg14", inst_base + 14*2,ENET,port,display);
	wr_val = FIELD_RXTX_REG14_CLTE_LATCAL_MAN_PROG_SET(rd_val,xgene_phy_get_avg(sum_cal, max_loop));
	enet_sds_ind_csr_reg_wr("RXTX_REG14", inst_base + 14*2,wr_val,ENET,port,display);
	lprintf(3,"SUM 0x%x\n",xgene_phy_get_avg(sum_cal, max_loop));

	rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg14", inst_base + 14*2,ENET,port,display);
	wr_val = FIELD_RXTX_REG14_CTLE_LATCAL_MAN_ENA_SET(rd_val, 0x1); // auto=0
	enet_sds_ind_csr_reg_wr("RXTX_REG14", inst_base + 14*2,wr_val,ENET,port,display);
	lprintf(3,"Enable Manual Summer calibration\n");

	avg_loop = 0;
    timeout=50;
	while (avg_loop < max_loop) {
		/* Start latch calibration */
		rd_val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,ENET,port,display);
		wr_val = FIELD_RXTX_REG127_FORCE_LAT_CAL_START_SET(rd_val,1);
		enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, wr_val,ENET,port,display);

		/*
		 * As per PHY design spec, the latch calibration requires a minimum
		 * of 100us to complete.
		 */
		USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500

		rd_val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,ENET,port,display);
		wr_val = FIELD_RXTX_REG127_FORCE_LAT_CAL_START_SET(rd_val,0);
		enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, wr_val,ENET,port,display);

		/* check lat calib, 
		 * The lat_calib is take about 200ms to be done 
		 * after release serdes reset. 
		 * It only occured 1time
		 */
		USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500
		loop = 1000;
		do {
			val = enet_sds_ind_csr_reg_rd("rxtx_reg158", inst_base + 158*2,ENET,port,display);

			if (FIELD_RXTX_REG158_LAT_CALIB_DONE_RD(val))
				break;
			USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500

		} while (--loop > 0);

		val = enet_sds_ind_csr_reg_rd("rxtx_reg158", inst_base + 158*2,ENET,port,display);

		if (FIELD_RXTX_REG158_LAT_CALIB_DONE_RD(val)) 
			lprintf(3,"rxtx_channel%d  lat calib pass and time taken =%dms \n",port, (1000-loop)*2);
		else 
			lprintf(3,"rxtx_channel%d  lat calib failed even after %d loops\n",port, (1000-loop));

		val = enet_sds_ind_csr_reg_rd("rxtx_reg21", inst_base + 21*2,ENET,port,display);
		lat_do_itr = FIELD_RXTX_REG21_DO_LATCH_CALOUT_RD(val);
		lat_xo_itr = FIELD_RXTX_REG21_XO_LATCH_CALOUT_RD(val);
		fail_odd = FIELD_RXTX_REG21_LATCH_CAL_FAIL_ODD_RD(val);

		val = enet_sds_ind_csr_reg_rd("rxtx_reg22", inst_base + 22*2,ENET,port,display);
		lat_eo_itr = FIELD_RXTX_REG22_EO_LATCH_CALOUT_RD(val);
		lat_so_itr = FIELD_RXTX_REG22_SO_LATCH_CALOUT_RD(val);
		fail_even = FIELD_RXTX_REG22_LATCH_CAL_FAIL_EVEN_RD(val);

		val = enet_sds_ind_csr_reg_rd("rxtx_reg23", inst_base + 23*2,ENET,port,display);
		lat_de_itr = FIELD_RXTX_REG23_DE_LATCH_CALOUT_RD(val);
		lat_xe_itr = FIELD_RXTX_REG23_XE_LATCH_CALOUT_RD(val);

		val = enet_sds_ind_csr_reg_rd("rxtx_reg24", inst_base + 24*2,ENET,port,display);
		lat_ee_itr = FIELD_RXTX_REG24_EE_LATCH_CALOUT_RD(val);
		lat_se_itr = FIELD_RXTX_REG24_SE_LATCH_CALOUT_RD(val);

		/* Check for failure. If passed, sum them for averaging */
		if ((fail_even == 0 || fail_even == 1) && (fail_odd == 0 || fail_odd == 1)) {
			lat_do += lat_do_itr;
			lat_xo += lat_xo_itr;
			lat_eo += lat_eo_itr;
			lat_so += lat_so_itr;
			lat_de += lat_de_itr;
			lat_xe += lat_xe_itr;
			lat_ee += lat_ee_itr;
			lat_se += lat_se_itr;

			lprintf(3,"Iteration %d:\n", avg_loop);
			lprintf(3,"DO 0x%x XO 0x%x EO 0x%x SO 0x%x\n",lat_do_itr, lat_xo_itr, lat_eo_itr,lat_so_itr);
			lprintf(3,"DE 0x%x XE 0x%x EE 0x%x SE 0x%x\n",lat_de_itr, lat_xe_itr, lat_ee_itr,lat_se_itr);
			lprintf(3,"SUM 0x%x\n", sum_cal_itr);
			++avg_loop;
            timeout=50;
		} 
        else {
            timeout--;
            if(timeout == 0) {
			    printf("Receiver latch calibration failed at %d loop\n",avg_loop);
                return -2;
		    }
            else {
                printf("!");
            }
        }
		serdes_reset_rxd(port,0);
	}

	/* Update latch manual calibration with average value */
	val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,ENET,port,display);
	val = FIELD_RXTX_REG127_DO_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_do, max_loop));
	val = FIELD_RXTX_REG127_XO_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_xo, max_loop));
	enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, val,ENET,port,display);

	val = enet_sds_ind_csr_reg_rd("RXTX_REG128", inst_base + 128*2,ENET,port,display);
	val = FIELD_RXTX_REG128_EO_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_eo, max_loop));
	val = FIELD_RXTX_REG128_SO_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_so, max_loop));
	enet_sds_ind_csr_reg_wr("RXTX_REG128", inst_base + 128*2, val,ENET,port,display);

	val = enet_sds_ind_csr_reg_rd("RXTX_REG129", inst_base + 129*2,ENET,port,display);
	val = FIELD_RXTX_REG129_DE_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_de, max_loop));
	val = FIELD_RXTX_REG129_XE_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_xe, max_loop));
	enet_sds_ind_csr_reg_wr("RXTX_REG129", inst_base + 129*2, val,ENET,port,display);

	val = enet_sds_ind_csr_reg_rd("RXTX_REG130", inst_base + 130*2,ENET,port,display);
	val = FIELD_RXTX_REG130_EE_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_ee, max_loop));
	val = FIELD_RXTX_REG130_SE_LATCH_MANCAL_SET(val,xgene_phy_get_avg(lat_se, max_loop));
	enet_sds_ind_csr_reg_wr("RXTX_REG130", inst_base + 130*2, val,ENET,port,display);

	lprintf(3,"Average Value:\n");
	lprintf(3,"DO 0x%x XO 0x%x EO 0x%x SO 0x%x\n",
			xgene_phy_get_avg(lat_do, max_loop),
			xgene_phy_get_avg(lat_xo, max_loop),
			xgene_phy_get_avg(lat_eo, max_loop),
			xgene_phy_get_avg(lat_so, max_loop));
	lprintf(3,"DE 0x%x XE 0x%x EE 0x%x SE 0x%x\n",
			xgene_phy_get_avg(lat_de, max_loop),
			xgene_phy_get_avg(lat_xe, max_loop),
			xgene_phy_get_avg(lat_ee, max_loop),
			xgene_phy_get_avg(lat_se, max_loop));
	val = enet_sds_ind_csr_reg_rd("RXTX_REG127", inst_base + 127*2,ENET,port,display);
	val = FIELD_RXTX_REG127_LATCH_MAN_CAL_ENA_SET(val, 0x1); //auto=0
	lprintf(3,"Enable Manual Latch calibration\n");
	enet_sds_ind_csr_reg_wr("RXTX_REG127", inst_base + 127*2, val,ENET,port,display);
	USDELAY(1000); // required is 100 uSec as per above comment but we are putting more than 100 & 500

	/* Disable RX Hi-Z termination */
	val = enet_sds_ind_csr_reg_rd("RXTX_REG12", inst_base + 12*2,ENET,port,display);
	val = FIELD_RXTX_REG12_RX_DET_TERM_ENABLE_SET(val, 0);
	enet_sds_ind_csr_reg_wr("RXTX_REG12", inst_base + 12*2, val,ENET,port,display);

	/* Turn on/off DFE */
    //enet_sds_ind_csr_reg_wr("RXTX_REG28", inst_base + 28*2, 0x7,ENET,port,display);
    enet_sds_ind_csr_reg_wr("RXTX_REG28", inst_base + 28*2, 0x0,ENET,port,display); //10-09-2014 BLT Debug Jitu/Satish

	enet_sds_ind_csr_reg_wr("RXTX_REG31", inst_base + 31*2, val,ENET,port,display);

    return 0;
}

void enet_sds_rxtx_re_cfg_sata_sgmii(int port,int display){
    uint32_t inst, inst_base,data;
        	
    inst = port & 0x1;
    inst_base = 0x0400 + inst*0x0200;

    data = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2,ENET,port,display);
    data = sm_enet_set(data, 0xb, 10, 7); //   (txamp_cntl) = 0xf
    data = sm_enet_set(data, 1, 6, 6); //   (txamp_ena) = 0x1
    enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, data,ENET,port,display);    
    USDELAY(800);

    data = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2,ENET,port,display);
    data = sm_enet_set(data, 1, 14, 14);
    enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, data,ENET,port,display);
    USDELAY(800);

    data = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2,ENET,port,display);
    data = sm_enet_set(data, 0, 14, 14);
    enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, data,ENET,port,display);
    USDELAY(800);

    data = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2,ENET,port,display);
    data = sm_enet_set(data, 0, 13, 13);
    enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, data,ENET,port,display);
    USDELAY(800);

    data = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2,ENET,port,display);
    data = sm_enet_set(data, 1, 13, 13);
    enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, data,ENET,port,display);
    USDELAY(800);    

    data = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2,ENET,port,display);
    data = sm_enet_set(data, 0, 12, 12);
    enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, data,ENET,port,display);
    USDELAY(800);

    data = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2,ENET,port,display);
    data = sm_enet_set(data, 1, 12, 12);
    enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2,data,ENET,port,display);
    USDELAY(800); 
}

//-------------------------------------------------------------------------------
void qi_move_xfi_sgmii(int pqtarget, int pqstepmag, int port) {
    int currpqsign;
    int currpq;
    int step;
    int i;
    int sds2_offset;
    int vRange;
    int qinit;
    int qend;
    int qskip, newpq;
    int pqsign, pqval,data;
    uint32_t inst, inst_base;

	inst = 0;
	inst_base = 0x0400 + inst*0x0200;

	int display =0;

    printf("qi move %d, %d, \n", pqtarget, pqstepmag);
    // This function to smoothly move QI to target
    data = enet_sds_ind_csr_reg_rd("RXTX_REG126", inst_base + 126*2,XGENET,port,display);
    currpqsign = FIELD_RXTX_REG126_SIGN_QI_REG_RD(data);
    currpq = FIELD_RXTX_REG126_QI_REG_RD(data);

    if (currpqsign==1)
        currpq = currpq * -1;

    if (pqtarget >= currpq)
        step = pqstepmag;
    else
        step= pqstepmag * -1;

    //printf("currpq %d \n", currpq);
    newpq = currpq;
    for(newpq = currpq; newpq <= pqtarget; newpq = newpq +step){
        if (newpq >= 0) {
            pqsign = 0;
            pqval = newpq;
        }
        else {
            pqsign = 1;
            pqval = newpq * -1;
        }
        //WriteReg('sign_qi_reg', pqsign)
        //WriteReg('qi_reg', pqval)
        data = FIELD_RXTX_REG126_SIGN_QI_REG_SET(data, pqsign);
        data = FIELD_RXTX_REG126_QI_REG_SET(data, pqval);
        printf("qi %d sign_qi %d\n", pqval, pqsign);
        enet_sds_ind_csr_reg_wr("RXTX_REG126", inst_base + 126*2, data,XGENET,port,display);
        newpq = newpq + step;
        //printf("newpq %d \n", newpq);
    };// while (newpq < pqtarget);
}

void es_singlephase_xfi_sgmii(int vRange, int vskip, int port, int itr) {

    int vm;
    int fullFlag;
    int es_data;
    int es_data1;
    int es_data2;
    int est_data;
    int est_data1;
    int est_data2,data;
    uint32_t inst, inst_base;
    int display =0;
    int es_total;
    int est_total;
    int i;
    inst = 0;
    inst_base = 0x0400 + inst*0x0200;

    // function to sweep voltage level
    for (vm=0; vm < vRange; vm = vm + vskip) {
        es_total = 0;
        est_total = 0;
        // set vmargin to new value
        //   WriteReg('escan_vmargin',vm) 
        data = enet_sds_ind_csr_reg_rd("RXTX_REG19", inst_base + 19*2,XGENET,port,display);
        data = FIELD_RXTX_REG19_ESCAN_VMARGIN_SET(data, vm);
        enet_sds_ind_csr_reg_wr("RXTX_REG19", inst_base + 19*2, data,XGENET,port,display);

        for(i =0; i<itr; i++)
        {
            // toggle resetb
            data = enet_sds_ind_csr_reg_rd("RXTX_REG61", inst_base + 61*2,XGENET,port,display);
            data = FIELD_RXTX_REG61_EYE_ACC_RESETB_SET(data, 0);
            enet_sds_ind_csr_reg_wr("RXTX_REG61", inst_base + 61*2, data,XGENET,port,display);

            data = enet_sds_ind_csr_reg_rd("RXTX_REG61", inst_base + 61*2,XGENET,port,display);
            data = FIELD_RXTX_REG61_EYE_ACC_RESETB_SET(data, 1);
            enet_sds_ind_csr_reg_wr("RXTX_REG61", inst_base + 61*2, data,XGENET,port,display);

            // poll for data full flag
            do {
                data = enet_sds_ind_csr_reg_rd("RXTX_REG118", inst_base + 118*2,XGENET,port,display);
                fullFlag = FIELD_RXTX_REG118_ACC_FULL_FLAG_RD(data);
                //printf("waiting full flag \n");
            } while (fullFlag == 0);

            // trigger data capture
            data = enet_sds_ind_csr_reg_rd("RXTX_REG61", inst_base + 61*2,XGENET,port,display);
            data = FIELD_RXTX_REG61_EYE_MONITOR_CAPTURE_SET(data, 1);
            enet_sds_ind_csr_reg_wr("RXTX_REG61", inst_base + 61*2, data,XGENET,port,display);

            data = enet_sds_ind_csr_reg_rd("RXTX_REG61", inst_base + 61*2,XGENET,port,display);
            data = FIELD_RXTX_REG61_EYE_MONITOR_CAPTURE_SET(data, 0);
            enet_sds_ind_csr_reg_wr("RXTX_REG61", inst_base + 61*2, data,XGENET,port,display);

            // read data to string
            es_data1 = enet_sds_ind_csr_reg_rd("RXTX_REG123", inst_base + 123*2,XGENET,port,display);
            es_data2 = enet_sds_ind_csr_reg_rd("RXTX_REG124", inst_base + 124*2,XGENET,port,display);

            //es_data = es_data1*(2**16)+es_data2;
            es_data = es_data1*65536+es_data2;
            est_data1 = enet_sds_ind_csr_reg_rd("RXTX_REG161", inst_base + 161*2,XGENET,port,display);
            est_data2 = enet_sds_ind_csr_reg_rd("RXTX_REG162", inst_base + 162*2,XGENET,port,display);
            //est_data = est_data1*(2**16)+est_data2;
            est_data = est_data1*65536+est_data2;

            es_total    += es_data;
            est_total   += est_data;

        }
        printf ("es_str: %d \n", es_total);
        printf ("est_str: %d \n", est_total);
    }
}

int eyescan_sub_xfi_sgmii(int port, int itr) {
    int vRange;
    int qinit;
    int qend;
    int qskip;
    int num_of_steps;
    int increment;
    int barVal;
    int qi;
    int pqsign, pqval,data;
    uint32_t inst, inst_base;
	int display =0;

	inst = 0;
	inst_base = 0x0400 + inst*0x0200;

    vRange = 64;
    qinit = -64;
    qend = 64;
    qskip = 1;

    printf("\nCapture eye plot using eyescan for port-%d\n",port);

#if 0 // Moved this from eyescan_sub function gen_avg_val() code ==> as per Chidvilas's discussion with Poly on [28-Aug-2014]   
    data = enet_sds_ind_csr_reg_rd("RXTX_REG145", inst_base + 145*2,XGENET,port,display);
    data = FIELD_RXTX_REG145_RXVWES_LATENA_SET(data, 1);
    data = FIELD_RXTX_REG145_RXES_ENA_SET(data, 1);
    enet_sds_ind_csr_reg_wr("RXTX_REG145", inst_base + 145*2, data,XGENET,port,display);
#endif

    data = enet_sds_ind_csr_reg_rd("RXTX_REG62", inst_base + 62*2,XGENET,port,display);
    data = FIELD_RXTX_REG62_PERIOD_H1_QLATCH_SET(data, 2);
    data = FIELD_RXTX_REG62_SWITCH_H1_QLATCH_SET(data, 1);
    data = FIELD_RXTX_REG62_H1_QLATCH_SIGN_INV_SET(data, 0);
    enet_sds_ind_csr_reg_wr("RXTX_REG62", inst_base + 62*2, data,XGENET,port,display);

    data = enet_sds_ind_csr_reg_rd("RXTX_REG61", inst_base + 61*2,XGENET,port,display);
    data = FIELD_RXTX_REG61_EYE_COUNT_WIDTH_SEL_SET(data, 2);
    enet_sds_ind_csr_reg_wr("RXTX_REG61", inst_base + 61*2, data,XGENET,port,display);

    //qi_move_xfi_sgmii(qinit,2, port); // Move to qinit from current qi in step of 2

    //for qi from qinit to qend 
    printf("CHANNEL %d START \n", port);
    for (qi = qinit ; qi < qend; qi= qi+qskip) 
    {
        //qi_move_xfi_sgmii(qi,qskip, port);

        data = enet_sds_ind_csr_reg_rd("RXTX_REG126", inst_base + 126*2,XGENET,port,display);

        if(qi<0){
            pqsign = 1;
            pqval = qi * -1;
        } else {
            pqsign = 0;
            pqval = qi;
        };
        data = FIELD_RXTX_REG126_SIGN_QI_REG_SET(data, pqsign);
        data = FIELD_RXTX_REG126_QI_REG_SET(data, pqval);

        printf("qi %d sign_qi %d\n", pqval, pqsign);
        enet_sds_ind_csr_reg_wr("RXTX_REG126", inst_base + 126*2, data,XGENET,port,display);

        es_singlephase_xfi_sgmii(vRange, qskip, port, itr);
        printf("endscan \n");
    }
    //qi_move_xfi_sgmii(0,2, port);
    printf("CHANNEL %d END \n", port);

    data = enet_sds_ind_csr_reg_rd("RXTX_REG19", inst_base + 19*2,XGENET,port,display);
    data = FIELD_RXTX_REG19_ESCAN_VMARGIN_SET(data, 0);
    enet_sds_ind_csr_reg_wr("RXTX_REG19", inst_base + 19*2, data,XGENET,port,display);

    return 0;
}

void enet_sds_rxtx_re_cfg_xfi_sgmii(int port,int display) {
    uint32_t inst, inst_base,data;
        	
	inst = 0;
	inst_base = 0x0400 + inst*0x0200;

    data = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2,XGENET,port,display);
    data = sm_enet_set(data, 0xb, 10, 7); //   (txamp_cntl) = 0xf
    data = sm_enet_set(data, 1, 6, 6); //   (txamp_ena) = 0x1
    enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, data,XGENET,port,display);    
    USDELAY(800);

    data = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2,XGENET,port,display);
    data = sm_enet_set(data, 1, 14, 14);
    enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, data,XGENET,port,display);
    USDELAY(800);

    data = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2,XGENET,port,display);
    data = sm_enet_set(data, 0, 14, 14);
    enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, data,XGENET,port,display);
    USDELAY(800);

    data = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2,XGENET,port,display);
    data = sm_enet_set(data, 0, 13, 13);
    enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, data,XGENET,port,display);
    USDELAY(800);

    data = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2,XGENET,port,display);
    data = sm_enet_set(data, 1, 13, 13);
    enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, data,XGENET,port,display);
    USDELAY(800);    

    data = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2,XGENET,port,display);
    data = sm_enet_set(data, 0, 12, 12);
    enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, data,XGENET,port,display);
    USDELAY(800);

    data = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2,XGENET,port,display);
    data = sm_enet_set(data, 1, 12, 12);
    enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, data,XGENET,port,display);
    USDELAY(800); 
}

//-------------------------------------------------------------------------------
void qi_move (int pqtarget, int pqstepmag, int port) {
    int currpqsign;
    int currpq;
    int step;
    int i;
    int sds2_offset;
    int vRange;
    int qinit;
    int qend;
    int qskip, newpq;
    int pqsign, pqval,data;
    uint32_t inst, inst_base;

    //inst = 0;
    inst = port & 0x1;
    inst_base = 0x0400 + inst*0x0200;
	int display =0;

    printf("qi move %d, %d, \n", pqtarget, pqstepmag);
    // This function to smoothly move QI to target
    data = enet_sds_ind_csr_reg_rd("RXTX_REG126", inst_base + 126*2,ENET,port,display);
    currpqsign = FIELD_RXTX_REG126_SIGN_QI_REG_RD(data);
    currpq = FIELD_RXTX_REG126_QI_REG_RD(data);

    if (currpqsign==1)
        currpq = currpq * -1;

    if (pqtarget >= currpq)
        step = pqstepmag;
    else
        step= pqstepmag * -1;

    //printf("currpq %d \n", currpq);
    newpq = currpq;
    for(newpq = currpq; newpq <= pqtarget; newpq = newpq +step){
        if (newpq >= 0) {
            pqsign = 0;
            pqval = newpq;
        }
        else {
            pqsign = 1;
            pqval = newpq * -1;
        }
        //WriteReg('sign_qi_reg', pqsign)
        //WriteReg('qi_reg', pqval)
        data = FIELD_RXTX_REG126_SIGN_QI_REG_SET(data, pqsign);
        data = FIELD_RXTX_REG126_QI_REG_SET(data, pqval);
        printf("qi %d sign_qi %d\n", pqval, pqsign);
        enet_sds_ind_csr_reg_wr("RXTX_REG126", inst_base + 126*2, data,ENET,port,display);
        newpq = newpq + step;
        //printf("newpq %d \n", newpq);
    };// while (newpq < pqtarget);
}

void es_singlephase(int vRange, int vskip, int port, int itr) {

    int vm;
    int fullFlag;
    int es_data;
    int es_data1;
    int es_data2;
    int est_data;
    int est_data1;
    int est_data2,data;
    uint32_t inst, inst_base;
	int display =0;
    int es_total;
    int est_total;
    int i;
    
    //inst = 0;
    inst = port & 0x1;
    inst_base = 0x0400 + inst*0x0200;

    // function to sweep voltage level
    for (vm=0; vm < vRange; vm = vm + vskip) {
        es_total = 0;
        est_total = 0;
        // set vmargin to new value
        //   WriteReg('escan_vmargin',vm) 
        data = enet_sds_ind_csr_reg_rd("RXTX_REG19", inst_base + 19*2,ENET,port,display);
        data = FIELD_RXTX_REG19_ESCAN_VMARGIN_SET(data, vm);
        enet_sds_ind_csr_reg_wr("RXTX_REG19", inst_base + 19*2, data,ENET,port,display);

        for(i =0; i<itr; i++)
        {
            // toggle resetb
            data = enet_sds_ind_csr_reg_rd("RXTX_REG61", inst_base + 61*2,ENET,port,display);
            data = FIELD_RXTX_REG61_EYE_ACC_RESETB_SET(data, 0);
            enet_sds_ind_csr_reg_wr("RXTX_REG61", inst_base + 61*2, data,ENET,port,display);

            data = enet_sds_ind_csr_reg_rd("RXTX_REG61", inst_base + 61*2,ENET,port,display);
            data = FIELD_RXTX_REG61_EYE_ACC_RESETB_SET(data, 1);
            enet_sds_ind_csr_reg_wr("RXTX_REG61", inst_base + 61*2, data,ENET,port,display);

            // poll for data full flag
            do {
                data = enet_sds_ind_csr_reg_rd("RXTX_REG118", inst_base + 118*2,ENET,port,display);
                fullFlag = FIELD_RXTX_REG118_ACC_FULL_FLAG_RD(data);
                //printf("waiting full flag \n");
            } while (fullFlag == 0);

            // trigger data capture
            data = enet_sds_ind_csr_reg_rd("RXTX_REG61", inst_base + 61*2,ENET,port,display);
            data = FIELD_RXTX_REG61_EYE_MONITOR_CAPTURE_SET(data, 1);
            enet_sds_ind_csr_reg_wr("RXTX_REG61", inst_base + 61*2, data,ENET,port,display);

            data = enet_sds_ind_csr_reg_rd("RXTX_REG61", inst_base + 61*2,ENET,port,display);
            data = FIELD_RXTX_REG61_EYE_MONITOR_CAPTURE_SET(data, 0);
            enet_sds_ind_csr_reg_wr("RXTX_REG61", inst_base + 61*2, data,ENET,port,display);

            // read data to string
            es_data1 = enet_sds_ind_csr_reg_rd("RXTX_REG123", inst_base + 123*2,ENET,port,display);
            es_data2 = enet_sds_ind_csr_reg_rd("RXTX_REG124", inst_base + 124*2,ENET,port,display);

            //es_data = es_data1*(2**16)+es_data2;
            es_data = es_data1*65536+es_data2;
            est_data1 = enet_sds_ind_csr_reg_rd("RXTX_REG161", inst_base + 161*2,ENET,port,display);
            est_data2 = enet_sds_ind_csr_reg_rd("RXTX_REG162", inst_base + 162*2,ENET,port,display);
            //est_data = est_data1*(2**16)+est_data2;
            est_data = est_data1*65536+est_data2;

            es_total    += es_data;
            est_total   += est_data;

        }
        printf ("es_str: %d \n", es_total);
        printf ("est_str: %d \n", est_total);
    }
}

int eyescan_sub_sata_sgmii(int port, int itr) {
    int vRange;
    int qinit;
    int qend;
    int qskip;
    int num_of_steps;
    int increment;
    int barVal;
    int qi;
    int pqsign, pqval,data;
    uint32_t inst, inst_base;
	int display =0;

    //inst = 0;
    inst = port & 0x1;
    inst_base = 0x0400 + inst*0x0200;

    vRange = 64;
    qinit = -64;
    qend = 64;
    qskip = 1;

    printf("\nCapture eye plot using eyescan for port-%d\n",port);

#if 0 // Moved this from eyescan_sub function gen_avg_val() code ==> as per Chidvilas's discussion with Poly on [28-Aug-2014]   
    data = enet_sds_ind_csr_reg_rd("RXTX_REG145", inst_base + 145*2,ENET,port,display);
    data = FIELD_RXTX_REG145_RXVWES_LATENA_SET(data, 1);
    data = FIELD_RXTX_REG145_RXES_ENA_SET(data, 1);
    enet_sds_ind_csr_reg_wr("RXTX_REG145", inst_base + 145*2, data,ENET,port,display);
#endif

    data = enet_sds_ind_csr_reg_rd("RXTX_REG62", inst_base + 62*2,ENET,port,display);
    data = FIELD_RXTX_REG62_PERIOD_H1_QLATCH_SET(data, 2);
    data = FIELD_RXTX_REG62_SWITCH_H1_QLATCH_SET(data, 1);
    data = FIELD_RXTX_REG62_H1_QLATCH_SIGN_INV_SET(data, 0);
    enet_sds_ind_csr_reg_wr("RXTX_REG62", inst_base + 62*2, data,ENET,port,display);

    data = enet_sds_ind_csr_reg_rd("RXTX_REG61", inst_base + 61*2,ENET,port,display);
    data = FIELD_RXTX_REG61_EYE_COUNT_WIDTH_SEL_SET(data, 2);
    enet_sds_ind_csr_reg_wr("RXTX_REG61", inst_base + 61*2, data,ENET,port,display);

    //qi_move(qinit,2, port); // Move to qinit from current qi in step of 2

    //for qi from qinit to qend 
    printf("CHANNEL %d START \n", port);
    for (qi = qinit ; qi < qend; qi= qi+qskip) 
    {
        //qi_move(qi,qskip, port);

        data = enet_sds_ind_csr_reg_rd("RXTX_REG126", inst_base + 126*2,ENET,port,display);

        if(qi<0){
            pqsign = 1;
            pqval = qi * -1;
        } else {
            pqsign = 0;
            pqval = qi;
        };
        data = FIELD_RXTX_REG126_SIGN_QI_REG_SET(data, pqsign);
        data = FIELD_RXTX_REG126_QI_REG_SET(data, pqval);

        printf("qi %d sign_qi %d\n", pqval, pqsign);
        enet_sds_ind_csr_reg_wr("RXTX_REG126", inst_base + 126*2, data,ENET,port,display);

        es_singlephase(vRange, qskip, port, itr);
        printf("endscan \n");
    }
    //qi_move(0,2, port);
    printf("CHANNEL %d END \n", port);

    data = enet_sds_ind_csr_reg_rd("RXTX_REG19", inst_base + 19*2,ENET,port,display);
    data = FIELD_RXTX_REG19_ESCAN_VMARGIN_SET(data, 0);
    enet_sds_ind_csr_reg_wr("RXTX_REG19", inst_base + 19*2, data,ENET,port,display);

    return 0;
}

void serdes_reg_dump_dbg() {

    int inst_base_temp , port ,k , rd_reg_val , display_val,inst ;
    display_val = 0;

    printf("\n\nSATA-SGMII SERDES CMU REG Values (0x0000 to 0x0019): \n");
    printf("\t\t\tGE-0/1 \t\t\t GE-2/3");
    for(k=0; k<=19; k++) {
        printf("\nCMU_REG_%d :", k);
        for(port=0; port<=3; port+=2) {
            rd_reg_val = enet_sds_ind_csr_reg_rd("CMU_reg0", CMU + 2*k , ENET , port , display_val); 
            printf("\t[0x0000%08x]", rd_reg_val);
        }
    }
    printf("\n\n");
}


