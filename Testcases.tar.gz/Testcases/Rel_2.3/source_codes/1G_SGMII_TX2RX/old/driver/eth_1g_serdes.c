/////////////////////////////////////////////////////////////////////////////////
// SERDES config for real Koolchip
/*
  1GEthernet (SGMII)
  * We use x2 serdes and HS PLL
  * clock source is 125MHz differential clock
  * serial line data rate: 1GHz
  */
////////////////////////////////////////////////////////////////////////////////
/* md: both are defined in XFI-SGMII with same 0 & 1 value
int pll_manualcal = 0;
int man_pvt_cal = 1;
*/ 
int vco_momsel_init = 0x1b; // Anil 6/24
#include <stdio.h>
#include <common.h>
#include "eth_common.h"
#include "eth_serdes.h"
#include "sm_xxx_serdes.h"
#include "eth_1g_csr.h"
#include "sm_sata_2x_rsps.h"

#define CMU	  0x0000
////////////////////////////////////////////////////////////////////////////////
void  serdes_pdown_force_vco (int port, int display) {
    uint32_t data32;
     lprintf(8, " serdes_pdown_force_vco () \n");
     data32 = enet_sds_ind_csr_reg_rd("CMU_reg0", CMU + 2*0,ENET,port,display);
     /* data32 = FIELD_CMU_REG0_PDOWN_SET(data32, 1); */
     data32 = sm_enet_set(data32, 1, 14, 14);
     enet_sds_ind_csr_reg_wr("CMU_reg0", CMU + 2*0, data32,ENET,port,display);

     //delay(10);
     USDELAY(10);
     data32 = enet_sds_ind_csr_reg_rd("CMU_reg0", CMU + 2*0,ENET,port,display);
     data32 = sm_enet_set(data32, 0, 14, 14);
     enet_sds_ind_csr_reg_wr("CMU_reg0", CMU + 2*0, data32,ENET,port,display);

     data32 = enet_sds_ind_csr_reg_rd("CMU_reg32", CMU + 2*32,ENET,port,display);
     /* data32 = FIELD_CMU_REG32_FORCE_VCOCAL_START_SET(data32, 1); */
     data32 = sm_enet_set(data32, 1, 14, 14);
     enet_sds_ind_csr_reg_wr("CMU_reg32", CMU + 2*32, data32,ENET,port,display);

     //delay(10);
     USDELAY(10);
     //data32 = enet_sds_ind_csr_reg_rd("CMU_reg32", CMU + 2*32,ENET,port,display);
     /* data32 = FIELD_CMU_REG32_FORCE_VCOCAL_START_SET(data32, 1); */
     data32 = sm_enet_set(data32, 0, 14, 14);
     enet_sds_ind_csr_reg_wr("CMU_reg32", CMU + 2*32, data32,ENET,port,display);

     //delay(10);
     USDELAY(10);
}
void enet_sds_CMU_cfg(int port, int display){
  uint32_t wr_val, rd_val, inst, inst_base;
        	
  //////////////////////////
  // HSPLL Controls
  //////////////////////////
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg0", CMU + 2*0,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 7, 7, 5); // cal_counter_res
  enet_sds_ind_csr_reg_wr("CMU_reg0", CMU + 2*0, wr_val,ENET,port,display);
  lprintf(8, "\nCalibration mode set to %s \n", pll_manualcal ? "MANUAL" : "AUTOMATIC");
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg1", CMU + 2*1,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 1, 13, 10); // (pll_cp) = 0x1
  wr_val = sm_enet_set(wr_val, 5, 9, 5); // (pll_cp_sel) = 0x5

  wr_val = sm_enet_set(wr_val, pll_manualcal, 3, 3); // pll_manualcal set in test_util.h
  /* wr_val = sm_enet_set(wr_val, 1, 3, 3); // (pll_manualcal) = 0x1 */
  //  wr_val = sm_enet_set(wr_val, 0, 3, 3); // (pll_manualcal) = 0x1   // poly 04/16 set to auto cal
  enet_sds_ind_csr_reg_wr("CMU_reg1", CMU + 2*1, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg2", CMU + 2*2,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 0xa , 4, 1); //  (pll_lfres) = 0xa // original

  // PLL settings for 12.5MHz Ref clock  
  //wr_val = sm_enet_set(wr_val, 499, 13, 5); // (pll_fbdiv) = 61
  //wr_val = sm_enet_set(wr_val, 3, 15, 14); // (pll_refdiv) = 0

  // PLL settings for 50MHz Ref clock  
  wr_val = sm_enet_set(wr_val, 124, 13, 5); // (pll_fbdiv) = 124
  wr_val = sm_enet_set(wr_val, 1, 15, 14); // (pll_refdiv) = 0x1

  // PLL settings for 25MHz Ref clock 
  //wr_val = sm_enet_set(wr_val, 249, 13, 5); // (pll_fbdiv) = 249  Satish: SLT Intermittent Failure debug 03-09-2014
  //wr_val = sm_enet_set(wr_val, 2, 15, 14); // (pll_refdiv) = 0x2  Satish: SLT Intermittent Failure debug 03-09-2014

  enet_sds_ind_csr_reg_wr("CMU_reg2", CMU + 2*2, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg3", CMU + 2*3,ENET,port,display);
  /* wr_val = sm_enet_set(rd_val, 1, 0, 0); // (vcovarsel) = 0x1 */
  wr_val = sm_enet_set(rd_val, 7, 3, 0); // (vcovarsel) = 0x1
  wr_val = sm_enet_set(wr_val, vco_momsel_init, 9, 4); // (vco_momsel_init) = 0x15
  wr_val = sm_enet_set(wr_val, vco_momsel_init, 15, 10); // (vco_mammomsel) = 0x15
  enet_sds_ind_csr_reg_wr("CMU_reg3", CMU + 2*3, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg5", CMU + 2*5,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 3, 15, 14); // (pll_lfsmcap) = 0x3
  wr_val = sm_enet_set(wr_val, 4, 13, 12); // (pll_lfcap) = 0x3
  wr_val = sm_enet_set(wr_val, 7, 3, 1); // (pll_lock_resolution) = 0x7
  enet_sds_ind_csr_reg_wr("CMU_reg5", CMU + 2*5, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg6", CMU + 2*6,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 0, 10, 9); // (pll_vregtrim) = 0x0
  lprintf(8, "\nPVT Calibration mode set to %s \n", man_pvt_cal ? "MANUAL" : "AUTOMATIC");
  wr_val = sm_enet_set(wr_val, man_pvt_cal, 2, 2);
  enet_sds_ind_csr_reg_wr("CMU_reg6", CMU + 2*6, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg8", CMU + 2*8,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 255, 15, 8); // (tx_data_rate_ch3,2,1,0) = 0xFFFF
  enet_sds_ind_csr_reg_wr("CMU_reg8", CMU + 2*8, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg9", CMU + 2*9,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 1, 9, 7); // (tx_word_mode_ch1) = 0x1
  wr_val = sm_enet_set(wr_val, 1, 6, 4); // (tx_word_mode_ch0) = 0x1
  wr_val = sm_enet_set(wr_val, 1, 3, 3); //   (pll_post_divby2) = 0x1
  enet_sds_ind_csr_reg_wr("CMU_reg9", CMU + 2*9, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg13", CMU + 2*13,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 0xFFFF, 15, 0); //  (state_delay1,2,3,4) = 0xFFFF
  enet_sds_ind_csr_reg_wr("CMU_reg13", CMU + 2*13, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg14", CMU + 2*14,ENET,port,display);
  wr_val = sm_enet_set(wr_val, 0xFFFF, 15, 0); //  (state_delay5,6,7,8) = 0xFFFF
  enet_sds_ind_csr_reg_wr("CMU_reg14", CMU + 2*14, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,ENET,port,display);
  /* wr_val = sm_enet_set(rd_val, 1, 6, 6); // (calibration done override) = 0x1 */
  wr_val = sm_enet_set(rd_val, 0, 6, 6); // (calibration done override) = 0x1
  //wr_val = sm_enet_set(wr_val, 1, 5, 5); // (bypass_pll_lock) = 0x1
  wr_val = sm_enet_set(wr_val, 0, 5, 5); // (bypass_pll_lock) = 0x1 // Anil 6/24
  // wr_val = sm_enet_set(wr_val, 4, 4, 2); // (vcocal_wait_btw_code) = 0x4
  wr_val = sm_enet_set(wr_val, 7, 4, 2); // (vcocal_wait_btw_code) = 0x4 // Anil 6/24
  enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg30", CMU + 2*30,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 0, 3, 3); // (pcie_mode) = 0x0
  wr_val = sm_enet_set(wr_val, 3, 2, 1); // (lock_count) = 0x3
  enet_sds_ind_csr_reg_wr("CMU_reg30", CMU + 2*30, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg31", CMU + 2*31,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 0xF, 4, 0); // (los_override _ch0,1,2,3,6,7,8) = 0xF
  enet_sds_ind_csr_reg_wr("CMU_reg31", CMU + 2*31, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg32", CMU + 2*32,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 3, 2, 1); // (pvt_cal_wait_swel) = 0x3
  wr_val = sm_enet_set(wr_val, 3, 8, 7); // (iref_adj) = 0x3
  enet_sds_ind_csr_reg_wr("CMU_reg32", CMU + 2*32, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg34", CMU + 2*34,ENET,port,display);
  //  wr_val = sm_enet_set(rd_val, 0x2A2A, 15, 0); // (vco_cal_vth_lo_min/max, vco_cal_vth_hi_min/max) = 0x2A2A
  wr_val = sm_enet_set(rd_val, 0x8d27, 15, 0); // (vco_cal_vth_lo_min/max, vco_cal_vth_hi_min/max) = 0x8d27
  // wr_val = sm_enet_set(rd_val, 0x9828, 15, 0); // Anil 6/24
  /* wr_val = sm_enet_set(rd_val, 0x7c36, 15, 0); // Anil 6/24 */
  // wr_val = sm_enet_set(rd_val, 0x9c38, 15, 0); // Anil 6/24
  enet_sds_ind_csr_reg_wr("CMU_reg34", CMU + 2*34, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg37", CMU + 2*37,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 0xF, 15, 12); // (CTLE_cal_done_ovr)  = 0xF
  wr_val = sm_enet_set(wr_val, 0xF, 3, 0); //   (FT_search_done_ovr) = 0xF
  wr_val = sm_enet_set(wr_val, 0xF, 11, 8); //   (latch_cal_done_ovr) = 0xF // 04/07/2014

  enet_sds_ind_csr_reg_wr("CMU_reg37", CMU + 2*37, wr_val,ENET,port,display);
}

void enet_sds_rxtx_cfg(int port,int display){
    uint32_t wr_val, rd_val, inst, inst_base;
    int coeff=0;
    int h =0;
    ////////////////////////////////////////////////////
    for(inst = 0;inst < 2;inst++) {
        inst_base = 0x0400 + inst*0x0200;

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg147", inst_base + 147*2,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 6, 15, 0); //   (STMC_OVERRIDE) = 0x6 -> SATISH incorrect, should be 15, 0
        enet_sds_ind_csr_reg_wr("rxtx_reg147", inst_base + 147*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg0", inst_base + 0*2,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 0x10, 15, 11); //   (CTLE_EQ_HR) = 0x10
        wr_val = sm_enet_set(wr_val, 0x10, 10, 6); //   (CTLE_EQ_QR) = 0x10 // kchidvil 05/09
        // wr_val = sm_enet_set(wr_val, 0x10, 5, 1); //   (CTLE_EQ_FR) = 0x10 // kchidvil 05/09
        wr_val = sm_enet_set(wr_val, 0x16, 5, 1);  //   (CTLE_EQ_FR) = 0x16 (AC=5,DC=2) // 04/07/2014
        enet_sds_ind_csr_reg_wr("rxtx_reg0", inst_base + 0*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg1", inst_base + 1*2,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 0x7, 15, 12); //   (rxacvcm ) = 0x7
        //wr_val = sm_enet_set(wr_val, 0x0, 11, 7); //   (CTLE_EQ) = 0x09
        wr_val = sm_enet_set(wr_val, 0x10, 11, 7); //   (CTLE_EQ) = 0x10  (AC=4,DC=0)  // 04/07/2014 
        wr_val = sm_enet_set(wr_val, 0x3, 6, 5);   //   (Bias Current) = 0x3 (95%)     // 04/07/2014
        enet_sds_ind_csr_reg_wr("rxtx_reg1", inst_base + 1*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 1, 8, 8); //   (vtt_ena) = 0x1
        wr_val = sm_enet_set(wr_val, 1, 7, 6); //   (vtt_sel) = 0x1
        wr_val = sm_enet_set(wr_val, 1, 5, 5); //   (tx_fifo_ena) = 0x1 -> SATISH incorrect, should be 5,5
        enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 4*2,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 3, 15, 14); //   (TX_data_rate) = 0x3
        wr_val = sm_enet_set(wr_val, 1, 13, 11); //   (TX_word_mode) = 0x1
        enet_sds_ind_csr_reg_wr("rxtx_reg4", inst_base + 4*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg5", inst_base + 5*2,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 0, 15, 11); //   (tx_cn1) = 0x0
        //   wr_val = sm_enet_set(wr_val, 0x10, 10, 5); //   (tx_cp1) = 0x10
        wr_val = sm_enet_set(wr_val, 0, 10, 5); //   (tx_cp1) = 0xf
        wr_val = sm_enet_set(wr_val, 0, 4, 0); //   (tx_CN2) = 0x0
        enet_sds_ind_csr_reg_wr("rxtx_reg5", inst_base + 5*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 0xf, 10, 7); //   (txamp_cntl) = 0xf
        wr_val = sm_enet_set(wr_val, 1, 6, 6); //   (txamp_ena) = 0x1
        enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 7*2,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 0, 6, 6); //   (bist_ena_rx) = 0x0
        wr_val = sm_enet_set(wr_val, 1, 13, 11); // (rx_word_mode) = 0x1
        wr_val = sm_enet_set(wr_val, 3, 10, 9); //   (rx_data_rate) = 0x3 --> SATISH incorrect, should be 10:9
        enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 7*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg8", inst_base + 8*2,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 1, 14, 14); //   (CDR_Loop_ena) = 0x1
        wr_val = sm_enet_set(wr_val, 0, 11, 11); //   (cdr_bypass_rxlos) = 0x0
        wr_val = sm_enet_set(wr_val, 0, 9, 9); //   (SSC_enable) = 0x0
        wr_val = sm_enet_set(wr_val, 0, 8, 8); //   (sd_disabl) = 0x0
        wr_val = sm_enet_set(wr_val, 4, 6, 6); //   (sd_vref) = 0x4
        enet_sds_ind_csr_reg_wr("rxtx_reg8", inst_base + 8*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg11", inst_base + 11*2,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 0, 15, 11); //   (phase_adjust_limit) = 0x0
        enet_sds_ind_csr_reg_wr("rxtx_reg11", inst_base + 11*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg12", inst_base + 12*2,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 1, 13, 13); //   (Latch_off_ena) = 0x1
        wr_val = sm_enet_set(wr_val, 0, 2, 2); //   (sumos_enable) = 0x0
        wr_val = sm_enet_set(wr_val, 0, 1, 1); //   (rx_det_term_enable) = 0x0
        enet_sds_ind_csr_reg_wr("rxtx_reg12", inst_base + 12*2, wr_val,ENET,port,display);

        // TX Rate Change enable: Toggle 0-1-0
        rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU +2*16,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 0, 15, 15);
        enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 1, 15, 15);
        enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,ENET,port,display);
        wr_val = sm_enet_set(rd_val,0, 15, 15);
        enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU +2*16,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 0, 13, 13);
        enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 1, 13, 13);
        enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,ENET,port,display);
        wr_val = sm_enet_set(rd_val,0, 13, 13);
        enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU +2*16,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 0, 11, 11);
        enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 1, 11, 11);
        enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,ENET,port,display);
        wr_val = sm_enet_set(rd_val,0, 11, 11);
        enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU +2*16,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 0, 9, 9);
        enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 1, 9, 9);
        enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,ENET,port,display);
        wr_val = sm_enet_set(rd_val,0, 9, 9);
        enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

        // RX rate change enable: Toggle 0-1-0
        rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 0, 14, 14);
        enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 1, 14, 14);
        enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 0, 14, 14);
        enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 0, 12, 12);
        enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 1, 12, 12);
        enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 0, 12, 12);
        enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 0, 10, 10);
        enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 1, 10, 10);
        enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 0, 10, 10);
        enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 0, 8, 8);
        enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 1, 8, 8);
        enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 0, 8, 8);
        enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg26", inst_base + 26*2,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 0, 13, 11); //   (period_error_latch) = 0x0
        wr_val = sm_enet_set(wr_val, 1, 3, 3); //   (blwc_ena) = 0x1
        enet_sds_ind_csr_reg_wr("rxtx_reg26", inst_base + 26*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg28", inst_base + 28*2,ENET,port,display);
        //wr_val = sm_enet_set(rd_val, 7, 15, 0); //   (DFE_tap_ena) = 0x7 -> SATISH incorrect, should be 15:0
        wr_val = sm_enet_set(rd_val, 0, 15, 0); //   (DFE_tap_ena) = 0x0 -> 10-09-2014 BLT Debug Jitu/Satish
        enet_sds_ind_csr_reg_wr("rxtx_reg28", inst_base + 28*2, wr_val,ENET,port,display);


        //=================================================================================================//
        //DFE disable logic for XFI-SGMII 1G Mode Only

        // Code to freeze taps
        wr_val = enet_sds_ind_csr_reg_rd("rxtx_reg28", inst_base + 28*2,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 0x0, 15, 0); 
        enet_sds_ind_csr_reg_wr("rxtx_reg28", inst_base + 28*2, wr_val,ENET,port,display);

        //  select value 0 to be written to coefficient
        enet_sds_ind_csr_reg_wr("rxtx_reg107", inst_base + 107*2, coeff,ENET,port,display);// Coefficient value_MSB =0
        enet_sds_ind_csr_reg_wr("rxtx_reg108", inst_base + 108*2, coeff,ENET,port,display);// Coefficient value_LSB =0

        for(h=0;h<=10;h++)                                                         // 3 taps(h0,h1 & h2) selected
        {
            // Verify read before disable

            wr_val = enet_sds_ind_csr_reg_rd("rxtx_reg26", inst_base + 26*2,ENET,port,display);
            wr_val |= h<<7;	// Set  DFE_tap_select
            wr_val &= 0;	// for read set wr_ena=0 for safe side may not be required .
            enet_sds_ind_csr_reg_wr("rxtx_reg26", inst_base + 26*2, wr_val,ENET,port,display);

            lprintf(4,"** TAP Value Before Disabling DFE ** \n");

            wr_val = enet_sds_ind_csr_reg_rd("rxtx_reg105", inst_base + 105*2,ENET,port,display);
            lprintf(4,"inst %d Tap %d DFE_tap_snap_readout_msb 0x%x \n", inst, h, wr_val);

            wr_val = enet_sds_ind_csr_reg_rd("rxtx_reg106", inst_base + 106*2,ENET,port,display);
            lprintf(4,"inst %d Tap %d DFE_tap_snap_readout_lsb 0x%x \n", inst, h, wr_val);


            wr_val = enet_sds_ind_csr_reg_rd("rxtx_reg26", inst_base + 26*2,ENET,port,display);
            wr_val |= h<<7;	// Set  DFE_tap_select
            wr_val &= 1;	// for read set wr_ena=1 for safe side may not be required .
            enet_sds_ind_csr_reg_wr("rxtx_reg26", inst_base + 26*2, wr_val,ENET,port,display);

            lprintf(4," TAP Value After Disabling DFE \n");

            wr_val = enet_sds_ind_csr_reg_rd("rxtx_reg26", inst_base + 26*2,ENET,port,display);
            //value= RXTX_REG26_ DFE_TAP_WRITE_ENA_SET(value,0);   // for read set wr_ena=0 for safe side may not be required .
            wr_val &= 0;
            enet_sds_ind_csr_reg_wr("rxtx_reg26", inst_base + 26*2, wr_val,ENET,port,display);

            // Verify read after disable.
            wr_val = enet_sds_ind_csr_reg_rd("rxtx_reg105", inst_base + 105*2,ENET,port,display);  
            lprintf(4,"DFE_tap_snap_readout_msb 0x%x \n", wr_val);

            wr_val = enet_sds_ind_csr_reg_rd("rxtx_reg106", inst_base + 106*2,ENET,port,display);  
            lprintf(4, "DFE_tap_snap_readout_lsb 0x%x \n", wr_val);

        }

        //=================================================================================================//


        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg31", inst_base + 31*2,ENET,port,display);
        /* wr_val = sm_enet_set(rd_val, 0, 15, 0); //   (DFE_preset_H0) = 0x7 -> SATISH incorrect, should be 15:0 // kchidvil 05/09 */
        wr_val = sm_enet_set(rd_val, 0, 15, 0); //   (DFE_preset_H0) = 0x7 -> SATISH incorrect, should be 15:0 // kchidvil 05/09
        enet_sds_ind_csr_reg_wr("rxtx_reg31", inst_base + 31*2, wr_val,ENET,port,display);


        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg61", inst_base + 61*2,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 1, 4, 4); //   (iscan_inbert) = 0x1
        //wr_val = sm_enet_set(wr_val, 1, 13, 10); //   (SPD_sel_cdr) = 0x1
        //wr_val = sm_enet_set(wr_val, 0x7, 13, 10); //   (SPD_sel_cdr) = 0x7 10-09-2014 BLT Debug Jitu/Satish 
        //wr_val = sm_enet_set(wr_val, 0x4, 13, 10); //   (SPD_sel_cdr) = 0x3 10-09-2014 BLT Debug Jitu/Satish 
        wr_val = sm_enet_set(wr_val, 0x6, 13, 10); //   (SPD_sel_cdr) = 0x6 10-09-2014 BLT Debug Jitu/Satish 
        wr_val = sm_enet_set(wr_val, 0, 7, 6); //   (eye_count_width_sel) = 0x0
        wr_val = sm_enet_set(wr_val, 0, 3, 3); //   (LoadFrq_shift) = 0x0
        enet_sds_ind_csr_reg_wr("rxtx_reg61", inst_base + 61*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg62", inst_base + 62*2,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 0, 13, 11); //   (period_h1_qlatc) = 0x0
        enet_sds_ind_csr_reg_wr("rxtx_reg62", inst_base + 62*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg81", inst_base + 81*2,ENET,port,display);
        //wr_val = sm_enet_set(rd_val, 0xe, 15, 0); //   (mu_dfe1-9 - mu_ph1-9 ) = 0xe -> SATISH incorrect
        wr_val = sm_enet_set(rd_val, 0xe, 15, 11);
        wr_val = sm_enet_set(wr_val, 0xe, 10, 6);
        wr_val = sm_enet_set(wr_val, 0xe, 5, 1);
        enet_sds_ind_csr_reg_wr("rxtx_reg81", inst_base + 81*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg83", inst_base + 83*2,ENET,port,display);
        //wr_val = sm_enet_set(rd_val, 0xe, 15, 0); //   (mu_dfe1-9 - mu_ph1-9 ) = 0xe -> SATISH incorrect
        wr_val = sm_enet_set(rd_val, 0xe, 15, 11);
        wr_val = sm_enet_set(wr_val, 0xe, 10, 6);
        wr_val = sm_enet_set(wr_val, 0xe, 5, 1);
        enet_sds_ind_csr_reg_wr("rxtx_reg83", inst_base + 83*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg83", inst_base + 83*2,ENET,port,display);
        //wr_val = sm_enet_set(rd_val, , 15, 0); //   (mu_dfe1-9 - mu_ph1-9 ) = 0xe -> SATISH incorrect
        wr_val = sm_enet_set(rd_val, 0xe, 15, 11);
        wr_val = sm_enet_set(wr_val, 0xe, 10, 6);
        wr_val = sm_enet_set(wr_val, 0xe, 5, 1);
        enet_sds_ind_csr_reg_wr("rxtx_reg83", inst_base + 83*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg84", inst_base + 84*2,ENET,port,display);
        //wr_val = sm_enet_set(rd_val, 0xe, 15, 0); //   (mu_dfe1-9 - mu_ph1-9 ) = 0xe -> SATISH incorrect
        wr_val = sm_enet_set(rd_val, 0xe, 15, 11);
        wr_val = sm_enet_set(wr_val, 0xe, 10, 6);
        wr_val = sm_enet_set(wr_val, 0xe, 5, 1);
        enet_sds_ind_csr_reg_wr("rxtx_reg84", inst_base + 84*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg85", inst_base + 85*2,ENET,port,display);
        //wr_val = sm_enet_set(rd_val, 0xe, 15, 0); //   (mu_dfe1-9 - mu_ph1-9 ) = 0xe -> SATISH incorrect
        wr_val = sm_enet_set(rd_val, 0xe, 15, 11);
        wr_val = sm_enet_set(wr_val, 0xe, 10, 6);
        wr_val = sm_enet_set(wr_val, 0xe, 5, 1);
        enet_sds_ind_csr_reg_wr("rxtx_reg85", inst_base + 85*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg86", inst_base + 86*2,ENET,port,display);
        //wr_val = sm_enet_set(rd_val, 0xe, 15, 0); //   (mu_dfe1-9 - mu_ph1-9 ) = 0xe > SATISH incorrect
        wr_val = sm_enet_set(rd_val, 0xe, 15, 11);
        wr_val = sm_enet_set(wr_val, 0xe, 10, 6);
        wr_val = sm_enet_set(wr_val, 0xe, 5, 1);
        enet_sds_ind_csr_reg_wr("rxtx_reg86", inst_base + 86*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg87", inst_base + 87*2,ENET,port,display);
        //wr_val = sm_enet_set(rd_val, 0xe, 15, 0); //   (mu_dfe1-9 - mu_ph1-9 ) = 0xe -> SATISH incorrect
        wr_val = sm_enet_set(rd_val, 0xe, 15, 11);
        wr_val = sm_enet_set(wr_val, 0xe, 10, 6);
        wr_val = sm_enet_set(wr_val, 0xe, 5, 1);
        enet_sds_ind_csr_reg_wr("rxtx_reg87", inst_base + 87*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg88", inst_base + 88*2,ENET,port,display);
        //wr_val = sm_enet_set(rd_val, 0xe, 15, 0); //   (mu_dfe1-9 - mu_ph1-9 ) = 0xe -> SATISH incorrect
        wr_val = sm_enet_set(rd_val, 0xe, 15, 11);
        wr_val = sm_enet_set(wr_val, 0xe, 10, 6);
        wr_val = sm_enet_set(wr_val, 0xe, 5, 1);
        enet_sds_ind_csr_reg_wr("rxtx_reg88", inst_base + 88*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg89", inst_base + 89*2,ENET,port,display);
        //wr_val = sm_enet_set(rd_val, 0xe, 15, 0); //   (mu_dfe1-9 - mu_ph1-9 ) = 0xe -> SATISH incorrect
        wr_val = sm_enet_set(rd_val, 0xe, 15, 11);
        wr_val = sm_enet_set(wr_val, 0xe, 10, 6);
        wr_val = sm_enet_set(wr_val, 0xe, 5, 1);
        enet_sds_ind_csr_reg_wr("rxtx_reg89", inst_base + 89*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg96", inst_base + 96*2,ENET,port,display);
        //wr_val = sm_enet_set(rd_val, 0x10, 15, 0); //   (mu_freq1-9 ) = 0x10 -> SATISH incorrect
        wr_val = sm_enet_set(rd_val, 0x10, 15, 11);
        wr_val = sm_enet_set(wr_val, 0x10, 10, 6);
        wr_val = sm_enet_set(wr_val, 0x10, 5, 1);
        enet_sds_ind_csr_reg_wr("rxtx_reg96", inst_base + 96*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg97", inst_base + 97*2,ENET,port,display);
        //wr_val = sm_enet_set(rd_val, 0x10, 15, 0); //   (mu_freq1-9 ) = 0x10 -> SATISH incorrect
        wr_val = sm_enet_set(rd_val, 0x10, 15, 11);
        wr_val = sm_enet_set(wr_val, 0x10, 10, 6);
        wr_val = sm_enet_set(wr_val, 0x10, 5, 1);
        enet_sds_ind_csr_reg_wr("rxtx_reg97", inst_base + 97*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg98", inst_base + 98*2,ENET,port,display);
        //wr_val = sm_enet_set(rd_val, 0x10, 15, 0); //   (mu_freq1-9 ) = 0x10 -> SATISH incorrect
        wr_val = sm_enet_set(rd_val, 0x10, 15, 11);
        wr_val = sm_enet_set(wr_val, 0x10, 10, 6);
        wr_val = sm_enet_set(wr_val, 0x10, 5, 1);
        enet_sds_ind_csr_reg_wr("rxtx_reg98", inst_base + 98*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg99", inst_base + 99*2,ENET,port,display);
        //wr_val = sm_enet_set(rd_val, 7, 15, 0); //   (mu_phase1-9) = 0x7 -> SATISH incorrect
        wr_val = sm_enet_set(rd_val, 7, 15, 11);
        wr_val = sm_enet_set(wr_val, 7, 10, 6);
        wr_val = sm_enet_set(wr_val, 7, 5, 1);
        enet_sds_ind_csr_reg_wr("rxtx_reg99", inst_base + 99*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg100", inst_base + 100*2,ENET,port,display);
        //wr_val = sm_enet_set(rd_val, 7, 15, 0); //   (mu_phase1-9) = 0x7 -> SATISH incorrect
        wr_val = sm_enet_set(rd_val, 7, 15, 11);
        wr_val = sm_enet_set(wr_val, 7, 10, 6);
        wr_val = sm_enet_set(wr_val, 7, 5, 1);
        enet_sds_ind_csr_reg_wr("rxtx_reg100", inst_base + 100*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg101", inst_base + 101*2,ENET,port,display);
        //wr_val = sm_enet_set(rd_val, 7, 15, 0); //   (mu_phase1-9) = 0x7 -> SATISH incorrect
        wr_val = sm_enet_set(rd_val, 7, 15, 11);
        wr_val = sm_enet_set(wr_val, 7, 10, 6);
        wr_val = sm_enet_set(wr_val, 7, 5, 1);
        enet_sds_ind_csr_reg_wr("rxtx_reg101", inst_base + 101*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg102", inst_base + 102*2,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 0, 6, 5); //  (freqloop_limit) = 0x0 -> SATISH (incorrect field, should be 6,5)
        enet_sds_ind_csr_reg_wr("rxtx_reg102", inst_base + 102*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg125", inst_base + 125*2,ENET,port,display);
        //wr_val = sm_enet_set(rd_val, 0x0, 15, 3); //   (pq_reg) = 0x0
        //wr_val = sm_enet_set(rd_val, 0x8, 15, 9); //   (pq_reg) = 0x8 (programmable PQ skew) // 04/07/2014
        wr_val = sm_enet_set(rd_val, 0x0, 15, 9); //   (pq_reg) = 0x0 10-09-2014 BLT Debug Jitu/Satish
        wr_val = sm_enet_set(wr_val, 0x0, 8, 8); //   (sign_pq) = 0x0 
        wr_val = sm_enet_set(wr_val, 1, 1, 1); //   (phz_manual) = 0x1
        enet_sds_ind_csr_reg_wr("rxtx_reg125", inst_base + 125*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 0, 3, 3); //   (latch_man_cal_ena) = 0x0 -> SATISH (incorrect field 1,1, should be 3,3)
        enet_sds_ind_csr_reg_wr("rxtx_reg127", inst_base + 127*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg128", inst_base + 128*2,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 2, 3, 2); //   (latch_cal_wait_sel) = 0x2 -> SATISH (incorrect field 1,1 should be 3,2)
        enet_sds_ind_csr_reg_wr("rxtx_reg128", inst_base + 128*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg145", inst_base + 145*2,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 3, 15, 14); //   (rxdfe_config) = 0x3
        wr_val = sm_enet_set(wr_val, 0, 0, 0); //   (tx_idle_sata) = 0x0 --> SATISH (incorrect comment)
        enet_sds_ind_csr_reg_wr("rxtx_reg145", inst_base + 145*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg148", inst_base + 148*2,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 0xffff, 15, 0); // (rx_bist_word_cnt_0) = 0xffff
        enet_sds_ind_csr_reg_wr("rxtx_reg148", inst_base + 148*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg149", inst_base + 149*2,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 0xffff, 15, 0); // (rx_bist_word_cnt_1) = 0xffff
        enet_sds_ind_csr_reg_wr("rxtx_reg149", inst_base + 149*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg150", inst_base + 150*2,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 0xffff, 15, 0); // (rx_bist_word_cnt_2) = 0xffff
        enet_sds_ind_csr_reg_wr("rxtx_reg150", inst_base + 150*2, wr_val,ENET,port,display);

        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg151", inst_base + 151*2,ENET,port,display);
        wr_val = sm_enet_set(rd_val, 0xffff, 15, 0); // (rx_bist_word_cnt_3) = 0xffff
        enet_sds_ind_csr_reg_wr("rxtx_reg151", inst_base + 151*2, wr_val,ENET,port,display);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Serdes programming
////////////////////////////////////////////////////////////////////////////////
void sm_enet_module_program_all_regs(int port, int display) {
  enet_sds_CMU_cfg(port, display);
  enet_sds_rxtx_cfg(port, display);
  return;
}

////////////////////////////////////////////////////////////////////////////////
// Enable Clock macro in Serdes, 100MHz reference clock
// 100MHz differential and single ended clock outputs

void serdes_clkmacro(int port){
  uint32_t 	wr_val, rd_val, loop;
  uint32_t 	clkmacro_pll_ready, clkmacro_pll_lock;

  printf("C> ======================================================================= \n");
  printf("C> serdes_clkmacro()\n");

  int display = 0;
  rd_val = eth_rd(SM_SATA_ENET_SDS_CSR_REGS_SATA_ENET_CLK_MACRO_REG__ADDR,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 0x3, 20, 12); //FBDiv
  wr_val = sm_enet_set(wr_val, 0x3, 22, 21); // RefDiv
  eth_wr(SM_SATA_ENET_SDS_CSR_REGS_SATA_ENET_CLK_MACRO_REG__ADDR, wr_val,ENET,port,display);

  rd_val = eth_rd(SM_SATA_ENET_SDS_CSR_REGS_SATA_ENET_CLK_MACRO_REG__ADDR,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 1, 0, 0); //i_reset_b
  eth_wr(SM_SATA_ENET_SDS_CSR_REGS_SATA_ENET_CLK_MACRO_REG__ADDR, wr_val,ENET,port,display);

  printf("INIT_SERDES : Check CLKMACRO PLL Ready/LOCK\n");
  //delay(10);
  USDELAY(10);
  loop = 1000;
  clkmacro_pll_ready = 0;
  while (clkmacro_pll_ready == 0) {
    rd_val = eth_rd(SM_SATA_ENET_SDS_CSR_REGS_SATA_ENET_CLK_MACRO_REG__ADDR,ENET,port,display);
    clkmacro_pll_ready = (rd_val >> 31) & 0x1;
    clkmacro_pll_lock = (rd_val >> 30) & 0x1;

    if (loop == 0)
      break;
    loop--;
  }

  printf("INIT_SERDES : CLKMACROPLL is %sREADY\n", clkmacro_pll_ready ? "" : "not ");
  printf("INIT_SERDES : CLKMACROPLL %sLOCKed\n", clkmacro_pll_lock ? "" : "not ");
}


void serdes_reset_rxd_rxa (int port, int display) {
  unsigned int  wr_val, rd_val;
  int inst_base;
  if(port == 0 || port == 2) {
    inst_base = 0x0400;
    // printf (" CH0 RX Reset Digital ...\n\r");
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,ENET,port,display);
    wr_val = sm_enet_set(rd_val, 0, 8, 8); // digital reset == 1'b0
    enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,ENET,port,display);

    inst_base = 0x0400;
    // printf (" CH0 RX Reset Analog ...\n\r");
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,ENET,port,display);
    wr_val = sm_enet_set(rd_val, 0, 7, 7); // analog reset == 1'b0
    enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,ENET,port,display);
  } else {
    inst_base = 0x0600;
    // printf (" CH1 RX Reset Digital ...\n\r");
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,ENET,port,display);
    wr_val = sm_enet_set(rd_val, 0, 8, 8); // digital reset == 1'b0
    enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,ENET,port,display);

    inst_base = 0x0600;
    // printf (" CH1 RX Reset Analog ...\n\r");
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,ENET,port,display);
    wr_val = sm_enet_set(rd_val, 0, 7, 7); // analog reset == 1'b0
    enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,ENET,port,display);
  }

  // Remove analog reset first, followed by removing digital reset
  //delay(10);
  USDELAY(10);

  if(port == 0 || port == 2) {
    inst_base = 0x0400;
    // printf (" CH0 RX Remove Reset Analog ...\n\r");
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,ENET,port,display);
    wr_val = sm_enet_set(rd_val, 1, 7, 7); // analog reset == 1'b1
    enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,ENET,port,display);

    //delay(10);
    USDELAY(10);

    inst_base = 0x0400;
    // printf (" CH0 RX Remove Reset Digital ...\n\r");
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,ENET,port,display);
    wr_val = sm_enet_set(rd_val, 1, 8, 8); // digital reset == 1'b1
    enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,ENET,port,display);
  } else {
    inst_base = 0x0600;
    // printf (" CH1 RX Remove Reset Analog ...\n\r");
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,ENET,port,display);
    wr_val = sm_enet_set(rd_val, 1, 7, 7); // analog reset == 1'b1
    enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,ENET,port,display);

    //delay(10);
    USDELAY(10);

    inst_base = 0x0600;
    // printf (" CH1 RX Remove Reset Digital ...\n\r");
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,ENET,port,display);
    wr_val = sm_enet_set(rd_val, 1, 8, 8); // digital reset == 1'b1
    enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,ENET,port,display);
  }

  //delay(10);
  USDELAY(10);
}

void serdes_reset_rxd (int port, int display) {
  unsigned int  wr_val, rd_val;
  int inst_base;
  if(port == 0 || port == 2) {
    inst_base = 0x0400;
    // printf (" CH0 RX Reset Digital ...\n\r");
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,ENET,port,display);
    wr_val = sm_enet_set(rd_val, 0, 8, 8); // digital reset == 1'b0
    enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,ENET,port,display);
  } else {
    inst_base = 0x0600;
    // printf (" CH1 RX Reset Digital ...\n\r");
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,ENET,port,display);
    wr_val = sm_enet_set(rd_val, 0, 8, 8); // digital reset == 1'b0
    enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,ENET,port,display);
  }

  // Remove analog reset first, followed by removing digital reset
  //delay(10);
  USDELAY(10);

  if(port == 0 || port == 2) {
    inst_base = 0x0400;
    // printf (" CH0 RX Remove Reset Digital ...\n\r");
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,ENET,port,display);
    wr_val = sm_enet_set(rd_val, 1, 8, 8); // digital reset == 1'b1
    enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,ENET,port,display);
  } else {
    inst_base = 0x0600;
    // printf (" CH1 RX Remove Reset Digital ...\n\r");
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,ENET,port,display);
    wr_val = sm_enet_set(rd_val, 1, 8, 8); // digital reset == 1'b1
    enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,ENET,port,display);
  }

  //delay(10);
  USDELAY(10);
}

void serdes_reset_rxa (int port) {
  unsigned int  wr_val, rd_val;
  int inst_base;
  int display = 0;
  if(port == 0 || port == 2){
    inst_base = 0x0400;
    // printf (" CH0 RX Reset Analog ...\n\r");
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,ENET,port,display);
    wr_val = sm_enet_set(rd_val, 0, 7, 7); // analog reset == 1'b0
    enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,ENET,port,display);
  } else {
    inst_base = 0x0600;
    // printf (" CH1 RX Reset Analog ...\n\r");
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,ENET,port,display);
    wr_val = sm_enet_set(rd_val, 0, 7, 7); // analog reset == 1'b0
    enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,ENET,port,display);
  }

  //delay(10);
  USDELAY(10);

  if(port == 0 || port == 2) {
    inst_base = 0x0400;
    // printf (" CH0 RX Remove Reset Analog ...\n\r");
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,ENET,port,display);
    wr_val = sm_enet_set(rd_val, 1, 7, 7); // analog reset == 1'b1
    enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,ENET,port,display);
  } else {
    inst_base = 0x0600;
    // printf (" CH1 RX Remove Reset Analog ...\n\r");
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,ENET,port,display);
    wr_val = sm_enet_set(rd_val, 1, 7, 7); // analog reset == 1'b1
    enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,ENET,port,display);
  }

  //delay(10);
  USDELAY(10);
}

void force_lat_summer_cal (int eth_type, int port, int display) {

  uint32_t inst, inst_base;
  unsigned int data32 = 0;
  unsigned int  wr_val, rd_val;
  int summ_cal;
    inst = port & 0x1;
    inst_base = 0x0400 + inst*0x0200;

#if 0
  //printf ("force_lat_summer_cal() =====> FORCING LATCH/SUMMER CALIBRATION\n\r");
// Enable RX Hi-Z termination enable
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg12", inst_base + 12*2,eth_type,port,display);
    wr_val = sm_enet_set(rd_val,1, 1, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg12", inst_base + 12*2, wr_val,eth_type,port,display);
   // Turn off DFE 
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg28", inst_base + 28*2,eth_type,port,display);
   wr_val = sm_enet_set(rd_val, 0x0, 15, 0); 
   enet_sds_ind_csr_reg_wr("rxtx_reg28", inst_base + 28*2, wr_val,eth_type,port,display);
   // DFE Presets to zero 
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg31", inst_base + 31*2,eth_type,port,display);
   wr_val = sm_enet_set(rd_val, 0x0, 15, 0); 
   enet_sds_ind_csr_reg_wr("rxtx_reg31", inst_base + 31*2, wr_val,eth_type,port,display);
#endif


   // SUMMer calib 1
    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2, eth_type, port, display);
    data32 = sm_enet_set(data32, 1, 1, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, data32, eth_type, port, display);
    //delay(400);
    USDELAY(400);
    // SUMMer calib 0
    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2, eth_type, port, display);
    data32 = sm_enet_set(data32, 0, 1, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, data32, eth_type, port, display);
    //delay(400);
    USDELAY(400);
   // Latch calib 1
    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2, eth_type, port, display);
    data32 = sm_enet_set(data32, 1, 2, 2);
    enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, data32, eth_type, port, display);
    //delay(400);
    USDELAY(400);
   // Latch calib 0
    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2, eth_type, port, display);
    data32 = sm_enet_set(data32, 0, 2, 2);
    enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, data32, eth_type, port, display);
    //delay(400);
    USDELAY(400);

#if 0
   // Turn on DFE 
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg28", inst_base + 28*2,eth_type,port,display);
   wr_val = sm_enet_set(rd_val,0x7, 15, 0); 
   enet_sds_ind_csr_reg_wr("rxtx_reg28", inst_base + 28*2, wr_val,eth_type,port,display);
   // DFE Presets to 0x2a00(default)
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg31", inst_base + 31*2,eth_type,port,display);
   wr_val = sm_enet_set(rd_val, 0x2a00, 15, 0); 
   enet_sds_ind_csr_reg_wr("rxtx_reg31", inst_base + 31*2, wr_val,eth_type,port,display);
   // Disable RX Hi-Z termination enable
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg12", inst_base + 12*2,eth_type,port,display);
   wr_val = sm_enet_set(rd_val,0, 1, 1);
   enet_sds_ind_csr_reg_wr("rxtx_reg12", inst_base + 12*2, wr_val,eth_type,port,display);
    delay(1000);
   data32 = enet_sds_ind_csr_reg_rd("rxtx_reg121", inst_base + 121*2, eth_type, port, display);
#endif

}

void serdes_calib(int port, int display){
  unsigned int rd_val, wr_val; 
  int inst_base;

  // ********************
  // TERM CALIBRATION CH0 
  // ********************
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 0xd, 14, 8); //   (pvt_code_r2a)  =0x0d
  wr_val = sm_enet_set(wr_val, 0, 7, 5); //   (reserved)  =0x0
  enet_sds_ind_csr_reg_wr("CMU_reg17", CMU + 2*17, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 1, 15, 15); //   (pvt_term_man_ena)  =0x1
  enet_sds_ind_csr_reg_wr("CMU_reg17", CMU + 2*17, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 0, 15, 15); //   (pvt_term_man_ena)  =0x0
  enet_sds_ind_csr_reg_wr("CMU_reg17", CMU + 2*17, wr_val,ENET,port,display);
  // ********************
  // TERM CALIBRATION CH1 
  // ********************
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 0xd, 14, 8); //   (pvt_code_r2a)  =0x0d
  wr_val = sm_enet_set(wr_val, 1, 7, 5); //   (reserved)  =0x0
  // wr_val = sm_enet_set(wr_val, 1, 15, 15); //   (pvt_term_man_ena)  =0x1
  enet_sds_ind_csr_reg_wr("CMU_reg17", CMU + 2*17, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 1, 15, 15); //   (pvt_term_man_ena)  =0x1
  enet_sds_ind_csr_reg_wr("CMU_reg17", CMU + 2*17, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 0, 15, 15); //   (pvt_term_man_ena)  =0x0
  enet_sds_ind_csr_reg_wr("CMU_reg17", CMU + 2*17, wr_val,ENET,port,display);


  // *********************
  // DOWN CALIBRATION CH0
  // *********************
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 0x26, 14, 8); //   (pvt_code_r2a)  =0x26
  wr_val = sm_enet_set(wr_val, 0, 7, 5); //   (reserved)  =0x0
  enet_sds_ind_csr_reg_wr("CMU_reg17", CMU + 2*17, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 1, 0, 0); //   (pvt_dn_man_ena)  =0x1
  enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 0, 0, 0); //   (pvt_dn_man_ena)  =0x0
  enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);
  // *********************
  // DOWN CALIBRATION CH1
  // *********************
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 0x26, 14, 8); //   (pvt_code_r2a)  =0x26
  wr_val = sm_enet_set(wr_val, 1, 7, 5); //   (reserved)  =0x0
  enet_sds_ind_csr_reg_wr("CMU_reg17", CMU + 2*17, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 1, 0, 0); //   (pvt_dn_man_ena)  =0x1
  enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 0, 0, 0); //   (pvt_dn_man_ena)  =0x0
  enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);
  // *********************
  // UP CALIBRATION CH0
  // *********************
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 0x28, 14, 8); //   (pvt_code_r2a)  =0x26
  wr_val = sm_enet_set(wr_val, 0, 7, 5); //   (reserved)  =0x0
  enet_sds_ind_csr_reg_wr("CMU_reg17", CMU + 2*17, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 1, 1, 1); //   (pvt_up_man_ena)  =0x1
  enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 0, 0, 0); //   (pvt_up_man_ena)  =0x0
  enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

  // *********************
  // UP CALIBRATION CH0
  // *********************
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 0x28, 14, 8); //   (pvt_code_r2a)  =0x26
  wr_val = sm_enet_set(wr_val, 1, 7, 5); //   (reserved)  =0x0
  enet_sds_ind_csr_reg_wr("CMU_reg17", CMU + 2*17, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 1, 1, 1); //   (pvt_up_man_ena)  =0x1
  enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 0, 0, 0); //   (pvt_up_man_ena)  =0x0
  enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,ENET,port,display);

  // ***************************
  // SUMMER CALIBRATION CH0/CH1
  // ***************************

  inst_base = 0x0400;
  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg14", inst_base + 14*2,ENET,port,display);
  /* wr_val = sm_enet_set(rd_val, 0xe, 5, 0); //   (clte_latcal_man_prog) = 0xe */
  wr_val = sm_enet_set(rd_val, 0x10, 5, 0); //   (clte_latcal_man_prog) = 0xe
  wr_val = sm_enet_set(wr_val, 0, 6, 6); //   (clte_latcal_man_ena)  = 0x1
  enet_sds_ind_csr_reg_wr("rxtx_reg14",inst_base + 14*2, wr_val,ENET,port,display);

  inst_base = 0x0600;
  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg14", inst_base + 14*2,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 0xe, 5, 0); //   (clte_latcal_man_prog) = 0xe
  wr_val = sm_enet_set(wr_val, 0, 6, 6); //   (clte_latcal_man_ena)  = 0x1
  enet_sds_ind_csr_reg_wr("rxtx_reg14",inst_base + 14*2, wr_val,ENET,port,display);

  // SUMMer calib toggle
  inst_base = 0x0400;
  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 1, 1, 1); //   (force_sum_cal_start)  = 0x1 -> SATISH incorrect, should be 2,2
  enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 0, 1, 1); //   (force_sum_cal_start)  = 0x0 -> SATISH incorrect, should be 2,2
  enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, wr_val,ENET,port,display);

  inst_base = 0x0600;
  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 1, 1, 1); //   (force_sum_cal_start)  = 0x1 -> SATISH incorrect, should be 2,2
  enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 0, 1, 1); //   (force_sum_cal_start)  = 0x0 -> SATISH incorrect, should be 2,2
  enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, wr_val,ENET,port,display);

  // latch calib toggle
  inst_base = 0x0400;
  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 1, 2, 2); //   (force_lat_cal_start)  = 0x1 -> SATISH incorrect, should be 2,2
  enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 0, 2, 2); //   (force_lat_cal_start)  = 0x0 -> SATISH incorrect, should be 2,2
  enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, wr_val,ENET,port,display);

  inst_base = 0x0600;
  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 1, 2, 2); //   (force_lat_cal_start)  = 0x1 -> SATISH incorrect, should be 2,2
  enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 0, 2, 2); //   (force_lat_cal_start)  = 0x0 -> SATISH incorrect, should be 2,2
  enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, wr_val,ENET,port,display);

  inst_base = 0x0400;
  //enet_sds_ind_csr_reg_wr("rxtx_reg28", inst_base + 28*2, 0x7,ENET,port,display);
  enet_sds_ind_csr_reg_wr("rxtx_reg28", inst_base + 28*2, 0x0,ENET,port,display);       //10-09-2014 BLT Debug Jitu/Satish
  enet_sds_ind_csr_reg_wr("rxtx_reg31", inst_base + 31*2, 0x2a00,ENET,port,display);
  inst_base = 0x0600;
  //enet_sds_ind_csr_reg_wr("rxtx_reg28", inst_base + 28*2, 0x7,ENET,port,display);
  enet_sds_ind_csr_reg_wr("rxtx_reg28", inst_base + 28*2, 0x0,ENET,port,display);       //10-09-2014 BLT Debug Jitu/Satish
  enet_sds_ind_csr_reg_wr("rxtx_reg31", inst_base + 31*2, 0x2a00,ENET,port,display);

  delay(10);
  USDELAY(10);
}

////////////////////////////////////////////////////////////////////////////////
// refclk = 0 - External differential clk
// refclk = 1 - Internal single ended (cmos) clk
// refclk = 2 - Internal differential clk

int sm_enet_module_init_enet_serdes(int intf, uint32_t refclk, uint32_t tx2rx_serdes_lb) {
  uint32_t 	wr_val, rd_val, loop, data, serdes_enet_sel;
  uint32_t 	pll_ready, pll_lock, vco_calibration, tx_ready, rx_ready, rx_clk_inv;
  uint32_t 	refclksel, refclk_cmos_sel;
  uint32_t        inst, inst_base;
  uint32_t        data32;
  
  int port = intf;
  int display = 0;
  lprintf(8, "C> ======================================================================= \n");
  lprintf(8, "C> sm_enet_module_init_enet_serdes()\n");

  // select Ethernet from bus mux (1=Ethernet	0=SATA)
  serdes_enet_sel = 1;
  lprintf(8, "INIT_SERDES : serdes_enet_sel = 0x%0x\n", serdes_enet_sel);
  wr_val = FIELD_SATA_ENET_CONFIG_REG_CFG_SATA_ENET_SELECT_WR(serdes_enet_sel);
  eth_wr(SM_SATA_ENET_COMMON_CSR_SATA_ENET_CONFIG_REG__ADDR, wr_val,ENET,port,display);

  lprintf(8, "INIT_SERDES : ENET using -- HSPLL\n");
  lprintf(8, "INIT_SERDES : REFCLK using -- %s\n",	(refclk == 0) ? "External differential clk" : 
	 (refclk == 1) ? "Internal single ended (cmos) clk" :
	 "Internal differential clk");

  if(refclk != 0)
    //serdes_clkmacro(port); // enable clock macro in serdes - used in internal ref clock mode
    kc_macro_cfg(port); // enable clock macro in serdes - used in internal ref clock mode

  refclksel = (refclk >> 1) & 1;
  refclk_cmos_sel = refclk & 1;

  // Reset i_hresetb and Assert main serdes reset -  i_resetb 
  lprintf(8, "INIT_SERDES : assert all reset\n");
  // SATA_ENET_SDS_RST_CTL
  //eth_wr(SM_SATA_ENET_SDS_CSR_REGS_SATA_ENET_SDS_RST_CTL__ADDR, 0x0,ENET,port,display);
  eth_wr(SM_SATA_ENET_SDS_CSR_REGS_SATA_ENET_SDS_RST_CTL__ADDR, 0x20,ENET,port,display); // as per SATA
  eth_wr(SM_SATA_ENET_SDS_CSR_REGS_SATA_ENET_SDS_RST_CTL__ADDR, 0xDE,ENET,port,display); // as per SATA

  write( 0x17001398,0x001E1E1E); // Give control to Slave MDIO
  data32 = read(0x17001398);
  lprintf(8, " READ MPA_MDIO_IOCTL : 0x%08x\n", data32);
	
  // set cfg_i_customer_pin_mode = 0, as all register are directly programmed through indirect programming
  eth_wr(SM_SATA_ENET_SDS_CSR_REGS_SATA_ENET_SDS_CTL0__ADDR, 0,ENET,port,display); 

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg12", CMU + 2*12,ENET,port,display);
  wr_val = sm_enet_set(rd_val, 2, 7, 4); // Txready delay setting
  enet_sds_ind_csr_reg_wr("CMU_reg12", CMU + 2*12, wr_val,ENET,port,display);

  lprintf(8, "INIT_SERDES : Config Ref Clock\n");
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg0", CMU + 2*0,ENET,port,display);
  wr_val = sm_enet_set(rd_val, refclksel, 13, 13);
  enet_sds_ind_csr_reg_wr("CMU_reg0", CMU + 2*0, wr_val,ENET,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg1", CMU + 2*1,ENET,port,display);
  wr_val = sm_enet_set(rd_val, refclk_cmos_sel, 0, 0);
  enet_sds_ind_csr_reg_wr("CMU_reg1", CMU + 2*1, wr_val,ENET,port,display);


  //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  // This function programs the serdes as per KC_serdes_40nm_setting_0v26.xls
  sm_enet_module_program_all_regs(port,display);

#ifdef CONFIG_SDS_SERDES_RX_CLK_INV
  rx_clk_inv = 1;
#else 
  rx_clk_inv = 0;
#endif   

  if(rx_clk_inv) {
    lprintf(8, "INIT_SERDES : Enable RXCLK Inversion.");
    for (inst = 0; inst < 2;  inst++) {
      lprintf(8, "INIT_SERDES : RXTX Inst %x\n", inst);
      inst_base = 0x0400 + inst*0x0200;
      rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg13", inst_base + 0xD*2,ENET,port,display);
      wr_val = sm_enet_set(rd_val, 1, 13, 13);
      enet_sds_ind_csr_reg_wr("rxtx_reg13",  inst_base + 0xD*2, wr_val,ENET,port,display);
    } 
  }

  if (tx2rx_serdes_lb) {
    lprintf(4,"INIT_SERDES : SERDES Tx2Rx Loopback Enable\n");
    for (inst = 0; inst < 2;  inst++) {
      lprintf(8, "INIT_SERDES : RXTX Inst %x\n", inst);
      inst_base = 0x0400 + inst*0x0200;
      rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,ENET,port,display);
      wr_val = sm_enet_set(rd_val, 1, 6, 6);
      enet_sds_ind_csr_reg_wr("rxtx_reg4",  inst_base + 0x4*2, wr_val,ENET,port,display);

      rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,ENET,port,display);
      wr_val = sm_enet_set(rd_val, 1, 14, 14);
      enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,ENET,port,display);
    }
  }
  else {
    lprintf(4,"INIT_SERDES : SERDES Tx2Rx Loopback Disable\n");
    for (inst = 0; inst < 2;  inst++) {
      lprintf(8, "INIT_SERDES : RXTX Inst %x\n", inst);
      inst_base = 0x0400 + inst*0x0200;
      rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,ENET,port,display);
      wr_val = sm_enet_set(rd_val, 0, 6, 6);
      enet_sds_ind_csr_reg_wr("rxtx_reg4",  inst_base + 0x4*2, wr_val,ENET,port,display);

      rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,ENET,port,display);
      wr_val = sm_enet_set(rd_val, 0, 14, 14);
      enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,ENET,port,display);
    }
  }

  int rx2tx_serdes_lb = 0;
  if (rx2tx_serdes_lb) {
    lprintf(4, "INIT_SERDES : SERDES Rx2Tx Loopback\n");
    for (inst = 0; inst < 2;  inst++) {
      printf("INIT_SERDES : RXTX Inst %x\n", inst);
      inst_base = 0x0400 + inst*0x0200;
      rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg8", inst_base + 0x8*2,ENET,port,display);
      wr_val = sm_enet_set(rd_val, 1, 15, 15); //rxtx_rev_par_lpbk
      enet_sds_ind_csr_reg_wr("rxtx_reg8",  inst_base + 0x8*2, wr_val,ENET,port,display);
    }
  }

  // Releasae i_resetb
  lprintf(8, "INIT_SERDES : de-assert all reset\n");
  // SATA_ENET_SDS_RST_CTL
  wr_val = 0xDF;
  eth_wr(SM_SATA_ENET_SDS_CSR_REGS_SATA_ENET_SDS_RST_CTL__ADDR, wr_val,ENET,port,display);

  // Added by Anil - taken from SATA
  if(man_pvt_cal)
    serdes_calib(port, display);

  // port = intf + 0x0;
  // serdes_reset_rxd_rxa(port, display);
  // port = intf + 0x1;
  // serdes_reset_rxd_rxa(port, display);
  // 
  // port = intf;

  lprintf(8, "INIT_SERDES : Check PLL Ready/LOCK and VCO Calibration status\n\n");
  loop = 10;
  pll_ready = 0;
  while (pll_ready == 0) {
      
    rd_val = eth_rd(SM_SATA_ENET_SDS_CSR_REGS_SATA_ENET_SDS_CMU_STATUS0__ADDR,ENET,port,display);
    pll_ready = FIELD_SATA_ENET_SDS_CMU_STATUS0_CFG_CMU_O_PLL_READY_RD(rd_val);
    pll_lock = FIELD_SATA_ENET_SDS_CMU_STATUS0_CFG_CMU_O_PLL_LOCK_RD(rd_val);
    vco_calibration = FIELD_SATA_ENET_SDS_CMU_STATUS0_CFG_CMU_O_VCO_CALDONE_RD(rd_val);

    if (loop == 0)
      break;
    else {
      //lprintf(8, "@");
      USDELAY(5000);
    }
    loop--;
  }
  //delay(5000);  
  USDELAY(5000);

  lprintf(8, "INIT_SERDES : PLL is %sREADY\n", pll_ready ? "" : "not ");
  //lprintf(3, "INIT_SERDES : PLL %sLOCKed\n", pll_lock ? "" : "not ");
  lprintf(8, "INIT_SERDES : PLL VCO Calibration %s\n", vco_calibration ? "Successful" : "not Successful");

  lprintf(8, "INIT_SERDES : Check TX/RX Ready\n");
  rd_val = eth_rd(SM_SATA_ENET_SDS_CSR_REGS_SATA_ENET_SDS0_RXTX_STATUS__ADDR,ENET,port,display);
  tx_ready = FIELD_SATA_ENET_SDS0_RXTX_STATUS_CFG_TX_O_TX_READY_RD(rd_val);
  rx_ready = FIELD_SATA_ENET_SDS0_RXTX_STATUS_CFG_RX_O_RX_READY_RD(rd_val);
	
  lprintf(8, "INIT_SERDES : TX is %sready\n", tx_ready ? "" : "not ");
  lprintf(8, "INIT_SERDES : RX is %sready\n", rx_ready ? "" : "not ");


  return pll_ready;

}


// --------------------------------------------------------
void sata_enet_bist(){
  int port;
  for(port=0;port<=3;port++)
    sata_enet_bist_port(ENET,port,0);
}

void sata_enet_bist_port(int eth_type,int port, int display){
  int data32,bist_done,bist_pass,bist_fail;
  int channel_offset = (port & 0x1) * 0x200;
  //// 1. Tx forward loopback enable, enables the loopabck buffer"
  data32 = enet_sds_ind_csr_reg_rd("KC_SERDES_RXTX_REGS_RXTX_REG4", KC_SERDES_RXTX_REGS_RXTX_REG4__ADDR + channel_offset,eth_type,port,display);  
  data32 = FIELD_RXTX_REG4_TX_LOOPBACK_BUF_EN_SET(data32,1);
  enet_sds_ind_csr_reg_wr("KC_SERDES_RXTX_REGS_RXTX_REG4", KC_SERDES_RXTX_REGS_RXTX_REG4__ADDR,data32+ channel_offset,eth_type,port,display);

  ////2. RX Forward Loopback enable
  ////3. RX Bist enable for PRBS transfer
  data32 = enet_sds_ind_csr_reg_rd("KC_SERDES_RXTX_REGS_RXTX_REG7", KC_SERDES_RXTX_REGS_RXTX_REG7__ADDR + channel_offset,eth_type,port,display);  
  data32 = FIELD_RXTX_REG7_LOOP_BACK_ENA_CTLE_SET(data32,1);
  data32 = FIELD_RXTX_REG7_BIST_ENA_RX_SET(data32,1);
  enet_sds_ind_csr_reg_wr("KC_SERDES_RXTX_REGS_RXTX_REG7", KC_SERDES_RXTX_REGS_RXTX_REG7__ADDR,data32+ channel_offset,eth_type,port,display);

  // set PRBS polynomial to 31
  data32 = enet_sds_ind_csr_reg_rd("KC_SERDES_RXTX_REGS_RXTX_REG4", KC_SERDES_RXTX_REGS_RXTX_REG4__ADDR + channel_offset,eth_type,port,display);  
  data32 = FIELD_RXTX_REG4_TX_PRBS_SEL_SET(data32,4);
  enet_sds_ind_csr_reg_wr("KC_SERDES_RXTX_REGS_RXTX_REG4", KC_SERDES_RXTX_REGS_RXTX_REG4__ADDR,data32+ channel_offset,eth_type,port,display);

  data32 = enet_sds_ind_csr_reg_rd("KC_SERDES_RXTX_REGS_RXTX_REG7", KC_SERDES_RXTX_REGS_RXTX_REG7__ADDR + channel_offset,eth_type,port,display);  
  data32 = FIELD_RXTX_REG7_RX_PRBS_SEL_SET(data32,4);
  enet_sds_ind_csr_reg_wr("KC_SERDES_RXTX_REGS_RXTX_REG7", KC_SERDES_RXTX_REGS_RXTX_REG7__ADDR,data32+ channel_offset,eth_type,port,display);

  ////4. TX Bist enable for PRBS transfer
  data32 = enet_sds_ind_csr_reg_rd("KC_SERDES_RXTX_REGS_RXTX_REG2", KC_SERDES_RXTX_REGS_RXTX_REG2__ADDR + channel_offset,eth_type,port,display);  
  data32 = FIELD_RXTX_REG2_BIST_ENA_TX_SET(data32,1);
  enet_sds_ind_csr_reg_wr("KC_SERDES_RXTX_REGS_RXTX_REG2", KC_SERDES_RXTX_REGS_RXTX_REG2__ADDR,data32+ channel_offset,eth_type,port,display);

  ////5. Toggle Re-sync the RX bert logic, without reset
  data32 = enet_sds_ind_csr_reg_rd("KC_SERDES_RXTX_REGS_RXTX_REG6", KC_SERDES_RXTX_REGS_RXTX_REG6__ADDR + channel_offset,eth_type,port,display);  
  data32 = FIELD_RXTX_REG6_RX_BIST_RESYNC_SET(data32,1);
  enet_sds_ind_csr_reg_wr("KC_SERDES_RXTX_REGS_RXTX_REG6", KC_SERDES_RXTX_REGS_RXTX_REG6__ADDR,data32+ channel_offset,eth_type,port,display);
  data32 = FIELD_RXTX_REG6_RX_BIST_RESYNC_SET(data32,0);
  enet_sds_ind_csr_reg_wr("KC_SERDES_RXTX_REGS_RXTX_REG6", KC_SERDES_RXTX_REGS_RXTX_REG6__ADDR,data32+ channel_offset,eth_type,port,display);

  ////6. Reset bert logic  (0->1)
  data32 = enet_sds_ind_csr_reg_rd("KC_SERDES_RXTX_REGS_RXTX_REG61", KC_SERDES_RXTX_REGS_RXTX_REG61__ADDR + channel_offset,eth_type,port,display);  
  data32 = FIELD_RXTX_REG61_BERT_RESETB_SET(data32,1);
  enet_sds_ind_csr_reg_wr("KC_SERDES_RXTX_REGS_RXTX_REG61", KC_SERDES_RXTX_REGS_RXTX_REG61__ADDR,data32+ channel_offset,eth_type,port,display);
  data32 = FIELD_RXTX_REG61_BERT_RESETB_SET(data32,0);
  enet_sds_ind_csr_reg_wr("KC_SERDES_RXTX_REGS_RXTX_REG61", KC_SERDES_RXTX_REGS_RXTX_REG61__ADDR,data32+ channel_offset,eth_type,port,display);

  ////7. Check for BERT PASS/FAIL bert passes
  bist_done = 0;
  while(!bist_done) {
    data32 = enet_sds_ind_csr_reg_rd("KC_SERDES_RXTX_REGS_RXTX_REG158", KC_SERDES_RXTX_REGS_RXTX_REG158__ADDR + channel_offset,eth_type,port,display);
    printf(".");
    bist_pass = FIELD_RXTX_REG158_RX_BIST_PASS_RD(data32);
    bist_fail = FIELD_RXTX_REG158_RX_BIST_FAIL_RD(data32);
    bist_done = bist_pass|bist_fail;
  }
  printf("\n\r\n\r  BIST TEST %s\n\r", bist_pass && !bist_fail ? "PASSED" : "FAILED");
  
  ////8. Read internal Bist error counter value (1->0) 
  data32 = enet_sds_ind_csr_reg_rd("KC_SERDES_RXTX_REGS_RXTX_REG6", KC_SERDES_RXTX_REGS_RXTX_REG6__ADDR + channel_offset,eth_type,port,display);  
  data32 = FIELD_RXTX_REG6_RX_BIST_ERRCNT_RD_SET(data32,1);
  enet_sds_ind_csr_reg_wr("KC_SERDES_RXTX_REGS_RXTX_REG6", KC_SERDES_RXTX_REGS_RXTX_REG6__ADDR,data32+ channel_offset,eth_type,port,display);
  data32 = FIELD_RXTX_REG6_RX_BIST_ERRCNT_RD_SET(data32,0);
  enet_sds_ind_csr_reg_wr("KC_SERDES_RXTX_REGS_RXTX_REG6", KC_SERDES_RXTX_REGS_RXTX_REG6__ADDR,data32+ channel_offset,eth_type,port,display);

  ////9. Bist err count (LSB)
  data32 = enet_sds_ind_csr_reg_rd("KC_SERDES_RXTX_REGS_RXTX_REG153", KC_SERDES_RXTX_REGS_RXTX_REG153__ADDR + channel_offset,eth_type,port,display);  

  ////10. Bist err count (MSB)
  data32 = enet_sds_ind_csr_reg_rd("KC_SERDES_RXTX_REGS_RXTX_REG152", KC_SERDES_RXTX_REGS_RXTX_REG152__ADDR + channel_offset,eth_type,port,display);  

  ////11. INject error (Write 1)
  data32 = enet_sds_ind_csr_reg_rd("KC_SERDES_RXTX_REGS_RXTX_REG8", KC_SERDES_RXTX_REGS_RXTX_REG8__ADDR + channel_offset,eth_type,port,display);  
  data32 = FIELD_RXTX_REG8_TX_BIST_INJECT_ERR_SET(data32,1);
  enet_sds_ind_csr_reg_wr("KC_SERDES_RXTX_REGS_RXTX_REG8", KC_SERDES_RXTX_REGS_RXTX_REG8__ADDR,data32+ channel_offset,eth_type,port,display);
  ////12. INject error (Write 0)
  data32 = FIELD_RXTX_REG8_TX_BIST_INJECT_ERR_SET(data32,0);
  enet_sds_ind_csr_reg_wr("KC_SERDES_RXTX_REGS_RXTX_REG8", KC_SERDES_RXTX_REGS_RXTX_REG8__ADDR,data32+ channel_offset,eth_type,port,display);

  ////8. Read internal Bist error counter value (1->0) 
  data32 = enet_sds_ind_csr_reg_rd("KC_SERDES_RXTX_REGS_RXTX_REG6", KC_SERDES_RXTX_REGS_RXTX_REG6__ADDR + channel_offset,eth_type,port,display);  
  data32 = FIELD_RXTX_REG6_RX_BIST_ERRCNT_RD_SET(data32,1);
  enet_sds_ind_csr_reg_wr("KC_SERDES_RXTX_REGS_RXTX_REG6", KC_SERDES_RXTX_REGS_RXTX_REG6__ADDR,data32+ channel_offset,eth_type,port,display);
  data32 = FIELD_RXTX_REG6_RX_BIST_ERRCNT_RD_SET(data32,0);
  enet_sds_ind_csr_reg_wr("KC_SERDES_RXTX_REGS_RXTX_REG6", KC_SERDES_RXTX_REGS_RXTX_REG6__ADDR,data32+ channel_offset,eth_type,port,display);

  ////9. Bist err count (LSB)
  data32 = enet_sds_ind_csr_reg_rd("KC_SERDES_RXTX_REGS_RXTX_REG153", KC_SERDES_RXTX_REGS_RXTX_REG153__ADDR + channel_offset,eth_type,port,display);  

  ////10. Bist err count (MSB)
  data32 = enet_sds_ind_csr_reg_rd("KC_SERDES_RXTX_REGS_RXTX_REG152", KC_SERDES_RXTX_REGS_RXTX_REG152__ADDR + channel_offset,eth_type,port,display);  
}
////////////////////////////////////////////////////////////////////////////////////////////////////
// KC SERDES CLK MACRO
////////////////////////////////////////////////////////////////////////////////////////////////////

int kc_serdes_rd(int offset,int port){
  return enet_sds_ind_csr_reg_rd("offset",offset,ENET,port,0);
}
void kc_serdes_wr(int offset, int wr_data,int port){
  enet_sds_ind_csr_reg_wr("offset",offset,wr_data,ENET,port,0);
}

int kc_macro_cfg(int port)
{
  int rc = 0;
  int i;    
  unsigned int rmw_addr,data32;

  rmw_addr = SM_SATA_ENET_SDS_CSR_REGS_SATA_ENET_CLK_MACRO_REG__ADDR;
  data32 = eth_rd(rmw_addr,ENET,port,0);
  data32 = FIELD_SATA_ENET_CLK_MACRO_REG_I_RESET_B_SET(data32, 0x0);
  data32 = FIELD_SATA_ENET_CLK_MACRO_REG_I_PLL_FBDIV_SET(data32, 0x27);
  data32 = FIELD_SATA_ENET_CLK_MACRO_REG_I_CUSTOMEROV_SET(data32, 0x0); 
  eth_wr(rmw_addr,data32,ENET,port,0);
#if 1
  rmw_addr = KC_CLKMACRO_CMU_REGS_CMU_REG34__ADDR;
  data32 = kc_serdes_rd(rmw_addr  ,port );
  data32 = FIELD_CMU_REG34_VCO_CAL_VTH_LO_MAX_SET(data32, 0x7);
  data32 = FIELD_CMU_REG34_VCO_CAL_VTH_HI_MAX_SET(data32, 0xd);
  data32 = FIELD_CMU_REG34_VCO_CAL_VTH_LO_MIN_SET(data32, 0x2);
  data32 = FIELD_CMU_REG34_VCO_CAL_VTH_HI_MIN_SET(data32, 0x8);
  kc_serdes_wr( rmw_addr   , data32,port);
#endif

  //CMU_REG0
  rmw_addr = KC_CLKMACRO_CMU_REGS_CMU_REG0__ADDR;
  data32 = kc_serdes_rd(rmw_addr,port);
  data32 = FIELD_CMU_REG0_CAL_COUNT_RESOL_SET(data32, 0x4);
  kc_serdes_wr(rmw_addr, data32,port);

  //CMU_REG1
  data32 = kc_serdes_rd(KC_CLKMACRO_CMU_REGS_CMU_REG1__ADDR,port);
  data32 = FIELD_CMU_REG1_PLL_CP_SET(data32, 0x1);     
  data32 = FIELD_CMU_REG1_PLL_CP_SEL_SET(data32, 0x5); 
  data32 = FIELD_CMU_REG1_PLL_MANUALCAL_SET(data32, 0x0);   
  kc_serdes_wr(KC_CLKMACRO_CMU_REGS_CMU_REG1__ADDR, data32,port);


  //CMU_REG2
  data32 = kc_serdes_rd(KC_CLKMACRO_CMU_REGS_CMU_REG2__ADDR,port);
  data32 =  FIELD_CMU_REG2_PLL_LFRES_SET(data32, 0xa);   
  data32 = FIELD_CMU_REG2_PLL_FBDIV_SET(data32, 0x27);      //100Mhz refclk
  kc_serdes_wr(KC_CLKMACRO_CMU_REGS_CMU_REG2__ADDR, data32,port); 
  

  //CMU_REG3
  data32 = kc_serdes_rd( KC_CLKMACRO_CMU_REGS_CMU_REG3__ADDR,port);
  data32 = FIELD_CMU_REG3_VCOVARSEL_SET(data32,0x3); 
  data32 = FIELD_CMU_REG3_VCO_MOMSEL_INIT_SET(data32,0x10); 
  kc_serdes_wr(KC_CLKMACRO_CMU_REGS_CMU_REG3__ADDR, data32,port);

  //CMU_REG26   Added on 3/23/2013
  data32 = kc_serdes_rd( KC_CLKMACRO_CMU_REGS_CMU_REG26__ADDR,port);
  data32 = FIELD_CMU_REG26_FORCE_PLL_LOCK_SET(data32,0x0); 
  kc_serdes_wr(KC_CLKMACRO_CMU_REGS_CMU_REG26__ADDR, data32,port);


  //CMU_REG5   
  data32 = kc_serdes_rd(KC_CLKMACRO_CMU_REGS_CMU_REG5__ADDR,port);
  data32 = FIELD_CMU_REG5_PLL_LFSMCAP_SET(data32,0x3); 
  data32 = FIELD_CMU_REG5_PLL_LFCAP_SET(data32,0x3); 
  data32 = FIELD_CMU_REG5_PLL_LOCK_RESOLUTION_SET(data32,0x7);  
  kc_serdes_wr(KC_CLKMACRO_CMU_REGS_CMU_REG5__ADDR, data32,port);


  //CMU_reg6
  data32 = kc_serdes_rd(KC_CLKMACRO_CMU_REGS_CMU_REG6__ADDR,port);
  data32 = FIELD_CMU_REG6_PLL_VREGTRIM_SET(data32,0x0); 
  data32 = FIELD_CMU_REG6_MAN_PVT_CAL_SET(data32,0x1); 
  kc_serdes_wr(KC_CLKMACRO_CMU_REGS_CMU_REG6__ADDR, data32,port);


  //CMU_reg16
  data32 = kc_serdes_rd(KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR,port);
  data32 = FIELD_CMU_REG16_CALIBRATION_DONE_OVERRIDE_SET(data32,0x1); //JITU_ANIL 03/25/20113 
  data32 = FIELD_CMU_REG16_BYPASS_PLL_LOCK_SET(data32,0x1); //JITU_ANIL 03/23/20113 
  data32 = FIELD_CMU_REG16_VCOCAL_WAIT_BTW_CODE_SET(data32,0x4); //JITU_ANIL 03/23/20113 
  kc_serdes_wr(KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR, data32,port);

  //CMU_reg30
  data32 = kc_serdes_rd(KC_CLKMACRO_CMU_REGS_CMU_REG30__ADDR,port);
  data32 = FIELD_CMU_REG30_PCIE_MODE_SET(data32,0x0); 
  data32 = FIELD_CMU_REG30_LOCK_COUNT_SET(data32,0x3); //JITU_ANIL 03/23/20113 
  kc_serdes_wr(KC_CLKMACRO_CMU_REGS_CMU_REG30__ADDR, data32,port);
  //CMU_reg31
  kc_serdes_wr(KC_CLKMACRO_CMU_REGS_CMU_REG31__ADDR, 0xF,port);

  //CMU_reg32
  data32 = kc_serdes_rd( KC_CLKMACRO_CMU_REGS_CMU_REG32__ADDR,port);
  data32 = FIELD_CMU_REG32_PVT_CAL_WAIT_SEL_SET(data32,0x3); //JITU_ANIL 03/23/20113 
  data32 = FIELD_CMU_REG32_IREF_ADJ_SET(data32,0x3); 
  kc_serdes_wr(KC_CLKMACRO_CMU_REGS_CMU_REG32__ADDR, data32,port);

  //CMU_reg34

  //	kc_serdes_wr( KC_CLKMACRO_CMU_REGS_CMU_REG34__ADDR, 0x2A2A);
  kc_serdes_wr( KC_CLKMACRO_CMU_REGS_CMU_REG34__ADDR, 0x8d27,port);


  //CMU_reg37
  data32 = kc_serdes_rd(KC_CLKMACRO_CMU_REGS_CMU_REG37__ADDR,port);
  kc_serdes_wr( KC_CLKMACRO_CMU_REGS_CMU_REG37__ADDR, 0xF00F,port);

  rmw_addr = SM_SATA_ENET_SDS_CSR_REGS_SATA_ENET_CLK_MACRO_REG__ADDR;
  data32 = eth_rd(rmw_addr,ENET,port,0);
  data32 = FIELD_SATA_ENET_CLK_MACRO_REG_I_RESET_B_SET(data32, 0x1);
  data32 =   FIELD_SATA_ENET_CLK_MACRO_REG_I_CUSTOMEROV_SET(data32, 0x0);
  eth_wr(rmw_addr,data32,ENET,port,0);
  //delay(800000);
  USDELAY(800000);
  

  rc = 0;
  int calib_loop_count = 0;
  rc = kc_macro_pvt_and_calib_ready_check(port);
  while (rc && calib_loop_count<5) {
#if 0
    rmw_addr = SM_SATA_ENET_SDS_CSR_REGS_SATA_ENET_CLK_MACRO_REG__ADDR;
    data32 = eth_rd(rmw_addr,ENET,port,0);
    data32 = FIELD_SATA_ENET_CLK_MACRO_REG_I_RESET_B_SET(data32, 0x1);
    data32 =   FIELD_SATA_ENET_CLK_MACRO_REG_I_CUSTOMEROV_SET(data32, 0x0);
    eth_wr(rmw_addr,data32,ENET,port,0)
      delay(8000);
#endif
    if(rc) kc_macro_pdown_force_vco(port);
    rc = kc_macro_pvt_and_calib_ready_check(port);
    if (rc==0) break;
    ++calib_loop_count;
    printf(" sata_sm_sds_config() calib_loop_count=%d rc = %d.. \n\r",calib_loop_count,rc);
  }
  if (calib_loop_count==5) goto  end;
 
  i = 10;
  if (FIELD_SATA_ENET_CLK_MACRO_REG_O_PLL_LOCK_RD(data32) && ( i > 0)) {
    printf ("\nPLL Locked for Internal Clock Mode\n");
    //delay(100);
    USDELAY(100);
  } 
  else { //printf ("  =============>>>> PLL CLKMACRO UN-LOOKED ...\n");
  }

  if (FIELD_SATA_ENET_CLK_MACRO_REG_O_PLL_READY_RD(data32)) {
    //printf ("  =============>>>> PLL CLKMACRO READY ...\n");
      

  } 
  else  {  //printf ("  =============>>>> PLL CLKMACRO NOT READY ...\n"); 
  }

 end:
  return rc;
}

int kc_macro_pvt_and_calib_ready_check(int port) {

  int rc = 0;
  unsigned int rmw_addr,data32;
  int timeout;
  // ********************
  // TERM CALIBRATION CH0 
  // ********************
  data32 = kc_serdes_rd( KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR,port);
  data32 = FIELD_CMU_REG17_PVT_CODE_R2A_SET(data32,0x0d);
  data32 = FIELD_CMU_REG17_RESERVED_7_SET(data32,0x0); 
  kc_serdes_wr( KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR, data32,port);

  data32 = kc_serdes_rd( KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR,port);
  data32 = FIELD_CMU_REG17_PVT_TERM_MAN_ENA_SET(data32,0x1);
  kc_serdes_wr( KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR, data32,port);
 
  data32 = kc_serdes_rd( KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR,port);
  data32 = FIELD_CMU_REG17_PVT_TERM_MAN_ENA_SET(data32,0x0);
  kc_serdes_wr( KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR, data32,port);



  // *********************
  // DOWN CALIBRATION CH0
  // *********************
  data32 = kc_serdes_rd( KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR,port);
  data32 = FIELD_CMU_REG17_PVT_CODE_R2A_SET(data32,0x26);
  data32 = FIELD_CMU_REG17_RESERVED_7_SET(data32,0x0); 
  kc_serdes_wr( KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR, data32,port);

  data32 = kc_serdes_rd( KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR,port);
  data32 = FIELD_CMU_REG16_PVT_DN_MAN_ENA_SET(data32,0x1);
  kc_serdes_wr( KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR, data32,port);


  data32 = kc_serdes_rd( KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR,port);
  data32 = FIELD_CMU_REG16_PVT_DN_MAN_ENA_SET(data32,0x0);
  kc_serdes_wr( KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR, data32,port);


  // *********************
  // UP CALIBRATION CH0
  // *********************
  data32 = kc_serdes_rd( KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR,port);
  data32 = FIELD_CMU_REG17_PVT_CODE_R2A_SET(data32,0x28);
  data32 = FIELD_CMU_REG17_RESERVED_7_SET(data32,0x0); 
  kc_serdes_wr( KC_CLKMACRO_CMU_REGS_CMU_REG17__ADDR, data32,port);

  data32 = kc_serdes_rd( KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR,port);
  data32 = FIELD_CMU_REG16_PVT_UP_MAN_ENA_SET(data32,0x1);
  kc_serdes_wr( KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR, data32,port);

  data32 = kc_serdes_rd( KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR,port);
  data32 = FIELD_CMU_REG16_PVT_UP_MAN_ENA_SET(data32,0x0);
  kc_serdes_wr( KC_CLKMACRO_CMU_REGS_CMU_REG16__ADDR, data32,port);

  ///
  // Check for PLL calibration
  int loopcount =5;
  data32 = kc_serdes_rd (KC_CLKMACRO_CMU_REGS_CMU_REG7__ADDR,port);
  while (FIELD_CMU_REG7_PLL_CALIB_DONE_RD(data32) == 0x0) {
    loopcount--;
    for(timeout=0; timeout<0x80000; ++timeout);
    data32 = kc_serdes_rd (KC_CLKMACRO_CMU_REGS_CMU_REG7__ADDR,port);
    if (loopcount==0) {
      //printf ("CLKMACRO PLL CALIB DONE NOT DETECTED ...\n\r");
      break;
    }
  }

  // PLL Calibration DONE 
  data32 = kc_serdes_rd (KC_CLKMACRO_CMU_REGS_CMU_REG7__ADDR,port);
  if (FIELD_CMU_REG7_PLL_CALIB_DONE_RD(data32) == 0x1) {
    //printf ("kc_macro_pvt_and_calib_ready_check() ====>  CLKMACRO PLL CALIB  Done ...\n\r");
    lprintf (5, "CLKMACRO PLL CALIB  Done ...\n\r");
  }
  // Check for VCO FAIL 
  if (FIELD_CMU_REG7_VCO_CAL_FAIL_RD(data32) == 0x0) {
    //printf ("kc_macro_pvt_and_calib_ready_check() ====>  CLKMACRO CALIB Successfull...\n\r");
    lprintf (5, "CLKMACRO CALIB Successfull...\n\r");
  }
  else {
    // Assert SDS reset and recall calib function
    rmw_addr = SM_SATA_ENET_SDS_CSR_REGS_SATA_ENET_CLK_MACRO_REG__ADDR;
    data32 = eth_rd(rmw_addr,ENET,port,0);
    //       data32 = FIELD_SATA_ENET_CLK_MACRO_REG_I_RESET_B_SET(data32, 0x0);
    //       data32 =   FIELD_SATA_ENET_CLK_MACRO_REG_I_CUSTOMEROV_SET(data32, 0x0);
    eth_wr(rmw_addr,data32,ENET,port,0);
    //printf ("kc_macro_pvt_and_calib_ready_check() ====>  CLKMACRO CALIB FAILED due to VCO FAIL...\n\r");
    rc = 1;
  }


  return rc;
} // kc_macro_pvt_and_calib_ready_check

void  kc_macro_pdown_force_vco (int port) {
  unsigned int rmw_addr,data32;
  
  lprintf (8, " serdes_pdown_force_vco () \n");
  rmw_addr = KC_CLKMACRO_CMU_REGS_CMU_REG0__ADDR;
  data32 = kc_serdes_rd (rmw_addr,port);
  data32 = FIELD_CMU_REG0_PDOWN_SET(data32, 1);
  kc_serdes_wr( rmw_addr, data32,port);
  //delay(800);
  USDELAY(800);

#if 0
  //ADDING PLL RESET
  rmw_addr = KC_CLKMACRO_CMU_REGS_CMU_REG5__ADDR;
  data32 = kc_serdes_rd (rmw_addr,port);
  data32 = FIELD_CMU_REG5_PLL_RESETB_SET(data32,0);
  kc_serdes_wr(rmw_addr, data32,port);
 
  delay(800);
  rmw_addr = KC_CLKMACRO_CMU_REGS_CMU_REG5__ADDR;
  data32 = kc_serdes_rd (rmw_addr,port);
  data32 = FIELD_CMU_REG5_PLL_RESETB_SET(data32,1);
  kc_serdes_wr(rmw_addr, data32,port);
#endif
  rmw_addr = KC_CLKMACRO_CMU_REGS_CMU_REG0__ADDR;
  data32 = kc_serdes_rd (rmw_addr,port);
  data32 = FIELD_CMU_REG0_PDOWN_SET(data32, 0);
  kc_serdes_wr( rmw_addr , data32,port);

  //delay(800);
  USDELAY(800);
  rmw_addr = KC_CLKMACRO_CMU_REGS_CMU_REG32__ADDR;
  data32 = kc_serdes_rd (rmw_addr,port);
  data32 = FIELD_CMU_REG32_FORCE_VCOCAL_START_SET(data32, 1);
  kc_serdes_wr(rmw_addr , data32,port);
  data32 =  FIELD_CMU_REG32_FORCE_VCOCAL_START_SET(data32, 0);
  kc_serdes_wr( KC_CLKMACRO_CMU_REGS_CMU_REG32__ADDR, data32,port);

}

