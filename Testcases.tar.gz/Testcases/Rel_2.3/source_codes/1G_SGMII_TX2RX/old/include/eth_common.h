#ifndef __ETH_COMMON_H_
#define __ETH_COMMON_H_

#include <types.h>

#define uint32_t unsigned int

//#define RANDOMIZE_SLT    

#define UART_BAUD 9600
#define ARGV_SIZE 10
#define MAX_INDCMD_DONE_COUNTER 100
#define SLT_MSG_NUM 4
#define SLT_FP_SIZE  2048

struct cmd {
   char *str;
   int (*cmd_func)(int , char*[]);
   char *help_msg;
};

enum {PORT0, PORT1, PORT2, PORT3} PORT;
enum {MENET, ENET,  XGENET } ETH_TYPE;

static int display_all = 0;
static int display_serdes = 0;

extern int pll_manualcal; // 0 = Autocalibration, 1 = Manual Calibration
extern int man_pvt_cal;   // Only for XGENET, unused in SATA_ENET
                          // 0 = From SM, 1 = Manual Calibration
extern int vco_momsel_init; // 0 = Autocalibration, 1 = Manual Calibration
extern int vco_momsel_init_xg; // 0 = Autocalibration, 1 = Manual Calibration

//global val
#define ENET_01_BASE_ADDR  0x1f210000
#define ENET_23_BASE_ADDR  0x1f220000
#define XGENET_0_BASE_ADDR 0x1f610000
#define XGENET_1_BASE_ADDR 0x1f620000
#define XGENET_2_BASE_ADDR 0x1f710000
#define XGENET_3_BASE_ADDR 0x1f720000
#define MENET_BASE_ADDR    0x17020000 //md: 

#define FIRST_PORT 0
#define LAST_PORT  3

#define XFI_SGMII_PORTS         // All 4 1 gig XFI_SGMII Ports  
#define SATA_SGMII_PORTS        // All 4 1 gig SATA_SGMII Ports 

#define STORM_A2 //
#define CMU   0x0000

#define QM_XGESOC_BASE_ADDR 0x1f200000
#define QM_XGE01_BASE_ADDR 0x1f600000
#define QM_XGE23_BASE_ADDR 0x1f700000
#define SW_HACK_STAY_LOOPBACK
#define QM_TEST_MSG_NUM 1 //48
#define PKT_SIZE 128 //256 //128 //64 
#define PKT_NUM 1 //4 //20 //200
extern u64 buf[]; 
extern u64 buf1[]; 

extern int putnum(int num);
extern int   read32(unsigned int *address);
extern u64 read_64(u64 *address);
extern u32 read_word(u64 *address);
extern void  write32(unsigned int *address, int data);
extern int   read(unsigned int *address);
extern void write(unsigned int *address, int data);
short read16(short *address);
extern void  write16(short *address, short data);
extern char  read8(char *address);
extern void  write8(char *address,char data);
extern int eth_base(int eth_type, int port);
extern int eth_rd(int offset, int eth_type, int port, int display);
extern void eth_wr(int offset, int wr_data, int eth_type, int port, int display);
extern int mcxmac_stat_rd(int offset, int port);
extern int mac_stat_rd(int offset, int port);
extern int  mcxmac_ind(int rnw, int offset, int wr_data, int eth_type, int port, int display);
extern int mcxmac_ind_rd(int offset, int eth_type, int port, int display);
extern void mcxmac_ind_wr(int offset, int wr_data, int eth_type, int port, int display);
extern void mdio_wr(int phy_reg, int wr_data, int eth_type, int port, int display);
extern int mdio_rd(int phy_reg, int eth_type, int port, int display);
extern void axgmac_ind_write (int addr, int data, int port, int display) ;
extern int axgmac_ind_read(int addr);
extern void error(int stoptest) ;
extern void end_test() ;
extern int get_val();
extern void get_file (int *start_address, int size_in_bytes) ;
extern void enet_sds_ind_csr_reg_wr(const char *name, uint32_t offset, uint32_t data, int eth_type, int port, int display );
extern uint32_t enet_sds_ind_csr_reg_rd(const char *name, uint32_t  offset, int eth_type, int port, int display);
extern uint32_t sm_enet_set(uint32_t ori_val,uint32_t set_val,uint32_t end,uint32_t start) ;
extern void delay(int val);
extern void error(int exit);
extern void end_test();
extern int  get_val();
extern void get_file(int *start_address, int size_in_bytes);
extern void ddr_init();
extern int myread(int *address, int display);
extern void mywrite(int *address, int data);
extern int my_get_val(char *str);
extern void mac_ind_write_mode (int port, int addr, int data2, int data1, int data0) ;
extern void enet_reg_wr_mode (int port, int addr, int data2, int data1, int data0) ;
extern void enet_init_ecc(int port, int display) ;
extern int  init_enet_serdes(int inst, int refclk) ;
extern void enet_clkcfg_1(int port, int display);
extern void enet_clkcfg_2(int port, int display);
extern void enet_basic(int intf, int display) ;
extern int init_enet(int inst) ;
extern int configure_sgmii(int port, int display, int reconfig_count);
extern void read_statistics(int port);
extern int vco_status(int inst, int display) ;
extern int link_status();
extern int lnk_sts(int srt_port, int end_port, int display) ;
extern void debug_1g();
extern void menet_init_ecc() ;
extern void menet_clkcfg() ;
extern void mgmt_mac_config() ;
extern void eth_reg_wr_mode (int addr, int data2, int data1, int data0, int eth_type, int port, int display ) ;
extern void mcxmac_ind_wr_mode(int offset, int wr_data2, int wr_data1, int wr_data0, int eth_type, int port, int display);
extern void clk_reset_cfg(int port, int display) ;
extern void xgenet_init_ecc(int port, int display) ;
extern int init_xgenet_serdes(int port, int display) ;
extern void init_mcxmac(int eth_type, int port, int display) ;
extern void bypass_resume_cfg(int port, int display) ;
extern void loopback_cfg(int port, int display) ;
extern void cle_bypass_mode_cfg (int port, int display) ;
extern int init_xgenet(int port, int display) ;
extern void read_common_statistics(int port);
extern void read_statistics_mcxmac(int port);
extern void print_stat_sgmii_xfi() ;
extern int link_status_xg();
extern int lnk_sts_xg(int srt_port, int end_port, int display);
extern int vco_status_xg(int inst, int display) ;
extern int configure_sgmii_xg(int port, int display, unsigned int reconfig_count);
extern void rst_sds_rxa_xg();

extern int xgene_phy_get_avg(int accum, int samples);
extern int xgene_phy_gen_avg_val(int port);
extern int xgene_phy_gen_avg_val_sata_sgmii(int port);
extern int debug_gen_avg_val_sata_sgmii(int port);
extern int debug_gen_avg_val_xfi_sgmii(int port);

extern void qi_move (int pqtarget, int pqstepmag, int port);
extern void es_singlephase(int vRange, int vskip, int port, int itr);
extern int eyescan_sub_sata_sgmii(int port, int itr);
extern int eyescan_sata_sgmii(int argc, char *argv[]);
extern int eyescan_sata_sgmii_all_lane();

extern void qi_move_xfi_sgmii (int pqtarget, int pqstepmag, int port);
extern void es_singlephase_xfi_sgmii(int vRange, int vskip, int port, int itr);
extern int eyescan_sub_xfi_sgmii(int port, int itr);
extern int eyescan_xfi_sgmii(int argc, char *argv[]);
extern int eyescan_xfi_sgmii_all_lane();

extern void enet_sds_rxtx_re_cfg_xfi_sgmii(int port,int display);
extern void enet_sds_rxtx_re_cfg_sata_sgmii(int port,int display);

extern void slt_hack_sata_sg(int port);

extern void debug_xg();
extern int xgbaser_ind_read(int addr, int port, int display);
extern void xgbaser_ind_write (int addr, int data, int port, int display);
extern void sw_workaround_xg();
extern void config_rsif_vc2_xg();
extern void enable_64_byte_axi_write_padding_xg();
extern u32 mdio_sgmii_phyId_regression_test(int phy_addr, int phy_reg, int count);
extern u32 mdio_rgmii_phyId_regression_test(int phy_addr, int phy_reg, int count);
extern int eth_rx2tx();
extern void mac_stat_1g_xfi();
extern void wait_link_change();
extern void set_mcu_hpweight(int weight);
extern void set_mcu_lpweight(int weight);
extern void set_mcu_wpweight(int weight);
extern void set_mcu_ref_burst_cnt(int ref_burst_cnt);
extern void enable_l3_cache();
extern void sw_workaround();
extern void config_rsif_vc2();
extern void enable_64_byte_axi_write_padding();
extern void xfi_sgmii_serdes_reg_dump();
extern void sata_sgmii_serdes_reg_dump();
extern void mac_stat_1g_sata();
extern void print_stat_sgmii_sata();
extern void send_pause_frame_xfi();
extern void send_pause_frame_sata();
extern int port_link_check(int phy_addr);
extern int sgmii_core_link_check(int port, int eth_type);

extern void set_serdes_lpbk() ;
extern void reset_serdes_lpbk() ;
extern void set_phy_level_lpbk_sgmii(int eth_type);
extern int phy_rd_wr();
extern void sgmii_read_prbs_err_cnt(int port, int lpbk_mode, int eth_type);
extern int xfi_sgmii_serdes_prbs_test();
extern int sata_sgmii_serdes_prbs_test();
extern int sgmii_serdes_prbs_test(int eth_type);
extern void send_pause_packet_xfi(int tx_port, u32 pn);
extern void send_pause_packet_sata(int tx_port, u32 pn);
extern int margin_util_sgmii_xfi();
extern int margin_util_sgmii_sata();
extern void mac_stat_sgmii_xfi();
extern void mac_stat_sgmii_sata();

extern int check_phy_autoneg_bypass_sts(int phy_addr);
extern void set_serial_interface_autoneg_bypass();
extern void phy_autoneg_bypass_sts();
extern int eth_dbg_sata();
extern int eth_dbg_xfi();

#endif // __ETH_COMMON_H_

