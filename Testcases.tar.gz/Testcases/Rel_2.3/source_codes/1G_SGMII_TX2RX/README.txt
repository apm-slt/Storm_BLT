###############################################################################
##       APPLIED MICRO (APM)
## Version     : 1.0
## Description : This README gives brief information about directry structure
                 and its contents. Also this will help user to build binary image & 
                 run test case on VBIOS platform.
###############################################################################

oo===================================================================================oo
1) SVN Checkout :
-----------------
   - DEN Server :
	svn co file:///projects/den/storm/validation/storm_a3.svn storm_a3
   - PDC Server :
	svn co svn+ssh://denlwv100/projects/den/storm/validation/storm_a3.svn storm_a3
oo===================================================================================oo
2) Directory Structure :
------------------------
<storm_a3>
    ├─── <eth>
    │      └─── <sata_sgmii>
    │               ├─── <include>
    │               │        ├─── eth_common.h
    │               │        ├─── eth_1g_csr.h
    │               │        ├─── eth_xg_csr.h (for 10G)    
    │               │        ├─── eth_mg_csr.h (for RGMII)   
    │               │        ├─── eth_cle_csr.h 
    │               │        ├─── eth_cle_drv.h
    │               │        ├─── cle_eth_def.h 
    │               │        └─── sm_sata_2x_rsps.h
    │               ├─── <driver>
    │               │        ├─── eth_common.c
    │               │        ├─── eth_drv.c
    │               │        ├─── eth_xfi_serdes.c (for 10G)
    │               │        ├─── eth_xg_serdes.c (for 10G)
    │               │        ├─── eth_1g_serdes.c
    │               │        ├─── eth_cle_drv.c   
    │               │        └─── object.mk
    │               └─── <tests>
    │                        ├──── <eth_rx2tx_storm_a3_qm_lpbk>
    │                        │            ├──── eth_rx2tx.c
    │                        │            ├──── eth_1g_main.c
    │                        │            ├──── Makefile
    │                        │            ├──── setup.csh(setup.sh)
    │                        │            ├──── objects.mk
    │                        │            ├──── PowerCycleBoard.tcl
    │                        │            ├──── bdi_lod.tcl
    │                        │            ├──── run   
    │                        │            └──── <bin>*(see in Description more about bin folder)
    │                        ├──── <eth_rx2tx_storm_a3_fifo_lpbk>
    │                        │            ├──── eth_rx2tx.c
    │                        │            ├──── eth_1g_main.c
    │                        │            ├──── Makefile
    │                        │            ├──── setup.csh(setup.sh)
    │                        │            ├──── objects.mk
    │                        │            ├──── PowerCycleBoard.tcl
    │                        │            ├──── bdi_lod.tcl
    │                        │            ├──── run       
    │                        │            └──── <bin>*
    │                        ├──── <eth_rx2tx_storm_a3_cpu_lpbk>
    │                        │            ├──── eth_rx2tx.c
    │                        │            ├──── eth_1g_main.c
    │                        │            ├──── Makefile
    │                        │            ├──── setup.csh(setup.sh)
    │                        │            ├──── objects.mk
    │                        │            ├──── PowerCycleBoard.tcl
    │                        │            ├──── bdi_lod.tcl
    │                        │            ├──── run   
    │                        │            └──── <bin>*
    │                        ├──── <eth_rx2tx_storm_a3_NonAutoNeg>
    │                        │            ├──── eth_rx2tx.c
    │                        │            ├──── eth_1g_main.c
    │                        │            ├──── Makefile
    │                        │            ├──── setup.csh(setup.sh)
    │                        │            ├──── objects.mk
    │                        │            ├──── PowerCycleBoard.tcl
    │                        │            ├──── bdi_lod.tcl
    │                        │            ├──── run       
    │                        │            └──── <bin>*
    │                        ├──── <eth_rx2tx_storm_a3>
    │                        │            ├──── eth_rx2tx.c
    │                        │            ├──── eth_1g_main.c
    │                        │            ├──── Makefile
    │                        │            ├──── setup.csh(setup.sh)
    │                        │            ├──── objects.mk
    │                        │            ├──── PowerCycleBoard.tcl
    │                        │            ├──── bdi_lod.tcl
    │                        │            ├──── run       
    │                        │            └──── <bin>*   
    │                        ├──── <eth_rx2tx>
    │                        │            ├──── eth_rx2tx.c
    │                        │            ├──── eth_1g_main.c
    │                        │            ├──── Makefile
    │                        │            ├──── setup.csh(setup.sh)
    │                        │            ├──── objects.mk
    │                        │            ├──── PowerCycleBoard.tcl
    │                        │            ├──── bdi_lod.tcl
    │                        │            ├──── run       
    │                        │            └──── <bin>*   
    │                        ├──── <eth_rx2tx_storm_a3_qm_cmd_test>
    │                        │            ├──── eth_rx2tx.c
    │                        │            ├──── eth_1g_main.c
    │                        │            ├──── Makefile
    │                        │            ├──── setup.csh(setup.sh)
    │                        │            ├──── objects.mk
    │                        │            ├──── PowerCycleBoard.tcl
    │                        │            ├──── bdi_lod.tcl
    │                        │            ├──── run       
    │                        │            └──── <bin>*    
    │                        ├──── <eth_rx2tx_storm_a3_avb>
    │                        │            ├──── eth_rx2tx.c
    │                        │            ├──── eth_1g_main.c
    │                        │            ├──── Makefile
    │                        │            ├──── setup.csh(setup.sh)
    │                        │            ├──── objects.mk
    │                        │            ├──── PowerCycleBoard.tcl
    │                        │            ├──── bdi_lod.tcl
    │                        │            ├──── run       
    │                        │            └──── <bin>*    
    │                        ├──── <eth_rx2tx_storm_a3_cle>
    │                        │            ├──── eth_rx2tx.c
    │                        │            ├──── eth_1g_main.c
    │                        │            ├──── Makefile
    │                        │            ├──── setup.csh(setup.sh)
    │                        │            ├──── objects.mk
    │                        │            ├──── PowerCycleBoard.tcl
    │                        │            ├──── bdi_lod.tcl
    │                        │            ├──── run       
    │                        │            └──── <bin>*    
    │                        ├──── <eth_tx2rx>
    │                        │            ├──── eth_tx2rx.c
    │                        │            ├──── eth_1g_main.c    
    │                        │            ├──── Makefile
    │                        │            ├──── setup.csh(setup.sh)
    │                        │            ├──── objects.mk
    │                        │            ├──── run    
    │                        │            └──── <bin>*
    │                        ├──── <eth_tx2rx_slt>
    │                        │            ├──── eth_tx2rx.c
    │                        │            ├──── eth_1g_main.c    
    │                        │            ├──── Makefile
    │                        │            ├──── setup.csh(setup.sh)
    │                        │            ├──── objects.mk
    │                        │            ├──── run    
    │                        │            └──── <bin>*
    │                        ├──── <eth_drr>
    │                        │            ├──── eth_tx2rx.c
    │                        │            ├──── eth_1g_main.c    
    │                        │            ├──── Makefile
    │                        │            ├──── setup.csh(setup.sh)
    │                        │            ├──── objects.mk
    │                        │            ├──── run    
    │                        │            └──── <bin>*
    │                        ├──── <eth_avb>
    │                        │            ├──── eth_tx2rx.c
    │                        │            ├──── eth_1g_main.c    
    │                        │            ├──── Makefile
    │                        │            ├──── setup.csh(setup.sh)
    │                        │            ├──── objects.mk
    │                        │            ├──── run    
    │                        │            └──── <bin>*
    │                        └──── <eth_qm_bug>
    │                                     ├──── eth_tx2rx.c
    │                                     ├──── eth_1g_main.c      
    │                                     ├──── Makefile
    │                                     ├──── setup.csh(setup.sh)
    │                                     ├──── objects.mk
    │                                     ├──── run    
    │                                     └──── <bin>
    └─── <qm>
          ├─── <include>
          │        ├─── qm_drv.h
          │        ├─── qm_csr.h
          │        ├─── qm_misc.h
          │        ├─── qm_vfw.h
          │        ├─── qm_vfw.c
          │        ├─── qm_msg.h
          │        └─── qm_common.h
          ├─── <driver>
          │        ├─── qm_drv.c
          │        ├─── qm_misc.c
          │        └─── objects.mk    
          └─── <tests>
                   ├─── qm_n.c
                   ├─── qm_n_vfw.c
                   └───     :

NOTE: <bin>* indicates that this file is not present when svn checkout or svn up 
since we delete this folder at the time of svn check in. 
This folder consist of linker files, clibrary, dis assembly file, elf & binary images. 
All these are generated every time when we compile. The name of binary
image is <name_of_test_case_(mem_type).bin>. mem_type may be ocm / nor  etc.
oo===================================================================================oo
3) Directories / files structure:
----------------------------------------
   - Source Code (*.c) :
	This covers all the tests mentioned as per the Test Plan document.
Based on the category of the test i.e. rx2tx or tx2rx or misc, the code will
be avilable in the source code file under the corresponding directory.
   - objects.mk :
   - setup.csh(setup.sh) :
	o The option 'noddrinit' in this file is preferred
   - Makefile :
	o Mention proper VBIOS path
   - <include> folder :
	This contains set of .h files.
   - <driver> folder :
	This contains all the required drivers.
   - <tests> folder :
	This contains the actual tests cases as per the Test Plan document.
   - <scripts> (*.tcl) :
    These are small automated scripts used for regration. Please verify bench
    details in it.
   - <bin> folder :
	This contains linker files, clibrary, dis assembly file, elf & executable binary file
oo===================================================================================oo
4) Details of include files:
---------------------------
    a)
oo===================================================================================oo
5) Details of driver files:
---------------------------
    a)
        
oo===================================================================================oo
6) Significance of test names:
----------------------------
    a)eth_rx2tx_a3_qm_lpbk:

oo===================================================================================oo
7) How to Compile :
-------------------
   - Run :
	source setup.csh
	make DDR_ADDR_MAP=<DDR_addr_displayed_as_VA_by_VBIOS_in_desired_config>
   - Examples for various DIMM sizes :
	For  2GB ==> make DDR_ADDR_MAP=0x080000000
	For  8GB ==> make DDR_ADDR_MAP=0x100000000
	For 32GB ==> make DDR_ADDR_MAP=0x400000000
oo===================================================================================oo
8) How to load binary through OCD :
-----------------------------------
   Step-1> Start the OCD server session :
	openocd -f <path_of_cfg_file>
   Step-2> Start the OCD client session :
	telnet localhost 4444
   Step-3> Load image through OCD client :
	reset halt;reset halt;ocm_map;load_image <path_of_bin_file/binary_image.bin> 0x1d000000;resume 0
oo===================================================================================oo
9) How to run the test case :
-----------------------------
   - After the bin file is loaded on storm device successfully, VBIOS prompt
     will be displayed on console
   - If 'noddrinit' is :
	> enabled  in setup.csh, type 'ddrinit' on VBIOS prompt
	> disabled in setup.csh, there is no need to do 'ddrinit' on VBIOS prompt
   - Run the test case by typing test case function name
	o go <test_case_fn_name>
	o e.g. go eth_rx2tx, go eth_misc, etc.
oo===================================================================================oo
10) Test case parameters :
-------------------------
   - NA 
oo===================================================================================oo
