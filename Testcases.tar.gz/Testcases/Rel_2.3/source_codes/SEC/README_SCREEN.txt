This storm_B0 version is used to screen for the 9/5/14 shipment.  Currently,
this has been fixed:
1).  SATA test to improve the yield to recover 40% fall-out
2).  SEC test to fix incorrect error report and inconsistent issue
4).  Not update from PCIe from the last screen
5).  Still waiting for XFI and SGMII tests
