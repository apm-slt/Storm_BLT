
#ifndef __SEC_DRIVER_H__
#define __SEC_DRIVER_H__

#include "../include/vSEC_globals.h"
#include "../include/sec_addr_map.h"
#include "../include/vSEC_qm_driver.h"
#include "../include/vSEC_mem_manager.h"
#include "../include/vSEC_defines.h"
#include "../include/vSEC_regs.h"


/* Print debugging info?  1 for yes, 0 for no */
#if (1)
	#define DEBUG_SEC_DRIVER
#endif

#ifdef DEBUG_SEC_DRIVER
	#define debug_sec_drv(...)		printf(__VA_ARGS__)
#else
	#define debug_sec_drv
#endif


#ifdef STORM_ASIC_VALIDATION
	#define SEC_ASSOC_QM_ID   QMTM1_ID
#else
	#define SEC_ASSOC_QM_ID   QMLite_ID
#endif


typedef enum
{
  EIP96_CORE_TYPE = 0,
  XTS_CORE_TYPE = 1,
  EIP62_CORE_TYPE = 2
} sec_crypto_type;

void rst_sec(unsigned int rst_pattern);
void extern rst_sec_csr(void);
void extern rst_sec_axi(void);
void extern rst_sec_eip96(void);
void extern rst_sec_ext(void);
void extern rst_sec_eip62(void);
void stp_sec(int stp_pattern);
void extern stp_sec_csr(void);
void extern stp_sec_axi(void);
void extern stp_sec_eip96(void);
void extern stp_sec_ext(void);
void extern stp_sec_eip62(void);
void resume_sec(void);
void init_sec(void);
void sm_sec_init_ecc(void);
void build_sec_32b_src2sm_wq_msg(int qid, int fpqnum, int henqnum, int hfpsel,
                                      unsigned int bufdatalen, unsigned long long bufaddr,
                                      unsigned long long tknaddr, unsigned long long dstaddr, int user_info,
                                      enq_msg_header_queue* msg_header_queue_ptr);
void extern build_sec_32b_src2mm_wq_msg(int qid, int fpqnum, int henqnum, int hfpsel,
                                      unsigned int bufdatalen, unsigned long long bufaddr,
                                      unsigned long long tknaddr, unsigned long long dstlistptr, int listlen,
                                      int user_info,
                                      enq_msg_header_queue* msg_header_queue_ptr);
void build_sec_32b_src2buf_wq_msg(int qid, int fpqnum, int henqnum, int hfpsel,
                                  unsigned int bufdatalen, unsigned long long bufaddr,
                                  unsigned long long tknaddr, int user_info,
                                  enq_msg_header_queue* msg_header_queue_ptr);
void build_sec_64b_src2buf_wq_msg(int qid, int fpqnum, int henqnum, int hfpsel,
                                    int nxt_bufnum,
                                    unsigned int bufdatalen, unsigned long long bufaddr,
                                    unsigned int nxt_bufdatalen_1, unsigned long long nxt_bufaddr_1,
                                    unsigned int nxt_bufdatalen_2, unsigned long long nxt_bufaddr_2,
                                    unsigned int nxt_bufdatalen_3, unsigned long long nxt_bufaddr_3,
                                    unsigned int nxt_bufdatalen_4, unsigned long long nxt_bufaddr_4,
                                    unsigned long long tknaddr, int user_info,
                                    enq_msg_header_queue*  msg_header_queue_ptr);
void build_sec_16b_fp_msg(int qid, unsigned int bufdatalen, unsigned long long bufaddr, int user_info,
                          enq_msg_header_queue* msg_header_queue_ptr);
int chk_rslt_tkn(msg_16b_t* cm_msg_field1_ptr, unsigned long long expect_base_addr, int mem_len);
void build_sec_64b_sll_dll_wq_msg(int qid, int fpqnum, int henqnum, int hfpsel,
                                    int bufdatalen, unsigned long long bufaddr,
                                    int total_datalen_ll,
                                    int nxt_bufdatalen_1, unsigned long long nxt_bufaddr_1,
                                    int nxt_bufdatalen_2, unsigned long long nxt_bufaddr_2,
                                    int nxt_bufdatalen_3, unsigned long long nxt_bufaddr_3,
                                    unsigned long long sll_ptr, int sll_len,
                                    unsigned long long dll_ptr, int dll_len,
                                    unsigned long long tknaddr, int user_info,
                                    enq_msg_header_queue*  msg_header_queue_ptr);
void build_sec_64b_sll_bufmd_wq_msg(int qid, int fpqnum, int henqnum, int hfpsel,
                                    int bufdatalen, unsigned long long bufaddr,
                                    int total_datalen_ll,
                                    int nxt_bufdatalen_1, unsigned long long nxt_bufaddr_1,
                                    int nxt_bufdatalen_2, unsigned long long nxt_bufaddr_2,
                                    int nxt_bufdatalen_3, unsigned long long nxt_bufaddr_3,
                                    unsigned long long sll_ptr, int sll_len,
                                    unsigned long long tknaddr, int user_info,
                                    enq_msg_header_queue*  msg_header_queue_ptr);
void build_sec_bufmd_wq_msg(int qid, int fpqnum, int henqnum, int hfpsel,
                                    unsigned int num_of_buf, unsigned int cur_buf_pos,
                                    unsigned short* buf_len_ptr, unsigned long long* buf_addr_ptr,
                                    unsigned long long sll_ptr,
                                    unsigned long long tknaddr, int user_info,
                                    enq_msg_header_queue*  msg_header_queue_ptr);
void print_sec_cm_msg_err_info (msg_16b_t *deq_msg_0);
int gen_sec_user_info(unsigned char crypto_core_type);
int get_sec_wqid(unsigned char crypto_core_type);
int gen_sec_fpqid();
int get_sec_hfpsel(int fpqid);


#endif /* __SEC_DRIVER_H__ */
