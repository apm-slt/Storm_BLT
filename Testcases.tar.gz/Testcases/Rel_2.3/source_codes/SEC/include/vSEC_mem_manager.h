#ifndef __vSEC_MEM_MANAGER_H__
#define __vSEC_MEM_MANAGER_H__

#include "../include/vSEC_test_driver.h"
#include "../include/vSEC_globals.h"

/* Print debugging info?  1 for yes, 0 for no */
#if (1)
	#define DEBUG_vSEC_MEM_MANAGER
#endif

#ifdef DEBUG_vSEC_MEM_MANAGER
	#define debug_vsec_mem_manager(...)		printf(__VA_ARGS__)
#else
	#define debug_vsec_mem_manager
#endif

// Simple queue based memory manager
typedef struct
{
	unsigned long long mem_start;
	unsigned long long mem_len;
	unsigned long long alot_base; //Dynamic
	unsigned long long free_len; // Dynamic
	unsigned long long alot_entry[MAX_MEM_BUF];
	unsigned long long alot_pos;
	unsigned long long dlot_pos;
	unsigned long long num_of_entry;
} queue_mem_manager;

typedef enum
{
	A_BYTE,
	A_4BYTE,
	A_8BYTE,
	A_16BYTE,
	A_32BYTE,
	A_64BYTE,
	A_128BYTE,
} MEM_ALIGN_CODE;

typedef enum
{
	B_16KB,
	B_4KB,
	B_2KB,
	B_1KB,
	B_256B,
	B_FIT // Select this to choose a a fit buffer type, ex. if length is 255 then buffer type is 256B
} BUF_TYPE_CODE;

typedef struct
{
  unsigned int *mem_array_ptr;
  unsigned long long mem_len;
} mem_array_header;

typedef struct
{
  mem_array_header * mem_array_header_ptr;
  int queue_tail;
  int queue_head;
  int no_of_entry;
} mem_array_header_queue;

void init_queue_mem_manager(queue_mem_manager* mem_manager, unsigned long long start_base, unsigned long long mem_len);
unsigned int get_mem_align(unsigned long long mem_addr, MEM_ALIGN_CODE  align_code);
unsigned long long alot_mem(queue_mem_manager* mem_manager, unsigned long long mem_len, MEM_ALIGN_CODE align_code);
int dlot_mem(queue_mem_manager* mem_manager);
unsigned long long alot_free_mem(queue_mem_manager* mem_manager, unsigned long long mem_len, MEM_ALIGN_CODE align_code);
int gen_buf_len_code (unsigned long long buf_len, BUF_TYPE_CODE buf_type);
unsigned long long gen_rand_buf_len_code(unsigned long long buf_len);
unsigned long long get_buf_len (unsigned long long buf_len_code);
void load_mem(unsigned long long mem_addr, unsigned long long mem_len, unsigned int *mem_array_ptr);
void dump_mem(unsigned long long mem_addr, unsigned long long mem_len);
void write_mem_array_header(mem_array_header_queue* mem_array_header_queue_ptr, unsigned int *mem_array_ptr, unsigned int mem_len);
mem_array_header* read_mem_array_header(mem_array_header_queue* mem_array_header_queue_ptr);
int chk_mem_a_4byte(unsigned long long result_base_addr, unsigned long long expect_base_addr, unsigned int mem_len);
int chk_mem(unsigned long long result_base_addr, unsigned long long expect_base_addr, unsigned int mem_len);
void load_in_array_mem(mem_array_header_queue* mem_array_header_queue_ptr, queue_mem_manager* mem_manager_ptr,
					unsigned long long* mem_addr_ptr, unsigned long long* mem_len_ptr,
					MEM_ALIGN_CODE align_code, unsigned int base_offset);
void load_exp_array_mem(mem_array_header_queue* mem_array_header_queue_ptr, queue_mem_manager* mem_manager_ptr,
                  buf_header_queue *expt_buf_queue_ptr,
                  MEM_ALIGN_CODE align_code);


#endif /*__vSEC_MEM_MANAGER_H__*/

