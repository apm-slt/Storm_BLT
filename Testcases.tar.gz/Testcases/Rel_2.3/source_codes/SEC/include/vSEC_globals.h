//
// File name	: vSEC_globals.h
// Description	: Declaration of all global variables and constants
//

#ifndef __vSEC_GLOBALS_H__
#define __vSEC_GLOBALS_H__

#include "../include/vSEC_defines.h"

//--------------------------------------------------------------------------------
//Define Test case: 1 for active, 0 for inactive (only one test case active)
#define L0_SEC_EIP38_BULK_AES_XTS_ENC_128BIT_KEY			0 //32
#define L0_SEC_EIP62_BUFFER_MODE							0 //32
#define L0_SEC_EIP96_BUFFER_MODE							0
#define L1_SEC_EIP38_AXI_CTX_READ_ERROR_INT					0 //
#define	L1_SEC_EIP38_AXI_READ_ERROR_INT						0 //
#define L1_SEC_EIP38_AXI_TOKEN_READ_ERROR_INT				0 //
#define L1_SEC_EIP38_AXI_WRITE_ERROR_INT					0 //
#define L1_SEC_EIP38_BULK_AES_XTS_DEC_128BIT_KEY			0
#define L1_SEC_EIP38_BULK_AES_XTS_DEC_256BIT_KEY			0 //32
#define L1_SEC_EIP38_BULK_AES_XTS_DEC_256BIT_KEY_MULTMEM	0
#define L1_SEC_EIP38_BULK_AES_XTS_ENC_256BIT_KEY			0 //32
#define L1_SEC_EIP38_BULK_AES_XTS_ENC_256BIT_KEY_MULTMEM	0
#define L1_SEC_EIP38_CORE_INT								0 //
#define L1_SEC_EIP38_FP_ERROR								0 //
#define L1_SEC_EIP38_LERR_ERROR_INT							0 //
#define L1_SEC_EIP38_WQ_ERROR								0 //
#define L1_SEC_EIP62_AND_EIP38_PARALLEL_WORKING				0 //
#define L1_SEC_EIP62_AXI_CTX_READ_ERROR_INT					0 //
#define L1_SEC_EIP62_AXI_DSTLL_READ_ERROR_INT				0 //
#define L1_SEC_EIP62_AXI_READ_ERROR_INT						0 //
#define L1_SEC_EIP62_AXI_TOKEN_READ_ERROR_INT				0 //
#define L1_SEC_EIP62_AXI_WRITE_ERROR_INT					0 //
#define L1_SEC_EIP62_CORE_INT								0 //
#define L1_SEC_EIP62_ESP_IPV4_DEC							0 //
#define L1_SEC_EIP62_ESP_IPV4_DEC_CTX_REUSE					0 //
#define L1_SEC_EIP62_ESP_IPV4_ENC							0 //
#define L1_SEC_EIP62_FP_ERROR								0 //
#define L1_SEC_EIP62_LERR_ERROR_INT							0 //
#define L1_SEC_EIP62_MACSEC_DEC								0 //
#define L1_SEC_EIP62_MACSEC_ENC								0 //
#define L1_SEC_EIP62_MEMORY_MODE							0
#define L1_SEC_EIP62_MULTIPLE_SRC_BUFFER_MODE				0
#define L1_SEC_EIP62_MULTIPLE_SRC_MEMORY_MODE				0
#define L1_SEC_EIP62_WQ_ERROR								0 //
#define L1_SEC_EIP96_AND_EIP38_PARALLEL_WORKING				0 //
#define L1_SEC_EIP96_AXI_CTX_READ_ERROR_INT					0 //
#define L1_SEC_EIP96_AXI_DSTLL_READ_ERROR_INT				0 //
#define L1_SEC_EIP96_AXI_READ_ERROR_INT						0 //
#define L1_SEC_EIP96_AXI_TOKEN_READ_ERROR_INT				0 //
#define L1_SEC_EIP96_AXI_WRITE_ERROR_INT					0 //
#define L1_SEC_EIP96_CORE_INT								0 //
#define L1_SEC_EIP96_ESP_IPV4_DEC							0 //
#define L1_SEC_EIP96_ESP_IPV4_ENC							0 //
#define L1_SEC_EIP96_ESP_IPV4_ENC_CTX_REUSE					0 //
#define L1_SEC_EIP96_FP_ERROR								0 //
#define L1_SEC_EIP96_LERR_ERROR_INT							0 //
#define L1_SEC_EIP96_MACSEC_DEC								0 //
#define L1_SEC_EIP96_MACSEC_ENC								0 //
#define L1_SEC_EIP96_MD5_HASH								1//
#define L1_SEC_EIP96_MEMORY_MODE							0
#define L1_SEC_EIP96_MULTIPLE_SRC_BUFFER_MODE				0
#define L1_SEC_EIP96_MULTIPLE_SRC_MEMORY_MODE				0
#define L1_SEC_EIP96_SHA1_HASH								0 //
#define L1_SEC_EIP96_SHA224_HASH							0 //
#define L1_SEC_EIP96_SHA256_HASH							0 //
#define L1_SEC_EIP96_SHA384_HASH							0 //
#define L1_SEC_EIP96_SHA512_HASH							0 //
#define L1_SEC_EIP96_SSL_AES128_MD5_DEC						0 //-
#define L1_SEC_EIP96_SSL_AES128_MD5_DEC_CTX_REUSE			0 //-
#define L1_SEC_EIP96_SSL_AES128_SHA1_DEC					0 //-
#define L1_SEC_EIP96_SSL_AES128_SHA1_ENC					0 //-
#define L1_SEC_EIP96_SSL_DEC_32B_MSG						0
#define L1_SEC_EIP96_SSL_DEC_MEMORY_MODE					0 //-
#define L1_SEC_EIP96_SSL_ENC_32B_MSG						0
#define L1_SEC_EIP96_SSL_ENC_64B_MSG						0
#define L1_SEC_EIP96_SSL_ENC_DEC_TOGETHER					0 //-
#define L1_SEC_EIP96_SSL_ENC_MEMORY_MODE					0 //-
#define L1_SEC_EIP96_SSL_MAX_LINKED_LIST_BUFFER_MODE		0 //-
#define L1_SEC_EIP96_SSL_MAX_LINKED_LIST_MEMORY_MODE		0 //-
#define L1_SEC_EIP96_WQ_ERROR								0 //
#define L1_SEC_PROGRAMABLE_INT								0 //
#define L1_SEC_QMI_AXIWCMR_SLVERR_INT						0 //
#define L1_SEC_BASIC_PERFORMANCE							0

//--------------------------------------------------------------------------------

#define  CPU_OFFSET_ADDR        0x00000000  // In case of SOC, no offset is required

#define  MAX_NO_OF_ERROR        10 // Number of maximum errors to stop checking expected result

#if (L0_SEC_EIP38_BULK_AES_XTS_ENC_128BIT_KEY \
	| L0_SEC_EIP62_BUFFER_MODE \
	| L1_SEC_EIP38_BULK_AES_XTS_DEC_256BIT_KEY \
	| L1_SEC_EIP38_BULK_AES_XTS_ENC_256BIT_KEY)
	#define  MAX_MEM_BUF            32 			//Maximum number of input/output buffers
	#define  MAX_WK_MSG             32 			//Maximum number of work messages
	#define  MAX_FP_MSG             32 			//Maximum number of FP messages
	#define  MAX_NO_OF_QUEUE        32 			//Bigger is possible b/c QMTM1 is used
	#define  MAX_QUEUE_SIZE         0x800		//For DDR testing
#else
	#if (L1_SEC_BASIC_PERFORMANCE)
		#define  MAX_MEM_BUF            128 	//Maximum number of input/output buffers
		#define  MAX_WK_MSG             128 	//Maximum number of work messages
		#define  MAX_FP_MSG             128 	//Maximum number of FP messages
		#define  MAX_NO_OF_QUEUE        128 	//Bigger is possible b/c QMTM1 is used
		#define  MAX_QUEUE_SIZE         0x800	//For DDR testing
	#else
		#define  MAX_MEM_BUF            128 	//Maximum number of input/output buffers
		#define  MAX_WK_MSG             128 	//Maximum number of work messages
		#define  MAX_FP_MSG             128 	//Maximum number of FP messages
		#define  MAX_NO_OF_QUEUE        128		//Bigger is possible b/c QMTM1 is used
		#define  MAX_QUEUE_SIZE         0x80000//0x4000	//For DDR testing
	#endif
#endif

/////////////////////////
#define STORM_SEC

typedef enum
{
  QMTM0_ID = 0x0,
  QMTM1_ID = 0x1,
  QMTM2_ID = 0x2,
  QMLite_ID = 0x3,
} qm_id_map_t;

// Below is quite specific to SEC, consider to move to other places later
#ifdef STORM_SEC
	#define PRINT_DBG_MSG
	#include "vSEC_mem_manager.h"
	static queue_mem_manager *in_tkn_mem_manager_ptr;
	static queue_mem_manager *in_ctx_mem_manager_ptr;
	static queue_mem_manager *in_data_mem_manager_ptr;
	static queue_mem_manager *out_data_mem_manager_ptr;
	static queue_mem_manager *exp_tkn_mem_manager_ptr;
	static queue_mem_manager *exp_data_mem_manager_ptr;

//	static queue_mem_manager in_tkn_mem_manager1;
//	static queue_mem_manager in_ctx_mem_manager1;
//	static queue_mem_manager in_data_mem_manager1;
//	static queue_mem_manager out_data_mem_manager1;
//	static queue_mem_manager exp_tkn_mem_manager1;
//	static queue_mem_manager exp_data_mem_manager1;
//
//	static queue_mem_manager in_tkn_mem_manager2;
//	static queue_mem_manager in_ctx_mem_manager2;
//	static queue_mem_manager in_data_mem_manager2;
//	static queue_mem_manager out_data_mem_manager2;
//	static queue_mem_manager exp_tkn_mem_manager2;
//	static queue_mem_manager exp_data_mem_manager2;

//	static enq_msg_header wq_msg_header_array[MAX_WK_MSG];
//	static enq_msg_header fp_msg_header_array[MAX_FP_MSG];
//
//	static buf_header expt_buf_header_array[MAX_MEM_BUF];
//	static buf_header expt_tkn_header_array[MAX_WK_MSG];
//	static buf_header expt_deallot_header_array[MAX_FP_MSG];
//	static buf_header expt_cm_header_array[MAX_WK_MSG];
#endif

// Pointer to queue memory
//static unsigned long long enq_ptr[MAX_NO_OF_QUEUE];
//static unsigned long long deq_ptr[MAX_NO_OF_QUEUE];

// Seed of current executed test
int test_seed;
static int seed = 31;

int random(void);

#endif //__vSEC_GLOBALS_H__

