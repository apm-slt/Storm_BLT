/**
 *
 * Copyright (C) 2011 AppliedMicro Confidential Information
 * All Rights Reserved.
 *
 * THIS WORK CONTAINS PROPRIETARY INFORMATION WHICH IS THE PROPERTY OF
 * AppliedMicro AND IS SUBJECT TO THE TERMS OF NON-DISCLOSURE AGREEMENT
 * BETWEEN AppliedMicro AND THE COMPANY USING THIS FILE.
 *
 * WARNING !!!
 * This is an auto-generated C header file for register definitions 
 * PLEASE DON'T MANUALLY MODIFY IN THIS FILE AS CHANGES WILL BE LOST
 */
#ifndef __vSEC_QM_CSR_H__
#define __vSEC_QM_CSR_H__

#include "../include/vSEC_defines.h"

/*    Address QM_CSR  Registers */
#define CSR_IPBRR_ADDR                                               0x00000000
#define CSR_IPBRR_DEFAULT                                            0x00000070
#define CSR_QM_CONFIG_ADDR                                           0x00000004
#define CSR_QM_CONFIG_DEFAULT                                        0x00000000
#define CSR_PBM_ADDR                                                 0x00000008
#define CSR_PBM_DEFAULT                                              0x00000000
#define CSR_PBM_BUF_WR_ADDR                                          0x0000000c
#define CSR_PBM_BUF_WR_DEFAULT                                       0x00000000
#define CSR_PBM_BUF_RD_ADDR                                          0x00000010
#define CSR_PBM_BUF_RD_DEFAULT                                       0x00000000
#define CSR_PBM_COAL_ADDR                                            0x00000014
#define CSR_PBM_COAL_DEFAULT                                         0x00000109
#define CSR_PBM_CTICK0_ADDR                                          0x00000018
#define CSR_PBM_CTICK0_DEFAULT                                       0x00000000
#define CSR_PBM_CTICK1_ADDR                                          0x0000001c
#define CSR_PBM_CTICK1_DEFAULT                                       0x00000000
#define CSR_PBM_CTICK2_ADDR                                          0x00000020
#define CSR_PBM_CTICK2_DEFAULT                                       0x00000000
#define CSR_PBM_CTICK3_ADDR                                          0x00000024
#define CSR_PBM_CTICK3_DEFAULT                                       0x00000000
#define CSR_THRESHOLD0_SET0_ADDR                                     0x00000028
#define CSR_THRESHOLD0_SET0_DEFAULT                                  0x00000000
#define CSR_THRESHOLD1_SET0_ADDR                                     0x0000002c
#define CSR_THRESHOLD1_SET0_DEFAULT                                  0x00000000
#define CSR_THRESHOLD0_SET1_ADDR                                     0x00000030
#define CSR_THRESHOLD0_SET1_DEFAULT                                  0x00000000
#define CSR_THRESHOLD1_SET1_ADDR                                     0x00000034
#define CSR_THRESHOLD1_SET1_DEFAULT                                  0x00000000
#define CSR_THRESHOLD0_SET2_ADDR                                     0x00000038
#define CSR_THRESHOLD0_SET2_DEFAULT                                  0x00000000
#define CSR_THRESHOLD1_SET2_ADDR                                     0x0000003c
#define CSR_THRESHOLD1_SET2_DEFAULT                                  0x00000000
#define CSR_THRESHOLD0_SET3_ADDR                                     0x00000040
#define CSR_THRESHOLD0_SET3_DEFAULT                                  0x00000000
#define CSR_THRESHOLD1_SET3_ADDR                                     0x00000044
#define CSR_THRESHOLD1_SET3_DEFAULT                                  0x00000000
#define CSR_THRESHOLD0_SET4_ADDR                                     0x00000048
#define CSR_THRESHOLD0_SET4_DEFAULT                                  0x00000000
#define CSR_THRESHOLD1_SET4_ADDR                                     0x0000004c
#define CSR_THRESHOLD1_SET4_DEFAULT                                  0x00000000
#define CSR_THRESHOLD0_SET5_ADDR                                     0x00000050
#define CSR_THRESHOLD0_SET5_DEFAULT                                  0x00000000
#define CSR_THRESHOLD1_SET5_ADDR                                     0x00000054
#define CSR_THRESHOLD1_SET5_DEFAULT                                  0x00000000
#define CSR_THRESHOLD0_SET6_ADDR                                     0x00000058
#define CSR_THRESHOLD0_SET6_DEFAULT                                  0x00000000
#define CSR_THRESHOLD1_SET6_ADDR                                     0x0000005c
#define CSR_THRESHOLD1_SET6_DEFAULT                                  0x00000000
#define CSR_THRESHOLD0_SET7_ADDR                                     0x00000060
#define CSR_THRESHOLD0_SET7_DEFAULT                                  0x00000000
#define CSR_THRESHOLD1_SET7_ADDR                                     0x00000064
#define CSR_THRESHOLD1_SET7_DEFAULT                                  0x00000000
#define CSR_HYSTERESIS_ADDR                                          0x00000068
#define CSR_HYSTERESIS_DEFAULT                                       0x00000000
#define CSR_QSTATE_ADDR                                              0x0000006c
#define CSR_QSTATE_DEFAULT                                           0x00000000
#define CSR_QSTATE_WR_0_ADDR                                         0x00000070
#define CSR_QSTATE_WR_0_DEFAULT                                      0x00000000
#define CSR_QSTATE_WR_1_ADDR                                         0x00000074
#define CSR_QSTATE_WR_1_DEFAULT                                      0x00000000
#define CSR_QSTATE_WR_2_ADDR                                         0x00000078
#define CSR_QSTATE_WR_2_DEFAULT                                      0x00000000
#define CSR_QSTATE_WR_3_ADDR                                         0x0000007c
#define CSR_QSTATE_WR_3_DEFAULT                                      0x00000000
#define CSR_QSTATE_WR_4_ADDR                                         0x00000080
#define CSR_QSTATE_WR_4_DEFAULT                                      0x00000000
#define CSR_QSTATE_RD_0_ADDR                                         0x00000084
#define CSR_QSTATE_RD_0_DEFAULT                                      0x00000000
#define CSR_QSTATE_RD_1_ADDR                                         0x00000088
#define CSR_QSTATE_RD_1_DEFAULT                                      0x00000000
#define CSR_QSTATE_RD_2_ADDR                                         0x0000008c
#define CSR_QSTATE_RD_2_DEFAULT                                      0x00000000
#define CSR_QSTATE_RD_3_ADDR                                         0x00000090
#define CSR_QSTATE_RD_3_DEFAULT                                      0x00000000
#define CSR_QSTATE_RD_4_ADDR                                         0x00000094
#define CSR_QSTATE_RD_4_DEFAULT                                      0x00000000
#define CSR_CSTATE_WR_0_ADDR                                         0x0000009c
#define CSR_CSTATE_WR_0_DEFAULT                                      0x00000000
#define CSR_CSTATE_WR_1_ADDR                                         0x000000a0
#define CSR_CSTATE_WR_1_DEFAULT                                      0x00000000
#define CSR_CSTATE_RD_0_ADDR                                         0x000000a4
#define CSR_CSTATE_RD_0_DEFAULT                                      0x00000000
#define CSR_CSTATE_RD_1_ADDR                                         0x000000a8
#define CSR_CSTATE_RD_1_DEFAULT                                      0x00000000
#define CSR_CU_TIMER_ADDR                                            0x000000ac
#define CSR_CU_TIMER_DEFAULT                                         0x00000000
#define CSR_PROC_MBOX_BASE_0_ADDR                                    0x000000b0
#define CSR_PROC_MBOX_BASE_0_DEFAULT                                 0x00000000
#define CSR_PROC_MBOX_BASE_1_ADDR                                    0x000000b4
#define CSR_PROC_MBOX_BASE_1_DEFAULT                                 0x00000000
#define CSR_PROC_MBOX_BASE_2_ADDR                                    0x000000b8
#define CSR_PROC_MBOX_BASE_2_DEFAULT                                 0x00000000
#define CSR_PROC_MBOX_BASE_3_ADDR                                    0x000000bc
#define CSR_PROC_MBOX_BASE_3_DEFAULT                                 0x00000000
#define CSR_PROC_FPOOL_BASE_0_ADDR                                   0x000000c0
#define CSR_PROC_FPOOL_BASE_0_DEFAULT                                0x00000000
#define CSR_PROC_FPOOL_BASE_1_ADDR                                   0x000000c4
#define CSR_PROC_FPOOL_BASE_1_DEFAULT                                0x00000000
#define CSR_PROC_FPOOL_BASE_2_ADDR                                   0x000000c8
#define CSR_PROC_FPOOL_BASE_2_DEFAULT                                0x00000000
#define CSR_PROC_FPOOL_BASE_3_ADDR                                   0x000000cc
#define CSR_PROC_FPOOL_BASE_3_DEFAULT                                0x00000000
#define CSR_ENQ_BASE_0_ADDR                                          0x000000d4
#define CSR_ENQ_BASE_0_DEFAULT                                       0x00000000
#define CSR_ENQ_BASE_1_ADDR                                          0x000000d8
#define CSR_ENQ_BASE_1_DEFAULT                                       0x00000000
#define CSR_ENQ_BASE_2_ADDR                                          0x000000dc
#define CSR_ENQ_BASE_2_DEFAULT                                       0x00000000
#define CSR_ENQ_BASE_3_ADDR                                          0x000000e0
#define CSR_ENQ_BASE_3_DEFAULT                                       0x00000000
#define CSR_ENQ_STATUS_0_ADDR                                        0x000000e4
#define CSR_ENQ_STATUS_0_DEFAULT                                     0x00000000
#define CSR_ENQ_STATUS_1_ADDR                                        0x000000e8
#define CSR_ENQ_STATUS_1_DEFAULT                                     0x00000000
#define CSR_ENQ_STATUS_2_ADDR                                        0x000000ec
#define CSR_ENQ_STATUS_2_DEFAULT                                     0x00000000
#define CSR_ENQ_STATUS_3_ADDR                                        0x000000f0
#define CSR_ENQ_STATUS_3_DEFAULT                                     0x00000000
#define CSR_ENQ_STATUS_4_ADDR                                        0x000000f4
#define CSR_ENQ_STATUS_4_DEFAULT                                     0x00000000
#define CSR_ENQ_STATUS_5_ADDR                                        0x000000f8
#define CSR_ENQ_STATUS_5_DEFAULT                                     0x00000000
#define CSR_ENQ_STATUS_6_ADDR                                        0x000000fc
#define CSR_ENQ_STATUS_6_DEFAULT                                     0x00000000
#define CSR_ENQ_STATUS_7_ADDR                                        0x00000100
#define CSR_ENQ_STATUS_7_DEFAULT                                     0x00000000
#define CSR_ENQ_STATUS_8_ADDR                                        0x00000104
#define CSR_ENQ_STATUS_8_DEFAULT                                     0x00000000
#define CSR_ENQ_STATUS_9_ADDR                                        0x00000108
#define CSR_ENQ_STATUS_9_DEFAULT                                     0x00000000
#define CSR_ENQ_STATUS_10_ADDR                                       0x0000010c
#define CSR_ENQ_STATUS_10_DEFAULT                                    0x00000000
#define CSR_ENQ_STATUS_11_ADDR                                       0x00000110
#define CSR_ENQ_STATUS_11_DEFAULT                                    0x00000000
#define CSR_ENQ_STATUS_12_ADDR                                       0x00000114
#define CSR_ENQ_STATUS_12_DEFAULT                                    0x00000000
#define CSR_ENQ_STATUS_13_ADDR                                       0x00000118
#define CSR_ENQ_STATUS_13_DEFAULT                                    0x00000000
#define CSR_ENQ_STATUS_14_ADDR                                       0x0000011c
#define CSR_ENQ_STATUS_14_DEFAULT                                    0x00000000
#define CSR_ENQ_STATUS_15_ADDR                                       0x00000120
#define CSR_ENQ_STATUS_15_DEFAULT                                    0x00000000
#define QM_INTERRUPT_ADDR                                            0x00000124
#define QM_INTERRUPT_DEFAULT                                         0x00000000
#define QM_INTERRUPTMASK_ADDR                                        0x00000128
#define QM_SAB_QNE_INTERRUPT_ADDR                                    0x0000012c
#define QM_SAB_QNE_INTERRUPT_DEFAULT                                 0x00000000
#define QM_SAB_QNE_INTERRUPTMASK_ADDR                                0x00000130
#define CSR_PBM_ERRINF_ADDR                                          0x00000134
#define CSR_PBM_ERRINF_DEFAULT                                       0x00000000
#define CSR_MSGRD_ERRINF_ADDR                                        0x00000138
#define CSR_MSGRD_ERRINF_DEFAULT                                     0x00000000
#define CSR_QM_SAB_PROC0_ADDR                                        0x0000013c
#define CSR_QM_SAB_PROC0_DEFAULT                                     0x00000000
#define CSR_QM_SAB_PROC0MASK_ADDR                                    0x00000140
#define CSR_QM_SAB_PROC1_ADDR                                        0x00000144
#define CSR_QM_SAB_PROC1_DEFAULT                                     0x00000000
#define CSR_QM_SAB_PROC1MASK_ADDR                                    0x00000148
#define CSR_QM_SAB_PROC2_ADDR                                        0x0000014c
#define CSR_QM_SAB_PROC2_DEFAULT                                     0x00000000
#define CSR_QM_SAB_PROC2MASK_ADDR                                    0x00000150
#define CSR_QM_SAB_PROC3_ADDR                                        0x00000154
#define CSR_QM_SAB_PROC3_DEFAULT                                     0x00000000
#define CSR_QM_SAB_PROC3MASK_ADDR                                    0x00000158
#define CSR_QM_SAB_PROC4_ADDR                                        0x0000015c
#define CSR_QM_SAB_PROC4_DEFAULT                                     0x00000000
#define CSR_QM_SAB_PROC4MASK_ADDR                                    0x00000160
#define CSR_QM_SAB_PROC5_ADDR                                        0x00000164
#define CSR_QM_SAB_PROC5_DEFAULT                                     0x00000000
#define CSR_QM_SAB_PROC5MASK_ADDR                                    0x00000168
#define CSR_QM_SAB_PROC6_ADDR                                        0x0000016c
#define CSR_QM_SAB_PROC6_DEFAULT                                     0x00000000
#define CSR_QM_SAB_PROC6MASK_ADDR                                    0x00000170
#define CSR_QM_SAB_PROC7_ADDR                                        0x00000174
#define CSR_QM_SAB_PROC7_DEFAULT                                     0x00000000
#define CSR_QM_SAB_PROC7MASK_ADDR                                    0x00000178
#define CSR_QM_MBOX_NE_INT_MODE_ADDR                                 0x0000017c
#define CSR_QM_MBOX_NE_INT_MODE_DEFAULT                              0x00000000
#define CSR_QM_MBOX_NE_ADDR                                          0x00000180
#define CSR_QM_MBOX_NE_DEFAULT                                       0x00000000
#define CSR_PROC_SAB0_ADDR                                           0x00000184
#define CSR_PROC_SAB0_DEFAULT                                        0x00000000
#define CSR_PROC_SAB1_ADDR                                           0x00000188
#define CSR_PROC_SAB1_DEFAULT                                        0x00000000
#define CSR_PROC_SAB2_ADDR                                           0x0000018c
#define CSR_PROC_SAB2_DEFAULT                                        0x00000000
#define CSR_PROC_SAB3_ADDR                                           0x00000190
#define CSR_PROC_SAB3_DEFAULT                                        0x00000000
#define CSR_PROC_SAB4_ADDR                                           0x00000194
#define CSR_PROC_SAB4_DEFAULT                                        0x00000000
#define CSR_PROC_SAB5_ADDR                                           0x00000198
#define CSR_PROC_SAB5_DEFAULT                                        0x00000000
#define CSR_PROC_SAB6_ADDR                                           0x0000019c
#define CSR_PROC_SAB6_DEFAULT                                        0x00000000
#define CSR_PROC_SAB7_ADDR                                           0x000001a0
#define CSR_PROC_SAB7_DEFAULT                                        0x00000000
#define CSR_PROC_SAB8_ADDR                                           0x000001a4
#define CSR_PROC_SAB8_DEFAULT                                        0x00000000
#define CSR_PROC_SAB9_ADDR                                           0x000001a8
#define CSR_PROC_SAB9_DEFAULT                                        0x00000000
#define CSR_PROC_SAB10_ADDR                                          0x000001ac
#define CSR_PROC_SAB10_DEFAULT                                       0x00000000
#define CSR_PROC_SAB11_ADDR                                          0x000001b0
#define CSR_PROC_SAB11_DEFAULT                                       0x00000000
#define CSR_PROC_SAB12_ADDR                                          0x000001b4
#define CSR_PROC_SAB12_DEFAULT                                       0x00000000
#define CSR_PROC_SAB13_ADDR                                          0x000001b8
#define CSR_PROC_SAB13_DEFAULT                                       0x00000000
#define CSR_PROC_SAB14_ADDR                                          0x000001bc
#define CSR_PROC_SAB14_DEFAULT                                       0x00000000
#define CSR_PROC_SAB15_ADDR                                          0x000001c0
#define CSR_PROC_SAB15_DEFAULT                                       0x00000000
#define CSR_PROC_SAB16_ADDR                                          0x000001c4
#define CSR_PROC_SAB16_DEFAULT                                       0x00000000
#define CSR_PROC_SAB17_ADDR                                          0x000001c8
#define CSR_PROC_SAB17_DEFAULT                                       0x00000000
#define CSR_PROC_SAB18_ADDR                                          0x000001cc
#define CSR_PROC_SAB18_DEFAULT                                       0x00000000
#define CSR_PROC_SAB19_ADDR                                          0x000001d0
#define CSR_PROC_SAB19_DEFAULT                                       0x00000000
#define CSR_PROC_SAB20_ADDR                                          0x000001d4
#define CSR_PROC_SAB20_DEFAULT                                       0x00000000
#define CSR_PROC_SAB21_ADDR                                          0x000001d8
#define CSR_PROC_SAB21_DEFAULT                                       0x00000000
#define CSR_PROC_SAB22_ADDR                                          0x000001dc
#define CSR_PROC_SAB22_DEFAULT                                       0x00000000
#define CSR_PROC_SAB23_ADDR                                          0x000001e0
#define CSR_PROC_SAB23_DEFAULT                                       0x00000000
#define CSR_PROC_SAB24_ADDR                                          0x000001e4
#define CSR_PROC_SAB24_DEFAULT                                       0x00000000
#define CSR_PROC_SAB25_ADDR                                          0x000001e8
#define CSR_PROC_SAB25_DEFAULT                                       0x00000000
#define CSR_PROC_SAB26_ADDR                                          0x000001ec
#define CSR_PROC_SAB26_DEFAULT                                       0x00000000
#define CSR_PROC_SAB27_ADDR                                          0x000001f0
#define CSR_PROC_SAB27_DEFAULT                                       0x00000000
#define CSR_PROC_SAB28_ADDR                                          0x000001f4
#define CSR_PROC_SAB28_DEFAULT                                       0x00000000
#define CSR_PROC_SAB29_ADDR                                          0x000001f8
#define CSR_PROC_SAB29_DEFAULT                                       0x00000000
#define CSR_PROC_SAB30_ADDR                                          0x000001fc
#define CSR_PROC_SAB30_DEFAULT                                       0x00000000
#define CSR_PROC_SAB31_ADDR                                          0x00000200
#define CSR_PROC_SAB31_DEFAULT                                       0x00000000
#define CSR_QM_STATS_CFG_ADDR                                        0x00000204
#define CSR_QM_STATS_CFG_DEFAULT                                     0x00000000
#define CSR_ENQ_STATISTICS_ADDR                                      0x00000208
#define CSR_ENQ_STATISTICS_DEFAULT                                   0x00000000
#define CSR_DEQ_STATISTICS_ADDR                                      0x0000020c
#define CSR_DEQ_STATISTICS_DEFAULT                                   0x00000000
#define CSR_FIFO_STATUS_ADDR                                         0x00000210
#define CSR_FIFO_STATUS_DEFAULT                                      0x00000000
#define CSR_ACR_FIFO_CTRL_ADDR                                       0x00000214
#define CSR_ACR_FIFO_CTRL_DEFAULT                                    0xc0e08020
#define CSR_ERRQ_ADDR                                                0x00000218
#define CSR_ERRQ_DEFAULT                                             0x00000000
#define CSR_QM_RAM_MARGIN_ADDR                                       0x0000021c
#define CSR_QM_RAM_MARGIN_DEFAULT                                    0x00000000
#define CSR_QM_TESTINT0_ADDR                                         0x00000220
#define CSR_QM_TESTINT0_DEFAULT                                      0x00000000
#define CSR_QM_TESTINT1_ADDR                                         0x00000224
#define CSR_QM_TESTINT1_DEFAULT                                      0x00000000
#define CSR_QMLITE_PBN_MAP_0_ADDR                                    0x00000228
#define CSR_QMLITE_PBN_MAP_0_DEFAULT                                 0x00000000
#define CSR_QMLITE_PBN_MAP_1_ADDR                                    0x0000022c
#define CSR_QMLITE_PBN_MAP_1_DEFAULT                                 0x00000000
#define CSR_RECOMB_CTRL_0_ADDR                                       0x00000230
#define CSR_RECOMB_CTRL_0_DEFAULT                                    0x00000104
#define CSR_RECOMB_CTRL_1_ADDR                                       0x00000234
#define CSR_RECOMB_CTRL_1_DEFAULT                                    0x02080208
#define CSR_RECOMB_CTRL_2_ADDR                                       0x00000238
#define CSR_RECOMB_CTRL_2_DEFAULT                                    0x80202020
#define CSR_QM_RECOMB_RAM_MARGIN_ADDR                                0x00000240
#define CSR_QM_RECOMB_RAM_MARGIN_DEFAULT                             0x00000000
#define CSR_RECOMB_STS_0_ADDR                                        0x00000244
#define CSR_RECOMB_STS_0_DEFAULT                                     0x000001ff
#define CSR_RECOMB_STS_1_ADDR                                        0x00000248
#define CSR_RECOMB_STS_1_DEFAULT                                     0xffffffff
#define CSR_RECOMB_STS_2_ADDR                                        0x0000024c
#define CSR_RECOMB_STS_2_DEFAULT                                     0xffffffff
#define RECOMB_INTERRUPT_ADDR                                        0x00000250
#define RECOMB_INTERRUPT_DEFAULT                                     0x00000000
#define RECOMB_INTERRUPTMASK_ADDR                                    0x00000254
#define CSR_DEQ_CTRL_0_ADDR                                          0x00000258
#define CSR_DEQ_CTRL_0_DEFAULT                                       0x00000007
#define CSR_MPIC_CTRL_0_ADDR                                         0x0000025c
#define CSR_MPIC_CTRL_0_DEFAULT                                      0x00000001
#define CSR_MISC_CTRL_0_ADDR                                         0x00000260
#define CSR_MISC_CTRL_0_DEFAULT                                      0x00000000
#define PBM_DIAGDATA_CTRL_0_ADDR                                     0x00000264
#define PBM_DIAGDATA_CTRL_0_DEFAULT                                  0x00000000

/*	Register csr_ipbrr	*/

/*	 Fields revno	 */
#define REGSPEC_REVNO_F1_LE_WIDTH                                             2
#define REGSPEC_REVNO_F1_LE_SHIFT                                            17
#define REGSPEC_REVNO_F1_LE_MASK                                     0x00c00000
#define REGSPEC_REVNO_F1_LE_RD(src)                (((src) & 0x00c00000) >> 22)
#define REGSPEC_REVNO_F1_LE_SET(dst,src)                  ((dst) & ~0x00c00000)| \
				(((unsigned int)(src) << 22) & 0x00c00000)

/*	 Fields busid	 */
#define REGSPEC_BUSID_F1_LE_WIDTH                                             2
#define REGSPEC_BUSID_F1_LE_SHIFT                                            19
#define REGSPEC_BUSID_F1_LE_MASK                                     0x00300000
#define REGSPEC_BUSID_F1_LE_RD(src)                (((src) & 0x00300000) >> 20)
#define REGSPEC_BUSID_F1_LE_SET(dst,src)                  ((dst) & ~0x00300000)| \
				(((unsigned int)(src) << 20) & 0x00300000)

/*	 Fields deviceid	 */
#define REGSPEC_DEVICEID_F1_LE_WIDTH                                         12
#define REGSPEC_DEVICEID_F1_LE_SHIFT                                         31
#define REGSPEC_DEVICEID_F1_LE_MASK                                  0xff0f0000
#define REGSPEC_DEVICEID_F1_LE_RD(src)               	(((src) & 0xff000000) >> 24) |\
				(((src) & 0x000f0000) >> 8)
#define REGSPEC_DEVICEID_F1_LE_SET(dst,src) ((dst)&~0xff0f0000)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x000f0000)

/*	Register csr_qm_config	*/

/*	 Fields enable	 */
#define REGSPEC_ENABLE_F1_LE_WIDTH                                            1
#define REGSPEC_ENABLE_F1_LE_SHIFT                                            0
#define REGSPEC_ENABLE_F1_LE_MASK                                    0x00000080
#define REGSPEC_ENABLE_F1_LE_RD(src)                 (((src) & 0x00000080)<< 7)
#define REGSPEC_ENABLE_F1_LE_WR(src)           (((unsigned int)(src) >> 7) & 0x00000080)
#define REGSPEC_ENABLE_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields erq_ovr_protect	 */
#define ERQ_OVR_PROTECT_F1_LE_WIDTH                                           1
#define ERQ_OVR_PROTECT_F1_LE_SHIFT                                           1
#define ERQ_OVR_PROTECT_F1_LE_MASK                                   0x00000040
#define ERQ_OVR_PROTECT_F1_LE_RD(src)                (((src) & 0x00000040)<< 6)
#define ERQ_OVR_PROTECT_F1_LE_WR(src)          (((unsigned int)(src) >> 6) & 0x00000040)
#define ERQ_OVR_PROTECT_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields mbox_enq_status_toggle_mode	 */
#define REGSPEC_MBOX_ENQ_STATUS_TOGGLE_MODE_F1_LE_WIDTH                       1
#define REGSPEC_MBOX_ENQ_STATUS_TOGGLE_MODE_F1_LE_SHIFT                       2
#define REGSPEC_MBOX_ENQ_STATUS_TOGGLE_MODE_F1_LE_MASK               0x00000020
#define REGSPEC_MBOX_ENQ_STATUS_TOGGLE_MODE_F1_LE_RD(src)                                                     (((src) & 0x00000020)<< 5)
#define REGSPEC_MBOX_ENQ_STATUS_TOGGLE_MODE_F1_LE_WR(src)                                                (((unsigned int)(src) >> 5) & 0x00000020)
#define REGSPEC_MBOX_ENQ_STATUS_TOGGLE_MODE_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*	Register csr_pbm	*/

/*	 Fields overwrite	 */
#define OVERWRITE_F1_LE_WIDTH                                                 1
#define OVERWRITE_F1_LE_SHIFT                                                 0
#define OVERWRITE_F1_LE_MASK                                         0x00000080
#define OVERWRITE_F1_LE_RD(src)                      (((src) & 0x00000080)<< 7)
#define OVERWRITE_F1_LE_WR(src)                (((unsigned int)(src) >> 7) & 0x00000080)
#define OVERWRITE_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields slvid_pbn	 */
#define SLVID_PBN_F1_LE_WIDTH                                                10
#define SLVID_PBN_F1_LE_SHIFT                                                31
#define SLVID_PBN_F1_LE_MASK                                         0xff030000
#define SLVID_PBN_F1_LE_RD(src)               	(((src) & 0xff000000) >> 24) |\
				(((src) & 0x00030000) >> 8)
#define SLVID_PBN_F1_LE_WR(src)      	(((unsigned int)(src) << 24) & 0xff000000) |\
				(((unsigned int)(src) << 8) & 0x00030000)
#define SLVID_PBN_F1_LE_SET(dst,src) ((dst)&~0xff030000)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00030000)

/*	Register csr_pbm_buf_wr	*/

/*	 Fields pb_size	 */
#define PB_SIZE_F2_LE_WIDTH                                                   1
#define PB_SIZE_F2_LE_SHIFT                                                   0
#define PB_SIZE_F2_LE_MASK                                           0x00000080
#define PB_SIZE_F2_LE_RD(src)                        (((src) & 0x00000080)<< 7)
#define PB_SIZE_F2_LE_WR(src)                  (((unsigned int)(src) >> 7) & 0x00000080)
#define PB_SIZE_F2_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields in_service_clr	 */
#define IN_SERVICE_CLR_F1_LE_WIDTH                                            1
#define IN_SERVICE_CLR_F1_LE_SHIFT                                            1
#define IN_SERVICE_CLR_F1_LE_MASK                                    0x00000040
#define IN_SERVICE_CLR_F1_LE_RD(src)                 (((src) & 0x00000040)<< 6)
#define IN_SERVICE_CLR_F1_LE_WR(src)           (((unsigned int)(src) >> 6) & 0x00000040)
#define IN_SERVICE_CLR_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields data	 */
#define DATA_F1_LE_WIDTH                                                     30
#define DATA_F1_LE_SHIFT                                                     31
#define DATA_F1_LE_MASK                                              0xffffff3f
#define DATA_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x0000003f) << 24)
#define DATA_F1_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x0000003f)
#define DATA_F1_LE_SET(dst,src) 	((dst)&~0xffffff3f)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x0000003f)

/*	Register csr_pbm_buf_rd	*/

/*	 Fields pb_size	 */
#define PB_SIZE_F3_LE_WIDTH                                                   1
#define PB_SIZE_F3_LE_SHIFT                                                   0
#define PB_SIZE_F3_LE_MASK                                           0x00000080
#define PB_SIZE_F3_LE_RD(src)                        (((src) & 0x00000080)<< 7)
#define PB_SIZE_F3_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields pb_in_service	 */
#define PB_IN_SERVICE_F1_LE_WIDTH                                             1
#define PB_IN_SERVICE_F1_LE_SHIFT                                             1
#define PB_IN_SERVICE_F1_LE_MASK                                     0x00000040
#define PB_IN_SERVICE_F1_LE_RD(src)                  (((src) & 0x00000040)<< 6)
#define PB_IN_SERVICE_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields slot_num	 */
#define SLOT_NUM_F1_LE_WIDTH                                                  8
#define SLOT_NUM_F1_LE_SHIFT                                                  9
#define SLOT_NUM_F1_LE_MASK                                          0x0000c03f
#define SLOT_NUM_F1_LE_RD(src)               (((src) & 0x0000c000 )>> 14) | \
				(((src) & 0x0000003f) << 2)
#define SLOT_NUM_F1_LE_SET(dst,src) ((dst) & ~0x0000c03f) | \
	(((unsigned int)(src) << 14) & 0x0000c000) | (((unsigned int)(src) >> 2) & 0x0000003f)

/*	 Fields prefetch_buf_en	 */
#define PREFETCH_BUF_EN_F1_LE_WIDTH                                           1
#define PREFETCH_BUF_EN_F1_LE_SHIFT                                          10
#define PREFETCH_BUF_EN_F1_LE_MASK                                   0x00002000
#define PREFETCH_BUF_EN_F1_LE_RD(src)              (((src) & 0x00002000) >> 13)
#define PREFETCH_BUF_EN_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*	 Fields is_free_pool	 */
#define IS_FREE_POOL_F1_LE_WIDTH                                              1
#define IS_FREE_POOL_F1_LE_SHIFT                                             11
#define IS_FREE_POOL_F1_LE_MASK                                      0x00001000
#define IS_FREE_POOL_F1_LE_RD(src)                 (((src) & 0x00001000) >> 12)
#define IS_FREE_POOL_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*	 Fields tlvq	 */
#define TLVQ_F1_LE_WIDTH                                                      1
#define TLVQ_F1_LE_SHIFT                                                     12
#define TLVQ_F1_LE_MASK                                              0x00000800
#define TLVQ_F1_LE_RD(src)                         (((src) & 0x00000800) >> 11)
#define TLVQ_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*	 Fields corresponding_qnum	 */
#define CORRESPONDING_QNUM_F1_LE_WIDTH                                       10
#define CORRESPONDING_QNUM_F1_LE_SHIFT                                       22
#define CORRESPONDING_QNUM_F1_LE_MASK                                0x00fe0700
#define CORRESPONDING_QNUM_F1_LE_RD(src)               (((src) & 0x00fe0000) >> 17) | \
				(((src) & 0x00000700) >> 1)
#define CORRESPONDING_QNUM_F1_LE_SET(dst,src) ((dst) & ~0x00fe0700)| \
	(((unsigned int)(src) << 17) & 0x00fe0000)  | (((unsigned int)(src) << 17) & 0x00fe0000)

/*	 Fields num_msgs_in_buf	 */
#define NUM_MSGS_IN_BUF_F1_LE_WIDTH                                           9
#define NUM_MSGS_IN_BUF_F1_LE_SHIFT                                          31
#define NUM_MSGS_IN_BUF_F1_LE_MASK                                   0xff010000
#define NUM_MSGS_IN_BUF_F1_LE_RD(src)               	(((src) & 0xff000000) >> 24) |\
				(((src) & 0x00010000) >> 8)
#define NUM_MSGS_IN_BUF_F1_LE_SET(dst,src) ((dst)&~0xff010000)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00010000)

/*	Register csr_pbm_coal	*/

/*	 Fields qne_ctick_sel	 */
#define QNE_CTICK_SEL_F1_LE_WIDTH                                             3
#define QNE_CTICK_SEL_F1_LE_SHIFT                                             3
#define QNE_CTICK_SEL_F1_LE_MASK                                     0x00000070
#define QNE_CTICK_SEL_F1_LE_RD(src)                  (((src) & 0x00000070)<< 4)
#define QNE_CTICK_SEL_F1_LE_WR(src)            (((unsigned int)(src) >> 4) & 0x00000070)
#define QNE_CTICK_SEL_F1_LE_SET(dst,src)                   ((dst) & ~0x00000070) |\
			 (((unsigned int)(src) >> 4) & 0x00000070)

/*	 Fields observe_ctick_7	 */
#define OBSERVE_CTICK_7_F1_LE_WIDTH                                           1
#define OBSERVE_CTICK_7_F1_LE_SHIFT                                           4
#define OBSERVE_CTICK_7_F1_LE_MASK                                   0x00000008
#define OBSERVE_CTICK_7_F1_LE_RD(src)                (((src) & 0x00000008)<< 3)
#define OBSERVE_CTICK_7_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*	 Fields count_range	 */
#define COUNT_RANGE_F1_LE_WIDTH                                              16
#define COUNT_RANGE_F1_LE_SHIFT                                              31
#define COUNT_RANGE_F1_LE_MASK                                       0xffff0000
#define COUNT_RANGE_F1_LE_RD(src)               	(((src) & 0xff000000) >> 24) |\
				(((src) & 0x00ff0000) >> 8)
#define COUNT_RANGE_F1_LE_WR(src)      	(((unsigned int)(src) << 24) & 0xff000000) |\
				(((unsigned int)(src) << 8) & 0x00ff0000)
#define COUNT_RANGE_F1_LE_SET(dst,src) ((dst)&~0xffff0000)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00ff0000)

/*	Register csr_pbm_ctick0	*/

/*	 Fields mbox0	 */
#define MBOX00_F1_LE_WIDTH                                                    3
#define MBOX00_F1_LE_SHIFT                                                    3
#define MBOX00_F1_LE_MASK                                            0x00000070
#define MBOX00_F1_LE_RD(src)                         (((src) & 0x00000070)<< 4)
#define MBOX00_F1_LE_WR(src)                   (((unsigned int)(src) >> 4) & 0x00000070)
#define MBOX00_F1_LE_SET(dst,src)                   ((dst) & ~0x00000070) |\
			 (((unsigned int)(src) >> 4) & 0x00000070)

/*	 Fields mbox1	 */
#define MBOX10_F1_LE_WIDTH                                                    3
#define MBOX10_F1_LE_SHIFT                                                    7
#define MBOX10_F1_LE_MASK                                            0x00000007
#define MBOX10_F1_LE_RD(src)                         (((src) & 0x00000007)<< 0)
#define MBOX10_F1_LE_WR(src)                   (((unsigned int)(src) >> 0) & 0x00000007)
#define MBOX10_F1_LE_SET(dst,src)                   ((dst) & ~0x00000007) |\
			 (((unsigned int)(src) >> 0) & 0x00000007)

/*	 Fields mbox2	 */
#define MBOX20_F1_LE_WIDTH                                                    3
#define MBOX20_F1_LE_SHIFT                                                   11
#define MBOX20_F1_LE_MASK                                            0x00007000
#define MBOX20_F1_LE_RD(src)                       (((src) & 0x00007000) >> 12)
#define MBOX20_F1_LE_WR(src)                  (((unsigned int)(src) << 12) & 0x00007000)
#define MBOX20_F1_LE_SET(dst,src)                ((dst) & ~0x00007000) |  \
				(((unsigned int)(src) << 12) & 0x00007000)

/*	 Fields mbox3	 */
#define MBOX30_F1_LE_WIDTH                                                    3
#define MBOX30_F1_LE_SHIFT                                                   15
#define MBOX30_F1_LE_MASK                                            0x00000700
#define MBOX30_F1_LE_RD(src)                        (((src) & 0x00000700) >> 8)
#define MBOX30_F1_LE_WR(src)                   (((unsigned int)(src) << 8) & 0x00000700)
#define MBOX30_F1_LE_SET(dst,src)                 ((dst) & ~0x00000700) |  \
				(((unsigned int)(src) << 8) & 0x00000700)

/*	 Fields mbox4	 */
#define MBOX40_F1_LE_WIDTH                                                    3
#define MBOX40_F1_LE_SHIFT                                                   19
#define MBOX40_F1_LE_MASK                                            0x00700000
#define MBOX40_F1_LE_RD(src)                       (((src) & 0x00700000) >> 20)
#define MBOX40_F1_LE_WR(src)                  (((unsigned int)(src) << 20) & 0x00700000)
#define MBOX40_F1_LE_SET(dst,src)                  ((dst) & ~0x00700000)| \
				(((unsigned int)(src) << 20) & 0x00700000)

/*	 Fields mbox5	 */
#define MBOX50_F1_LE_WIDTH                                                    3
#define MBOX50_F1_LE_SHIFT                                                   23
#define MBOX50_F1_LE_MASK                                            0x00070000
#define MBOX50_F1_LE_RD(src)                       (((src) & 0x00070000) >> 16)
#define MBOX50_F1_LE_WR(src)                  (((unsigned int)(src) << 16) & 0x00070000)
#define MBOX50_F1_LE_SET(dst,src)                  ((dst) & ~0x00070000)| \
				(((unsigned int)(src) << 16) & 0x00070000)

/*	 Fields mbox6	 */
#define MBOX60_F1_LE_WIDTH                                                    3
#define MBOX60_F1_LE_SHIFT                                                   27
#define MBOX60_F1_LE_MASK                                            0x70000000
#define MBOX60_F1_LE_RD(src)                       (((src) & 0x70000000) >> 28)
#define MBOX60_F1_LE_WR(src)                  (((unsigned int)(src) << 28) & 0x70000000)
#define MBOX60_F1_LE_SET(dst,src)                     ((dst)&~0x70000000)|\
				(((unsigned int)(src) << 28) & 0x70000000)

/*	 Fields mbox7	 */
#define MBOX70_F1_LE_WIDTH                                                    3
#define MBOX70_F1_LE_SHIFT                                                   31
#define MBOX70_F1_LE_MASK                                            0x07000000
#define MBOX70_F1_LE_RD(src)                       (((src) & 0x07000000) >> 24)
#define MBOX70_F1_LE_WR(src)                  (((unsigned int)(src) << 24) & 0x07000000)
#define MBOX70_F1_LE_SET(dst,src)                     ((dst)&~0x07000000)|\
				(((unsigned int)(src) << 24) & 0x07000000)

/*	Register csr_pbm_ctick1	*/

/*	 Fields mbox8	 */
#define MBOX81_F1_LE_WIDTH                                                    3
#define MBOX81_F1_LE_SHIFT                                                    3
#define MBOX81_F1_LE_MASK                                            0x00000070
#define MBOX81_F1_LE_RD(src)                         (((src) & 0x00000070)<< 4)
#define MBOX81_F1_LE_WR(src)                   (((unsigned int)(src) >> 4) & 0x00000070)
#define MBOX81_F1_LE_SET(dst,src)                   ((dst) & ~0x00000070) |\
			 (((unsigned int)(src) >> 4) & 0x00000070)

/*	 Fields mbox9	 */
#define MBOX91_F1_LE_WIDTH                                                    3
#define MBOX91_F1_LE_SHIFT                                                    7
#define MBOX91_F1_LE_MASK                                            0x00000007
#define MBOX91_F1_LE_RD(src)                         (((src) & 0x00000007)<< 0)
#define MBOX91_F1_LE_WR(src)                   (((unsigned int)(src) >> 0) & 0x00000007)
#define MBOX91_F1_LE_SET(dst,src)                   ((dst) & ~0x00000007) |\
			 (((unsigned int)(src) >> 0) & 0x00000007)

/*	 Fields mbox10	 */
#define MBOX101_F1_LE_WIDTH                                                   3
#define MBOX101_F1_LE_SHIFT                                                  11
#define MBOX101_F1_LE_MASK                                           0x00007000
#define MBOX101_F1_LE_RD(src)                      (((src) & 0x00007000) >> 12)
#define MBOX101_F1_LE_WR(src)                 (((unsigned int)(src) << 12) & 0x00007000)
#define MBOX101_F1_LE_SET(dst,src)                ((dst) & ~0x00007000) |  \
				(((unsigned int)(src) << 12) & 0x00007000)

/*	 Fields mbox11	 */
#define MBOX111_F1_LE_WIDTH                                                   3
#define MBOX111_F1_LE_SHIFT                                                  15
#define MBOX111_F1_LE_MASK                                           0x00000700
#define MBOX111_F1_LE_RD(src)                       (((src) & 0x00000700) >> 8)
#define MBOX111_F1_LE_WR(src)                  (((unsigned int)(src) << 8) & 0x00000700)
#define MBOX111_F1_LE_SET(dst,src)                 ((dst) & ~0x00000700) |  \
				(((unsigned int)(src) << 8) & 0x00000700)

/*	 Fields mbox12	 */
#define MBOX121_F1_LE_WIDTH                                                   3
#define MBOX121_F1_LE_SHIFT                                                  19
#define MBOX121_F1_LE_MASK                                           0x00700000
#define MBOX121_F1_LE_RD(src)                      (((src) & 0x00700000) >> 20)
#define MBOX121_F1_LE_WR(src)                 (((unsigned int)(src) << 20) & 0x00700000)
#define MBOX121_F1_LE_SET(dst,src)                  ((dst) & ~0x00700000)| \
				(((unsigned int)(src) << 20) & 0x00700000)

/*	 Fields mbox13	 */
#define MBOX131_F1_LE_WIDTH                                                   3
#define MBOX131_F1_LE_SHIFT                                                  23
#define MBOX131_F1_LE_MASK                                           0x00070000
#define MBOX131_F1_LE_RD(src)                      (((src) & 0x00070000) >> 16)
#define MBOX131_F1_LE_WR(src)                 (((unsigned int)(src) << 16) & 0x00070000)
#define MBOX131_F1_LE_SET(dst,src)                  ((dst) & ~0x00070000)| \
				(((unsigned int)(src) << 16) & 0x00070000)

/*	 Fields mbox14	 */
#define MBOX141_F1_LE_WIDTH                                                   3
#define MBOX141_F1_LE_SHIFT                                                  27
#define MBOX141_F1_LE_MASK                                           0x70000000
#define MBOX141_F1_LE_RD(src)                      (((src) & 0x70000000) >> 28)
#define MBOX141_F1_LE_WR(src)                 (((unsigned int)(src) << 28) & 0x70000000)
#define MBOX141_F1_LE_SET(dst,src)                     ((dst)&~0x70000000)|\
				(((unsigned int)(src) << 28) & 0x70000000)

/*	 Fields mbox15	 */
#define MBOX151_F1_LE_WIDTH                                                   3
#define MBOX151_F1_LE_SHIFT                                                  31
#define MBOX151_F1_LE_MASK                                           0x07000000
#define MBOX151_F1_LE_RD(src)                      (((src) & 0x07000000) >> 24)
#define MBOX151_F1_LE_WR(src)                 (((unsigned int)(src) << 24) & 0x07000000)
#define MBOX151_F1_LE_SET(dst,src)                     ((dst)&~0x07000000)|\
				(((unsigned int)(src) << 24) & 0x07000000)

/*	Register csr_pbm_ctick2	*/

/*	 Fields mbox16	 */
#define MBOX162_F1_LE_WIDTH                                                   3
#define MBOX162_F1_LE_SHIFT                                                   3
#define MBOX162_F1_LE_MASK                                           0x00000070
#define MBOX162_F1_LE_RD(src)                        (((src) & 0x00000070)<< 4)
#define MBOX162_F1_LE_WR(src)                  (((unsigned int)(src) >> 4) & 0x00000070)
#define MBOX162_F1_LE_SET(dst,src)                   ((dst) & ~0x00000070) |\
			 (((unsigned int)(src) >> 4) & 0x00000070)

/*	 Fields mbox17	 */
#define MBOX172_F1_LE_WIDTH                                                   3
#define MBOX172_F1_LE_SHIFT                                                   7
#define MBOX172_F1_LE_MASK                                           0x00000007
#define MBOX172_F1_LE_RD(src)                        (((src) & 0x00000007)<< 0)
#define MBOX172_F1_LE_WR(src)                  (((unsigned int)(src) >> 0) & 0x00000007)
#define MBOX172_F1_LE_SET(dst,src)                   ((dst) & ~0x00000007) |\
			 (((unsigned int)(src) >> 0) & 0x00000007)

/*	 Fields mbox18	 */
#define MBOX182_F1_LE_WIDTH                                                   3
#define MBOX182_F1_LE_SHIFT                                                  11
#define MBOX182_F1_LE_MASK                                           0x00007000
#define MBOX182_F1_LE_RD(src)                      (((src) & 0x00007000) >> 12)
#define MBOX182_F1_LE_WR(src)                 (((unsigned int)(src) << 12) & 0x00007000)
#define MBOX182_F1_LE_SET(dst,src)                ((dst) & ~0x00007000) |  \
				(((unsigned int)(src) << 12) & 0x00007000)

/*	 Fields mbox19	 */
#define MBOX192_F1_LE_WIDTH                                                   3
#define MBOX192_F1_LE_SHIFT                                                  15
#define MBOX192_F1_LE_MASK                                           0x00000700
#define MBOX192_F1_LE_RD(src)                       (((src) & 0x00000700) >> 8)
#define MBOX192_F1_LE_WR(src)                  (((unsigned int)(src) << 8) & 0x00000700)
#define MBOX192_F1_LE_SET(dst,src)                 ((dst) & ~0x00000700) |  \
				(((unsigned int)(src) << 8) & 0x00000700)

/*	 Fields mbox20	 */
#define MBOX202_F1_LE_WIDTH                                                   3
#define MBOX202_F1_LE_SHIFT                                                  19
#define MBOX202_F1_LE_MASK                                           0x00700000
#define MBOX202_F1_LE_RD(src)                      (((src) & 0x00700000) >> 20)
#define MBOX202_F1_LE_WR(src)                 (((unsigned int)(src) << 20) & 0x00700000)
#define MBOX202_F1_LE_SET(dst,src)                  ((dst) & ~0x00700000)| \
				(((unsigned int)(src) << 20) & 0x00700000)

/*	 Fields mbox21	 */
#define MBOX212_F1_LE_WIDTH                                                   3
#define MBOX212_F1_LE_SHIFT                                                  23
#define MBOX212_F1_LE_MASK                                           0x00070000
#define MBOX212_F1_LE_RD(src)                      (((src) & 0x00070000) >> 16)
#define MBOX212_F1_LE_WR(src)                 (((unsigned int)(src) << 16) & 0x00070000)
#define MBOX212_F1_LE_SET(dst,src)                  ((dst) & ~0x00070000)| \
				(((unsigned int)(src) << 16) & 0x00070000)

/*	 Fields mbox22	 */
#define MBOX222_F1_LE_WIDTH                                                   3
#define MBOX222_F1_LE_SHIFT                                                  27
#define MBOX222_F1_LE_MASK                                           0x70000000
#define MBOX222_F1_LE_RD(src)                      (((src) & 0x70000000) >> 28)
#define MBOX222_F1_LE_WR(src)                 (((unsigned int)(src) << 28) & 0x70000000)
#define MBOX222_F1_LE_SET(dst,src)                     ((dst)&~0x70000000)|\
				(((unsigned int)(src) << 28) & 0x70000000)

/*	 Fields mbox23	 */
#define MBOX232_F1_LE_WIDTH                                                   3
#define MBOX232_F1_LE_SHIFT                                                  31
#define MBOX232_F1_LE_MASK                                           0x07000000
#define MBOX232_F1_LE_RD(src)                      (((src) & 0x07000000) >> 24)
#define MBOX232_F1_LE_WR(src)                 (((unsigned int)(src) << 24) & 0x07000000)
#define MBOX232_F1_LE_SET(dst,src)                     ((dst)&~0x07000000)|\
				(((unsigned int)(src) << 24) & 0x07000000)

/*	Register csr_pbm_ctick3	*/

/*	 Fields mbox24	 */
#define MBOX243_F1_LE_WIDTH                                                   3
#define MBOX243_F1_LE_SHIFT                                                   3
#define MBOX243_F1_LE_MASK                                           0x00000070
#define MBOX243_F1_LE_RD(src)                        (((src) & 0x00000070)<< 4)
#define MBOX243_F1_LE_WR(src)                  (((unsigned int)(src) >> 4) & 0x00000070)
#define MBOX243_F1_LE_SET(dst,src)                   ((dst) & ~0x00000070) |\
			 (((unsigned int)(src) >> 4) & 0x00000070)

/*	 Fields mbox25	 */
#define MBOX253_F1_LE_WIDTH                                                   3
#define MBOX253_F1_LE_SHIFT                                                   7
#define MBOX253_F1_LE_MASK                                           0x00000007
#define MBOX253_F1_LE_RD(src)                        (((src) & 0x00000007)<< 0)
#define MBOX253_F1_LE_WR(src)                  (((unsigned int)(src) >> 0) & 0x00000007)
#define MBOX253_F1_LE_SET(dst,src)                   ((dst) & ~0x00000007) |\
			 (((unsigned int)(src) >> 0) & 0x00000007)

/*	 Fields mbox26	 */
#define MBOX263_F1_LE_WIDTH                                                   3
#define MBOX263_F1_LE_SHIFT                                                  11
#define MBOX263_F1_LE_MASK                                           0x00007000
#define MBOX263_F1_LE_RD(src)                      (((src) & 0x00007000) >> 12)
#define MBOX263_F1_LE_WR(src)                 (((unsigned int)(src) << 12) & 0x00007000)
#define MBOX263_F1_LE_SET(dst,src)                ((dst) & ~0x00007000) |  \
				(((unsigned int)(src) << 12) & 0x00007000)

/*	 Fields mbox27	 */
#define MBOX273_F1_LE_WIDTH                                                   3
#define MBOX273_F1_LE_SHIFT                                                  15
#define MBOX273_F1_LE_MASK                                           0x00000700
#define MBOX273_F1_LE_RD(src)                       (((src) & 0x00000700) >> 8)
#define MBOX273_F1_LE_WR(src)                  (((unsigned int)(src) << 8) & 0x00000700)
#define MBOX273_F1_LE_SET(dst,src)                 ((dst) & ~0x00000700) |  \
				(((unsigned int)(src) << 8) & 0x00000700)

/*	 Fields mbox28	 */
#define MBOX283_F1_LE_WIDTH                                                   3
#define MBOX283_F1_LE_SHIFT                                                  19
#define MBOX283_F1_LE_MASK                                           0x00700000
#define MBOX283_F1_LE_RD(src)                      (((src) & 0x00700000) >> 20)
#define MBOX283_F1_LE_WR(src)                 (((unsigned int)(src) << 20) & 0x00700000)
#define MBOX283_F1_LE_SET(dst,src)                  ((dst) & ~0x00700000)| \
				(((unsigned int)(src) << 20) & 0x00700000)

/*	 Fields mbox29	 */
#define MBOX293_F1_LE_WIDTH                                                   3
#define MBOX293_F1_LE_SHIFT                                                  23
#define MBOX293_F1_LE_MASK                                           0x00070000
#define MBOX293_F1_LE_RD(src)                      (((src) & 0x00070000) >> 16)
#define MBOX293_F1_LE_WR(src)                 (((unsigned int)(src) << 16) & 0x00070000)
#define MBOX293_F1_LE_SET(dst,src)                  ((dst) & ~0x00070000)| \
				(((unsigned int)(src) << 16) & 0x00070000)

/*	 Fields mbox30	 */
#define MBOX303_F1_LE_WIDTH                                                   3
#define MBOX303_F1_LE_SHIFT                                                  27
#define MBOX303_F1_LE_MASK                                           0x70000000
#define MBOX303_F1_LE_RD(src)                      (((src) & 0x70000000) >> 28)
#define MBOX303_F1_LE_WR(src)                 (((unsigned int)(src) << 28) & 0x70000000)
#define MBOX303_F1_LE_SET(dst,src)                     ((dst)&~0x70000000)|\
				(((unsigned int)(src) << 28) & 0x70000000)

/*	 Fields mbox31	 */
#define MBOX313_F1_LE_WIDTH                                                   3
#define MBOX313_F1_LE_SHIFT                                                  31
#define MBOX313_F1_LE_MASK                                           0x07000000
#define MBOX313_F1_LE_RD(src)                      (((src) & 0x07000000) >> 24)
#define MBOX313_F1_LE_WR(src)                 (((unsigned int)(src) << 24) & 0x07000000)
#define MBOX313_F1_LE_SET(dst,src)                     ((dst)&~0x07000000)|\
				(((unsigned int)(src) << 24) & 0x07000000)

/*	Register csr_threshold0_set0	*/

/*	 Fields thr0	 */
#define THR00_F1_LE_WIDTH                                                    18
#define THR00_F1_LE_SHIFT                                                    31
#define THR00_F1_LE_MASK                                             0xffff0300
#define THR00_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24)| \
		(((src) & 0x00ff0000) >> 8) |(((src) & 0x00000300) << 8)
#define THR00_F1_LE_WR(src) 	(((unsigned int)(src) << 24) & 0xff000000) | \
			(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x00000300)
#define THR00_F1_LE_SET(dst,src) ((dst)&~0xffff0300)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00ff0000) | \
 			 (((unsigned int)(src) >> 8) & 0x00000300)

/*	Register csr_threshold1_set0	*/

/*	 Fields thr1	 */
#define THR10_F1_LE_WIDTH                                                    18
#define THR10_F1_LE_SHIFT                                                    31
#define THR10_F1_LE_MASK                                             0xffff0300
#define THR10_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24)| \
		(((src) & 0x00ff0000) >> 8) |(((src) & 0x00000300) << 8)
#define THR10_F1_LE_WR(src) 	(((unsigned int)(src) << 24) & 0xff000000) | \
			(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x00000300)
#define THR10_F1_LE_SET(dst,src) ((dst)&~0xffff0300)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00ff0000) | \
 			 (((unsigned int)(src) >> 8) & 0x00000300)

/*	Register csr_threshold0_set1	*/

/*	 Fields thr0	 */
#define THR01_F1_LE_WIDTH                                                    18
#define THR01_F1_LE_SHIFT                                                    31
#define THR01_F1_LE_MASK                                             0xffff0300
#define THR01_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24)| \
		(((src) & 0x00ff0000) >> 8) |(((src) & 0x00000300) << 8)
#define THR01_F1_LE_WR(src) 	(((unsigned int)(src) << 24) & 0xff000000) | \
			(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x00000300)
#define THR01_F1_LE_SET(dst,src) ((dst)&~0xffff0300)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00ff0000) | \
 			 (((unsigned int)(src) >> 8) & 0x00000300)

/*	Register csr_threshold1_set1	*/

/*	 Fields thr1	 */
#define THR11_F1_LE_WIDTH                                                    18
#define THR11_F1_LE_SHIFT                                                    31
#define THR11_F1_LE_MASK                                             0xffff0300
#define THR11_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24)| \
		(((src) & 0x00ff0000) >> 8) |(((src) & 0x00000300) << 8)
#define THR11_F1_LE_WR(src) 	(((unsigned int)(src) << 24) & 0xff000000) | \
			(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x00000300)
#define THR11_F1_LE_SET(dst,src) ((dst)&~0xffff0300)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00ff0000) | \
 			 (((unsigned int)(src) >> 8) & 0x00000300)

/*	Register csr_threshold0_set2	*/

/*	 Fields thr0	 */
#define THR02_F1_LE_WIDTH                                                    18
#define THR02_F1_LE_SHIFT                                                    31
#define THR02_F1_LE_MASK                                             0xffff0300
#define THR02_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24)| \
		(((src) & 0x00ff0000) >> 8) |(((src) & 0x00000300) << 8)
#define THR02_F1_LE_WR(src) 	(((unsigned int)(src) << 24) & 0xff000000) | \
			(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x00000300)
#define THR02_F1_LE_SET(dst,src) ((dst)&~0xffff0300)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00ff0000) | \
 			 (((unsigned int)(src) >> 8) & 0x00000300)

/*	Register csr_threshold1_set2	*/

/*	 Fields thr1	 */
#define THR12_F1_LE_WIDTH                                                    18
#define THR12_F1_LE_SHIFT                                                    31
#define THR12_F1_LE_MASK                                             0xffff0300
#define THR12_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24)| \
		(((src) & 0x00ff0000) >> 8) |(((src) & 0x00000300) << 8)
#define THR12_F1_LE_WR(src) 	(((unsigned int)(src) << 24) & 0xff000000) | \
			(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x00000300)
#define THR12_F1_LE_SET(dst,src) ((dst)&~0xffff0300)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00ff0000) | \
 			 (((unsigned int)(src) >> 8) & 0x00000300)

/*	Register csr_threshold0_set3	*/

/*	 Fields thr0	 */
#define THR03_F1_LE_WIDTH                                                    18
#define THR03_F1_LE_SHIFT                                                    31
#define THR03_F1_LE_MASK                                             0xffff0300
#define THR03_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24)| \
		(((src) & 0x00ff0000) >> 8) |(((src) & 0x00000300) << 8)
#define THR03_F1_LE_WR(src) 	(((unsigned int)(src) << 24) & 0xff000000) | \
			(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x00000300)
#define THR03_F1_LE_SET(dst,src) ((dst)&~0xffff0300)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00ff0000) | \
 			 (((unsigned int)(src) >> 8) & 0x00000300)

/*	Register csr_threshold1_set3	*/

/*	 Fields thr1	 */
#define THR13_F1_LE_WIDTH                                                    18
#define THR13_F1_LE_SHIFT                                                    31
#define THR13_F1_LE_MASK                                             0xffff0300
#define THR13_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24)| \
		(((src) & 0x00ff0000) >> 8) |(((src) & 0x00000300) << 8)
#define THR13_F1_LE_WR(src) 	(((unsigned int)(src) << 24) & 0xff000000) | \
			(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x00000300)
#define THR13_F1_LE_SET(dst,src) ((dst)&~0xffff0300)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00ff0000) | \
 			 (((unsigned int)(src) >> 8) & 0x00000300)

/*	Register csr_threshold0_set4	*/

/*	 Fields thr0	 */
#define THR04_F1_LE_WIDTH                                                    18
#define THR04_F1_LE_SHIFT                                                    31
#define THR04_F1_LE_MASK                                             0xffff0300
#define THR04_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24)| \
		(((src) & 0x00ff0000) >> 8) |(((src) & 0x00000300) << 8)
#define THR04_F1_LE_WR(src) 	(((unsigned int)(src) << 24) & 0xff000000) | \
			(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x00000300)
#define THR04_F1_LE_SET(dst,src) ((dst)&~0xffff0300)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00ff0000) | \
 			 (((unsigned int)(src) >> 8) & 0x00000300)

/*	Register csr_threshold1_set4	*/

/*	 Fields thr1	 */
#define THR14_F1_LE_WIDTH                                                    18
#define THR14_F1_LE_SHIFT                                                    31
#define THR14_F1_LE_MASK                                             0xffff0300
#define THR14_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24)| \
		(((src) & 0x00ff0000) >> 8) |(((src) & 0x00000300) << 8)
#define THR14_F1_LE_WR(src) 	(((unsigned int)(src) << 24) & 0xff000000) | \
			(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x00000300)
#define THR14_F1_LE_SET(dst,src) ((dst)&~0xffff0300)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00ff0000) | \
 			 (((unsigned int)(src) >> 8) & 0x00000300)

/*	Register csr_threshold0_set5	*/

/*	 Fields thr0	 */
#define THR05_F1_LE_WIDTH                                                    18
#define THR05_F1_LE_SHIFT                                                    31
#define THR05_F1_LE_MASK                                             0xffff0300
#define THR05_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24)| \
		(((src) & 0x00ff0000) >> 8) |(((src) & 0x00000300) << 8)
#define THR05_F1_LE_WR(src) 	(((unsigned int)(src) << 24) & 0xff000000) | \
			(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x00000300)
#define THR05_F1_LE_SET(dst,src) ((dst)&~0xffff0300)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00ff0000) | \
 			 (((unsigned int)(src) >> 8) & 0x00000300)

/*	Register csr_threshold1_set5	*/

/*	 Fields thr1	 */
#define THR15_F1_LE_WIDTH                                                    18
#define THR15_F1_LE_SHIFT                                                    31
#define THR15_F1_LE_MASK                                             0xffff0300
#define THR15_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24)| \
		(((src) & 0x00ff0000) >> 8) |(((src) & 0x00000300) << 8)
#define THR15_F1_LE_WR(src) 	(((unsigned int)(src) << 24) & 0xff000000) | \
			(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x00000300)
#define THR15_F1_LE_SET(dst,src) ((dst)&~0xffff0300)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00ff0000) | \
 			 (((unsigned int)(src) >> 8) & 0x00000300)

/*	Register csr_threshold0_set6	*/

/*	 Fields thr0	 */
#define THR06_F1_LE_WIDTH                                                    18
#define THR06_F1_LE_SHIFT                                                    31
#define THR06_F1_LE_MASK                                             0xffff0300
#define THR06_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24)| \
		(((src) & 0x00ff0000) >> 8) |(((src) & 0x00000300) << 8)
#define THR06_F1_LE_WR(src) 	(((unsigned int)(src) << 24) & 0xff000000) | \
			(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x00000300)
#define THR06_F1_LE_SET(dst,src) ((dst)&~0xffff0300)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00ff0000) | \
 			 (((unsigned int)(src) >> 8) & 0x00000300)

/*	Register csr_threshold1_set6	*/

/*	 Fields thr1	 */
#define THR16_F1_LE_WIDTH                                                    18
#define THR16_F1_LE_SHIFT                                                    31
#define THR16_F1_LE_MASK                                             0xffff0300
#define THR16_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24)| \
		(((src) & 0x00ff0000) >> 8) |(((src) & 0x00000300) << 8)
#define THR16_F1_LE_WR(src) 	(((unsigned int)(src) << 24) & 0xff000000) | \
			(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x00000300)
#define THR16_F1_LE_SET(dst,src) ((dst)&~0xffff0300)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00ff0000) | \
 			 (((unsigned int)(src) >> 8) & 0x00000300)

/*	Register csr_threshold0_set7	*/

/*	 Fields thr0	 */
#define THR07_F1_LE_WIDTH                                                    18
#define THR07_F1_LE_SHIFT                                                    31
#define THR07_F1_LE_MASK                                             0xffff0300
#define THR07_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24)| \
		(((src) & 0x00ff0000) >> 8) |(((src) & 0x00000300) << 8)
#define THR07_F1_LE_WR(src) 	(((unsigned int)(src) << 24) & 0xff000000) | \
			(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x00000300)
#define THR07_F1_LE_SET(dst,src) ((dst)&~0xffff0300)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00ff0000) | \
 			 (((unsigned int)(src) >> 8) & 0x00000300)

/*	Register csr_threshold1_set7	*/

/*	 Fields thr1	 */
#define THR17_F1_LE_WIDTH                                                    18
#define THR17_F1_LE_SHIFT                                                    31
#define THR17_F1_LE_MASK                                             0xffff0300
#define THR17_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24)| \
		(((src) & 0x00ff0000) >> 8) |(((src) & 0x00000300) << 8)
#define THR17_F1_LE_WR(src) 	(((unsigned int)(src) << 24) & 0xff000000) | \
			(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x00000300)
#define THR17_F1_LE_SET(dst,src) ((dst)&~0xffff0300)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00ff0000) | \
 			 (((unsigned int)(src) >> 8) & 0x00000300)

/*	Register csr_hysteresis	*/

/*	 Fields set0_hyst	 */
#define SET0_HYST_F1_LE_WIDTH                                                 4
#define SET0_HYST_F1_LE_SHIFT                                                 3
#define SET0_HYST_F1_LE_MASK                                         0x000000f0
#define SET0_HYST_F1_LE_RD(src)                      (((src) & 0x000000f0)<< 4)
#define SET0_HYST_F1_LE_WR(src)                (((unsigned int)(src) >> 4) & 0x000000f0)
#define SET0_HYST_F1_LE_SET(dst,src)                   ((dst) & ~0x000000f0) |\
			 (((unsigned int)(src) >> 4) & 0x000000f0)

/*	 Fields set1_hyst	 */
#define SET1_HYST_F1_LE_WIDTH                                                 4
#define SET1_HYST_F1_LE_SHIFT                                                 7
#define SET1_HYST_F1_LE_MASK                                         0x0000000f
#define SET1_HYST_F1_LE_RD(src)                      (((src) & 0x0000000f)<< 0)
#define SET1_HYST_F1_LE_WR(src)                (((unsigned int)(src) >> 0) & 0x0000000f)
#define SET1_HYST_F1_LE_SET(dst,src)                   ((dst) & ~0x0000000f) |\
			 (((unsigned int)(src) >> 0) & 0x0000000f)

/*	 Fields set2_hyst	 */
#define SET2_HYST_F1_LE_WIDTH                                                 4
#define SET2_HYST_F1_LE_SHIFT                                                11
#define SET2_HYST_F1_LE_MASK                                         0x0000f000
#define SET2_HYST_F1_LE_RD(src)                    (((src) & 0x0000f000) >> 12)
#define SET2_HYST_F1_LE_WR(src)               (((unsigned int)(src) << 12) & 0x0000f000)
#define SET2_HYST_F1_LE_SET(dst,src)                ((dst) & ~0x0000f000) |  \
				(((unsigned int)(src) << 12) & 0x0000f000)

/*	 Fields set3_hyst	 */
#define SET3_HYST_F1_LE_WIDTH                                                 4
#define SET3_HYST_F1_LE_SHIFT                                                15
#define SET3_HYST_F1_LE_MASK                                         0x00000f00
#define SET3_HYST_F1_LE_RD(src)                     (((src) & 0x00000f00) >> 8)
#define SET3_HYST_F1_LE_WR(src)                (((unsigned int)(src) << 8) & 0x00000f00)
#define SET3_HYST_F1_LE_SET(dst,src)                 ((dst) & ~0x00000f00) |  \
				(((unsigned int)(src) << 8) & 0x00000f00)

/*	 Fields set4_hyst	 */
#define SET4_HYST_F1_LE_WIDTH                                                 4
#define SET4_HYST_F1_LE_SHIFT                                                19
#define SET4_HYST_F1_LE_MASK                                         0x00f00000
#define SET4_HYST_F1_LE_RD(src)                    (((src) & 0x00f00000) >> 20)
#define SET4_HYST_F1_LE_WR(src)               (((unsigned int)(src) << 20) & 0x00f00000)
#define SET4_HYST_F1_LE_SET(dst,src)                  ((dst) & ~0x00f00000)| \
				(((unsigned int)(src) << 20) & 0x00f00000)

/*	 Fields set5_hyst	 */
#define SET5_HYST_F1_LE_WIDTH                                                 4
#define SET5_HYST_F1_LE_SHIFT                                                23
#define SET5_HYST_F1_LE_MASK                                         0x000f0000
#define SET5_HYST_F1_LE_RD(src)                    (((src) & 0x000f0000) >> 16)
#define SET5_HYST_F1_LE_WR(src)               (((unsigned int)(src) << 16) & 0x000f0000)
#define SET5_HYST_F1_LE_SET(dst,src)                  ((dst) & ~0x000f0000)| \
				(((unsigned int)(src) << 16) & 0x000f0000)

/*	 Fields set6_hyst	 */
#define SET6_HYST_F1_LE_WIDTH                                                 4
#define SET6_HYST_F1_LE_SHIFT                                                27
#define SET6_HYST_F1_LE_MASK                                         0xf0000000
#define SET6_HYST_F1_LE_RD(src)                    (((src) & 0xf0000000) >> 28)
#define SET6_HYST_F1_LE_WR(src)               (((unsigned int)(src) << 28) & 0xf0000000)
#define SET6_HYST_F1_LE_SET(dst,src)                     ((dst)&~0xf0000000)|\
				(((unsigned int)(src) << 28) & 0xf0000000)

/*	 Fields set7_hyst	 */
#define SET7_HYST_F1_LE_WIDTH                                                 4
#define SET7_HYST_F1_LE_SHIFT                                                31
#define SET7_HYST_F1_LE_MASK                                         0x0f000000
#define SET7_HYST_F1_LE_RD(src)                    (((src) & 0x0f000000) >> 24)
#define SET7_HYST_F1_LE_WR(src)               (((unsigned int)(src) << 24) & 0x0f000000)
#define SET7_HYST_F1_LE_SET(dst,src)                     ((dst)&~0x0f000000)|\
				(((unsigned int)(src) << 24) & 0x0f000000)

/*	Register csr_qstate	*/

/*	 Fields qnumber	 */
#define QNUMBER_F1_LE_WIDTH                                                  10
#define QNUMBER_F1_LE_SHIFT                                                  31
#define QNUMBER_F1_LE_MASK                                           0xff030000
#define QNUMBER_F1_LE_RD(src)               	(((src) & 0xff000000) >> 24) |\
				(((src) & 0x00030000) >> 8)
#define QNUMBER_F1_LE_WR(src)      	(((unsigned int)(src) << 24) & 0xff000000) |\
				(((unsigned int)(src) << 8) & 0x00030000)
#define QNUMBER_F1_LE_SET(dst,src) ((dst)&~0xff030000)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00030000)

/*	Register csr_qstate_wr_0	*/

/*	 Fields data	 */
#define DATA0_F4_LE_WIDTH                                                    32
#define DATA0_F4_LE_SHIFT                                                    31
#define DATA0_F4_LE_MASK                                             0xffffffff
#define DATA0_F4_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define DATA0_F4_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define DATA0_F4_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_qstate_wr_1	*/

/*	 Fields data	 */
#define DATA1_F4_LE_WIDTH                                                    32
#define DATA1_F4_LE_SHIFT                                                    31
#define DATA1_F4_LE_MASK                                             0xffffffff
#define DATA1_F4_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define DATA1_F4_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define DATA1_F4_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_qstate_wr_2	*/

/*	 Fields data	 */
#define DATA2_F2_LE_WIDTH                                                    32
#define DATA2_F2_LE_SHIFT                                                    31
#define DATA2_F2_LE_MASK                                             0xffffffff
#define DATA2_F2_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define DATA2_F2_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define DATA2_F2_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_qstate_wr_3	*/

/*	 Fields data	 */
#define DATA3_F2_LE_WIDTH                                                    32
#define DATA3_F2_LE_SHIFT                                                    31
#define DATA3_F2_LE_MASK                                             0xffffffff
#define DATA3_F2_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define DATA3_F2_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define DATA3_F2_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_qstate_wr_4	*/

/*	 Fields data	 */
#define DATA4_F2_LE_WIDTH                                                    21
#define DATA4_F2_LE_SHIFT                                                    31
#define DATA4_F2_LE_MASK                                             0xffff1f00
#define DATA4_F2_LE_RD(src) 	(((src) & 0xff000000) >> 24)| \
		(((src) & 0x00ff0000) >> 8) |(((src) & 0x00001f00) << 8)
#define DATA4_F2_LE_WR(src) 	(((unsigned int)(src) << 24) & 0xff000000) | \
			(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x00001f00)
#define DATA4_F2_LE_SET(dst,src) ((dst)&~0xffff1f00)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00ff0000) | \
 			 (((unsigned int)(src) >> 8) & 0x00001f00)

/*	Register csr_qstate_rd_0	*/

/*	 Fields data	 */
#define DATA0_F5_LE_WIDTH                                                    32
#define DATA0_F5_LE_SHIFT                                                    31
#define DATA0_F5_LE_MASK                                             0xffffffff
#define DATA0_F5_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define DATA0_F5_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_qstate_rd_1	*/

/*	 Fields data	 */
#define DATA1_F5_LE_WIDTH                                                    32
#define DATA1_F5_LE_SHIFT                                                    31
#define DATA1_F5_LE_MASK                                             0xffffffff
#define DATA1_F5_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define DATA1_F5_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_qstate_rd_2	*/

/*	 Fields data	 */
#define DATA2_F3_LE_WIDTH                                                    32
#define DATA2_F3_LE_SHIFT                                                    31
#define DATA2_F3_LE_MASK                                             0xffffffff
#define DATA2_F3_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define DATA2_F3_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_qstate_rd_3	*/

/*	 Fields data	 */
#define DATA3_F3_LE_WIDTH                                                    32
#define DATA3_F3_LE_SHIFT                                                    31
#define DATA3_F3_LE_MASK                                             0xffffffff
#define DATA3_F3_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define DATA3_F3_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_qstate_rd_4	*/

/*	 Fields data	 */
#define DATA4_F3_LE_WIDTH                                                    21
#define DATA4_F3_LE_SHIFT                                                    31
#define DATA4_F3_LE_MASK                                             0xffff1f00
#define DATA4_F3_LE_RD(src) 	(((src) & 0xff000000) >> 24)| \
		(((src) & 0x00ff0000) >> 8) |(((src) & 0x00001f00) << 8)
#define DATA4_F3_LE_SET(dst,src) ((dst)&~0xffff1f00)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00ff0000) | \
 			 (((unsigned int)(src) >> 8) & 0x00001f00)

/*	Register csr_cstate_wr_0	*/

/*	 Fields data	 */
#define DATA0_F6_LE_WIDTH                                                    32
#define DATA0_F6_LE_SHIFT                                                    31
#define DATA0_F6_LE_MASK                                             0xffffffff
#define DATA0_F6_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define DATA0_F6_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define DATA0_F6_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_cstate_wr_1	*/

/*	 Fields data	 */
#define DATA1_F6_LE_WIDTH                                                    15
#define DATA1_F6_LE_SHIFT                                                    31
#define DATA1_F6_LE_MASK                                             0xff7f0000
#define DATA1_F6_LE_RD(src)               	(((src) & 0xff000000) >> 24) |\
				(((src) & 0x007f0000) >> 8)
#define DATA1_F6_LE_WR(src)      	(((unsigned int)(src) << 24) & 0xff000000) |\
				(((unsigned int)(src) << 8) & 0x007f0000)
#define DATA1_F6_LE_SET(dst,src) ((dst)&~0xff7f0000)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x007f0000)

/*	Register csr_cstate_rd_0	*/

/*	 Fields data	 */
#define DATA0_F7_LE_WIDTH                                                    32
#define DATA0_F7_LE_SHIFT                                                    31
#define DATA0_F7_LE_MASK                                             0xffffffff
#define DATA0_F7_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define DATA0_F7_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_cstate_rd_1	*/

/*	 Fields data	 */
#define DATA1_F7_LE_WIDTH                                                    15
#define DATA1_F7_LE_SHIFT                                                    31
#define DATA1_F7_LE_MASK                                             0xff7f0000
#define DATA1_F7_LE_RD(src)               	(((src) & 0xff000000) >> 24) |\
				(((src) & 0x007f0000) >> 8)
#define DATA1_F7_LE_SET(dst,src) ((dst)&~0xff7f0000)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x007f0000)

/*	Register csr_cu_timer	*/

/*	 Fields init	 */
#define INIT_F1_LE_WIDTH                                                     20
#define INIT_F1_LE_SHIFT                                                     31
#define INIT_F1_LE_MASK                                              0xffff0f00
#define INIT_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24)| \
		(((src) & 0x00ff0000) >> 8) |(((src) & 0x00000f00) << 8)
#define INIT_F1_LE_WR(src) 	(((unsigned int)(src) << 24) & 0xff000000) | \
			(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x00000f00)
#define INIT_F1_LE_SET(dst,src) ((dst)&~0xffff0f00)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00ff0000) | \
 			 (((unsigned int)(src) >> 8) & 0x00000f00)

/*	Register csr_proc_mbox_base_0	*/

/*	 Fields coherent	 */
#define COHERENT0_F3_LE_WIDTH                                                 1
#define COHERENT0_F3_LE_SHIFT                                                 0
#define COHERENT0_F3_LE_MASK                                         0x00000080
#define COHERENT0_F3_LE_RD(src)                      (((src) & 0x00000080)<< 7)
#define COHERENT0_F3_LE_WR(src)                (((unsigned int)(src) >> 7) & 0x00000080)
#define COHERENT0_F3_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields vc	 */
#define VC0_F3_LE_WIDTH                                                       2
#define VC0_F3_LE_SHIFT                                                       2
#define VC0_F3_LE_MASK                                               0x00000060
#define VC0_F3_LE_RD(src)                            (((src) & 0x00000060)<< 5)
#define VC0_F3_LE_WR(src)                      (((unsigned int)(src) >> 5) & 0x00000060)
#define VC0_F3_LE_SET(dst,src)                   ((dst) & ~0x00000060) |\
			 (((unsigned int)(src) >> 5) & 0x00000060)

/*	 Fields stashing	 */
#define STASHING0_F3_LE_WIDTH                                                 1
#define STASHING0_F3_LE_SHIFT                                                 3
#define STASHING0_F3_LE_MASK                                         0x00000010
#define STASHING0_F3_LE_RD(src)                      (((src) & 0x00000010)<< 4)
#define STASHING0_F3_LE_WR(src)                (((unsigned int)(src) >> 4) & 0x00000010)
#define STASHING0_F3_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields addr	 */
#define REGSPEC_ADDR0_F3_LE_WIDTH                                            26
#define REGSPEC_ADDR0_F3_LE_SHIFT                                            31
#define REGSPEC_ADDR0_F3_LE_MASK                                     0xffffff03
#define REGSPEC_ADDR0_F3_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x00000003) << 24)
#define REGSPEC_ADDR0_F3_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x00000003)
#define REGSPEC_ADDR0_F3_LE_SET(dst,src) 	((dst)&~0xffffff03)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x00000003)

/*	Register csr_proc_mbox_base_1	*/

/*	 Fields coherent	 */
#define COHERENT1_F3_LE_WIDTH                                                 1
#define COHERENT1_F3_LE_SHIFT                                                 0
#define COHERENT1_F3_LE_MASK                                         0x00000080
#define COHERENT1_F3_LE_RD(src)                      (((src) & 0x00000080)<< 7)
#define COHERENT1_F3_LE_WR(src)                (((unsigned int)(src) >> 7) & 0x00000080)
#define COHERENT1_F3_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields vc	 */
#define VC1_F3_LE_WIDTH                                                       2
#define VC1_F3_LE_SHIFT                                                       2
#define VC1_F3_LE_MASK                                               0x00000060
#define VC1_F3_LE_RD(src)                            (((src) & 0x00000060)<< 5)
#define VC1_F3_LE_WR(src)                      (((unsigned int)(src) >> 5) & 0x00000060)
#define VC1_F3_LE_SET(dst,src)                   ((dst) & ~0x00000060) |\
			 (((unsigned int)(src) >> 5) & 0x00000060)

/*	 Fields stashing	 */
#define STASHING1_F3_LE_WIDTH                                                 1
#define STASHING1_F3_LE_SHIFT                                                 3
#define STASHING1_F3_LE_MASK                                         0x00000010
#define STASHING1_F3_LE_RD(src)                      (((src) & 0x00000010)<< 4)
#define STASHING1_F3_LE_WR(src)                (((unsigned int)(src) >> 4) & 0x00000010)
#define STASHING1_F3_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields addr	 */
#define REGSPEC_ADDR1_F3_LE_WIDTH                                            26
#define REGSPEC_ADDR1_F3_LE_SHIFT                                            31
#define REGSPEC_ADDR1_F3_LE_MASK                                     0xffffff03
#define REGSPEC_ADDR1_F3_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x00000003) << 24)
#define REGSPEC_ADDR1_F3_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x00000003)
#define REGSPEC_ADDR1_F3_LE_SET(dst,src) 	((dst)&~0xffffff03)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x00000003)

/*	Register csr_proc_mbox_base_2	*/

/*	 Fields coherent	 */
#define COHERENT2_F3_LE_WIDTH                                                 1
#define COHERENT2_F3_LE_SHIFT                                                 0
#define COHERENT2_F3_LE_MASK                                         0x00000080
#define COHERENT2_F3_LE_RD(src)                      (((src) & 0x00000080)<< 7)
#define COHERENT2_F3_LE_WR(src)                (((unsigned int)(src) >> 7) & 0x00000080)
#define COHERENT2_F3_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields vc	 */
#define VC2_F3_LE_WIDTH                                                       2
#define VC2_F3_LE_SHIFT                                                       2
#define VC2_F3_LE_MASK                                               0x00000060
#define VC2_F3_LE_RD(src)                            (((src) & 0x00000060)<< 5)
#define VC2_F3_LE_WR(src)                      (((unsigned int)(src) >> 5) & 0x00000060)
#define VC2_F3_LE_SET(dst,src)                   ((dst) & ~0x00000060) |\
			 (((unsigned int)(src) >> 5) & 0x00000060)

/*	 Fields stashing	 */
#define STASHING2_F3_LE_WIDTH                                                 1
#define STASHING2_F3_LE_SHIFT                                                 3
#define STASHING2_F3_LE_MASK                                         0x00000010
#define STASHING2_F3_LE_RD(src)                      (((src) & 0x00000010)<< 4)
#define STASHING2_F3_LE_WR(src)                (((unsigned int)(src) >> 4) & 0x00000010)
#define STASHING2_F3_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields addr	 */
#define REGSPEC_ADDR2_F3_LE_WIDTH                                            26
#define REGSPEC_ADDR2_F3_LE_SHIFT                                            31
#define REGSPEC_ADDR2_F3_LE_MASK                                     0xffffff03
#define REGSPEC_ADDR2_F3_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x00000003) << 24)
#define REGSPEC_ADDR2_F3_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x00000003)
#define REGSPEC_ADDR2_F3_LE_SET(dst,src) 	((dst)&~0xffffff03)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x00000003)

/*	Register csr_proc_mbox_base_3	*/

/*	 Fields coherent	 */
#define COHERENT3_F3_LE_WIDTH                                                 1
#define COHERENT3_F3_LE_SHIFT                                                 0
#define COHERENT3_F3_LE_MASK                                         0x00000080
#define COHERENT3_F3_LE_RD(src)                      (((src) & 0x00000080)<< 7)
#define COHERENT3_F3_LE_WR(src)                (((unsigned int)(src) >> 7) & 0x00000080)
#define COHERENT3_F3_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields vc	 */
#define VC3_F3_LE_WIDTH                                                       2
#define VC3_F3_LE_SHIFT                                                       2
#define VC3_F3_LE_MASK                                               0x00000060
#define VC3_F3_LE_RD(src)                            (((src) & 0x00000060)<< 5)
#define VC3_F3_LE_WR(src)                      (((unsigned int)(src) >> 5) & 0x00000060)
#define VC3_F3_LE_SET(dst,src)                   ((dst) & ~0x00000060) |\
			 (((unsigned int)(src) >> 5) & 0x00000060)

/*	 Fields stashing	 */
#define STASHING3_F3_LE_WIDTH                                                 1
#define STASHING3_F3_LE_SHIFT                                                 3
#define STASHING3_F3_LE_MASK                                         0x00000010
#define STASHING3_F3_LE_RD(src)                      (((src) & 0x00000010)<< 4)
#define STASHING3_F3_LE_WR(src)                (((unsigned int)(src) >> 4) & 0x00000010)
#define STASHING3_F3_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields addr	 */
#define REGSPEC_ADDR3_F3_LE_WIDTH                                            26
#define REGSPEC_ADDR3_F3_LE_SHIFT                                            31
#define REGSPEC_ADDR3_F3_LE_MASK                                     0xffffff03
#define REGSPEC_ADDR3_F3_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x00000003) << 24)
#define REGSPEC_ADDR3_F3_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x00000003)
#define REGSPEC_ADDR3_F3_LE_SET(dst,src) 	((dst)&~0xffffff03)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x00000003)

/*	Register csr_proc_fpool_base_0	*/

/*	 Fields coherent	 */
#define COHERENT0_F4_LE_WIDTH                                                 1
#define COHERENT0_F4_LE_SHIFT                                                 0
#define COHERENT0_F4_LE_MASK                                         0x00000080
#define COHERENT0_F4_LE_RD(src)                      (((src) & 0x00000080)<< 7)
#define COHERENT0_F4_LE_WR(src)                (((unsigned int)(src) >> 7) & 0x00000080)
#define COHERENT0_F4_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields vc	 */
#define VC0_F4_LE_WIDTH                                                       2
#define VC0_F4_LE_SHIFT                                                       2
#define VC0_F4_LE_MASK                                               0x00000060
#define VC0_F4_LE_RD(src)                            (((src) & 0x00000060)<< 5)
#define VC0_F4_LE_WR(src)                      (((unsigned int)(src) >> 5) & 0x00000060)
#define VC0_F4_LE_SET(dst,src)                   ((dst) & ~0x00000060) |\
			 (((unsigned int)(src) >> 5) & 0x00000060)

/*	 Fields stashing	 */
#define STASHING0_F4_LE_WIDTH                                                 1
#define STASHING0_F4_LE_SHIFT                                                 3
#define STASHING0_F4_LE_MASK                                         0x00000010
#define STASHING0_F4_LE_RD(src)                      (((src) & 0x00000010)<< 4)
#define STASHING0_F4_LE_WR(src)                (((unsigned int)(src) >> 4) & 0x00000010)
#define STASHING0_F4_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields addr	 */
#define REGSPEC_ADDR0_F4_LE_WIDTH                                            27
#define REGSPEC_ADDR0_F4_LE_SHIFT                                            31
#define REGSPEC_ADDR0_F4_LE_MASK                                     0xffffff07
#define REGSPEC_ADDR0_F4_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x00000007) << 24)
#define REGSPEC_ADDR0_F4_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x00000007)
#define REGSPEC_ADDR0_F4_LE_SET(dst,src) 	((dst)&~0xffffff07)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x00000007)

/*	Register csr_proc_fpool_base_1	*/

/*	 Fields coherent	 */
#define COHERENT1_F4_LE_WIDTH                                                 1
#define COHERENT1_F4_LE_SHIFT                                                 0
#define COHERENT1_F4_LE_MASK                                         0x00000080
#define COHERENT1_F4_LE_RD(src)                      (((src) & 0x00000080)<< 7)
#define COHERENT1_F4_LE_WR(src)                (((unsigned int)(src) >> 7) & 0x00000080)
#define COHERENT1_F4_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields vc	 */
#define VC1_F4_LE_WIDTH                                                       2
#define VC1_F4_LE_SHIFT                                                       2
#define VC1_F4_LE_MASK                                               0x00000060
#define VC1_F4_LE_RD(src)                            (((src) & 0x00000060)<< 5)
#define VC1_F4_LE_WR(src)                      (((unsigned int)(src) >> 5) & 0x00000060)
#define VC1_F4_LE_SET(dst,src)                   ((dst) & ~0x00000060) |\
			 (((unsigned int)(src) >> 5) & 0x00000060)

/*	 Fields stashing	 */
#define STASHING1_F4_LE_WIDTH                                                 1
#define STASHING1_F4_LE_SHIFT                                                 3
#define STASHING1_F4_LE_MASK                                         0x00000010
#define STASHING1_F4_LE_RD(src)                      (((src) & 0x00000010)<< 4)
#define STASHING1_F4_LE_WR(src)                (((unsigned int)(src) >> 4) & 0x00000010)
#define STASHING1_F4_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields addr	 */
#define REGSPEC_ADDR1_F4_LE_WIDTH                                            27
#define REGSPEC_ADDR1_F4_LE_SHIFT                                            31
#define REGSPEC_ADDR1_F4_LE_MASK                                     0xffffff07
#define REGSPEC_ADDR1_F4_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x00000007) << 24)
#define REGSPEC_ADDR1_F4_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x00000007)
#define REGSPEC_ADDR1_F4_LE_SET(dst,src) 	((dst)&~0xffffff07)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x00000007)

/*	Register csr_proc_fpool_base_2	*/

/*	 Fields coherent	 */
#define COHERENT2_F4_LE_WIDTH                                                 1
#define COHERENT2_F4_LE_SHIFT                                                 0
#define COHERENT2_F4_LE_MASK                                         0x00000080
#define COHERENT2_F4_LE_RD(src)                      (((src) & 0x00000080)<< 7)
#define COHERENT2_F4_LE_WR(src)                (((unsigned int)(src) >> 7) & 0x00000080)
#define COHERENT2_F4_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields vc	 */
#define VC2_F4_LE_WIDTH                                                       2
#define VC2_F4_LE_SHIFT                                                       2
#define VC2_F4_LE_MASK                                               0x00000060
#define VC2_F4_LE_RD(src)                            (((src) & 0x00000060)<< 5)
#define VC2_F4_LE_WR(src)                      (((unsigned int)(src) >> 5) & 0x00000060)
#define VC2_F4_LE_SET(dst,src)                   ((dst) & ~0x00000060) |\
			 (((unsigned int)(src) >> 5) & 0x00000060)

/*	 Fields stashing	 */
#define STASHING2_F4_LE_WIDTH                                                 1
#define STASHING2_F4_LE_SHIFT                                                 3
#define STASHING2_F4_LE_MASK                                         0x00000010
#define STASHING2_F4_LE_RD(src)                      (((src) & 0x00000010)<< 4)
#define STASHING2_F4_LE_WR(src)                (((unsigned int)(src) >> 4) & 0x00000010)
#define STASHING2_F4_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields addr	 */
#define REGSPEC_ADDR2_F4_LE_WIDTH                                            27
#define REGSPEC_ADDR2_F4_LE_SHIFT                                            31
#define REGSPEC_ADDR2_F4_LE_MASK                                     0xffffff07
#define REGSPEC_ADDR2_F4_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x00000007) << 24)
#define REGSPEC_ADDR2_F4_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x00000007)
#define REGSPEC_ADDR2_F4_LE_SET(dst,src) 	((dst)&~0xffffff07)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x00000007)

/*	Register csr_proc_fpool_base_3	*/

/*	 Fields coherent	 */
#define COHERENT3_F4_LE_WIDTH                                                 1
#define COHERENT3_F4_LE_SHIFT                                                 0
#define COHERENT3_F4_LE_MASK                                         0x00000080
#define COHERENT3_F4_LE_RD(src)                      (((src) & 0x00000080)<< 7)
#define COHERENT3_F4_LE_WR(src)                (((unsigned int)(src) >> 7) & 0x00000080)
#define COHERENT3_F4_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields vc	 */
#define VC3_F4_LE_WIDTH                                                       2
#define VC3_F4_LE_SHIFT                                                       2
#define VC3_F4_LE_MASK                                               0x00000060
#define VC3_F4_LE_RD(src)                            (((src) & 0x00000060)<< 5)
#define VC3_F4_LE_WR(src)                      (((unsigned int)(src) >> 5) & 0x00000060)
#define VC3_F4_LE_SET(dst,src)                   ((dst) & ~0x00000060) |\
			 (((unsigned int)(src) >> 5) & 0x00000060)

/*	 Fields stashing	 */
#define STASHING3_F4_LE_WIDTH                                                 1
#define STASHING3_F4_LE_SHIFT                                                 3
#define STASHING3_F4_LE_MASK                                         0x00000010
#define STASHING3_F4_LE_RD(src)                      (((src) & 0x00000010)<< 4)
#define STASHING3_F4_LE_WR(src)                (((unsigned int)(src) >> 4) & 0x00000010)
#define STASHING3_F4_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields addr	 */
#define REGSPEC_ADDR3_F4_LE_WIDTH                                            27
#define REGSPEC_ADDR3_F4_LE_SHIFT                                            31
#define REGSPEC_ADDR3_F4_LE_MASK                                     0xffffff07
#define REGSPEC_ADDR3_F4_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x00000007) << 24)
#define REGSPEC_ADDR3_F4_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x00000007)
#define REGSPEC_ADDR3_F4_LE_SET(dst,src) 	((dst)&~0xffffff07)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x00000007)

/*	Register csr_enq_base_0	*/

/*	 Fields coherent	 */
#define COHERENT0_F5_LE_WIDTH                                                 1
#define COHERENT0_F5_LE_SHIFT                                                 0
#define COHERENT0_F5_LE_MASK                                         0x00000080
#define COHERENT0_F5_LE_RD(src)                      (((src) & 0x00000080)<< 7)
#define COHERENT0_F5_LE_WR(src)                (((unsigned int)(src) >> 7) & 0x00000080)
#define COHERENT0_F5_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields vc	 */
#define VC0_F5_LE_WIDTH                                                       2
#define VC0_F5_LE_SHIFT                                                       2
#define VC0_F5_LE_MASK                                               0x00000060
#define VC0_F5_LE_RD(src)                            (((src) & 0x00000060)<< 5)
#define VC0_F5_LE_WR(src)                      (((unsigned int)(src) >> 5) & 0x00000060)
#define VC0_F5_LE_SET(dst,src)                   ((dst) & ~0x00000060) |\
			 (((unsigned int)(src) >> 5) & 0x00000060)

/*	 Fields stashing	 */
#define STASHING0_F5_LE_WIDTH                                                 1
#define STASHING0_F5_LE_SHIFT                                                 3
#define STASHING0_F5_LE_MASK                                         0x00000010
#define STASHING0_F5_LE_RD(src)                      (((src) & 0x00000010)<< 4)
#define STASHING0_F5_LE_WR(src)                (((unsigned int)(src) >> 4) & 0x00000010)
#define STASHING0_F5_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields addr	 */
#define REGSPEC_ADDR0_F5_LE_WIDTH                                            26
#define REGSPEC_ADDR0_F5_LE_SHIFT                                            31
#define REGSPEC_ADDR0_F5_LE_MASK                                     0xffffff03
#define REGSPEC_ADDR0_F5_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x00000003) << 24)
#define REGSPEC_ADDR0_F5_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x00000003)
#define REGSPEC_ADDR0_F5_LE_SET(dst,src) 	((dst)&~0xffffff03)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x00000003)

/*	Register csr_enq_base_1	*/

/*	 Fields coherent	 */
#define COHERENT1_F5_LE_WIDTH                                                 1
#define COHERENT1_F5_LE_SHIFT                                                 0
#define COHERENT1_F5_LE_MASK                                         0x00000080
#define COHERENT1_F5_LE_RD(src)                      (((src) & 0x00000080)<< 7)
#define COHERENT1_F5_LE_WR(src)                (((unsigned int)(src) >> 7) & 0x00000080)
#define COHERENT1_F5_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields vc	 */
#define VC1_F5_LE_WIDTH                                                       2
#define VC1_F5_LE_SHIFT                                                       2
#define VC1_F5_LE_MASK                                               0x00000060
#define VC1_F5_LE_RD(src)                            (((src) & 0x00000060)<< 5)
#define VC1_F5_LE_WR(src)                      (((unsigned int)(src) >> 5) & 0x00000060)
#define VC1_F5_LE_SET(dst,src)                   ((dst) & ~0x00000060) |\
			 (((unsigned int)(src) >> 5) & 0x00000060)

/*	 Fields stashing	 */
#define STASHING1_F5_LE_WIDTH                                                 1
#define STASHING1_F5_LE_SHIFT                                                 3
#define STASHING1_F5_LE_MASK                                         0x00000010
#define STASHING1_F5_LE_RD(src)                      (((src) & 0x00000010)<< 4)
#define STASHING1_F5_LE_WR(src)                (((unsigned int)(src) >> 4) & 0x00000010)
#define STASHING1_F5_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields addr	 */
#define REGSPEC_ADDR1_F5_LE_WIDTH                                            26
#define REGSPEC_ADDR1_F5_LE_SHIFT                                            31
#define REGSPEC_ADDR1_F5_LE_MASK                                     0xffffff03
#define REGSPEC_ADDR1_F5_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x00000003) << 24)
#define REGSPEC_ADDR1_F5_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x00000003)
#define REGSPEC_ADDR1_F5_LE_SET(dst,src) 	((dst)&~0xffffff03)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x00000003)

/*	Register csr_enq_base_2	*/

/*	 Fields coherent	 */
#define COHERENT2_F5_LE_WIDTH                                                 1
#define COHERENT2_F5_LE_SHIFT                                                 0
#define COHERENT2_F5_LE_MASK                                         0x00000080
#define COHERENT2_F5_LE_RD(src)                      (((src) & 0x00000080)<< 7)
#define COHERENT2_F5_LE_WR(src)                (((unsigned int)(src) >> 7) & 0x00000080)
#define COHERENT2_F5_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields vc	 */
#define VC2_F5_LE_WIDTH                                                       2
#define VC2_F5_LE_SHIFT                                                       2
#define VC2_F5_LE_MASK                                               0x00000060
#define VC2_F5_LE_RD(src)                            (((src) & 0x00000060)<< 5)
#define VC2_F5_LE_WR(src)                      (((unsigned int)(src) >> 5) & 0x00000060)
#define VC2_F5_LE_SET(dst,src)                   ((dst) & ~0x00000060) |\
			 (((unsigned int)(src) >> 5) & 0x00000060)

/*	 Fields stashing	 */
#define STASHING2_F5_LE_WIDTH                                                 1
#define STASHING2_F5_LE_SHIFT                                                 3
#define STASHING2_F5_LE_MASK                                         0x00000010
#define STASHING2_F5_LE_RD(src)                      (((src) & 0x00000010)<< 4)
#define STASHING2_F5_LE_WR(src)                (((unsigned int)(src) >> 4) & 0x00000010)
#define STASHING2_F5_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields addr	 */
#define REGSPEC_ADDR2_F5_LE_WIDTH                                            26
#define REGSPEC_ADDR2_F5_LE_SHIFT                                            31
#define REGSPEC_ADDR2_F5_LE_MASK                                     0xffffff03
#define REGSPEC_ADDR2_F5_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x00000003) << 24)
#define REGSPEC_ADDR2_F5_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x00000003)
#define REGSPEC_ADDR2_F5_LE_SET(dst,src) 	((dst)&~0xffffff03)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x00000003)

/*	Register csr_enq_base_3	*/

/*	 Fields coherent	 */
#define COHERENT3_F5_LE_WIDTH                                                 1
#define COHERENT3_F5_LE_SHIFT                                                 0
#define COHERENT3_F5_LE_MASK                                         0x00000080
#define COHERENT3_F5_LE_RD(src)                      (((src) & 0x00000080)<< 7)
#define COHERENT3_F5_LE_WR(src)                (((unsigned int)(src) >> 7) & 0x00000080)
#define COHERENT3_F5_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields vc	 */
#define VC3_F5_LE_WIDTH                                                       2
#define VC3_F5_LE_SHIFT                                                       2
#define VC3_F5_LE_MASK                                               0x00000060
#define VC3_F5_LE_RD(src)                            (((src) & 0x00000060)<< 5)
#define VC3_F5_LE_WR(src)                      (((unsigned int)(src) >> 5) & 0x00000060)
#define VC3_F5_LE_SET(dst,src)                   ((dst) & ~0x00000060) |\
			 (((unsigned int)(src) >> 5) & 0x00000060)

/*	 Fields stashing	 */
#define STASHING3_F5_LE_WIDTH                                                 1
#define STASHING3_F5_LE_SHIFT                                                 3
#define STASHING3_F5_LE_MASK                                         0x00000010
#define STASHING3_F5_LE_RD(src)                      (((src) & 0x00000010)<< 4)
#define STASHING3_F5_LE_WR(src)                (((unsigned int)(src) >> 4) & 0x00000010)
#define STASHING3_F5_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields addr	 */
#define REGSPEC_ADDR3_F5_LE_WIDTH                                            26
#define REGSPEC_ADDR3_F5_LE_SHIFT                                            31
#define REGSPEC_ADDR3_F5_LE_MASK                                     0xffffff03
#define REGSPEC_ADDR3_F5_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x00000003) << 24)
#define REGSPEC_ADDR3_F5_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x00000003)
#define REGSPEC_ADDR3_F5_LE_SET(dst,src) 	((dst)&~0xffffff03)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x00000003)

/*	Register csr_enq_status_0	*/

/*	 Fields mbox_0_15	 */
#define MBOX_0_150_F1_LE_WIDTH                                                1
#define MBOX_0_150_F1_LE_SHIFT                                                0
#define MBOX_0_150_F1_LE_MASK                                        0x00000080
#define MBOX_0_150_F1_LE_RD(src)                     (((src) & 0x00000080)<< 7)
#define MBOX_0_150_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields mbox_0_14	 */
#define MBOX_0_140_F1_LE_WIDTH                                                1
#define MBOX_0_140_F1_LE_SHIFT                                                1
#define MBOX_0_140_F1_LE_MASK                                        0x00000040
#define MBOX_0_140_F1_LE_RD(src)                     (((src) & 0x00000040)<< 6)
#define MBOX_0_140_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields mbox_0_13	 */
#define MBOX_0_130_F1_LE_WIDTH                                                1
#define MBOX_0_130_F1_LE_SHIFT                                                2
#define MBOX_0_130_F1_LE_MASK                                        0x00000020
#define MBOX_0_130_F1_LE_RD(src)                     (((src) & 0x00000020)<< 5)
#define MBOX_0_130_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*	 Fields mbox_0_12	 */
#define MBOX_0_120_F1_LE_WIDTH                                                1
#define MBOX_0_120_F1_LE_SHIFT                                                3
#define MBOX_0_120_F1_LE_MASK                                        0x00000010
#define MBOX_0_120_F1_LE_RD(src)                     (((src) & 0x00000010)<< 4)
#define MBOX_0_120_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields mbox_0_11	 */
#define MBOX_0_110_F1_LE_WIDTH                                                1
#define MBOX_0_110_F1_LE_SHIFT                                                4
#define MBOX_0_110_F1_LE_MASK                                        0x00000008
#define MBOX_0_110_F1_LE_RD(src)                     (((src) & 0x00000008)<< 3)
#define MBOX_0_110_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*	 Fields mbox_0_10	 */
#define MBOX_0_100_F1_LE_WIDTH                                                1
#define MBOX_0_100_F1_LE_SHIFT                                                5
#define MBOX_0_100_F1_LE_MASK                                        0x00000004
#define MBOX_0_100_F1_LE_RD(src)                     (((src) & 0x00000004)<< 2)
#define MBOX_0_100_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*	 Fields mbox_0_9	 */
#define MBOX_0_90_F1_LE_WIDTH                                                 1
#define MBOX_0_90_F1_LE_SHIFT                                                 6
#define MBOX_0_90_F1_LE_MASK                                         0x00000002
#define MBOX_0_90_F1_LE_RD(src)                      (((src) & 0x00000002)<< 1)
#define MBOX_0_90_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*	 Fields mbox_0_8	 */
#define MBOX_0_80_F1_LE_WIDTH                                                 1
#define MBOX_0_80_F1_LE_SHIFT                                                 7
#define MBOX_0_80_F1_LE_MASK                                         0x00000001
#define MBOX_0_80_F1_LE_RD(src)                      (((src) & 0x00000001)<< 0)
#define MBOX_0_80_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*	 Fields mbox_0_7	 */
#define MBOX_0_70_F1_LE_WIDTH                                                 1
#define MBOX_0_70_F1_LE_SHIFT                                                 8
#define MBOX_0_70_F1_LE_MASK                                         0x00008000
#define MBOX_0_70_F1_LE_RD(src)                    (((src) & 0x00008000) >> 15)
#define MBOX_0_70_F1_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*	 Fields mbox_0_6	 */
#define MBOX_0_60_F1_LE_WIDTH                                                 1
#define MBOX_0_60_F1_LE_SHIFT                                                 9
#define MBOX_0_60_F1_LE_MASK                                         0x00004000
#define MBOX_0_60_F1_LE_RD(src)                    (((src) & 0x00004000) >> 14)
#define MBOX_0_60_F1_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*	 Fields mbox_0_5	 */
#define MBOX_0_50_F1_LE_WIDTH                                                 1
#define MBOX_0_50_F1_LE_SHIFT                                                10
#define MBOX_0_50_F1_LE_MASK                                         0x00002000
#define MBOX_0_50_F1_LE_RD(src)                    (((src) & 0x00002000) >> 13)
#define MBOX_0_50_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*	 Fields mbox_0_4	 */
#define MBOX_0_40_F1_LE_WIDTH                                                 1
#define MBOX_0_40_F1_LE_SHIFT                                                11
#define MBOX_0_40_F1_LE_MASK                                         0x00001000
#define MBOX_0_40_F1_LE_RD(src)                    (((src) & 0x00001000) >> 12)
#define MBOX_0_40_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*	 Fields mbox_0_3	 */
#define MBOX_0_30_F1_LE_WIDTH                                                 1
#define MBOX_0_30_F1_LE_SHIFT                                                12
#define MBOX_0_30_F1_LE_MASK                                         0x00000800
#define MBOX_0_30_F1_LE_RD(src)                    (((src) & 0x00000800) >> 11)
#define MBOX_0_30_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*	 Fields mbox_0_2	 */
#define MBOX_0_20_F1_LE_WIDTH                                                 1
#define MBOX_0_20_F1_LE_SHIFT                                                13
#define MBOX_0_20_F1_LE_MASK                                         0x00000400
#define MBOX_0_20_F1_LE_RD(src)                    (((src) & 0x00000400) >> 10)
#define MBOX_0_20_F1_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*	 Fields mbox_0_1	 */
#define MBOX_0_10_F1_LE_WIDTH                                                 1
#define MBOX_0_10_F1_LE_SHIFT                                                14
#define MBOX_0_10_F1_LE_MASK                                         0x00000200
#define MBOX_0_10_F1_LE_RD(src)                     (((src) & 0x00000200) >> 9)
#define MBOX_0_10_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*	 Fields mbox_0_0	 */
#define MBOX_0_00_F1_LE_WIDTH                                                 1
#define MBOX_0_00_F1_LE_SHIFT                                                15
#define MBOX_0_00_F1_LE_MASK                                         0x00000100
#define MBOX_0_00_F1_LE_RD(src)                     (((src) & 0x00000100) >> 8)
#define MBOX_0_00_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*	 Fields mbox_1_15	 */
#define MBOX_1_150_F1_LE_WIDTH                                                1
#define MBOX_1_150_F1_LE_SHIFT                                               16
#define MBOX_1_150_F1_LE_MASK                                        0x00800000
#define MBOX_1_150_F1_LE_RD(src)                   (((src) & 0x00800000) >> 23)
#define MBOX_1_150_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*	 Fields mbox_1_14	 */
#define MBOX_1_140_F1_LE_WIDTH                                                1
#define MBOX_1_140_F1_LE_SHIFT                                               17
#define MBOX_1_140_F1_LE_MASK                                        0x00400000
#define MBOX_1_140_F1_LE_RD(src)                   (((src) & 0x00400000) >> 22)
#define MBOX_1_140_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*	 Fields mbox_1_13	 */
#define MBOX_1_130_F1_LE_WIDTH                                                1
#define MBOX_1_130_F1_LE_SHIFT                                               18
#define MBOX_1_130_F1_LE_MASK                                        0x00200000
#define MBOX_1_130_F1_LE_RD(src)                   (((src) & 0x00200000) >> 21)
#define MBOX_1_130_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*	 Fields mbox_1_12	 */
#define MBOX_1_120_F1_LE_WIDTH                                                1
#define MBOX_1_120_F1_LE_SHIFT                                               19
#define MBOX_1_120_F1_LE_MASK                                        0x00100000
#define MBOX_1_120_F1_LE_RD(src)                   (((src) & 0x00100000) >> 20)
#define MBOX_1_120_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields mbox_1_11	 */
#define MBOX_1_110_F1_LE_WIDTH                                                1
#define MBOX_1_110_F1_LE_SHIFT                                               20
#define MBOX_1_110_F1_LE_MASK                                        0x00080000
#define MBOX_1_110_F1_LE_RD(src)                   (((src) & 0x00080000) >> 19)
#define MBOX_1_110_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*	 Fields mbox_1_10	 */
#define MBOX_1_100_F1_LE_WIDTH                                                1
#define MBOX_1_100_F1_LE_SHIFT                                               21
#define MBOX_1_100_F1_LE_MASK                                        0x00040000
#define MBOX_1_100_F1_LE_RD(src)                   (((src) & 0x00040000) >> 18)
#define MBOX_1_100_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*	 Fields mbox_1_9	 */
#define MBOX_1_90_F1_LE_WIDTH                                                 1
#define MBOX_1_90_F1_LE_SHIFT                                                22
#define MBOX_1_90_F1_LE_MASK                                         0x00020000
#define MBOX_1_90_F1_LE_RD(src)                    (((src) & 0x00020000) >> 17)
#define MBOX_1_90_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*	 Fields mbox_1_8	 */
#define MBOX_1_80_F1_LE_WIDTH                                                 1
#define MBOX_1_80_F1_LE_SHIFT                                                23
#define MBOX_1_80_F1_LE_MASK                                         0x00010000
#define MBOX_1_80_F1_LE_RD(src)                    (((src) & 0x00010000) >> 16)
#define MBOX_1_80_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*	 Fields mbox_1_7	 */
#define MBOX_1_70_F1_LE_WIDTH                                                 1
#define MBOX_1_70_F1_LE_SHIFT                                                24
#define MBOX_1_70_F1_LE_MASK                                         0x80000000
#define MBOX_1_70_F1_LE_RD(src)                    (((src) & 0x80000000) >> 31)
#define MBOX_1_70_F1_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields mbox_1_6	 */
#define MBOX_1_60_F1_LE_WIDTH                                                 1
#define MBOX_1_60_F1_LE_SHIFT                                                25
#define MBOX_1_60_F1_LE_MASK                                         0x40000000
#define MBOX_1_60_F1_LE_RD(src)                    (((src) & 0x40000000) >> 30)
#define MBOX_1_60_F1_LE_SET(dst,src)                     ((dst)&~0x40000000)|\
				(((unsigned int)(src) << 30) & 0x40000000)

/*	 Fields mbox_1_5	 */
#define MBOX_1_50_F1_LE_WIDTH                                                 1
#define MBOX_1_50_F1_LE_SHIFT                                                26
#define MBOX_1_50_F1_LE_MASK                                         0x20000000
#define MBOX_1_50_F1_LE_RD(src)                    (((src) & 0x20000000) >> 29)
#define MBOX_1_50_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields mbox_1_4	 */
#define MBOX_1_40_F1_LE_WIDTH                                                 1
#define MBOX_1_40_F1_LE_SHIFT                                                27
#define MBOX_1_40_F1_LE_MASK                                         0x10000000
#define MBOX_1_40_F1_LE_RD(src)                    (((src) & 0x10000000) >> 28)
#define MBOX_1_40_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields mbox_1_3	 */
#define MBOX_1_30_F1_LE_WIDTH                                                 1
#define MBOX_1_30_F1_LE_SHIFT                                                28
#define MBOX_1_30_F1_LE_MASK                                         0x08000000
#define MBOX_1_30_F1_LE_RD(src)                    (((src) & 0x08000000) >> 27)
#define MBOX_1_30_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields mbox_1_2	 */
#define MBOX_1_20_F1_LE_WIDTH                                                 1
#define MBOX_1_20_F1_LE_SHIFT                                                29
#define MBOX_1_20_F1_LE_MASK                                         0x04000000
#define MBOX_1_20_F1_LE_RD(src)                    (((src) & 0x04000000) >> 26)
#define MBOX_1_20_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields mbox_1_1	 */
#define MBOX_1_10_F1_LE_WIDTH                                                 1
#define MBOX_1_10_F1_LE_SHIFT                                                30
#define MBOX_1_10_F1_LE_MASK                                         0x02000000
#define MBOX_1_10_F1_LE_RD(src)                    (((src) & 0x02000000) >> 25)
#define MBOX_1_10_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields mbox_1_0	 */
#define MBOX_1_00_F1_LE_WIDTH                                                 1
#define MBOX_1_00_F1_LE_SHIFT                                                31
#define MBOX_1_00_F1_LE_MASK                                         0x01000000
#define MBOX_1_00_F1_LE_RD(src)                    (((src) & 0x01000000) >> 24)
#define MBOX_1_00_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register csr_enq_status_1	*/

/*	 Fields mbox_2_15	 */
#define MBOX_2_151_F1_LE_WIDTH                                                1
#define MBOX_2_151_F1_LE_SHIFT                                                0
#define MBOX_2_151_F1_LE_MASK                                        0x00000080
#define MBOX_2_151_F1_LE_RD(src)                     (((src) & 0x00000080)<< 7)
#define MBOX_2_151_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields mbox_2_14	 */
#define MBOX_2_141_F1_LE_WIDTH                                                1
#define MBOX_2_141_F1_LE_SHIFT                                                1
#define MBOX_2_141_F1_LE_MASK                                        0x00000040
#define MBOX_2_141_F1_LE_RD(src)                     (((src) & 0x00000040)<< 6)
#define MBOX_2_141_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields mbox_2_13	 */
#define MBOX_2_131_F1_LE_WIDTH                                                1
#define MBOX_2_131_F1_LE_SHIFT                                                2
#define MBOX_2_131_F1_LE_MASK                                        0x00000020
#define MBOX_2_131_F1_LE_RD(src)                     (((src) & 0x00000020)<< 5)
#define MBOX_2_131_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*	 Fields mbox_2_12	 */
#define MBOX_2_121_F1_LE_WIDTH                                                1
#define MBOX_2_121_F1_LE_SHIFT                                                3
#define MBOX_2_121_F1_LE_MASK                                        0x00000010
#define MBOX_2_121_F1_LE_RD(src)                     (((src) & 0x00000010)<< 4)
#define MBOX_2_121_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields mbox_2_11	 */
#define MBOX_2_111_F1_LE_WIDTH                                                1
#define MBOX_2_111_F1_LE_SHIFT                                                4
#define MBOX_2_111_F1_LE_MASK                                        0x00000008
#define MBOX_2_111_F1_LE_RD(src)                     (((src) & 0x00000008)<< 3)
#define MBOX_2_111_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*	 Fields mbox_2_10	 */
#define MBOX_2_101_F1_LE_WIDTH                                                1
#define MBOX_2_101_F1_LE_SHIFT                                                5
#define MBOX_2_101_F1_LE_MASK                                        0x00000004
#define MBOX_2_101_F1_LE_RD(src)                     (((src) & 0x00000004)<< 2)
#define MBOX_2_101_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*	 Fields mbox_2_9	 */
#define MBOX_2_91_F1_LE_WIDTH                                                 1
#define MBOX_2_91_F1_LE_SHIFT                                                 6
#define MBOX_2_91_F1_LE_MASK                                         0x00000002
#define MBOX_2_91_F1_LE_RD(src)                      (((src) & 0x00000002)<< 1)
#define MBOX_2_91_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*	 Fields mbox_2_8	 */
#define MBOX_2_81_F1_LE_WIDTH                                                 1
#define MBOX_2_81_F1_LE_SHIFT                                                 7
#define MBOX_2_81_F1_LE_MASK                                         0x00000001
#define MBOX_2_81_F1_LE_RD(src)                      (((src) & 0x00000001)<< 0)
#define MBOX_2_81_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*	 Fields mbox_2_7	 */
#define MBOX_2_71_F1_LE_WIDTH                                                 1
#define MBOX_2_71_F1_LE_SHIFT                                                 8
#define MBOX_2_71_F1_LE_MASK                                         0x00008000
#define MBOX_2_71_F1_LE_RD(src)                    (((src) & 0x00008000) >> 15)
#define MBOX_2_71_F1_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*	 Fields mbox_2_6	 */
#define MBOX_2_61_F1_LE_WIDTH                                                 1
#define MBOX_2_61_F1_LE_SHIFT                                                 9
#define MBOX_2_61_F1_LE_MASK                                         0x00004000
#define MBOX_2_61_F1_LE_RD(src)                    (((src) & 0x00004000) >> 14)
#define MBOX_2_61_F1_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*	 Fields mbox_2_5	 */
#define MBOX_2_51_F1_LE_WIDTH                                                 1
#define MBOX_2_51_F1_LE_SHIFT                                                10
#define MBOX_2_51_F1_LE_MASK                                         0x00002000
#define MBOX_2_51_F1_LE_RD(src)                    (((src) & 0x00002000) >> 13)
#define MBOX_2_51_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*	 Fields mbox_2_4	 */
#define MBOX_2_41_F1_LE_WIDTH                                                 1
#define MBOX_2_41_F1_LE_SHIFT                                                11
#define MBOX_2_41_F1_LE_MASK                                         0x00001000
#define MBOX_2_41_F1_LE_RD(src)                    (((src) & 0x00001000) >> 12)
#define MBOX_2_41_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*	 Fields mbox_2_3	 */
#define MBOX_2_31_F1_LE_WIDTH                                                 1
#define MBOX_2_31_F1_LE_SHIFT                                                12
#define MBOX_2_31_F1_LE_MASK                                         0x00000800
#define MBOX_2_31_F1_LE_RD(src)                    (((src) & 0x00000800) >> 11)
#define MBOX_2_31_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*	 Fields mbox_2_2	 */
#define MBOX_2_21_F1_LE_WIDTH                                                 1
#define MBOX_2_21_F1_LE_SHIFT                                                13
#define MBOX_2_21_F1_LE_MASK                                         0x00000400
#define MBOX_2_21_F1_LE_RD(src)                    (((src) & 0x00000400) >> 10)
#define MBOX_2_21_F1_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*	 Fields mbox_2_1	 */
#define MBOX_2_11_F1_LE_WIDTH                                                 1
#define MBOX_2_11_F1_LE_SHIFT                                                14
#define MBOX_2_11_F1_LE_MASK                                         0x00000200
#define MBOX_2_11_F1_LE_RD(src)                     (((src) & 0x00000200) >> 9)
#define MBOX_2_11_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*	 Fields mbox_2_0	 */
#define MBOX_2_01_F1_LE_WIDTH                                                 1
#define MBOX_2_01_F1_LE_SHIFT                                                15
#define MBOX_2_01_F1_LE_MASK                                         0x00000100
#define MBOX_2_01_F1_LE_RD(src)                     (((src) & 0x00000100) >> 8)
#define MBOX_2_01_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*	 Fields mbox_3_15	 */
#define MBOX_3_151_F1_LE_WIDTH                                                1
#define MBOX_3_151_F1_LE_SHIFT                                               16
#define MBOX_3_151_F1_LE_MASK                                        0x00800000
#define MBOX_3_151_F1_LE_RD(src)                   (((src) & 0x00800000) >> 23)
#define MBOX_3_151_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*	 Fields mbox_3_14	 */
#define MBOX_3_141_F1_LE_WIDTH                                                1
#define MBOX_3_141_F1_LE_SHIFT                                               17
#define MBOX_3_141_F1_LE_MASK                                        0x00400000
#define MBOX_3_141_F1_LE_RD(src)                   (((src) & 0x00400000) >> 22)
#define MBOX_3_141_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*	 Fields mbox_3_13	 */
#define MBOX_3_131_F1_LE_WIDTH                                                1
#define MBOX_3_131_F1_LE_SHIFT                                               18
#define MBOX_3_131_F1_LE_MASK                                        0x00200000
#define MBOX_3_131_F1_LE_RD(src)                   (((src) & 0x00200000) >> 21)
#define MBOX_3_131_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*	 Fields mbox_3_12	 */
#define MBOX_3_121_F1_LE_WIDTH                                                1
#define MBOX_3_121_F1_LE_SHIFT                                               19
#define MBOX_3_121_F1_LE_MASK                                        0x00100000
#define MBOX_3_121_F1_LE_RD(src)                   (((src) & 0x00100000) >> 20)
#define MBOX_3_121_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields mbox_3_11	 */
#define MBOX_3_111_F1_LE_WIDTH                                                1
#define MBOX_3_111_F1_LE_SHIFT                                               20
#define MBOX_3_111_F1_LE_MASK                                        0x00080000
#define MBOX_3_111_F1_LE_RD(src)                   (((src) & 0x00080000) >> 19)
#define MBOX_3_111_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*	 Fields mbox_3_10	 */
#define MBOX_3_101_F1_LE_WIDTH                                                1
#define MBOX_3_101_F1_LE_SHIFT                                               21
#define MBOX_3_101_F1_LE_MASK                                        0x00040000
#define MBOX_3_101_F1_LE_RD(src)                   (((src) & 0x00040000) >> 18)
#define MBOX_3_101_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*	 Fields mbox_3_9	 */
#define MBOX_3_91_F1_LE_WIDTH                                                 1
#define MBOX_3_91_F1_LE_SHIFT                                                22
#define MBOX_3_91_F1_LE_MASK                                         0x00020000
#define MBOX_3_91_F1_LE_RD(src)                    (((src) & 0x00020000) >> 17)
#define MBOX_3_91_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*	 Fields mbox_3_8	 */
#define MBOX_3_81_F1_LE_WIDTH                                                 1
#define MBOX_3_81_F1_LE_SHIFT                                                23
#define MBOX_3_81_F1_LE_MASK                                         0x00010000
#define MBOX_3_81_F1_LE_RD(src)                    (((src) & 0x00010000) >> 16)
#define MBOX_3_81_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*	 Fields mbox_3_7	 */
#define MBOX_3_71_F1_LE_WIDTH                                                 1
#define MBOX_3_71_F1_LE_SHIFT                                                24
#define MBOX_3_71_F1_LE_MASK                                         0x80000000
#define MBOX_3_71_F1_LE_RD(src)                    (((src) & 0x80000000) >> 31)
#define MBOX_3_71_F1_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields mbox_3_6	 */
#define MBOX_3_61_F1_LE_WIDTH                                                 1
#define MBOX_3_61_F1_LE_SHIFT                                                25
#define MBOX_3_61_F1_LE_MASK                                         0x40000000
#define MBOX_3_61_F1_LE_RD(src)                    (((src) & 0x40000000) >> 30)
#define MBOX_3_61_F1_LE_SET(dst,src)                     ((dst)&~0x40000000)|\
				(((unsigned int)(src) << 30) & 0x40000000)

/*	 Fields mbox_3_5	 */
#define MBOX_3_51_F1_LE_WIDTH                                                 1
#define MBOX_3_51_F1_LE_SHIFT                                                26
#define MBOX_3_51_F1_LE_MASK                                         0x20000000
#define MBOX_3_51_F1_LE_RD(src)                    (((src) & 0x20000000) >> 29)
#define MBOX_3_51_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields mbox_3_4	 */
#define MBOX_3_41_F1_LE_WIDTH                                                 1
#define MBOX_3_41_F1_LE_SHIFT                                                27
#define MBOX_3_41_F1_LE_MASK                                         0x10000000
#define MBOX_3_41_F1_LE_RD(src)                    (((src) & 0x10000000) >> 28)
#define MBOX_3_41_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields mbox_3_3	 */
#define MBOX_3_31_F1_LE_WIDTH                                                 1
#define MBOX_3_31_F1_LE_SHIFT                                                28
#define MBOX_3_31_F1_LE_MASK                                         0x08000000
#define MBOX_3_31_F1_LE_RD(src)                    (((src) & 0x08000000) >> 27)
#define MBOX_3_31_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields mbox_3_2	 */
#define MBOX_3_21_F1_LE_WIDTH                                                 1
#define MBOX_3_21_F1_LE_SHIFT                                                29
#define MBOX_3_21_F1_LE_MASK                                         0x04000000
#define MBOX_3_21_F1_LE_RD(src)                    (((src) & 0x04000000) >> 26)
#define MBOX_3_21_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields mbox_3_1	 */
#define MBOX_3_11_F1_LE_WIDTH                                                 1
#define MBOX_3_11_F1_LE_SHIFT                                                30
#define MBOX_3_11_F1_LE_MASK                                         0x02000000
#define MBOX_3_11_F1_LE_RD(src)                    (((src) & 0x02000000) >> 25)
#define MBOX_3_11_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields mbox_3_0	 */
#define MBOX_3_01_F1_LE_WIDTH                                                 1
#define MBOX_3_01_F1_LE_SHIFT                                                31
#define MBOX_3_01_F1_LE_MASK                                         0x01000000
#define MBOX_3_01_F1_LE_RD(src)                    (((src) & 0x01000000) >> 24)
#define MBOX_3_01_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register csr_enq_status_2	*/

/*	 Fields mbox_4_15	 */
#define MBOX_4_152_F1_LE_WIDTH                                                1
#define MBOX_4_152_F1_LE_SHIFT                                                0
#define MBOX_4_152_F1_LE_MASK                                        0x00000080
#define MBOX_4_152_F1_LE_RD(src)                     (((src) & 0x00000080)<< 7)
#define MBOX_4_152_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields mbox_4_14	 */
#define MBOX_4_142_F1_LE_WIDTH                                                1
#define MBOX_4_142_F1_LE_SHIFT                                                1
#define MBOX_4_142_F1_LE_MASK                                        0x00000040
#define MBOX_4_142_F1_LE_RD(src)                     (((src) & 0x00000040)<< 6)
#define MBOX_4_142_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields mbox_4_13	 */
#define MBOX_4_132_F1_LE_WIDTH                                                1
#define MBOX_4_132_F1_LE_SHIFT                                                2
#define MBOX_4_132_F1_LE_MASK                                        0x00000020
#define MBOX_4_132_F1_LE_RD(src)                     (((src) & 0x00000020)<< 5)
#define MBOX_4_132_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*	 Fields mbox_4_12	 */
#define MBOX_4_122_F1_LE_WIDTH                                                1
#define MBOX_4_122_F1_LE_SHIFT                                                3
#define MBOX_4_122_F1_LE_MASK                                        0x00000010
#define MBOX_4_122_F1_LE_RD(src)                     (((src) & 0x00000010)<< 4)
#define MBOX_4_122_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields mbox_4_11	 */
#define MBOX_4_112_F1_LE_WIDTH                                                1
#define MBOX_4_112_F1_LE_SHIFT                                                4
#define MBOX_4_112_F1_LE_MASK                                        0x00000008
#define MBOX_4_112_F1_LE_RD(src)                     (((src) & 0x00000008)<< 3)
#define MBOX_4_112_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*	 Fields mbox_4_10	 */
#define MBOX_4_102_F1_LE_WIDTH                                                1
#define MBOX_4_102_F1_LE_SHIFT                                                5
#define MBOX_4_102_F1_LE_MASK                                        0x00000004
#define MBOX_4_102_F1_LE_RD(src)                     (((src) & 0x00000004)<< 2)
#define MBOX_4_102_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*	 Fields mbox_4_9	 */
#define MBOX_4_92_F1_LE_WIDTH                                                 1
#define MBOX_4_92_F1_LE_SHIFT                                                 6
#define MBOX_4_92_F1_LE_MASK                                         0x00000002
#define MBOX_4_92_F1_LE_RD(src)                      (((src) & 0x00000002)<< 1)
#define MBOX_4_92_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*	 Fields mbox_4_8	 */
#define MBOX_4_82_F1_LE_WIDTH                                                 1
#define MBOX_4_82_F1_LE_SHIFT                                                 7
#define MBOX_4_82_F1_LE_MASK                                         0x00000001
#define MBOX_4_82_F1_LE_RD(src)                      (((src) & 0x00000001)<< 0)
#define MBOX_4_82_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*	 Fields mbox_4_7	 */
#define MBOX_4_72_F1_LE_WIDTH                                                 1
#define MBOX_4_72_F1_LE_SHIFT                                                 8
#define MBOX_4_72_F1_LE_MASK                                         0x00008000
#define MBOX_4_72_F1_LE_RD(src)                    (((src) & 0x00008000) >> 15)
#define MBOX_4_72_F1_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*	 Fields mbox_4_6	 */
#define MBOX_4_62_F1_LE_WIDTH                                                 1
#define MBOX_4_62_F1_LE_SHIFT                                                 9
#define MBOX_4_62_F1_LE_MASK                                         0x00004000
#define MBOX_4_62_F1_LE_RD(src)                    (((src) & 0x00004000) >> 14)
#define MBOX_4_62_F1_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*	 Fields mbox_4_5	 */
#define MBOX_4_52_F1_LE_WIDTH                                                 1
#define MBOX_4_52_F1_LE_SHIFT                                                10
#define MBOX_4_52_F1_LE_MASK                                         0x00002000
#define MBOX_4_52_F1_LE_RD(src)                    (((src) & 0x00002000) >> 13)
#define MBOX_4_52_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*	 Fields mbox_4_4	 */
#define MBOX_4_42_F1_LE_WIDTH                                                 1
#define MBOX_4_42_F1_LE_SHIFT                                                11
#define MBOX_4_42_F1_LE_MASK                                         0x00001000
#define MBOX_4_42_F1_LE_RD(src)                    (((src) & 0x00001000) >> 12)
#define MBOX_4_42_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*	 Fields mbox_4_3	 */
#define MBOX_4_32_F1_LE_WIDTH                                                 1
#define MBOX_4_32_F1_LE_SHIFT                                                12
#define MBOX_4_32_F1_LE_MASK                                         0x00000800
#define MBOX_4_32_F1_LE_RD(src)                    (((src) & 0x00000800) >> 11)
#define MBOX_4_32_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*	 Fields mbox_4_2	 */
#define MBOX_4_22_F1_LE_WIDTH                                                 1
#define MBOX_4_22_F1_LE_SHIFT                                                13
#define MBOX_4_22_F1_LE_MASK                                         0x00000400
#define MBOX_4_22_F1_LE_RD(src)                    (((src) & 0x00000400) >> 10)
#define MBOX_4_22_F1_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*	 Fields mbox_4_1	 */
#define MBOX_4_12_F1_LE_WIDTH                                                 1
#define MBOX_4_12_F1_LE_SHIFT                                                14
#define MBOX_4_12_F1_LE_MASK                                         0x00000200
#define MBOX_4_12_F1_LE_RD(src)                     (((src) & 0x00000200) >> 9)
#define MBOX_4_12_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*	 Fields mbox_4_0	 */
#define MBOX_4_02_F1_LE_WIDTH                                                 1
#define MBOX_4_02_F1_LE_SHIFT                                                15
#define MBOX_4_02_F1_LE_MASK                                         0x00000100
#define MBOX_4_02_F1_LE_RD(src)                     (((src) & 0x00000100) >> 8)
#define MBOX_4_02_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*	 Fields mbox_5_15	 */
#define MBOX_5_152_F1_LE_WIDTH                                                1
#define MBOX_5_152_F1_LE_SHIFT                                               16
#define MBOX_5_152_F1_LE_MASK                                        0x00800000
#define MBOX_5_152_F1_LE_RD(src)                   (((src) & 0x00800000) >> 23)
#define MBOX_5_152_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*	 Fields mbox_5_14	 */
#define MBOX_5_142_F1_LE_WIDTH                                                1
#define MBOX_5_142_F1_LE_SHIFT                                               17
#define MBOX_5_142_F1_LE_MASK                                        0x00400000
#define MBOX_5_142_F1_LE_RD(src)                   (((src) & 0x00400000) >> 22)
#define MBOX_5_142_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*	 Fields mbox_5_13	 */
#define MBOX_5_132_F1_LE_WIDTH                                                1
#define MBOX_5_132_F1_LE_SHIFT                                               18
#define MBOX_5_132_F1_LE_MASK                                        0x00200000
#define MBOX_5_132_F1_LE_RD(src)                   (((src) & 0x00200000) >> 21)
#define MBOX_5_132_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*	 Fields mbox_5_12	 */
#define MBOX_5_122_F1_LE_WIDTH                                                1
#define MBOX_5_122_F1_LE_SHIFT                                               19
#define MBOX_5_122_F1_LE_MASK                                        0x00100000
#define MBOX_5_122_F1_LE_RD(src)                   (((src) & 0x00100000) >> 20)
#define MBOX_5_122_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields mbox_5_11	 */
#define MBOX_5_112_F1_LE_WIDTH                                                1
#define MBOX_5_112_F1_LE_SHIFT                                               20
#define MBOX_5_112_F1_LE_MASK                                        0x00080000
#define MBOX_5_112_F1_LE_RD(src)                   (((src) & 0x00080000) >> 19)
#define MBOX_5_112_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*	 Fields mbox_5_10	 */
#define MBOX_5_102_F1_LE_WIDTH                                                1
#define MBOX_5_102_F1_LE_SHIFT                                               21
#define MBOX_5_102_F1_LE_MASK                                        0x00040000
#define MBOX_5_102_F1_LE_RD(src)                   (((src) & 0x00040000) >> 18)
#define MBOX_5_102_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*	 Fields mbox_5_9	 */
#define MBOX_5_92_F1_LE_WIDTH                                                 1
#define MBOX_5_92_F1_LE_SHIFT                                                22
#define MBOX_5_92_F1_LE_MASK                                         0x00020000
#define MBOX_5_92_F1_LE_RD(src)                    (((src) & 0x00020000) >> 17)
#define MBOX_5_92_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*	 Fields mbox_5_8	 */
#define MBOX_5_82_F1_LE_WIDTH                                                 1
#define MBOX_5_82_F1_LE_SHIFT                                                23
#define MBOX_5_82_F1_LE_MASK                                         0x00010000
#define MBOX_5_82_F1_LE_RD(src)                    (((src) & 0x00010000) >> 16)
#define MBOX_5_82_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*	 Fields mbox_5_7	 */
#define MBOX_5_72_F1_LE_WIDTH                                                 1
#define MBOX_5_72_F1_LE_SHIFT                                                24
#define MBOX_5_72_F1_LE_MASK                                         0x80000000
#define MBOX_5_72_F1_LE_RD(src)                    (((src) & 0x80000000) >> 31)
#define MBOX_5_72_F1_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields mbox_5_6	 */
#define MBOX_5_62_F1_LE_WIDTH                                                 1
#define MBOX_5_62_F1_LE_SHIFT                                                25
#define MBOX_5_62_F1_LE_MASK                                         0x40000000
#define MBOX_5_62_F1_LE_RD(src)                    (((src) & 0x40000000) >> 30)
#define MBOX_5_62_F1_LE_SET(dst,src)                     ((dst)&~0x40000000)|\
				(((unsigned int)(src) << 30) & 0x40000000)

/*	 Fields mbox_5_5	 */
#define MBOX_5_52_F1_LE_WIDTH                                                 1
#define MBOX_5_52_F1_LE_SHIFT                                                26
#define MBOX_5_52_F1_LE_MASK                                         0x20000000
#define MBOX_5_52_F1_LE_RD(src)                    (((src) & 0x20000000) >> 29)
#define MBOX_5_52_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields mbox_5_4	 */
#define MBOX_5_42_F1_LE_WIDTH                                                 1
#define MBOX_5_42_F1_LE_SHIFT                                                27
#define MBOX_5_42_F1_LE_MASK                                         0x10000000
#define MBOX_5_42_F1_LE_RD(src)                    (((src) & 0x10000000) >> 28)
#define MBOX_5_42_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields mbox_5_3	 */
#define MBOX_5_32_F1_LE_WIDTH                                                 1
#define MBOX_5_32_F1_LE_SHIFT                                                28
#define MBOX_5_32_F1_LE_MASK                                         0x08000000
#define MBOX_5_32_F1_LE_RD(src)                    (((src) & 0x08000000) >> 27)
#define MBOX_5_32_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields mbox_5_2	 */
#define MBOX_5_22_F1_LE_WIDTH                                                 1
#define MBOX_5_22_F1_LE_SHIFT                                                29
#define MBOX_5_22_F1_LE_MASK                                         0x04000000
#define MBOX_5_22_F1_LE_RD(src)                    (((src) & 0x04000000) >> 26)
#define MBOX_5_22_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields mbox_5_1	 */
#define MBOX_5_12_F1_LE_WIDTH                                                 1
#define MBOX_5_12_F1_LE_SHIFT                                                30
#define MBOX_5_12_F1_LE_MASK                                         0x02000000
#define MBOX_5_12_F1_LE_RD(src)                    (((src) & 0x02000000) >> 25)
#define MBOX_5_12_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields mbox_5_0	 */
#define MBOX_5_02_F1_LE_WIDTH                                                 1
#define MBOX_5_02_F1_LE_SHIFT                                                31
#define MBOX_5_02_F1_LE_MASK                                         0x01000000
#define MBOX_5_02_F1_LE_RD(src)                    (((src) & 0x01000000) >> 24)
#define MBOX_5_02_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register csr_enq_status_3	*/

/*	 Fields mbox_6_15	 */
#define MBOX_6_153_F1_LE_WIDTH                                                1
#define MBOX_6_153_F1_LE_SHIFT                                                0
#define MBOX_6_153_F1_LE_MASK                                        0x00000080
#define MBOX_6_153_F1_LE_RD(src)                     (((src) & 0x00000080)<< 7)
#define MBOX_6_153_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields mbox_6_14	 */
#define MBOX_6_143_F1_LE_WIDTH                                                1
#define MBOX_6_143_F1_LE_SHIFT                                                1
#define MBOX_6_143_F1_LE_MASK                                        0x00000040
#define MBOX_6_143_F1_LE_RD(src)                     (((src) & 0x00000040)<< 6)
#define MBOX_6_143_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields mbox_6_13	 */
#define MBOX_6_133_F1_LE_WIDTH                                                1
#define MBOX_6_133_F1_LE_SHIFT                                                2
#define MBOX_6_133_F1_LE_MASK                                        0x00000020
#define MBOX_6_133_F1_LE_RD(src)                     (((src) & 0x00000020)<< 5)
#define MBOX_6_133_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*	 Fields mbox_6_12	 */
#define MBOX_6_123_F1_LE_WIDTH                                                1
#define MBOX_6_123_F1_LE_SHIFT                                                3
#define MBOX_6_123_F1_LE_MASK                                        0x00000010
#define MBOX_6_123_F1_LE_RD(src)                     (((src) & 0x00000010)<< 4)
#define MBOX_6_123_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields mbox_6_11	 */
#define MBOX_6_113_F1_LE_WIDTH                                                1
#define MBOX_6_113_F1_LE_SHIFT                                                4
#define MBOX_6_113_F1_LE_MASK                                        0x00000008
#define MBOX_6_113_F1_LE_RD(src)                     (((src) & 0x00000008)<< 3)
#define MBOX_6_113_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*	 Fields mbox_6_10	 */
#define MBOX_6_103_F1_LE_WIDTH                                                1
#define MBOX_6_103_F1_LE_SHIFT                                                5
#define MBOX_6_103_F1_LE_MASK                                        0x00000004
#define MBOX_6_103_F1_LE_RD(src)                     (((src) & 0x00000004)<< 2)
#define MBOX_6_103_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*	 Fields mbox_6_9	 */
#define MBOX_6_93_F1_LE_WIDTH                                                 1
#define MBOX_6_93_F1_LE_SHIFT                                                 6
#define MBOX_6_93_F1_LE_MASK                                         0x00000002
#define MBOX_6_93_F1_LE_RD(src)                      (((src) & 0x00000002)<< 1)
#define MBOX_6_93_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*	 Fields mbox_6_8	 */
#define MBOX_6_83_F1_LE_WIDTH                                                 1
#define MBOX_6_83_F1_LE_SHIFT                                                 7
#define MBOX_6_83_F1_LE_MASK                                         0x00000001
#define MBOX_6_83_F1_LE_RD(src)                      (((src) & 0x00000001)<< 0)
#define MBOX_6_83_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*	 Fields mbox_6_7	 */
#define MBOX_6_73_F1_LE_WIDTH                                                 1
#define MBOX_6_73_F1_LE_SHIFT                                                 8
#define MBOX_6_73_F1_LE_MASK                                         0x00008000
#define MBOX_6_73_F1_LE_RD(src)                    (((src) & 0x00008000) >> 15)
#define MBOX_6_73_F1_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*	 Fields mbox_6_6	 */
#define MBOX_6_63_F1_LE_WIDTH                                                 1
#define MBOX_6_63_F1_LE_SHIFT                                                 9
#define MBOX_6_63_F1_LE_MASK                                         0x00004000
#define MBOX_6_63_F1_LE_RD(src)                    (((src) & 0x00004000) >> 14)
#define MBOX_6_63_F1_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*	 Fields mbox_6_5	 */
#define MBOX_6_53_F1_LE_WIDTH                                                 1
#define MBOX_6_53_F1_LE_SHIFT                                                10
#define MBOX_6_53_F1_LE_MASK                                         0x00002000
#define MBOX_6_53_F1_LE_RD(src)                    (((src) & 0x00002000) >> 13)
#define MBOX_6_53_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*	 Fields mbox_6_4	 */
#define MBOX_6_43_F1_LE_WIDTH                                                 1
#define MBOX_6_43_F1_LE_SHIFT                                                11
#define MBOX_6_43_F1_LE_MASK                                         0x00001000
#define MBOX_6_43_F1_LE_RD(src)                    (((src) & 0x00001000) >> 12)
#define MBOX_6_43_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*	 Fields mbox_6_3	 */
#define MBOX_6_33_F1_LE_WIDTH                                                 1
#define MBOX_6_33_F1_LE_SHIFT                                                12
#define MBOX_6_33_F1_LE_MASK                                         0x00000800
#define MBOX_6_33_F1_LE_RD(src)                    (((src) & 0x00000800) >> 11)
#define MBOX_6_33_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*	 Fields mbox_6_2	 */
#define MBOX_6_23_F1_LE_WIDTH                                                 1
#define MBOX_6_23_F1_LE_SHIFT                                                13
#define MBOX_6_23_F1_LE_MASK                                         0x00000400
#define MBOX_6_23_F1_LE_RD(src)                    (((src) & 0x00000400) >> 10)
#define MBOX_6_23_F1_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*	 Fields mbox_6_1	 */
#define MBOX_6_13_F1_LE_WIDTH                                                 1
#define MBOX_6_13_F1_LE_SHIFT                                                14
#define MBOX_6_13_F1_LE_MASK                                         0x00000200
#define MBOX_6_13_F1_LE_RD(src)                     (((src) & 0x00000200) >> 9)
#define MBOX_6_13_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*	 Fields mbox_6_0	 */
#define MBOX_6_03_F1_LE_WIDTH                                                 1
#define MBOX_6_03_F1_LE_SHIFT                                                15
#define MBOX_6_03_F1_LE_MASK                                         0x00000100
#define MBOX_6_03_F1_LE_RD(src)                     (((src) & 0x00000100) >> 8)
#define MBOX_6_03_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*	 Fields mbox_7_15	 */
#define MBOX_7_153_F1_LE_WIDTH                                                1
#define MBOX_7_153_F1_LE_SHIFT                                               16
#define MBOX_7_153_F1_LE_MASK                                        0x00800000
#define MBOX_7_153_F1_LE_RD(src)                   (((src) & 0x00800000) >> 23)
#define MBOX_7_153_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*	 Fields mbox_7_14	 */
#define MBOX_7_143_F1_LE_WIDTH                                                1
#define MBOX_7_143_F1_LE_SHIFT                                               17
#define MBOX_7_143_F1_LE_MASK                                        0x00400000
#define MBOX_7_143_F1_LE_RD(src)                   (((src) & 0x00400000) >> 22)
#define MBOX_7_143_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*	 Fields mbox_7_13	 */
#define MBOX_7_133_F1_LE_WIDTH                                                1
#define MBOX_7_133_F1_LE_SHIFT                                               18
#define MBOX_7_133_F1_LE_MASK                                        0x00200000
#define MBOX_7_133_F1_LE_RD(src)                   (((src) & 0x00200000) >> 21)
#define MBOX_7_133_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*	 Fields mbox_7_12	 */
#define MBOX_7_123_F1_LE_WIDTH                                                1
#define MBOX_7_123_F1_LE_SHIFT                                               19
#define MBOX_7_123_F1_LE_MASK                                        0x00100000
#define MBOX_7_123_F1_LE_RD(src)                   (((src) & 0x00100000) >> 20)
#define MBOX_7_123_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields mbox_7_11	 */
#define MBOX_7_113_F1_LE_WIDTH                                                1
#define MBOX_7_113_F1_LE_SHIFT                                               20
#define MBOX_7_113_F1_LE_MASK                                        0x00080000
#define MBOX_7_113_F1_LE_RD(src)                   (((src) & 0x00080000) >> 19)
#define MBOX_7_113_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*	 Fields mbox_7_10	 */
#define MBOX_7_103_F1_LE_WIDTH                                                1
#define MBOX_7_103_F1_LE_SHIFT                                               21
#define MBOX_7_103_F1_LE_MASK                                        0x00040000
#define MBOX_7_103_F1_LE_RD(src)                   (((src) & 0x00040000) >> 18)
#define MBOX_7_103_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*	 Fields mbox_7_9	 */
#define MBOX_7_93_F1_LE_WIDTH                                                 1
#define MBOX_7_93_F1_LE_SHIFT                                                22
#define MBOX_7_93_F1_LE_MASK                                         0x00020000
#define MBOX_7_93_F1_LE_RD(src)                    (((src) & 0x00020000) >> 17)
#define MBOX_7_93_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*	 Fields mbox_7_8	 */
#define MBOX_7_83_F1_LE_WIDTH                                                 1
#define MBOX_7_83_F1_LE_SHIFT                                                23
#define MBOX_7_83_F1_LE_MASK                                         0x00010000
#define MBOX_7_83_F1_LE_RD(src)                    (((src) & 0x00010000) >> 16)
#define MBOX_7_83_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*	 Fields mbox_7_7	 */
#define MBOX_7_73_F1_LE_WIDTH                                                 1
#define MBOX_7_73_F1_LE_SHIFT                                                24
#define MBOX_7_73_F1_LE_MASK                                         0x80000000
#define MBOX_7_73_F1_LE_RD(src)                    (((src) & 0x80000000) >> 31)
#define MBOX_7_73_F1_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields mbox_7_6	 */
#define MBOX_7_63_F1_LE_WIDTH                                                 1
#define MBOX_7_63_F1_LE_SHIFT                                                25
#define MBOX_7_63_F1_LE_MASK                                         0x40000000
#define MBOX_7_63_F1_LE_RD(src)                    (((src) & 0x40000000) >> 30)
#define MBOX_7_63_F1_LE_SET(dst,src)                     ((dst)&~0x40000000)|\
				(((unsigned int)(src) << 30) & 0x40000000)

/*	 Fields mbox_7_5	 */
#define MBOX_7_53_F1_LE_WIDTH                                                 1
#define MBOX_7_53_F1_LE_SHIFT                                                26
#define MBOX_7_53_F1_LE_MASK                                         0x20000000
#define MBOX_7_53_F1_LE_RD(src)                    (((src) & 0x20000000) >> 29)
#define MBOX_7_53_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields mbox_7_4	 */
#define MBOX_7_43_F1_LE_WIDTH                                                 1
#define MBOX_7_43_F1_LE_SHIFT                                                27
#define MBOX_7_43_F1_LE_MASK                                         0x10000000
#define MBOX_7_43_F1_LE_RD(src)                    (((src) & 0x10000000) >> 28)
#define MBOX_7_43_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields mbox_7_3	 */
#define MBOX_7_33_F1_LE_WIDTH                                                 1
#define MBOX_7_33_F1_LE_SHIFT                                                28
#define MBOX_7_33_F1_LE_MASK                                         0x08000000
#define MBOX_7_33_F1_LE_RD(src)                    (((src) & 0x08000000) >> 27)
#define MBOX_7_33_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields mbox_7_2	 */
#define MBOX_7_23_F1_LE_WIDTH                                                 1
#define MBOX_7_23_F1_LE_SHIFT                                                29
#define MBOX_7_23_F1_LE_MASK                                         0x04000000
#define MBOX_7_23_F1_LE_RD(src)                    (((src) & 0x04000000) >> 26)
#define MBOX_7_23_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields mbox_7_1	 */
#define MBOX_7_13_F1_LE_WIDTH                                                 1
#define MBOX_7_13_F1_LE_SHIFT                                                30
#define MBOX_7_13_F1_LE_MASK                                         0x02000000
#define MBOX_7_13_F1_LE_RD(src)                    (((src) & 0x02000000) >> 25)
#define MBOX_7_13_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields mbox_7_0	 */
#define MBOX_7_03_F1_LE_WIDTH                                                 1
#define MBOX_7_03_F1_LE_SHIFT                                                31
#define MBOX_7_03_F1_LE_MASK                                         0x01000000
#define MBOX_7_03_F1_LE_RD(src)                    (((src) & 0x01000000) >> 24)
#define MBOX_7_03_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register csr_enq_status_4	*/

/*	 Fields mbox_8_15	 */
#define MBOX_8_154_F1_LE_WIDTH                                                1
#define MBOX_8_154_F1_LE_SHIFT                                                0
#define MBOX_8_154_F1_LE_MASK                                        0x00000080
#define MBOX_8_154_F1_LE_RD(src)                     (((src) & 0x00000080)<< 7)
#define MBOX_8_154_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields mbox_8_14	 */
#define MBOX_8_144_F1_LE_WIDTH                                                1
#define MBOX_8_144_F1_LE_SHIFT                                                1
#define MBOX_8_144_F1_LE_MASK                                        0x00000040
#define MBOX_8_144_F1_LE_RD(src)                     (((src) & 0x00000040)<< 6)
#define MBOX_8_144_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields mbox_8_13	 */
#define MBOX_8_134_F1_LE_WIDTH                                                1
#define MBOX_8_134_F1_LE_SHIFT                                                2
#define MBOX_8_134_F1_LE_MASK                                        0x00000020
#define MBOX_8_134_F1_LE_RD(src)                     (((src) & 0x00000020)<< 5)
#define MBOX_8_134_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*	 Fields mbox_8_12	 */
#define MBOX_8_124_F1_LE_WIDTH                                                1
#define MBOX_8_124_F1_LE_SHIFT                                                3
#define MBOX_8_124_F1_LE_MASK                                        0x00000010
#define MBOX_8_124_F1_LE_RD(src)                     (((src) & 0x00000010)<< 4)
#define MBOX_8_124_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields mbox_8_11	 */
#define MBOX_8_114_F1_LE_WIDTH                                                1
#define MBOX_8_114_F1_LE_SHIFT                                                4
#define MBOX_8_114_F1_LE_MASK                                        0x00000008
#define MBOX_8_114_F1_LE_RD(src)                     (((src) & 0x00000008)<< 3)
#define MBOX_8_114_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*	 Fields mbox_8_10	 */
#define MBOX_8_104_F1_LE_WIDTH                                                1
#define MBOX_8_104_F1_LE_SHIFT                                                5
#define MBOX_8_104_F1_LE_MASK                                        0x00000004
#define MBOX_8_104_F1_LE_RD(src)                     (((src) & 0x00000004)<< 2)
#define MBOX_8_104_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*	 Fields mbox_8_9	 */
#define MBOX_8_94_F1_LE_WIDTH                                                 1
#define MBOX_8_94_F1_LE_SHIFT                                                 6
#define MBOX_8_94_F1_LE_MASK                                         0x00000002
#define MBOX_8_94_F1_LE_RD(src)                      (((src) & 0x00000002)<< 1)
#define MBOX_8_94_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*	 Fields mbox_8_8	 */
#define MBOX_8_84_F1_LE_WIDTH                                                 1
#define MBOX_8_84_F1_LE_SHIFT                                                 7
#define MBOX_8_84_F1_LE_MASK                                         0x00000001
#define MBOX_8_84_F1_LE_RD(src)                      (((src) & 0x00000001)<< 0)
#define MBOX_8_84_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*	 Fields mbox_8_7	 */
#define MBOX_8_74_F1_LE_WIDTH                                                 1
#define MBOX_8_74_F1_LE_SHIFT                                                 8
#define MBOX_8_74_F1_LE_MASK                                         0x00008000
#define MBOX_8_74_F1_LE_RD(src)                    (((src) & 0x00008000) >> 15)
#define MBOX_8_74_F1_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*	 Fields mbox_8_6	 */
#define MBOX_8_64_F1_LE_WIDTH                                                 1
#define MBOX_8_64_F1_LE_SHIFT                                                 9
#define MBOX_8_64_F1_LE_MASK                                         0x00004000
#define MBOX_8_64_F1_LE_RD(src)                    (((src) & 0x00004000) >> 14)
#define MBOX_8_64_F1_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*	 Fields mbox_8_5	 */
#define MBOX_8_54_F1_LE_WIDTH                                                 1
#define MBOX_8_54_F1_LE_SHIFT                                                10
#define MBOX_8_54_F1_LE_MASK                                         0x00002000
#define MBOX_8_54_F1_LE_RD(src)                    (((src) & 0x00002000) >> 13)
#define MBOX_8_54_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*	 Fields mbox_8_4	 */
#define MBOX_8_44_F1_LE_WIDTH                                                 1
#define MBOX_8_44_F1_LE_SHIFT                                                11
#define MBOX_8_44_F1_LE_MASK                                         0x00001000
#define MBOX_8_44_F1_LE_RD(src)                    (((src) & 0x00001000) >> 12)
#define MBOX_8_44_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*	 Fields mbox_8_3	 */
#define MBOX_8_34_F1_LE_WIDTH                                                 1
#define MBOX_8_34_F1_LE_SHIFT                                                12
#define MBOX_8_34_F1_LE_MASK                                         0x00000800
#define MBOX_8_34_F1_LE_RD(src)                    (((src) & 0x00000800) >> 11)
#define MBOX_8_34_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*	 Fields mbox_8_2	 */
#define MBOX_8_24_F1_LE_WIDTH                                                 1
#define MBOX_8_24_F1_LE_SHIFT                                                13
#define MBOX_8_24_F1_LE_MASK                                         0x00000400
#define MBOX_8_24_F1_LE_RD(src)                    (((src) & 0x00000400) >> 10)
#define MBOX_8_24_F1_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*	 Fields mbox_8_1	 */
#define MBOX_8_14_F1_LE_WIDTH                                                 1
#define MBOX_8_14_F1_LE_SHIFT                                                14
#define MBOX_8_14_F1_LE_MASK                                         0x00000200
#define MBOX_8_14_F1_LE_RD(src)                     (((src) & 0x00000200) >> 9)
#define MBOX_8_14_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*	 Fields mbox_8_0	 */
#define MBOX_8_04_F1_LE_WIDTH                                                 1
#define MBOX_8_04_F1_LE_SHIFT                                                15
#define MBOX_8_04_F1_LE_MASK                                         0x00000100
#define MBOX_8_04_F1_LE_RD(src)                     (((src) & 0x00000100) >> 8)
#define MBOX_8_04_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*	 Fields mbox_9_15	 */
#define MBOX_9_154_F1_LE_WIDTH                                                1
#define MBOX_9_154_F1_LE_SHIFT                                               16
#define MBOX_9_154_F1_LE_MASK                                        0x00800000
#define MBOX_9_154_F1_LE_RD(src)                   (((src) & 0x00800000) >> 23)
#define MBOX_9_154_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*	 Fields mbox_9_14	 */
#define MBOX_9_144_F1_LE_WIDTH                                                1
#define MBOX_9_144_F1_LE_SHIFT                                               17
#define MBOX_9_144_F1_LE_MASK                                        0x00400000
#define MBOX_9_144_F1_LE_RD(src)                   (((src) & 0x00400000) >> 22)
#define MBOX_9_144_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*	 Fields mbox_9_13	 */
#define MBOX_9_134_F1_LE_WIDTH                                                1
#define MBOX_9_134_F1_LE_SHIFT                                               18
#define MBOX_9_134_F1_LE_MASK                                        0x00200000
#define MBOX_9_134_F1_LE_RD(src)                   (((src) & 0x00200000) >> 21)
#define MBOX_9_134_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*	 Fields mbox_9_12	 */
#define MBOX_9_124_F1_LE_WIDTH                                                1
#define MBOX_9_124_F1_LE_SHIFT                                               19
#define MBOX_9_124_F1_LE_MASK                                        0x00100000
#define MBOX_9_124_F1_LE_RD(src)                   (((src) & 0x00100000) >> 20)
#define MBOX_9_124_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields mbox_9_11	 */
#define MBOX_9_114_F1_LE_WIDTH                                                1
#define MBOX_9_114_F1_LE_SHIFT                                               20
#define MBOX_9_114_F1_LE_MASK                                        0x00080000
#define MBOX_9_114_F1_LE_RD(src)                   (((src) & 0x00080000) >> 19)
#define MBOX_9_114_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*	 Fields mbox_9_10	 */
#define MBOX_9_104_F1_LE_WIDTH                                                1
#define MBOX_9_104_F1_LE_SHIFT                                               21
#define MBOX_9_104_F1_LE_MASK                                        0x00040000
#define MBOX_9_104_F1_LE_RD(src)                   (((src) & 0x00040000) >> 18)
#define MBOX_9_104_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*	 Fields mbox_9_9	 */
#define MBOX_9_94_F1_LE_WIDTH                                                 1
#define MBOX_9_94_F1_LE_SHIFT                                                22
#define MBOX_9_94_F1_LE_MASK                                         0x00020000
#define MBOX_9_94_F1_LE_RD(src)                    (((src) & 0x00020000) >> 17)
#define MBOX_9_94_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*	 Fields mbox_9_8	 */
#define MBOX_9_84_F1_LE_WIDTH                                                 1
#define MBOX_9_84_F1_LE_SHIFT                                                23
#define MBOX_9_84_F1_LE_MASK                                         0x00010000
#define MBOX_9_84_F1_LE_RD(src)                    (((src) & 0x00010000) >> 16)
#define MBOX_9_84_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*	 Fields mbox_9_7	 */
#define MBOX_9_74_F1_LE_WIDTH                                                 1
#define MBOX_9_74_F1_LE_SHIFT                                                24
#define MBOX_9_74_F1_LE_MASK                                         0x80000000
#define MBOX_9_74_F1_LE_RD(src)                    (((src) & 0x80000000) >> 31)
#define MBOX_9_74_F1_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields mbox_9_6	 */
#define MBOX_9_64_F1_LE_WIDTH                                                 1
#define MBOX_9_64_F1_LE_SHIFT                                                25
#define MBOX_9_64_F1_LE_MASK                                         0x40000000
#define MBOX_9_64_F1_LE_RD(src)                    (((src) & 0x40000000) >> 30)
#define MBOX_9_64_F1_LE_SET(dst,src)                     ((dst)&~0x40000000)|\
				(((unsigned int)(src) << 30) & 0x40000000)

/*	 Fields mbox_9_5	 */
#define MBOX_9_54_F1_LE_WIDTH                                                 1
#define MBOX_9_54_F1_LE_SHIFT                                                26
#define MBOX_9_54_F1_LE_MASK                                         0x20000000
#define MBOX_9_54_F1_LE_RD(src)                    (((src) & 0x20000000) >> 29)
#define MBOX_9_54_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields mbox_9_4	 */
#define MBOX_9_44_F1_LE_WIDTH                                                 1
#define MBOX_9_44_F1_LE_SHIFT                                                27
#define MBOX_9_44_F1_LE_MASK                                         0x10000000
#define MBOX_9_44_F1_LE_RD(src)                    (((src) & 0x10000000) >> 28)
#define MBOX_9_44_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields mbox_9_3	 */
#define MBOX_9_34_F1_LE_WIDTH                                                 1
#define MBOX_9_34_F1_LE_SHIFT                                                28
#define MBOX_9_34_F1_LE_MASK                                         0x08000000
#define MBOX_9_34_F1_LE_RD(src)                    (((src) & 0x08000000) >> 27)
#define MBOX_9_34_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields mbox_9_2	 */
#define MBOX_9_24_F1_LE_WIDTH                                                 1
#define MBOX_9_24_F1_LE_SHIFT                                                29
#define MBOX_9_24_F1_LE_MASK                                         0x04000000
#define MBOX_9_24_F1_LE_RD(src)                    (((src) & 0x04000000) >> 26)
#define MBOX_9_24_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields mbox_9_1	 */
#define MBOX_9_14_F1_LE_WIDTH                                                 1
#define MBOX_9_14_F1_LE_SHIFT                                                30
#define MBOX_9_14_F1_LE_MASK                                         0x02000000
#define MBOX_9_14_F1_LE_RD(src)                    (((src) & 0x02000000) >> 25)
#define MBOX_9_14_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields mbox_9_0	 */
#define MBOX_9_04_F1_LE_WIDTH                                                 1
#define MBOX_9_04_F1_LE_SHIFT                                                31
#define MBOX_9_04_F1_LE_MASK                                         0x01000000
#define MBOX_9_04_F1_LE_RD(src)                    (((src) & 0x01000000) >> 24)
#define MBOX_9_04_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register csr_enq_status_5	*/

/*	 Fields mbox_10_15	 */
#define MBOX_10_155_F1_LE_WIDTH                                               1
#define MBOX_10_155_F1_LE_SHIFT                                               0
#define MBOX_10_155_F1_LE_MASK                                       0x00000080
#define MBOX_10_155_F1_LE_RD(src)                    (((src) & 0x00000080)<< 7)
#define MBOX_10_155_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields mbox_10_14	 */
#define MBOX_10_145_F1_LE_WIDTH                                               1
#define MBOX_10_145_F1_LE_SHIFT                                               1
#define MBOX_10_145_F1_LE_MASK                                       0x00000040
#define MBOX_10_145_F1_LE_RD(src)                    (((src) & 0x00000040)<< 6)
#define MBOX_10_145_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields mbox_10_13	 */
#define MBOX_10_135_F1_LE_WIDTH                                               1
#define MBOX_10_135_F1_LE_SHIFT                                               2
#define MBOX_10_135_F1_LE_MASK                                       0x00000020
#define MBOX_10_135_F1_LE_RD(src)                    (((src) & 0x00000020)<< 5)
#define MBOX_10_135_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*	 Fields mbox_10_12	 */
#define MBOX_10_125_F1_LE_WIDTH                                               1
#define MBOX_10_125_F1_LE_SHIFT                                               3
#define MBOX_10_125_F1_LE_MASK                                       0x00000010
#define MBOX_10_125_F1_LE_RD(src)                    (((src) & 0x00000010)<< 4)
#define MBOX_10_125_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields mbox_10_11	 */
#define MBOX_10_115_F1_LE_WIDTH                                               1
#define MBOX_10_115_F1_LE_SHIFT                                               4
#define MBOX_10_115_F1_LE_MASK                                       0x00000008
#define MBOX_10_115_F1_LE_RD(src)                    (((src) & 0x00000008)<< 3)
#define MBOX_10_115_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*	 Fields mbox_10_10	 */
#define MBOX_10_105_F1_LE_WIDTH                                               1
#define MBOX_10_105_F1_LE_SHIFT                                               5
#define MBOX_10_105_F1_LE_MASK                                       0x00000004
#define MBOX_10_105_F1_LE_RD(src)                    (((src) & 0x00000004)<< 2)
#define MBOX_10_105_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*	 Fields mbox_10_9	 */
#define MBOX_10_95_F1_LE_WIDTH                                                1
#define MBOX_10_95_F1_LE_SHIFT                                                6
#define MBOX_10_95_F1_LE_MASK                                        0x00000002
#define MBOX_10_95_F1_LE_RD(src)                     (((src) & 0x00000002)<< 1)
#define MBOX_10_95_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*	 Fields mbox_10_8	 */
#define MBOX_10_85_F1_LE_WIDTH                                                1
#define MBOX_10_85_F1_LE_SHIFT                                                7
#define MBOX_10_85_F1_LE_MASK                                        0x00000001
#define MBOX_10_85_F1_LE_RD(src)                     (((src) & 0x00000001)<< 0)
#define MBOX_10_85_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*	 Fields mbox_10_7	 */
#define MBOX_10_75_F1_LE_WIDTH                                                1
#define MBOX_10_75_F1_LE_SHIFT                                                8
#define MBOX_10_75_F1_LE_MASK                                        0x00008000
#define MBOX_10_75_F1_LE_RD(src)                   (((src) & 0x00008000) >> 15)
#define MBOX_10_75_F1_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*	 Fields mbox_10_6	 */
#define MBOX_10_65_F1_LE_WIDTH                                                1
#define MBOX_10_65_F1_LE_SHIFT                                                9
#define MBOX_10_65_F1_LE_MASK                                        0x00004000
#define MBOX_10_65_F1_LE_RD(src)                   (((src) & 0x00004000) >> 14)
#define MBOX_10_65_F1_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*	 Fields mbox_10_5	 */
#define MBOX_10_55_F1_LE_WIDTH                                                1
#define MBOX_10_55_F1_LE_SHIFT                                               10
#define MBOX_10_55_F1_LE_MASK                                        0x00002000
#define MBOX_10_55_F1_LE_RD(src)                   (((src) & 0x00002000) >> 13)
#define MBOX_10_55_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*	 Fields mbox_10_4	 */
#define MBOX_10_45_F1_LE_WIDTH                                                1
#define MBOX_10_45_F1_LE_SHIFT                                               11
#define MBOX_10_45_F1_LE_MASK                                        0x00001000
#define MBOX_10_45_F1_LE_RD(src)                   (((src) & 0x00001000) >> 12)
#define MBOX_10_45_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*	 Fields mbox_10_3	 */
#define MBOX_10_35_F1_LE_WIDTH                                                1
#define MBOX_10_35_F1_LE_SHIFT                                               12
#define MBOX_10_35_F1_LE_MASK                                        0x00000800
#define MBOX_10_35_F1_LE_RD(src)                   (((src) & 0x00000800) >> 11)
#define MBOX_10_35_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*	 Fields mbox_10_2	 */
#define MBOX_10_25_F1_LE_WIDTH                                                1
#define MBOX_10_25_F1_LE_SHIFT                                               13
#define MBOX_10_25_F1_LE_MASK                                        0x00000400
#define MBOX_10_25_F1_LE_RD(src)                   (((src) & 0x00000400) >> 10)
#define MBOX_10_25_F1_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*	 Fields mbox_10_1	 */
#define MBOX_10_15_F1_LE_WIDTH                                                1
#define MBOX_10_15_F1_LE_SHIFT                                               14
#define MBOX_10_15_F1_LE_MASK                                        0x00000200
#define MBOX_10_15_F1_LE_RD(src)                    (((src) & 0x00000200) >> 9)
#define MBOX_10_15_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*	 Fields mbox_10_0	 */
#define MBOX_10_05_F1_LE_WIDTH                                                1
#define MBOX_10_05_F1_LE_SHIFT                                               15
#define MBOX_10_05_F1_LE_MASK                                        0x00000100
#define MBOX_10_05_F1_LE_RD(src)                    (((src) & 0x00000100) >> 8)
#define MBOX_10_05_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*	 Fields mbox_11_15	 */
#define MBOX_11_155_F1_LE_WIDTH                                               1
#define MBOX_11_155_F1_LE_SHIFT                                              16
#define MBOX_11_155_F1_LE_MASK                                       0x00800000
#define MBOX_11_155_F1_LE_RD(src)                  (((src) & 0x00800000) >> 23)
#define MBOX_11_155_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*	 Fields mbox_11_14	 */
#define MBOX_11_145_F1_LE_WIDTH                                               1
#define MBOX_11_145_F1_LE_SHIFT                                              17
#define MBOX_11_145_F1_LE_MASK                                       0x00400000
#define MBOX_11_145_F1_LE_RD(src)                  (((src) & 0x00400000) >> 22)
#define MBOX_11_145_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*	 Fields mbox_11_13	 */
#define MBOX_11_135_F1_LE_WIDTH                                               1
#define MBOX_11_135_F1_LE_SHIFT                                              18
#define MBOX_11_135_F1_LE_MASK                                       0x00200000
#define MBOX_11_135_F1_LE_RD(src)                  (((src) & 0x00200000) >> 21)
#define MBOX_11_135_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*	 Fields mbox_11_12	 */
#define MBOX_11_125_F1_LE_WIDTH                                               1
#define MBOX_11_125_F1_LE_SHIFT                                              19
#define MBOX_11_125_F1_LE_MASK                                       0x00100000
#define MBOX_11_125_F1_LE_RD(src)                  (((src) & 0x00100000) >> 20)
#define MBOX_11_125_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields mbox_11_11	 */
#define MBOX_11_115_F1_LE_WIDTH                                               1
#define MBOX_11_115_F1_LE_SHIFT                                              20
#define MBOX_11_115_F1_LE_MASK                                       0x00080000
#define MBOX_11_115_F1_LE_RD(src)                  (((src) & 0x00080000) >> 19)
#define MBOX_11_115_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*	 Fields mbox_11_10	 */
#define MBOX_11_105_F1_LE_WIDTH                                               1
#define MBOX_11_105_F1_LE_SHIFT                                              21
#define MBOX_11_105_F1_LE_MASK                                       0x00040000
#define MBOX_11_105_F1_LE_RD(src)                  (((src) & 0x00040000) >> 18)
#define MBOX_11_105_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*	 Fields mbox_11_9	 */
#define MBOX_11_95_F1_LE_WIDTH                                                1
#define MBOX_11_95_F1_LE_SHIFT                                               22
#define MBOX_11_95_F1_LE_MASK                                        0x00020000
#define MBOX_11_95_F1_LE_RD(src)                   (((src) & 0x00020000) >> 17)
#define MBOX_11_95_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*	 Fields mbox_11_8	 */
#define MBOX_11_85_F1_LE_WIDTH                                                1
#define MBOX_11_85_F1_LE_SHIFT                                               23
#define MBOX_11_85_F1_LE_MASK                                        0x00010000
#define MBOX_11_85_F1_LE_RD(src)                   (((src) & 0x00010000) >> 16)
#define MBOX_11_85_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*	 Fields mbox_11_7	 */
#define MBOX_11_75_F1_LE_WIDTH                                                1
#define MBOX_11_75_F1_LE_SHIFT                                               24
#define MBOX_11_75_F1_LE_MASK                                        0x80000000
#define MBOX_11_75_F1_LE_RD(src)                   (((src) & 0x80000000) >> 31)
#define MBOX_11_75_F1_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields mbox_11_6	 */
#define MBOX_11_65_F1_LE_WIDTH                                                1
#define MBOX_11_65_F1_LE_SHIFT                                               25
#define MBOX_11_65_F1_LE_MASK                                        0x40000000
#define MBOX_11_65_F1_LE_RD(src)                   (((src) & 0x40000000) >> 30)
#define MBOX_11_65_F1_LE_SET(dst,src)                     ((dst)&~0x40000000)|\
				(((unsigned int)(src) << 30) & 0x40000000)

/*	 Fields mbox_11_5	 */
#define MBOX_11_55_F1_LE_WIDTH                                                1
#define MBOX_11_55_F1_LE_SHIFT                                               26
#define MBOX_11_55_F1_LE_MASK                                        0x20000000
#define MBOX_11_55_F1_LE_RD(src)                   (((src) & 0x20000000) >> 29)
#define MBOX_11_55_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields mbox_11_4	 */
#define MBOX_11_45_F1_LE_WIDTH                                                1
#define MBOX_11_45_F1_LE_SHIFT                                               27
#define MBOX_11_45_F1_LE_MASK                                        0x10000000
#define MBOX_11_45_F1_LE_RD(src)                   (((src) & 0x10000000) >> 28)
#define MBOX_11_45_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields mbox_11_3	 */
#define MBOX_11_35_F1_LE_WIDTH                                                1
#define MBOX_11_35_F1_LE_SHIFT                                               28
#define MBOX_11_35_F1_LE_MASK                                        0x08000000
#define MBOX_11_35_F1_LE_RD(src)                   (((src) & 0x08000000) >> 27)
#define MBOX_11_35_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields mbox_11_2	 */
#define MBOX_11_25_F1_LE_WIDTH                                                1
#define MBOX_11_25_F1_LE_SHIFT                                               29
#define MBOX_11_25_F1_LE_MASK                                        0x04000000
#define MBOX_11_25_F1_LE_RD(src)                   (((src) & 0x04000000) >> 26)
#define MBOX_11_25_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields mbox_11_1	 */
#define MBOX_11_15_F1_LE_WIDTH                                                1
#define MBOX_11_15_F1_LE_SHIFT                                               30
#define MBOX_11_15_F1_LE_MASK                                        0x02000000
#define MBOX_11_15_F1_LE_RD(src)                   (((src) & 0x02000000) >> 25)
#define MBOX_11_15_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields mbox_11_0	 */
#define MBOX_11_05_F1_LE_WIDTH                                                1
#define MBOX_11_05_F1_LE_SHIFT                                               31
#define MBOX_11_05_F1_LE_MASK                                        0x01000000
#define MBOX_11_05_F1_LE_RD(src)                   (((src) & 0x01000000) >> 24)
#define MBOX_11_05_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register csr_enq_status_6	*/

/*	 Fields mbox_12_15	 */
#define MBOX_12_156_F1_LE_WIDTH                                               1
#define MBOX_12_156_F1_LE_SHIFT                                               0
#define MBOX_12_156_F1_LE_MASK                                       0x00000080
#define MBOX_12_156_F1_LE_RD(src)                    (((src) & 0x00000080)<< 7)
#define MBOX_12_156_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields mbox_12_14	 */
#define MBOX_12_146_F1_LE_WIDTH                                               1
#define MBOX_12_146_F1_LE_SHIFT                                               1
#define MBOX_12_146_F1_LE_MASK                                       0x00000040
#define MBOX_12_146_F1_LE_RD(src)                    (((src) & 0x00000040)<< 6)
#define MBOX_12_146_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields mbox_12_13	 */
#define MBOX_12_136_F1_LE_WIDTH                                               1
#define MBOX_12_136_F1_LE_SHIFT                                               2
#define MBOX_12_136_F1_LE_MASK                                       0x00000020
#define MBOX_12_136_F1_LE_RD(src)                    (((src) & 0x00000020)<< 5)
#define MBOX_12_136_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*	 Fields mbox_12_12	 */
#define MBOX_12_126_F1_LE_WIDTH                                               1
#define MBOX_12_126_F1_LE_SHIFT                                               3
#define MBOX_12_126_F1_LE_MASK                                       0x00000010
#define MBOX_12_126_F1_LE_RD(src)                    (((src) & 0x00000010)<< 4)
#define MBOX_12_126_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields mbox_12_11	 */
#define MBOX_12_116_F1_LE_WIDTH                                               1
#define MBOX_12_116_F1_LE_SHIFT                                               4
#define MBOX_12_116_F1_LE_MASK                                       0x00000008
#define MBOX_12_116_F1_LE_RD(src)                    (((src) & 0x00000008)<< 3)
#define MBOX_12_116_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*	 Fields mbox_12_10	 */
#define MBOX_12_106_F1_LE_WIDTH                                               1
#define MBOX_12_106_F1_LE_SHIFT                                               5
#define MBOX_12_106_F1_LE_MASK                                       0x00000004
#define MBOX_12_106_F1_LE_RD(src)                    (((src) & 0x00000004)<< 2)
#define MBOX_12_106_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*	 Fields mbox_12_9	 */
#define MBOX_12_96_F1_LE_WIDTH                                                1
#define MBOX_12_96_F1_LE_SHIFT                                                6
#define MBOX_12_96_F1_LE_MASK                                        0x00000002
#define MBOX_12_96_F1_LE_RD(src)                     (((src) & 0x00000002)<< 1)
#define MBOX_12_96_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*	 Fields mbox_12_8	 */
#define MBOX_12_86_F1_LE_WIDTH                                                1
#define MBOX_12_86_F1_LE_SHIFT                                                7
#define MBOX_12_86_F1_LE_MASK                                        0x00000001
#define MBOX_12_86_F1_LE_RD(src)                     (((src) & 0x00000001)<< 0)
#define MBOX_12_86_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*	 Fields mbox_12_7	 */
#define MBOX_12_76_F1_LE_WIDTH                                                1
#define MBOX_12_76_F1_LE_SHIFT                                                8
#define MBOX_12_76_F1_LE_MASK                                        0x00008000
#define MBOX_12_76_F1_LE_RD(src)                   (((src) & 0x00008000) >> 15)
#define MBOX_12_76_F1_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*	 Fields mbox_12_6	 */
#define MBOX_12_66_F1_LE_WIDTH                                                1
#define MBOX_12_66_F1_LE_SHIFT                                                9
#define MBOX_12_66_F1_LE_MASK                                        0x00004000
#define MBOX_12_66_F1_LE_RD(src)                   (((src) & 0x00004000) >> 14)
#define MBOX_12_66_F1_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*	 Fields mbox_12_5	 */
#define MBOX_12_56_F1_LE_WIDTH                                                1
#define MBOX_12_56_F1_LE_SHIFT                                               10
#define MBOX_12_56_F1_LE_MASK                                        0x00002000
#define MBOX_12_56_F1_LE_RD(src)                   (((src) & 0x00002000) >> 13)
#define MBOX_12_56_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*	 Fields mbox_12_4	 */
#define MBOX_12_46_F1_LE_WIDTH                                                1
#define MBOX_12_46_F1_LE_SHIFT                                               11
#define MBOX_12_46_F1_LE_MASK                                        0x00001000
#define MBOX_12_46_F1_LE_RD(src)                   (((src) & 0x00001000) >> 12)
#define MBOX_12_46_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*	 Fields mbox_12_3	 */
#define MBOX_12_36_F1_LE_WIDTH                                                1
#define MBOX_12_36_F1_LE_SHIFT                                               12
#define MBOX_12_36_F1_LE_MASK                                        0x00000800
#define MBOX_12_36_F1_LE_RD(src)                   (((src) & 0x00000800) >> 11)
#define MBOX_12_36_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*	 Fields mbox_12_2	 */
#define MBOX_12_26_F1_LE_WIDTH                                                1
#define MBOX_12_26_F1_LE_SHIFT                                               13
#define MBOX_12_26_F1_LE_MASK                                        0x00000400
#define MBOX_12_26_F1_LE_RD(src)                   (((src) & 0x00000400) >> 10)
#define MBOX_12_26_F1_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*	 Fields mbox_12_1	 */
#define MBOX_12_16_F1_LE_WIDTH                                                1
#define MBOX_12_16_F1_LE_SHIFT                                               14
#define MBOX_12_16_F1_LE_MASK                                        0x00000200
#define MBOX_12_16_F1_LE_RD(src)                    (((src) & 0x00000200) >> 9)
#define MBOX_12_16_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*	 Fields mbox_12_0	 */
#define MBOX_12_06_F1_LE_WIDTH                                                1
#define MBOX_12_06_F1_LE_SHIFT                                               15
#define MBOX_12_06_F1_LE_MASK                                        0x00000100
#define MBOX_12_06_F1_LE_RD(src)                    (((src) & 0x00000100) >> 8)
#define MBOX_12_06_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*	 Fields mbox_13_15	 */
#define MBOX_13_156_F1_LE_WIDTH                                               1
#define MBOX_13_156_F1_LE_SHIFT                                              16
#define MBOX_13_156_F1_LE_MASK                                       0x00800000
#define MBOX_13_156_F1_LE_RD(src)                  (((src) & 0x00800000) >> 23)
#define MBOX_13_156_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*	 Fields mbox_13_14	 */
#define MBOX_13_146_F1_LE_WIDTH                                               1
#define MBOX_13_146_F1_LE_SHIFT                                              17
#define MBOX_13_146_F1_LE_MASK                                       0x00400000
#define MBOX_13_146_F1_LE_RD(src)                  (((src) & 0x00400000) >> 22)
#define MBOX_13_146_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*	 Fields mbox_13_13	 */
#define MBOX_13_136_F1_LE_WIDTH                                               1
#define MBOX_13_136_F1_LE_SHIFT                                              18
#define MBOX_13_136_F1_LE_MASK                                       0x00200000
#define MBOX_13_136_F1_LE_RD(src)                  (((src) & 0x00200000) >> 21)
#define MBOX_13_136_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*	 Fields mbox_13_12	 */
#define MBOX_13_126_F1_LE_WIDTH                                               1
#define MBOX_13_126_F1_LE_SHIFT                                              19
#define MBOX_13_126_F1_LE_MASK                                       0x00100000
#define MBOX_13_126_F1_LE_RD(src)                  (((src) & 0x00100000) >> 20)
#define MBOX_13_126_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields mbox_13_11	 */
#define MBOX_13_116_F1_LE_WIDTH                                               1
#define MBOX_13_116_F1_LE_SHIFT                                              20
#define MBOX_13_116_F1_LE_MASK                                       0x00080000
#define MBOX_13_116_F1_LE_RD(src)                  (((src) & 0x00080000) >> 19)
#define MBOX_13_116_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*	 Fields mbox_13_10	 */
#define MBOX_13_106_F1_LE_WIDTH                                               1
#define MBOX_13_106_F1_LE_SHIFT                                              21
#define MBOX_13_106_F1_LE_MASK                                       0x00040000
#define MBOX_13_106_F1_LE_RD(src)                  (((src) & 0x00040000) >> 18)
#define MBOX_13_106_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*	 Fields mbox_13_9	 */
#define MBOX_13_96_F1_LE_WIDTH                                                1
#define MBOX_13_96_F1_LE_SHIFT                                               22
#define MBOX_13_96_F1_LE_MASK                                        0x00020000
#define MBOX_13_96_F1_LE_RD(src)                   (((src) & 0x00020000) >> 17)
#define MBOX_13_96_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*	 Fields mbox_13_8	 */
#define MBOX_13_86_F1_LE_WIDTH                                                1
#define MBOX_13_86_F1_LE_SHIFT                                               23
#define MBOX_13_86_F1_LE_MASK                                        0x00010000
#define MBOX_13_86_F1_LE_RD(src)                   (((src) & 0x00010000) >> 16)
#define MBOX_13_86_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*	 Fields mbox_13_7	 */
#define MBOX_13_76_F1_LE_WIDTH                                                1
#define MBOX_13_76_F1_LE_SHIFT                                               24
#define MBOX_13_76_F1_LE_MASK                                        0x80000000
#define MBOX_13_76_F1_LE_RD(src)                   (((src) & 0x80000000) >> 31)
#define MBOX_13_76_F1_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields mbox_13_6	 */
#define MBOX_13_66_F1_LE_WIDTH                                                1
#define MBOX_13_66_F1_LE_SHIFT                                               25
#define MBOX_13_66_F1_LE_MASK                                        0x40000000
#define MBOX_13_66_F1_LE_RD(src)                   (((src) & 0x40000000) >> 30)
#define MBOX_13_66_F1_LE_SET(dst,src)                     ((dst)&~0x40000000)|\
				(((unsigned int)(src) << 30) & 0x40000000)

/*	 Fields mbox_13_5	 */
#define MBOX_13_56_F1_LE_WIDTH                                                1
#define MBOX_13_56_F1_LE_SHIFT                                               26
#define MBOX_13_56_F1_LE_MASK                                        0x20000000
#define MBOX_13_56_F1_LE_RD(src)                   (((src) & 0x20000000) >> 29)
#define MBOX_13_56_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields mbox_13_4	 */
#define MBOX_13_46_F1_LE_WIDTH                                                1
#define MBOX_13_46_F1_LE_SHIFT                                               27
#define MBOX_13_46_F1_LE_MASK                                        0x10000000
#define MBOX_13_46_F1_LE_RD(src)                   (((src) & 0x10000000) >> 28)
#define MBOX_13_46_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields mbox_13_3	 */
#define MBOX_13_36_F1_LE_WIDTH                                                1
#define MBOX_13_36_F1_LE_SHIFT                                               28
#define MBOX_13_36_F1_LE_MASK                                        0x08000000
#define MBOX_13_36_F1_LE_RD(src)                   (((src) & 0x08000000) >> 27)
#define MBOX_13_36_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields mbox_13_2	 */
#define MBOX_13_26_F1_LE_WIDTH                                                1
#define MBOX_13_26_F1_LE_SHIFT                                               29
#define MBOX_13_26_F1_LE_MASK                                        0x04000000
#define MBOX_13_26_F1_LE_RD(src)                   (((src) & 0x04000000) >> 26)
#define MBOX_13_26_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields mbox_13_1	 */
#define MBOX_13_16_F1_LE_WIDTH                                                1
#define MBOX_13_16_F1_LE_SHIFT                                               30
#define MBOX_13_16_F1_LE_MASK                                        0x02000000
#define MBOX_13_16_F1_LE_RD(src)                   (((src) & 0x02000000) >> 25)
#define MBOX_13_16_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields mbox_13_0	 */
#define MBOX_13_06_F1_LE_WIDTH                                                1
#define MBOX_13_06_F1_LE_SHIFT                                               31
#define MBOX_13_06_F1_LE_MASK                                        0x01000000
#define MBOX_13_06_F1_LE_RD(src)                   (((src) & 0x01000000) >> 24)
#define MBOX_13_06_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register csr_enq_status_7	*/

/*	 Fields mbox_14_15	 */
#define MBOX_14_157_F1_LE_WIDTH                                               1
#define MBOX_14_157_F1_LE_SHIFT                                               0
#define MBOX_14_157_F1_LE_MASK                                       0x00000080
#define MBOX_14_157_F1_LE_RD(src)                    (((src) & 0x00000080)<< 7)
#define MBOX_14_157_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields mbox_14_14	 */
#define MBOX_14_147_F1_LE_WIDTH                                               1
#define MBOX_14_147_F1_LE_SHIFT                                               1
#define MBOX_14_147_F1_LE_MASK                                       0x00000040
#define MBOX_14_147_F1_LE_RD(src)                    (((src) & 0x00000040)<< 6)
#define MBOX_14_147_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields mbox_14_13	 */
#define MBOX_14_137_F1_LE_WIDTH                                               1
#define MBOX_14_137_F1_LE_SHIFT                                               2
#define MBOX_14_137_F1_LE_MASK                                       0x00000020
#define MBOX_14_137_F1_LE_RD(src)                    (((src) & 0x00000020)<< 5)
#define MBOX_14_137_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*	 Fields mbox_14_12	 */
#define MBOX_14_127_F1_LE_WIDTH                                               1
#define MBOX_14_127_F1_LE_SHIFT                                               3
#define MBOX_14_127_F1_LE_MASK                                       0x00000010
#define MBOX_14_127_F1_LE_RD(src)                    (((src) & 0x00000010)<< 4)
#define MBOX_14_127_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields mbox_14_11	 */
#define MBOX_14_117_F1_LE_WIDTH                                               1
#define MBOX_14_117_F1_LE_SHIFT                                               4
#define MBOX_14_117_F1_LE_MASK                                       0x00000008
#define MBOX_14_117_F1_LE_RD(src)                    (((src) & 0x00000008)<< 3)
#define MBOX_14_117_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*	 Fields mbox_14_10	 */
#define MBOX_14_107_F1_LE_WIDTH                                               1
#define MBOX_14_107_F1_LE_SHIFT                                               5
#define MBOX_14_107_F1_LE_MASK                                       0x00000004
#define MBOX_14_107_F1_LE_RD(src)                    (((src) & 0x00000004)<< 2)
#define MBOX_14_107_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*	 Fields mbox_14_9	 */
#define MBOX_14_97_F1_LE_WIDTH                                                1
#define MBOX_14_97_F1_LE_SHIFT                                                6
#define MBOX_14_97_F1_LE_MASK                                        0x00000002
#define MBOX_14_97_F1_LE_RD(src)                     (((src) & 0x00000002)<< 1)
#define MBOX_14_97_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*	 Fields mbox_14_8	 */
#define MBOX_14_87_F1_LE_WIDTH                                                1
#define MBOX_14_87_F1_LE_SHIFT                                                7
#define MBOX_14_87_F1_LE_MASK                                        0x00000001
#define MBOX_14_87_F1_LE_RD(src)                     (((src) & 0x00000001)<< 0)
#define MBOX_14_87_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*	 Fields mbox_14_7	 */
#define MBOX_14_77_F1_LE_WIDTH                                                1
#define MBOX_14_77_F1_LE_SHIFT                                                8
#define MBOX_14_77_F1_LE_MASK                                        0x00008000
#define MBOX_14_77_F1_LE_RD(src)                   (((src) & 0x00008000) >> 15)
#define MBOX_14_77_F1_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*	 Fields mbox_14_6	 */
#define MBOX_14_67_F1_LE_WIDTH                                                1
#define MBOX_14_67_F1_LE_SHIFT                                                9
#define MBOX_14_67_F1_LE_MASK                                        0x00004000
#define MBOX_14_67_F1_LE_RD(src)                   (((src) & 0x00004000) >> 14)
#define MBOX_14_67_F1_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*	 Fields mbox_14_5	 */
#define MBOX_14_57_F1_LE_WIDTH                                                1
#define MBOX_14_57_F1_LE_SHIFT                                               10
#define MBOX_14_57_F1_LE_MASK                                        0x00002000
#define MBOX_14_57_F1_LE_RD(src)                   (((src) & 0x00002000) >> 13)
#define MBOX_14_57_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*	 Fields mbox_14_4	 */
#define MBOX_14_47_F1_LE_WIDTH                                                1
#define MBOX_14_47_F1_LE_SHIFT                                               11
#define MBOX_14_47_F1_LE_MASK                                        0x00001000
#define MBOX_14_47_F1_LE_RD(src)                   (((src) & 0x00001000) >> 12)
#define MBOX_14_47_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*	 Fields mbox_14_3	 */
#define MBOX_14_37_F1_LE_WIDTH                                                1
#define MBOX_14_37_F1_LE_SHIFT                                               12
#define MBOX_14_37_F1_LE_MASK                                        0x00000800
#define MBOX_14_37_F1_LE_RD(src)                   (((src) & 0x00000800) >> 11)
#define MBOX_14_37_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*	 Fields mbox_14_2	 */
#define MBOX_14_27_F1_LE_WIDTH                                                1
#define MBOX_14_27_F1_LE_SHIFT                                               13
#define MBOX_14_27_F1_LE_MASK                                        0x00000400
#define MBOX_14_27_F1_LE_RD(src)                   (((src) & 0x00000400) >> 10)
#define MBOX_14_27_F1_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*	 Fields mbox_14_1	 */
#define MBOX_14_17_F1_LE_WIDTH                                                1
#define MBOX_14_17_F1_LE_SHIFT                                               14
#define MBOX_14_17_F1_LE_MASK                                        0x00000200
#define MBOX_14_17_F1_LE_RD(src)                    (((src) & 0x00000200) >> 9)
#define MBOX_14_17_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*	 Fields mbox_14_0	 */
#define MBOX_14_07_F1_LE_WIDTH                                                1
#define MBOX_14_07_F1_LE_SHIFT                                               15
#define MBOX_14_07_F1_LE_MASK                                        0x00000100
#define MBOX_14_07_F1_LE_RD(src)                    (((src) & 0x00000100) >> 8)
#define MBOX_14_07_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*	 Fields mbox_15_15	 */
#define MBOX_15_157_F1_LE_WIDTH                                               1
#define MBOX_15_157_F1_LE_SHIFT                                              16
#define MBOX_15_157_F1_LE_MASK                                       0x00800000
#define MBOX_15_157_F1_LE_RD(src)                  (((src) & 0x00800000) >> 23)
#define MBOX_15_157_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*	 Fields mbox_15_14	 */
#define MBOX_15_147_F1_LE_WIDTH                                               1
#define MBOX_15_147_F1_LE_SHIFT                                              17
#define MBOX_15_147_F1_LE_MASK                                       0x00400000
#define MBOX_15_147_F1_LE_RD(src)                  (((src) & 0x00400000) >> 22)
#define MBOX_15_147_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*	 Fields mbox_15_13	 */
#define MBOX_15_137_F1_LE_WIDTH                                               1
#define MBOX_15_137_F1_LE_SHIFT                                              18
#define MBOX_15_137_F1_LE_MASK                                       0x00200000
#define MBOX_15_137_F1_LE_RD(src)                  (((src) & 0x00200000) >> 21)
#define MBOX_15_137_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*	 Fields mbox_15_12	 */
#define MBOX_15_127_F1_LE_WIDTH                                               1
#define MBOX_15_127_F1_LE_SHIFT                                              19
#define MBOX_15_127_F1_LE_MASK                                       0x00100000
#define MBOX_15_127_F1_LE_RD(src)                  (((src) & 0x00100000) >> 20)
#define MBOX_15_127_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields mbox_15_11	 */
#define MBOX_15_117_F1_LE_WIDTH                                               1
#define MBOX_15_117_F1_LE_SHIFT                                              20
#define MBOX_15_117_F1_LE_MASK                                       0x00080000
#define MBOX_15_117_F1_LE_RD(src)                  (((src) & 0x00080000) >> 19)
#define MBOX_15_117_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*	 Fields mbox_15_10	 */
#define MBOX_15_107_F1_LE_WIDTH                                               1
#define MBOX_15_107_F1_LE_SHIFT                                              21
#define MBOX_15_107_F1_LE_MASK                                       0x00040000
#define MBOX_15_107_F1_LE_RD(src)                  (((src) & 0x00040000) >> 18)
#define MBOX_15_107_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*	 Fields mbox_15_9	 */
#define MBOX_15_97_F1_LE_WIDTH                                                1
#define MBOX_15_97_F1_LE_SHIFT                                               22
#define MBOX_15_97_F1_LE_MASK                                        0x00020000
#define MBOX_15_97_F1_LE_RD(src)                   (((src) & 0x00020000) >> 17)
#define MBOX_15_97_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*	 Fields mbox_15_8	 */
#define MBOX_15_87_F1_LE_WIDTH                                                1
#define MBOX_15_87_F1_LE_SHIFT                                               23
#define MBOX_15_87_F1_LE_MASK                                        0x00010000
#define MBOX_15_87_F1_LE_RD(src)                   (((src) & 0x00010000) >> 16)
#define MBOX_15_87_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*	 Fields mbox_15_7	 */
#define MBOX_15_77_F1_LE_WIDTH                                                1
#define MBOX_15_77_F1_LE_SHIFT                                               24
#define MBOX_15_77_F1_LE_MASK                                        0x80000000
#define MBOX_15_77_F1_LE_RD(src)                   (((src) & 0x80000000) >> 31)
#define MBOX_15_77_F1_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields mbox_15_6	 */
#define MBOX_15_67_F1_LE_WIDTH                                                1
#define MBOX_15_67_F1_LE_SHIFT                                               25
#define MBOX_15_67_F1_LE_MASK                                        0x40000000
#define MBOX_15_67_F1_LE_RD(src)                   (((src) & 0x40000000) >> 30)
#define MBOX_15_67_F1_LE_SET(dst,src)                     ((dst)&~0x40000000)|\
				(((unsigned int)(src) << 30) & 0x40000000)

/*	 Fields mbox_15_5	 */
#define MBOX_15_57_F1_LE_WIDTH                                                1
#define MBOX_15_57_F1_LE_SHIFT                                               26
#define MBOX_15_57_F1_LE_MASK                                        0x20000000
#define MBOX_15_57_F1_LE_RD(src)                   (((src) & 0x20000000) >> 29)
#define MBOX_15_57_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields mbox_15_4	 */
#define MBOX_15_47_F1_LE_WIDTH                                                1
#define MBOX_15_47_F1_LE_SHIFT                                               27
#define MBOX_15_47_F1_LE_MASK                                        0x10000000
#define MBOX_15_47_F1_LE_RD(src)                   (((src) & 0x10000000) >> 28)
#define MBOX_15_47_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields mbox_15_3	 */
#define MBOX_15_37_F1_LE_WIDTH                                                1
#define MBOX_15_37_F1_LE_SHIFT                                               28
#define MBOX_15_37_F1_LE_MASK                                        0x08000000
#define MBOX_15_37_F1_LE_RD(src)                   (((src) & 0x08000000) >> 27)
#define MBOX_15_37_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields mbox_15_2	 */
#define MBOX_15_27_F1_LE_WIDTH                                                1
#define MBOX_15_27_F1_LE_SHIFT                                               29
#define MBOX_15_27_F1_LE_MASK                                        0x04000000
#define MBOX_15_27_F1_LE_RD(src)                   (((src) & 0x04000000) >> 26)
#define MBOX_15_27_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields mbox_15_1	 */
#define MBOX_15_17_F1_LE_WIDTH                                                1
#define MBOX_15_17_F1_LE_SHIFT                                               30
#define MBOX_15_17_F1_LE_MASK                                        0x02000000
#define MBOX_15_17_F1_LE_RD(src)                   (((src) & 0x02000000) >> 25)
#define MBOX_15_17_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields mbox_15_0	 */
#define MBOX_15_07_F1_LE_WIDTH                                                1
#define MBOX_15_07_F1_LE_SHIFT                                               31
#define MBOX_15_07_F1_LE_MASK                                        0x01000000
#define MBOX_15_07_F1_LE_RD(src)                   (((src) & 0x01000000) >> 24)
#define MBOX_15_07_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register csr_enq_status_8	*/

/*	 Fields mbox_16_15	 */
#define MBOX_16_158_F1_LE_WIDTH                                               1
#define MBOX_16_158_F1_LE_SHIFT                                               0
#define MBOX_16_158_F1_LE_MASK                                       0x00000080
#define MBOX_16_158_F1_LE_RD(src)                    (((src) & 0x00000080)<< 7)
#define MBOX_16_158_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields mbox_16_14	 */
#define MBOX_16_148_F1_LE_WIDTH                                               1
#define MBOX_16_148_F1_LE_SHIFT                                               1
#define MBOX_16_148_F1_LE_MASK                                       0x00000040
#define MBOX_16_148_F1_LE_RD(src)                    (((src) & 0x00000040)<< 6)
#define MBOX_16_148_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields mbox_16_13	 */
#define MBOX_16_138_F1_LE_WIDTH                                               1
#define MBOX_16_138_F1_LE_SHIFT                                               2
#define MBOX_16_138_F1_LE_MASK                                       0x00000020
#define MBOX_16_138_F1_LE_RD(src)                    (((src) & 0x00000020)<< 5)
#define MBOX_16_138_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*	 Fields mbox_16_12	 */
#define MBOX_16_128_F1_LE_WIDTH                                               1
#define MBOX_16_128_F1_LE_SHIFT                                               3
#define MBOX_16_128_F1_LE_MASK                                       0x00000010
#define MBOX_16_128_F1_LE_RD(src)                    (((src) & 0x00000010)<< 4)
#define MBOX_16_128_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields mbox_16_11	 */
#define MBOX_16_118_F1_LE_WIDTH                                               1
#define MBOX_16_118_F1_LE_SHIFT                                               4
#define MBOX_16_118_F1_LE_MASK                                       0x00000008
#define MBOX_16_118_F1_LE_RD(src)                    (((src) & 0x00000008)<< 3)
#define MBOX_16_118_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*	 Fields mbox_16_10	 */
#define MBOX_16_108_F1_LE_WIDTH                                               1
#define MBOX_16_108_F1_LE_SHIFT                                               5
#define MBOX_16_108_F1_LE_MASK                                       0x00000004
#define MBOX_16_108_F1_LE_RD(src)                    (((src) & 0x00000004)<< 2)
#define MBOX_16_108_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*	 Fields mbox_16_9	 */
#define MBOX_16_98_F1_LE_WIDTH                                                1
#define MBOX_16_98_F1_LE_SHIFT                                                6
#define MBOX_16_98_F1_LE_MASK                                        0x00000002
#define MBOX_16_98_F1_LE_RD(src)                     (((src) & 0x00000002)<< 1)
#define MBOX_16_98_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*	 Fields mbox_16_8	 */
#define MBOX_16_88_F1_LE_WIDTH                                                1
#define MBOX_16_88_F1_LE_SHIFT                                                7
#define MBOX_16_88_F1_LE_MASK                                        0x00000001
#define MBOX_16_88_F1_LE_RD(src)                     (((src) & 0x00000001)<< 0)
#define MBOX_16_88_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*	 Fields mbox_16_7	 */
#define MBOX_16_78_F1_LE_WIDTH                                                1
#define MBOX_16_78_F1_LE_SHIFT                                                8
#define MBOX_16_78_F1_LE_MASK                                        0x00008000
#define MBOX_16_78_F1_LE_RD(src)                   (((src) & 0x00008000) >> 15)
#define MBOX_16_78_F1_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*	 Fields mbox_16_6	 */
#define MBOX_16_68_F1_LE_WIDTH                                                1
#define MBOX_16_68_F1_LE_SHIFT                                                9
#define MBOX_16_68_F1_LE_MASK                                        0x00004000
#define MBOX_16_68_F1_LE_RD(src)                   (((src) & 0x00004000) >> 14)
#define MBOX_16_68_F1_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*	 Fields mbox_16_5	 */
#define MBOX_16_58_F1_LE_WIDTH                                                1
#define MBOX_16_58_F1_LE_SHIFT                                               10
#define MBOX_16_58_F1_LE_MASK                                        0x00002000
#define MBOX_16_58_F1_LE_RD(src)                   (((src) & 0x00002000) >> 13)
#define MBOX_16_58_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*	 Fields mbox_16_4	 */
#define MBOX_16_48_F1_LE_WIDTH                                                1
#define MBOX_16_48_F1_LE_SHIFT                                               11
#define MBOX_16_48_F1_LE_MASK                                        0x00001000
#define MBOX_16_48_F1_LE_RD(src)                   (((src) & 0x00001000) >> 12)
#define MBOX_16_48_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*	 Fields mbox_16_3	 */
#define MBOX_16_38_F1_LE_WIDTH                                                1
#define MBOX_16_38_F1_LE_SHIFT                                               12
#define MBOX_16_38_F1_LE_MASK                                        0x00000800
#define MBOX_16_38_F1_LE_RD(src)                   (((src) & 0x00000800) >> 11)
#define MBOX_16_38_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*	 Fields mbox_16_2	 */
#define MBOX_16_28_F1_LE_WIDTH                                                1
#define MBOX_16_28_F1_LE_SHIFT                                               13
#define MBOX_16_28_F1_LE_MASK                                        0x00000400
#define MBOX_16_28_F1_LE_RD(src)                   (((src) & 0x00000400) >> 10)
#define MBOX_16_28_F1_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*	 Fields mbox_16_1	 */
#define MBOX_16_18_F1_LE_WIDTH                                                1
#define MBOX_16_18_F1_LE_SHIFT                                               14
#define MBOX_16_18_F1_LE_MASK                                        0x00000200
#define MBOX_16_18_F1_LE_RD(src)                    (((src) & 0x00000200) >> 9)
#define MBOX_16_18_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*	 Fields mbox_16_0	 */
#define MBOX_16_08_F1_LE_WIDTH                                                1
#define MBOX_16_08_F1_LE_SHIFT                                               15
#define MBOX_16_08_F1_LE_MASK                                        0x00000100
#define MBOX_16_08_F1_LE_RD(src)                    (((src) & 0x00000100) >> 8)
#define MBOX_16_08_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*	 Fields mbox_17_15	 */
#define MBOX_17_158_F1_LE_WIDTH                                               1
#define MBOX_17_158_F1_LE_SHIFT                                              16
#define MBOX_17_158_F1_LE_MASK                                       0x00800000
#define MBOX_17_158_F1_LE_RD(src)                  (((src) & 0x00800000) >> 23)
#define MBOX_17_158_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*	 Fields mbox_17_14	 */
#define MBOX_17_148_F1_LE_WIDTH                                               1
#define MBOX_17_148_F1_LE_SHIFT                                              17
#define MBOX_17_148_F1_LE_MASK                                       0x00400000
#define MBOX_17_148_F1_LE_RD(src)                  (((src) & 0x00400000) >> 22)
#define MBOX_17_148_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*	 Fields mbox_17_13	 */
#define MBOX_17_138_F1_LE_WIDTH                                               1
#define MBOX_17_138_F1_LE_SHIFT                                              18
#define MBOX_17_138_F1_LE_MASK                                       0x00200000
#define MBOX_17_138_F1_LE_RD(src)                  (((src) & 0x00200000) >> 21)
#define MBOX_17_138_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*	 Fields mbox_17_12	 */
#define MBOX_17_128_F1_LE_WIDTH                                               1
#define MBOX_17_128_F1_LE_SHIFT                                              19
#define MBOX_17_128_F1_LE_MASK                                       0x00100000
#define MBOX_17_128_F1_LE_RD(src)                  (((src) & 0x00100000) >> 20)
#define MBOX_17_128_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields mbox_17_11	 */
#define MBOX_17_118_F1_LE_WIDTH                                               1
#define MBOX_17_118_F1_LE_SHIFT                                              20
#define MBOX_17_118_F1_LE_MASK                                       0x00080000
#define MBOX_17_118_F1_LE_RD(src)                  (((src) & 0x00080000) >> 19)
#define MBOX_17_118_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*	 Fields mbox_17_10	 */
#define MBOX_17_108_F1_LE_WIDTH                                               1
#define MBOX_17_108_F1_LE_SHIFT                                              21
#define MBOX_17_108_F1_LE_MASK                                       0x00040000
#define MBOX_17_108_F1_LE_RD(src)                  (((src) & 0x00040000) >> 18)
#define MBOX_17_108_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*	 Fields mbox_17_9	 */
#define MBOX_17_98_F1_LE_WIDTH                                                1
#define MBOX_17_98_F1_LE_SHIFT                                               22
#define MBOX_17_98_F1_LE_MASK                                        0x00020000
#define MBOX_17_98_F1_LE_RD(src)                   (((src) & 0x00020000) >> 17)
#define MBOX_17_98_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*	 Fields mbox_17_8	 */
#define MBOX_17_88_F1_LE_WIDTH                                                1
#define MBOX_17_88_F1_LE_SHIFT                                               23
#define MBOX_17_88_F1_LE_MASK                                        0x00010000
#define MBOX_17_88_F1_LE_RD(src)                   (((src) & 0x00010000) >> 16)
#define MBOX_17_88_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*	 Fields mbox_17_7	 */
#define MBOX_17_78_F1_LE_WIDTH                                                1
#define MBOX_17_78_F1_LE_SHIFT                                               24
#define MBOX_17_78_F1_LE_MASK                                        0x80000000
#define MBOX_17_78_F1_LE_RD(src)                   (((src) & 0x80000000) >> 31)
#define MBOX_17_78_F1_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields mbox_17_6	 */
#define MBOX_17_68_F1_LE_WIDTH                                                1
#define MBOX_17_68_F1_LE_SHIFT                                               25
#define MBOX_17_68_F1_LE_MASK                                        0x40000000
#define MBOX_17_68_F1_LE_RD(src)                   (((src) & 0x40000000) >> 30)
#define MBOX_17_68_F1_LE_SET(dst,src)                     ((dst)&~0x40000000)|\
				(((unsigned int)(src) << 30) & 0x40000000)

/*	 Fields mbox_17_5	 */
#define MBOX_17_58_F1_LE_WIDTH                                                1
#define MBOX_17_58_F1_LE_SHIFT                                               26
#define MBOX_17_58_F1_LE_MASK                                        0x20000000
#define MBOX_17_58_F1_LE_RD(src)                   (((src) & 0x20000000) >> 29)
#define MBOX_17_58_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields mbox_17_4	 */
#define MBOX_17_48_F1_LE_WIDTH                                                1
#define MBOX_17_48_F1_LE_SHIFT                                               27
#define MBOX_17_48_F1_LE_MASK                                        0x10000000
#define MBOX_17_48_F1_LE_RD(src)                   (((src) & 0x10000000) >> 28)
#define MBOX_17_48_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields mbox_17_3	 */
#define MBOX_17_38_F1_LE_WIDTH                                                1
#define MBOX_17_38_F1_LE_SHIFT                                               28
#define MBOX_17_38_F1_LE_MASK                                        0x08000000
#define MBOX_17_38_F1_LE_RD(src)                   (((src) & 0x08000000) >> 27)
#define MBOX_17_38_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields mbox_17_2	 */
#define MBOX_17_28_F1_LE_WIDTH                                                1
#define MBOX_17_28_F1_LE_SHIFT                                               29
#define MBOX_17_28_F1_LE_MASK                                        0x04000000
#define MBOX_17_28_F1_LE_RD(src)                   (((src) & 0x04000000) >> 26)
#define MBOX_17_28_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields mbox_17_1	 */
#define MBOX_17_18_F1_LE_WIDTH                                                1
#define MBOX_17_18_F1_LE_SHIFT                                               30
#define MBOX_17_18_F1_LE_MASK                                        0x02000000
#define MBOX_17_18_F1_LE_RD(src)                   (((src) & 0x02000000) >> 25)
#define MBOX_17_18_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields mbox_17_0	 */
#define MBOX_17_08_F1_LE_WIDTH                                                1
#define MBOX_17_08_F1_LE_SHIFT                                               31
#define MBOX_17_08_F1_LE_MASK                                        0x01000000
#define MBOX_17_08_F1_LE_RD(src)                   (((src) & 0x01000000) >> 24)
#define MBOX_17_08_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register csr_enq_status_9	*/

/*	 Fields mbox_18_15	 */
#define MBOX_18_159_F1_LE_WIDTH                                               1
#define MBOX_18_159_F1_LE_SHIFT                                               0
#define MBOX_18_159_F1_LE_MASK                                       0x00000080
#define MBOX_18_159_F1_LE_RD(src)                    (((src) & 0x00000080)<< 7)
#define MBOX_18_159_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields mbox_18_14	 */
#define MBOX_18_149_F1_LE_WIDTH                                               1
#define MBOX_18_149_F1_LE_SHIFT                                               1
#define MBOX_18_149_F1_LE_MASK                                       0x00000040
#define MBOX_18_149_F1_LE_RD(src)                    (((src) & 0x00000040)<< 6)
#define MBOX_18_149_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields mbox_18_13	 */
#define MBOX_18_139_F1_LE_WIDTH                                               1
#define MBOX_18_139_F1_LE_SHIFT                                               2
#define MBOX_18_139_F1_LE_MASK                                       0x00000020
#define MBOX_18_139_F1_LE_RD(src)                    (((src) & 0x00000020)<< 5)
#define MBOX_18_139_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*	 Fields mbox_18_12	 */
#define MBOX_18_129_F1_LE_WIDTH                                               1
#define MBOX_18_129_F1_LE_SHIFT                                               3
#define MBOX_18_129_F1_LE_MASK                                       0x00000010
#define MBOX_18_129_F1_LE_RD(src)                    (((src) & 0x00000010)<< 4)
#define MBOX_18_129_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields mbox_18_11	 */
#define MBOX_18_119_F1_LE_WIDTH                                               1
#define MBOX_18_119_F1_LE_SHIFT                                               4
#define MBOX_18_119_F1_LE_MASK                                       0x00000008
#define MBOX_18_119_F1_LE_RD(src)                    (((src) & 0x00000008)<< 3)
#define MBOX_18_119_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*	 Fields mbox_18_10	 */
#define MBOX_18_109_F1_LE_WIDTH                                               1
#define MBOX_18_109_F1_LE_SHIFT                                               5
#define MBOX_18_109_F1_LE_MASK                                       0x00000004
#define MBOX_18_109_F1_LE_RD(src)                    (((src) & 0x00000004)<< 2)
#define MBOX_18_109_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*	 Fields mbox_18_9	 */
#define MBOX_18_99_F1_LE_WIDTH                                                1
#define MBOX_18_99_F1_LE_SHIFT                                                6
#define MBOX_18_99_F1_LE_MASK                                        0x00000002
#define MBOX_18_99_F1_LE_RD(src)                     (((src) & 0x00000002)<< 1)
#define MBOX_18_99_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*	 Fields mbox_18_8	 */
#define MBOX_18_89_F1_LE_WIDTH                                                1
#define MBOX_18_89_F1_LE_SHIFT                                                7
#define MBOX_18_89_F1_LE_MASK                                        0x00000001
#define MBOX_18_89_F1_LE_RD(src)                     (((src) & 0x00000001)<< 0)
#define MBOX_18_89_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*	 Fields mbox_18_7	 */
#define MBOX_18_79_F1_LE_WIDTH                                                1
#define MBOX_18_79_F1_LE_SHIFT                                                8
#define MBOX_18_79_F1_LE_MASK                                        0x00008000
#define MBOX_18_79_F1_LE_RD(src)                   (((src) & 0x00008000) >> 15)
#define MBOX_18_79_F1_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*	 Fields mbox_18_6	 */
#define MBOX_18_69_F1_LE_WIDTH                                                1
#define MBOX_18_69_F1_LE_SHIFT                                                9
#define MBOX_18_69_F1_LE_MASK                                        0x00004000
#define MBOX_18_69_F1_LE_RD(src)                   (((src) & 0x00004000) >> 14)
#define MBOX_18_69_F1_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*	 Fields mbox_18_5	 */
#define MBOX_18_59_F1_LE_WIDTH                                                1
#define MBOX_18_59_F1_LE_SHIFT                                               10
#define MBOX_18_59_F1_LE_MASK                                        0x00002000
#define MBOX_18_59_F1_LE_RD(src)                   (((src) & 0x00002000) >> 13)
#define MBOX_18_59_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*	 Fields mbox_18_4	 */
#define MBOX_18_49_F1_LE_WIDTH                                                1
#define MBOX_18_49_F1_LE_SHIFT                                               11
#define MBOX_18_49_F1_LE_MASK                                        0x00001000
#define MBOX_18_49_F1_LE_RD(src)                   (((src) & 0x00001000) >> 12)
#define MBOX_18_49_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*	 Fields mbox_18_3	 */
#define MBOX_18_39_F1_LE_WIDTH                                                1
#define MBOX_18_39_F1_LE_SHIFT                                               12
#define MBOX_18_39_F1_LE_MASK                                        0x00000800
#define MBOX_18_39_F1_LE_RD(src)                   (((src) & 0x00000800) >> 11)
#define MBOX_18_39_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*	 Fields mbox_18_2	 */
#define MBOX_18_29_F1_LE_WIDTH                                                1
#define MBOX_18_29_F1_LE_SHIFT                                               13
#define MBOX_18_29_F1_LE_MASK                                        0x00000400
#define MBOX_18_29_F1_LE_RD(src)                   (((src) & 0x00000400) >> 10)
#define MBOX_18_29_F1_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*	 Fields mbox_18_1	 */
#define MBOX_18_19_F1_LE_WIDTH                                                1
#define MBOX_18_19_F1_LE_SHIFT                                               14
#define MBOX_18_19_F1_LE_MASK                                        0x00000200
#define MBOX_18_19_F1_LE_RD(src)                    (((src) & 0x00000200) >> 9)
#define MBOX_18_19_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*	 Fields mbox_18_0	 */
#define MBOX_18_09_F1_LE_WIDTH                                                1
#define MBOX_18_09_F1_LE_SHIFT                                               15
#define MBOX_18_09_F1_LE_MASK                                        0x00000100
#define MBOX_18_09_F1_LE_RD(src)                    (((src) & 0x00000100) >> 8)
#define MBOX_18_09_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*	 Fields mbox_19_15	 */
#define MBOX_19_159_F1_LE_WIDTH                                               1
#define MBOX_19_159_F1_LE_SHIFT                                              16
#define MBOX_19_159_F1_LE_MASK                                       0x00800000
#define MBOX_19_159_F1_LE_RD(src)                  (((src) & 0x00800000) >> 23)
#define MBOX_19_159_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*	 Fields mbox_19_14	 */
#define MBOX_19_149_F1_LE_WIDTH                                               1
#define MBOX_19_149_F1_LE_SHIFT                                              17
#define MBOX_19_149_F1_LE_MASK                                       0x00400000
#define MBOX_19_149_F1_LE_RD(src)                  (((src) & 0x00400000) >> 22)
#define MBOX_19_149_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*	 Fields mbox_19_13	 */
#define MBOX_19_139_F1_LE_WIDTH                                               1
#define MBOX_19_139_F1_LE_SHIFT                                              18
#define MBOX_19_139_F1_LE_MASK                                       0x00200000
#define MBOX_19_139_F1_LE_RD(src)                  (((src) & 0x00200000) >> 21)
#define MBOX_19_139_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*	 Fields mbox_19_12	 */
#define MBOX_19_129_F1_LE_WIDTH                                               1
#define MBOX_19_129_F1_LE_SHIFT                                              19
#define MBOX_19_129_F1_LE_MASK                                       0x00100000
#define MBOX_19_129_F1_LE_RD(src)                  (((src) & 0x00100000) >> 20)
#define MBOX_19_129_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields mbox_19_11	 */
#define MBOX_19_119_F1_LE_WIDTH                                               1
#define MBOX_19_119_F1_LE_SHIFT                                              20
#define MBOX_19_119_F1_LE_MASK                                       0x00080000
#define MBOX_19_119_F1_LE_RD(src)                  (((src) & 0x00080000) >> 19)
#define MBOX_19_119_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*	 Fields mbox_19_10	 */
#define MBOX_19_109_F1_LE_WIDTH                                               1
#define MBOX_19_109_F1_LE_SHIFT                                              21
#define MBOX_19_109_F1_LE_MASK                                       0x00040000
#define MBOX_19_109_F1_LE_RD(src)                  (((src) & 0x00040000) >> 18)
#define MBOX_19_109_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*	 Fields mbox_19_9	 */
#define MBOX_19_99_F1_LE_WIDTH                                                1
#define MBOX_19_99_F1_LE_SHIFT                                               22
#define MBOX_19_99_F1_LE_MASK                                        0x00020000
#define MBOX_19_99_F1_LE_RD(src)                   (((src) & 0x00020000) >> 17)
#define MBOX_19_99_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*	 Fields mbox_19_8	 */
#define MBOX_19_89_F1_LE_WIDTH                                                1
#define MBOX_19_89_F1_LE_SHIFT                                               23
#define MBOX_19_89_F1_LE_MASK                                        0x00010000
#define MBOX_19_89_F1_LE_RD(src)                   (((src) & 0x00010000) >> 16)
#define MBOX_19_89_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*	 Fields mbox_19_7	 */
#define MBOX_19_79_F1_LE_WIDTH                                                1
#define MBOX_19_79_F1_LE_SHIFT                                               24
#define MBOX_19_79_F1_LE_MASK                                        0x80000000
#define MBOX_19_79_F1_LE_RD(src)                   (((src) & 0x80000000) >> 31)
#define MBOX_19_79_F1_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields mbox_19_6	 */
#define MBOX_19_69_F1_LE_WIDTH                                                1
#define MBOX_19_69_F1_LE_SHIFT                                               25
#define MBOX_19_69_F1_LE_MASK                                        0x40000000
#define MBOX_19_69_F1_LE_RD(src)                   (((src) & 0x40000000) >> 30)
#define MBOX_19_69_F1_LE_SET(dst,src)                     ((dst)&~0x40000000)|\
				(((unsigned int)(src) << 30) & 0x40000000)

/*	 Fields mbox_19_5	 */
#define MBOX_19_59_F1_LE_WIDTH                                                1
#define MBOX_19_59_F1_LE_SHIFT                                               26
#define MBOX_19_59_F1_LE_MASK                                        0x20000000
#define MBOX_19_59_F1_LE_RD(src)                   (((src) & 0x20000000) >> 29)
#define MBOX_19_59_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields mbox_19_4	 */
#define MBOX_19_49_F1_LE_WIDTH                                                1
#define MBOX_19_49_F1_LE_SHIFT                                               27
#define MBOX_19_49_F1_LE_MASK                                        0x10000000
#define MBOX_19_49_F1_LE_RD(src)                   (((src) & 0x10000000) >> 28)
#define MBOX_19_49_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields mbox_19_3	 */
#define MBOX_19_39_F1_LE_WIDTH                                                1
#define MBOX_19_39_F1_LE_SHIFT                                               28
#define MBOX_19_39_F1_LE_MASK                                        0x08000000
#define MBOX_19_39_F1_LE_RD(src)                   (((src) & 0x08000000) >> 27)
#define MBOX_19_39_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields mbox_19_2	 */
#define MBOX_19_29_F1_LE_WIDTH                                                1
#define MBOX_19_29_F1_LE_SHIFT                                               29
#define MBOX_19_29_F1_LE_MASK                                        0x04000000
#define MBOX_19_29_F1_LE_RD(src)                   (((src) & 0x04000000) >> 26)
#define MBOX_19_29_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields mbox_19_1	 */
#define MBOX_19_19_F1_LE_WIDTH                                                1
#define MBOX_19_19_F1_LE_SHIFT                                               30
#define MBOX_19_19_F1_LE_MASK                                        0x02000000
#define MBOX_19_19_F1_LE_RD(src)                   (((src) & 0x02000000) >> 25)
#define MBOX_19_19_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields mbox_19_0	 */
#define MBOX_19_09_F1_LE_WIDTH                                                1
#define MBOX_19_09_F1_LE_SHIFT                                               31
#define MBOX_19_09_F1_LE_MASK                                        0x01000000
#define MBOX_19_09_F1_LE_RD(src)                   (((src) & 0x01000000) >> 24)
#define MBOX_19_09_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register csr_enq_status_10	*/

/*	 Fields mbox_20_15	 */
#define MBOX_20_150_F1_LE_WIDTH                                               1
#define MBOX_20_150_F1_LE_SHIFT                                               0
#define MBOX_20_150_F1_LE_MASK                                       0x00000080
#define MBOX_20_150_F1_LE_RD(src)                    (((src) & 0x00000080)<< 7)
#define MBOX_20_150_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields mbox_20_14	 */
#define MBOX_20_140_F1_LE_WIDTH                                               1
#define MBOX_20_140_F1_LE_SHIFT                                               1
#define MBOX_20_140_F1_LE_MASK                                       0x00000040
#define MBOX_20_140_F1_LE_RD(src)                    (((src) & 0x00000040)<< 6)
#define MBOX_20_140_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields mbox_20_13	 */
#define MBOX_20_130_F1_LE_WIDTH                                               1
#define MBOX_20_130_F1_LE_SHIFT                                               2
#define MBOX_20_130_F1_LE_MASK                                       0x00000020
#define MBOX_20_130_F1_LE_RD(src)                    (((src) & 0x00000020)<< 5)
#define MBOX_20_130_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*	 Fields mbox_20_12	 */
#define MBOX_20_120_F1_LE_WIDTH                                               1
#define MBOX_20_120_F1_LE_SHIFT                                               3
#define MBOX_20_120_F1_LE_MASK                                       0x00000010
#define MBOX_20_120_F1_LE_RD(src)                    (((src) & 0x00000010)<< 4)
#define MBOX_20_120_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields mbox_20_11	 */
#define MBOX_20_110_F1_LE_WIDTH                                               1
#define MBOX_20_110_F1_LE_SHIFT                                               4
#define MBOX_20_110_F1_LE_MASK                                       0x00000008
#define MBOX_20_110_F1_LE_RD(src)                    (((src) & 0x00000008)<< 3)
#define MBOX_20_110_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*	 Fields mbox_20_10	 */
#define MBOX_20_100_F1_LE_WIDTH                                               1
#define MBOX_20_100_F1_LE_SHIFT                                               5
#define MBOX_20_100_F1_LE_MASK                                       0x00000004
#define MBOX_20_100_F1_LE_RD(src)                    (((src) & 0x00000004)<< 2)
#define MBOX_20_100_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*	 Fields mbox_20_9	 */
#define MBOX_20_90_F1_LE_WIDTH                                                1
#define MBOX_20_90_F1_LE_SHIFT                                                6
#define MBOX_20_90_F1_LE_MASK                                        0x00000002
#define MBOX_20_90_F1_LE_RD(src)                     (((src) & 0x00000002)<< 1)
#define MBOX_20_90_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*	 Fields mbox_20_8	 */
#define MBOX_20_80_F1_LE_WIDTH                                                1
#define MBOX_20_80_F1_LE_SHIFT                                                7
#define MBOX_20_80_F1_LE_MASK                                        0x00000001
#define MBOX_20_80_F1_LE_RD(src)                     (((src) & 0x00000001)<< 0)
#define MBOX_20_80_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*	 Fields mbox_20_7	 */
#define MBOX_20_70_F1_LE_WIDTH                                                1
#define MBOX_20_70_F1_LE_SHIFT                                                8
#define MBOX_20_70_F1_LE_MASK                                        0x00008000
#define MBOX_20_70_F1_LE_RD(src)                   (((src) & 0x00008000) >> 15)
#define MBOX_20_70_F1_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*	 Fields mbox_20_6	 */
#define MBOX_20_60_F1_LE_WIDTH                                                1
#define MBOX_20_60_F1_LE_SHIFT                                                9
#define MBOX_20_60_F1_LE_MASK                                        0x00004000
#define MBOX_20_60_F1_LE_RD(src)                   (((src) & 0x00004000) >> 14)
#define MBOX_20_60_F1_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*	 Fields mbox_20_5	 */
#define MBOX_20_50_F1_LE_WIDTH                                                1
#define MBOX_20_50_F1_LE_SHIFT                                               10
#define MBOX_20_50_F1_LE_MASK                                        0x00002000
#define MBOX_20_50_F1_LE_RD(src)                   (((src) & 0x00002000) >> 13)
#define MBOX_20_50_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*	 Fields mbox_20_4	 */
#define MBOX_20_40_F1_LE_WIDTH                                                1
#define MBOX_20_40_F1_LE_SHIFT                                               11
#define MBOX_20_40_F1_LE_MASK                                        0x00001000
#define MBOX_20_40_F1_LE_RD(src)                   (((src) & 0x00001000) >> 12)
#define MBOX_20_40_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*	 Fields mbox_20_3	 */
#define MBOX_20_30_F1_LE_WIDTH                                                1
#define MBOX_20_30_F1_LE_SHIFT                                               12
#define MBOX_20_30_F1_LE_MASK                                        0x00000800
#define MBOX_20_30_F1_LE_RD(src)                   (((src) & 0x00000800) >> 11)
#define MBOX_20_30_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*	 Fields mbox_20_2	 */
#define MBOX_20_20_F1_LE_WIDTH                                                1
#define MBOX_20_20_F1_LE_SHIFT                                               13
#define MBOX_20_20_F1_LE_MASK                                        0x00000400
#define MBOX_20_20_F1_LE_RD(src)                   (((src) & 0x00000400) >> 10)
#define MBOX_20_20_F1_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*	 Fields mbox_20_1	 */
#define MBOX_20_10_F1_LE_WIDTH                                                1
#define MBOX_20_10_F1_LE_SHIFT                                               14
#define MBOX_20_10_F1_LE_MASK                                        0x00000200
#define MBOX_20_10_F1_LE_RD(src)                    (((src) & 0x00000200) >> 9)
#define MBOX_20_10_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*	 Fields mbox_20_0	 */
#define MBOX_20_00_F1_LE_WIDTH                                                1
#define MBOX_20_00_F1_LE_SHIFT                                               15
#define MBOX_20_00_F1_LE_MASK                                        0x00000100
#define MBOX_20_00_F1_LE_RD(src)                    (((src) & 0x00000100) >> 8)
#define MBOX_20_00_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*	 Fields mbox_21_15	 */
#define MBOX_21_150_F1_LE_WIDTH                                               1
#define MBOX_21_150_F1_LE_SHIFT                                              16
#define MBOX_21_150_F1_LE_MASK                                       0x00800000
#define MBOX_21_150_F1_LE_RD(src)                  (((src) & 0x00800000) >> 23)
#define MBOX_21_150_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*	 Fields mbox_21_14	 */
#define MBOX_21_140_F1_LE_WIDTH                                               1
#define MBOX_21_140_F1_LE_SHIFT                                              17
#define MBOX_21_140_F1_LE_MASK                                       0x00400000
#define MBOX_21_140_F1_LE_RD(src)                  (((src) & 0x00400000) >> 22)
#define MBOX_21_140_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*	 Fields mbox_21_13	 */
#define MBOX_21_130_F1_LE_WIDTH                                               1
#define MBOX_21_130_F1_LE_SHIFT                                              18
#define MBOX_21_130_F1_LE_MASK                                       0x00200000
#define MBOX_21_130_F1_LE_RD(src)                  (((src) & 0x00200000) >> 21)
#define MBOX_21_130_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*	 Fields mbox_21_12	 */
#define MBOX_21_120_F1_LE_WIDTH                                               1
#define MBOX_21_120_F1_LE_SHIFT                                              19
#define MBOX_21_120_F1_LE_MASK                                       0x00100000
#define MBOX_21_120_F1_LE_RD(src)                  (((src) & 0x00100000) >> 20)
#define MBOX_21_120_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields mbox_21_11	 */
#define MBOX_21_110_F1_LE_WIDTH                                               1
#define MBOX_21_110_F1_LE_SHIFT                                              20
#define MBOX_21_110_F1_LE_MASK                                       0x00080000
#define MBOX_21_110_F1_LE_RD(src)                  (((src) & 0x00080000) >> 19)
#define MBOX_21_110_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*	 Fields mbox_21_10	 */
#define MBOX_21_100_F1_LE_WIDTH                                               1
#define MBOX_21_100_F1_LE_SHIFT                                              21
#define MBOX_21_100_F1_LE_MASK                                       0x00040000
#define MBOX_21_100_F1_LE_RD(src)                  (((src) & 0x00040000) >> 18)
#define MBOX_21_100_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*	 Fields mbox_21_9	 */
#define MBOX_21_90_F1_LE_WIDTH                                                1
#define MBOX_21_90_F1_LE_SHIFT                                               22
#define MBOX_21_90_F1_LE_MASK                                        0x00020000
#define MBOX_21_90_F1_LE_RD(src)                   (((src) & 0x00020000) >> 17)
#define MBOX_21_90_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*	 Fields mbox_21_8	 */
#define MBOX_21_80_F1_LE_WIDTH                                                1
#define MBOX_21_80_F1_LE_SHIFT                                               23
#define MBOX_21_80_F1_LE_MASK                                        0x00010000
#define MBOX_21_80_F1_LE_RD(src)                   (((src) & 0x00010000) >> 16)
#define MBOX_21_80_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*	 Fields mbox_21_7	 */
#define MBOX_21_70_F1_LE_WIDTH                                                1
#define MBOX_21_70_F1_LE_SHIFT                                               24
#define MBOX_21_70_F1_LE_MASK                                        0x80000000
#define MBOX_21_70_F1_LE_RD(src)                   (((src) & 0x80000000) >> 31)
#define MBOX_21_70_F1_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields mbox_21_6	 */
#define MBOX_21_60_F1_LE_WIDTH                                                1
#define MBOX_21_60_F1_LE_SHIFT                                               25
#define MBOX_21_60_F1_LE_MASK                                        0x40000000
#define MBOX_21_60_F1_LE_RD(src)                   (((src) & 0x40000000) >> 30)
#define MBOX_21_60_F1_LE_SET(dst,src)                     ((dst)&~0x40000000)|\
				(((unsigned int)(src) << 30) & 0x40000000)

/*	 Fields mbox_21_5	 */
#define MBOX_21_50_F1_LE_WIDTH                                                1
#define MBOX_21_50_F1_LE_SHIFT                                               26
#define MBOX_21_50_F1_LE_MASK                                        0x20000000
#define MBOX_21_50_F1_LE_RD(src)                   (((src) & 0x20000000) >> 29)
#define MBOX_21_50_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields mbox_21_4	 */
#define MBOX_21_40_F1_LE_WIDTH                                                1
#define MBOX_21_40_F1_LE_SHIFT                                               27
#define MBOX_21_40_F1_LE_MASK                                        0x10000000
#define MBOX_21_40_F1_LE_RD(src)                   (((src) & 0x10000000) >> 28)
#define MBOX_21_40_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields mbox_21_3	 */
#define MBOX_21_30_F1_LE_WIDTH                                                1
#define MBOX_21_30_F1_LE_SHIFT                                               28
#define MBOX_21_30_F1_LE_MASK                                        0x08000000
#define MBOX_21_30_F1_LE_RD(src)                   (((src) & 0x08000000) >> 27)
#define MBOX_21_30_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields mbox_21_2	 */
#define MBOX_21_20_F1_LE_WIDTH                                                1
#define MBOX_21_20_F1_LE_SHIFT                                               29
#define MBOX_21_20_F1_LE_MASK                                        0x04000000
#define MBOX_21_20_F1_LE_RD(src)                   (((src) & 0x04000000) >> 26)
#define MBOX_21_20_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields mbox_21_1	 */
#define MBOX_21_10_F1_LE_WIDTH                                                1
#define MBOX_21_10_F1_LE_SHIFT                                               30
#define MBOX_21_10_F1_LE_MASK                                        0x02000000
#define MBOX_21_10_F1_LE_RD(src)                   (((src) & 0x02000000) >> 25)
#define MBOX_21_10_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields mbox_21_0	 */
#define MBOX_21_00_F1_LE_WIDTH                                                1
#define MBOX_21_00_F1_LE_SHIFT                                               31
#define MBOX_21_00_F1_LE_MASK                                        0x01000000
#define MBOX_21_00_F1_LE_RD(src)                   (((src) & 0x01000000) >> 24)
#define MBOX_21_00_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register csr_enq_status_11	*/

/*	 Fields mbox_22_15	 */
#define MBOX_22_151_F1_LE_WIDTH                                               1
#define MBOX_22_151_F1_LE_SHIFT                                               0
#define MBOX_22_151_F1_LE_MASK                                       0x00000080
#define MBOX_22_151_F1_LE_RD(src)                    (((src) & 0x00000080)<< 7)
#define MBOX_22_151_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields mbox_22_14	 */
#define MBOX_22_141_F1_LE_WIDTH                                               1
#define MBOX_22_141_F1_LE_SHIFT                                               1
#define MBOX_22_141_F1_LE_MASK                                       0x00000040
#define MBOX_22_141_F1_LE_RD(src)                    (((src) & 0x00000040)<< 6)
#define MBOX_22_141_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields mbox_22_13	 */
#define MBOX_22_131_F1_LE_WIDTH                                               1
#define MBOX_22_131_F1_LE_SHIFT                                               2
#define MBOX_22_131_F1_LE_MASK                                       0x00000020
#define MBOX_22_131_F1_LE_RD(src)                    (((src) & 0x00000020)<< 5)
#define MBOX_22_131_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*	 Fields mbox_22_12	 */
#define MBOX_22_121_F1_LE_WIDTH                                               1
#define MBOX_22_121_F1_LE_SHIFT                                               3
#define MBOX_22_121_F1_LE_MASK                                       0x00000010
#define MBOX_22_121_F1_LE_RD(src)                    (((src) & 0x00000010)<< 4)
#define MBOX_22_121_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields mbox_22_11	 */
#define MBOX_22_111_F1_LE_WIDTH                                               1
#define MBOX_22_111_F1_LE_SHIFT                                               4
#define MBOX_22_111_F1_LE_MASK                                       0x00000008
#define MBOX_22_111_F1_LE_RD(src)                    (((src) & 0x00000008)<< 3)
#define MBOX_22_111_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*	 Fields mbox_22_10	 */
#define MBOX_22_101_F1_LE_WIDTH                                               1
#define MBOX_22_101_F1_LE_SHIFT                                               5
#define MBOX_22_101_F1_LE_MASK                                       0x00000004
#define MBOX_22_101_F1_LE_RD(src)                    (((src) & 0x00000004)<< 2)
#define MBOX_22_101_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*	 Fields mbox_22_9	 */
#define MBOX_22_91_F1_LE_WIDTH                                                1
#define MBOX_22_91_F1_LE_SHIFT                                                6
#define MBOX_22_91_F1_LE_MASK                                        0x00000002
#define MBOX_22_91_F1_LE_RD(src)                     (((src) & 0x00000002)<< 1)
#define MBOX_22_91_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*	 Fields mbox_22_8	 */
#define MBOX_22_81_F1_LE_WIDTH                                                1
#define MBOX_22_81_F1_LE_SHIFT                                                7
#define MBOX_22_81_F1_LE_MASK                                        0x00000001
#define MBOX_22_81_F1_LE_RD(src)                     (((src) & 0x00000001)<< 0)
#define MBOX_22_81_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*	 Fields mbox_22_7	 */
#define MBOX_22_71_F1_LE_WIDTH                                                1
#define MBOX_22_71_F1_LE_SHIFT                                                8
#define MBOX_22_71_F1_LE_MASK                                        0x00008000
#define MBOX_22_71_F1_LE_RD(src)                   (((src) & 0x00008000) >> 15)
#define MBOX_22_71_F1_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*	 Fields mbox_22_6	 */
#define MBOX_22_61_F1_LE_WIDTH                                                1
#define MBOX_22_61_F1_LE_SHIFT                                                9
#define MBOX_22_61_F1_LE_MASK                                        0x00004000
#define MBOX_22_61_F1_LE_RD(src)                   (((src) & 0x00004000) >> 14)
#define MBOX_22_61_F1_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*	 Fields mbox_22_5	 */
#define MBOX_22_51_F1_LE_WIDTH                                                1
#define MBOX_22_51_F1_LE_SHIFT                                               10
#define MBOX_22_51_F1_LE_MASK                                        0x00002000
#define MBOX_22_51_F1_LE_RD(src)                   (((src) & 0x00002000) >> 13)
#define MBOX_22_51_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*	 Fields mbox_22_4	 */
#define MBOX_22_41_F1_LE_WIDTH                                                1
#define MBOX_22_41_F1_LE_SHIFT                                               11
#define MBOX_22_41_F1_LE_MASK                                        0x00001000
#define MBOX_22_41_F1_LE_RD(src)                   (((src) & 0x00001000) >> 12)
#define MBOX_22_41_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*	 Fields mbox_22_3	 */
#define MBOX_22_31_F1_LE_WIDTH                                                1
#define MBOX_22_31_F1_LE_SHIFT                                               12
#define MBOX_22_31_F1_LE_MASK                                        0x00000800
#define MBOX_22_31_F1_LE_RD(src)                   (((src) & 0x00000800) >> 11)
#define MBOX_22_31_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*	 Fields mbox_22_2	 */
#define MBOX_22_21_F1_LE_WIDTH                                                1
#define MBOX_22_21_F1_LE_SHIFT                                               13
#define MBOX_22_21_F1_LE_MASK                                        0x00000400
#define MBOX_22_21_F1_LE_RD(src)                   (((src) & 0x00000400) >> 10)
#define MBOX_22_21_F1_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*	 Fields mbox_22_1	 */
#define MBOX_22_11_F1_LE_WIDTH                                                1
#define MBOX_22_11_F1_LE_SHIFT                                               14
#define MBOX_22_11_F1_LE_MASK                                        0x00000200
#define MBOX_22_11_F1_LE_RD(src)                    (((src) & 0x00000200) >> 9)
#define MBOX_22_11_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*	 Fields mbox_22_0	 */
#define MBOX_22_01_F1_LE_WIDTH                                                1
#define MBOX_22_01_F1_LE_SHIFT                                               15
#define MBOX_22_01_F1_LE_MASK                                        0x00000100
#define MBOX_22_01_F1_LE_RD(src)                    (((src) & 0x00000100) >> 8)
#define MBOX_22_01_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*	 Fields mbox_23_15	 */
#define MBOX_23_151_F1_LE_WIDTH                                               1
#define MBOX_23_151_F1_LE_SHIFT                                              16
#define MBOX_23_151_F1_LE_MASK                                       0x00800000
#define MBOX_23_151_F1_LE_RD(src)                  (((src) & 0x00800000) >> 23)
#define MBOX_23_151_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*	 Fields mbox_23_14	 */
#define MBOX_23_141_F1_LE_WIDTH                                               1
#define MBOX_23_141_F1_LE_SHIFT                                              17
#define MBOX_23_141_F1_LE_MASK                                       0x00400000
#define MBOX_23_141_F1_LE_RD(src)                  (((src) & 0x00400000) >> 22)
#define MBOX_23_141_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*	 Fields mbox_23_13	 */
#define MBOX_23_131_F1_LE_WIDTH                                               1
#define MBOX_23_131_F1_LE_SHIFT                                              18
#define MBOX_23_131_F1_LE_MASK                                       0x00200000
#define MBOX_23_131_F1_LE_RD(src)                  (((src) & 0x00200000) >> 21)
#define MBOX_23_131_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*	 Fields mbox_23_12	 */
#define MBOX_23_121_F1_LE_WIDTH                                               1
#define MBOX_23_121_F1_LE_SHIFT                                              19
#define MBOX_23_121_F1_LE_MASK                                       0x00100000
#define MBOX_23_121_F1_LE_RD(src)                  (((src) & 0x00100000) >> 20)
#define MBOX_23_121_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields mbox_23_11	 */
#define MBOX_23_111_F1_LE_WIDTH                                               1
#define MBOX_23_111_F1_LE_SHIFT                                              20
#define MBOX_23_111_F1_LE_MASK                                       0x00080000
#define MBOX_23_111_F1_LE_RD(src)                  (((src) & 0x00080000) >> 19)
#define MBOX_23_111_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*	 Fields mbox_23_10	 */
#define MBOX_23_101_F1_LE_WIDTH                                               1
#define MBOX_23_101_F1_LE_SHIFT                                              21
#define MBOX_23_101_F1_LE_MASK                                       0x00040000
#define MBOX_23_101_F1_LE_RD(src)                  (((src) & 0x00040000) >> 18)
#define MBOX_23_101_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*	 Fields mbox_23_9	 */
#define MBOX_23_91_F1_LE_WIDTH                                                1
#define MBOX_23_91_F1_LE_SHIFT                                               22
#define MBOX_23_91_F1_LE_MASK                                        0x00020000
#define MBOX_23_91_F1_LE_RD(src)                   (((src) & 0x00020000) >> 17)
#define MBOX_23_91_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*	 Fields mbox_23_8	 */
#define MBOX_23_81_F1_LE_WIDTH                                                1
#define MBOX_23_81_F1_LE_SHIFT                                               23
#define MBOX_23_81_F1_LE_MASK                                        0x00010000
#define MBOX_23_81_F1_LE_RD(src)                   (((src) & 0x00010000) >> 16)
#define MBOX_23_81_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*	 Fields mbox_23_7	 */
#define MBOX_23_71_F1_LE_WIDTH                                                1
#define MBOX_23_71_F1_LE_SHIFT                                               24
#define MBOX_23_71_F1_LE_MASK                                        0x80000000
#define MBOX_23_71_F1_LE_RD(src)                   (((src) & 0x80000000) >> 31)
#define MBOX_23_71_F1_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields mbox_23_6	 */
#define MBOX_23_61_F1_LE_WIDTH                                                1
#define MBOX_23_61_F1_LE_SHIFT                                               25
#define MBOX_23_61_F1_LE_MASK                                        0x40000000
#define MBOX_23_61_F1_LE_RD(src)                   (((src) & 0x40000000) >> 30)
#define MBOX_23_61_F1_LE_SET(dst,src)                     ((dst)&~0x40000000)|\
				(((unsigned int)(src) << 30) & 0x40000000)

/*	 Fields mbox_23_5	 */
#define MBOX_23_51_F1_LE_WIDTH                                                1
#define MBOX_23_51_F1_LE_SHIFT                                               26
#define MBOX_23_51_F1_LE_MASK                                        0x20000000
#define MBOX_23_51_F1_LE_RD(src)                   (((src) & 0x20000000) >> 29)
#define MBOX_23_51_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields mbox_23_4	 */
#define MBOX_23_41_F1_LE_WIDTH                                                1
#define MBOX_23_41_F1_LE_SHIFT                                               27
#define MBOX_23_41_F1_LE_MASK                                        0x10000000
#define MBOX_23_41_F1_LE_RD(src)                   (((src) & 0x10000000) >> 28)
#define MBOX_23_41_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields mbox_23_3	 */
#define MBOX_23_31_F1_LE_WIDTH                                                1
#define MBOX_23_31_F1_LE_SHIFT                                               28
#define MBOX_23_31_F1_LE_MASK                                        0x08000000
#define MBOX_23_31_F1_LE_RD(src)                   (((src) & 0x08000000) >> 27)
#define MBOX_23_31_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields mbox_23_2	 */
#define MBOX_23_21_F1_LE_WIDTH                                                1
#define MBOX_23_21_F1_LE_SHIFT                                               29
#define MBOX_23_21_F1_LE_MASK                                        0x04000000
#define MBOX_23_21_F1_LE_RD(src)                   (((src) & 0x04000000) >> 26)
#define MBOX_23_21_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields mbox_23_1	 */
#define MBOX_23_11_F1_LE_WIDTH                                                1
#define MBOX_23_11_F1_LE_SHIFT                                               30
#define MBOX_23_11_F1_LE_MASK                                        0x02000000
#define MBOX_23_11_F1_LE_RD(src)                   (((src) & 0x02000000) >> 25)
#define MBOX_23_11_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields mbox_23_0	 */
#define MBOX_23_01_F1_LE_WIDTH                                                1
#define MBOX_23_01_F1_LE_SHIFT                                               31
#define MBOX_23_01_F1_LE_MASK                                        0x01000000
#define MBOX_23_01_F1_LE_RD(src)                   (((src) & 0x01000000) >> 24)
#define MBOX_23_01_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register csr_enq_status_12	*/

/*	 Fields mbox_24_15	 */
#define MBOX_24_152_F1_LE_WIDTH                                               1
#define MBOX_24_152_F1_LE_SHIFT                                               0
#define MBOX_24_152_F1_LE_MASK                                       0x00000080
#define MBOX_24_152_F1_LE_RD(src)                    (((src) & 0x00000080)<< 7)
#define MBOX_24_152_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields mbox_24_14	 */
#define MBOX_24_142_F1_LE_WIDTH                                               1
#define MBOX_24_142_F1_LE_SHIFT                                               1
#define MBOX_24_142_F1_LE_MASK                                       0x00000040
#define MBOX_24_142_F1_LE_RD(src)                    (((src) & 0x00000040)<< 6)
#define MBOX_24_142_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields mbox_24_13	 */
#define MBOX_24_132_F1_LE_WIDTH                                               1
#define MBOX_24_132_F1_LE_SHIFT                                               2
#define MBOX_24_132_F1_LE_MASK                                       0x00000020
#define MBOX_24_132_F1_LE_RD(src)                    (((src) & 0x00000020)<< 5)
#define MBOX_24_132_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*	 Fields mbox_24_12	 */
#define MBOX_24_122_F1_LE_WIDTH                                               1
#define MBOX_24_122_F1_LE_SHIFT                                               3
#define MBOX_24_122_F1_LE_MASK                                       0x00000010
#define MBOX_24_122_F1_LE_RD(src)                    (((src) & 0x00000010)<< 4)
#define MBOX_24_122_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields mbox_24_11	 */
#define MBOX_24_112_F1_LE_WIDTH                                               1
#define MBOX_24_112_F1_LE_SHIFT                                               4
#define MBOX_24_112_F1_LE_MASK                                       0x00000008
#define MBOX_24_112_F1_LE_RD(src)                    (((src) & 0x00000008)<< 3)
#define MBOX_24_112_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*	 Fields mbox_24_10	 */
#define MBOX_24_102_F1_LE_WIDTH                                               1
#define MBOX_24_102_F1_LE_SHIFT                                               5
#define MBOX_24_102_F1_LE_MASK                                       0x00000004
#define MBOX_24_102_F1_LE_RD(src)                    (((src) & 0x00000004)<< 2)
#define MBOX_24_102_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*	 Fields mbox_24_9	 */
#define MBOX_24_92_F1_LE_WIDTH                                                1
#define MBOX_24_92_F1_LE_SHIFT                                                6
#define MBOX_24_92_F1_LE_MASK                                        0x00000002
#define MBOX_24_92_F1_LE_RD(src)                     (((src) & 0x00000002)<< 1)
#define MBOX_24_92_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*	 Fields mbox_24_8	 */
#define MBOX_24_82_F1_LE_WIDTH                                                1
#define MBOX_24_82_F1_LE_SHIFT                                                7
#define MBOX_24_82_F1_LE_MASK                                        0x00000001
#define MBOX_24_82_F1_LE_RD(src)                     (((src) & 0x00000001)<< 0)
#define MBOX_24_82_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*	 Fields mbox_24_7	 */
#define MBOX_24_72_F1_LE_WIDTH                                                1
#define MBOX_24_72_F1_LE_SHIFT                                                8
#define MBOX_24_72_F1_LE_MASK                                        0x00008000
#define MBOX_24_72_F1_LE_RD(src)                   (((src) & 0x00008000) >> 15)
#define MBOX_24_72_F1_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*	 Fields mbox_24_6	 */
#define MBOX_24_62_F1_LE_WIDTH                                                1
#define MBOX_24_62_F1_LE_SHIFT                                                9
#define MBOX_24_62_F1_LE_MASK                                        0x00004000
#define MBOX_24_62_F1_LE_RD(src)                   (((src) & 0x00004000) >> 14)
#define MBOX_24_62_F1_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*	 Fields mbox_24_5	 */
#define MBOX_24_52_F1_LE_WIDTH                                                1
#define MBOX_24_52_F1_LE_SHIFT                                               10
#define MBOX_24_52_F1_LE_MASK                                        0x00002000
#define MBOX_24_52_F1_LE_RD(src)                   (((src) & 0x00002000) >> 13)
#define MBOX_24_52_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*	 Fields mbox_24_4	 */
#define MBOX_24_42_F1_LE_WIDTH                                                1
#define MBOX_24_42_F1_LE_SHIFT                                               11
#define MBOX_24_42_F1_LE_MASK                                        0x00001000
#define MBOX_24_42_F1_LE_RD(src)                   (((src) & 0x00001000) >> 12)
#define MBOX_24_42_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*	 Fields mbox_24_3	 */
#define MBOX_24_32_F1_LE_WIDTH                                                1
#define MBOX_24_32_F1_LE_SHIFT                                               12
#define MBOX_24_32_F1_LE_MASK                                        0x00000800
#define MBOX_24_32_F1_LE_RD(src)                   (((src) & 0x00000800) >> 11)
#define MBOX_24_32_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*	 Fields mbox_24_2	 */
#define MBOX_24_22_F1_LE_WIDTH                                                1
#define MBOX_24_22_F1_LE_SHIFT                                               13
#define MBOX_24_22_F1_LE_MASK                                        0x00000400
#define MBOX_24_22_F1_LE_RD(src)                   (((src) & 0x00000400) >> 10)
#define MBOX_24_22_F1_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*	 Fields mbox_24_1	 */
#define MBOX_24_12_F1_LE_WIDTH                                                1
#define MBOX_24_12_F1_LE_SHIFT                                               14
#define MBOX_24_12_F1_LE_MASK                                        0x00000200
#define MBOX_24_12_F1_LE_RD(src)                    (((src) & 0x00000200) >> 9)
#define MBOX_24_12_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*	 Fields mbox_24_0	 */
#define MBOX_24_02_F1_LE_WIDTH                                                1
#define MBOX_24_02_F1_LE_SHIFT                                               15
#define MBOX_24_02_F1_LE_MASK                                        0x00000100
#define MBOX_24_02_F1_LE_RD(src)                    (((src) & 0x00000100) >> 8)
#define MBOX_24_02_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*	 Fields mbox_25_15	 */
#define MBOX_25_152_F1_LE_WIDTH                                               1
#define MBOX_25_152_F1_LE_SHIFT                                              16
#define MBOX_25_152_F1_LE_MASK                                       0x00800000
#define MBOX_25_152_F1_LE_RD(src)                  (((src) & 0x00800000) >> 23)
#define MBOX_25_152_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*	 Fields mbox_25_14	 */
#define MBOX_25_142_F1_LE_WIDTH                                               1
#define MBOX_25_142_F1_LE_SHIFT                                              17
#define MBOX_25_142_F1_LE_MASK                                       0x00400000
#define MBOX_25_142_F1_LE_RD(src)                  (((src) & 0x00400000) >> 22)
#define MBOX_25_142_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*	 Fields mbox_25_13	 */
#define MBOX_25_132_F1_LE_WIDTH                                               1
#define MBOX_25_132_F1_LE_SHIFT                                              18
#define MBOX_25_132_F1_LE_MASK                                       0x00200000
#define MBOX_25_132_F1_LE_RD(src)                  (((src) & 0x00200000) >> 21)
#define MBOX_25_132_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*	 Fields mbox_25_12	 */
#define MBOX_25_122_F1_LE_WIDTH                                               1
#define MBOX_25_122_F1_LE_SHIFT                                              19
#define MBOX_25_122_F1_LE_MASK                                       0x00100000
#define MBOX_25_122_F1_LE_RD(src)                  (((src) & 0x00100000) >> 20)
#define MBOX_25_122_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields mbox_25_11	 */
#define MBOX_25_112_F1_LE_WIDTH                                               1
#define MBOX_25_112_F1_LE_SHIFT                                              20
#define MBOX_25_112_F1_LE_MASK                                       0x00080000
#define MBOX_25_112_F1_LE_RD(src)                  (((src) & 0x00080000) >> 19)
#define MBOX_25_112_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*	 Fields mbox_25_10	 */
#define MBOX_25_102_F1_LE_WIDTH                                               1
#define MBOX_25_102_F1_LE_SHIFT                                              21
#define MBOX_25_102_F1_LE_MASK                                       0x00040000
#define MBOX_25_102_F1_LE_RD(src)                  (((src) & 0x00040000) >> 18)
#define MBOX_25_102_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*	 Fields mbox_25_9	 */
#define MBOX_25_92_F1_LE_WIDTH                                                1
#define MBOX_25_92_F1_LE_SHIFT                                               22
#define MBOX_25_92_F1_LE_MASK                                        0x00020000
#define MBOX_25_92_F1_LE_RD(src)                   (((src) & 0x00020000) >> 17)
#define MBOX_25_92_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*	 Fields mbox_25_8	 */
#define MBOX_25_82_F1_LE_WIDTH                                                1
#define MBOX_25_82_F1_LE_SHIFT                                               23
#define MBOX_25_82_F1_LE_MASK                                        0x00010000
#define MBOX_25_82_F1_LE_RD(src)                   (((src) & 0x00010000) >> 16)
#define MBOX_25_82_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*	 Fields mbox_25_7	 */
#define MBOX_25_72_F1_LE_WIDTH                                                1
#define MBOX_25_72_F1_LE_SHIFT                                               24
#define MBOX_25_72_F1_LE_MASK                                        0x80000000
#define MBOX_25_72_F1_LE_RD(src)                   (((src) & 0x80000000) >> 31)
#define MBOX_25_72_F1_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields mbox_25_6	 */
#define MBOX_25_62_F1_LE_WIDTH                                                1
#define MBOX_25_62_F1_LE_SHIFT                                               25
#define MBOX_25_62_F1_LE_MASK                                        0x40000000
#define MBOX_25_62_F1_LE_RD(src)                   (((src) & 0x40000000) >> 30)
#define MBOX_25_62_F1_LE_SET(dst,src)                     ((dst)&~0x40000000)|\
				(((unsigned int)(src) << 30) & 0x40000000)

/*	 Fields mbox_25_5	 */
#define MBOX_25_52_F1_LE_WIDTH                                                1
#define MBOX_25_52_F1_LE_SHIFT                                               26
#define MBOX_25_52_F1_LE_MASK                                        0x20000000
#define MBOX_25_52_F1_LE_RD(src)                   (((src) & 0x20000000) >> 29)
#define MBOX_25_52_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields mbox_25_4	 */
#define MBOX_25_42_F1_LE_WIDTH                                                1
#define MBOX_25_42_F1_LE_SHIFT                                               27
#define MBOX_25_42_F1_LE_MASK                                        0x10000000
#define MBOX_25_42_F1_LE_RD(src)                   (((src) & 0x10000000) >> 28)
#define MBOX_25_42_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields mbox_25_3	 */
#define MBOX_25_32_F1_LE_WIDTH                                                1
#define MBOX_25_32_F1_LE_SHIFT                                               28
#define MBOX_25_32_F1_LE_MASK                                        0x08000000
#define MBOX_25_32_F1_LE_RD(src)                   (((src) & 0x08000000) >> 27)
#define MBOX_25_32_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields mbox_25_2	 */
#define MBOX_25_22_F1_LE_WIDTH                                                1
#define MBOX_25_22_F1_LE_SHIFT                                               29
#define MBOX_25_22_F1_LE_MASK                                        0x04000000
#define MBOX_25_22_F1_LE_RD(src)                   (((src) & 0x04000000) >> 26)
#define MBOX_25_22_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields mbox_25_1	 */
#define MBOX_25_12_F1_LE_WIDTH                                                1
#define MBOX_25_12_F1_LE_SHIFT                                               30
#define MBOX_25_12_F1_LE_MASK                                        0x02000000
#define MBOX_25_12_F1_LE_RD(src)                   (((src) & 0x02000000) >> 25)
#define MBOX_25_12_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields mbox_25_0	 */
#define MBOX_25_02_F1_LE_WIDTH                                                1
#define MBOX_25_02_F1_LE_SHIFT                                               31
#define MBOX_25_02_F1_LE_MASK                                        0x01000000
#define MBOX_25_02_F1_LE_RD(src)                   (((src) & 0x01000000) >> 24)
#define MBOX_25_02_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register csr_enq_status_13	*/

/*	 Fields mbox_26_15	 */
#define MBOX_26_153_F1_LE_WIDTH                                               1
#define MBOX_26_153_F1_LE_SHIFT                                               0
#define MBOX_26_153_F1_LE_MASK                                       0x00000080
#define MBOX_26_153_F1_LE_RD(src)                    (((src) & 0x00000080)<< 7)
#define MBOX_26_153_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields mbox_26_14	 */
#define MBOX_26_143_F1_LE_WIDTH                                               1
#define MBOX_26_143_F1_LE_SHIFT                                               1
#define MBOX_26_143_F1_LE_MASK                                       0x00000040
#define MBOX_26_143_F1_LE_RD(src)                    (((src) & 0x00000040)<< 6)
#define MBOX_26_143_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields mbox_26_13	 */
#define MBOX_26_133_F1_LE_WIDTH                                               1
#define MBOX_26_133_F1_LE_SHIFT                                               2
#define MBOX_26_133_F1_LE_MASK                                       0x00000020
#define MBOX_26_133_F1_LE_RD(src)                    (((src) & 0x00000020)<< 5)
#define MBOX_26_133_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*	 Fields mbox_26_12	 */
#define MBOX_26_123_F1_LE_WIDTH                                               1
#define MBOX_26_123_F1_LE_SHIFT                                               3
#define MBOX_26_123_F1_LE_MASK                                       0x00000010
#define MBOX_26_123_F1_LE_RD(src)                    (((src) & 0x00000010)<< 4)
#define MBOX_26_123_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields mbox_26_11	 */
#define MBOX_26_113_F1_LE_WIDTH                                               1
#define MBOX_26_113_F1_LE_SHIFT                                               4
#define MBOX_26_113_F1_LE_MASK                                       0x00000008
#define MBOX_26_113_F1_LE_RD(src)                    (((src) & 0x00000008)<< 3)
#define MBOX_26_113_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*	 Fields mbox_26_10	 */
#define MBOX_26_103_F1_LE_WIDTH                                               1
#define MBOX_26_103_F1_LE_SHIFT                                               5
#define MBOX_26_103_F1_LE_MASK                                       0x00000004
#define MBOX_26_103_F1_LE_RD(src)                    (((src) & 0x00000004)<< 2)
#define MBOX_26_103_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*	 Fields mbox_26_9	 */
#define MBOX_26_93_F1_LE_WIDTH                                                1
#define MBOX_26_93_F1_LE_SHIFT                                                6
#define MBOX_26_93_F1_LE_MASK                                        0x00000002
#define MBOX_26_93_F1_LE_RD(src)                     (((src) & 0x00000002)<< 1)
#define MBOX_26_93_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*	 Fields mbox_26_8	 */
#define MBOX_26_83_F1_LE_WIDTH                                                1
#define MBOX_26_83_F1_LE_SHIFT                                                7
#define MBOX_26_83_F1_LE_MASK                                        0x00000001
#define MBOX_26_83_F1_LE_RD(src)                     (((src) & 0x00000001)<< 0)
#define MBOX_26_83_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*	 Fields mbox_26_7	 */
#define MBOX_26_73_F1_LE_WIDTH                                                1
#define MBOX_26_73_F1_LE_SHIFT                                                8
#define MBOX_26_73_F1_LE_MASK                                        0x00008000
#define MBOX_26_73_F1_LE_RD(src)                   (((src) & 0x00008000) >> 15)
#define MBOX_26_73_F1_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*	 Fields mbox_26_6	 */
#define MBOX_26_63_F1_LE_WIDTH                                                1
#define MBOX_26_63_F1_LE_SHIFT                                                9
#define MBOX_26_63_F1_LE_MASK                                        0x00004000
#define MBOX_26_63_F1_LE_RD(src)                   (((src) & 0x00004000) >> 14)
#define MBOX_26_63_F1_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*	 Fields mbox_26_5	 */
#define MBOX_26_53_F1_LE_WIDTH                                                1
#define MBOX_26_53_F1_LE_SHIFT                                               10
#define MBOX_26_53_F1_LE_MASK                                        0x00002000
#define MBOX_26_53_F1_LE_RD(src)                   (((src) & 0x00002000) >> 13)
#define MBOX_26_53_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*	 Fields mbox_26_4	 */
#define MBOX_26_43_F1_LE_WIDTH                                                1
#define MBOX_26_43_F1_LE_SHIFT                                               11
#define MBOX_26_43_F1_LE_MASK                                        0x00001000
#define MBOX_26_43_F1_LE_RD(src)                   (((src) & 0x00001000) >> 12)
#define MBOX_26_43_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*	 Fields mbox_26_3	 */
#define MBOX_26_33_F1_LE_WIDTH                                                1
#define MBOX_26_33_F1_LE_SHIFT                                               12
#define MBOX_26_33_F1_LE_MASK                                        0x00000800
#define MBOX_26_33_F1_LE_RD(src)                   (((src) & 0x00000800) >> 11)
#define MBOX_26_33_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*	 Fields mbox_26_2	 */
#define MBOX_26_23_F1_LE_WIDTH                                                1
#define MBOX_26_23_F1_LE_SHIFT                                               13
#define MBOX_26_23_F1_LE_MASK                                        0x00000400
#define MBOX_26_23_F1_LE_RD(src)                   (((src) & 0x00000400) >> 10)
#define MBOX_26_23_F1_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*	 Fields mbox_26_1	 */
#define MBOX_26_13_F1_LE_WIDTH                                                1
#define MBOX_26_13_F1_LE_SHIFT                                               14
#define MBOX_26_13_F1_LE_MASK                                        0x00000200
#define MBOX_26_13_F1_LE_RD(src)                    (((src) & 0x00000200) >> 9)
#define MBOX_26_13_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*	 Fields mbox_26_0	 */
#define MBOX_26_03_F1_LE_WIDTH                                                1
#define MBOX_26_03_F1_LE_SHIFT                                               15
#define MBOX_26_03_F1_LE_MASK                                        0x00000100
#define MBOX_26_03_F1_LE_RD(src)                    (((src) & 0x00000100) >> 8)
#define MBOX_26_03_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*	 Fields mbox_27_15	 */
#define MBOX_27_153_F1_LE_WIDTH                                               1
#define MBOX_27_153_F1_LE_SHIFT                                              16
#define MBOX_27_153_F1_LE_MASK                                       0x00800000
#define MBOX_27_153_F1_LE_RD(src)                  (((src) & 0x00800000) >> 23)
#define MBOX_27_153_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*	 Fields mbox_27_14	 */
#define MBOX_27_143_F1_LE_WIDTH                                               1
#define MBOX_27_143_F1_LE_SHIFT                                              17
#define MBOX_27_143_F1_LE_MASK                                       0x00400000
#define MBOX_27_143_F1_LE_RD(src)                  (((src) & 0x00400000) >> 22)
#define MBOX_27_143_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*	 Fields mbox_27_13	 */
#define MBOX_27_133_F1_LE_WIDTH                                               1
#define MBOX_27_133_F1_LE_SHIFT                                              18
#define MBOX_27_133_F1_LE_MASK                                       0x00200000
#define MBOX_27_133_F1_LE_RD(src)                  (((src) & 0x00200000) >> 21)
#define MBOX_27_133_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*	 Fields mbox_27_12	 */
#define MBOX_27_123_F1_LE_WIDTH                                               1
#define MBOX_27_123_F1_LE_SHIFT                                              19
#define MBOX_27_123_F1_LE_MASK                                       0x00100000
#define MBOX_27_123_F1_LE_RD(src)                  (((src) & 0x00100000) >> 20)
#define MBOX_27_123_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields mbox_27_11	 */
#define MBOX_27_113_F1_LE_WIDTH                                               1
#define MBOX_27_113_F1_LE_SHIFT                                              20
#define MBOX_27_113_F1_LE_MASK                                       0x00080000
#define MBOX_27_113_F1_LE_RD(src)                  (((src) & 0x00080000) >> 19)
#define MBOX_27_113_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*	 Fields mbox_27_10	 */
#define MBOX_27_103_F1_LE_WIDTH                                               1
#define MBOX_27_103_F1_LE_SHIFT                                              21
#define MBOX_27_103_F1_LE_MASK                                       0x00040000
#define MBOX_27_103_F1_LE_RD(src)                  (((src) & 0x00040000) >> 18)
#define MBOX_27_103_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*	 Fields mbox_27_9	 */
#define MBOX_27_93_F1_LE_WIDTH                                                1
#define MBOX_27_93_F1_LE_SHIFT                                               22
#define MBOX_27_93_F1_LE_MASK                                        0x00020000
#define MBOX_27_93_F1_LE_RD(src)                   (((src) & 0x00020000) >> 17)
#define MBOX_27_93_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*	 Fields mbox_27_8	 */
#define MBOX_27_83_F1_LE_WIDTH                                                1
#define MBOX_27_83_F1_LE_SHIFT                                               23
#define MBOX_27_83_F1_LE_MASK                                        0x00010000
#define MBOX_27_83_F1_LE_RD(src)                   (((src) & 0x00010000) >> 16)
#define MBOX_27_83_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*	 Fields mbox_27_7	 */
#define MBOX_27_73_F1_LE_WIDTH                                                1
#define MBOX_27_73_F1_LE_SHIFT                                               24
#define MBOX_27_73_F1_LE_MASK                                        0x80000000
#define MBOX_27_73_F1_LE_RD(src)                   (((src) & 0x80000000) >> 31)
#define MBOX_27_73_F1_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields mbox_27_6	 */
#define MBOX_27_63_F1_LE_WIDTH                                                1
#define MBOX_27_63_F1_LE_SHIFT                                               25
#define MBOX_27_63_F1_LE_MASK                                        0x40000000
#define MBOX_27_63_F1_LE_RD(src)                   (((src) & 0x40000000) >> 30)
#define MBOX_27_63_F1_LE_SET(dst,src)                     ((dst)&~0x40000000)|\
				(((unsigned int)(src) << 30) & 0x40000000)

/*	 Fields mbox_27_5	 */
#define MBOX_27_53_F1_LE_WIDTH                                                1
#define MBOX_27_53_F1_LE_SHIFT                                               26
#define MBOX_27_53_F1_LE_MASK                                        0x20000000
#define MBOX_27_53_F1_LE_RD(src)                   (((src) & 0x20000000) >> 29)
#define MBOX_27_53_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields mbox_27_4	 */
#define MBOX_27_43_F1_LE_WIDTH                                                1
#define MBOX_27_43_F1_LE_SHIFT                                               27
#define MBOX_27_43_F1_LE_MASK                                        0x10000000
#define MBOX_27_43_F1_LE_RD(src)                   (((src) & 0x10000000) >> 28)
#define MBOX_27_43_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields mbox_27_3	 */
#define MBOX_27_33_F1_LE_WIDTH                                                1
#define MBOX_27_33_F1_LE_SHIFT                                               28
#define MBOX_27_33_F1_LE_MASK                                        0x08000000
#define MBOX_27_33_F1_LE_RD(src)                   (((src) & 0x08000000) >> 27)
#define MBOX_27_33_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields mbox_27_2	 */
#define MBOX_27_23_F1_LE_WIDTH                                                1
#define MBOX_27_23_F1_LE_SHIFT                                               29
#define MBOX_27_23_F1_LE_MASK                                        0x04000000
#define MBOX_27_23_F1_LE_RD(src)                   (((src) & 0x04000000) >> 26)
#define MBOX_27_23_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields mbox_27_1	 */
#define MBOX_27_13_F1_LE_WIDTH                                                1
#define MBOX_27_13_F1_LE_SHIFT                                               30
#define MBOX_27_13_F1_LE_MASK                                        0x02000000
#define MBOX_27_13_F1_LE_RD(src)                   (((src) & 0x02000000) >> 25)
#define MBOX_27_13_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields mbox_27_0	 */
#define MBOX_27_03_F1_LE_WIDTH                                                1
#define MBOX_27_03_F1_LE_SHIFT                                               31
#define MBOX_27_03_F1_LE_MASK                                        0x01000000
#define MBOX_27_03_F1_LE_RD(src)                   (((src) & 0x01000000) >> 24)
#define MBOX_27_03_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register csr_enq_status_14	*/

/*	 Fields mbox_28_15	 */
#define MBOX_28_154_F1_LE_WIDTH                                               1
#define MBOX_28_154_F1_LE_SHIFT                                               0
#define MBOX_28_154_F1_LE_MASK                                       0x00000080
#define MBOX_28_154_F1_LE_RD(src)                    (((src) & 0x00000080)<< 7)
#define MBOX_28_154_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields mbox_28_14	 */
#define MBOX_28_144_F1_LE_WIDTH                                               1
#define MBOX_28_144_F1_LE_SHIFT                                               1
#define MBOX_28_144_F1_LE_MASK                                       0x00000040
#define MBOX_28_144_F1_LE_RD(src)                    (((src) & 0x00000040)<< 6)
#define MBOX_28_144_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields mbox_28_13	 */
#define MBOX_28_134_F1_LE_WIDTH                                               1
#define MBOX_28_134_F1_LE_SHIFT                                               2
#define MBOX_28_134_F1_LE_MASK                                       0x00000020
#define MBOX_28_134_F1_LE_RD(src)                    (((src) & 0x00000020)<< 5)
#define MBOX_28_134_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*	 Fields mbox_28_12	 */
#define MBOX_28_124_F1_LE_WIDTH                                               1
#define MBOX_28_124_F1_LE_SHIFT                                               3
#define MBOX_28_124_F1_LE_MASK                                       0x00000010
#define MBOX_28_124_F1_LE_RD(src)                    (((src) & 0x00000010)<< 4)
#define MBOX_28_124_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields mbox_28_11	 */
#define MBOX_28_114_F1_LE_WIDTH                                               1
#define MBOX_28_114_F1_LE_SHIFT                                               4
#define MBOX_28_114_F1_LE_MASK                                       0x00000008
#define MBOX_28_114_F1_LE_RD(src)                    (((src) & 0x00000008)<< 3)
#define MBOX_28_114_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*	 Fields mbox_28_10	 */
#define MBOX_28_104_F1_LE_WIDTH                                               1
#define MBOX_28_104_F1_LE_SHIFT                                               5
#define MBOX_28_104_F1_LE_MASK                                       0x00000004
#define MBOX_28_104_F1_LE_RD(src)                    (((src) & 0x00000004)<< 2)
#define MBOX_28_104_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*	 Fields mbox_28_9	 */
#define MBOX_28_94_F1_LE_WIDTH                                                1
#define MBOX_28_94_F1_LE_SHIFT                                                6
#define MBOX_28_94_F1_LE_MASK                                        0x00000002
#define MBOX_28_94_F1_LE_RD(src)                     (((src) & 0x00000002)<< 1)
#define MBOX_28_94_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*	 Fields mbox_28_8	 */
#define MBOX_28_84_F1_LE_WIDTH                                                1
#define MBOX_28_84_F1_LE_SHIFT                                                7
#define MBOX_28_84_F1_LE_MASK                                        0x00000001
#define MBOX_28_84_F1_LE_RD(src)                     (((src) & 0x00000001)<< 0)
#define MBOX_28_84_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*	 Fields mbox_28_7	 */
#define MBOX_28_74_F1_LE_WIDTH                                                1
#define MBOX_28_74_F1_LE_SHIFT                                                8
#define MBOX_28_74_F1_LE_MASK                                        0x00008000
#define MBOX_28_74_F1_LE_RD(src)                   (((src) & 0x00008000) >> 15)
#define MBOX_28_74_F1_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*	 Fields mbox_28_6	 */
#define MBOX_28_64_F1_LE_WIDTH                                                1
#define MBOX_28_64_F1_LE_SHIFT                                                9
#define MBOX_28_64_F1_LE_MASK                                        0x00004000
#define MBOX_28_64_F1_LE_RD(src)                   (((src) & 0x00004000) >> 14)
#define MBOX_28_64_F1_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*	 Fields mbox_28_5	 */
#define MBOX_28_54_F1_LE_WIDTH                                                1
#define MBOX_28_54_F1_LE_SHIFT                                               10
#define MBOX_28_54_F1_LE_MASK                                        0x00002000
#define MBOX_28_54_F1_LE_RD(src)                   (((src) & 0x00002000) >> 13)
#define MBOX_28_54_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*	 Fields mbox_28_4	 */
#define MBOX_28_44_F1_LE_WIDTH                                                1
#define MBOX_28_44_F1_LE_SHIFT                                               11
#define MBOX_28_44_F1_LE_MASK                                        0x00001000
#define MBOX_28_44_F1_LE_RD(src)                   (((src) & 0x00001000) >> 12)
#define MBOX_28_44_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*	 Fields mbox_28_3	 */
#define MBOX_28_34_F1_LE_WIDTH                                                1
#define MBOX_28_34_F1_LE_SHIFT                                               12
#define MBOX_28_34_F1_LE_MASK                                        0x00000800
#define MBOX_28_34_F1_LE_RD(src)                   (((src) & 0x00000800) >> 11)
#define MBOX_28_34_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*	 Fields mbox_28_2	 */
#define MBOX_28_24_F1_LE_WIDTH                                                1
#define MBOX_28_24_F1_LE_SHIFT                                               13
#define MBOX_28_24_F1_LE_MASK                                        0x00000400
#define MBOX_28_24_F1_LE_RD(src)                   (((src) & 0x00000400) >> 10)
#define MBOX_28_24_F1_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*	 Fields mbox_28_1	 */
#define MBOX_28_14_F1_LE_WIDTH                                                1
#define MBOX_28_14_F1_LE_SHIFT                                               14
#define MBOX_28_14_F1_LE_MASK                                        0x00000200
#define MBOX_28_14_F1_LE_RD(src)                    (((src) & 0x00000200) >> 9)
#define MBOX_28_14_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*	 Fields mbox_28_0	 */
#define MBOX_28_04_F1_LE_WIDTH                                                1
#define MBOX_28_04_F1_LE_SHIFT                                               15
#define MBOX_28_04_F1_LE_MASK                                        0x00000100
#define MBOX_28_04_F1_LE_RD(src)                    (((src) & 0x00000100) >> 8)
#define MBOX_28_04_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*	 Fields mbox_29_15	 */
#define MBOX_29_154_F1_LE_WIDTH                                               1
#define MBOX_29_154_F1_LE_SHIFT                                              16
#define MBOX_29_154_F1_LE_MASK                                       0x00800000
#define MBOX_29_154_F1_LE_RD(src)                  (((src) & 0x00800000) >> 23)
#define MBOX_29_154_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*	 Fields mbox_29_14	 */
#define MBOX_29_144_F1_LE_WIDTH                                               1
#define MBOX_29_144_F1_LE_SHIFT                                              17
#define MBOX_29_144_F1_LE_MASK                                       0x00400000
#define MBOX_29_144_F1_LE_RD(src)                  (((src) & 0x00400000) >> 22)
#define MBOX_29_144_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*	 Fields mbox_29_13	 */
#define MBOX_29_134_F1_LE_WIDTH                                               1
#define MBOX_29_134_F1_LE_SHIFT                                              18
#define MBOX_29_134_F1_LE_MASK                                       0x00200000
#define MBOX_29_134_F1_LE_RD(src)                  (((src) & 0x00200000) >> 21)
#define MBOX_29_134_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*	 Fields mbox_29_12	 */
#define MBOX_29_124_F1_LE_WIDTH                                               1
#define MBOX_29_124_F1_LE_SHIFT                                              19
#define MBOX_29_124_F1_LE_MASK                                       0x00100000
#define MBOX_29_124_F1_LE_RD(src)                  (((src) & 0x00100000) >> 20)
#define MBOX_29_124_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields mbox_29_11	 */
#define MBOX_29_114_F1_LE_WIDTH                                               1
#define MBOX_29_114_F1_LE_SHIFT                                              20
#define MBOX_29_114_F1_LE_MASK                                       0x00080000
#define MBOX_29_114_F1_LE_RD(src)                  (((src) & 0x00080000) >> 19)
#define MBOX_29_114_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*	 Fields mbox_29_10	 */
#define MBOX_29_104_F1_LE_WIDTH                                               1
#define MBOX_29_104_F1_LE_SHIFT                                              21
#define MBOX_29_104_F1_LE_MASK                                       0x00040000
#define MBOX_29_104_F1_LE_RD(src)                  (((src) & 0x00040000) >> 18)
#define MBOX_29_104_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*	 Fields mbox_29_9	 */
#define MBOX_29_94_F1_LE_WIDTH                                                1
#define MBOX_29_94_F1_LE_SHIFT                                               22
#define MBOX_29_94_F1_LE_MASK                                        0x00020000
#define MBOX_29_94_F1_LE_RD(src)                   (((src) & 0x00020000) >> 17)
#define MBOX_29_94_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*	 Fields mbox_29_8	 */
#define MBOX_29_84_F1_LE_WIDTH                                                1
#define MBOX_29_84_F1_LE_SHIFT                                               23
#define MBOX_29_84_F1_LE_MASK                                        0x00010000
#define MBOX_29_84_F1_LE_RD(src)                   (((src) & 0x00010000) >> 16)
#define MBOX_29_84_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*	 Fields mbox_29_7	 */
#define MBOX_29_74_F1_LE_WIDTH                                                1
#define MBOX_29_74_F1_LE_SHIFT                                               24
#define MBOX_29_74_F1_LE_MASK                                        0x80000000
#define MBOX_29_74_F1_LE_RD(src)                   (((src) & 0x80000000) >> 31)
#define MBOX_29_74_F1_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields mbox_29_6	 */
#define MBOX_29_64_F1_LE_WIDTH                                                1
#define MBOX_29_64_F1_LE_SHIFT                                               25
#define MBOX_29_64_F1_LE_MASK                                        0x40000000
#define MBOX_29_64_F1_LE_RD(src)                   (((src) & 0x40000000) >> 30)
#define MBOX_29_64_F1_LE_SET(dst,src)                     ((dst)&~0x40000000)|\
				(((unsigned int)(src) << 30) & 0x40000000)

/*	 Fields mbox_29_5	 */
#define MBOX_29_54_F1_LE_WIDTH                                                1
#define MBOX_29_54_F1_LE_SHIFT                                               26
#define MBOX_29_54_F1_LE_MASK                                        0x20000000
#define MBOX_29_54_F1_LE_RD(src)                   (((src) & 0x20000000) >> 29)
#define MBOX_29_54_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields mbox_29_4	 */
#define MBOX_29_44_F1_LE_WIDTH                                                1
#define MBOX_29_44_F1_LE_SHIFT                                               27
#define MBOX_29_44_F1_LE_MASK                                        0x10000000
#define MBOX_29_44_F1_LE_RD(src)                   (((src) & 0x10000000) >> 28)
#define MBOX_29_44_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields mbox_29_3	 */
#define MBOX_29_34_F1_LE_WIDTH                                                1
#define MBOX_29_34_F1_LE_SHIFT                                               28
#define MBOX_29_34_F1_LE_MASK                                        0x08000000
#define MBOX_29_34_F1_LE_RD(src)                   (((src) & 0x08000000) >> 27)
#define MBOX_29_34_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields mbox_29_2	 */
#define MBOX_29_24_F1_LE_WIDTH                                                1
#define MBOX_29_24_F1_LE_SHIFT                                               29
#define MBOX_29_24_F1_LE_MASK                                        0x04000000
#define MBOX_29_24_F1_LE_RD(src)                   (((src) & 0x04000000) >> 26)
#define MBOX_29_24_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields mbox_29_1	 */
#define MBOX_29_14_F1_LE_WIDTH                                                1
#define MBOX_29_14_F1_LE_SHIFT                                               30
#define MBOX_29_14_F1_LE_MASK                                        0x02000000
#define MBOX_29_14_F1_LE_RD(src)                   (((src) & 0x02000000) >> 25)
#define MBOX_29_14_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields mbox_29_0	 */
#define MBOX_29_04_F1_LE_WIDTH                                                1
#define MBOX_29_04_F1_LE_SHIFT                                               31
#define MBOX_29_04_F1_LE_MASK                                        0x01000000
#define MBOX_29_04_F1_LE_RD(src)                   (((src) & 0x01000000) >> 24)
#define MBOX_29_04_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register csr_enq_status_15	*/

/*	 Fields mbox_30_15	 */
#define MBOX_30_155_F1_LE_WIDTH                                               1
#define MBOX_30_155_F1_LE_SHIFT                                               0
#define MBOX_30_155_F1_LE_MASK                                       0x00000080
#define MBOX_30_155_F1_LE_RD(src)                    (((src) & 0x00000080)<< 7)
#define MBOX_30_155_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields mbox_30_14	 */
#define MBOX_30_145_F1_LE_WIDTH                                               1
#define MBOX_30_145_F1_LE_SHIFT                                               1
#define MBOX_30_145_F1_LE_MASK                                       0x00000040
#define MBOX_30_145_F1_LE_RD(src)                    (((src) & 0x00000040)<< 6)
#define MBOX_30_145_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields mbox_30_13	 */
#define MBOX_30_135_F1_LE_WIDTH                                               1
#define MBOX_30_135_F1_LE_SHIFT                                               2
#define MBOX_30_135_F1_LE_MASK                                       0x00000020
#define MBOX_30_135_F1_LE_RD(src)                    (((src) & 0x00000020)<< 5)
#define MBOX_30_135_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*	 Fields mbox_30_12	 */
#define MBOX_30_125_F1_LE_WIDTH                                               1
#define MBOX_30_125_F1_LE_SHIFT                                               3
#define MBOX_30_125_F1_LE_MASK                                       0x00000010
#define MBOX_30_125_F1_LE_RD(src)                    (((src) & 0x00000010)<< 4)
#define MBOX_30_125_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields mbox_30_11	 */
#define MBOX_30_115_F1_LE_WIDTH                                               1
#define MBOX_30_115_F1_LE_SHIFT                                               4
#define MBOX_30_115_F1_LE_MASK                                       0x00000008
#define MBOX_30_115_F1_LE_RD(src)                    (((src) & 0x00000008)<< 3)
#define MBOX_30_115_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*	 Fields mbox_30_10	 */
#define MBOX_30_105_F1_LE_WIDTH                                               1
#define MBOX_30_105_F1_LE_SHIFT                                               5
#define MBOX_30_105_F1_LE_MASK                                       0x00000004
#define MBOX_30_105_F1_LE_RD(src)                    (((src) & 0x00000004)<< 2)
#define MBOX_30_105_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*	 Fields mbox_30_9	 */
#define MBOX_30_95_F1_LE_WIDTH                                                1
#define MBOX_30_95_F1_LE_SHIFT                                                6
#define MBOX_30_95_F1_LE_MASK                                        0x00000002
#define MBOX_30_95_F1_LE_RD(src)                     (((src) & 0x00000002)<< 1)
#define MBOX_30_95_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*	 Fields mbox_30_8	 */
#define MBOX_30_85_F1_LE_WIDTH                                                1
#define MBOX_30_85_F1_LE_SHIFT                                                7
#define MBOX_30_85_F1_LE_MASK                                        0x00000001
#define MBOX_30_85_F1_LE_RD(src)                     (((src) & 0x00000001)<< 0)
#define MBOX_30_85_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*	 Fields mbox_30_7	 */
#define MBOX_30_75_F1_LE_WIDTH                                                1
#define MBOX_30_75_F1_LE_SHIFT                                                8
#define MBOX_30_75_F1_LE_MASK                                        0x00008000
#define MBOX_30_75_F1_LE_RD(src)                   (((src) & 0x00008000) >> 15)
#define MBOX_30_75_F1_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*	 Fields mbox_30_6	 */
#define MBOX_30_65_F1_LE_WIDTH                                                1
#define MBOX_30_65_F1_LE_SHIFT                                                9
#define MBOX_30_65_F1_LE_MASK                                        0x00004000
#define MBOX_30_65_F1_LE_RD(src)                   (((src) & 0x00004000) >> 14)
#define MBOX_30_65_F1_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*	 Fields mbox_30_5	 */
#define MBOX_30_55_F1_LE_WIDTH                                                1
#define MBOX_30_55_F1_LE_SHIFT                                               10
#define MBOX_30_55_F1_LE_MASK                                        0x00002000
#define MBOX_30_55_F1_LE_RD(src)                   (((src) & 0x00002000) >> 13)
#define MBOX_30_55_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*	 Fields mbox_30_4	 */
#define MBOX_30_45_F1_LE_WIDTH                                                1
#define MBOX_30_45_F1_LE_SHIFT                                               11
#define MBOX_30_45_F1_LE_MASK                                        0x00001000
#define MBOX_30_45_F1_LE_RD(src)                   (((src) & 0x00001000) >> 12)
#define MBOX_30_45_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*	 Fields mbox_30_3	 */
#define MBOX_30_35_F1_LE_WIDTH                                                1
#define MBOX_30_35_F1_LE_SHIFT                                               12
#define MBOX_30_35_F1_LE_MASK                                        0x00000800
#define MBOX_30_35_F1_LE_RD(src)                   (((src) & 0x00000800) >> 11)
#define MBOX_30_35_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*	 Fields mbox_30_2	 */
#define MBOX_30_25_F1_LE_WIDTH                                                1
#define MBOX_30_25_F1_LE_SHIFT                                               13
#define MBOX_30_25_F1_LE_MASK                                        0x00000400
#define MBOX_30_25_F1_LE_RD(src)                   (((src) & 0x00000400) >> 10)
#define MBOX_30_25_F1_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*	 Fields mbox_30_1	 */
#define MBOX_30_15_F1_LE_WIDTH                                                1
#define MBOX_30_15_F1_LE_SHIFT                                               14
#define MBOX_30_15_F1_LE_MASK                                        0x00000200
#define MBOX_30_15_F1_LE_RD(src)                    (((src) & 0x00000200) >> 9)
#define MBOX_30_15_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*	 Fields mbox_30_0	 */
#define MBOX_30_05_F1_LE_WIDTH                                                1
#define MBOX_30_05_F1_LE_SHIFT                                               15
#define MBOX_30_05_F1_LE_MASK                                        0x00000100
#define MBOX_30_05_F1_LE_RD(src)                    (((src) & 0x00000100) >> 8)
#define MBOX_30_05_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*	 Fields mbox_31_15	 */
#define MBOX_31_155_F1_LE_WIDTH                                               1
#define MBOX_31_155_F1_LE_SHIFT                                              16
#define MBOX_31_155_F1_LE_MASK                                       0x00800000
#define MBOX_31_155_F1_LE_RD(src)                  (((src) & 0x00800000) >> 23)
#define MBOX_31_155_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*	 Fields mbox_31_14	 */
#define MBOX_31_145_F1_LE_WIDTH                                               1
#define MBOX_31_145_F1_LE_SHIFT                                              17
#define MBOX_31_145_F1_LE_MASK                                       0x00400000
#define MBOX_31_145_F1_LE_RD(src)                  (((src) & 0x00400000) >> 22)
#define MBOX_31_145_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*	 Fields mbox_31_13	 */
#define MBOX_31_135_F1_LE_WIDTH                                               1
#define MBOX_31_135_F1_LE_SHIFT                                              18
#define MBOX_31_135_F1_LE_MASK                                       0x00200000
#define MBOX_31_135_F1_LE_RD(src)                  (((src) & 0x00200000) >> 21)
#define MBOX_31_135_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*	 Fields mbox_31_12	 */
#define MBOX_31_125_F1_LE_WIDTH                                               1
#define MBOX_31_125_F1_LE_SHIFT                                              19
#define MBOX_31_125_F1_LE_MASK                                       0x00100000
#define MBOX_31_125_F1_LE_RD(src)                  (((src) & 0x00100000) >> 20)
#define MBOX_31_125_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields mbox_31_11	 */
#define MBOX_31_115_F1_LE_WIDTH                                               1
#define MBOX_31_115_F1_LE_SHIFT                                              20
#define MBOX_31_115_F1_LE_MASK                                       0x00080000
#define MBOX_31_115_F1_LE_RD(src)                  (((src) & 0x00080000) >> 19)
#define MBOX_31_115_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*	 Fields mbox_31_10	 */
#define MBOX_31_105_F1_LE_WIDTH                                               1
#define MBOX_31_105_F1_LE_SHIFT                                              21
#define MBOX_31_105_F1_LE_MASK                                       0x00040000
#define MBOX_31_105_F1_LE_RD(src)                  (((src) & 0x00040000) >> 18)
#define MBOX_31_105_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*	 Fields mbox_31_9	 */
#define MBOX_31_95_F1_LE_WIDTH                                                1
#define MBOX_31_95_F1_LE_SHIFT                                               22
#define MBOX_31_95_F1_LE_MASK                                        0x00020000
#define MBOX_31_95_F1_LE_RD(src)                   (((src) & 0x00020000) >> 17)
#define MBOX_31_95_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*	 Fields mbox_31_8	 */
#define MBOX_31_85_F1_LE_WIDTH                                                1
#define MBOX_31_85_F1_LE_SHIFT                                               23
#define MBOX_31_85_F1_LE_MASK                                        0x00010000
#define MBOX_31_85_F1_LE_RD(src)                   (((src) & 0x00010000) >> 16)
#define MBOX_31_85_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*	 Fields mbox_31_7	 */
#define MBOX_31_75_F1_LE_WIDTH                                                1
#define MBOX_31_75_F1_LE_SHIFT                                               24
#define MBOX_31_75_F1_LE_MASK                                        0x80000000
#define MBOX_31_75_F1_LE_RD(src)                   (((src) & 0x80000000) >> 31)
#define MBOX_31_75_F1_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields mbox_31_6	 */
#define MBOX_31_65_F1_LE_WIDTH                                                1
#define MBOX_31_65_F1_LE_SHIFT                                               25
#define MBOX_31_65_F1_LE_MASK                                        0x40000000
#define MBOX_31_65_F1_LE_RD(src)                   (((src) & 0x40000000) >> 30)
#define MBOX_31_65_F1_LE_SET(dst,src)                     ((dst)&~0x40000000)|\
				(((unsigned int)(src) << 30) & 0x40000000)

/*	 Fields mbox_31_5	 */
#define MBOX_31_55_F1_LE_WIDTH                                                1
#define MBOX_31_55_F1_LE_SHIFT                                               26
#define MBOX_31_55_F1_LE_MASK                                        0x20000000
#define MBOX_31_55_F1_LE_RD(src)                   (((src) & 0x20000000) >> 29)
#define MBOX_31_55_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields mbox_31_4	 */
#define MBOX_31_45_F1_LE_WIDTH                                                1
#define MBOX_31_45_F1_LE_SHIFT                                               27
#define MBOX_31_45_F1_LE_MASK                                        0x10000000
#define MBOX_31_45_F1_LE_RD(src)                   (((src) & 0x10000000) >> 28)
#define MBOX_31_45_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields mbox_31_3	 */
#define MBOX_31_35_F1_LE_WIDTH                                                1
#define MBOX_31_35_F1_LE_SHIFT                                               28
#define MBOX_31_35_F1_LE_MASK                                        0x08000000
#define MBOX_31_35_F1_LE_RD(src)                   (((src) & 0x08000000) >> 27)
#define MBOX_31_35_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields mbox_31_2	 */
#define MBOX_31_25_F1_LE_WIDTH                                                1
#define MBOX_31_25_F1_LE_SHIFT                                               29
#define MBOX_31_25_F1_LE_MASK                                        0x04000000
#define MBOX_31_25_F1_LE_RD(src)                   (((src) & 0x04000000) >> 26)
#define MBOX_31_25_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields mbox_31_1	 */
#define MBOX_31_15_F1_LE_WIDTH                                                1
#define MBOX_31_15_F1_LE_SHIFT                                               30
#define MBOX_31_15_F1_LE_MASK                                        0x02000000
#define MBOX_31_15_F1_LE_RD(src)                   (((src) & 0x02000000) >> 25)
#define MBOX_31_15_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields mbox_31_0	 */
#define MBOX_31_05_F1_LE_WIDTH                                                1
#define MBOX_31_05_F1_LE_SHIFT                                               31
#define MBOX_31_05_F1_LE_MASK                                        0x01000000
#define MBOX_31_05_F1_LE_RD(src)                   (((src) & 0x01000000) >> 24)
#define MBOX_31_05_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register qm_INT	*/

/*	 Fields queue_not_empty	 */
#define QUEUE_NOT_EMPTY_F1_LE_WIDTH                                           1
#define QUEUE_NOT_EMPTY_F1_LE_SHIFT                                           0
#define QUEUE_NOT_EMPTY_F1_LE_MASK                                   0x00000080
#define QUEUE_NOT_EMPTY_F1_LE_RD(src)                (((src) & 0x00000080)<< 7)
#define QUEUE_NOT_EMPTY_F1_LE_WR(src)          (((unsigned int)(src) >> 7) & 0x00000080)
#define QUEUE_NOT_EMPTY_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields acr_fifo_critical	 */
#define ACR_FIFO_CRITICAL_F1_LE_WIDTH                                         1
#define ACR_FIFO_CRITICAL_F1_LE_SHIFT                                        28
#define ACR_FIFO_CRITICAL_F1_LE_MASK                                 0x08000000
#define ACR_FIFO_CRITICAL_F1_LE_RD(src)            (((src) & 0x08000000) >> 27)
#define ACR_FIFO_CRITICAL_F1_LE_WR(src)       (((unsigned int)(src) << 27) & 0x08000000)
#define ACR_FIFO_CRITICAL_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields qpcore_acr_error	 */
#define QPCORE_ACR_ERROR_F1_LE_WIDTH                                          1
#define QPCORE_ACR_ERROR_F1_LE_SHIFT                                         29
#define QPCORE_ACR_ERROR_F1_LE_MASK                                  0x04000000
#define QPCORE_ACR_ERROR_F1_LE_RD(src)             (((src) & 0x04000000) >> 26)
#define QPCORE_ACR_ERROR_F1_LE_WR(src)        (((unsigned int)(src) << 26) & 0x04000000)
#define QPCORE_ACR_ERROR_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields deq_axi_error	 */
#define DEQ_AXI_ERROR_F1_LE_WIDTH                                             1
#define DEQ_AXI_ERROR_F1_LE_SHIFT                                            30
#define DEQ_AXI_ERROR_F1_LE_MASK                                     0x02000000
#define DEQ_AXI_ERROR_F1_LE_RD(src)                (((src) & 0x02000000) >> 25)
#define DEQ_AXI_ERROR_F1_LE_WR(src)           (((unsigned int)(src) << 25) & 0x02000000)
#define DEQ_AXI_ERROR_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields pbm_dec_error	 */
#define PBM_DEC_ERROR_F1_LE_WIDTH                                             1
#define PBM_DEC_ERROR_F1_LE_SHIFT                                            31
#define PBM_DEC_ERROR_F1_LE_MASK                                     0x01000000
#define PBM_DEC_ERROR_F1_LE_RD(src)                (((src) & 0x01000000) >> 24)
#define PBM_DEC_ERROR_F1_LE_WR(src)           (((unsigned int)(src) << 24) & 0x01000000)
#define PBM_DEC_ERROR_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register qm_interruptMask	*/

/*Mask Register Fields queue_not_emptyMask	 */
#define QUEUE_NOT_EMPTYMASK_F1_LE_WIDTH                                       1
#define QUEUE_NOT_EMPTYMASK_F1_LE_SHIFT                                       0
#define QUEUE_NOT_EMPTYMASK_F1_LE_MASK                               0x00000080
#define QUEUE_NOT_EMPTYMASK_F1_LE_RD(src)            (((src) & 0x00000080)<< 7)
#define QUEUE_NOT_EMPTYMASK_F1_LE_WR(src)      (((unsigned int)(src) >> 7) & 0x00000080)
#define QUEUE_NOT_EMPTYMASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*Mask Register Fields acr_fifo_criticalMask	 */
#define ACR_FIFO_CRITICALMASK_F1_LE_WIDTH                                     1
#define ACR_FIFO_CRITICALMASK_F1_LE_SHIFT                                    28
#define ACR_FIFO_CRITICALMASK_F1_LE_MASK                             0x08000000
#define ACR_FIFO_CRITICALMASK_F1_LE_RD(src)        (((src) & 0x08000000) >> 27)
#define ACR_FIFO_CRITICALMASK_F1_LE_WR(src)   (((unsigned int)(src) << 27) & 0x08000000)
#define ACR_FIFO_CRITICALMASK_F1_LE_SET(dst,src)                      ((dst)&~0x08000000)|\
			(((unsigned int)(src) << 27) & 0x08000000)

/*Mask Register Fields qpcore_acr_errorMask	 */
#define QPCORE_ACR_ERRORMASK_F1_LE_WIDTH                                      1
#define QPCORE_ACR_ERRORMASK_F1_LE_SHIFT                                     29
#define QPCORE_ACR_ERRORMASK_F1_LE_MASK                              0x04000000
#define QPCORE_ACR_ERRORMASK_F1_LE_RD(src)         (((src) & 0x04000000) >> 26)
#define QPCORE_ACR_ERRORMASK_F1_LE_WR(src)    (((unsigned int)(src) << 26) & 0x04000000)
#define QPCORE_ACR_ERRORMASK_F1_LE_SET(dst,src)                      ((dst)&~0x04000000)|\
			(((unsigned int)(src) << 26) & 0x04000000)

/*Mask Register Fields deq_axi_errorMask	 */
#define DEQ_AXI_ERRORMASK_F1_LE_WIDTH                                         1
#define DEQ_AXI_ERRORMASK_F1_LE_SHIFT                                        30
#define DEQ_AXI_ERRORMASK_F1_LE_MASK                                 0x02000000
#define DEQ_AXI_ERRORMASK_F1_LE_RD(src)            (((src) & 0x02000000) >> 25)
#define DEQ_AXI_ERRORMASK_F1_LE_WR(src)       (((unsigned int)(src) << 25) & 0x02000000)
#define DEQ_AXI_ERRORMASK_F1_LE_SET(dst,src)                      ((dst)&~0x02000000)|\
			(((unsigned int)(src) << 25) & 0x02000000)

/*Mask Register Fields pbm_dec_errorMask	 */
#define PBM_DEC_ERRORMASK_F1_LE_WIDTH                                         1
#define PBM_DEC_ERRORMASK_F1_LE_SHIFT                                        31
#define PBM_DEC_ERRORMASK_F1_LE_MASK                                 0x01000000
#define PBM_DEC_ERRORMASK_F1_LE_RD(src)            (((src) & 0x01000000) >> 24)
#define PBM_DEC_ERRORMASK_F1_LE_WR(src)       (((unsigned int)(src) << 24) & 0x01000000)
#define PBM_DEC_ERRORMASK_F1_LE_SET(dst,src)                      ((dst)&~0x01000000)|\
			(((unsigned int)(src) << 24) & 0x01000000)

/*	Register qm_SAB_qne_INT	*/

/*	 Fields interrupting_csr	 */
#define INTERRUPTING_CSR_F1_LE_WIDTH                                         32
#define INTERRUPTING_CSR_F1_LE_SHIFT                                         31
#define INTERRUPTING_CSR_F1_LE_MASK                                  0xffffffff
#define INTERRUPTING_CSR_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define INTERRUPTING_CSR_F1_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define INTERRUPTING_CSR_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register qm_SAB_qne_interruptMask	*/

/*Mask Register Fields interrupting_csrMask	 */
#define INTERRUPTING_CSRMASK_F9_LE_WIDTH                                     32
#define INTERRUPTING_CSRMASK_F9_LE_SHIFT                                     31
#define INTERRUPTING_CSRMASK_F9_LE_MASK                              0xffffffff
#define INTERRUPTING_CSRMASK_F9_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
	   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define INTERRUPTING_CSRMASK_F9_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   (((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
				(((unsigned int)(src) >> 24) & 0x000000ff)
#define INTERRUPTING_CSRMASK_F9_LE_SET(dst,src)  ((dst)&~0xffffffff)| \
 (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_pbm_errinf	*/

/*	 Fields pbm_config_err	 */
#define PBM_CONFIG_ERR_F1_LE_WIDTH                                            1
#define PBM_CONFIG_ERR_F1_LE_SHIFT                                           14
#define PBM_CONFIG_ERR_F1_LE_MASK                                    0x00000200
#define PBM_CONFIG_ERR_F1_LE_RD(src)                (((src) & 0x00000200) >> 9)
#define PBM_CONFIG_ERR_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*	 Fields pbm_decrement_err	 */
#define PBM_DECREMENT_ERR_F1_LE_WIDTH                                         1
#define PBM_DECREMENT_ERR_F1_LE_SHIFT                                        15
#define PBM_DECREMENT_ERR_F1_LE_MASK                                 0x00000100
#define PBM_DECREMENT_ERR_F1_LE_RD(src)             (((src) & 0x00000100) >> 8)
#define PBM_DECREMENT_ERR_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*	 Fields slave_id	 */
#define SLAVE_ID_F1_LE_WIDTH                                                  4
#define SLAVE_ID_F1_LE_SHIFT                                                 25
#define SLAVE_ID_F1_LE_MASK                                          0xc0030000
#define SLAVE_ID_F1_LE_RD(src)              	(((src) & 0xc0000000) >> 30) |\
				(((src) & 0x00030000) >> 14)
#define SLAVE_ID_F1_LE_SET(dst,src) ((dst)&~0xc0030000)| \
			(((unsigned int)(src) << 30) & 0xc0000000) | (((unsigned int)(src) << 14) & 0x00030000)

/*	 Fields PB_number	 */
#define PB_NUMBER_F1_LE_WIDTH                                                 6
#define PB_NUMBER_F1_LE_SHIFT                                                31
#define PB_NUMBER_F1_LE_MASK                                         0x3f000000
#define PB_NUMBER_F1_LE_RD(src)                    (((src) & 0x3f000000) >> 24)
#define PB_NUMBER_F1_LE_SET(dst,src)                     ((dst)&~0x3f000000)|\
				(((unsigned int)(src) << 24) & 0x3f000000)

/*	Register csr_msgrd_errinf	*/

/*	 Fields qpcore_was_disabled	 */
#define QPCORE_WAS_DISABLED_F1_LE_WIDTH                                       1
#define QPCORE_WAS_DISABLED_F1_LE_SHIFT                                       4
#define QPCORE_WAS_DISABLED_F1_LE_MASK                               0x00000008
#define QPCORE_WAS_DISABLED_F1_LE_RD(src)            (((src) & 0x00000008)<< 3)
#define QPCORE_WAS_DISABLED_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*	 Fields drop_code	 */
#define DROP_CODE_F1_LE_WIDTH                                                 3
#define DROP_CODE_F1_LE_SHIFT                                                 7
#define DROP_CODE_F1_LE_MASK                                         0x00000007
#define DROP_CODE_F1_LE_RD(src)                      (((src) & 0x00000007)<< 0)
#define DROP_CODE_F1_LE_SET(dst,src)                   ((dst) & ~0x00000007) |\
			 (((unsigned int)(src) >> 0) & 0x00000007)

/*	 Fields acr_qid	 */
#define ACR_QID_F1_LE_WIDTH                                                  10
#define ACR_QID_F1_LE_SHIFT                                                  17
#define ACR_QID_F1_LE_MASK                                           0x00c0ff00
#define ACR_QID_F1_LE_RD(src)               (((src) & 0x00c00000) >> 22) | \
				(((src) & 0x0000ff00) >> 6)
#define ACR_QID_F1_LE_SET(dst,src) ((dst) & ~0x00c0ff00)| \
	(((unsigned int)(src) << 22) & 0x00c00000)  | (((unsigned int)(src) << 22) & 0x00c00000)

/*	 Fields response_code	 */
#define RESPONSE_CODE_F1_LE_WIDTH                                             2
#define RESPONSE_CODE_F1_LE_SHIFT                                            21
#define RESPONSE_CODE_F1_LE_MASK                                     0x000c0000
#define RESPONSE_CODE_F1_LE_RD(src)                (((src) & 0x000c0000) >> 18)
#define RESPONSE_CODE_F1_LE_SET(dst,src)                  ((dst) & ~0x000c0000)| \
				(((unsigned int)(src) << 18) & 0x000c0000)

/*	 Fields qid	 */
#define QID_F1_LE_WIDTH                                                      10
#define QID_F1_LE_SHIFT                                                      31
#define QID_F1_LE_MASK                                               0xff030000
#define QID_F1_LE_RD(src)               	(((src) & 0xff000000) >> 24) |\
				(((src) & 0x00030000) >> 8)
#define QID_F1_LE_SET(dst,src) ((dst)&~0xff030000)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00030000)

/*	Register csr_qm_sab_proc0	*/

/*	 Fields interrupting_csr	 */
#define INTERRUPTING_CSR0_F1_LE_WIDTH                                        32
#define INTERRUPTING_CSR0_F1_LE_SHIFT                                        31
#define INTERRUPTING_CSR0_F1_LE_MASK                                 0xffffffff
#define INTERRUPTING_CSR0_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define INTERRUPTING_CSR0_F1_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define INTERRUPTING_CSR0_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_qm_sab_proc0Mask	*/

/*Mask Register Fields interrupting_csrMask	 */
#define INTERRUPTING_CSRMASK0_LE_WIDTH                                       32
#define INTERRUPTING_CSRMASK0_LE_SHIFT                                       31
#define INTERRUPTING_CSRMASK0_LE_MASK                                0xffffffff
#define INTERRUPTING_CSRMASK0_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
	   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define INTERRUPTING_CSRMASK0_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   (((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
				(((unsigned int)(src) >> 24) & 0x000000ff)
#define INTERRUPTING_CSRMASK0_LE_SET(dst,src)  ((dst)&~0xffffffff)| \
 (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_qm_sab_proc1	*/

/*	 Fields interrupting_csr	 */
#define INTERRUPTING_CSR1_F1_LE_WIDTH                                        32
#define INTERRUPTING_CSR1_F1_LE_SHIFT                                        31
#define INTERRUPTING_CSR1_F1_LE_MASK                                 0xffffffff
#define INTERRUPTING_CSR1_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define INTERRUPTING_CSR1_F1_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define INTERRUPTING_CSR1_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_qm_sab_proc1Mask	*/

/*Mask Register Fields interrupting_csrMask	 */
#define INTERRUPTING_CSRMASK1_LE_WIDTH                                       32
#define INTERRUPTING_CSRMASK1_LE_SHIFT                                       31
#define INTERRUPTING_CSRMASK1_LE_MASK                                0xffffffff
#define INTERRUPTING_CSRMASK1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
	   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define INTERRUPTING_CSRMASK1_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   (((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
				(((unsigned int)(src) >> 24) & 0x000000ff)
#define INTERRUPTING_CSRMASK1_LE_SET(dst,src)  ((dst)&~0xffffffff)| \
 (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_qm_sab_proc2	*/

/*	 Fields interrupting_csr	 */
#define INTERRUPTING_CSR2_F1_LE_WIDTH                                        32
#define INTERRUPTING_CSR2_F1_LE_SHIFT                                        31
#define INTERRUPTING_CSR2_F1_LE_MASK                                 0xffffffff
#define INTERRUPTING_CSR2_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define INTERRUPTING_CSR2_F1_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define INTERRUPTING_CSR2_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_qm_sab_proc2Mask	*/

/*Mask Register Fields interrupting_csrMask	 */
#define INTERRUPTING_CSRMASK2_LE_WIDTH                                       32
#define INTERRUPTING_CSRMASK2_LE_SHIFT                                       31
#define INTERRUPTING_CSRMASK2_LE_MASK                                0xffffffff
#define INTERRUPTING_CSRMASK2_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
	   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define INTERRUPTING_CSRMASK2_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   (((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
				(((unsigned int)(src) >> 24) & 0x000000ff)
#define INTERRUPTING_CSRMASK2_LE_SET(dst,src)  ((dst)&~0xffffffff)| \
 (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_qm_sab_proc3	*/

/*	 Fields interrupting_csr	 */
#define INTERRUPTING_CSR3_F1_LE_WIDTH                                        32
#define INTERRUPTING_CSR3_F1_LE_SHIFT                                        31
#define INTERRUPTING_CSR3_F1_LE_MASK                                 0xffffffff
#define INTERRUPTING_CSR3_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define INTERRUPTING_CSR3_F1_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define INTERRUPTING_CSR3_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_qm_sab_proc3Mask	*/

/*Mask Register Fields interrupting_csrMask	 */
#define INTERRUPTING_CSRMASK3_LE_WIDTH                                       32
#define INTERRUPTING_CSRMASK3_LE_SHIFT                                       31
#define INTERRUPTING_CSRMASK3_LE_MASK                                0xffffffff
#define INTERRUPTING_CSRMASK3_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
	   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define INTERRUPTING_CSRMASK3_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   (((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
				(((unsigned int)(src) >> 24) & 0x000000ff)
#define INTERRUPTING_CSRMASK3_LE_SET(dst,src)  ((dst)&~0xffffffff)| \
 (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_qm_sab_proc4	*/

/*	 Fields interrupting_csr	 */
#define INTERRUPTING_CSR4_F1_LE_WIDTH                                        32
#define INTERRUPTING_CSR4_F1_LE_SHIFT                                        31
#define INTERRUPTING_CSR4_F1_LE_MASK                                 0xffffffff
#define INTERRUPTING_CSR4_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define INTERRUPTING_CSR4_F1_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define INTERRUPTING_CSR4_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_qm_sab_proc4Mask	*/

/*Mask Register Fields interrupting_csrMask	 */
#define INTERRUPTING_CSRMASK4_LE_WIDTH                                       32
#define INTERRUPTING_CSRMASK4_LE_SHIFT                                       31
#define INTERRUPTING_CSRMASK4_LE_MASK                                0xffffffff
#define INTERRUPTING_CSRMASK4_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
	   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define INTERRUPTING_CSRMASK4_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   (((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
				(((unsigned int)(src) >> 24) & 0x000000ff)
#define INTERRUPTING_CSRMASK4_LE_SET(dst,src)  ((dst)&~0xffffffff)| \
 (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_qm_sab_proc5	*/

/*	 Fields interrupting_csr	 */
#define INTERRUPTING_CSR5_F1_LE_WIDTH                                        32
#define INTERRUPTING_CSR5_F1_LE_SHIFT                                        31
#define INTERRUPTING_CSR5_F1_LE_MASK                                 0xffffffff
#define INTERRUPTING_CSR5_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define INTERRUPTING_CSR5_F1_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define INTERRUPTING_CSR5_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_qm_sab_proc5Mask	*/

/*Mask Register Fields interrupting_csrMask	 */
#define INTERRUPTING_CSRMASK5_LE_WIDTH                                       32
#define INTERRUPTING_CSRMASK5_LE_SHIFT                                       31
#define INTERRUPTING_CSRMASK5_LE_MASK                                0xffffffff
#define INTERRUPTING_CSRMASK5_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
	   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define INTERRUPTING_CSRMASK5_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   (((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
				(((unsigned int)(src) >> 24) & 0x000000ff)
#define INTERRUPTING_CSRMASK5_LE_SET(dst,src)  ((dst)&~0xffffffff)| \
 (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_qm_sab_proc6	*/

/*	 Fields interrupting_csr	 */
#define INTERRUPTING_CSR6_F1_LE_WIDTH                                        32
#define INTERRUPTING_CSR6_F1_LE_SHIFT                                        31
#define INTERRUPTING_CSR6_F1_LE_MASK                                 0xffffffff
#define INTERRUPTING_CSR6_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define INTERRUPTING_CSR6_F1_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define INTERRUPTING_CSR6_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_qm_sab_proc6Mask	*/

/*Mask Register Fields interrupting_csrMask	 */
#define INTERRUPTING_CSRMASK6_LE_WIDTH                                       32
#define INTERRUPTING_CSRMASK6_LE_SHIFT                                       31
#define INTERRUPTING_CSRMASK6_LE_MASK                                0xffffffff
#define INTERRUPTING_CSRMASK6_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
	   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define INTERRUPTING_CSRMASK6_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   (((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
				(((unsigned int)(src) >> 24) & 0x000000ff)
#define INTERRUPTING_CSRMASK6_LE_SET(dst,src)  ((dst)&~0xffffffff)| \
 (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_qm_sab_proc7	*/

/*	 Fields interrupting_csr	 */
#define INTERRUPTING_CSR7_F1_LE_WIDTH                                        32
#define INTERRUPTING_CSR7_F1_LE_SHIFT                                        31
#define INTERRUPTING_CSR7_F1_LE_MASK                                 0xffffffff
#define INTERRUPTING_CSR7_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define INTERRUPTING_CSR7_F1_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define INTERRUPTING_CSR7_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_qm_sab_proc7Mask	*/

/*Mask Register Fields interrupting_csrMask	 */
#define INTERRUPTING_CSRMASK7_LE_WIDTH                                       32
#define INTERRUPTING_CSRMASK7_LE_SHIFT                                       31
#define INTERRUPTING_CSRMASK7_LE_MASK                                0xffffffff
#define INTERRUPTING_CSRMASK7_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
	   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define INTERRUPTING_CSRMASK7_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   (((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
				(((unsigned int)(src) >> 24) & 0x000000ff)
#define INTERRUPTING_CSRMASK7_LE_SET(dst,src)  ((dst)&~0xffffffff)| \
 (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_qm_mbox_ne_int_mode	*/

/*	 Fields mbox_0_31	 */
#define MBOX_0_31_F1_LE_WIDTH                                                32
#define MBOX_0_31_F1_LE_SHIFT                                                31
#define MBOX_0_31_F1_LE_MASK                                         0xffffffff
#define MBOX_0_31_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define MBOX_0_31_F1_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define MBOX_0_31_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_qm_mbox_ne	*/

/*	 Fields mbox_0_not_empty	 */
#define MBOX_0_NOT_EMPTY_F1_LE_WIDTH                                          1
#define MBOX_0_NOT_EMPTY_F1_LE_SHIFT                                          0
#define MBOX_0_NOT_EMPTY_F1_LE_MASK                                  0x00000080
#define MBOX_0_NOT_EMPTY_F1_LE_RD(src)               (((src) & 0x00000080)<< 7)
#define MBOX_0_NOT_EMPTY_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields mbox_1_not_empty	 */
#define MBOX_1_NOT_EMPTY_F1_LE_WIDTH                                          1
#define MBOX_1_NOT_EMPTY_F1_LE_SHIFT                                          1
#define MBOX_1_NOT_EMPTY_F1_LE_MASK                                  0x00000040
#define MBOX_1_NOT_EMPTY_F1_LE_RD(src)               (((src) & 0x00000040)<< 6)
#define MBOX_1_NOT_EMPTY_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields mbox_2_not_empty	 */
#define MBOX_2_NOT_EMPTY_F1_LE_WIDTH                                          1
#define MBOX_2_NOT_EMPTY_F1_LE_SHIFT                                          2
#define MBOX_2_NOT_EMPTY_F1_LE_MASK                                  0x00000020
#define MBOX_2_NOT_EMPTY_F1_LE_RD(src)               (((src) & 0x00000020)<< 5)
#define MBOX_2_NOT_EMPTY_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*	 Fields mbox_3_not_empty	 */
#define MBOX_3_NOT_EMPTY_F1_LE_WIDTH                                          1
#define MBOX_3_NOT_EMPTY_F1_LE_SHIFT                                          3
#define MBOX_3_NOT_EMPTY_F1_LE_MASK                                  0x00000010
#define MBOX_3_NOT_EMPTY_F1_LE_RD(src)               (((src) & 0x00000010)<< 4)
#define MBOX_3_NOT_EMPTY_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields mbox_4_not_empty	 */
#define MBOX_4_NOT_EMPTY_F1_LE_WIDTH                                          1
#define MBOX_4_NOT_EMPTY_F1_LE_SHIFT                                          4
#define MBOX_4_NOT_EMPTY_F1_LE_MASK                                  0x00000008
#define MBOX_4_NOT_EMPTY_F1_LE_RD(src)               (((src) & 0x00000008)<< 3)
#define MBOX_4_NOT_EMPTY_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*	 Fields mbox_5_not_empty	 */
#define MBOX_5_NOT_EMPTY_F1_LE_WIDTH                                          1
#define MBOX_5_NOT_EMPTY_F1_LE_SHIFT                                          5
#define MBOX_5_NOT_EMPTY_F1_LE_MASK                                  0x00000004
#define MBOX_5_NOT_EMPTY_F1_LE_RD(src)               (((src) & 0x00000004)<< 2)
#define MBOX_5_NOT_EMPTY_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*	 Fields mbox_6_not_empty	 */
#define MBOX_6_NOT_EMPTY_F1_LE_WIDTH                                          1
#define MBOX_6_NOT_EMPTY_F1_LE_SHIFT                                          6
#define MBOX_6_NOT_EMPTY_F1_LE_MASK                                  0x00000002
#define MBOX_6_NOT_EMPTY_F1_LE_RD(src)               (((src) & 0x00000002)<< 1)
#define MBOX_6_NOT_EMPTY_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*	 Fields mbox_7_not_empty	 */
#define MBOX_7_NOT_EMPTY_F1_LE_WIDTH                                          1
#define MBOX_7_NOT_EMPTY_F1_LE_SHIFT                                          7
#define MBOX_7_NOT_EMPTY_F1_LE_MASK                                  0x00000001
#define MBOX_7_NOT_EMPTY_F1_LE_RD(src)               (((src) & 0x00000001)<< 0)
#define MBOX_7_NOT_EMPTY_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*	 Fields mbox_8_not_empty	 */
#define MBOX_8_NOT_EMPTY_F1_LE_WIDTH                                          1
#define MBOX_8_NOT_EMPTY_F1_LE_SHIFT                                          8
#define MBOX_8_NOT_EMPTY_F1_LE_MASK                                  0x00008000
#define MBOX_8_NOT_EMPTY_F1_LE_RD(src)             (((src) & 0x00008000) >> 15)
#define MBOX_8_NOT_EMPTY_F1_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*	 Fields mbox_9_not_empty	 */
#define MBOX_9_NOT_EMPTY_F1_LE_WIDTH                                          1
#define MBOX_9_NOT_EMPTY_F1_LE_SHIFT                                          9
#define MBOX_9_NOT_EMPTY_F1_LE_MASK                                  0x00004000
#define MBOX_9_NOT_EMPTY_F1_LE_RD(src)             (((src) & 0x00004000) >> 14)
#define MBOX_9_NOT_EMPTY_F1_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*	 Fields mbox_10_not_empty	 */
#define MBOX_10_NOT_EMPTY_F1_LE_WIDTH                                         1
#define MBOX_10_NOT_EMPTY_F1_LE_SHIFT                                        10
#define MBOX_10_NOT_EMPTY_F1_LE_MASK                                 0x00002000
#define MBOX_10_NOT_EMPTY_F1_LE_RD(src)            (((src) & 0x00002000) >> 13)
#define MBOX_10_NOT_EMPTY_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*	 Fields mbox_11_not_empty	 */
#define MBOX_11_NOT_EMPTY_F1_LE_WIDTH                                         1
#define MBOX_11_NOT_EMPTY_F1_LE_SHIFT                                        11
#define MBOX_11_NOT_EMPTY_F1_LE_MASK                                 0x00001000
#define MBOX_11_NOT_EMPTY_F1_LE_RD(src)            (((src) & 0x00001000) >> 12)
#define MBOX_11_NOT_EMPTY_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*	 Fields mbox_12_not_empty	 */
#define MBOX_12_NOT_EMPTY_F1_LE_WIDTH                                         1
#define MBOX_12_NOT_EMPTY_F1_LE_SHIFT                                        12
#define MBOX_12_NOT_EMPTY_F1_LE_MASK                                 0x00000800
#define MBOX_12_NOT_EMPTY_F1_LE_RD(src)            (((src) & 0x00000800) >> 11)
#define MBOX_12_NOT_EMPTY_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*	 Fields mbox_13_not_empty	 */
#define MBOX_13_NOT_EMPTY_F1_LE_WIDTH                                         1
#define MBOX_13_NOT_EMPTY_F1_LE_SHIFT                                        13
#define MBOX_13_NOT_EMPTY_F1_LE_MASK                                 0x00000400
#define MBOX_13_NOT_EMPTY_F1_LE_RD(src)            (((src) & 0x00000400) >> 10)
#define MBOX_13_NOT_EMPTY_F1_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*	 Fields mbox_14_not_empty	 */
#define MBOX_14_NOT_EMPTY_F1_LE_WIDTH                                         1
#define MBOX_14_NOT_EMPTY_F1_LE_SHIFT                                        14
#define MBOX_14_NOT_EMPTY_F1_LE_MASK                                 0x00000200
#define MBOX_14_NOT_EMPTY_F1_LE_RD(src)             (((src) & 0x00000200) >> 9)
#define MBOX_14_NOT_EMPTY_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*	 Fields mbox_15_not_empty	 */
#define MBOX_15_NOT_EMPTY_F1_LE_WIDTH                                         1
#define MBOX_15_NOT_EMPTY_F1_LE_SHIFT                                        15
#define MBOX_15_NOT_EMPTY_F1_LE_MASK                                 0x00000100
#define MBOX_15_NOT_EMPTY_F1_LE_RD(src)             (((src) & 0x00000100) >> 8)
#define MBOX_15_NOT_EMPTY_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*	 Fields mbox_16_not_empty	 */
#define MBOX_16_NOT_EMPTY_F1_LE_WIDTH                                         1
#define MBOX_16_NOT_EMPTY_F1_LE_SHIFT                                        16
#define MBOX_16_NOT_EMPTY_F1_LE_MASK                                 0x00800000
#define MBOX_16_NOT_EMPTY_F1_LE_RD(src)            (((src) & 0x00800000) >> 23)
#define MBOX_16_NOT_EMPTY_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*	 Fields mbox_17_not_empty	 */
#define MBOX_17_NOT_EMPTY_F1_LE_WIDTH                                         1
#define MBOX_17_NOT_EMPTY_F1_LE_SHIFT                                        17
#define MBOX_17_NOT_EMPTY_F1_LE_MASK                                 0x00400000
#define MBOX_17_NOT_EMPTY_F1_LE_RD(src)            (((src) & 0x00400000) >> 22)
#define MBOX_17_NOT_EMPTY_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*	 Fields mbox_18_not_empty	 */
#define MBOX_18_NOT_EMPTY_F1_LE_WIDTH                                         1
#define MBOX_18_NOT_EMPTY_F1_LE_SHIFT                                        18
#define MBOX_18_NOT_EMPTY_F1_LE_MASK                                 0x00200000
#define MBOX_18_NOT_EMPTY_F1_LE_RD(src)            (((src) & 0x00200000) >> 21)
#define MBOX_18_NOT_EMPTY_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*	 Fields mbox_19_not_empty	 */
#define MBOX_19_NOT_EMPTY_F1_LE_WIDTH                                         1
#define MBOX_19_NOT_EMPTY_F1_LE_SHIFT                                        19
#define MBOX_19_NOT_EMPTY_F1_LE_MASK                                 0x00100000
#define MBOX_19_NOT_EMPTY_F1_LE_RD(src)            (((src) & 0x00100000) >> 20)
#define MBOX_19_NOT_EMPTY_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields mbox_20_not_empty	 */
#define MBOX_20_NOT_EMPTY_F1_LE_WIDTH                                         1
#define MBOX_20_NOT_EMPTY_F1_LE_SHIFT                                        20
#define MBOX_20_NOT_EMPTY_F1_LE_MASK                                 0x00080000
#define MBOX_20_NOT_EMPTY_F1_LE_RD(src)            (((src) & 0x00080000) >> 19)
#define MBOX_20_NOT_EMPTY_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*	 Fields mbox_21_not_empty	 */
#define MBOX_21_NOT_EMPTY_F1_LE_WIDTH                                         1
#define MBOX_21_NOT_EMPTY_F1_LE_SHIFT                                        21
#define MBOX_21_NOT_EMPTY_F1_LE_MASK                                 0x00040000
#define MBOX_21_NOT_EMPTY_F1_LE_RD(src)            (((src) & 0x00040000) >> 18)
#define MBOX_21_NOT_EMPTY_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*	 Fields mbox_22_not_empty	 */
#define MBOX_22_NOT_EMPTY_F1_LE_WIDTH                                         1
#define MBOX_22_NOT_EMPTY_F1_LE_SHIFT                                        22
#define MBOX_22_NOT_EMPTY_F1_LE_MASK                                 0x00020000
#define MBOX_22_NOT_EMPTY_F1_LE_RD(src)            (((src) & 0x00020000) >> 17)
#define MBOX_22_NOT_EMPTY_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*	 Fields mbox_23_not_empty	 */
#define MBOX_23_NOT_EMPTY_F1_LE_WIDTH                                         1
#define MBOX_23_NOT_EMPTY_F1_LE_SHIFT                                        23
#define MBOX_23_NOT_EMPTY_F1_LE_MASK                                 0x00010000
#define MBOX_23_NOT_EMPTY_F1_LE_RD(src)            (((src) & 0x00010000) >> 16)
#define MBOX_23_NOT_EMPTY_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*	 Fields mbox_24_not_empty	 */
#define MBOX_24_NOT_EMPTY_F1_LE_WIDTH                                         1
#define MBOX_24_NOT_EMPTY_F1_LE_SHIFT                                        24
#define MBOX_24_NOT_EMPTY_F1_LE_MASK                                 0x80000000
#define MBOX_24_NOT_EMPTY_F1_LE_RD(src)            (((src) & 0x80000000) >> 31)
#define MBOX_24_NOT_EMPTY_F1_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields mbox_25_not_empty	 */
#define MBOX_25_NOT_EMPTY_F1_LE_WIDTH                                         1
#define MBOX_25_NOT_EMPTY_F1_LE_SHIFT                                        25
#define MBOX_25_NOT_EMPTY_F1_LE_MASK                                 0x40000000
#define MBOX_25_NOT_EMPTY_F1_LE_RD(src)            (((src) & 0x40000000) >> 30)
#define MBOX_25_NOT_EMPTY_F1_LE_SET(dst,src)                     ((dst)&~0x40000000)|\
				(((unsigned int)(src) << 30) & 0x40000000)

/*	 Fields mbox_26_not_empty	 */
#define MBOX_26_NOT_EMPTY_F1_LE_WIDTH                                         1
#define MBOX_26_NOT_EMPTY_F1_LE_SHIFT                                        26
#define MBOX_26_NOT_EMPTY_F1_LE_MASK                                 0x20000000
#define MBOX_26_NOT_EMPTY_F1_LE_RD(src)            (((src) & 0x20000000) >> 29)
#define MBOX_26_NOT_EMPTY_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields mbox_27_not_empty	 */
#define MBOX_27_NOT_EMPTY_F1_LE_WIDTH                                         1
#define MBOX_27_NOT_EMPTY_F1_LE_SHIFT                                        27
#define MBOX_27_NOT_EMPTY_F1_LE_MASK                                 0x10000000
#define MBOX_27_NOT_EMPTY_F1_LE_RD(src)            (((src) & 0x10000000) >> 28)
#define MBOX_27_NOT_EMPTY_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields mbox_28_not_empty	 */
#define MBOX_28_NOT_EMPTY_F1_LE_WIDTH                                         1
#define MBOX_28_NOT_EMPTY_F1_LE_SHIFT                                        28
#define MBOX_28_NOT_EMPTY_F1_LE_MASK                                 0x08000000
#define MBOX_28_NOT_EMPTY_F1_LE_RD(src)            (((src) & 0x08000000) >> 27)
#define MBOX_28_NOT_EMPTY_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields mbox_29_not_empty	 */
#define MBOX_29_NOT_EMPTY_F1_LE_WIDTH                                         1
#define MBOX_29_NOT_EMPTY_F1_LE_SHIFT                                        29
#define MBOX_29_NOT_EMPTY_F1_LE_MASK                                 0x04000000
#define MBOX_29_NOT_EMPTY_F1_LE_RD(src)            (((src) & 0x04000000) >> 26)
#define MBOX_29_NOT_EMPTY_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields mbox_30_not_empty	 */
#define MBOX_30_NOT_EMPTY_F1_LE_WIDTH                                         1
#define MBOX_30_NOT_EMPTY_F1_LE_SHIFT                                        30
#define MBOX_30_NOT_EMPTY_F1_LE_MASK                                 0x02000000
#define MBOX_30_NOT_EMPTY_F1_LE_RD(src)            (((src) & 0x02000000) >> 25)
#define MBOX_30_NOT_EMPTY_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields mbox_31_not_empty	 */
#define MBOX_31_NOT_EMPTY_F1_LE_WIDTH                                         1
#define MBOX_31_NOT_EMPTY_F1_LE_SHIFT                                        31
#define MBOX_31_NOT_EMPTY_F1_LE_MASK                                 0x01000000
#define MBOX_31_NOT_EMPTY_F1_LE_RD(src)            (((src) & 0x01000000) >> 24)
#define MBOX_31_NOT_EMPTY_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register csr_proc_sab0	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL0_F4_LE_WIDTH                                          32
#define QUEUE_CRITICAL0_F4_LE_SHIFT                                          31
#define QUEUE_CRITICAL0_F4_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL0_F4_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL0_F4_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab1	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL1_F4_LE_WIDTH                                          32
#define QUEUE_CRITICAL1_F4_LE_SHIFT                                          31
#define QUEUE_CRITICAL1_F4_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL1_F4_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL1_F4_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab2	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL2_F3_LE_WIDTH                                          32
#define QUEUE_CRITICAL2_F3_LE_SHIFT                                          31
#define QUEUE_CRITICAL2_F3_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL2_F3_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL2_F3_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab3	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL3_F3_LE_WIDTH                                          32
#define QUEUE_CRITICAL3_F3_LE_SHIFT                                          31
#define QUEUE_CRITICAL3_F3_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL3_F3_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL3_F3_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab4	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL4_F3_LE_WIDTH                                          32
#define QUEUE_CRITICAL4_F3_LE_SHIFT                                          31
#define QUEUE_CRITICAL4_F3_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL4_F3_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL4_F3_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab5	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL5_F3_LE_WIDTH                                          32
#define QUEUE_CRITICAL5_F3_LE_SHIFT                                          31
#define QUEUE_CRITICAL5_F3_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL5_F3_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL5_F3_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab6	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL6_F3_LE_WIDTH                                          32
#define QUEUE_CRITICAL6_F3_LE_SHIFT                                          31
#define QUEUE_CRITICAL6_F3_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL6_F3_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL6_F3_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab7	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL7_F3_LE_WIDTH                                          32
#define QUEUE_CRITICAL7_F3_LE_SHIFT                                          31
#define QUEUE_CRITICAL7_F3_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL7_F3_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL7_F3_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab8	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL8_F3_LE_WIDTH                                          32
#define QUEUE_CRITICAL8_F3_LE_SHIFT                                          31
#define QUEUE_CRITICAL8_F3_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL8_F3_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL8_F3_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab9	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL9_F3_LE_WIDTH                                          32
#define QUEUE_CRITICAL9_F3_LE_SHIFT                                          31
#define QUEUE_CRITICAL9_F3_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL9_F3_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL9_F3_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab10	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL0_F5_LE_WIDTH                                          32
#define QUEUE_CRITICAL0_F5_LE_SHIFT                                          31
#define QUEUE_CRITICAL0_F5_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL0_F5_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL0_F5_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab11	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL1_F5_LE_WIDTH                                          32
#define QUEUE_CRITICAL1_F5_LE_SHIFT                                          31
#define QUEUE_CRITICAL1_F5_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL1_F5_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL1_F5_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab12	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL2_F4_LE_WIDTH                                          32
#define QUEUE_CRITICAL2_F4_LE_SHIFT                                          31
#define QUEUE_CRITICAL2_F4_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL2_F4_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL2_F4_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab13	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL3_F4_LE_WIDTH                                          32
#define QUEUE_CRITICAL3_F4_LE_SHIFT                                          31
#define QUEUE_CRITICAL3_F4_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL3_F4_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL3_F4_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab14	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL4_F4_LE_WIDTH                                          32
#define QUEUE_CRITICAL4_F4_LE_SHIFT                                          31
#define QUEUE_CRITICAL4_F4_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL4_F4_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL4_F4_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab15	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL5_F4_LE_WIDTH                                          32
#define QUEUE_CRITICAL5_F4_LE_SHIFT                                          31
#define QUEUE_CRITICAL5_F4_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL5_F4_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL5_F4_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab16	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL6_F4_LE_WIDTH                                          32
#define QUEUE_CRITICAL6_F4_LE_SHIFT                                          31
#define QUEUE_CRITICAL6_F4_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL6_F4_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL6_F4_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab17	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL7_F4_LE_WIDTH                                          32
#define QUEUE_CRITICAL7_F4_LE_SHIFT                                          31
#define QUEUE_CRITICAL7_F4_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL7_F4_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL7_F4_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab18	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL8_F4_LE_WIDTH                                          32
#define QUEUE_CRITICAL8_F4_LE_SHIFT                                          31
#define QUEUE_CRITICAL8_F4_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL8_F4_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL8_F4_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab19	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL9_F4_LE_WIDTH                                          32
#define QUEUE_CRITICAL9_F4_LE_SHIFT                                          31
#define QUEUE_CRITICAL9_F4_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL9_F4_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL9_F4_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab20	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL0_F6_LE_WIDTH                                          32
#define QUEUE_CRITICAL0_F6_LE_SHIFT                                          31
#define QUEUE_CRITICAL0_F6_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL0_F6_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL0_F6_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab21	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL1_F6_LE_WIDTH                                          32
#define QUEUE_CRITICAL1_F6_LE_SHIFT                                          31
#define QUEUE_CRITICAL1_F6_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL1_F6_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL1_F6_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab22	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL2_F5_LE_WIDTH                                          32
#define QUEUE_CRITICAL2_F5_LE_SHIFT                                          31
#define QUEUE_CRITICAL2_F5_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL2_F5_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL2_F5_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab23	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL3_F5_LE_WIDTH                                          32
#define QUEUE_CRITICAL3_F5_LE_SHIFT                                          31
#define QUEUE_CRITICAL3_F5_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL3_F5_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL3_F5_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab24	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL4_F5_LE_WIDTH                                          32
#define QUEUE_CRITICAL4_F5_LE_SHIFT                                          31
#define QUEUE_CRITICAL4_F5_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL4_F5_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL4_F5_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab25	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL5_F5_LE_WIDTH                                          32
#define QUEUE_CRITICAL5_F5_LE_SHIFT                                          31
#define QUEUE_CRITICAL5_F5_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL5_F5_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL5_F5_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab26	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL6_F5_LE_WIDTH                                          32
#define QUEUE_CRITICAL6_F5_LE_SHIFT                                          31
#define QUEUE_CRITICAL6_F5_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL6_F5_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL6_F5_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab27	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL7_F5_LE_WIDTH                                          32
#define QUEUE_CRITICAL7_F5_LE_SHIFT                                          31
#define QUEUE_CRITICAL7_F5_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL7_F5_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL7_F5_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab28	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL8_F5_LE_WIDTH                                          32
#define QUEUE_CRITICAL8_F5_LE_SHIFT                                          31
#define QUEUE_CRITICAL8_F5_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL8_F5_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL8_F5_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab29	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL9_F5_LE_WIDTH                                          32
#define QUEUE_CRITICAL9_F5_LE_SHIFT                                          31
#define QUEUE_CRITICAL9_F5_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL9_F5_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL9_F5_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab30	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL0_F7_LE_WIDTH                                          32
#define QUEUE_CRITICAL0_F7_LE_SHIFT                                          31
#define QUEUE_CRITICAL0_F7_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL0_F7_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL0_F7_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_proc_sab31	*/

/*	 Fields queue_critical	 */
#define QUEUE_CRITICAL1_F7_LE_WIDTH                                          32
#define QUEUE_CRITICAL1_F7_LE_SHIFT                                          31
#define QUEUE_CRITICAL1_F7_LE_MASK                                   0xffffffff
#define QUEUE_CRITICAL1_F7_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define QUEUE_CRITICAL1_F7_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_qm_stats_cfg	*/

/*	 Fields qid_enq_counter	 */
#define QID_ENQ_COUNTER_F1_LE_WIDTH                                          10
#define QID_ENQ_COUNTER_F1_LE_SHIFT                                          15
#define QID_ENQ_COUNTER_F1_LE_MASK                                   0x0000ff03
#define QID_ENQ_COUNTER_F1_LE_RD(src)                (((src) & 0x0000ff00 )>> 8) | \
				(((src) & 0x00000003) << 8)
#define QID_ENQ_COUNTER_F1_LE_WR(src)       (((unsigned int)(src) << 8) & 0x0000ff00) | \
				(((unsigned int)(src) >> 8) & 0x00000003)
#define QID_ENQ_COUNTER_F1_LE_SET(dst,src) ((dst) & ~0x0000ff03) | \
	(((unsigned int)(src) << 8) & 0x0000ff00) | (((unsigned int)(src) >> 8) & 0x00000003)

/*	 Fields qid_deq_counter	 */
#define QID_DEQ_COUNTER_F1_LE_WIDTH                                          10
#define QID_DEQ_COUNTER_F1_LE_SHIFT                                          31
#define QID_DEQ_COUNTER_F1_LE_MASK                                   0xff030000
#define QID_DEQ_COUNTER_F1_LE_RD(src)               	(((src) & 0xff000000) >> 24) |\
				(((src) & 0x00030000) >> 8)
#define QID_DEQ_COUNTER_F1_LE_WR(src)      	(((unsigned int)(src) << 24) & 0xff000000) |\
				(((unsigned int)(src) << 8) & 0x00030000)
#define QID_DEQ_COUNTER_F1_LE_SET(dst,src) ((dst)&~0xff030000)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00030000)

/*	Register csr_enq_statistics	*/

/*	 Fields enq_count	 */
#define ENQ_COUNT_F1_LE_WIDTH                                                32
#define ENQ_COUNT_F1_LE_SHIFT                                                31
#define ENQ_COUNT_F1_LE_MASK                                         0xffffffff
#define ENQ_COUNT_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define ENQ_COUNT_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_deq_statistics	*/

/*	 Fields deq_count	 */
#define DEQ_COUNT_F1_LE_WIDTH                                                32
#define DEQ_COUNT_F1_LE_SHIFT                                                31
#define DEQ_COUNT_F1_LE_MASK                                         0xffffffff
#define DEQ_COUNT_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define DEQ_COUNT_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_fifo_status	*/

/*	 Fields csr_epoch_overrun	 */
#define CSR_EPOCH_OVERRUN_F1_LE_WIDTH                                         1
#define CSR_EPOCH_OVERRUN_F1_LE_SHIFT                                         0
#define CSR_EPOCH_OVERRUN_F1_LE_MASK                                 0x00000080
#define CSR_EPOCH_OVERRUN_F1_LE_RD(src)              (((src) & 0x00000080)<< 7)
#define CSR_EPOCH_OVERRUN_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields csr_cut_busy	 */
#define CSR_CUT_BUSY_F1_LE_WIDTH                                              1
#define CSR_CUT_BUSY_F1_LE_SHIFT                                              1
#define CSR_CUT_BUSY_F1_LE_MASK                                      0x00000040
#define CSR_CUT_BUSY_F1_LE_RD(src)                   (((src) & 0x00000040)<< 6)
#define CSR_CUT_BUSY_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields csr_cut_toggle	 */
#define CSR_CUT_TOGGLE_F1_LE_WIDTH                                            1
#define CSR_CUT_TOGGLE_F1_LE_SHIFT                                            2
#define CSR_CUT_TOGGLE_F1_LE_MASK                                    0x00000020
#define CSR_CUT_TOGGLE_F1_LE_RD(src)                 (((src) & 0x00000020)<< 5)
#define CSR_CUT_TOGGLE_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*	 Fields csr_qpcore_active_process	 */
#define CSR_QPCORE_ACTIVE_PROCESS_F1_LE_WIDTH                                 5
#define CSR_QPCORE_ACTIVE_PROCESS_F1_LE_SHIFT                                 9
#define CSR_QPCORE_ACTIVE_PROCESS_F1_LE_MASK                         0x0000c007
#define CSR_QPCORE_ACTIVE_PROCESS_F1_LE_RD(src)               (((src) & 0x0000c000 )>> 14) | \
				(((src) & 0x00000007) << 2)
#define CSR_QPCORE_ACTIVE_PROCESS_F1_LE_SET(dst,src) ((dst) & ~0x0000c007) | \
	(((unsigned int)(src) << 14) & 0x0000c000) | (((unsigned int)(src) >> 2) & 0x00000007)

/*	 Fields csr_msgrd_fifo_stat	 */
#define CSR_MSGRD_FIFO_STAT_F1_LE_WIDTH                                       7
#define CSR_MSGRD_FIFO_STAT_F1_LE_SHIFT                                      19
#define CSR_MSGRD_FIFO_STAT_F1_LE_MASK                               0x00f00700
#define CSR_MSGRD_FIFO_STAT_F1_LE_RD(src)               (((src) & 0x00f00000) >> 20) | \
				(((src) & 0x00000700) >> 4)
#define CSR_MSGRD_FIFO_STAT_F1_LE_SET(dst,src) ((dst) & ~0x00f00700)| \
	(((unsigned int)(src) << 20) & 0x00f00000)  | (((unsigned int)(src) << 20) & 0x00f00000)

/*	 Fields csr_acr_mstr_cmd_level	 */
#define CSR_ACR_MSTR_CMD_LEVEL_F1_LE_WIDTH                                    4
#define CSR_ACR_MSTR_CMD_LEVEL_F1_LE_SHIFT                                   23
#define CSR_ACR_MSTR_CMD_LEVEL_F1_LE_MASK                            0x000f0000
#define CSR_ACR_MSTR_CMD_LEVEL_F1_LE_RD(src)       (((src) & 0x000f0000) >> 16)
#define CSR_ACR_MSTR_CMD_LEVEL_F1_LE_SET(dst,src)                  ((dst) & ~0x000f0000)| \
				(((unsigned int)(src) << 16) & 0x000f0000)

/*	 Fields csr_acr_allocated	 */
#define CSR_ACR_ALLOCATED_F1_LE_WIDTH                                         8
#define CSR_ACR_ALLOCATED_F1_LE_SHIFT                                        31
#define CSR_ACR_ALLOCATED_F1_LE_MASK                                 0xff000000
#define CSR_ACR_ALLOCATED_F1_LE_RD(src)            (((src) & 0xff000000) >> 24)
#define CSR_ACR_ALLOCATED_F1_LE_SET(dst,src)                     ((dst)&~0xff000000)|\
				(((unsigned int)(src) << 24) & 0xff000000)

/*	Register csr_acr_fifo_ctrl	*/

/*	 Fields critical_level	 */
#define CRITICAL_LEVEL_F1_LE_WIDTH                                            4
#define CRITICAL_LEVEL_F1_LE_SHIFT                                            3
#define CRITICAL_LEVEL_F1_LE_MASK                                    0x000000f0
#define CRITICAL_LEVEL_F1_LE_RD(src)                 (((src) & 0x000000f0)<< 4)
#define CRITICAL_LEVEL_F1_LE_WR(src)           (((unsigned int)(src) >> 4) & 0x000000f0)
#define CRITICAL_LEVEL_F1_LE_SET(dst,src)                   ((dst) & ~0x000000f0) |\
			 (((unsigned int)(src) >> 4) & 0x000000f0)

/*	 Fields critical_test	 */
#define CRITICAL_TEST_F1_LE_WIDTH                                             1
#define CRITICAL_TEST_F1_LE_SHIFT                                             7
#define CRITICAL_TEST_F1_LE_MASK                                     0x00000001
#define CRITICAL_TEST_F1_LE_RD(src)                  (((src) & 0x00000001)<< 0)
#define CRITICAL_TEST_F1_LE_WR(src)            (((unsigned int)(src) >> 0) & 0x00000001)
#define CRITICAL_TEST_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*	 Fields max_level	 */
#define MAX_LEVEL_F1_LE_WIDTH                                                 8
#define MAX_LEVEL_F1_LE_SHIFT                                                15
#define MAX_LEVEL_F1_LE_MASK                                         0x0000ff00
#define MAX_LEVEL_F1_LE_RD(src)                     (((src) & 0x0000ff00) >> 8)
#define MAX_LEVEL_F1_LE_WR(src)                (((unsigned int)(src) << 8) & 0x0000ff00)
#define MAX_LEVEL_F1_LE_SET(dst,src)                 ((dst) & ~0x0000ff00) |  \
				(((unsigned int)(src) << 8) & 0x0000ff00)

/*	 Fields qmi_hold_enable	 */
#define QMI_HOLD_ENABLE_F1_LE_WIDTH                                           1
#define QMI_HOLD_ENABLE_F1_LE_SHIFT                                          16
#define QMI_HOLD_ENABLE_F1_LE_MASK                                   0x00800000
#define QMI_HOLD_ENABLE_F1_LE_RD(src)              (((src) & 0x00800000) >> 23)
#define QMI_HOLD_ENABLE_F1_LE_WR(src)         (((unsigned int)(src) << 23) & 0x00800000)
#define QMI_HOLD_ENABLE_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*	 Fields qmi_hold_level	 */
#define QMI_HOLD_LEVEL_F1_LE_WIDTH                                            8
#define QMI_HOLD_LEVEL_F1_LE_SHIFT                                           31
#define QMI_HOLD_LEVEL_F1_LE_MASK                                    0xff000000
#define QMI_HOLD_LEVEL_F1_LE_RD(src)               (((src) & 0xff000000) >> 24)
#define QMI_HOLD_LEVEL_F1_LE_WR(src)          (((unsigned int)(src) << 24) & 0xff000000)
#define QMI_HOLD_LEVEL_F1_LE_SET(dst,src)                     ((dst)&~0xff000000)|\
				(((unsigned int)(src) << 24) & 0xff000000)

/*	Register csr_errq	*/

/*	 Fields unexpected_en	 */
#define UNEXPECTED_EN_F1_LE_WIDTH                                             1
#define UNEXPECTED_EN_F1_LE_SHIFT                                             0
#define UNEXPECTED_EN_F1_LE_MASK                                     0x00000080
#define UNEXPECTED_EN_F1_LE_RD(src)                  (((src) & 0x00000080)<< 7)
#define UNEXPECTED_EN_F1_LE_WR(src)            (((unsigned int)(src) >> 7) & 0x00000080)
#define UNEXPECTED_EN_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields unexpected_qid	 */
#define UNEXPECTED_QID_F1_LE_WIDTH                                           10
#define UNEXPECTED_QID_F1_LE_SHIFT                                           15
#define UNEXPECTED_QID_F1_LE_MASK                                    0x0000ff03
#define UNEXPECTED_QID_F1_LE_RD(src)                (((src) & 0x0000ff00 )>> 8) | \
				(((src) & 0x00000003) << 8)
#define UNEXPECTED_QID_F1_LE_WR(src)       (((unsigned int)(src) << 8) & 0x0000ff00) | \
				(((unsigned int)(src) >> 8) & 0x00000003)
#define UNEXPECTED_QID_F1_LE_SET(dst,src) ((dst) & ~0x0000ff03) | \
	(((unsigned int)(src) << 8) & 0x0000ff00) | (((unsigned int)(src) >> 8) & 0x00000003)

/*	 Fields expected_en	 */
#define EXPECTED_EN_F1_LE_WIDTH                                               1
#define EXPECTED_EN_F1_LE_SHIFT                                              16
#define EXPECTED_EN_F1_LE_MASK                                       0x00800000
#define EXPECTED_EN_F1_LE_RD(src)                  (((src) & 0x00800000) >> 23)
#define EXPECTED_EN_F1_LE_WR(src)             (((unsigned int)(src) << 23) & 0x00800000)
#define EXPECTED_EN_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*	 Fields expected_qid	 */
#define EXPECTED_QID_F1_LE_WIDTH                                             10
#define EXPECTED_QID_F1_LE_SHIFT                                             31
#define EXPECTED_QID_F1_LE_MASK                                      0xff030000
#define EXPECTED_QID_F1_LE_RD(src)               	(((src) & 0xff000000) >> 24) |\
				(((src) & 0x00030000) >> 8)
#define EXPECTED_QID_F1_LE_WR(src)      	(((unsigned int)(src) << 24) & 0xff000000) |\
				(((unsigned int)(src) << 8) & 0x00030000)
#define EXPECTED_QID_F1_LE_SET(dst,src) ((dst)&~0xff030000)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00030000)

/*	Register csr_qm_ram_margin	*/

/*	 Fields recomb_rmea	 */
#define RECOMB_RMEA_F1_LE_WIDTH                                               1
#define RECOMB_RMEA_F1_LE_SHIFT                                               2
#define RECOMB_RMEA_F1_LE_MASK                                       0x00000020
#define RECOMB_RMEA_F1_LE_RD(src)                    (((src) & 0x00000020)<< 5)
#define RECOMB_RMEA_F1_LE_WR(src)              (((unsigned int)(src) >> 5) & 0x00000020)
#define RECOMB_RMEA_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*	 Fields recomb_rmeb	 */
#define RECOMB_RMEB_F1_LE_WIDTH                                               1
#define RECOMB_RMEB_F1_LE_SHIFT                                               3
#define RECOMB_RMEB_F1_LE_MASK                                       0x00000010
#define RECOMB_RMEB_F1_LE_RD(src)                    (((src) & 0x00000010)<< 4)
#define RECOMB_RMEB_F1_LE_WR(src)              (((unsigned int)(src) >> 4) & 0x00000010)
#define RECOMB_RMEB_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields recomb_rma	 */
#define RECOMB_RMA_F1_LE_WIDTH                                                2
#define RECOMB_RMA_F1_LE_SHIFT                                                5
#define RECOMB_RMA_F1_LE_MASK                                        0x0000000c
#define RECOMB_RMA_F1_LE_RD(src)                     (((src) & 0x0000000c)<< 2)
#define RECOMB_RMA_F1_LE_WR(src)               (((unsigned int)(src) >> 2) & 0x0000000c)
#define RECOMB_RMA_F1_LE_SET(dst,src)                   ((dst) & ~0x0000000c) |\
			 (((unsigned int)(src) >> 2) & 0x0000000c)

/*	 Fields recomb_rmb	 */
#define RECOMB_RMB_F1_LE_WIDTH                                                2
#define RECOMB_RMB_F1_LE_SHIFT                                                7
#define RECOMB_RMB_F1_LE_MASK                                        0x00000003
#define RECOMB_RMB_F1_LE_RD(src)                     (((src) & 0x00000003)<< 0)
#define RECOMB_RMB_F1_LE_WR(src)               (((unsigned int)(src) >> 0) & 0x00000003)
#define RECOMB_RMB_F1_LE_SET(dst,src)                   ((dst) & ~0x00000003) |\
			 (((unsigned int)(src) >> 0) & 0x00000003)

/*	 Fields acr_rmea	 */
#define ACR_RMEA_F1_LE_WIDTH                                                  1
#define ACR_RMEA_F1_LE_SHIFT                                                 10
#define ACR_RMEA_F1_LE_MASK                                          0x00002000
#define ACR_RMEA_F1_LE_RD(src)                     (((src) & 0x00002000) >> 13)
#define ACR_RMEA_F1_LE_WR(src)                (((unsigned int)(src) << 13) & 0x00002000)
#define ACR_RMEA_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*	 Fields acr_rmeb	 */
#define ACR_RMEB_F1_LE_WIDTH                                                  1
#define ACR_RMEB_F1_LE_SHIFT                                                 11
#define ACR_RMEB_F1_LE_MASK                                          0x00001000
#define ACR_RMEB_F1_LE_RD(src)                     (((src) & 0x00001000) >> 12)
#define ACR_RMEB_F1_LE_WR(src)                (((unsigned int)(src) << 12) & 0x00001000)
#define ACR_RMEB_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*	 Fields acr_rma	 */
#define ACR_RMA_F1_LE_WIDTH                                                   2
#define ACR_RMA_F1_LE_SHIFT                                                  13
#define ACR_RMA_F1_LE_MASK                                           0x00000c00
#define ACR_RMA_F1_LE_RD(src)                      (((src) & 0x00000c00) >> 10)
#define ACR_RMA_F1_LE_WR(src)                 (((unsigned int)(src) << 10) & 0x00000c00)
#define ACR_RMA_F1_LE_SET(dst,src)                ((dst) & ~0x00000c00) |  \
				(((unsigned int)(src) << 10) & 0x00000c00)

/*	 Fields acr_rmb	 */
#define ACR_RMB_F1_LE_WIDTH                                                   2
#define ACR_RMB_F1_LE_SHIFT                                                  15
#define ACR_RMB_F1_LE_MASK                                           0x00000300
#define ACR_RMB_F1_LE_RD(src)                       (((src) & 0x00000300) >> 8)
#define ACR_RMB_F1_LE_WR(src)                  (((unsigned int)(src) << 8) & 0x00000300)
#define ACR_RMB_F1_LE_SET(dst,src)                 ((dst) & ~0x00000300) |  \
				(((unsigned int)(src) << 8) & 0x00000300)

/*	 Fields qstate_rmea	 */
#define QSTATE_RMEA_F1_LE_WIDTH                                               1
#define QSTATE_RMEA_F1_LE_SHIFT                                              18
#define QSTATE_RMEA_F1_LE_MASK                                       0x00200000
#define QSTATE_RMEA_F1_LE_RD(src)                  (((src) & 0x00200000) >> 21)
#define QSTATE_RMEA_F1_LE_WR(src)             (((unsigned int)(src) << 21) & 0x00200000)
#define QSTATE_RMEA_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*	 Fields qstate_rmeb	 */
#define QSTATE_RMEB_F1_LE_WIDTH                                               1
#define QSTATE_RMEB_F1_LE_SHIFT                                              19
#define QSTATE_RMEB_F1_LE_MASK                                       0x00100000
#define QSTATE_RMEB_F1_LE_RD(src)                  (((src) & 0x00100000) >> 20)
#define QSTATE_RMEB_F1_LE_WR(src)             (((unsigned int)(src) << 20) & 0x00100000)
#define QSTATE_RMEB_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields qstate_rma	 */
#define QSTATE_RMA_F1_LE_WIDTH                                                2
#define QSTATE_RMA_F1_LE_SHIFT                                               21
#define QSTATE_RMA_F1_LE_MASK                                        0x000c0000
#define QSTATE_RMA_F1_LE_RD(src)                   (((src) & 0x000c0000) >> 18)
#define QSTATE_RMA_F1_LE_WR(src)              (((unsigned int)(src) << 18) & 0x000c0000)
#define QSTATE_RMA_F1_LE_SET(dst,src)                  ((dst) & ~0x000c0000)| \
				(((unsigned int)(src) << 18) & 0x000c0000)

/*	 Fields qstate_rmb	 */
#define QSTATE_RMB_F1_LE_WIDTH                                                2
#define QSTATE_RMB_F1_LE_SHIFT                                               23
#define QSTATE_RMB_F1_LE_MASK                                        0x00030000
#define QSTATE_RMB_F1_LE_RD(src)                   (((src) & 0x00030000) >> 16)
#define QSTATE_RMB_F1_LE_WR(src)              (((unsigned int)(src) << 16) & 0x00030000)
#define QSTATE_RMB_F1_LE_SET(dst,src)                  ((dst) & ~0x00030000)| \
				(((unsigned int)(src) << 16) & 0x00030000)

/*	 Fields cstate_rmea	 */
#define CSTATE_RMEA_F1_LE_WIDTH                                               1
#define CSTATE_RMEA_F1_LE_SHIFT                                              26
#define CSTATE_RMEA_F1_LE_MASK                                       0x20000000
#define CSTATE_RMEA_F1_LE_RD(src)                  (((src) & 0x20000000) >> 29)
#define CSTATE_RMEA_F1_LE_WR(src)             (((unsigned int)(src) << 29) & 0x20000000)
#define CSTATE_RMEA_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields cstate_rmeb	 */
#define CSTATE_RMEB_F1_LE_WIDTH                                               1
#define CSTATE_RMEB_F1_LE_SHIFT                                              27
#define CSTATE_RMEB_F1_LE_MASK                                       0x10000000
#define CSTATE_RMEB_F1_LE_RD(src)                  (((src) & 0x10000000) >> 28)
#define CSTATE_RMEB_F1_LE_WR(src)             (((unsigned int)(src) << 28) & 0x10000000)
#define CSTATE_RMEB_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields cstate_rma	 */
#define CSTATE_RMA_F1_LE_WIDTH                                                2
#define CSTATE_RMA_F1_LE_SHIFT                                               29
#define CSTATE_RMA_F1_LE_MASK                                        0x0c000000
#define CSTATE_RMA_F1_LE_RD(src)                   (((src) & 0x0c000000) >> 26)
#define CSTATE_RMA_F1_LE_WR(src)              (((unsigned int)(src) << 26) & 0x0c000000)
#define CSTATE_RMA_F1_LE_SET(dst,src)                     ((dst)&~0x0c000000)|\
				(((unsigned int)(src) << 26) & 0x0c000000)

/*	 Fields cstate_rmb	 */
#define CSTATE_RMB_F1_LE_WIDTH                                                2
#define CSTATE_RMB_F1_LE_SHIFT                                               31
#define CSTATE_RMB_F1_LE_MASK                                        0x03000000
#define CSTATE_RMB_F1_LE_RD(src)                   (((src) & 0x03000000) >> 24)
#define CSTATE_RMB_F1_LE_WR(src)              (((unsigned int)(src) << 24) & 0x03000000)
#define CSTATE_RMB_F1_LE_SET(dst,src)                     ((dst)&~0x03000000)|\
				(((unsigned int)(src) << 24) & 0x03000000)

/*	Register csr_qm_testint0	*/

/*	 Fields mbox	 */
#define MBOX0_F1_LE_WIDTH                                                    32
#define MBOX0_F1_LE_SHIFT                                                    31
#define MBOX0_F1_LE_MASK                                             0xffffffff
#define MBOX0_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define MBOX0_F1_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define MBOX0_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_qm_testint1	*/

/*	 Fields sab_proc7	 */
#define SAB_PROC71_F1_LE_WIDTH                                                1
#define SAB_PROC71_F1_LE_SHIFT                                                0
#define SAB_PROC71_F1_LE_MASK                                        0x00000080
#define SAB_PROC71_F1_LE_RD(src)                     (((src) & 0x00000080)<< 7)
#define SAB_PROC71_F1_LE_WR(src)               (((unsigned int)(src) >> 7) & 0x00000080)
#define SAB_PROC71_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields sab_proc6	 */
#define SAB_PROC61_F1_LE_WIDTH                                                1
#define SAB_PROC61_F1_LE_SHIFT                                                1
#define SAB_PROC61_F1_LE_MASK                                        0x00000040
#define SAB_PROC61_F1_LE_RD(src)                     (((src) & 0x00000040)<< 6)
#define SAB_PROC61_F1_LE_WR(src)               (((unsigned int)(src) >> 6) & 0x00000040)
#define SAB_PROC61_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields sab_proc5	 */
#define SAB_PROC51_F1_LE_WIDTH                                                1
#define SAB_PROC51_F1_LE_SHIFT                                                2
#define SAB_PROC51_F1_LE_MASK                                        0x00000020
#define SAB_PROC51_F1_LE_RD(src)                     (((src) & 0x00000020)<< 5)
#define SAB_PROC51_F1_LE_WR(src)               (((unsigned int)(src) >> 5) & 0x00000020)
#define SAB_PROC51_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*	 Fields sab_proc4	 */
#define SAB_PROC41_F1_LE_WIDTH                                                1
#define SAB_PROC41_F1_LE_SHIFT                                                3
#define SAB_PROC41_F1_LE_MASK                                        0x00000010
#define SAB_PROC41_F1_LE_RD(src)                     (((src) & 0x00000010)<< 4)
#define SAB_PROC41_F1_LE_WR(src)               (((unsigned int)(src) >> 4) & 0x00000010)
#define SAB_PROC41_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields sab_proc3	 */
#define SAB_PROC31_F1_LE_WIDTH                                                1
#define SAB_PROC31_F1_LE_SHIFT                                                4
#define SAB_PROC31_F1_LE_MASK                                        0x00000008
#define SAB_PROC31_F1_LE_RD(src)                     (((src) & 0x00000008)<< 3)
#define SAB_PROC31_F1_LE_WR(src)               (((unsigned int)(src) >> 3) & 0x00000008)
#define SAB_PROC31_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*	 Fields sab_proc2	 */
#define SAB_PROC21_F1_LE_WIDTH                                                1
#define SAB_PROC21_F1_LE_SHIFT                                                5
#define SAB_PROC21_F1_LE_MASK                                        0x00000004
#define SAB_PROC21_F1_LE_RD(src)                     (((src) & 0x00000004)<< 2)
#define SAB_PROC21_F1_LE_WR(src)               (((unsigned int)(src) >> 2) & 0x00000004)
#define SAB_PROC21_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*	 Fields sab_proc1	 */
#define SAB_PROC11_F1_LE_WIDTH                                                1
#define SAB_PROC11_F1_LE_SHIFT                                                6
#define SAB_PROC11_F1_LE_MASK                                        0x00000002
#define SAB_PROC11_F1_LE_RD(src)                     (((src) & 0x00000002)<< 1)
#define SAB_PROC11_F1_LE_WR(src)               (((unsigned int)(src) >> 1) & 0x00000002)
#define SAB_PROC11_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*	 Fields sab_proc0	 */
#define SAB_PROC01_F1_LE_WIDTH                                                1
#define SAB_PROC01_F1_LE_SHIFT                                                7
#define SAB_PROC01_F1_LE_MASK                                        0x00000001
#define SAB_PROC01_F1_LE_RD(src)                     (((src) & 0x00000001)<< 0)
#define SAB_PROC01_F1_LE_WR(src)               (((unsigned int)(src) >> 0) & 0x00000001)
#define SAB_PROC01_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*	 Fields qm_int	 */
#define QM_INT1_F1_LE_WIDTH                                                   1
#define QM_INT1_F1_LE_SHIFT                                                  11
#define QM_INT1_F1_LE_MASK                                           0x00001000
#define QM_INT1_F1_LE_RD(src)                      (((src) & 0x00001000) >> 12)
#define QM_INT1_F1_LE_WR(src)                 (((unsigned int)(src) << 12) & 0x00001000)
#define QM_INT1_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*	 Fields ecc_sec	 */
#define ECC_SEC1_F1_LE_WIDTH                                                  6
#define ECC_SEC1_F1_LE_SHIFT                                                 21
#define ECC_SEC1_F1_LE_MASK                                          0x00fc0000
#define ECC_SEC1_F1_LE_RD(src)                     (((src) & 0x00fc0000) >> 18)
#define ECC_SEC1_F1_LE_WR(src)                (((unsigned int)(src) << 18) & 0x00fc0000)
#define ECC_SEC1_F1_LE_SET(dst,src)                  ((dst) & ~0x00fc0000)| \
				(((unsigned int)(src) << 18) & 0x00fc0000)

/*	 Fields ecc_ded	 */
#define ECC_DED1_F1_LE_WIDTH                                                  6
#define ECC_DED1_F1_LE_SHIFT                                                 31
#define ECC_DED1_F1_LE_MASK                                          0x3f000000
#define ECC_DED1_F1_LE_RD(src)                     (((src) & 0x3f000000) >> 24)
#define ECC_DED1_F1_LE_WR(src)                (((unsigned int)(src) << 24) & 0x3f000000)
#define ECC_DED1_F1_LE_SET(dst,src)                     ((dst)&~0x3f000000)|\
				(((unsigned int)(src) << 24) & 0x3f000000)

/*	Register csr_qmlite_pbn_map_0	*/

/*	 Fields slimpro_fpq0_mbox	 */
#define SLIMPRO_FPQ0_MBOX0_F1_LE_WIDTH                                        5
#define SLIMPRO_FPQ0_MBOX0_F1_LE_SHIFT                                        6
#define SLIMPRO_FPQ0_MBOX0_F1_LE_MASK                                0x0000003e
#define SLIMPRO_FPQ0_MBOX0_F1_LE_RD(src)             (((src) & 0x0000003e)<< 1)
#define SLIMPRO_FPQ0_MBOX0_F1_LE_WR(src)       (((unsigned int)(src) >> 1) & 0x0000003e)
#define SLIMPRO_FPQ0_MBOX0_F1_LE_SET(dst,src)                   ((dst) & ~0x0000003e) |\
			 (((unsigned int)(src) >> 1) & 0x0000003e)

/*	 Fields slimpro_wq0_mbox	 */
#define SLIMPRO_WQ0_MBOX0_F1_LE_WIDTH                                         5
#define SLIMPRO_WQ0_MBOX0_F1_LE_SHIFT                                        11
#define SLIMPRO_WQ0_MBOX0_F1_LE_MASK                                 0x0000f001
#define SLIMPRO_WQ0_MBOX0_F1_LE_RD(src)               (((src) & 0x0000f000 )>> 12) | \
				(((src) & 0x00000001) << 4)
#define SLIMPRO_WQ0_MBOX0_F1_LE_WR(src)      (((unsigned int)(src) << 12) & 0x0000f000) | \
				(((unsigned int)(src) >> 4) & 0x00000001)
#define SLIMPRO_WQ0_MBOX0_F1_LE_SET(dst,src) ((dst) & ~0x0000f001) | \
	(((unsigned int)(src) << 12) & 0x0000f000) | (((unsigned int)(src) >> 4) & 0x00000001)

/*	 Fields cop_fpq_mbox	 */
#define COP_FPQ_MBOX0_F1_LE_WIDTH                                             5
#define COP_FPQ_MBOX0_F1_LE_SHIFT                                            16
#define COP_FPQ_MBOX0_F1_LE_MASK                                     0x00800f00
#define COP_FPQ_MBOX0_F1_LE_RD(src)               (((src) & 0x00800000) >> 23) | \
				(((src) & 0x00000f00) >> 7)
#define COP_FPQ_MBOX0_F1_LE_WR(src)      (((unsigned int)(src) << 23) & 0x00800000) | \
				(((unsigned int)(src) << 7) & 0x00000f00)
#define COP_FPQ_MBOX0_F1_LE_SET(dst,src) ((dst) & ~0x00800f00)| \
	(((unsigned int)(src) << 23) & 0x00800000)  | (((unsigned int)(src) << 23) & 0x00800000)

/*	 Fields cop_wq_mbox	 */
#define COP_WQ_MBOX0_F1_LE_WIDTH                                              5
#define COP_WQ_MBOX0_F1_LE_SHIFT                                             21
#define COP_WQ_MBOX0_F1_LE_MASK                                      0x007c0000
#define COP_WQ_MBOX0_F1_LE_RD(src)                 (((src) & 0x007c0000) >> 18)
#define COP_WQ_MBOX0_F1_LE_WR(src)            (((unsigned int)(src) << 18) & 0x007c0000)
#define COP_WQ_MBOX0_F1_LE_SET(dst,src)                  ((dst) & ~0x007c0000)| \
				(((unsigned int)(src) << 18) & 0x007c0000)

/*	 Fields cpu_fpq_mbox	 */
#define CPU_FPQ_MBOX0_F1_LE_WIDTH                                             5
#define CPU_FPQ_MBOX0_F1_LE_SHIFT                                            26
#define CPU_FPQ_MBOX0_F1_LE_MASK                                     0xe0030000
#define CPU_FPQ_MBOX0_F1_LE_RD(src)              	(((src) & 0xe0000000) >> 29) |\
				(((src) & 0x00030000) >> 13)
#define CPU_FPQ_MBOX0_F1_LE_WR(src)     	(((unsigned int)(src) << 29) & 0xe0000000) |\
				(((unsigned int)(src) << 13) & 0x00030000)
#define CPU_FPQ_MBOX0_F1_LE_SET(dst,src) ((dst)&~0xe0030000)| \
			(((unsigned int)(src) << 29) & 0xe0000000) | (((unsigned int)(src) << 13) & 0x00030000)

/*	 Fields cpu_wq_mbox	 */
#define CPU_WQ_MBOX0_F1_LE_WIDTH                                              5
#define CPU_WQ_MBOX0_F1_LE_SHIFT                                             31
#define CPU_WQ_MBOX0_F1_LE_MASK                                      0x1f000000
#define CPU_WQ_MBOX0_F1_LE_RD(src)                 (((src) & 0x1f000000) >> 24)
#define CPU_WQ_MBOX0_F1_LE_WR(src)            (((unsigned int)(src) << 24) & 0x1f000000)
#define CPU_WQ_MBOX0_F1_LE_SET(dst,src)                     ((dst)&~0x1f000000)|\
				(((unsigned int)(src) << 24) & 0x1f000000)

/*	Register csr_qmlite_pbn_map_1	*/

/*	 Fields slimpro_fpq1_mbox	 */
#define SLIMPRO_FPQ1_MBOX1_F1_LE_WIDTH                                        5
#define SLIMPRO_FPQ1_MBOX1_F1_LE_SHIFT                                       26
#define SLIMPRO_FPQ1_MBOX1_F1_LE_MASK                                0xe0030000
#define SLIMPRO_FPQ1_MBOX1_F1_LE_RD(src)              	(((src) & 0xe0000000) >> 29) |\
				(((src) & 0x00030000) >> 13)
#define SLIMPRO_FPQ1_MBOX1_F1_LE_WR(src)     	(((unsigned int)(src) << 29) & 0xe0000000) |\
				(((unsigned int)(src) << 13) & 0x00030000)
#define SLIMPRO_FPQ1_MBOX1_F1_LE_SET(dst,src) ((dst)&~0xe0030000)| \
			(((unsigned int)(src) << 29) & 0xe0000000) | (((unsigned int)(src) << 13) & 0x00030000)

/*	 Fields slimpro_wq1_mbox	 */
#define SLIMPRO_WQ1_MBOX1_F1_LE_WIDTH                                         5
#define SLIMPRO_WQ1_MBOX1_F1_LE_SHIFT                                        31
#define SLIMPRO_WQ1_MBOX1_F1_LE_MASK                                 0x1f000000
#define SLIMPRO_WQ1_MBOX1_F1_LE_RD(src)            (((src) & 0x1f000000) >> 24)
#define SLIMPRO_WQ1_MBOX1_F1_LE_WR(src)       (((unsigned int)(src) << 24) & 0x1f000000)
#define SLIMPRO_WQ1_MBOX1_F1_LE_SET(dst,src)                     ((dst)&~0x1f000000)|\
				(((unsigned int)(src) << 24) & 0x1f000000)

/*	Register csr_recomb_ctrl_0	*/

/*	 Fields force_eviction_cstate_address	 */
#define FORCE_EVICTION_CSTATE_ADDRESS0_F1_LE_WIDTH                            6
#define FORCE_EVICTION_CSTATE_ADDRESS0_F1_LE_SHIFT                           19
#define FORCE_EVICTION_CSTATE_ADDRESS0_F1_LE_MASK                    0x00f00300
#define FORCE_EVICTION_CSTATE_ADDRESS0_F1_LE_RD(src)               (((src) & 0x00f00000) >> 20) | \
				(((src) & 0x00000300) >> 4)
#define FORCE_EVICTION_CSTATE_ADDRESS0_F1_LE_WR(src)      (((unsigned int)(src) << 20) & 0x00f00000) | \
				(((unsigned int)(src) << 4) & 0x00000300)
#define FORCE_EVICTION_CSTATE_ADDRESS0_F1_LE_SET(dst,src) ((dst) & ~0x00f00300)| \
	(((unsigned int)(src) << 20) & 0x00f00000)  | (((unsigned int)(src) << 20) & 0x00f00000)

/*	 Fields prescale_cntr	 */
#define PRESCALE_CNTR0_F1_LE_WIDTH                                            2
#define PRESCALE_CNTR0_F1_LE_SHIFT                                           23
#define PRESCALE_CNTR0_F1_LE_MASK                                    0x00030000
#define PRESCALE_CNTR0_F1_LE_RD(src)               (((src) & 0x00030000) >> 16)
#define PRESCALE_CNTR0_F1_LE_WR(src)          (((unsigned int)(src) << 16) & 0x00030000)
#define PRESCALE_CNTR0_F1_LE_SET(dst,src)                  ((dst) & ~0x00030000)| \
				(((unsigned int)(src) << 16) & 0x00030000)

/*	 Fields force_eviction_cstate	 */
#define FORCE_EVICTION_CSTATE0_F1_LE_WIDTH                                    1
#define FORCE_EVICTION_CSTATE0_F1_LE_SHIFT                                   28
#define FORCE_EVICTION_CSTATE0_F1_LE_MASK                            0x08000000
#define FORCE_EVICTION_CSTATE0_F1_LE_RD(src)       (((src) & 0x08000000) >> 27)
#define FORCE_EVICTION_CSTATE0_F1_LE_WR(src)  (((unsigned int)(src) << 27) & 0x08000000)
#define FORCE_EVICTION_CSTATE0_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields qidsb_resp_collapse_en	 */
#define QIDSB_RESP_COLLAPSE_EN0_F1_LE_WIDTH                                   1
#define QIDSB_RESP_COLLAPSE_EN0_F1_LE_SHIFT                                  29
#define QIDSB_RESP_COLLAPSE_EN0_F1_LE_MASK                           0x04000000
#define QIDSB_RESP_COLLAPSE_EN0_F1_LE_RD(src)      (((src) & 0x04000000) >> 26)
#define QIDSB_RESP_COLLAPSE_EN0_F1_LE_WR(src)                                               (((unsigned int)(src) << 26) & 0x04000000)
#define QIDSB_RESP_COLLAPSE_EN0_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields force_eviction	 */
#define FORCE_EVICTION0_F1_LE_WIDTH                                           1
#define FORCE_EVICTION0_F1_LE_SHIFT                                          30
#define FORCE_EVICTION0_F1_LE_MASK                                   0x02000000
#define FORCE_EVICTION0_F1_LE_RD(src)              (((src) & 0x02000000) >> 25)
#define FORCE_EVICTION0_F1_LE_WR(src)         (((unsigned int)(src) << 25) & 0x02000000)
#define FORCE_EVICTION0_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields recomb_en	 */
#define RECOMB_EN0_F1_LE_WIDTH                                                1
#define RECOMB_EN0_F1_LE_SHIFT                                               31
#define RECOMB_EN0_F1_LE_MASK                                        0x01000000
#define RECOMB_EN0_F1_LE_RD(src)                   (((src) & 0x01000000) >> 24)
#define RECOMB_EN0_F1_LE_WR(src)              (((unsigned int)(src) << 24) & 0x01000000)
#define RECOMB_EN0_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register csr_recomb_ctrl_1	*/

/*	 Fields amareq_afifo_thresh	 */
#define AMAREQ_AFIFO_THRESH1_F1_LE_WIDTH                                      2
#define AMAREQ_AFIFO_THRESH1_F1_LE_SHIFT                                      7
#define AMAREQ_AFIFO_THRESH1_F1_LE_MASK                              0x00000003
#define AMAREQ_AFIFO_THRESH1_F1_LE_RD(src)           (((src) & 0x00000003)<< 0)
#define AMAREQ_AFIFO_THRESH1_F1_LE_WR(src)     (((unsigned int)(src) >> 0) & 0x00000003)
#define AMAREQ_AFIFO_THRESH1_F1_LE_SET(dst,src)                   ((dst) & ~0x00000003) |\
			 (((unsigned int)(src) >> 0) & 0x00000003)

/*	 Fields amareq_dfifo_thresh	 */
#define AMAREQ_DFIFO_THRESH1_F1_LE_WIDTH                                      4
#define AMAREQ_DFIFO_THRESH1_F1_LE_SHIFT                                     15
#define AMAREQ_DFIFO_THRESH1_F1_LE_MASK                              0x00000f00
#define AMAREQ_DFIFO_THRESH1_F1_LE_RD(src)          (((src) & 0x00000f00) >> 8)
#define AMAREQ_DFIFO_THRESH1_F1_LE_WR(src)     (((unsigned int)(src) << 8) & 0x00000f00)
#define AMAREQ_DFIFO_THRESH1_F1_LE_SET(dst,src)                 ((dst) & ~0x00000f00) |  \
				(((unsigned int)(src) << 8) & 0x00000f00)

/*	 Fields wctrl_afifo_thresh	 */
#define WCTRL_AFIFO_THRESH1_F1_LE_WIDTH                                       2
#define WCTRL_AFIFO_THRESH1_F1_LE_SHIFT                                      23
#define WCTRL_AFIFO_THRESH1_F1_LE_MASK                               0x00030000
#define WCTRL_AFIFO_THRESH1_F1_LE_RD(src)          (((src) & 0x00030000) >> 16)
#define WCTRL_AFIFO_THRESH1_F1_LE_WR(src)     (((unsigned int)(src) << 16) & 0x00030000)
#define WCTRL_AFIFO_THRESH1_F1_LE_SET(dst,src)                  ((dst) & ~0x00030000)| \
				(((unsigned int)(src) << 16) & 0x00030000)

/*	 Fields wctrl_dfifo_thresh	 */
#define WCTRL_DFIFO_THRESH1_F1_LE_WIDTH                                       4
#define WCTRL_DFIFO_THRESH1_F1_LE_SHIFT                                      31
#define WCTRL_DFIFO_THRESH1_F1_LE_MASK                               0x0f000000
#define WCTRL_DFIFO_THRESH1_F1_LE_RD(src)          (((src) & 0x0f000000) >> 24)
#define WCTRL_DFIFO_THRESH1_F1_LE_WR(src)     (((unsigned int)(src) << 24) & 0x0f000000)
#define WCTRL_DFIFO_THRESH1_F1_LE_SET(dst,src)                     ((dst)&~0x0f000000)|\
				(((unsigned int)(src) << 24) & 0x0f000000)

/*	Register csr_recomb_ctrl_2	*/

/*	 Fields bresp_brespfifo_thresh	 */
#define BRESP_BRESPFIFO_THRESH2_F1_LE_WIDTH                                   8
#define BRESP_BRESPFIFO_THRESH2_F1_LE_SHIFT                                   7
#define BRESP_BRESPFIFO_THRESH2_F1_LE_MASK                           0x000000ff
#define BRESP_BRESPFIFO_THRESH2_F1_LE_RD(src)        (((src) & 0x000000ff)<< 0)
#define BRESP_BRESPFIFO_THRESH2_F1_LE_WR(src)  (((unsigned int)(src) >> 0) & 0x000000ff)
#define BRESP_BRESPFIFO_THRESH2_F1_LE_SET(dst,src)                   ((dst) & ~0x000000ff) |\
			 (((unsigned int)(src) >> 0) & 0x000000ff)

/*	 Fields bresp_vc0bfifo_thresh	 */
#define BRESP_VC0BFIFO_THRESH2_F1_LE_WIDTH                                    6
#define BRESP_VC0BFIFO_THRESH2_F1_LE_SHIFT                                   15
#define BRESP_VC0BFIFO_THRESH2_F1_LE_MASK                            0x00003f00
#define BRESP_VC0BFIFO_THRESH2_F1_LE_RD(src)        (((src) & 0x00003f00) >> 8)
#define BRESP_VC0BFIFO_THRESH2_F1_LE_WR(src)   (((unsigned int)(src) << 8) & 0x00003f00)
#define BRESP_VC0BFIFO_THRESH2_F1_LE_SET(dst,src)                 ((dst) & ~0x00003f00) |  \
				(((unsigned int)(src) << 8) & 0x00003f00)

/*	 Fields bresp_vc1bfifo_thresh	 */
#define BRESP_VC1BFIFO_THRESH2_F1_LE_WIDTH                                    6
#define BRESP_VC1BFIFO_THRESH2_F1_LE_SHIFT                                   23
#define BRESP_VC1BFIFO_THRESH2_F1_LE_MASK                            0x003f0000
#define BRESP_VC1BFIFO_THRESH2_F1_LE_RD(src)       (((src) & 0x003f0000) >> 16)
#define BRESP_VC1BFIFO_THRESH2_F1_LE_WR(src)  (((unsigned int)(src) << 16) & 0x003f0000)
#define BRESP_VC1BFIFO_THRESH2_F1_LE_SET(dst,src)                  ((dst) & ~0x003f0000)| \
				(((unsigned int)(src) << 16) & 0x003f0000)

/*	 Fields bresp_vc2bfifo_thresh	 */
#define BRESP_VC2BFIFO_THRESH2_F1_LE_WIDTH                                    6
#define BRESP_VC2BFIFO_THRESH2_F1_LE_SHIFT                                   31
#define BRESP_VC2BFIFO_THRESH2_F1_LE_MASK                            0x3f000000
#define BRESP_VC2BFIFO_THRESH2_F1_LE_RD(src)       (((src) & 0x3f000000) >> 24)
#define BRESP_VC2BFIFO_THRESH2_F1_LE_WR(src)  (((unsigned int)(src) << 24) & 0x3f000000)
#define BRESP_VC2BFIFO_THRESH2_F1_LE_SET(dst,src)                     ((dst)&~0x3f000000)|\
				(((unsigned int)(src) << 24) & 0x3f000000)

/*	Register csr_qm_recomb_ram_margin	*/

/*	 Fields qidsbmem_rmea	 */
#define QIDSBMEM_RMEA_F1_LE_WIDTH                                             1
#define QIDSBMEM_RMEA_F1_LE_SHIFT                                            18
#define QIDSBMEM_RMEA_F1_LE_MASK                                     0x00200000
#define QIDSBMEM_RMEA_F1_LE_RD(src)                (((src) & 0x00200000) >> 21)
#define QIDSBMEM_RMEA_F1_LE_WR(src)           (((unsigned int)(src) << 21) & 0x00200000)
#define QIDSBMEM_RMEA_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*	 Fields qidsbmem_rmeb	 */
#define QIDSBMEM_RMEB_F1_LE_WIDTH                                             1
#define QIDSBMEM_RMEB_F1_LE_SHIFT                                            19
#define QIDSBMEM_RMEB_F1_LE_MASK                                     0x00100000
#define QIDSBMEM_RMEB_F1_LE_RD(src)                (((src) & 0x00100000) >> 20)
#define QIDSBMEM_RMEB_F1_LE_WR(src)           (((unsigned int)(src) << 20) & 0x00100000)
#define QIDSBMEM_RMEB_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields qidsbmem_rma	 */
#define QIDSBMEM_RMA_F1_LE_WIDTH                                              2
#define QIDSBMEM_RMA_F1_LE_SHIFT                                             21
#define QIDSBMEM_RMA_F1_LE_MASK                                      0x000c0000
#define QIDSBMEM_RMA_F1_LE_RD(src)                 (((src) & 0x000c0000) >> 18)
#define QIDSBMEM_RMA_F1_LE_WR(src)            (((unsigned int)(src) << 18) & 0x000c0000)
#define QIDSBMEM_RMA_F1_LE_SET(dst,src)                  ((dst) & ~0x000c0000)| \
				(((unsigned int)(src) << 18) & 0x000c0000)

/*	 Fields qidsbmem_rmb	 */
#define QIDSBMEM_RMB_F1_LE_WIDTH                                              2
#define QIDSBMEM_RMB_F1_LE_SHIFT                                             23
#define QIDSBMEM_RMB_F1_LE_MASK                                      0x00030000
#define QIDSBMEM_RMB_F1_LE_RD(src)                 (((src) & 0x00030000) >> 16)
#define QIDSBMEM_RMB_F1_LE_WR(src)            (((unsigned int)(src) << 16) & 0x00030000)
#define QIDSBMEM_RMB_F1_LE_SET(dst,src)                  ((dst) & ~0x00030000)| \
				(((unsigned int)(src) << 16) & 0x00030000)

/*	 Fields cmem_rmea	 */
#define CMEM_RMEA_F1_LE_WIDTH                                                 1
#define CMEM_RMEA_F1_LE_SHIFT                                                26
#define CMEM_RMEA_F1_LE_MASK                                         0x20000000
#define CMEM_RMEA_F1_LE_RD(src)                    (((src) & 0x20000000) >> 29)
#define CMEM_RMEA_F1_LE_WR(src)               (((unsigned int)(src) << 29) & 0x20000000)
#define CMEM_RMEA_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields cmem_rmeb	 */
#define CMEM_RMEB_F1_LE_WIDTH                                                 1
#define CMEM_RMEB_F1_LE_SHIFT                                                27
#define CMEM_RMEB_F1_LE_MASK                                         0x10000000
#define CMEM_RMEB_F1_LE_RD(src)                    (((src) & 0x10000000) >> 28)
#define CMEM_RMEB_F1_LE_WR(src)               (((unsigned int)(src) << 28) & 0x10000000)
#define CMEM_RMEB_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields cmem_rma	 */
#define CMEM_RMA_F1_LE_WIDTH                                                  2
#define CMEM_RMA_F1_LE_SHIFT                                                 29
#define CMEM_RMA_F1_LE_MASK                                          0x0c000000
#define CMEM_RMA_F1_LE_RD(src)                     (((src) & 0x0c000000) >> 26)
#define CMEM_RMA_F1_LE_WR(src)                (((unsigned int)(src) << 26) & 0x0c000000)
#define CMEM_RMA_F1_LE_SET(dst,src)                     ((dst)&~0x0c000000)|\
				(((unsigned int)(src) << 26) & 0x0c000000)

/*	 Fields cmem_rmb	 */
#define CMEM_RMB_F1_LE_WIDTH                                                  2
#define CMEM_RMB_F1_LE_SHIFT                                                 31
#define CMEM_RMB_F1_LE_MASK                                          0x03000000
#define CMEM_RMB_F1_LE_RD(src)                     (((src) & 0x03000000) >> 24)
#define CMEM_RMB_F1_LE_WR(src)                (((unsigned int)(src) << 24) & 0x03000000)
#define CMEM_RMB_F1_LE_SET(dst,src)                     ((dst)&~0x03000000)|\
				(((unsigned int)(src) << 24) & 0x03000000)

/*	Register csr_recomb_sts_0	*/

/*	 Fields cstate_empty	 */
#define CSTATE_EMPTY0_F1_LE_WIDTH                                             1
#define CSTATE_EMPTY0_F1_LE_SHIFT                                            23
#define CSTATE_EMPTY0_F1_LE_MASK                                     0x00010000
#define CSTATE_EMPTY0_F1_LE_RD(src)                (((src) & 0x00010000) >> 16)
#define CSTATE_EMPTY0_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*	 Fields amareq_afifo_empty	 */
#define AMAREQ_AFIFO_EMPTY0_F1_LE_WIDTH                                       1
#define AMAREQ_AFIFO_EMPTY0_F1_LE_SHIFT                                      24
#define AMAREQ_AFIFO_EMPTY0_F1_LE_MASK                               0x80000000
#define AMAREQ_AFIFO_EMPTY0_F1_LE_RD(src)          (((src) & 0x80000000) >> 31)
#define AMAREQ_AFIFO_EMPTY0_F1_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields amareq_dfifo_empty	 */
#define AMAREQ_DFIFO_EMPTY0_F1_LE_WIDTH                                       1
#define AMAREQ_DFIFO_EMPTY0_F1_LE_SHIFT                                      25
#define AMAREQ_DFIFO_EMPTY0_F1_LE_MASK                               0x40000000
#define AMAREQ_DFIFO_EMPTY0_F1_LE_RD(src)          (((src) & 0x40000000) >> 30)
#define AMAREQ_DFIFO_EMPTY0_F1_LE_SET(dst,src)                     ((dst)&~0x40000000)|\
				(((unsigned int)(src) << 30) & 0x40000000)

/*	 Fields bresp_brespfifo_empty	 */
#define BRESP_BRESPFIFO_EMPTY0_F1_LE_WIDTH                                    1
#define BRESP_BRESPFIFO_EMPTY0_F1_LE_SHIFT                                   26
#define BRESP_BRESPFIFO_EMPTY0_F1_LE_MASK                            0x20000000
#define BRESP_BRESPFIFO_EMPTY0_F1_LE_RD(src)       (((src) & 0x20000000) >> 29)
#define BRESP_BRESPFIFO_EMPTY0_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields bresp_vc0bfifo_empty	 */
#define BRESP_VC0BFIFO_EMPTY0_F1_LE_WIDTH                                     1
#define BRESP_VC0BFIFO_EMPTY0_F1_LE_SHIFT                                    27
#define BRESP_VC0BFIFO_EMPTY0_F1_LE_MASK                             0x10000000
#define BRESP_VC0BFIFO_EMPTY0_F1_LE_RD(src)        (((src) & 0x10000000) >> 28)
#define BRESP_VC0BFIFO_EMPTY0_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields bresp_vc1bfifo_empty	 */
#define BRESP_VC1BFIFO_EMPTY0_F1_LE_WIDTH                                     1
#define BRESP_VC1BFIFO_EMPTY0_F1_LE_SHIFT                                    28
#define BRESP_VC1BFIFO_EMPTY0_F1_LE_MASK                             0x08000000
#define BRESP_VC1BFIFO_EMPTY0_F1_LE_RD(src)        (((src) & 0x08000000) >> 27)
#define BRESP_VC1BFIFO_EMPTY0_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields bresp_vc2bfifo_empty	 */
#define BRESP_VC2BFIFO_EMPTY0_F1_LE_WIDTH                                     1
#define BRESP_VC2BFIFO_EMPTY0_F1_LE_SHIFT                                    29
#define BRESP_VC2BFIFO_EMPTY0_F1_LE_MASK                             0x04000000
#define BRESP_VC2BFIFO_EMPTY0_F1_LE_RD(src)        (((src) & 0x04000000) >> 26)
#define BRESP_VC2BFIFO_EMPTY0_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields wctrl_afifo_empty	 */
#define WCTRL_AFIFO_EMPTY0_F1_LE_WIDTH                                        1
#define WCTRL_AFIFO_EMPTY0_F1_LE_SHIFT                                       30
#define WCTRL_AFIFO_EMPTY0_F1_LE_MASK                                0x02000000
#define WCTRL_AFIFO_EMPTY0_F1_LE_RD(src)           (((src) & 0x02000000) >> 25)
#define WCTRL_AFIFO_EMPTY0_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields wctrl_dfifo_empty	 */
#define WCTRL_DFIFO_EMPTY0_F1_LE_WIDTH                                        1
#define WCTRL_DFIFO_EMPTY0_F1_LE_SHIFT                                       31
#define WCTRL_DFIFO_EMPTY0_F1_LE_MASK                                0x01000000
#define WCTRL_DFIFO_EMPTY0_F1_LE_RD(src)           (((src) & 0x01000000) >> 24)
#define WCTRL_DFIFO_EMPTY0_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register csr_recomb_sts_1	*/

/*	 Fields cstate_empty	 */
#define CSTATE_EMPTY1_F1_LE_WIDTH                                            32
#define CSTATE_EMPTY1_F1_LE_SHIFT                                            31
#define CSTATE_EMPTY1_F1_LE_MASK                                     0xffffffff
#define CSTATE_EMPTY1_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define CSTATE_EMPTY1_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register csr_recomb_sts_2	*/

/*	 Fields cstate_empty	 */
#define CSTATE_EMPTY2_F1_LE_WIDTH                                            32
#define CSTATE_EMPTY2_F1_LE_SHIFT                                            31
#define CSTATE_EMPTY2_F1_LE_MASK                                     0xffffffff
#define CSTATE_EMPTY2_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define CSTATE_EMPTY2_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register recomb_INT	*/

/*	 Fields amareq_afifo_overfl_intr	 */
#define AMAREQ_AFIFO_OVERFL_INTR_F1_LE_WIDTH                                  1
#define AMAREQ_AFIFO_OVERFL_INTR_F1_LE_SHIFT                                 16
#define AMAREQ_AFIFO_OVERFL_INTR_F1_LE_MASK                          0x00800000
#define AMAREQ_AFIFO_OVERFL_INTR_F1_LE_RD(src)     (((src) & 0x00800000) >> 23)
#define AMAREQ_AFIFO_OVERFL_INTR_F1_LE_WR(src)                                               (((unsigned int)(src) << 23) & 0x00800000)
#define AMAREQ_AFIFO_OVERFL_INTR_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*	 Fields amareq_afifo_underfl_intr	 */
#define AMAREQ_AFIFO_UNDERFL_INTR_F1_LE_WIDTH                                 1
#define AMAREQ_AFIFO_UNDERFL_INTR_F1_LE_SHIFT                                17
#define AMAREQ_AFIFO_UNDERFL_INTR_F1_LE_MASK                         0x00400000
#define AMAREQ_AFIFO_UNDERFL_INTR_F1_LE_RD(src)    (((src) & 0x00400000) >> 22)
#define AMAREQ_AFIFO_UNDERFL_INTR_F1_LE_WR(src)                                               (((unsigned int)(src) << 22) & 0x00400000)
#define AMAREQ_AFIFO_UNDERFL_INTR_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*	 Fields amareq_dfifo_overfl_intr	 */
#define AMAREQ_DFIFO_OVERFL_INTR_F1_LE_WIDTH                                  1
#define AMAREQ_DFIFO_OVERFL_INTR_F1_LE_SHIFT                                 18
#define AMAREQ_DFIFO_OVERFL_INTR_F1_LE_MASK                          0x00200000
#define AMAREQ_DFIFO_OVERFL_INTR_F1_LE_RD(src)     (((src) & 0x00200000) >> 21)
#define AMAREQ_DFIFO_OVERFL_INTR_F1_LE_WR(src)                                               (((unsigned int)(src) << 21) & 0x00200000)
#define AMAREQ_DFIFO_OVERFL_INTR_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*	 Fields amareq_dfifo_underfl_intr	 */
#define AMAREQ_DFIFO_UNDERFL_INTR_F1_LE_WIDTH                                 1
#define AMAREQ_DFIFO_UNDERFL_INTR_F1_LE_SHIFT                                19
#define AMAREQ_DFIFO_UNDERFL_INTR_F1_LE_MASK                         0x00100000
#define AMAREQ_DFIFO_UNDERFL_INTR_F1_LE_RD(src)    (((src) & 0x00100000) >> 20)
#define AMAREQ_DFIFO_UNDERFL_INTR_F1_LE_WR(src)                                               (((unsigned int)(src) << 20) & 0x00100000)
#define AMAREQ_DFIFO_UNDERFL_INTR_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields bresp_brespfifo_overfl_intr	 */
#define BRESP_BRESPFIFO_OVERFL_INTR_F1_LE_WIDTH                               1
#define BRESP_BRESPFIFO_OVERFL_INTR_F1_LE_SHIFT                              20
#define BRESP_BRESPFIFO_OVERFL_INTR_F1_LE_MASK                       0x00080000
#define BRESP_BRESPFIFO_OVERFL_INTR_F1_LE_RD(src)  (((src) & 0x00080000) >> 19)
#define BRESP_BRESPFIFO_OVERFL_INTR_F1_LE_WR(src)                                               (((unsigned int)(src) << 19) & 0x00080000)
#define BRESP_BRESPFIFO_OVERFL_INTR_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*	 Fields bresp_brespfifo_underfl_intr	 */
#define BRESP_BRESPFIFO_UNDERFL_INTR_F1_LE_WIDTH                              1
#define BRESP_BRESPFIFO_UNDERFL_INTR_F1_LE_SHIFT                             21
#define BRESP_BRESPFIFO_UNDERFL_INTR_F1_LE_MASK                      0x00040000
#define BRESP_BRESPFIFO_UNDERFL_INTR_F1_LE_RD(src)                                                   (((src) & 0x00040000) >> 18)
#define BRESP_BRESPFIFO_UNDERFL_INTR_F1_LE_WR(src)                                               (((unsigned int)(src) << 18) & 0x00040000)
#define BRESP_BRESPFIFO_UNDERFL_INTR_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*	 Fields bresp_vc0bfifo_overfl_intr	 */
#define BRESP_VC0BFIFO_OVERFL_INTR_F1_LE_WIDTH                                1
#define BRESP_VC0BFIFO_OVERFL_INTR_F1_LE_SHIFT                               22
#define BRESP_VC0BFIFO_OVERFL_INTR_F1_LE_MASK                        0x00020000
#define BRESP_VC0BFIFO_OVERFL_INTR_F1_LE_RD(src)   (((src) & 0x00020000) >> 17)
#define BRESP_VC0BFIFO_OVERFL_INTR_F1_LE_WR(src)                                               (((unsigned int)(src) << 17) & 0x00020000)
#define BRESP_VC0BFIFO_OVERFL_INTR_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*	 Fields bresp_vc0bfifo_underfl_intr	 */
#define BRESP_VC0BFIFO_UNDERFL_INTR_F1_LE_WIDTH                               1
#define BRESP_VC0BFIFO_UNDERFL_INTR_F1_LE_SHIFT                              23
#define BRESP_VC0BFIFO_UNDERFL_INTR_F1_LE_MASK                       0x00010000
#define BRESP_VC0BFIFO_UNDERFL_INTR_F1_LE_RD(src)  (((src) & 0x00010000) >> 16)
#define BRESP_VC0BFIFO_UNDERFL_INTR_F1_LE_WR(src)                                               (((unsigned int)(src) << 16) & 0x00010000)
#define BRESP_VC0BFIFO_UNDERFL_INTR_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*	 Fields bresp_vc1bfifo_overfl_intr	 */
#define BRESP_VC1BFIFO_OVERFL_INTR_F1_LE_WIDTH                                1
#define BRESP_VC1BFIFO_OVERFL_INTR_F1_LE_SHIFT                               24
#define BRESP_VC1BFIFO_OVERFL_INTR_F1_LE_MASK                        0x80000000
#define BRESP_VC1BFIFO_OVERFL_INTR_F1_LE_RD(src)   (((src) & 0x80000000) >> 31)
#define BRESP_VC1BFIFO_OVERFL_INTR_F1_LE_WR(src)                                               (((unsigned int)(src) << 31) & 0x80000000)
#define BRESP_VC1BFIFO_OVERFL_INTR_F1_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields bresp_vc1bfifo_underfl_intr	 */
#define BRESP_VC1BFIFO_UNDERFL_INTR_F1_LE_WIDTH                               1
#define BRESP_VC1BFIFO_UNDERFL_INTR_F1_LE_SHIFT                              25
#define BRESP_VC1BFIFO_UNDERFL_INTR_F1_LE_MASK                       0x40000000
#define BRESP_VC1BFIFO_UNDERFL_INTR_F1_LE_RD(src)  (((src) & 0x40000000) >> 30)
#define BRESP_VC1BFIFO_UNDERFL_INTR_F1_LE_WR(src)                                               (((unsigned int)(src) << 30) & 0x40000000)
#define BRESP_VC1BFIFO_UNDERFL_INTR_F1_LE_SET(dst,src)                     ((dst)&~0x40000000)|\
				(((unsigned int)(src) << 30) & 0x40000000)

/*	 Fields bresp_vc2bfifo_overfl_intr	 */
#define BRESP_VC2BFIFO_OVERFL_INTR_F1_LE_WIDTH                                1
#define BRESP_VC2BFIFO_OVERFL_INTR_F1_LE_SHIFT                               26
#define BRESP_VC2BFIFO_OVERFL_INTR_F1_LE_MASK                        0x20000000
#define BRESP_VC2BFIFO_OVERFL_INTR_F1_LE_RD(src)   (((src) & 0x20000000) >> 29)
#define BRESP_VC2BFIFO_OVERFL_INTR_F1_LE_WR(src)                                               (((unsigned int)(src) << 29) & 0x20000000)
#define BRESP_VC2BFIFO_OVERFL_INTR_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields bresp_vc2bfifo_underfl_intr	 */
#define BRESP_VC2BFIFO_UNDERFL_INTR_F1_LE_WIDTH                               1
#define BRESP_VC2BFIFO_UNDERFL_INTR_F1_LE_SHIFT                              27
#define BRESP_VC2BFIFO_UNDERFL_INTR_F1_LE_MASK                       0x10000000
#define BRESP_VC2BFIFO_UNDERFL_INTR_F1_LE_RD(src)  (((src) & 0x10000000) >> 28)
#define BRESP_VC2BFIFO_UNDERFL_INTR_F1_LE_WR(src)                                               (((unsigned int)(src) << 28) & 0x10000000)
#define BRESP_VC2BFIFO_UNDERFL_INTR_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields wctrl_afifo_overfl_intr	 */
#define WCTRL_AFIFO_OVERFL_INTR_F1_LE_WIDTH                                   1
#define WCTRL_AFIFO_OVERFL_INTR_F1_LE_SHIFT                                  28
#define WCTRL_AFIFO_OVERFL_INTR_F1_LE_MASK                           0x08000000
#define WCTRL_AFIFO_OVERFL_INTR_F1_LE_RD(src)      (((src) & 0x08000000) >> 27)
#define WCTRL_AFIFO_OVERFL_INTR_F1_LE_WR(src)                                               (((unsigned int)(src) << 27) & 0x08000000)
#define WCTRL_AFIFO_OVERFL_INTR_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields wctrl_afifo_underfl_intr	 */
#define WCTRL_AFIFO_UNDERFL_INTR_F1_LE_WIDTH                                  1
#define WCTRL_AFIFO_UNDERFL_INTR_F1_LE_SHIFT                                 29
#define WCTRL_AFIFO_UNDERFL_INTR_F1_LE_MASK                          0x04000000
#define WCTRL_AFIFO_UNDERFL_INTR_F1_LE_RD(src)     (((src) & 0x04000000) >> 26)
#define WCTRL_AFIFO_UNDERFL_INTR_F1_LE_WR(src)                                               (((unsigned int)(src) << 26) & 0x04000000)
#define WCTRL_AFIFO_UNDERFL_INTR_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields wctrl_dfifo_overfl_intr	 */
#define WCTRL_DFIFO_OVERFL_INTR_F1_LE_WIDTH                                   1
#define WCTRL_DFIFO_OVERFL_INTR_F1_LE_SHIFT                                  30
#define WCTRL_DFIFO_OVERFL_INTR_F1_LE_MASK                           0x02000000
#define WCTRL_DFIFO_OVERFL_INTR_F1_LE_RD(src)      (((src) & 0x02000000) >> 25)
#define WCTRL_DFIFO_OVERFL_INTR_F1_LE_WR(src)                                               (((unsigned int)(src) << 25) & 0x02000000)
#define WCTRL_DFIFO_OVERFL_INTR_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields wctrl_dfifo_underfl_intr	 */
#define WCTRL_DFIFO_UNDERFL_INTR_F1_LE_WIDTH                                  1
#define WCTRL_DFIFO_UNDERFL_INTR_F1_LE_SHIFT                                 31
#define WCTRL_DFIFO_UNDERFL_INTR_F1_LE_MASK                          0x01000000
#define WCTRL_DFIFO_UNDERFL_INTR_F1_LE_RD(src)     (((src) & 0x01000000) >> 24)
#define WCTRL_DFIFO_UNDERFL_INTR_F1_LE_WR(src)                                               (((unsigned int)(src) << 24) & 0x01000000)
#define WCTRL_DFIFO_UNDERFL_INTR_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register recomb_interruptMask	*/

/*Mask Register Fields amareq_afifo_overfl_intrMask	 */
#define AMAREQ_AFIFO_OVERFL_INTRMASK_F1_LE_WIDTH                              1
#define AMAREQ_AFIFO_OVERFL_INTRMASK_F1_LE_SHIFT                             16
#define AMAREQ_AFIFO_OVERFL_INTRMASK_F1_LE_MASK                      0x00800000
#define AMAREQ_AFIFO_OVERFL_INTRMASK_F1_LE_RD(src)                                                   (((src) & 0x00800000) >> 23)
#define AMAREQ_AFIFO_OVERFL_INTRMASK_F1_LE_WR(src)                                               (((unsigned int)(src) << 23) & 0x00800000)
#define AMAREQ_AFIFO_OVERFL_INTRMASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*Mask Register Fields amareq_afifo_underfl_intrMask	 */
#define AMAREQ_AFIFO_UNDERFL_INTRMASK_F1_LE_WIDTH                             1
#define AMAREQ_AFIFO_UNDERFL_INTRMASK_F1_LE_SHIFT                            17
#define AMAREQ_AFIFO_UNDERFL_INTRMASK_F1_LE_MASK                     0x00400000
#define AMAREQ_AFIFO_UNDERFL_INTRMASK_F1_LE_RD(src)                                                   (((src) & 0x00400000) >> 22)
#define AMAREQ_AFIFO_UNDERFL_INTRMASK_F1_LE_WR(src)                                               (((unsigned int)(src) << 22) & 0x00400000)
#define AMAREQ_AFIFO_UNDERFL_INTRMASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*Mask Register Fields amareq_dfifo_overfl_intrMask	 */
#define AMAREQ_DFIFO_OVERFL_INTRMASK_F1_LE_WIDTH                              1
#define AMAREQ_DFIFO_OVERFL_INTRMASK_F1_LE_SHIFT                             18
#define AMAREQ_DFIFO_OVERFL_INTRMASK_F1_LE_MASK                      0x00200000
#define AMAREQ_DFIFO_OVERFL_INTRMASK_F1_LE_RD(src)                                                   (((src) & 0x00200000) >> 21)
#define AMAREQ_DFIFO_OVERFL_INTRMASK_F1_LE_WR(src)                                               (((unsigned int)(src) << 21) & 0x00200000)
#define AMAREQ_DFIFO_OVERFL_INTRMASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*Mask Register Fields amareq_dfifo_underfl_intrMask	 */
#define AMAREQ_DFIFO_UNDERFL_INTRMASK_F1_LE_WIDTH                             1
#define AMAREQ_DFIFO_UNDERFL_INTRMASK_F1_LE_SHIFT                            19
#define AMAREQ_DFIFO_UNDERFL_INTRMASK_F1_LE_MASK                     0x00100000
#define AMAREQ_DFIFO_UNDERFL_INTRMASK_F1_LE_RD(src)                                                   (((src) & 0x00100000) >> 20)
#define AMAREQ_DFIFO_UNDERFL_INTRMASK_F1_LE_WR(src)                                               (((unsigned int)(src) << 20) & 0x00100000)
#define AMAREQ_DFIFO_UNDERFL_INTRMASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*Mask Register Fields bresp_brespfifo_overfl_intrMask	 */
#define BRESP_BRESPFIFO_OVERFL_INTRMASK_F1_LE_WIDTH                           1
#define BRESP_BRESPFIFO_OVERFL_INTRMASK_F1_LE_SHIFT                          20
#define BRESP_BRESPFIFO_OVERFL_INTRMASK_F1_LE_MASK                   0x00080000
#define BRESP_BRESPFIFO_OVERFL_INTRMASK_F1_LE_RD(src)                                                   (((src) & 0x00080000) >> 19)
#define BRESP_BRESPFIFO_OVERFL_INTRMASK_F1_LE_WR(src)                                               (((unsigned int)(src) << 19) & 0x00080000)
#define BRESP_BRESPFIFO_OVERFL_INTRMASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*Mask Register Fields bresp_brespfifo_underfl_intrMask	 */
#define BRESP_BRESPFIFO_UNDERFL_INTRMASK_F1_LE_WIDTH                          1
#define BRESP_BRESPFIFO_UNDERFL_INTRMASK_F1_LE_SHIFT                         21
#define BRESP_BRESPFIFO_UNDERFL_INTRMASK_F1_LE_MASK                  0x00040000
#define BRESP_BRESPFIFO_UNDERFL_INTRMASK_F1_LE_RD(src)                                                   (((src) & 0x00040000) >> 18)
#define BRESP_BRESPFIFO_UNDERFL_INTRMASK_F1_LE_WR(src)                                               (((unsigned int)(src) << 18) & 0x00040000)
#define BRESP_BRESPFIFO_UNDERFL_INTRMASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*Mask Register Fields bresp_vc0bfifo_overfl_intrMask	 */
#define BRESP_VC0BFIFO_OVERFL_INTRMASK_F1_LE_WIDTH                            1
#define BRESP_VC0BFIFO_OVERFL_INTRMASK_F1_LE_SHIFT                           22
#define BRESP_VC0BFIFO_OVERFL_INTRMASK_F1_LE_MASK                    0x00020000
#define BRESP_VC0BFIFO_OVERFL_INTRMASK_F1_LE_RD(src)                                                   (((src) & 0x00020000) >> 17)
#define BRESP_VC0BFIFO_OVERFL_INTRMASK_F1_LE_WR(src)                                               (((unsigned int)(src) << 17) & 0x00020000)
#define BRESP_VC0BFIFO_OVERFL_INTRMASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*Mask Register Fields bresp_vc0bfifo_underfl_intrMask	 */
#define BRESP_VC0BFIFO_UNDERFL_INTRMASK_F1_LE_WIDTH                           1
#define BRESP_VC0BFIFO_UNDERFL_INTRMASK_F1_LE_SHIFT                          23
#define BRESP_VC0BFIFO_UNDERFL_INTRMASK_F1_LE_MASK                   0x00010000
#define BRESP_VC0BFIFO_UNDERFL_INTRMASK_F1_LE_RD(src)                                                   (((src) & 0x00010000) >> 16)
#define BRESP_VC0BFIFO_UNDERFL_INTRMASK_F1_LE_WR(src)                                               (((unsigned int)(src) << 16) & 0x00010000)
#define BRESP_VC0BFIFO_UNDERFL_INTRMASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*Mask Register Fields bresp_vc1bfifo_overfl_intrMask	 */
#define BRESP_VC1BFIFO_OVERFL_INTRMASK_F1_LE_WIDTH                            1
#define BRESP_VC1BFIFO_OVERFL_INTRMASK_F1_LE_SHIFT                           24
#define BRESP_VC1BFIFO_OVERFL_INTRMASK_F1_LE_MASK                    0x80000000
#define BRESP_VC1BFIFO_OVERFL_INTRMASK_F1_LE_RD(src)                                                   (((src) & 0x80000000) >> 31)
#define BRESP_VC1BFIFO_OVERFL_INTRMASK_F1_LE_WR(src)                                               (((unsigned int)(src) << 31) & 0x80000000)
#define BRESP_VC1BFIFO_OVERFL_INTRMASK_F1_LE_SET(dst,src)                      ((dst)&~0x80000000)|\
			(((unsigned int)(src) << 31) & 0x80000000)

/*Mask Register Fields bresp_vc1bfifo_underfl_intrMask	 */
#define BRESP_VC1BFIFO_UNDERFL_INTRMASK_F1_LE_WIDTH                           1
#define BRESP_VC1BFIFO_UNDERFL_INTRMASK_F1_LE_SHIFT                          25
#define BRESP_VC1BFIFO_UNDERFL_INTRMASK_F1_LE_MASK                   0x40000000
#define BRESP_VC1BFIFO_UNDERFL_INTRMASK_F1_LE_RD(src)                                                   (((src) & 0x40000000) >> 30)
#define BRESP_VC1BFIFO_UNDERFL_INTRMASK_F1_LE_WR(src)                                               (((unsigned int)(src) << 30) & 0x40000000)
#define BRESP_VC1BFIFO_UNDERFL_INTRMASK_F1_LE_SET(dst,src)                      ((dst)&~0x40000000)|\
			(((unsigned int)(src) << 30) & 0x40000000)

/*Mask Register Fields bresp_vc2bfifo_overfl_intrMask	 */
#define BRESP_VC2BFIFO_OVERFL_INTRMASK_F1_LE_WIDTH                            1
#define BRESP_VC2BFIFO_OVERFL_INTRMASK_F1_LE_SHIFT                           26
#define BRESP_VC2BFIFO_OVERFL_INTRMASK_F1_LE_MASK                    0x20000000
#define BRESP_VC2BFIFO_OVERFL_INTRMASK_F1_LE_RD(src)                                                   (((src) & 0x20000000) >> 29)
#define BRESP_VC2BFIFO_OVERFL_INTRMASK_F1_LE_WR(src)                                               (((unsigned int)(src) << 29) & 0x20000000)
#define BRESP_VC2BFIFO_OVERFL_INTRMASK_F1_LE_SET(dst,src)                      ((dst)&~0x20000000)|\
			(((unsigned int)(src) << 29) & 0x20000000)

/*Mask Register Fields bresp_vc2bfifo_underfl_intrMask	 */
#define BRESP_VC2BFIFO_UNDERFL_INTRMASK_F1_LE_WIDTH                           1
#define BRESP_VC2BFIFO_UNDERFL_INTRMASK_F1_LE_SHIFT                          27
#define BRESP_VC2BFIFO_UNDERFL_INTRMASK_F1_LE_MASK                   0x10000000
#define BRESP_VC2BFIFO_UNDERFL_INTRMASK_F1_LE_RD(src)                                                   (((src) & 0x10000000) >> 28)
#define BRESP_VC2BFIFO_UNDERFL_INTRMASK_F1_LE_WR(src)                                               (((unsigned int)(src) << 28) & 0x10000000)
#define BRESP_VC2BFIFO_UNDERFL_INTRMASK_F1_LE_SET(dst,src)                      ((dst)&~0x10000000)|\
			(((unsigned int)(src) << 28) & 0x10000000)

/*Mask Register Fields wctrl_afifo_overfl_intrMask	 */
#define WCTRL_AFIFO_OVERFL_INTRMASK_F1_LE_WIDTH                               1
#define WCTRL_AFIFO_OVERFL_INTRMASK_F1_LE_SHIFT                              28
#define WCTRL_AFIFO_OVERFL_INTRMASK_F1_LE_MASK                       0x08000000
#define WCTRL_AFIFO_OVERFL_INTRMASK_F1_LE_RD(src)  (((src) & 0x08000000) >> 27)
#define WCTRL_AFIFO_OVERFL_INTRMASK_F1_LE_WR(src)                                               (((unsigned int)(src) << 27) & 0x08000000)
#define WCTRL_AFIFO_OVERFL_INTRMASK_F1_LE_SET(dst,src)                      ((dst)&~0x08000000)|\
			(((unsigned int)(src) << 27) & 0x08000000)

/*Mask Register Fields wctrl_afifo_underfl_intrMask	 */
#define WCTRL_AFIFO_UNDERFL_INTRMASK_F1_LE_WIDTH                              1
#define WCTRL_AFIFO_UNDERFL_INTRMASK_F1_LE_SHIFT                             29
#define WCTRL_AFIFO_UNDERFL_INTRMASK_F1_LE_MASK                      0x04000000
#define WCTRL_AFIFO_UNDERFL_INTRMASK_F1_LE_RD(src)                                                   (((src) & 0x04000000) >> 26)
#define WCTRL_AFIFO_UNDERFL_INTRMASK_F1_LE_WR(src)                                               (((unsigned int)(src) << 26) & 0x04000000)
#define WCTRL_AFIFO_UNDERFL_INTRMASK_F1_LE_SET(dst,src)                      ((dst)&~0x04000000)|\
			(((unsigned int)(src) << 26) & 0x04000000)

/*Mask Register Fields wctrl_dfifo_overfl_intrMask	 */
#define WCTRL_DFIFO_OVERFL_INTRMASK_F1_LE_WIDTH                               1
#define WCTRL_DFIFO_OVERFL_INTRMASK_F1_LE_SHIFT                              30
#define WCTRL_DFIFO_OVERFL_INTRMASK_F1_LE_MASK                       0x02000000
#define WCTRL_DFIFO_OVERFL_INTRMASK_F1_LE_RD(src)  (((src) & 0x02000000) >> 25)
#define WCTRL_DFIFO_OVERFL_INTRMASK_F1_LE_WR(src)                                               (((unsigned int)(src) << 25) & 0x02000000)
#define WCTRL_DFIFO_OVERFL_INTRMASK_F1_LE_SET(dst,src)                      ((dst)&~0x02000000)|\
			(((unsigned int)(src) << 25) & 0x02000000)

/*Mask Register Fields wctrl_dfifo_underfl_intrMask	 */
#define WCTRL_DFIFO_UNDERFL_INTRMASK_F1_LE_WIDTH                              1
#define WCTRL_DFIFO_UNDERFL_INTRMASK_F1_LE_SHIFT                             31
#define WCTRL_DFIFO_UNDERFL_INTRMASK_F1_LE_MASK                      0x01000000
#define WCTRL_DFIFO_UNDERFL_INTRMASK_F1_LE_RD(src)                                                   (((src) & 0x01000000) >> 24)
#define WCTRL_DFIFO_UNDERFL_INTRMASK_F1_LE_WR(src)                                               (((unsigned int)(src) << 24) & 0x01000000)
#define WCTRL_DFIFO_UNDERFL_INTRMASK_F1_LE_SET(dst,src)                      ((dst)&~0x01000000)|\
			(((unsigned int)(src) << 24) & 0x01000000)

/*	Register csr_deq_ctrl_0	*/

/*	 Fields dis_256mbox	 */
#define DIS_256MBOX0_F1_LE_WIDTH                                              1
#define DIS_256MBOX0_F1_LE_SHIFT                                             29
#define DIS_256MBOX0_F1_LE_MASK                                      0x04000000
#define DIS_256MBOX0_F1_LE_RD(src)                 (((src) & 0x04000000) >> 26)
#define DIS_256MBOX0_F1_LE_WR(src)            (((unsigned int)(src) << 26) & 0x04000000)
#define DIS_256MBOX0_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields dis_4msg_push	 */
#define DIS_4MSG_PUSH0_F1_LE_WIDTH                                            1
#define DIS_4MSG_PUSH0_F1_LE_SHIFT                                           30
#define DIS_4MSG_PUSH0_F1_LE_MASK                                    0x02000000
#define DIS_4MSG_PUSH0_F1_LE_RD(src)               (((src) & 0x02000000) >> 25)
#define DIS_4MSG_PUSH0_F1_LE_WR(src)          (((unsigned int)(src) << 25) & 0x02000000)
#define DIS_4MSG_PUSH0_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields dis_half_64b_push	 */
#define DIS_HALF_64B_PUSH0_F1_LE_WIDTH                                        1
#define DIS_HALF_64B_PUSH0_F1_LE_SHIFT                                       31
#define DIS_HALF_64B_PUSH0_F1_LE_MASK                                0x01000000
#define DIS_HALF_64B_PUSH0_F1_LE_RD(src)           (((src) & 0x01000000) >> 24)
#define DIS_HALF_64B_PUSH0_F1_LE_WR(src)      (((unsigned int)(src) << 24) & 0x01000000)
#define DIS_HALF_64B_PUSH0_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register csr_mpic_ctrl_0	*/

/*	 Fields dis_irq2wr	 */
#define DIS_IRQ2WR0_F1_LE_WIDTH                                               1
#define DIS_IRQ2WR0_F1_LE_SHIFT                                              31
#define DIS_IRQ2WR0_F1_LE_MASK                                       0x01000000
#define DIS_IRQ2WR0_F1_LE_RD(src)                  (((src) & 0x01000000) >> 24)
#define DIS_IRQ2WR0_F1_LE_WR(src)             (((unsigned int)(src) << 24) & 0x01000000)
#define DIS_IRQ2WR0_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register csr_misc_ctrl_0	*/

/*	 Fields sab_en_override	 */
#define SAB_EN_OVERRIDE0_F1_LE_WIDTH                                          1
#define SAB_EN_OVERRIDE0_F1_LE_SHIFT                                         27
#define SAB_EN_OVERRIDE0_F1_LE_MASK                                  0x10000000
#define SAB_EN_OVERRIDE0_F1_LE_RD(src)             (((src) & 0x10000000) >> 28)
#define SAB_EN_OVERRIDE0_F1_LE_WR(src)        (((unsigned int)(src) << 28) & 0x10000000)
#define SAB_EN_OVERRIDE0_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields qmi_hold_hyst	 */
#define QMI_HOLD_HYST0_F1_LE_WIDTH                                            4
#define QMI_HOLD_HYST0_F1_LE_SHIFT                                           31
#define QMI_HOLD_HYST0_F1_LE_MASK                                    0x0f000000
#define QMI_HOLD_HYST0_F1_LE_RD(src)               (((src) & 0x0f000000) >> 24)
#define QMI_HOLD_HYST0_F1_LE_WR(src)          (((unsigned int)(src) << 24) & 0x0f000000)
#define QMI_HOLD_HYST0_F1_LE_SET(dst,src)                     ((dst)&~0x0f000000)|\
				(((unsigned int)(src) << 24) & 0x0f000000)

/*	Register pbm_diagdata_ctrl_0	*/

/*	 Fields sel	 */
#define REGSPEC_SEL0_F1_LE_WIDTH                                              8
#define REGSPEC_SEL0_F1_LE_SHIFT                                             31
#define REGSPEC_SEL0_F1_LE_MASK                                      0xff000000
#define REGSPEC_SEL0_F1_LE_RD(src)                 (((src) & 0xff000000) >> 24)
#define REGSPEC_SEL0_F1_LE_WR(src)            (((unsigned int)(src) << 24) & 0xff000000)
#define REGSPEC_SEL0_F1_LE_SET(dst,src)                     ((dst)&~0xff000000)|\
				(((unsigned int)(src) << 24) & 0xff000000)

/*	Global Base Address	*/
#define QM_CLKRST_CSR_BASE_ADDR			(QM_CSR_BASE_ADDR + 0xc000)


/*    Address QM_CLKRST_CSR  Registers */
#define QM_SRST_ADDR                                                 0x00000200
#define QM_SRST_DEFAULT                                              0x00000003
#define QM_CLKEN_ADDR                                                0x00000208
#define QM_CLKEN_DEFAULT                                             0x00000000

/*	Register qm_srst	*/

/*	 Fields qm_reset	 */
#define QM_RESET_F1_LE_WIDTH                                                  1
#define QM_RESET_F1_LE_SHIFT                                                 30
#define QM_RESET_F1_LE_MASK                                          0x02000000
#define QM_RESET_F1_LE_RD(src)                     (((src) & 0x02000000) >> 25)
#define QM_RESET_F1_LE_WR(src)                (((unsigned int)(src) << 25) & 0x02000000)
#define QM_RESET_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields csr_reset	 */
#define CSR_RESET_F1_LE_WIDTH                                                 1
#define CSR_RESET_F1_LE_SHIFT                                                31
#define CSR_RESET_F1_LE_MASK                                         0x01000000
#define CSR_RESET_F1_LE_RD(src)                    (((src) & 0x01000000) >> 24)
#define CSR_RESET_F1_LE_WR(src)               (((unsigned int)(src) << 24) & 0x01000000)
#define CSR_RESET_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register qm_clken	*/

/*	 Fields qm_clken	 */
#define QM_CLKEN_F1_LE_WIDTH                                                  1
#define QM_CLKEN_F1_LE_SHIFT                                                 30
#define QM_CLKEN_F1_LE_MASK                                          0x02000000
#define QM_CLKEN_F1_LE_RD(src)                     (((src) & 0x02000000) >> 25)
#define QM_CLKEN_F1_LE_WR(src)                (((unsigned int)(src) << 25) & 0x02000000)
#define QM_CLKEN_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields csr_clken	 */
#define CSR_CLKEN_F1_LE_WIDTH                                                 1
#define CSR_CLKEN_F1_LE_SHIFT                                                31
#define CSR_CLKEN_F1_LE_MASK                                         0x01000000
#define CSR_CLKEN_F1_LE_RD(src)                    (((src) & 0x01000000) >> 24)
#define CSR_CLKEN_F1_LE_WR(src)               (((unsigned int)(src) << 24) & 0x01000000)
#define CSR_CLKEN_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Global Base Address	*/
#define REGSPEC_GLBL_DIAG_CSR_BASE_ADDR			(QM_CSR_BASE_ADDR + 0xd000)

/*    Address GLBL_DIAG_CSR  Registers */
#define REGSPEC_CFG_DIAG_SEL_ADDR                                    0x00000000
#define REGSPEC_CFG_DIAG_SEL_DEFAULT                                 0x00000000
#define REGSPEC_CFG_READ_BW_LAT_ADDR_MASK_ADDR                       0x00000004
#define REGSPEC_CFG_READ_BW_LAT_ADDR_MASK_DEFAULT                    0x00000000
#define REGSPEC_CFG_READ_BW_LAT_ADDR_PAT_ADDR                        0x00000008
#define REGSPEC_CFG_READ_BW_LAT_ADDR_PAT_DEFAULT                     0xffffffff
#define REGSPEC_CFG_WRITE_BW_LAT_ADDR_MASK_ADDR                      0x0000000c
#define REGSPEC_CFG_WRITE_BW_LAT_ADDR_MASK_DEFAULT                   0x00000000
#define REGSPEC_CFG_WRITE_BW_LAT_ADDR_PAT_ADDR                       0x00000010
#define REGSPEC_CFG_WRITE_BW_LAT_ADDR_PAT_DEFAULT                    0xffffffff
#define REGSPEC_CFG_DIAG_START_STOP_ADDR                             0x00000014
#define REGSPEC_CFG_DIAG_START_STOP_DEFAULT                          0x000003ff
#define REGSPEC_CFG_BW_MSTR_STOP_CNT_ADDR                            0x00000018
#define REGSPEC_CFG_BW_MSTR_STOP_CNT_DEFAULT                         0x00040004
#define REGSPEC_CFG_BW_SLV_STOP_CNT_ADDR                             0x0000001c
#define REGSPEC_CFG_BW_SLV_STOP_CNT_DEFAULT                          0x00040004
#define REGSPEC_STS_READ_LATENCY_OUTPUT_ADDR                         0x00000020
#define REGSPEC_STS_READ_LATENCY_OUTPUT_DEFAULT                      0x00000000
#define REGSPEC_STS_AXI_MRD_BW_CLK_CNT_ADDR                          0x00000024
#define REGSPEC_STS_AXI_MRD_BW_CLK_CNT_DEFAULT                       0x00000000
#define REGSPEC_STS_AXI_MRD_BW_BYTE_CNT_ADDR                         0x00000028
#define REGSPEC_STS_AXI_MRD_BW_BYTE_CNT_DEFAULT                      0x00000000
#define REGSPEC_STS_AXI_MWR_BW_CLK_CNT_ADDR                          0x0000002c
#define REGSPEC_STS_AXI_MWR_BW_CLK_CNT_DEFAULT                       0x00000000
#define REGSPEC_STS_AXI_MWR_BW_BYTE_CNT_ADDR                         0x00000030
#define REGSPEC_STS_AXI_MWR_BW_BYTE_CNT_DEFAULT                      0x00000000
#define REGSPEC_STS_AXI_SRD_BW_CLK_CNT_ADDR                          0x00000034
#define REGSPEC_STS_AXI_SRD_BW_CLK_CNT_DEFAULT                       0x00000000
#define REGSPEC_STS_AXI_SRD_BW_BYTE_CNT_ADDR                         0x00000038
#define REGSPEC_STS_AXI_SRD_BW_BYTE_CNT_DEFAULT                      0x00000000
#define REGSPEC_STS_AXI_SWR_BW_CLK_CNT_ADDR                          0x0000003c
#define REGSPEC_STS_AXI_SWR_BW_CLK_CNT_DEFAULT                       0x00000000
#define REGSPEC_STS_AXI_SWR_BW_BYTE_CNT_ADDR                         0x00000040
#define REGSPEC_STS_AXI_SWR_BW_BYTE_CNT_DEFAULT                      0x00000000
#define REGSPEC_CFG_DBG_TRIG_CTRL_ADDR                               0x00000044
#define REGSPEC_CFG_DBG_TRIG_CTRL_DEFAULT                            0x00000000
#define REGSPEC_CFG_DBG_PAT_REG_0_ADDR                               0x00000048
#define REGSPEC_CFG_DBG_PAT_REG_0_DEFAULT                            0x00000000
#define REGSPEC_CFG_DBG_PAT_MASK_REG_0_ADDR                          0x0000004c
#define REGSPEC_CFG_DBG_PAT_MASK_REG_0_DEFAULT                       0x00000000
#define REGSPEC_CFG_DBG_PAT_REG_1_ADDR                               0x00000050
#define REGSPEC_CFG_DBG_PAT_REG_1_DEFAULT                            0x00000000
#define REGSPEC_CFG_DBG_PAT_MASK_REG_1_ADDR                          0x00000054
#define REGSPEC_CFG_DBG_PAT_MASK_REG_1_DEFAULT                       0x00000000
#define REGSPEC_DBG_TRIG_OUT_ADDR                                    0x00000058
#define REGSPEC_DBG_TRIG_OUT_DEFAULT                                 0x00000000
#define REGSPEC_DBG_TRIG_INT_ADDR                                    0x0000005c
#define REGSPEC_DBG_TRIG_INT_DEFAULT                                 0x00000000
#define REGSPEC_DBG_TRIG_INTMASK_ADDR                                0x00000060
#define REGSPEC_INTR_STS_ADDR                                        0x00000064
#define REGSPEC_INTR_STS_DEFAULT                                     0x00000000
#define REGSPEC_CFG_MEM_ECC_BYPASS_ADDR                              0x00000068
#define REGSPEC_CFG_MEM_ECC_BYPASS_DEFAULT                           0x00000000
#define REGSPEC_CFG_MEM_PWRDN_DIS_ADDR                               0x0000006c
#define REGSPEC_CFG_MEM_PWRDN_DIS_DEFAULT                            0x00000000
#define REGSPEC_CFG_MEM_RAM_SHUTDOWN_ADDR                            0x00000070
#define REGSPEC_CFG_MEM_RAM_SHUTDOWN_DEFAULT                         0xffffffff
#define REGSPEC_BLOCK_MEM_RDY_ADDR                                   0x00000074
#define REGSPEC_BLOCK_MEM_RDY_DEFAULT                                0xffffffff
#define REGSPEC_STS_READ_LATENCY_TOT_READ_REQS_ADDR                  0x0000008c
#define REGSPEC_STS_READ_LATENCY_TOT_READ_REQS_DEFAULT               0x00000000
#define REGSPEC_CFG_LT_MSTR_STOP_CNT_ADDR                            0x00000090
#define REGSPEC_CFG_LT_MSTR_STOP_CNT_DEFAULT                         0x00040000
#define REGSPEC_CFG_BW_SRD_TRIG_CAP_ADDR                             0x000000a0
#define REGSPEC_CFG_BW_SRD_TRIG_CAP_DEFAULT                          0x00000000
#define REGSPEC_CFG_BW_SWR_TRIG_CAP_ADDR                             0x000000a4
#define REGSPEC_CFG_BW_SWR_TRIG_CAP_DEFAULT                          0x00000000
#define REGSPEC_CFG_BW_MRD_TRIG_CAP_ADDR                             0x000000a8
#define REGSPEC_CFG_BW_MRD_TRIG_CAP_DEFAULT                          0x00000000
#define REGSPEC_CFG_BW_MWR_TRIG_CAP_ADDR                             0x000000ac
#define REGSPEC_CFG_BW_MWR_TRIG_CAP_DEFAULT                          0x00000000
#define REGSPEC_CFG_LT_MRD_TRIG_CAP_ADDR                             0x000000b0
#define REGSPEC_CFG_LT_MRD_TRIG_CAP_DEFAULT                          0x00000000
#define REGSPEC_DBG_BLOCK_AXI_ADDR                                   0x000000b4
#define REGSPEC_DBG_BLOCK_AXI_DEFAULT                                0x00000000
#define REGSPEC_DBG_BLOCK_NON_AXI_ADDR                               0x000000b8
#define REGSPEC_DBG_BLOCK_NON_AXI_DEFAULT                            0x00000000
#define REGSPEC_DBG_AXI_SHIM_OUT_ADDR                                0x000000bc
#define REGSPEC_DBG_AXI_SHIM_OUT_DEFAULT                             0x00000000

/*	Register CFG_DIAG_SEL	*/

/*	 Fields CFG_SHIM_BLK_DBUS_MUX_SELECT	 */
#define REGSPEC_CFG_SHIM_BLK_DBUS_MUX_SELECT_F1_LE_WIDTH                      1
#define REGSPEC_CFG_SHIM_BLK_DBUS_MUX_SELECT_F1_LE_SHIFT                     19
#define REGSPEC_CFG_SHIM_BLK_DBUS_MUX_SELECT_F1_LE_MASK              0x00100000
#define REGSPEC_CFG_SHIM_BLK_DBUS_MUX_SELECT_F1_LE_RD(src)                                                   (((src) & 0x00100000) >> 20)
#define REGSPEC_CFG_SHIM_BLK_DBUS_MUX_SELECT_F1_LE_WR(src)                                               (((unsigned int)(src) << 20) & 0x00100000)
#define REGSPEC_CFG_SHIM_BLK_DBUS_MUX_SELECT_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields CFG_AXI_NON_AXI_MUX_SELECT	 */
#define REGSPEC_CFG_AXI_NON_AXI_MUX_SELECT_F1_LE_WIDTH                        1
#define REGSPEC_CFG_AXI_NON_AXI_MUX_SELECT_F1_LE_SHIFT                       20
#define REGSPEC_CFG_AXI_NON_AXI_MUX_SELECT_F1_LE_MASK                0x00080000
#define REGSPEC_CFG_AXI_NON_AXI_MUX_SELECT_F1_LE_RD(src)                                                   (((src) & 0x00080000) >> 19)
#define REGSPEC_CFG_AXI_NON_AXI_MUX_SELECT_F1_LE_WR(src)                                               (((unsigned int)(src) << 19) & 0x00080000)
#define REGSPEC_CFG_AXI_NON_AXI_MUX_SELECT_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*	 Fields CFG_MUX_SELECTOR	 */
#define REGSPEC_CFG_MUX_SELECTOR_F1_LE_WIDTH                                 11
#define REGSPEC_CFG_MUX_SELECTOR_F1_LE_SHIFT                                 31
#define REGSPEC_CFG_MUX_SELECTOR_F1_LE_MASK                          0xff070000
#define REGSPEC_CFG_MUX_SELECTOR_F1_LE_RD(src)               	(((src) & 0xff000000) >> 24) |\
				(((src) & 0x00070000) >> 8)
#define REGSPEC_CFG_MUX_SELECTOR_F1_LE_WR(src)      	(((unsigned int)(src) << 24) & 0xff000000) |\
				(((unsigned int)(src) << 8) & 0x00070000)
#define REGSPEC_CFG_MUX_SELECTOR_F1_LE_SET(dst,src) ((dst)&~0xff070000)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00070000)

/*	Register CFG_READ_BW_LAT_ADDR_MASK	*/

/*	 Fields READ_ADDR_MASK	 */
#define REGSPEC_READ_ADDR_MASK_F1_LE_WIDTH                                   32
#define REGSPEC_READ_ADDR_MASK_F1_LE_SHIFT                                   31
#define REGSPEC_READ_ADDR_MASK_F1_LE_MASK                            0xffffffff
#define REGSPEC_READ_ADDR_MASK_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define REGSPEC_READ_ADDR_MASK_F1_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define REGSPEC_READ_ADDR_MASK_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register CFG_READ_BW_LAT_ADDR_PAT	*/

/*	 Fields READ_ADDR_PAT	 */
#define REGSPEC_READ_ADDR_PAT_F1_LE_WIDTH                                    32
#define REGSPEC_READ_ADDR_PAT_F1_LE_SHIFT                                    31
#define REGSPEC_READ_ADDR_PAT_F1_LE_MASK                             0xffffffff
#define REGSPEC_READ_ADDR_PAT_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define REGSPEC_READ_ADDR_PAT_F1_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define REGSPEC_READ_ADDR_PAT_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register CFG_WRITE_BW_LAT_ADDR_MASK	*/

/*	 Fields WRITE_ADDR_MASK	 */
#define REGSPEC_WRITE_ADDR_MASK_F1_LE_WIDTH                                  32
#define REGSPEC_WRITE_ADDR_MASK_F1_LE_SHIFT                                  31
#define REGSPEC_WRITE_ADDR_MASK_F1_LE_MASK                           0xffffffff
#define REGSPEC_WRITE_ADDR_MASK_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define REGSPEC_WRITE_ADDR_MASK_F1_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define REGSPEC_WRITE_ADDR_MASK_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register CFG_WRITE_BW_LAT_ADDR_PAT	*/

/*	 Fields WRITE_ADDR_PAT	 */
#define REGSPEC_WRITE_ADDR_PAT_F1_LE_WIDTH                                   32
#define REGSPEC_WRITE_ADDR_PAT_F1_LE_SHIFT                                   31
#define REGSPEC_WRITE_ADDR_PAT_F1_LE_MASK                            0xffffffff
#define REGSPEC_WRITE_ADDR_PAT_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define REGSPEC_WRITE_ADDR_PAT_F1_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define REGSPEC_WRITE_ADDR_PAT_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register CFG_DIAG_START_STOP	*/

/*	 Fields CTRL_AddCap_MRD_LT	 */
#define REGSPEC_CTRL_ADDCAP_MRD_LT_F1_LE_WIDTH                                1
#define REGSPEC_CTRL_ADDCAP_MRD_LT_F1_LE_SHIFT                               22
#define REGSPEC_CTRL_ADDCAP_MRD_LT_F1_LE_MASK                        0x00020000
#define REGSPEC_CTRL_ADDCAP_MRD_LT_F1_LE_RD(src)   (((src) & 0x00020000) >> 17)
#define REGSPEC_CTRL_ADDCAP_MRD_LT_F1_LE_WR(src)                                               (((unsigned int)(src) << 17) & 0x00020000)
#define REGSPEC_CTRL_ADDCAP_MRD_LT_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*	 Fields CTRL_AddCap_SRD_BW	 */
#define REGSPEC_CTRL_ADDCAP_SRD_BW_F1_LE_WIDTH                                1
#define REGSPEC_CTRL_ADDCAP_SRD_BW_F1_LE_SHIFT                               23
#define REGSPEC_CTRL_ADDCAP_SRD_BW_F1_LE_MASK                        0x00010000
#define REGSPEC_CTRL_ADDCAP_SRD_BW_F1_LE_RD(src)   (((src) & 0x00010000) >> 16)
#define REGSPEC_CTRL_ADDCAP_SRD_BW_F1_LE_WR(src)                                               (((unsigned int)(src) << 16) & 0x00010000)
#define REGSPEC_CTRL_ADDCAP_SRD_BW_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*	 Fields CTRL_AddCap_MRD_BW	 */
#define REGSPEC_CTRL_ADDCAP_MRD_BW_F1_LE_WIDTH                                1
#define REGSPEC_CTRL_ADDCAP_MRD_BW_F1_LE_SHIFT                               24
#define REGSPEC_CTRL_ADDCAP_MRD_BW_F1_LE_MASK                        0x80000000
#define REGSPEC_CTRL_ADDCAP_MRD_BW_F1_LE_RD(src)   (((src) & 0x80000000) >> 31)
#define REGSPEC_CTRL_ADDCAP_MRD_BW_F1_LE_WR(src)                                               (((unsigned int)(src) << 31) & 0x80000000)
#define REGSPEC_CTRL_ADDCAP_MRD_BW_F1_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields CTRL_AddCap_SWR_BW	 */
#define REGSPEC_CTRL_ADDCAP_SWR_BW_F1_LE_WIDTH                                1
#define REGSPEC_CTRL_ADDCAP_SWR_BW_F1_LE_SHIFT                               25
#define REGSPEC_CTRL_ADDCAP_SWR_BW_F1_LE_MASK                        0x40000000
#define REGSPEC_CTRL_ADDCAP_SWR_BW_F1_LE_RD(src)   (((src) & 0x40000000) >> 30)
#define REGSPEC_CTRL_ADDCAP_SWR_BW_F1_LE_WR(src)                                               (((unsigned int)(src) << 30) & 0x40000000)
#define REGSPEC_CTRL_ADDCAP_SWR_BW_F1_LE_SET(dst,src)                     ((dst)&~0x40000000)|\
				(((unsigned int)(src) << 30) & 0x40000000)

/*	 Fields CTRL_AddCap_MWR_BW	 */
#define REGSPEC_CTRL_ADDCAP_MWR_BW_F1_LE_WIDTH                                1
#define REGSPEC_CTRL_ADDCAP_MWR_BW_F1_LE_SHIFT                               26
#define REGSPEC_CTRL_ADDCAP_MWR_BW_F1_LE_MASK                        0x20000000
#define REGSPEC_CTRL_ADDCAP_MWR_BW_F1_LE_RD(src)   (((src) & 0x20000000) >> 29)
#define REGSPEC_CTRL_ADDCAP_MWR_BW_F1_LE_WR(src)                                               (((unsigned int)(src) << 29) & 0x20000000)
#define REGSPEC_CTRL_ADDCAP_MWR_BW_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields START_MRD_LT	 */
#define REGSPEC_START_MRD_LT_F1_LE_WIDTH                                      1
#define REGSPEC_START_MRD_LT_F1_LE_SHIFT                                     27
#define REGSPEC_START_MRD_LT_F1_LE_MASK                              0x10000000
#define REGSPEC_START_MRD_LT_F1_LE_RD(src)         (((src) & 0x10000000) >> 28)
#define REGSPEC_START_MRD_LT_F1_LE_WR(src)    (((unsigned int)(src) << 28) & 0x10000000)
#define REGSPEC_START_MRD_LT_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields START_SRD_BW	 */
#define REGSPEC_START_SRD_BW_F1_LE_WIDTH                                      1
#define REGSPEC_START_SRD_BW_F1_LE_SHIFT                                     28
#define REGSPEC_START_SRD_BW_F1_LE_MASK                              0x08000000
#define REGSPEC_START_SRD_BW_F1_LE_RD(src)         (((src) & 0x08000000) >> 27)
#define REGSPEC_START_SRD_BW_F1_LE_WR(src)    (((unsigned int)(src) << 27) & 0x08000000)
#define REGSPEC_START_SRD_BW_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields START_MRD_BW	 */
#define REGSPEC_START_MRD_BW_F1_LE_WIDTH                                      1
#define REGSPEC_START_MRD_BW_F1_LE_SHIFT                                     29
#define REGSPEC_START_MRD_BW_F1_LE_MASK                              0x04000000
#define REGSPEC_START_MRD_BW_F1_LE_RD(src)         (((src) & 0x04000000) >> 26)
#define REGSPEC_START_MRD_BW_F1_LE_WR(src)    (((unsigned int)(src) << 26) & 0x04000000)
#define REGSPEC_START_MRD_BW_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields START_SWR_BW	 */
#define REGSPEC_START_SWR_BW_F1_LE_WIDTH                                      1
#define REGSPEC_START_SWR_BW_F1_LE_SHIFT                                     30
#define REGSPEC_START_SWR_BW_F1_LE_MASK                              0x02000000
#define REGSPEC_START_SWR_BW_F1_LE_RD(src)         (((src) & 0x02000000) >> 25)
#define REGSPEC_START_SWR_BW_F1_LE_WR(src)    (((unsigned int)(src) << 25) & 0x02000000)
#define REGSPEC_START_SWR_BW_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields START_MWR_BW	 */
#define REGSPEC_START_MWR_BW_F1_LE_WIDTH                                      1
#define REGSPEC_START_MWR_BW_F1_LE_SHIFT                                     31
#define REGSPEC_START_MWR_BW_F1_LE_MASK                              0x01000000
#define REGSPEC_START_MWR_BW_F1_LE_RD(src)         (((src) & 0x01000000) >> 24)
#define REGSPEC_START_MWR_BW_F1_LE_WR(src)    (((unsigned int)(src) << 24) & 0x01000000)
#define REGSPEC_START_MWR_BW_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register CFG_BW_MSTR_STOP_CNT	*/

/*	 Fields MSTR_STOP_RD_CNT	 */
#define REGSPEC_MSTR_STOP_RD_CNT_F1_LE_WIDTH                                 16
#define REGSPEC_MSTR_STOP_RD_CNT_F1_LE_SHIFT                                 15
#define REGSPEC_MSTR_STOP_RD_CNT_F1_LE_MASK                          0x0000ffff
#define REGSPEC_MSTR_STOP_RD_CNT_F1_LE_RD(src)                (((src) & 0x0000ff00 )>> 8) | \
				(((src) & 0x000000ff) << 8)
#define REGSPEC_MSTR_STOP_RD_CNT_F1_LE_WR(src)       (((unsigned int)(src) << 8) & 0x0000ff00) | \
				(((unsigned int)(src) >> 8) & 0x000000ff)
#define REGSPEC_MSTR_STOP_RD_CNT_F1_LE_SET(dst,src) ((dst) & ~0x0000ffff) | \
	(((unsigned int)(src) << 8) & 0x0000ff00) | (((unsigned int)(src) >> 8) & 0x000000ff)

/*	 Fields MSTR_STOP_WR_CNT	 */
#define REGSPEC_MSTR_STOP_WR_CNT_F1_LE_WIDTH                                 16
#define REGSPEC_MSTR_STOP_WR_CNT_F1_LE_SHIFT                                 31
#define REGSPEC_MSTR_STOP_WR_CNT_F1_LE_MASK                          0xffff0000
#define REGSPEC_MSTR_STOP_WR_CNT_F1_LE_RD(src)               	(((src) & 0xff000000) >> 24) |\
				(((src) & 0x00ff0000) >> 8)
#define REGSPEC_MSTR_STOP_WR_CNT_F1_LE_WR(src)      	(((unsigned int)(src) << 24) & 0xff000000) |\
				(((unsigned int)(src) << 8) & 0x00ff0000)
#define REGSPEC_MSTR_STOP_WR_CNT_F1_LE_SET(dst,src) ((dst)&~0xffff0000)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00ff0000)

/*	Register CFG_BW_SLV_STOP_CNT	*/

/*	 Fields SLV_STOP_RD_CNT	 */
#define REGSPEC_SLV_STOP_RD_CNT_F1_LE_WIDTH                                  16
#define REGSPEC_SLV_STOP_RD_CNT_F1_LE_SHIFT                                  15
#define REGSPEC_SLV_STOP_RD_CNT_F1_LE_MASK                           0x0000ffff
#define REGSPEC_SLV_STOP_RD_CNT_F1_LE_RD(src)                (((src) & 0x0000ff00 )>> 8) | \
				(((src) & 0x000000ff) << 8)
#define REGSPEC_SLV_STOP_RD_CNT_F1_LE_WR(src)       (((unsigned int)(src) << 8) & 0x0000ff00) | \
				(((unsigned int)(src) >> 8) & 0x000000ff)
#define REGSPEC_SLV_STOP_RD_CNT_F1_LE_SET(dst,src) ((dst) & ~0x0000ffff) | \
	(((unsigned int)(src) << 8) & 0x0000ff00) | (((unsigned int)(src) >> 8) & 0x000000ff)

/*	 Fields SLV_STOP_WR_CNT	 */
#define REGSPEC_SLV_STOP_WR_CNT_F1_LE_WIDTH                                  16
#define REGSPEC_SLV_STOP_WR_CNT_F1_LE_SHIFT                                  31
#define REGSPEC_SLV_STOP_WR_CNT_F1_LE_MASK                           0xffff0000
#define REGSPEC_SLV_STOP_WR_CNT_F1_LE_RD(src)               	(((src) & 0xff000000) >> 24) |\
				(((src) & 0x00ff0000) >> 8)
#define REGSPEC_SLV_STOP_WR_CNT_F1_LE_WR(src)      	(((unsigned int)(src) << 24) & 0xff000000) |\
				(((unsigned int)(src) << 8) & 0x00ff0000)
#define REGSPEC_SLV_STOP_WR_CNT_F1_LE_SET(dst,src) ((dst)&~0xffff0000)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00ff0000)

/*	Register STS_READ_LATENCY_OUTPUT	*/

/*	 Fields READ_TOT	 */
#define REGSPEC_READ_TOT_F1_LE_WIDTH                                         22
#define REGSPEC_READ_TOT_F1_LE_SHIFT                                         31
#define REGSPEC_READ_TOT_F1_LE_MASK                                  0xffff3f00
#define REGSPEC_READ_TOT_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24)| \
		(((src) & 0x00ff0000) >> 8) |(((src) & 0x00003f00) << 8)
#define REGSPEC_READ_TOT_F1_LE_SET(dst,src) ((dst)&~0xffff3f00)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00ff0000) | \
 			 (((unsigned int)(src) >> 8) & 0x00003f00)

/*	Register STS_AXI_MRD_BW_CLK_CNT	*/

/*	 Fields MSTR_READ_BW_CLK_CNT	 */
#define REGSPEC_MSTR_READ_BW_CLK_CNT_F1_LE_WIDTH                             32
#define REGSPEC_MSTR_READ_BW_CLK_CNT_F1_LE_SHIFT                             31
#define REGSPEC_MSTR_READ_BW_CLK_CNT_F1_LE_MASK                      0xffffffff
#define REGSPEC_MSTR_READ_BW_CLK_CNT_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define REGSPEC_MSTR_READ_BW_CLK_CNT_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register STS_AXI_MRD_BW_BYTE_CNT	*/

/*	 Fields MSTR_READ_BW_BYTE_CNT	 */
#define REGSPEC_MSTR_READ_BW_BYTE_CNT_F1_LE_WIDTH                            32
#define REGSPEC_MSTR_READ_BW_BYTE_CNT_F1_LE_SHIFT                            31
#define REGSPEC_MSTR_READ_BW_BYTE_CNT_F1_LE_MASK                     0xffffffff
#define REGSPEC_MSTR_READ_BW_BYTE_CNT_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define REGSPEC_MSTR_READ_BW_BYTE_CNT_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register STS_AXI_MWR_BW_CLK_CNT	*/

/*	 Fields MSTR_WRITE_BW_CLK_CNT	 */
#define REGSPEC_MSTR_WRITE_BW_CLK_CNT_F1_LE_WIDTH                            32
#define REGSPEC_MSTR_WRITE_BW_CLK_CNT_F1_LE_SHIFT                            31
#define REGSPEC_MSTR_WRITE_BW_CLK_CNT_F1_LE_MASK                     0xffffffff
#define REGSPEC_MSTR_WRITE_BW_CLK_CNT_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define REGSPEC_MSTR_WRITE_BW_CLK_CNT_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register STS_AXI_MWR_BW_BYTE_CNT	*/

/*	 Fields MSTR_WRITE_BW_BYTE_CNT	 */
#define REGSPEC_MSTR_WRITE_BW_BYTE_CNT_F1_LE_WIDTH                           32
#define REGSPEC_MSTR_WRITE_BW_BYTE_CNT_F1_LE_SHIFT                           31
#define REGSPEC_MSTR_WRITE_BW_BYTE_CNT_F1_LE_MASK                    0xffffffff
#define REGSPEC_MSTR_WRITE_BW_BYTE_CNT_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define REGSPEC_MSTR_WRITE_BW_BYTE_CNT_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register STS_AXI_SRD_BW_CLK_CNT	*/

/*	 Fields SLV_READ_BW_CLK_CNT	 */
#define REGSPEC_SLV_READ_BW_CLK_CNT_F1_LE_WIDTH                              32
#define REGSPEC_SLV_READ_BW_CLK_CNT_F1_LE_SHIFT                              31
#define REGSPEC_SLV_READ_BW_CLK_CNT_F1_LE_MASK                       0xffffffff
#define REGSPEC_SLV_READ_BW_CLK_CNT_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define REGSPEC_SLV_READ_BW_CLK_CNT_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register STS_AXI_SRD_BW_BYTE_CNT	*/

/*	 Fields SLV_READ_BW_BYTE_CNT	 */
#define REGSPEC_SLV_READ_BW_BYTE_CNT_F1_LE_WIDTH                             32
#define REGSPEC_SLV_READ_BW_BYTE_CNT_F1_LE_SHIFT                             31
#define REGSPEC_SLV_READ_BW_BYTE_CNT_F1_LE_MASK                      0xffffffff
#define REGSPEC_SLV_READ_BW_BYTE_CNT_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define REGSPEC_SLV_READ_BW_BYTE_CNT_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register STS_AXI_SWR_BW_CLK_CNT	*/

/*	 Fields SLV_WRITE_BW_CLK_CNT	 */
#define REGSPEC_SLV_WRITE_BW_CLK_CNT_F1_LE_WIDTH                             32
#define REGSPEC_SLV_WRITE_BW_CLK_CNT_F1_LE_SHIFT                             31
#define REGSPEC_SLV_WRITE_BW_CLK_CNT_F1_LE_MASK                      0xffffffff
#define REGSPEC_SLV_WRITE_BW_CLK_CNT_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define REGSPEC_SLV_WRITE_BW_CLK_CNT_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register STS_AXI_SWR_BW_BYTE_CNT	*/

/*	 Fields SLV_WRITE_BW_BYTE_CNT	 */
#define REGSPEC_SLV_WRITE_BW_BYTE_CNT_F1_LE_WIDTH                            32
#define REGSPEC_SLV_WRITE_BW_BYTE_CNT_F1_LE_SHIFT                            31
#define REGSPEC_SLV_WRITE_BW_BYTE_CNT_F1_LE_MASK                     0xffffffff
#define REGSPEC_SLV_WRITE_BW_BYTE_CNT_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define REGSPEC_SLV_WRITE_BW_BYTE_CNT_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register CFG_DBG_TRIG_CTRL	*/

/*	 Fields TRIG_EN_OUT_CTRL	 */
#define REGSPEC_TRIG_EN_OUT_CTRL_F1_LE_WIDTH                                  1
#define REGSPEC_TRIG_EN_OUT_CTRL_F1_LE_SHIFT                                 26
#define REGSPEC_TRIG_EN_OUT_CTRL_F1_LE_MASK                          0x20000000
#define REGSPEC_TRIG_EN_OUT_CTRL_F1_LE_RD(src)     (((src) & 0x20000000) >> 29)
#define REGSPEC_TRIG_EN_OUT_CTRL_F1_LE_WR(src)                                               (((unsigned int)(src) << 29) & 0x20000000)
#define REGSPEC_TRIG_EN_OUT_CTRL_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields TRIG_EN	 */
#define REGSPEC_TRIG_EN_F1_LE_WIDTH                                           1
#define REGSPEC_TRIG_EN_F1_LE_SHIFT                                          27
#define REGSPEC_TRIG_EN_F1_LE_MASK                                   0x10000000
#define REGSPEC_TRIG_EN_F1_LE_RD(src)              (((src) & 0x10000000) >> 28)
#define REGSPEC_TRIG_EN_F1_LE_WR(src)         (((unsigned int)(src) << 28) & 0x10000000)
#define REGSPEC_TRIG_EN_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields AND_E	 */
#define REGSPEC_AND_E_F1_LE_WIDTH                                             2
#define REGSPEC_AND_E_F1_LE_SHIFT                                            29
#define REGSPEC_AND_E_F1_LE_MASK                                     0x0c000000
#define REGSPEC_AND_E_F1_LE_RD(src)                (((src) & 0x0c000000) >> 26)
#define REGSPEC_AND_E_F1_LE_WR(src)           (((unsigned int)(src) << 26) & 0x0c000000)
#define REGSPEC_AND_E_F1_LE_SET(dst,src)                     ((dst)&~0x0c000000)|\
				(((unsigned int)(src) << 26) & 0x0c000000)

/*	 Fields OR_E	 */
#define REGSPEC_OR_E_F1_LE_WIDTH                                              2
#define REGSPEC_OR_E_F1_LE_SHIFT                                             31
#define REGSPEC_OR_E_F1_LE_MASK                                      0x03000000
#define REGSPEC_OR_E_F1_LE_RD(src)                 (((src) & 0x03000000) >> 24)
#define REGSPEC_OR_E_F1_LE_WR(src)            (((unsigned int)(src) << 24) & 0x03000000)
#define REGSPEC_OR_E_F1_LE_SET(dst,src)                     ((dst)&~0x03000000)|\
				(((unsigned int)(src) << 24) & 0x03000000)

/*	Register CFG_DBG_PAT_REG_0	*/

/*	 Fields PATTERN	 */
#define REGSPEC_PATTERN0_F1_LE_WIDTH                                         32
#define REGSPEC_PATTERN0_F1_LE_SHIFT                                         31
#define REGSPEC_PATTERN0_F1_LE_MASK                                  0xffffffff
#define REGSPEC_PATTERN0_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define REGSPEC_PATTERN0_F1_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define REGSPEC_PATTERN0_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register CFG_DBG_PAT_MASK_REG_0	*/

/*	 Fields PAT_MASK	 */
#define REGSPEC_PAT_MASK0_F1_LE_WIDTH                                        32
#define REGSPEC_PAT_MASK0_F1_LE_SHIFT                                        31
#define REGSPEC_PAT_MASK0_F1_LE_MASK                                 0xffffffff
#define REGSPEC_PAT_MASK0_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define REGSPEC_PAT_MASK0_F1_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define REGSPEC_PAT_MASK0_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register CFG_DBG_PAT_REG_1	*/

/*	 Fields PATTERN	 */
#define REGSPEC_PATTERN1_F1_LE_WIDTH                                         32
#define REGSPEC_PATTERN1_F1_LE_SHIFT                                         31
#define REGSPEC_PATTERN1_F1_LE_MASK                                  0xffffffff
#define REGSPEC_PATTERN1_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define REGSPEC_PATTERN1_F1_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define REGSPEC_PATTERN1_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register CFG_DBG_PAT_MASK_REG_1	*/

/*	 Fields PAT_MASK	 */
#define REGSPEC_PAT_MASK1_F1_LE_WIDTH                                        32
#define REGSPEC_PAT_MASK1_F1_LE_SHIFT                                        31
#define REGSPEC_PAT_MASK1_F1_LE_MASK                                 0xffffffff
#define REGSPEC_PAT_MASK1_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define REGSPEC_PAT_MASK1_F1_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define REGSPEC_PAT_MASK1_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register DBG_TRIG_OUT	*/

/*	 Fields DBG_OUT	 */
#define REGSPEC_DBG_OUT_F1_LE_WIDTH                                          32
#define REGSPEC_DBG_OUT_F1_LE_SHIFT                                          31
#define REGSPEC_DBG_OUT_F1_LE_MASK                                   0xffffffff
#define REGSPEC_DBG_OUT_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define REGSPEC_DBG_OUT_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register DBG_TRIG_INT	*/

/*	 Fields DBG_INT	 */
#define REGSPEC_DBG_INT_F1_LE_WIDTH                                           1
#define REGSPEC_DBG_INT_F1_LE_SHIFT                                          31
#define REGSPEC_DBG_INT_F1_LE_MASK                                   0x01000000
#define REGSPEC_DBG_INT_F1_LE_RD(src)              (((src) & 0x01000000) >> 24)
#define REGSPEC_DBG_INT_F1_LE_WR(src)         (((unsigned int)(src) << 24) & 0x01000000)
#define REGSPEC_DBG_INT_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register DBG_TRIG_INTMask	*/

/*Mask Register Fields DBG_INTMask	 */
#define REGSPEC_DBG_INTMASK_F1_LE_WIDTH                                       1
#define REGSPEC_DBG_INTMASK_F1_LE_SHIFT                                      31
#define REGSPEC_DBG_INTMASK_F1_LE_MASK                               0x01000000
#define REGSPEC_DBG_INTMASK_F1_LE_RD(src)          (((src) & 0x01000000) >> 24)
#define REGSPEC_DBG_INTMASK_F1_LE_WR(src)     (((unsigned int)(src) << 24) & 0x01000000)
#define REGSPEC_DBG_INTMASK_F1_LE_SET(dst,src)                      ((dst)&~0x01000000)|\
			(((unsigned int)(src) << 24) & 0x01000000)

/*	Register INTR_STS	*/

/*	 Fields DIAGMOD_INT	 */
#define REGSPEC_DIAGMOD_INT_F1_LE_WIDTH                                       1
#define REGSPEC_DIAGMOD_INT_F1_LE_SHIFT                                      30
#define REGSPEC_DIAGMOD_INT_F1_LE_MASK                               0x02000000
#define REGSPEC_DIAGMOD_INT_F1_LE_RD(src)          (((src) & 0x02000000) >> 25)
#define REGSPEC_DIAGMOD_INT_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields ERRMOD_INT	 */
#define REGSPEC_ERRMOD_INT_F1_LE_WIDTH                                        1
#define REGSPEC_ERRMOD_INT_F1_LE_SHIFT                                       31
#define REGSPEC_ERRMOD_INT_F1_LE_MASK                                0x01000000
#define REGSPEC_ERRMOD_INT_F1_LE_RD(src)           (((src) & 0x01000000) >> 24)
#define REGSPEC_ERRMOD_INT_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register CFG_MEM_ECC_BYPASS	*/

/*	 Fields CFG_ECC_BYPASS	 */
#define REGSPEC_CFG_ECC_BYPASS_F1_LE_WIDTH                                   16
#define REGSPEC_CFG_ECC_BYPASS_F1_LE_SHIFT                                   31
#define REGSPEC_CFG_ECC_BYPASS_F1_LE_MASK                            0xffff0000
#define REGSPEC_CFG_ECC_BYPASS_F1_LE_RD(src)               	(((src) & 0xff000000) >> 24) |\
				(((src) & 0x00ff0000) >> 8)
#define REGSPEC_CFG_ECC_BYPASS_F1_LE_WR(src)      	(((unsigned int)(src) << 24) & 0xff000000) |\
				(((unsigned int)(src) << 8) & 0x00ff0000)
#define REGSPEC_CFG_ECC_BYPASS_F1_LE_SET(dst,src) ((dst)&~0xffff0000)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00ff0000)

/*	Register CFG_MEM_PWRDN_DIS	*/

/*	 Fields CFG_ECC_PWRDN_DIS	 */
#define REGSPEC_CFG_ECC_PWRDN_DIS_F1_LE_WIDTH                                16
#define REGSPEC_CFG_ECC_PWRDN_DIS_F1_LE_SHIFT                                15
#define REGSPEC_CFG_ECC_PWRDN_DIS_F1_LE_MASK                         0x0000ffff
#define REGSPEC_CFG_ECC_PWRDN_DIS_F1_LE_RD(src)                (((src) & 0x0000ff00 )>> 8) | \
				(((src) & 0x000000ff) << 8)
#define REGSPEC_CFG_ECC_PWRDN_DIS_F1_LE_WR(src)       (((unsigned int)(src) << 8) & 0x0000ff00) | \
				(((unsigned int)(src) >> 8) & 0x000000ff)
#define REGSPEC_CFG_ECC_PWRDN_DIS_F1_LE_SET(dst,src) ((dst) & ~0x0000ffff) | \
	(((unsigned int)(src) << 8) & 0x0000ff00) | (((unsigned int)(src) >> 8) & 0x000000ff)

/*	 Fields CFG_PWRDN_DIS	 */
#define REGSPEC_CFG_PWRDN_DIS_F1_LE_WIDTH                                    16
#define REGSPEC_CFG_PWRDN_DIS_F1_LE_SHIFT                                    31
#define REGSPEC_CFG_PWRDN_DIS_F1_LE_MASK                             0xffff0000
#define REGSPEC_CFG_PWRDN_DIS_F1_LE_RD(src)               	(((src) & 0xff000000) >> 24) |\
				(((src) & 0x00ff0000) >> 8)
#define REGSPEC_CFG_PWRDN_DIS_F1_LE_WR(src)      	(((unsigned int)(src) << 24) & 0xff000000) |\
				(((unsigned int)(src) << 8) & 0x00ff0000)
#define REGSPEC_CFG_PWRDN_DIS_F1_LE_SET(dst,src) ((dst)&~0xffff0000)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00ff0000)

/*	Register CFG_MEM_RAM_SHUTDOWN	*/

/*	 Fields CFG_RAM_SHUTDOWN_EN	 */
#define REGSPEC_CFG_RAM_SHUTDOWN_EN_F1_LE_WIDTH                              32
#define REGSPEC_CFG_RAM_SHUTDOWN_EN_F1_LE_SHIFT                              31
#define REGSPEC_CFG_RAM_SHUTDOWN_EN_F1_LE_MASK                       0xffffffff
#define REGSPEC_CFG_RAM_SHUTDOWN_EN_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define REGSPEC_CFG_RAM_SHUTDOWN_EN_F1_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define REGSPEC_CFG_RAM_SHUTDOWN_EN_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register BLOCK_MEM_RDY	*/

/*	 Fields MEM_RDY	 */
#define REGSPEC_MEM_RDY_F1_LE_WIDTH                                          32
#define REGSPEC_MEM_RDY_F1_LE_SHIFT                                          31
#define REGSPEC_MEM_RDY_F1_LE_MASK                                   0xffffffff
#define REGSPEC_MEM_RDY_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define REGSPEC_MEM_RDY_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register STS_READ_LATENCY_TOT_READ_REQS	*/

/*	 Fields TOT_READS	 */
#define REGSPEC_TOT_READS_F1_LE_WIDTH                                        16
#define REGSPEC_TOT_READS_F1_LE_SHIFT                                        15
#define REGSPEC_TOT_READS_F1_LE_MASK                                 0x0000ffff
#define REGSPEC_TOT_READS_F1_LE_RD(src)                (((src) & 0x0000ff00 )>> 8) | \
				(((src) & 0x000000ff) << 8)
#define REGSPEC_TOT_READS_F1_LE_SET(dst,src) ((dst) & ~0x0000ffff) | \
	(((unsigned int)(src) << 8) & 0x0000ff00) | (((unsigned int)(src) >> 8) & 0x000000ff)

/*	Register CFG_LT_MSTR_STOP_CNT	*/

/*	 Fields MSTR_LT_STOP_CNT	 */
#define REGSPEC_MSTR_LT_STOP_CNT_F1_LE_WIDTH                                 16
#define REGSPEC_MSTR_LT_STOP_CNT_F1_LE_SHIFT                                 15
#define REGSPEC_MSTR_LT_STOP_CNT_F1_LE_MASK                          0x0000ffff
#define REGSPEC_MSTR_LT_STOP_CNT_F1_LE_RD(src)                (((src) & 0x0000ff00 )>> 8) | \
				(((src) & 0x000000ff) << 8)
#define REGSPEC_MSTR_LT_STOP_CNT_F1_LE_WR(src)       (((unsigned int)(src) << 8) & 0x0000ff00) | \
				(((unsigned int)(src) >> 8) & 0x000000ff)
#define REGSPEC_MSTR_LT_STOP_CNT_F1_LE_SET(dst,src) ((dst) & ~0x0000ffff) | \
	(((unsigned int)(src) << 8) & 0x0000ff00) | (((unsigned int)(src) >> 8) & 0x000000ff)

/*	Register CFG_BW_SRD_TRIG_CAP	*/

/*	 Fields CAP_ADD_BWSRD	 */
#define REGSPEC_CAP_ADD_BWSRD_F1_LE_WIDTH                                    32
#define REGSPEC_CAP_ADD_BWSRD_F1_LE_SHIFT                                    31
#define REGSPEC_CAP_ADD_BWSRD_F1_LE_MASK                             0xffffffff
#define REGSPEC_CAP_ADD_BWSRD_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define REGSPEC_CAP_ADD_BWSRD_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register CFG_BW_SWR_TRIG_CAP	*/

/*	 Fields CAP_ADD_BWSWR	 */
#define REGSPEC_CAP_ADD_BWSWR_F1_LE_WIDTH                                    32
#define REGSPEC_CAP_ADD_BWSWR_F1_LE_SHIFT                                    31
#define REGSPEC_CAP_ADD_BWSWR_F1_LE_MASK                             0xffffffff
#define REGSPEC_CAP_ADD_BWSWR_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define REGSPEC_CAP_ADD_BWSWR_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register CFG_BW_MRD_TRIG_CAP	*/

/*	 Fields CAP_ADD_BWMRD	 */
#define REGSPEC_CAP_ADD_BWMRD_F1_LE_WIDTH                                    32
#define REGSPEC_CAP_ADD_BWMRD_F1_LE_SHIFT                                    31
#define REGSPEC_CAP_ADD_BWMRD_F1_LE_MASK                             0xffffffff
#define REGSPEC_CAP_ADD_BWMRD_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define REGSPEC_CAP_ADD_BWMRD_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register CFG_BW_MWR_TRIG_CAP	*/

/*	 Fields CAP_ADD_BWMWR	 */
#define REGSPEC_CAP_ADD_BWMWR_F1_LE_WIDTH                                    32
#define REGSPEC_CAP_ADD_BWMWR_F1_LE_SHIFT                                    31
#define REGSPEC_CAP_ADD_BWMWR_F1_LE_MASK                             0xffffffff
#define REGSPEC_CAP_ADD_BWMWR_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define REGSPEC_CAP_ADD_BWMWR_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register CFG_LT_MRD_TRIG_CAP	*/

/*	 Fields CAP_ADD_LTMRD	 */
#define REGSPEC_CAP_ADD_LTMRD_F1_LE_WIDTH                                    32
#define REGSPEC_CAP_ADD_LTMRD_F1_LE_SHIFT                                    31
#define REGSPEC_CAP_ADD_LTMRD_F1_LE_MASK                             0xffffffff
#define REGSPEC_CAP_ADD_LTMRD_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define REGSPEC_CAP_ADD_LTMRD_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register DBG_BLOCK_AXI	*/

/*	 Fields DBG_BUS_BLOCK_AXI	 */
#define REGSPEC_DBG_BUS_BLOCK_AXI_F1_LE_WIDTH                                32
#define REGSPEC_DBG_BUS_BLOCK_AXI_F1_LE_SHIFT                                31
#define REGSPEC_DBG_BUS_BLOCK_AXI_F1_LE_MASK                         0xffffffff
#define REGSPEC_DBG_BUS_BLOCK_AXI_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define REGSPEC_DBG_BUS_BLOCK_AXI_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register DBG_BLOCK_NON_AXI	*/

/*	 Fields DBG_BUS_BLOCK_NON_AXI	 */
#define REGSPEC_DBG_BUS_BLOCK_NON_AXI_F1_LE_WIDTH                            32
#define REGSPEC_DBG_BUS_BLOCK_NON_AXI_F1_LE_SHIFT                            31
#define REGSPEC_DBG_BUS_BLOCK_NON_AXI_F1_LE_MASK                     0xffffffff
#define REGSPEC_DBG_BUS_BLOCK_NON_AXI_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define REGSPEC_DBG_BUS_BLOCK_NON_AXI_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register DBG_AXI_SHIM_OUT	*/

/*	 Fields DBG_BUS_SHIM	 */
#define REGSPEC_DBG_BUS_SHIM_F1_LE_WIDTH                                     32
#define REGSPEC_DBG_BUS_SHIM_F1_LE_SHIFT                                     31
#define REGSPEC_DBG_BUS_SHIM_F1_LE_MASK                              0xffffffff
#define REGSPEC_DBG_BUS_SHIM_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define REGSPEC_DBG_BUS_SHIM_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Global Base Address	*/
#define GLBL_ERR_CSR_BASE_ADDR			(QM_CSR_BASE_ADDR + 0xd800)

/*    Address GLBL_ERR_CSR  Registers */
#define GLBL_ERR_STS_ADDR                                            0x00000800
#define GLBL_ERR_STS_DEFAULT                                         0x00000000
#define GLBL_SEC_ERRL_ADDR                                           0x00000810
#define GLBL_SEC_ERRL_DEFAULT                                        0x00000000
#define GLBL_SEC_ERRLMASK_ADDR                                       0x00000814
#define GLBL_SEC_ERRH_ADDR                                           0x00000818
#define GLBL_SEC_ERRH_DEFAULT                                        0x00000000
#define GLBL_SEC_ERRHMASK_ADDR                                       0x0000081c
#define GLBL_MSEC_ERRL_ADDR                                          0x00000820
#define GLBL_MSEC_ERRL_DEFAULT                                       0x00000000
#define GLBL_MSEC_ERRLMASK_ADDR                                      0x00000824
#define GLBL_MSEC_ERRH_ADDR                                          0x00000828
#define GLBL_MSEC_ERRH_DEFAULT                                       0x00000000
#define GLBL_MSEC_ERRHMASK_ADDR                                      0x0000082c
#define GLBL_DED_ERRL_ADDR                                           0x00000830
#define GLBL_DED_ERRL_DEFAULT                                        0x00000000
#define GLBL_DED_ERRLMASK_ADDR                                       0x00000834
#define GLBL_DED_ERRH_ADDR                                           0x00000838
#define GLBL_DED_ERRH_DEFAULT                                        0x00000000
#define GLBL_DED_ERRHMASK_ADDR                                       0x0000083c
#define GLBL_MDED_ERRL_ADDR                                          0x00000840
#define GLBL_MDED_ERRL_DEFAULT                                       0x00000000
#define GLBL_MDED_ERRLMASK_ADDR                                      0x00000844
#define GLBL_MDED_ERRH_ADDR                                          0x00000848
#define GLBL_MDED_ERRH_DEFAULT                                       0x00000000
#define GLBL_MDED_ERRHMASK_ADDR                                      0x0000084c
#define GLBL_MERR_ADDR_ADDR                                          0x00000850
#define GLBL_MERR_ADDR_DEFAULT                                       0x00000000
#define GLBL_MERR_REQINFO_ADDR                                       0x00000854
#define GLBL_MERR_REQINFO_DEFAULT                                    0x00000000
#define GLBL_TRANS_ERR_ADDR                                          0x00000860
#define GLBL_TRANS_ERR_DEFAULT                                       0x00000000
#define GLBL_TRANS_ERRMASK_ADDR                                      0x00000864
#define GLBL_WDERR_ADDR_ADDR                                         0x00000870
#define GLBL_WDERR_ADDR_DEFAULT                                      0x00000000
#define GLBL_WDERR_REQINFO_ADDR                                      0x00000874
#define GLBL_WDERR_REQINFO_DEFAULT                                   0x00000000
#define GLBL_DEVERR_ADDR_ADDR                                        0x00000878
#define GLBL_DEVERR_ADDR_DEFAULT                                     0x00000000
#define GLBL_DEVERR_REQINFO_ADDR                                     0x0000087c
#define GLBL_DEVERR_REQINFO_DEFAULT                                  0x00000000
#define GLBL_SEC_ERRL_ALS_ADDR                                       0x00000880
#define GLBL_SEC_ERRL_ALS_DEFAULT                                    0x00000000
#define GLBL_SEC_ERRH_ALS_ADDR                                       0x00000884
#define GLBL_SEC_ERRH_ALS_DEFAULT                                    0x00000000
#define GLBL_DED_ERRL_ALS_ADDR                                       0x00000888
#define GLBL_DED_ERRL_ALS_DEFAULT                                    0x00000000
#define GLBL_DED_ERRH_ALS_ADDR                                       0x0000088c
#define GLBL_DED_ERRH_ALS_DEFAULT                                    0x00000000
#define GLBL_TRANS_ERR_ALS_ADDR                                      0x00000890
#define GLBL_TRANS_ERR_ALS_DEFAULT                                   0x00000000

/*	Register GLBL_ERR_STS	*/

/*	 Fields SHIM_ERR	 */
#define SHIM_ERR_F1_LE_WIDTH                                                  1
#define SHIM_ERR_F1_LE_SHIFT                                                 26
#define SHIM_ERR_F1_LE_MASK                                          0x20000000
#define SHIM_ERR_F1_LE_RD(src)                     (((src) & 0x20000000) >> 29)
#define SHIM_ERR_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields TRANS_ERR	 */
#define TRANS_ERR_F1_LE_WIDTH                                                 1
#define TRANS_ERR_F1_LE_SHIFT                                                27
#define TRANS_ERR_F1_LE_MASK                                         0x10000000
#define TRANS_ERR_F1_LE_RD(src)                    (((src) & 0x10000000) >> 28)
#define TRANS_ERR_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields MDED_ERR	 */
#define MDED_ERR_F1_LE_WIDTH                                                  1
#define MDED_ERR_F1_LE_SHIFT                                                 28
#define MDED_ERR_F1_LE_MASK                                          0x08000000
#define MDED_ERR_F1_LE_RD(src)                     (((src) & 0x08000000) >> 27)
#define MDED_ERR_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields DED_ERR	 */
#define DED_ERR_F1_LE_WIDTH                                                   1
#define DED_ERR_F1_LE_SHIFT                                                  29
#define DED_ERR_F1_LE_MASK                                           0x04000000
#define DED_ERR_F1_LE_RD(src)                      (((src) & 0x04000000) >> 26)
#define DED_ERR_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields MSEC_ERR	 */
#define MSEC_ERR_F1_LE_WIDTH                                                  1
#define MSEC_ERR_F1_LE_SHIFT                                                 30
#define MSEC_ERR_F1_LE_MASK                                          0x02000000
#define MSEC_ERR_F1_LE_RD(src)                     (((src) & 0x02000000) >> 25)
#define MSEC_ERR_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields SEC_ERR	 */
#define SEC_ERR_F1_LE_WIDTH                                                   1
#define SEC_ERR_F1_LE_SHIFT                                                  31
#define SEC_ERR_F1_LE_MASK                                           0x01000000
#define SEC_ERR_F1_LE_RD(src)                      (((src) & 0x01000000) >> 24)
#define SEC_ERR_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register GLBL_SEC_ERRL	*/

/*	 Fields SEC31	 */
#define SEC31_F2_LE_WIDTH                                                     1
#define SEC31_F2_LE_SHIFT                                                     0
#define SEC31_F2_LE_MASK                                             0x00000080
#define SEC31_F2_LE_RD(src)                          (((src) & 0x00000080)<< 7)
#define SEC31_F2_LE_WR(src)                    (((unsigned int)(src) >> 7) & 0x00000080)
#define SEC31_F2_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields SEC30	 */
#define SEC30_F2_LE_WIDTH                                                     1
#define SEC30_F2_LE_SHIFT                                                     1
#define SEC30_F2_LE_MASK                                             0x00000040
#define SEC30_F2_LE_RD(src)                          (((src) & 0x00000040)<< 6)
#define SEC30_F2_LE_WR(src)                    (((unsigned int)(src) >> 6) & 0x00000040)
#define SEC30_F2_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields SEC29	 */
#define SEC29_F2_LE_WIDTH                                                     1
#define SEC29_F2_LE_SHIFT                                                     2
#define SEC29_F2_LE_MASK                                             0x00000020
#define SEC29_F2_LE_RD(src)                          (((src) & 0x00000020)<< 5)
#define SEC29_F2_LE_WR(src)                    (((unsigned int)(src) >> 5) & 0x00000020)
#define SEC29_F2_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*	 Fields SEC28	 */
#define SEC28_F2_LE_WIDTH                                                     1
#define SEC28_F2_LE_SHIFT                                                     3
#define SEC28_F2_LE_MASK                                             0x00000010
#define SEC28_F2_LE_RD(src)                          (((src) & 0x00000010)<< 4)
#define SEC28_F2_LE_WR(src)                    (((unsigned int)(src) >> 4) & 0x00000010)
#define SEC28_F2_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields SEC27	 */
#define SEC27_F2_LE_WIDTH                                                     1
#define SEC27_F2_LE_SHIFT                                                     4
#define SEC27_F2_LE_MASK                                             0x00000008
#define SEC27_F2_LE_RD(src)                          (((src) & 0x00000008)<< 3)
#define SEC27_F2_LE_WR(src)                    (((unsigned int)(src) >> 3) & 0x00000008)
#define SEC27_F2_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*	 Fields SEC26	 */
#define SEC26_F2_LE_WIDTH                                                     1
#define SEC26_F2_LE_SHIFT                                                     5
#define SEC26_F2_LE_MASK                                             0x00000004
#define SEC26_F2_LE_RD(src)                          (((src) & 0x00000004)<< 2)
#define SEC26_F2_LE_WR(src)                    (((unsigned int)(src) >> 2) & 0x00000004)
#define SEC26_F2_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*	 Fields SEC25	 */
#define SEC25_F2_LE_WIDTH                                                     1
#define SEC25_F2_LE_SHIFT                                                     6
#define SEC25_F2_LE_MASK                                             0x00000002
#define SEC25_F2_LE_RD(src)                          (((src) & 0x00000002)<< 1)
#define SEC25_F2_LE_WR(src)                    (((unsigned int)(src) >> 1) & 0x00000002)
#define SEC25_F2_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*	 Fields SEC24	 */
#define SEC24_F2_LE_WIDTH                                                     1
#define SEC24_F2_LE_SHIFT                                                     7
#define SEC24_F2_LE_MASK                                             0x00000001
#define SEC24_F2_LE_RD(src)                          (((src) & 0x00000001)<< 0)
#define SEC24_F2_LE_WR(src)                    (((unsigned int)(src) >> 0) & 0x00000001)
#define SEC24_F2_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*	 Fields SEC23	 */
#define SEC23_F2_LE_WIDTH                                                     1
#define SEC23_F2_LE_SHIFT                                                     8
#define SEC23_F2_LE_MASK                                             0x00008000
#define SEC23_F2_LE_RD(src)                        (((src) & 0x00008000) >> 15)
#define SEC23_F2_LE_WR(src)                   (((unsigned int)(src) << 15) & 0x00008000)
#define SEC23_F2_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*	 Fields SEC22	 */
#define SEC22_F2_LE_WIDTH                                                     1
#define SEC22_F2_LE_SHIFT                                                     9
#define SEC22_F2_LE_MASK                                             0x00004000
#define SEC22_F2_LE_RD(src)                        (((src) & 0x00004000) >> 14)
#define SEC22_F2_LE_WR(src)                   (((unsigned int)(src) << 14) & 0x00004000)
#define SEC22_F2_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*	 Fields SEC21	 */
#define SEC21_F2_LE_WIDTH                                                     1
#define SEC21_F2_LE_SHIFT                                                    10
#define SEC21_F2_LE_MASK                                             0x00002000
#define SEC21_F2_LE_RD(src)                        (((src) & 0x00002000) >> 13)
#define SEC21_F2_LE_WR(src)                   (((unsigned int)(src) << 13) & 0x00002000)
#define SEC21_F2_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*	 Fields SEC20	 */
#define SEC20_F2_LE_WIDTH                                                     1
#define SEC20_F2_LE_SHIFT                                                    11
#define SEC20_F2_LE_MASK                                             0x00001000
#define SEC20_F2_LE_RD(src)                        (((src) & 0x00001000) >> 12)
#define SEC20_F2_LE_WR(src)                   (((unsigned int)(src) << 12) & 0x00001000)
#define SEC20_F2_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*	 Fields SEC19	 */
#define SEC19_F2_LE_WIDTH                                                     1
#define SEC19_F2_LE_SHIFT                                                    12
#define SEC19_F2_LE_MASK                                             0x00000800
#define SEC19_F2_LE_RD(src)                        (((src) & 0x00000800) >> 11)
#define SEC19_F2_LE_WR(src)                   (((unsigned int)(src) << 11) & 0x00000800)
#define SEC19_F2_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*	 Fields SEC18	 */
#define SEC18_F2_LE_WIDTH                                                     1
#define SEC18_F2_LE_SHIFT                                                    13
#define SEC18_F2_LE_MASK                                             0x00000400
#define SEC18_F2_LE_RD(src)                        (((src) & 0x00000400) >> 10)
#define SEC18_F2_LE_WR(src)                   (((unsigned int)(src) << 10) & 0x00000400)
#define SEC18_F2_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*	 Fields SEC17	 */
#define SEC17_F2_LE_WIDTH                                                     1
#define SEC17_F2_LE_SHIFT                                                    14
#define SEC17_F2_LE_MASK                                             0x00000200
#define SEC17_F2_LE_RD(src)                         (((src) & 0x00000200) >> 9)
#define SEC17_F2_LE_WR(src)                    (((unsigned int)(src) << 9) & 0x00000200)
#define SEC17_F2_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*	 Fields SEC16	 */
#define SEC16_F2_LE_WIDTH                                                     1
#define SEC16_F2_LE_SHIFT                                                    15
#define SEC16_F2_LE_MASK                                             0x00000100
#define SEC16_F2_LE_RD(src)                         (((src) & 0x00000100) >> 8)
#define SEC16_F2_LE_WR(src)                    (((unsigned int)(src) << 8) & 0x00000100)
#define SEC16_F2_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*	 Fields SEC15	 */
#define SEC15_F2_LE_WIDTH                                                     1
#define SEC15_F2_LE_SHIFT                                                    16
#define SEC15_F2_LE_MASK                                             0x00800000
#define SEC15_F2_LE_RD(src)                        (((src) & 0x00800000) >> 23)
#define SEC15_F2_LE_WR(src)                   (((unsigned int)(src) << 23) & 0x00800000)
#define SEC15_F2_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*	 Fields SEC14	 */
#define SEC14_F2_LE_WIDTH                                                     1
#define SEC14_F2_LE_SHIFT                                                    17
#define SEC14_F2_LE_MASK                                             0x00400000
#define SEC14_F2_LE_RD(src)                        (((src) & 0x00400000) >> 22)
#define SEC14_F2_LE_WR(src)                   (((unsigned int)(src) << 22) & 0x00400000)
#define SEC14_F2_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*	 Fields SEC13	 */
#define SEC13_F2_LE_WIDTH                                                     1
#define SEC13_F2_LE_SHIFT                                                    18
#define SEC13_F2_LE_MASK                                             0x00200000
#define SEC13_F2_LE_RD(src)                        (((src) & 0x00200000) >> 21)
#define SEC13_F2_LE_WR(src)                   (((unsigned int)(src) << 21) & 0x00200000)
#define SEC13_F2_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*	 Fields SEC12	 */
#define SEC12_F2_LE_WIDTH                                                     1
#define SEC12_F2_LE_SHIFT                                                    19
#define SEC12_F2_LE_MASK                                             0x00100000
#define SEC12_F2_LE_RD(src)                        (((src) & 0x00100000) >> 20)
#define SEC12_F2_LE_WR(src)                   (((unsigned int)(src) << 20) & 0x00100000)
#define SEC12_F2_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields SEC11	 */
#define SEC11_F2_LE_WIDTH                                                     1
#define SEC11_F2_LE_SHIFT                                                    20
#define SEC11_F2_LE_MASK                                             0x00080000
#define SEC11_F2_LE_RD(src)                        (((src) & 0x00080000) >> 19)
#define SEC11_F2_LE_WR(src)                   (((unsigned int)(src) << 19) & 0x00080000)
#define SEC11_F2_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*	 Fields SEC10	 */
#define SEC10_F2_LE_WIDTH                                                     1
#define SEC10_F2_LE_SHIFT                                                    21
#define SEC10_F2_LE_MASK                                             0x00040000
#define SEC10_F2_LE_RD(src)                        (((src) & 0x00040000) >> 18)
#define SEC10_F2_LE_WR(src)                   (((unsigned int)(src) << 18) & 0x00040000)
#define SEC10_F2_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*	 Fields SEC9	 */
#define SEC9_F2_LE_WIDTH                                                      1
#define SEC9_F2_LE_SHIFT                                                     22
#define SEC9_F2_LE_MASK                                              0x00020000
#define SEC9_F2_LE_RD(src)                         (((src) & 0x00020000) >> 17)
#define SEC9_F2_LE_WR(src)                    (((unsigned int)(src) << 17) & 0x00020000)
#define SEC9_F2_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*	 Fields SEC8	 */
#define SEC8_F2_LE_WIDTH                                                      1
#define SEC8_F2_LE_SHIFT                                                     23
#define SEC8_F2_LE_MASK                                              0x00010000
#define SEC8_F2_LE_RD(src)                         (((src) & 0x00010000) >> 16)
#define SEC8_F2_LE_WR(src)                    (((unsigned int)(src) << 16) & 0x00010000)
#define SEC8_F2_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*	 Fields SEC7	 */
#define SEC7_F2_LE_WIDTH                                                      1
#define SEC7_F2_LE_SHIFT                                                     24
#define SEC7_F2_LE_MASK                                              0x80000000
#define SEC7_F2_LE_RD(src)                         (((src) & 0x80000000) >> 31)
#define SEC7_F2_LE_WR(src)                    (((unsigned int)(src) << 31) & 0x80000000)
#define SEC7_F2_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields SEC6	 */
#define SEC6_F2_LE_WIDTH                                                      1
#define SEC6_F2_LE_SHIFT                                                     25
#define SEC6_F2_LE_MASK                                              0x40000000
#define SEC6_F2_LE_RD(src)                         (((src) & 0x40000000) >> 30)
#define SEC6_F2_LE_WR(src)                    (((unsigned int)(src) << 30) & 0x40000000)
#define SEC6_F2_LE_SET(dst,src)                     ((dst)&~0x40000000)|\
				(((unsigned int)(src) << 30) & 0x40000000)

/*	 Fields SEC5	 */
#define SEC5_F2_LE_WIDTH                                                      1
#define SEC5_F2_LE_SHIFT                                                     26
#define SEC5_F2_LE_MASK                                              0x20000000
#define SEC5_F2_LE_RD(src)                         (((src) & 0x20000000) >> 29)
#define SEC5_F2_LE_WR(src)                    (((unsigned int)(src) << 29) & 0x20000000)
#define SEC5_F2_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields SEC4	 */
#define SEC4_F2_LE_WIDTH                                                      1
#define SEC4_F2_LE_SHIFT                                                     27
#define SEC4_F2_LE_MASK                                              0x10000000
#define SEC4_F2_LE_RD(src)                         (((src) & 0x10000000) >> 28)
#define SEC4_F2_LE_WR(src)                    (((unsigned int)(src) << 28) & 0x10000000)
#define SEC4_F2_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields SEC3	 */
#define SEC3_F2_LE_WIDTH                                                      1
#define SEC3_F2_LE_SHIFT                                                     28
#define SEC3_F2_LE_MASK                                              0x08000000
#define SEC3_F2_LE_RD(src)                         (((src) & 0x08000000) >> 27)
#define SEC3_F2_LE_WR(src)                    (((unsigned int)(src) << 27) & 0x08000000)
#define SEC3_F2_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields SEC2	 */
#define SEC2_F2_LE_WIDTH                                                      1
#define SEC2_F2_LE_SHIFT                                                     29
#define SEC2_F2_LE_MASK                                              0x04000000
#define SEC2_F2_LE_RD(src)                         (((src) & 0x04000000) >> 26)
#define SEC2_F2_LE_WR(src)                    (((unsigned int)(src) << 26) & 0x04000000)
#define SEC2_F2_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields SEC1	 */
#define SEC1_F2_LE_WIDTH                                                      1
#define SEC1_F2_LE_SHIFT                                                     30
#define SEC1_F2_LE_MASK                                              0x02000000
#define SEC1_F2_LE_RD(src)                         (((src) & 0x02000000) >> 25)
#define SEC1_F2_LE_WR(src)                    (((unsigned int)(src) << 25) & 0x02000000)
#define SEC1_F2_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields SEC0	 */
#define SEC0_F2_LE_WIDTH                                                      1
#define SEC0_F2_LE_SHIFT                                                     31
#define SEC0_F2_LE_MASK                                              0x01000000
#define SEC0_F2_LE_RD(src)                         (((src) & 0x01000000) >> 24)
#define SEC0_F2_LE_WR(src)                    (((unsigned int)(src) << 24) & 0x01000000)
#define SEC0_F2_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register GLBL_SEC_ERRLMask	*/

/*Mask Register Fields SEC31Mask	 */
#define SEC31MASK_F2_LE_WIDTH                                                 1
#define SEC31MASK_F2_LE_SHIFT                                                 0
#define SEC31MASK_F2_LE_MASK                                         0x00000080
#define SEC31MASK_F2_LE_RD(src)                      (((src) & 0x00000080)<< 7)
#define SEC31MASK_F2_LE_WR(src)                (((unsigned int)(src) >> 7) & 0x00000080)
#define SEC31MASK_F2_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*Mask Register Fields SEC30Mask	 */
#define SEC30MASK_F2_LE_WIDTH                                                 1
#define SEC30MASK_F2_LE_SHIFT                                                 1
#define SEC30MASK_F2_LE_MASK                                         0x00000040
#define SEC30MASK_F2_LE_RD(src)                      (((src) & 0x00000040)<< 6)
#define SEC30MASK_F2_LE_WR(src)                (((unsigned int)(src) >> 6) & 0x00000040)
#define SEC30MASK_F2_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*Mask Register Fields SEC29Mask	 */
#define SEC29MASK_F2_LE_WIDTH                                                 1
#define SEC29MASK_F2_LE_SHIFT                                                 2
#define SEC29MASK_F2_LE_MASK                                         0x00000020
#define SEC29MASK_F2_LE_RD(src)                      (((src) & 0x00000020)<< 5)
#define SEC29MASK_F2_LE_WR(src)                (((unsigned int)(src) >> 5) & 0x00000020)
#define SEC29MASK_F2_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*Mask Register Fields SEC28Mask	 */
#define SEC28MASK_F2_LE_WIDTH                                                 1
#define SEC28MASK_F2_LE_SHIFT                                                 3
#define SEC28MASK_F2_LE_MASK                                         0x00000010
#define SEC28MASK_F2_LE_RD(src)                      (((src) & 0x00000010)<< 4)
#define SEC28MASK_F2_LE_WR(src)                (((unsigned int)(src) >> 4) & 0x00000010)
#define SEC28MASK_F2_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*Mask Register Fields SEC27Mask	 */
#define SEC27MASK_F2_LE_WIDTH                                                 1
#define SEC27MASK_F2_LE_SHIFT                                                 4
#define SEC27MASK_F2_LE_MASK                                         0x00000008
#define SEC27MASK_F2_LE_RD(src)                      (((src) & 0x00000008)<< 3)
#define SEC27MASK_F2_LE_WR(src)                (((unsigned int)(src) >> 3) & 0x00000008)
#define SEC27MASK_F2_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*Mask Register Fields SEC26Mask	 */
#define SEC26MASK_F2_LE_WIDTH                                                 1
#define SEC26MASK_F2_LE_SHIFT                                                 5
#define SEC26MASK_F2_LE_MASK                                         0x00000004
#define SEC26MASK_F2_LE_RD(src)                      (((src) & 0x00000004)<< 2)
#define SEC26MASK_F2_LE_WR(src)                (((unsigned int)(src) >> 2) & 0x00000004)
#define SEC26MASK_F2_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*Mask Register Fields SEC25Mask	 */
#define SEC25MASK_F2_LE_WIDTH                                                 1
#define SEC25MASK_F2_LE_SHIFT                                                 6
#define SEC25MASK_F2_LE_MASK                                         0x00000002
#define SEC25MASK_F2_LE_RD(src)                      (((src) & 0x00000002)<< 1)
#define SEC25MASK_F2_LE_WR(src)                (((unsigned int)(src) >> 1) & 0x00000002)
#define SEC25MASK_F2_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*Mask Register Fields SEC24Mask	 */
#define SEC24MASK_F2_LE_WIDTH                                                 1
#define SEC24MASK_F2_LE_SHIFT                                                 7
#define SEC24MASK_F2_LE_MASK                                         0x00000001
#define SEC24MASK_F2_LE_RD(src)                      (((src) & 0x00000001)<< 0)
#define SEC24MASK_F2_LE_WR(src)                (((unsigned int)(src) >> 0) & 0x00000001)
#define SEC24MASK_F2_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*Mask Register Fields SEC23Mask	 */
#define SEC23MASK_F2_LE_WIDTH                                                 1
#define SEC23MASK_F2_LE_SHIFT                                                 8
#define SEC23MASK_F2_LE_MASK                                         0x00008000
#define SEC23MASK_F2_LE_RD(src)                    (((src) & 0x00008000) >> 15)
#define SEC23MASK_F2_LE_WR(src)               (((unsigned int)(src) << 15) & 0x00008000)
#define SEC23MASK_F2_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*Mask Register Fields SEC22Mask	 */
#define SEC22MASK_F2_LE_WIDTH                                                 1
#define SEC22MASK_F2_LE_SHIFT                                                 9
#define SEC22MASK_F2_LE_MASK                                         0x00004000
#define SEC22MASK_F2_LE_RD(src)                    (((src) & 0x00004000) >> 14)
#define SEC22MASK_F2_LE_WR(src)               (((unsigned int)(src) << 14) & 0x00004000)
#define SEC22MASK_F2_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*Mask Register Fields SEC21Mask	 */
#define SEC21MASK_F2_LE_WIDTH                                                 1
#define SEC21MASK_F2_LE_SHIFT                                                10
#define SEC21MASK_F2_LE_MASK                                         0x00002000
#define SEC21MASK_F2_LE_RD(src)                    (((src) & 0x00002000) >> 13)
#define SEC21MASK_F2_LE_WR(src)               (((unsigned int)(src) << 13) & 0x00002000)
#define SEC21MASK_F2_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*Mask Register Fields SEC20Mask	 */
#define SEC20MASK_F2_LE_WIDTH                                                 1
#define SEC20MASK_F2_LE_SHIFT                                                11
#define SEC20MASK_F2_LE_MASK                                         0x00001000
#define SEC20MASK_F2_LE_RD(src)                    (((src) & 0x00001000) >> 12)
#define SEC20MASK_F2_LE_WR(src)               (((unsigned int)(src) << 12) & 0x00001000)
#define SEC20MASK_F2_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*Mask Register Fields SEC19Mask	 */
#define SEC19MASK_F2_LE_WIDTH                                                 1
#define SEC19MASK_F2_LE_SHIFT                                                12
#define SEC19MASK_F2_LE_MASK                                         0x00000800
#define SEC19MASK_F2_LE_RD(src)                    (((src) & 0x00000800) >> 11)
#define SEC19MASK_F2_LE_WR(src)               (((unsigned int)(src) << 11) & 0x00000800)
#define SEC19MASK_F2_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*Mask Register Fields SEC18Mask	 */
#define SEC18MASK_F2_LE_WIDTH                                                 1
#define SEC18MASK_F2_LE_SHIFT                                                13
#define SEC18MASK_F2_LE_MASK                                         0x00000400
#define SEC18MASK_F2_LE_RD(src)                    (((src) & 0x00000400) >> 10)
#define SEC18MASK_F2_LE_WR(src)               (((unsigned int)(src) << 10) & 0x00000400)
#define SEC18MASK_F2_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*Mask Register Fields SEC17Mask	 */
#define SEC17MASK_F2_LE_WIDTH                                                 1
#define SEC17MASK_F2_LE_SHIFT                                                14
#define SEC17MASK_F2_LE_MASK                                         0x00000200
#define SEC17MASK_F2_LE_RD(src)                     (((src) & 0x00000200) >> 9)
#define SEC17MASK_F2_LE_WR(src)                (((unsigned int)(src) << 9) & 0x00000200)
#define SEC17MASK_F2_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*Mask Register Fields SEC16Mask	 */
#define SEC16MASK_F2_LE_WIDTH                                                 1
#define SEC16MASK_F2_LE_SHIFT                                                15
#define SEC16MASK_F2_LE_MASK                                         0x00000100
#define SEC16MASK_F2_LE_RD(src)                     (((src) & 0x00000100) >> 8)
#define SEC16MASK_F2_LE_WR(src)                (((unsigned int)(src) << 8) & 0x00000100)
#define SEC16MASK_F2_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*Mask Register Fields SEC15Mask	 */
#define SEC15MASK_F2_LE_WIDTH                                                 1
#define SEC15MASK_F2_LE_SHIFT                                                16
#define SEC15MASK_F2_LE_MASK                                         0x00800000
#define SEC15MASK_F2_LE_RD(src)                    (((src) & 0x00800000) >> 23)
#define SEC15MASK_F2_LE_WR(src)               (((unsigned int)(src) << 23) & 0x00800000)
#define SEC15MASK_F2_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*Mask Register Fields SEC14Mask	 */
#define SEC14MASK_F2_LE_WIDTH                                                 1
#define SEC14MASK_F2_LE_SHIFT                                                17
#define SEC14MASK_F2_LE_MASK                                         0x00400000
#define SEC14MASK_F2_LE_RD(src)                    (((src) & 0x00400000) >> 22)
#define SEC14MASK_F2_LE_WR(src)               (((unsigned int)(src) << 22) & 0x00400000)
#define SEC14MASK_F2_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*Mask Register Fields SEC13Mask	 */
#define SEC13MASK_F2_LE_WIDTH                                                 1
#define SEC13MASK_F2_LE_SHIFT                                                18
#define SEC13MASK_F2_LE_MASK                                         0x00200000
#define SEC13MASK_F2_LE_RD(src)                    (((src) & 0x00200000) >> 21)
#define SEC13MASK_F2_LE_WR(src)               (((unsigned int)(src) << 21) & 0x00200000)
#define SEC13MASK_F2_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*Mask Register Fields SEC12Mask	 */
#define SEC12MASK_F2_LE_WIDTH                                                 1
#define SEC12MASK_F2_LE_SHIFT                                                19
#define SEC12MASK_F2_LE_MASK                                         0x00100000
#define SEC12MASK_F2_LE_RD(src)                    (((src) & 0x00100000) >> 20)
#define SEC12MASK_F2_LE_WR(src)               (((unsigned int)(src) << 20) & 0x00100000)
#define SEC12MASK_F2_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*Mask Register Fields SEC11Mask	 */
#define SEC11MASK_F2_LE_WIDTH                                                 1
#define SEC11MASK_F2_LE_SHIFT                                                20
#define SEC11MASK_F2_LE_MASK                                         0x00080000
#define SEC11MASK_F2_LE_RD(src)                    (((src) & 0x00080000) >> 19)
#define SEC11MASK_F2_LE_WR(src)               (((unsigned int)(src) << 19) & 0x00080000)
#define SEC11MASK_F2_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*Mask Register Fields SEC10Mask	 */
#define SEC10MASK_F2_LE_WIDTH                                                 1
#define SEC10MASK_F2_LE_SHIFT                                                21
#define SEC10MASK_F2_LE_MASK                                         0x00040000
#define SEC10MASK_F2_LE_RD(src)                    (((src) & 0x00040000) >> 18)
#define SEC10MASK_F2_LE_WR(src)               (((unsigned int)(src) << 18) & 0x00040000)
#define SEC10MASK_F2_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*Mask Register Fields SEC9Mask	 */
#define SEC9MASK_F2_LE_WIDTH                                                  1
#define SEC9MASK_F2_LE_SHIFT                                                 22
#define SEC9MASK_F2_LE_MASK                                          0x00020000
#define SEC9MASK_F2_LE_RD(src)                     (((src) & 0x00020000) >> 17)
#define SEC9MASK_F2_LE_WR(src)                (((unsigned int)(src) << 17) & 0x00020000)
#define SEC9MASK_F2_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*Mask Register Fields SEC8Mask	 */
#define SEC8MASK_F2_LE_WIDTH                                                  1
#define SEC8MASK_F2_LE_SHIFT                                                 23
#define SEC8MASK_F2_LE_MASK                                          0x00010000
#define SEC8MASK_F2_LE_RD(src)                     (((src) & 0x00010000) >> 16)
#define SEC8MASK_F2_LE_WR(src)                (((unsigned int)(src) << 16) & 0x00010000)
#define SEC8MASK_F2_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*Mask Register Fields SEC7Mask	 */
#define SEC7MASK_F2_LE_WIDTH                                                  1
#define SEC7MASK_F2_LE_SHIFT                                                 24
#define SEC7MASK_F2_LE_MASK                                          0x80000000
#define SEC7MASK_F2_LE_RD(src)                     (((src) & 0x80000000) >> 31)
#define SEC7MASK_F2_LE_WR(src)                (((unsigned int)(src) << 31) & 0x80000000)
#define SEC7MASK_F2_LE_SET(dst,src)                      ((dst)&~0x80000000)|\
			(((unsigned int)(src) << 31) & 0x80000000)

/*Mask Register Fields SEC6Mask	 */
#define SEC6MASK_F2_LE_WIDTH                                                  1
#define SEC6MASK_F2_LE_SHIFT                                                 25
#define SEC6MASK_F2_LE_MASK                                          0x40000000
#define SEC6MASK_F2_LE_RD(src)                     (((src) & 0x40000000) >> 30)
#define SEC6MASK_F2_LE_WR(src)                (((unsigned int)(src) << 30) & 0x40000000)
#define SEC6MASK_F2_LE_SET(dst,src)                      ((dst)&~0x40000000)|\
			(((unsigned int)(src) << 30) & 0x40000000)

/*Mask Register Fields SEC5Mask	 */
#define SEC5MASK_F2_LE_WIDTH                                                  1
#define SEC5MASK_F2_LE_SHIFT                                                 26
#define SEC5MASK_F2_LE_MASK                                          0x20000000
#define SEC5MASK_F2_LE_RD(src)                     (((src) & 0x20000000) >> 29)
#define SEC5MASK_F2_LE_WR(src)                (((unsigned int)(src) << 29) & 0x20000000)
#define SEC5MASK_F2_LE_SET(dst,src)                      ((dst)&~0x20000000)|\
			(((unsigned int)(src) << 29) & 0x20000000)

/*Mask Register Fields SEC4Mask	 */
#define SEC4MASK_F2_LE_WIDTH                                                  1
#define SEC4MASK_F2_LE_SHIFT                                                 27
#define SEC4MASK_F2_LE_MASK                                          0x10000000
#define SEC4MASK_F2_LE_RD(src)                     (((src) & 0x10000000) >> 28)
#define SEC4MASK_F2_LE_WR(src)                (((unsigned int)(src) << 28) & 0x10000000)
#define SEC4MASK_F2_LE_SET(dst,src)                      ((dst)&~0x10000000)|\
			(((unsigned int)(src) << 28) & 0x10000000)

/*Mask Register Fields SEC3Mask	 */
#define SEC3MASK_F2_LE_WIDTH                                                  1
#define SEC3MASK_F2_LE_SHIFT                                                 28
#define SEC3MASK_F2_LE_MASK                                          0x08000000
#define SEC3MASK_F2_LE_RD(src)                     (((src) & 0x08000000) >> 27)
#define SEC3MASK_F2_LE_WR(src)                (((unsigned int)(src) << 27) & 0x08000000)
#define SEC3MASK_F2_LE_SET(dst,src)                      ((dst)&~0x08000000)|\
			(((unsigned int)(src) << 27) & 0x08000000)

/*Mask Register Fields SEC2Mask	 */
#define SEC2MASK_F2_LE_WIDTH                                                  1
#define SEC2MASK_F2_LE_SHIFT                                                 29
#define SEC2MASK_F2_LE_MASK                                          0x04000000
#define SEC2MASK_F2_LE_RD(src)                     (((src) & 0x04000000) >> 26)
#define SEC2MASK_F2_LE_WR(src)                (((unsigned int)(src) << 26) & 0x04000000)
#define SEC2MASK_F2_LE_SET(dst,src)                      ((dst)&~0x04000000)|\
			(((unsigned int)(src) << 26) & 0x04000000)

/*Mask Register Fields SEC1Mask	 */
#define SEC1MASK_F2_LE_WIDTH                                                  1
#define SEC1MASK_F2_LE_SHIFT                                                 30
#define SEC1MASK_F2_LE_MASK                                          0x02000000
#define SEC1MASK_F2_LE_RD(src)                     (((src) & 0x02000000) >> 25)
#define SEC1MASK_F2_LE_WR(src)                (((unsigned int)(src) << 25) & 0x02000000)
#define SEC1MASK_F2_LE_SET(dst,src)                      ((dst)&~0x02000000)|\
			(((unsigned int)(src) << 25) & 0x02000000)

/*Mask Register Fields SEC0Mask	 */
#define SEC0MASK_F2_LE_WIDTH                                                  1
#define SEC0MASK_F2_LE_SHIFT                                                 31
#define SEC0MASK_F2_LE_MASK                                          0x01000000
#define SEC0MASK_F2_LE_RD(src)                     (((src) & 0x01000000) >> 24)
#define SEC0MASK_F2_LE_WR(src)                (((unsigned int)(src) << 24) & 0x01000000)
#define SEC0MASK_F2_LE_SET(dst,src)                      ((dst)&~0x01000000)|\
			(((unsigned int)(src) << 24) & 0x01000000)

/*	Register GLBL_SEC_ERRH	*/

/*	 Fields SEC31	 */
#define SEC31_F3_LE_WIDTH                                                     1
#define SEC31_F3_LE_SHIFT                                                     0
#define SEC31_F3_LE_MASK                                             0x00000080
#define SEC31_F3_LE_RD(src)                          (((src) & 0x00000080)<< 7)
#define SEC31_F3_LE_WR(src)                    (((unsigned int)(src) >> 7) & 0x00000080)
#define SEC31_F3_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields SEC30	 */
#define SEC30_F3_LE_WIDTH                                                     1
#define SEC30_F3_LE_SHIFT                                                     1
#define SEC30_F3_LE_MASK                                             0x00000040
#define SEC30_F3_LE_RD(src)                          (((src) & 0x00000040)<< 6)
#define SEC30_F3_LE_WR(src)                    (((unsigned int)(src) >> 6) & 0x00000040)
#define SEC30_F3_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields SEC29	 */
#define SEC29_F3_LE_WIDTH                                                     1
#define SEC29_F3_LE_SHIFT                                                     2
#define SEC29_F3_LE_MASK                                             0x00000020
#define SEC29_F3_LE_RD(src)                          (((src) & 0x00000020)<< 5)
#define SEC29_F3_LE_WR(src)                    (((unsigned int)(src) >> 5) & 0x00000020)
#define SEC29_F3_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*	 Fields SEC28	 */
#define SEC28_F3_LE_WIDTH                                                     1
#define SEC28_F3_LE_SHIFT                                                     3
#define SEC28_F3_LE_MASK                                             0x00000010
#define SEC28_F3_LE_RD(src)                          (((src) & 0x00000010)<< 4)
#define SEC28_F3_LE_WR(src)                    (((unsigned int)(src) >> 4) & 0x00000010)
#define SEC28_F3_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields SEC27	 */
#define SEC27_F3_LE_WIDTH                                                     1
#define SEC27_F3_LE_SHIFT                                                     4
#define SEC27_F3_LE_MASK                                             0x00000008
#define SEC27_F3_LE_RD(src)                          (((src) & 0x00000008)<< 3)
#define SEC27_F3_LE_WR(src)                    (((unsigned int)(src) >> 3) & 0x00000008)
#define SEC27_F3_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*	 Fields SEC26	 */
#define SEC26_F3_LE_WIDTH                                                     1
#define SEC26_F3_LE_SHIFT                                                     5
#define SEC26_F3_LE_MASK                                             0x00000004
#define SEC26_F3_LE_RD(src)                          (((src) & 0x00000004)<< 2)
#define SEC26_F3_LE_WR(src)                    (((unsigned int)(src) >> 2) & 0x00000004)
#define SEC26_F3_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*	 Fields SEC25	 */
#define SEC25_F3_LE_WIDTH                                                     1
#define SEC25_F3_LE_SHIFT                                                     6
#define SEC25_F3_LE_MASK                                             0x00000002
#define SEC25_F3_LE_RD(src)                          (((src) & 0x00000002)<< 1)
#define SEC25_F3_LE_WR(src)                    (((unsigned int)(src) >> 1) & 0x00000002)
#define SEC25_F3_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*	 Fields SEC24	 */
#define SEC24_F3_LE_WIDTH                                                     1
#define SEC24_F3_LE_SHIFT                                                     7
#define SEC24_F3_LE_MASK                                             0x00000001
#define SEC24_F3_LE_RD(src)                          (((src) & 0x00000001)<< 0)
#define SEC24_F3_LE_WR(src)                    (((unsigned int)(src) >> 0) & 0x00000001)
#define SEC24_F3_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*	 Fields SEC23	 */
#define SEC23_F3_LE_WIDTH                                                     1
#define SEC23_F3_LE_SHIFT                                                     8
#define SEC23_F3_LE_MASK                                             0x00008000
#define SEC23_F3_LE_RD(src)                        (((src) & 0x00008000) >> 15)
#define SEC23_F3_LE_WR(src)                   (((unsigned int)(src) << 15) & 0x00008000)
#define SEC23_F3_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*	 Fields SEC22	 */
#define SEC22_F3_LE_WIDTH                                                     1
#define SEC22_F3_LE_SHIFT                                                     9
#define SEC22_F3_LE_MASK                                             0x00004000
#define SEC22_F3_LE_RD(src)                        (((src) & 0x00004000) >> 14)
#define SEC22_F3_LE_WR(src)                   (((unsigned int)(src) << 14) & 0x00004000)
#define SEC22_F3_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*	 Fields SEC21	 */
#define SEC21_F3_LE_WIDTH                                                     1
#define SEC21_F3_LE_SHIFT                                                    10
#define SEC21_F3_LE_MASK                                             0x00002000
#define SEC21_F3_LE_RD(src)                        (((src) & 0x00002000) >> 13)
#define SEC21_F3_LE_WR(src)                   (((unsigned int)(src) << 13) & 0x00002000)
#define SEC21_F3_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*	 Fields SEC20	 */
#define SEC20_F3_LE_WIDTH                                                     1
#define SEC20_F3_LE_SHIFT                                                    11
#define SEC20_F3_LE_MASK                                             0x00001000
#define SEC20_F3_LE_RD(src)                        (((src) & 0x00001000) >> 12)
#define SEC20_F3_LE_WR(src)                   (((unsigned int)(src) << 12) & 0x00001000)
#define SEC20_F3_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*	 Fields SEC19	 */
#define SEC19_F3_LE_WIDTH                                                     1
#define SEC19_F3_LE_SHIFT                                                    12
#define SEC19_F3_LE_MASK                                             0x00000800
#define SEC19_F3_LE_RD(src)                        (((src) & 0x00000800) >> 11)
#define SEC19_F3_LE_WR(src)                   (((unsigned int)(src) << 11) & 0x00000800)
#define SEC19_F3_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*	 Fields SEC18	 */
#define SEC18_F3_LE_WIDTH                                                     1
#define SEC18_F3_LE_SHIFT                                                    13
#define SEC18_F3_LE_MASK                                             0x00000400
#define SEC18_F3_LE_RD(src)                        (((src) & 0x00000400) >> 10)
#define SEC18_F3_LE_WR(src)                   (((unsigned int)(src) << 10) & 0x00000400)
#define SEC18_F3_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*	 Fields SEC17	 */
#define SEC17_F3_LE_WIDTH                                                     1
#define SEC17_F3_LE_SHIFT                                                    14
#define SEC17_F3_LE_MASK                                             0x00000200
#define SEC17_F3_LE_RD(src)                         (((src) & 0x00000200) >> 9)
#define SEC17_F3_LE_WR(src)                    (((unsigned int)(src) << 9) & 0x00000200)
#define SEC17_F3_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*	 Fields SEC16	 */
#define SEC16_F3_LE_WIDTH                                                     1
#define SEC16_F3_LE_SHIFT                                                    15
#define SEC16_F3_LE_MASK                                             0x00000100
#define SEC16_F3_LE_RD(src)                         (((src) & 0x00000100) >> 8)
#define SEC16_F3_LE_WR(src)                    (((unsigned int)(src) << 8) & 0x00000100)
#define SEC16_F3_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*	 Fields SEC15	 */
#define SEC15_F3_LE_WIDTH                                                     1
#define SEC15_F3_LE_SHIFT                                                    16
#define SEC15_F3_LE_MASK                                             0x00800000
#define SEC15_F3_LE_RD(src)                        (((src) & 0x00800000) >> 23)
#define SEC15_F3_LE_WR(src)                   (((unsigned int)(src) << 23) & 0x00800000)
#define SEC15_F3_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*	 Fields SEC14	 */
#define SEC14_F3_LE_WIDTH                                                     1
#define SEC14_F3_LE_SHIFT                                                    17
#define SEC14_F3_LE_MASK                                             0x00400000
#define SEC14_F3_LE_RD(src)                        (((src) & 0x00400000) >> 22)
#define SEC14_F3_LE_WR(src)                   (((unsigned int)(src) << 22) & 0x00400000)
#define SEC14_F3_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*	 Fields SEC13	 */
#define SEC13_F3_LE_WIDTH                                                     1
#define SEC13_F3_LE_SHIFT                                                    18
#define SEC13_F3_LE_MASK                                             0x00200000
#define SEC13_F3_LE_RD(src)                        (((src) & 0x00200000) >> 21)
#define SEC13_F3_LE_WR(src)                   (((unsigned int)(src) << 21) & 0x00200000)
#define SEC13_F3_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*	 Fields SEC12	 */
#define SEC12_F3_LE_WIDTH                                                     1
#define SEC12_F3_LE_SHIFT                                                    19
#define SEC12_F3_LE_MASK                                             0x00100000
#define SEC12_F3_LE_RD(src)                        (((src) & 0x00100000) >> 20)
#define SEC12_F3_LE_WR(src)                   (((unsigned int)(src) << 20) & 0x00100000)
#define SEC12_F3_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields SEC11	 */
#define SEC11_F3_LE_WIDTH                                                     1
#define SEC11_F3_LE_SHIFT                                                    20
#define SEC11_F3_LE_MASK                                             0x00080000
#define SEC11_F3_LE_RD(src)                        (((src) & 0x00080000) >> 19)
#define SEC11_F3_LE_WR(src)                   (((unsigned int)(src) << 19) & 0x00080000)
#define SEC11_F3_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*	 Fields SEC10	 */
#define SEC10_F3_LE_WIDTH                                                     1
#define SEC10_F3_LE_SHIFT                                                    21
#define SEC10_F3_LE_MASK                                             0x00040000
#define SEC10_F3_LE_RD(src)                        (((src) & 0x00040000) >> 18)
#define SEC10_F3_LE_WR(src)                   (((unsigned int)(src) << 18) & 0x00040000)
#define SEC10_F3_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*	 Fields SEC9	 */
#define SEC9_F3_LE_WIDTH                                                      1
#define SEC9_F3_LE_SHIFT                                                     22
#define SEC9_F3_LE_MASK                                              0x00020000
#define SEC9_F3_LE_RD(src)                         (((src) & 0x00020000) >> 17)
#define SEC9_F3_LE_WR(src)                    (((unsigned int)(src) << 17) & 0x00020000)
#define SEC9_F3_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*	 Fields SEC8	 */
#define SEC8_F3_LE_WIDTH                                                      1
#define SEC8_F3_LE_SHIFT                                                     23
#define SEC8_F3_LE_MASK                                              0x00010000
#define SEC8_F3_LE_RD(src)                         (((src) & 0x00010000) >> 16)
#define SEC8_F3_LE_WR(src)                    (((unsigned int)(src) << 16) & 0x00010000)
#define SEC8_F3_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*	 Fields SEC7	 */
#define SEC7_F3_LE_WIDTH                                                      1
#define SEC7_F3_LE_SHIFT                                                     24
#define SEC7_F3_LE_MASK                                              0x80000000
#define SEC7_F3_LE_RD(src)                         (((src) & 0x80000000) >> 31)
#define SEC7_F3_LE_WR(src)                    (((unsigned int)(src) << 31) & 0x80000000)
#define SEC7_F3_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields SEC6	 */
#define SEC6_F3_LE_WIDTH                                                      1
#define SEC6_F3_LE_SHIFT                                                     25
#define SEC6_F3_LE_MASK                                              0x40000000
#define SEC6_F3_LE_RD(src)                         (((src) & 0x40000000) >> 30)
#define SEC6_F3_LE_WR(src)                    (((unsigned int)(src) << 30) & 0x40000000)
#define SEC6_F3_LE_SET(dst,src)                     ((dst)&~0x40000000)|\
				(((unsigned int)(src) << 30) & 0x40000000)

/*	 Fields SEC5	 */
#define SEC5_F3_LE_WIDTH                                                      1
#define SEC5_F3_LE_SHIFT                                                     26
#define SEC5_F3_LE_MASK                                              0x20000000
#define SEC5_F3_LE_RD(src)                         (((src) & 0x20000000) >> 29)
#define SEC5_F3_LE_WR(src)                    (((unsigned int)(src) << 29) & 0x20000000)
#define SEC5_F3_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields SEC4	 */
#define SEC4_F3_LE_WIDTH                                                      1
#define SEC4_F3_LE_SHIFT                                                     27
#define SEC4_F3_LE_MASK                                              0x10000000
#define SEC4_F3_LE_RD(src)                         (((src) & 0x10000000) >> 28)
#define SEC4_F3_LE_WR(src)                    (((unsigned int)(src) << 28) & 0x10000000)
#define SEC4_F3_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields SEC3	 */
#define SEC3_F3_LE_WIDTH                                                      1
#define SEC3_F3_LE_SHIFT                                                     28
#define SEC3_F3_LE_MASK                                              0x08000000
#define SEC3_F3_LE_RD(src)                         (((src) & 0x08000000) >> 27)
#define SEC3_F3_LE_WR(src)                    (((unsigned int)(src) << 27) & 0x08000000)
#define SEC3_F3_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields SEC2	 */
#define SEC2_F3_LE_WIDTH                                                      1
#define SEC2_F3_LE_SHIFT                                                     29
#define SEC2_F3_LE_MASK                                              0x04000000
#define SEC2_F3_LE_RD(src)                         (((src) & 0x04000000) >> 26)
#define SEC2_F3_LE_WR(src)                    (((unsigned int)(src) << 26) & 0x04000000)
#define SEC2_F3_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields SEC1	 */
#define SEC1_F3_LE_WIDTH                                                      1
#define SEC1_F3_LE_SHIFT                                                     30
#define SEC1_F3_LE_MASK                                              0x02000000
#define SEC1_F3_LE_RD(src)                         (((src) & 0x02000000) >> 25)
#define SEC1_F3_LE_WR(src)                    (((unsigned int)(src) << 25) & 0x02000000)
#define SEC1_F3_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields SEC0	 */
#define SEC0_F3_LE_WIDTH                                                      1
#define SEC0_F3_LE_SHIFT                                                     31
#define SEC0_F3_LE_MASK                                              0x01000000
#define SEC0_F3_LE_RD(src)                         (((src) & 0x01000000) >> 24)
#define SEC0_F3_LE_WR(src)                    (((unsigned int)(src) << 24) & 0x01000000)
#define SEC0_F3_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register GLBL_SEC_ERRHMask	*/

/*Mask Register Fields SEC31Mask	 */
#define SEC31MASK_F3_LE_WIDTH                                                 1
#define SEC31MASK_F3_LE_SHIFT                                                 0
#define SEC31MASK_F3_LE_MASK                                         0x00000080
#define SEC31MASK_F3_LE_RD(src)                      (((src) & 0x00000080)<< 7)
#define SEC31MASK_F3_LE_WR(src)                (((unsigned int)(src) >> 7) & 0x00000080)
#define SEC31MASK_F3_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*Mask Register Fields SEC30Mask	 */
#define SEC30MASK_F3_LE_WIDTH                                                 1
#define SEC30MASK_F3_LE_SHIFT                                                 1
#define SEC30MASK_F3_LE_MASK                                         0x00000040
#define SEC30MASK_F3_LE_RD(src)                      (((src) & 0x00000040)<< 6)
#define SEC30MASK_F3_LE_WR(src)                (((unsigned int)(src) >> 6) & 0x00000040)
#define SEC30MASK_F3_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*Mask Register Fields SEC29Mask	 */
#define SEC29MASK_F3_LE_WIDTH                                                 1
#define SEC29MASK_F3_LE_SHIFT                                                 2
#define SEC29MASK_F3_LE_MASK                                         0x00000020
#define SEC29MASK_F3_LE_RD(src)                      (((src) & 0x00000020)<< 5)
#define SEC29MASK_F3_LE_WR(src)                (((unsigned int)(src) >> 5) & 0x00000020)
#define SEC29MASK_F3_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*Mask Register Fields SEC28Mask	 */
#define SEC28MASK_F3_LE_WIDTH                                                 1
#define SEC28MASK_F3_LE_SHIFT                                                 3
#define SEC28MASK_F3_LE_MASK                                         0x00000010
#define SEC28MASK_F3_LE_RD(src)                      (((src) & 0x00000010)<< 4)
#define SEC28MASK_F3_LE_WR(src)                (((unsigned int)(src) >> 4) & 0x00000010)
#define SEC28MASK_F3_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*Mask Register Fields SEC27Mask	 */
#define SEC27MASK_F3_LE_WIDTH                                                 1
#define SEC27MASK_F3_LE_SHIFT                                                 4
#define SEC27MASK_F3_LE_MASK                                         0x00000008
#define SEC27MASK_F3_LE_RD(src)                      (((src) & 0x00000008)<< 3)
#define SEC27MASK_F3_LE_WR(src)                (((unsigned int)(src) >> 3) & 0x00000008)
#define SEC27MASK_F3_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*Mask Register Fields SEC26Mask	 */
#define SEC26MASK_F3_LE_WIDTH                                                 1
#define SEC26MASK_F3_LE_SHIFT                                                 5
#define SEC26MASK_F3_LE_MASK                                         0x00000004
#define SEC26MASK_F3_LE_RD(src)                      (((src) & 0x00000004)<< 2)
#define SEC26MASK_F3_LE_WR(src)                (((unsigned int)(src) >> 2) & 0x00000004)
#define SEC26MASK_F3_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*Mask Register Fields SEC25Mask	 */
#define SEC25MASK_F3_LE_WIDTH                                                 1
#define SEC25MASK_F3_LE_SHIFT                                                 6
#define SEC25MASK_F3_LE_MASK                                         0x00000002
#define SEC25MASK_F3_LE_RD(src)                      (((src) & 0x00000002)<< 1)
#define SEC25MASK_F3_LE_WR(src)                (((unsigned int)(src) >> 1) & 0x00000002)
#define SEC25MASK_F3_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*Mask Register Fields SEC24Mask	 */
#define SEC24MASK_F3_LE_WIDTH                                                 1
#define SEC24MASK_F3_LE_SHIFT                                                 7
#define SEC24MASK_F3_LE_MASK                                         0x00000001
#define SEC24MASK_F3_LE_RD(src)                      (((src) & 0x00000001)<< 0)
#define SEC24MASK_F3_LE_WR(src)                (((unsigned int)(src) >> 0) & 0x00000001)
#define SEC24MASK_F3_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*Mask Register Fields SEC23Mask	 */
#define SEC23MASK_F3_LE_WIDTH                                                 1
#define SEC23MASK_F3_LE_SHIFT                                                 8
#define SEC23MASK_F3_LE_MASK                                         0x00008000
#define SEC23MASK_F3_LE_RD(src)                    (((src) & 0x00008000) >> 15)
#define SEC23MASK_F3_LE_WR(src)               (((unsigned int)(src) << 15) & 0x00008000)
#define SEC23MASK_F3_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*Mask Register Fields SEC22Mask	 */
#define SEC22MASK_F3_LE_WIDTH                                                 1
#define SEC22MASK_F3_LE_SHIFT                                                 9
#define SEC22MASK_F3_LE_MASK                                         0x00004000
#define SEC22MASK_F3_LE_RD(src)                    (((src) & 0x00004000) >> 14)
#define SEC22MASK_F3_LE_WR(src)               (((unsigned int)(src) << 14) & 0x00004000)
#define SEC22MASK_F3_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*Mask Register Fields SEC21Mask	 */
#define SEC21MASK_F3_LE_WIDTH                                                 1
#define SEC21MASK_F3_LE_SHIFT                                                10
#define SEC21MASK_F3_LE_MASK                                         0x00002000
#define SEC21MASK_F3_LE_RD(src)                    (((src) & 0x00002000) >> 13)
#define SEC21MASK_F3_LE_WR(src)               (((unsigned int)(src) << 13) & 0x00002000)
#define SEC21MASK_F3_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*Mask Register Fields SEC20Mask	 */
#define SEC20MASK_F3_LE_WIDTH                                                 1
#define SEC20MASK_F3_LE_SHIFT                                                11
#define SEC20MASK_F3_LE_MASK                                         0x00001000
#define SEC20MASK_F3_LE_RD(src)                    (((src) & 0x00001000) >> 12)
#define SEC20MASK_F3_LE_WR(src)               (((unsigned int)(src) << 12) & 0x00001000)
#define SEC20MASK_F3_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*Mask Register Fields SEC19Mask	 */
#define SEC19MASK_F3_LE_WIDTH                                                 1
#define SEC19MASK_F3_LE_SHIFT                                                12
#define SEC19MASK_F3_LE_MASK                                         0x00000800
#define SEC19MASK_F3_LE_RD(src)                    (((src) & 0x00000800) >> 11)
#define SEC19MASK_F3_LE_WR(src)               (((unsigned int)(src) << 11) & 0x00000800)
#define SEC19MASK_F3_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*Mask Register Fields SEC18Mask	 */
#define SEC18MASK_F3_LE_WIDTH                                                 1
#define SEC18MASK_F3_LE_SHIFT                                                13
#define SEC18MASK_F3_LE_MASK                                         0x00000400
#define SEC18MASK_F3_LE_RD(src)                    (((src) & 0x00000400) >> 10)
#define SEC18MASK_F3_LE_WR(src)               (((unsigned int)(src) << 10) & 0x00000400)
#define SEC18MASK_F3_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*Mask Register Fields SEC17Mask	 */
#define SEC17MASK_F3_LE_WIDTH                                                 1
#define SEC17MASK_F3_LE_SHIFT                                                14
#define SEC17MASK_F3_LE_MASK                                         0x00000200
#define SEC17MASK_F3_LE_RD(src)                     (((src) & 0x00000200) >> 9)
#define SEC17MASK_F3_LE_WR(src)                (((unsigned int)(src) << 9) & 0x00000200)
#define SEC17MASK_F3_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*Mask Register Fields SEC16Mask	 */
#define SEC16MASK_F3_LE_WIDTH                                                 1
#define SEC16MASK_F3_LE_SHIFT                                                15
#define SEC16MASK_F3_LE_MASK                                         0x00000100
#define SEC16MASK_F3_LE_RD(src)                     (((src) & 0x00000100) >> 8)
#define SEC16MASK_F3_LE_WR(src)                (((unsigned int)(src) << 8) & 0x00000100)
#define SEC16MASK_F3_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*Mask Register Fields SEC15Mask	 */
#define SEC15MASK_F3_LE_WIDTH                                                 1
#define SEC15MASK_F3_LE_SHIFT                                                16
#define SEC15MASK_F3_LE_MASK                                         0x00800000
#define SEC15MASK_F3_LE_RD(src)                    (((src) & 0x00800000) >> 23)
#define SEC15MASK_F3_LE_WR(src)               (((unsigned int)(src) << 23) & 0x00800000)
#define SEC15MASK_F3_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*Mask Register Fields SEC14Mask	 */
#define SEC14MASK_F3_LE_WIDTH                                                 1
#define SEC14MASK_F3_LE_SHIFT                                                17
#define SEC14MASK_F3_LE_MASK                                         0x00400000
#define SEC14MASK_F3_LE_RD(src)                    (((src) & 0x00400000) >> 22)
#define SEC14MASK_F3_LE_WR(src)               (((unsigned int)(src) << 22) & 0x00400000)
#define SEC14MASK_F3_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*Mask Register Fields SEC13Mask	 */
#define SEC13MASK_F3_LE_WIDTH                                                 1
#define SEC13MASK_F3_LE_SHIFT                                                18
#define SEC13MASK_F3_LE_MASK                                         0x00200000
#define SEC13MASK_F3_LE_RD(src)                    (((src) & 0x00200000) >> 21)
#define SEC13MASK_F3_LE_WR(src)               (((unsigned int)(src) << 21) & 0x00200000)
#define SEC13MASK_F3_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*Mask Register Fields SEC12Mask	 */
#define SEC12MASK_F3_LE_WIDTH                                                 1
#define SEC12MASK_F3_LE_SHIFT                                                19
#define SEC12MASK_F3_LE_MASK                                         0x00100000
#define SEC12MASK_F3_LE_RD(src)                    (((src) & 0x00100000) >> 20)
#define SEC12MASK_F3_LE_WR(src)               (((unsigned int)(src) << 20) & 0x00100000)
#define SEC12MASK_F3_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*Mask Register Fields SEC11Mask	 */
#define SEC11MASK_F3_LE_WIDTH                                                 1
#define SEC11MASK_F3_LE_SHIFT                                                20
#define SEC11MASK_F3_LE_MASK                                         0x00080000
#define SEC11MASK_F3_LE_RD(src)                    (((src) & 0x00080000) >> 19)
#define SEC11MASK_F3_LE_WR(src)               (((unsigned int)(src) << 19) & 0x00080000)
#define SEC11MASK_F3_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*Mask Register Fields SEC10Mask	 */
#define SEC10MASK_F3_LE_WIDTH                                                 1
#define SEC10MASK_F3_LE_SHIFT                                                21
#define SEC10MASK_F3_LE_MASK                                         0x00040000
#define SEC10MASK_F3_LE_RD(src)                    (((src) & 0x00040000) >> 18)
#define SEC10MASK_F3_LE_WR(src)               (((unsigned int)(src) << 18) & 0x00040000)
#define SEC10MASK_F3_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*Mask Register Fields SEC9Mask	 */
#define SEC9MASK_F3_LE_WIDTH                                                  1
#define SEC9MASK_F3_LE_SHIFT                                                 22
#define SEC9MASK_F3_LE_MASK                                          0x00020000
#define SEC9MASK_F3_LE_RD(src)                     (((src) & 0x00020000) >> 17)
#define SEC9MASK_F3_LE_WR(src)                (((unsigned int)(src) << 17) & 0x00020000)
#define SEC9MASK_F3_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*Mask Register Fields SEC8Mask	 */
#define SEC8MASK_F3_LE_WIDTH                                                  1
#define SEC8MASK_F3_LE_SHIFT                                                 23
#define SEC8MASK_F3_LE_MASK                                          0x00010000
#define SEC8MASK_F3_LE_RD(src)                     (((src) & 0x00010000) >> 16)
#define SEC8MASK_F3_LE_WR(src)                (((unsigned int)(src) << 16) & 0x00010000)
#define SEC8MASK_F3_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*Mask Register Fields SEC7Mask	 */
#define SEC7MASK_F3_LE_WIDTH                                                  1
#define SEC7MASK_F3_LE_SHIFT                                                 24
#define SEC7MASK_F3_LE_MASK                                          0x80000000
#define SEC7MASK_F3_LE_RD(src)                     (((src) & 0x80000000) >> 31)
#define SEC7MASK_F3_LE_WR(src)                (((unsigned int)(src) << 31) & 0x80000000)
#define SEC7MASK_F3_LE_SET(dst,src)                      ((dst)&~0x80000000)|\
			(((unsigned int)(src) << 31) & 0x80000000)

/*Mask Register Fields SEC6Mask	 */
#define SEC6MASK_F3_LE_WIDTH                                                  1
#define SEC6MASK_F3_LE_SHIFT                                                 25
#define SEC6MASK_F3_LE_MASK                                          0x40000000
#define SEC6MASK_F3_LE_RD(src)                     (((src) & 0x40000000) >> 30)
#define SEC6MASK_F3_LE_WR(src)                (((unsigned int)(src) << 30) & 0x40000000)
#define SEC6MASK_F3_LE_SET(dst,src)                      ((dst)&~0x40000000)|\
			(((unsigned int)(src) << 30) & 0x40000000)

/*Mask Register Fields SEC5Mask	 */
#define SEC5MASK_F3_LE_WIDTH                                                  1
#define SEC5MASK_F3_LE_SHIFT                                                 26
#define SEC5MASK_F3_LE_MASK                                          0x20000000
#define SEC5MASK_F3_LE_RD(src)                     (((src) & 0x20000000) >> 29)
#define SEC5MASK_F3_LE_WR(src)                (((unsigned int)(src) << 29) & 0x20000000)
#define SEC5MASK_F3_LE_SET(dst,src)                      ((dst)&~0x20000000)|\
			(((unsigned int)(src) << 29) & 0x20000000)

/*Mask Register Fields SEC4Mask	 */
#define SEC4MASK_F3_LE_WIDTH                                                  1
#define SEC4MASK_F3_LE_SHIFT                                                 27
#define SEC4MASK_F3_LE_MASK                                          0x10000000
#define SEC4MASK_F3_LE_RD(src)                     (((src) & 0x10000000) >> 28)
#define SEC4MASK_F3_LE_WR(src)                (((unsigned int)(src) << 28) & 0x10000000)
#define SEC4MASK_F3_LE_SET(dst,src)                      ((dst)&~0x10000000)|\
			(((unsigned int)(src) << 28) & 0x10000000)

/*Mask Register Fields SEC3Mask	 */
#define SEC3MASK_F3_LE_WIDTH                                                  1
#define SEC3MASK_F3_LE_SHIFT                                                 28
#define SEC3MASK_F3_LE_MASK                                          0x08000000
#define SEC3MASK_F3_LE_RD(src)                     (((src) & 0x08000000) >> 27)
#define SEC3MASK_F3_LE_WR(src)                (((unsigned int)(src) << 27) & 0x08000000)
#define SEC3MASK_F3_LE_SET(dst,src)                      ((dst)&~0x08000000)|\
			(((unsigned int)(src) << 27) & 0x08000000)

/*Mask Register Fields SEC2Mask	 */
#define SEC2MASK_F3_LE_WIDTH                                                  1
#define SEC2MASK_F3_LE_SHIFT                                                 29
#define SEC2MASK_F3_LE_MASK                                          0x04000000
#define SEC2MASK_F3_LE_RD(src)                     (((src) & 0x04000000) >> 26)
#define SEC2MASK_F3_LE_WR(src)                (((unsigned int)(src) << 26) & 0x04000000)
#define SEC2MASK_F3_LE_SET(dst,src)                      ((dst)&~0x04000000)|\
			(((unsigned int)(src) << 26) & 0x04000000)

/*Mask Register Fields SEC1Mask	 */
#define SEC1MASK_F3_LE_WIDTH                                                  1
#define SEC1MASK_F3_LE_SHIFT                                                 30
#define SEC1MASK_F3_LE_MASK                                          0x02000000
#define SEC1MASK_F3_LE_RD(src)                     (((src) & 0x02000000) >> 25)
#define SEC1MASK_F3_LE_WR(src)                (((unsigned int)(src) << 25) & 0x02000000)
#define SEC1MASK_F3_LE_SET(dst,src)                      ((dst)&~0x02000000)|\
			(((unsigned int)(src) << 25) & 0x02000000)

/*Mask Register Fields SEC0Mask	 */
#define SEC0MASK_F3_LE_WIDTH                                                  1
#define SEC0MASK_F3_LE_SHIFT                                                 31
#define SEC0MASK_F3_LE_MASK                                          0x01000000
#define SEC0MASK_F3_LE_RD(src)                     (((src) & 0x01000000) >> 24)
#define SEC0MASK_F3_LE_WR(src)                (((unsigned int)(src) << 24) & 0x01000000)
#define SEC0MASK_F3_LE_SET(dst,src)                      ((dst)&~0x01000000)|\
			(((unsigned int)(src) << 24) & 0x01000000)

/*	Register GLBL_MSEC_ERRL	*/

/*	 Fields MSEC31	 */
#define MSEC31_F1_LE_WIDTH                                                    1
#define MSEC31_F1_LE_SHIFT                                                    0
#define MSEC31_F1_LE_MASK                                            0x00000080
#define MSEC31_F1_LE_RD(src)                         (((src) & 0x00000080)<< 7)
#define MSEC31_F1_LE_WR(src)                   (((unsigned int)(src) >> 7) & 0x00000080)
#define MSEC31_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields MSEC30	 */
#define MSEC30_F1_LE_WIDTH                                                    1
#define MSEC30_F1_LE_SHIFT                                                    1
#define MSEC30_F1_LE_MASK                                            0x00000040
#define MSEC30_F1_LE_RD(src)                         (((src) & 0x00000040)<< 6)
#define MSEC30_F1_LE_WR(src)                   (((unsigned int)(src) >> 6) & 0x00000040)
#define MSEC30_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields MSEC29	 */
#define MSEC29_F1_LE_WIDTH                                                    1
#define MSEC29_F1_LE_SHIFT                                                    2
#define MSEC29_F1_LE_MASK                                            0x00000020
#define MSEC29_F1_LE_RD(src)                         (((src) & 0x00000020)<< 5)
#define MSEC29_F1_LE_WR(src)                   (((unsigned int)(src) >> 5) & 0x00000020)
#define MSEC29_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*	 Fields MSEC28	 */
#define MSEC28_F1_LE_WIDTH                                                    1
#define MSEC28_F1_LE_SHIFT                                                    3
#define MSEC28_F1_LE_MASK                                            0x00000010
#define MSEC28_F1_LE_RD(src)                         (((src) & 0x00000010)<< 4)
#define MSEC28_F1_LE_WR(src)                   (((unsigned int)(src) >> 4) & 0x00000010)
#define MSEC28_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields MSEC27	 */
#define MSEC27_F1_LE_WIDTH                                                    1
#define MSEC27_F1_LE_SHIFT                                                    4
#define MSEC27_F1_LE_MASK                                            0x00000008
#define MSEC27_F1_LE_RD(src)                         (((src) & 0x00000008)<< 3)
#define MSEC27_F1_LE_WR(src)                   (((unsigned int)(src) >> 3) & 0x00000008)
#define MSEC27_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*	 Fields MSEC26	 */
#define MSEC26_F1_LE_WIDTH                                                    1
#define MSEC26_F1_LE_SHIFT                                                    5
#define MSEC26_F1_LE_MASK                                            0x00000004
#define MSEC26_F1_LE_RD(src)                         (((src) & 0x00000004)<< 2)
#define MSEC26_F1_LE_WR(src)                   (((unsigned int)(src) >> 2) & 0x00000004)
#define MSEC26_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*	 Fields MSEC25	 */
#define MSEC25_F1_LE_WIDTH                                                    1
#define MSEC25_F1_LE_SHIFT                                                    6
#define MSEC25_F1_LE_MASK                                            0x00000002
#define MSEC25_F1_LE_RD(src)                         (((src) & 0x00000002)<< 1)
#define MSEC25_F1_LE_WR(src)                   (((unsigned int)(src) >> 1) & 0x00000002)
#define MSEC25_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*	 Fields MSEC24	 */
#define MSEC24_F1_LE_WIDTH                                                    1
#define MSEC24_F1_LE_SHIFT                                                    7
#define MSEC24_F1_LE_MASK                                            0x00000001
#define MSEC24_F1_LE_RD(src)                         (((src) & 0x00000001)<< 0)
#define MSEC24_F1_LE_WR(src)                   (((unsigned int)(src) >> 0) & 0x00000001)
#define MSEC24_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*	 Fields MSEC23	 */
#define MSEC23_F1_LE_WIDTH                                                    1
#define MSEC23_F1_LE_SHIFT                                                    8
#define MSEC23_F1_LE_MASK                                            0x00008000
#define MSEC23_F1_LE_RD(src)                       (((src) & 0x00008000) >> 15)
#define MSEC23_F1_LE_WR(src)                  (((unsigned int)(src) << 15) & 0x00008000)
#define MSEC23_F1_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*	 Fields MSEC22	 */
#define MSEC22_F1_LE_WIDTH                                                    1
#define MSEC22_F1_LE_SHIFT                                                    9
#define MSEC22_F1_LE_MASK                                            0x00004000
#define MSEC22_F1_LE_RD(src)                       (((src) & 0x00004000) >> 14)
#define MSEC22_F1_LE_WR(src)                  (((unsigned int)(src) << 14) & 0x00004000)
#define MSEC22_F1_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*	 Fields MSEC21	 */
#define MSEC21_F1_LE_WIDTH                                                    1
#define MSEC21_F1_LE_SHIFT                                                   10
#define MSEC21_F1_LE_MASK                                            0x00002000
#define MSEC21_F1_LE_RD(src)                       (((src) & 0x00002000) >> 13)
#define MSEC21_F1_LE_WR(src)                  (((unsigned int)(src) << 13) & 0x00002000)
#define MSEC21_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*	 Fields MSEC20	 */
#define MSEC20_F1_LE_WIDTH                                                    1
#define MSEC20_F1_LE_SHIFT                                                   11
#define MSEC20_F1_LE_MASK                                            0x00001000
#define MSEC20_F1_LE_RD(src)                       (((src) & 0x00001000) >> 12)
#define MSEC20_F1_LE_WR(src)                  (((unsigned int)(src) << 12) & 0x00001000)
#define MSEC20_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*	 Fields MSEC19	 */
#define MSEC19_F1_LE_WIDTH                                                    1
#define MSEC19_F1_LE_SHIFT                                                   12
#define MSEC19_F1_LE_MASK                                            0x00000800
#define MSEC19_F1_LE_RD(src)                       (((src) & 0x00000800) >> 11)
#define MSEC19_F1_LE_WR(src)                  (((unsigned int)(src) << 11) & 0x00000800)
#define MSEC19_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*	 Fields MSEC18	 */
#define MSEC18_F1_LE_WIDTH                                                    1
#define MSEC18_F1_LE_SHIFT                                                   13
#define MSEC18_F1_LE_MASK                                            0x00000400
#define MSEC18_F1_LE_RD(src)                       (((src) & 0x00000400) >> 10)
#define MSEC18_F1_LE_WR(src)                  (((unsigned int)(src) << 10) & 0x00000400)
#define MSEC18_F1_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*	 Fields MSEC17	 */
#define MSEC17_F1_LE_WIDTH                                                    1
#define MSEC17_F1_LE_SHIFT                                                   14
#define MSEC17_F1_LE_MASK                                            0x00000200
#define MSEC17_F1_LE_RD(src)                        (((src) & 0x00000200) >> 9)
#define MSEC17_F1_LE_WR(src)                   (((unsigned int)(src) << 9) & 0x00000200)
#define MSEC17_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*	 Fields MSEC16	 */
#define MSEC16_F1_LE_WIDTH                                                    1
#define MSEC16_F1_LE_SHIFT                                                   15
#define MSEC16_F1_LE_MASK                                            0x00000100
#define MSEC16_F1_LE_RD(src)                        (((src) & 0x00000100) >> 8)
#define MSEC16_F1_LE_WR(src)                   (((unsigned int)(src) << 8) & 0x00000100)
#define MSEC16_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*	 Fields MSEC15	 */
#define MSEC15_F1_LE_WIDTH                                                    1
#define MSEC15_F1_LE_SHIFT                                                   16
#define MSEC15_F1_LE_MASK                                            0x00800000
#define MSEC15_F1_LE_RD(src)                       (((src) & 0x00800000) >> 23)
#define MSEC15_F1_LE_WR(src)                  (((unsigned int)(src) << 23) & 0x00800000)
#define MSEC15_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*	 Fields MSEC14	 */
#define MSEC14_F1_LE_WIDTH                                                    1
#define MSEC14_F1_LE_SHIFT                                                   17
#define MSEC14_F1_LE_MASK                                            0x00400000
#define MSEC14_F1_LE_RD(src)                       (((src) & 0x00400000) >> 22)
#define MSEC14_F1_LE_WR(src)                  (((unsigned int)(src) << 22) & 0x00400000)
#define MSEC14_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*	 Fields MSEC13	 */
#define MSEC13_F1_LE_WIDTH                                                    1
#define MSEC13_F1_LE_SHIFT                                                   18
#define MSEC13_F1_LE_MASK                                            0x00200000
#define MSEC13_F1_LE_RD(src)                       (((src) & 0x00200000) >> 21)
#define MSEC13_F1_LE_WR(src)                  (((unsigned int)(src) << 21) & 0x00200000)
#define MSEC13_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*	 Fields MSEC12	 */
#define MSEC12_F1_LE_WIDTH                                                    1
#define MSEC12_F1_LE_SHIFT                                                   19
#define MSEC12_F1_LE_MASK                                            0x00100000
#define MSEC12_F1_LE_RD(src)                       (((src) & 0x00100000) >> 20)
#define MSEC12_F1_LE_WR(src)                  (((unsigned int)(src) << 20) & 0x00100000)
#define MSEC12_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields MSEC11	 */
#define MSEC11_F1_LE_WIDTH                                                    1
#define MSEC11_F1_LE_SHIFT                                                   20
#define MSEC11_F1_LE_MASK                                            0x00080000
#define MSEC11_F1_LE_RD(src)                       (((src) & 0x00080000) >> 19)
#define MSEC11_F1_LE_WR(src)                  (((unsigned int)(src) << 19) & 0x00080000)
#define MSEC11_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*	 Fields MSEC10	 */
#define MSEC10_F1_LE_WIDTH                                                    1
#define MSEC10_F1_LE_SHIFT                                                   21
#define MSEC10_F1_LE_MASK                                            0x00040000
#define MSEC10_F1_LE_RD(src)                       (((src) & 0x00040000) >> 18)
#define MSEC10_F1_LE_WR(src)                  (((unsigned int)(src) << 18) & 0x00040000)
#define MSEC10_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*	 Fields MSEC9	 */
#define MSEC9_F1_LE_WIDTH                                                     1
#define MSEC9_F1_LE_SHIFT                                                    22
#define MSEC9_F1_LE_MASK                                             0x00020000
#define MSEC9_F1_LE_RD(src)                        (((src) & 0x00020000) >> 17)
#define MSEC9_F1_LE_WR(src)                   (((unsigned int)(src) << 17) & 0x00020000)
#define MSEC9_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*	 Fields MSEC8	 */
#define MSEC8_F1_LE_WIDTH                                                     1
#define MSEC8_F1_LE_SHIFT                                                    23
#define MSEC8_F1_LE_MASK                                             0x00010000
#define MSEC8_F1_LE_RD(src)                        (((src) & 0x00010000) >> 16)
#define MSEC8_F1_LE_WR(src)                   (((unsigned int)(src) << 16) & 0x00010000)
#define MSEC8_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*	 Fields MSEC7	 */
#define MSEC7_F1_LE_WIDTH                                                     1
#define MSEC7_F1_LE_SHIFT                                                    24
#define MSEC7_F1_LE_MASK                                             0x80000000
#define MSEC7_F1_LE_RD(src)                        (((src) & 0x80000000) >> 31)
#define MSEC7_F1_LE_WR(src)                   (((unsigned int)(src) << 31) & 0x80000000)
#define MSEC7_F1_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields MSEC6	 */
#define MSEC6_F1_LE_WIDTH                                                     1
#define MSEC6_F1_LE_SHIFT                                                    25
#define MSEC6_F1_LE_MASK                                             0x40000000
#define MSEC6_F1_LE_RD(src)                        (((src) & 0x40000000) >> 30)
#define MSEC6_F1_LE_WR(src)                   (((unsigned int)(src) << 30) & 0x40000000)
#define MSEC6_F1_LE_SET(dst,src)                     ((dst)&~0x40000000)|\
				(((unsigned int)(src) << 30) & 0x40000000)

/*	 Fields MSEC5	 */
#define MSEC5_F1_LE_WIDTH                                                     1
#define MSEC5_F1_LE_SHIFT                                                    26
#define MSEC5_F1_LE_MASK                                             0x20000000
#define MSEC5_F1_LE_RD(src)                        (((src) & 0x20000000) >> 29)
#define MSEC5_F1_LE_WR(src)                   (((unsigned int)(src) << 29) & 0x20000000)
#define MSEC5_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields MSEC4	 */
#define MSEC4_F1_LE_WIDTH                                                     1
#define MSEC4_F1_LE_SHIFT                                                    27
#define MSEC4_F1_LE_MASK                                             0x10000000
#define MSEC4_F1_LE_RD(src)                        (((src) & 0x10000000) >> 28)
#define MSEC4_F1_LE_WR(src)                   (((unsigned int)(src) << 28) & 0x10000000)
#define MSEC4_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields MSEC3	 */
#define MSEC3_F1_LE_WIDTH                                                     1
#define MSEC3_F1_LE_SHIFT                                                    28
#define MSEC3_F1_LE_MASK                                             0x08000000
#define MSEC3_F1_LE_RD(src)                        (((src) & 0x08000000) >> 27)
#define MSEC3_F1_LE_WR(src)                   (((unsigned int)(src) << 27) & 0x08000000)
#define MSEC3_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields MSEC2	 */
#define MSEC2_F1_LE_WIDTH                                                     1
#define MSEC2_F1_LE_SHIFT                                                    29
#define MSEC2_F1_LE_MASK                                             0x04000000
#define MSEC2_F1_LE_RD(src)                        (((src) & 0x04000000) >> 26)
#define MSEC2_F1_LE_WR(src)                   (((unsigned int)(src) << 26) & 0x04000000)
#define MSEC2_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields MSEC1	 */
#define MSEC1_F1_LE_WIDTH                                                     1
#define MSEC1_F1_LE_SHIFT                                                    30
#define MSEC1_F1_LE_MASK                                             0x02000000
#define MSEC1_F1_LE_RD(src)                        (((src) & 0x02000000) >> 25)
#define MSEC1_F1_LE_WR(src)                   (((unsigned int)(src) << 25) & 0x02000000)
#define MSEC1_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields MSEC0	 */
#define MSEC0_F1_LE_WIDTH                                                     1
#define MSEC0_F1_LE_SHIFT                                                    31
#define MSEC0_F1_LE_MASK                                             0x01000000
#define MSEC0_F1_LE_RD(src)                        (((src) & 0x01000000) >> 24)
#define MSEC0_F1_LE_WR(src)                   (((unsigned int)(src) << 24) & 0x01000000)
#define MSEC0_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register GLBL_MSEC_ERRLMask	*/

/*Mask Register Fields MSEC31Mask	 */
#define MSEC31MASK_F1_LE_WIDTH                                                1
#define MSEC31MASK_F1_LE_SHIFT                                                0
#define MSEC31MASK_F1_LE_MASK                                        0x00000080
#define MSEC31MASK_F1_LE_RD(src)                     (((src) & 0x00000080)<< 7)
#define MSEC31MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 7) & 0x00000080)
#define MSEC31MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*Mask Register Fields MSEC30Mask	 */
#define MSEC30MASK_F1_LE_WIDTH                                                1
#define MSEC30MASK_F1_LE_SHIFT                                                1
#define MSEC30MASK_F1_LE_MASK                                        0x00000040
#define MSEC30MASK_F1_LE_RD(src)                     (((src) & 0x00000040)<< 6)
#define MSEC30MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 6) & 0x00000040)
#define MSEC30MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*Mask Register Fields MSEC29Mask	 */
#define MSEC29MASK_F1_LE_WIDTH                                                1
#define MSEC29MASK_F1_LE_SHIFT                                                2
#define MSEC29MASK_F1_LE_MASK                                        0x00000020
#define MSEC29MASK_F1_LE_RD(src)                     (((src) & 0x00000020)<< 5)
#define MSEC29MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 5) & 0x00000020)
#define MSEC29MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*Mask Register Fields MSEC28Mask	 */
#define MSEC28MASK_F1_LE_WIDTH                                                1
#define MSEC28MASK_F1_LE_SHIFT                                                3
#define MSEC28MASK_F1_LE_MASK                                        0x00000010
#define MSEC28MASK_F1_LE_RD(src)                     (((src) & 0x00000010)<< 4)
#define MSEC28MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 4) & 0x00000010)
#define MSEC28MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*Mask Register Fields MSEC27Mask	 */
#define MSEC27MASK_F1_LE_WIDTH                                                1
#define MSEC27MASK_F1_LE_SHIFT                                                4
#define MSEC27MASK_F1_LE_MASK                                        0x00000008
#define MSEC27MASK_F1_LE_RD(src)                     (((src) & 0x00000008)<< 3)
#define MSEC27MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 3) & 0x00000008)
#define MSEC27MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*Mask Register Fields MSEC26Mask	 */
#define MSEC26MASK_F1_LE_WIDTH                                                1
#define MSEC26MASK_F1_LE_SHIFT                                                5
#define MSEC26MASK_F1_LE_MASK                                        0x00000004
#define MSEC26MASK_F1_LE_RD(src)                     (((src) & 0x00000004)<< 2)
#define MSEC26MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 2) & 0x00000004)
#define MSEC26MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*Mask Register Fields MSEC25Mask	 */
#define MSEC25MASK_F1_LE_WIDTH                                                1
#define MSEC25MASK_F1_LE_SHIFT                                                6
#define MSEC25MASK_F1_LE_MASK                                        0x00000002
#define MSEC25MASK_F1_LE_RD(src)                     (((src) & 0x00000002)<< 1)
#define MSEC25MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 1) & 0x00000002)
#define MSEC25MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*Mask Register Fields MSEC24Mask	 */
#define MSEC24MASK_F1_LE_WIDTH                                                1
#define MSEC24MASK_F1_LE_SHIFT                                                7
#define MSEC24MASK_F1_LE_MASK                                        0x00000001
#define MSEC24MASK_F1_LE_RD(src)                     (((src) & 0x00000001)<< 0)
#define MSEC24MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 0) & 0x00000001)
#define MSEC24MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*Mask Register Fields MSEC23Mask	 */
#define MSEC23MASK_F1_LE_WIDTH                                                1
#define MSEC23MASK_F1_LE_SHIFT                                                8
#define MSEC23MASK_F1_LE_MASK                                        0x00008000
#define MSEC23MASK_F1_LE_RD(src)                   (((src) & 0x00008000) >> 15)
#define MSEC23MASK_F1_LE_WR(src)              (((unsigned int)(src) << 15) & 0x00008000)
#define MSEC23MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*Mask Register Fields MSEC22Mask	 */
#define MSEC22MASK_F1_LE_WIDTH                                                1
#define MSEC22MASK_F1_LE_SHIFT                                                9
#define MSEC22MASK_F1_LE_MASK                                        0x00004000
#define MSEC22MASK_F1_LE_RD(src)                   (((src) & 0x00004000) >> 14)
#define MSEC22MASK_F1_LE_WR(src)              (((unsigned int)(src) << 14) & 0x00004000)
#define MSEC22MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*Mask Register Fields MSEC21Mask	 */
#define MSEC21MASK_F1_LE_WIDTH                                                1
#define MSEC21MASK_F1_LE_SHIFT                                               10
#define MSEC21MASK_F1_LE_MASK                                        0x00002000
#define MSEC21MASK_F1_LE_RD(src)                   (((src) & 0x00002000) >> 13)
#define MSEC21MASK_F1_LE_WR(src)              (((unsigned int)(src) << 13) & 0x00002000)
#define MSEC21MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*Mask Register Fields MSEC20Mask	 */
#define MSEC20MASK_F1_LE_WIDTH                                                1
#define MSEC20MASK_F1_LE_SHIFT                                               11
#define MSEC20MASK_F1_LE_MASK                                        0x00001000
#define MSEC20MASK_F1_LE_RD(src)                   (((src) & 0x00001000) >> 12)
#define MSEC20MASK_F1_LE_WR(src)              (((unsigned int)(src) << 12) & 0x00001000)
#define MSEC20MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*Mask Register Fields MSEC19Mask	 */
#define MSEC19MASK_F1_LE_WIDTH                                                1
#define MSEC19MASK_F1_LE_SHIFT                                               12
#define MSEC19MASK_F1_LE_MASK                                        0x00000800
#define MSEC19MASK_F1_LE_RD(src)                   (((src) & 0x00000800) >> 11)
#define MSEC19MASK_F1_LE_WR(src)              (((unsigned int)(src) << 11) & 0x00000800)
#define MSEC19MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*Mask Register Fields MSEC18Mask	 */
#define MSEC18MASK_F1_LE_WIDTH                                                1
#define MSEC18MASK_F1_LE_SHIFT                                               13
#define MSEC18MASK_F1_LE_MASK                                        0x00000400
#define MSEC18MASK_F1_LE_RD(src)                   (((src) & 0x00000400) >> 10)
#define MSEC18MASK_F1_LE_WR(src)              (((unsigned int)(src) << 10) & 0x00000400)
#define MSEC18MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*Mask Register Fields MSEC17Mask	 */
#define MSEC17MASK_F1_LE_WIDTH                                                1
#define MSEC17MASK_F1_LE_SHIFT                                               14
#define MSEC17MASK_F1_LE_MASK                                        0x00000200
#define MSEC17MASK_F1_LE_RD(src)                    (((src) & 0x00000200) >> 9)
#define MSEC17MASK_F1_LE_WR(src)               (((unsigned int)(src) << 9) & 0x00000200)
#define MSEC17MASK_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*Mask Register Fields MSEC16Mask	 */
#define MSEC16MASK_F1_LE_WIDTH                                                1
#define MSEC16MASK_F1_LE_SHIFT                                               15
#define MSEC16MASK_F1_LE_MASK                                        0x00000100
#define MSEC16MASK_F1_LE_RD(src)                    (((src) & 0x00000100) >> 8)
#define MSEC16MASK_F1_LE_WR(src)               (((unsigned int)(src) << 8) & 0x00000100)
#define MSEC16MASK_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*Mask Register Fields MSEC15Mask	 */
#define MSEC15MASK_F1_LE_WIDTH                                                1
#define MSEC15MASK_F1_LE_SHIFT                                               16
#define MSEC15MASK_F1_LE_MASK                                        0x00800000
#define MSEC15MASK_F1_LE_RD(src)                   (((src) & 0x00800000) >> 23)
#define MSEC15MASK_F1_LE_WR(src)              (((unsigned int)(src) << 23) & 0x00800000)
#define MSEC15MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*Mask Register Fields MSEC14Mask	 */
#define MSEC14MASK_F1_LE_WIDTH                                                1
#define MSEC14MASK_F1_LE_SHIFT                                               17
#define MSEC14MASK_F1_LE_MASK                                        0x00400000
#define MSEC14MASK_F1_LE_RD(src)                   (((src) & 0x00400000) >> 22)
#define MSEC14MASK_F1_LE_WR(src)              (((unsigned int)(src) << 22) & 0x00400000)
#define MSEC14MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*Mask Register Fields MSEC13Mask	 */
#define MSEC13MASK_F1_LE_WIDTH                                                1
#define MSEC13MASK_F1_LE_SHIFT                                               18
#define MSEC13MASK_F1_LE_MASK                                        0x00200000
#define MSEC13MASK_F1_LE_RD(src)                   (((src) & 0x00200000) >> 21)
#define MSEC13MASK_F1_LE_WR(src)              (((unsigned int)(src) << 21) & 0x00200000)
#define MSEC13MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*Mask Register Fields MSEC12Mask	 */
#define MSEC12MASK_F1_LE_WIDTH                                                1
#define MSEC12MASK_F1_LE_SHIFT                                               19
#define MSEC12MASK_F1_LE_MASK                                        0x00100000
#define MSEC12MASK_F1_LE_RD(src)                   (((src) & 0x00100000) >> 20)
#define MSEC12MASK_F1_LE_WR(src)              (((unsigned int)(src) << 20) & 0x00100000)
#define MSEC12MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*Mask Register Fields MSEC11Mask	 */
#define MSEC11MASK_F1_LE_WIDTH                                                1
#define MSEC11MASK_F1_LE_SHIFT                                               20
#define MSEC11MASK_F1_LE_MASK                                        0x00080000
#define MSEC11MASK_F1_LE_RD(src)                   (((src) & 0x00080000) >> 19)
#define MSEC11MASK_F1_LE_WR(src)              (((unsigned int)(src) << 19) & 0x00080000)
#define MSEC11MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*Mask Register Fields MSEC10Mask	 */
#define MSEC10MASK_F1_LE_WIDTH                                                1
#define MSEC10MASK_F1_LE_SHIFT                                               21
#define MSEC10MASK_F1_LE_MASK                                        0x00040000
#define MSEC10MASK_F1_LE_RD(src)                   (((src) & 0x00040000) >> 18)
#define MSEC10MASK_F1_LE_WR(src)              (((unsigned int)(src) << 18) & 0x00040000)
#define MSEC10MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*Mask Register Fields MSEC9Mask	 */
#define MSEC9MASK_F1_LE_WIDTH                                                 1
#define MSEC9MASK_F1_LE_SHIFT                                                22
#define MSEC9MASK_F1_LE_MASK                                         0x00020000
#define MSEC9MASK_F1_LE_RD(src)                    (((src) & 0x00020000) >> 17)
#define MSEC9MASK_F1_LE_WR(src)               (((unsigned int)(src) << 17) & 0x00020000)
#define MSEC9MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*Mask Register Fields MSEC8Mask	 */
#define MSEC8MASK_F1_LE_WIDTH                                                 1
#define MSEC8MASK_F1_LE_SHIFT                                                23
#define MSEC8MASK_F1_LE_MASK                                         0x00010000
#define MSEC8MASK_F1_LE_RD(src)                    (((src) & 0x00010000) >> 16)
#define MSEC8MASK_F1_LE_WR(src)               (((unsigned int)(src) << 16) & 0x00010000)
#define MSEC8MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*Mask Register Fields MSEC7Mask	 */
#define MSEC7MASK_F1_LE_WIDTH                                                 1
#define MSEC7MASK_F1_LE_SHIFT                                                24
#define MSEC7MASK_F1_LE_MASK                                         0x80000000
#define MSEC7MASK_F1_LE_RD(src)                    (((src) & 0x80000000) >> 31)
#define MSEC7MASK_F1_LE_WR(src)               (((unsigned int)(src) << 31) & 0x80000000)
#define MSEC7MASK_F1_LE_SET(dst,src)                      ((dst)&~0x80000000)|\
			(((unsigned int)(src) << 31) & 0x80000000)

/*Mask Register Fields MSEC6Mask	 */
#define MSEC6MASK_F1_LE_WIDTH                                                 1
#define MSEC6MASK_F1_LE_SHIFT                                                25
#define MSEC6MASK_F1_LE_MASK                                         0x40000000
#define MSEC6MASK_F1_LE_RD(src)                    (((src) & 0x40000000) >> 30)
#define MSEC6MASK_F1_LE_WR(src)               (((unsigned int)(src) << 30) & 0x40000000)
#define MSEC6MASK_F1_LE_SET(dst,src)                      ((dst)&~0x40000000)|\
			(((unsigned int)(src) << 30) & 0x40000000)

/*Mask Register Fields MSEC5Mask	 */
#define MSEC5MASK_F1_LE_WIDTH                                                 1
#define MSEC5MASK_F1_LE_SHIFT                                                26
#define MSEC5MASK_F1_LE_MASK                                         0x20000000
#define MSEC5MASK_F1_LE_RD(src)                    (((src) & 0x20000000) >> 29)
#define MSEC5MASK_F1_LE_WR(src)               (((unsigned int)(src) << 29) & 0x20000000)
#define MSEC5MASK_F1_LE_SET(dst,src)                      ((dst)&~0x20000000)|\
			(((unsigned int)(src) << 29) & 0x20000000)

/*Mask Register Fields MSEC4Mask	 */
#define MSEC4MASK_F1_LE_WIDTH                                                 1
#define MSEC4MASK_F1_LE_SHIFT                                                27
#define MSEC4MASK_F1_LE_MASK                                         0x10000000
#define MSEC4MASK_F1_LE_RD(src)                    (((src) & 0x10000000) >> 28)
#define MSEC4MASK_F1_LE_WR(src)               (((unsigned int)(src) << 28) & 0x10000000)
#define MSEC4MASK_F1_LE_SET(dst,src)                      ((dst)&~0x10000000)|\
			(((unsigned int)(src) << 28) & 0x10000000)

/*Mask Register Fields MSEC3Mask	 */
#define MSEC3MASK_F1_LE_WIDTH                                                 1
#define MSEC3MASK_F1_LE_SHIFT                                                28
#define MSEC3MASK_F1_LE_MASK                                         0x08000000
#define MSEC3MASK_F1_LE_RD(src)                    (((src) & 0x08000000) >> 27)
#define MSEC3MASK_F1_LE_WR(src)               (((unsigned int)(src) << 27) & 0x08000000)
#define MSEC3MASK_F1_LE_SET(dst,src)                      ((dst)&~0x08000000)|\
			(((unsigned int)(src) << 27) & 0x08000000)

/*Mask Register Fields MSEC2Mask	 */
#define MSEC2MASK_F1_LE_WIDTH                                                 1
#define MSEC2MASK_F1_LE_SHIFT                                                29
#define MSEC2MASK_F1_LE_MASK                                         0x04000000
#define MSEC2MASK_F1_LE_RD(src)                    (((src) & 0x04000000) >> 26)
#define MSEC2MASK_F1_LE_WR(src)               (((unsigned int)(src) << 26) & 0x04000000)
#define MSEC2MASK_F1_LE_SET(dst,src)                      ((dst)&~0x04000000)|\
			(((unsigned int)(src) << 26) & 0x04000000)

/*Mask Register Fields MSEC1Mask	 */
#define MSEC1MASK_F1_LE_WIDTH                                                 1
#define MSEC1MASK_F1_LE_SHIFT                                                30
#define MSEC1MASK_F1_LE_MASK                                         0x02000000
#define MSEC1MASK_F1_LE_RD(src)                    (((src) & 0x02000000) >> 25)
#define MSEC1MASK_F1_LE_WR(src)               (((unsigned int)(src) << 25) & 0x02000000)
#define MSEC1MASK_F1_LE_SET(dst,src)                      ((dst)&~0x02000000)|\
			(((unsigned int)(src) << 25) & 0x02000000)

/*Mask Register Fields MSEC0Mask	 */
#define MSEC0MASK_F1_LE_WIDTH                                                 1
#define MSEC0MASK_F1_LE_SHIFT                                                31
#define MSEC0MASK_F1_LE_MASK                                         0x01000000
#define MSEC0MASK_F1_LE_RD(src)                    (((src) & 0x01000000) >> 24)
#define MSEC0MASK_F1_LE_WR(src)               (((unsigned int)(src) << 24) & 0x01000000)
#define MSEC0MASK_F1_LE_SET(dst,src)                      ((dst)&~0x01000000)|\
			(((unsigned int)(src) << 24) & 0x01000000)

/*	Register GLBL_MSEC_ERRH	*/

/*	 Fields MSEC63	 */
#define MSEC63_F1_LE_WIDTH                                                    1
#define MSEC63_F1_LE_SHIFT                                                    0
#define MSEC63_F1_LE_MASK                                            0x00000080
#define MSEC63_F1_LE_RD(src)                         (((src) & 0x00000080)<< 7)
#define MSEC63_F1_LE_WR(src)                   (((unsigned int)(src) >> 7) & 0x00000080)
#define MSEC63_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields MSEC62	 */
#define MSEC62_F1_LE_WIDTH                                                    1
#define MSEC62_F1_LE_SHIFT                                                    1
#define MSEC62_F1_LE_MASK                                            0x00000040
#define MSEC62_F1_LE_RD(src)                         (((src) & 0x00000040)<< 6)
#define MSEC62_F1_LE_WR(src)                   (((unsigned int)(src) >> 6) & 0x00000040)
#define MSEC62_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields MSEC61	 */
#define MSEC61_F1_LE_WIDTH                                                    1
#define MSEC61_F1_LE_SHIFT                                                    2
#define MSEC61_F1_LE_MASK                                            0x00000020
#define MSEC61_F1_LE_RD(src)                         (((src) & 0x00000020)<< 5)
#define MSEC61_F1_LE_WR(src)                   (((unsigned int)(src) >> 5) & 0x00000020)
#define MSEC61_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*	 Fields MSEC60	 */
#define MSEC60_F1_LE_WIDTH                                                    1
#define MSEC60_F1_LE_SHIFT                                                    3
#define MSEC60_F1_LE_MASK                                            0x00000010
#define MSEC60_F1_LE_RD(src)                         (((src) & 0x00000010)<< 4)
#define MSEC60_F1_LE_WR(src)                   (((unsigned int)(src) >> 4) & 0x00000010)
#define MSEC60_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields MSEC59	 */
#define MSEC59_F1_LE_WIDTH                                                    1
#define MSEC59_F1_LE_SHIFT                                                    4
#define MSEC59_F1_LE_MASK                                            0x00000008
#define MSEC59_F1_LE_RD(src)                         (((src) & 0x00000008)<< 3)
#define MSEC59_F1_LE_WR(src)                   (((unsigned int)(src) >> 3) & 0x00000008)
#define MSEC59_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*	 Fields MSEC58	 */
#define MSEC58_F1_LE_WIDTH                                                    1
#define MSEC58_F1_LE_SHIFT                                                    5
#define MSEC58_F1_LE_MASK                                            0x00000004
#define MSEC58_F1_LE_RD(src)                         (((src) & 0x00000004)<< 2)
#define MSEC58_F1_LE_WR(src)                   (((unsigned int)(src) >> 2) & 0x00000004)
#define MSEC58_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*	 Fields MSEC57	 */
#define MSEC57_F1_LE_WIDTH                                                    1
#define MSEC57_F1_LE_SHIFT                                                    6
#define MSEC57_F1_LE_MASK                                            0x00000002
#define MSEC57_F1_LE_RD(src)                         (((src) & 0x00000002)<< 1)
#define MSEC57_F1_LE_WR(src)                   (((unsigned int)(src) >> 1) & 0x00000002)
#define MSEC57_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*	 Fields MSEC56	 */
#define MSEC56_F1_LE_WIDTH                                                    1
#define MSEC56_F1_LE_SHIFT                                                    7
#define MSEC56_F1_LE_MASK                                            0x00000001
#define MSEC56_F1_LE_RD(src)                         (((src) & 0x00000001)<< 0)
#define MSEC56_F1_LE_WR(src)                   (((unsigned int)(src) >> 0) & 0x00000001)
#define MSEC56_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*	 Fields MSEC55	 */
#define MSEC55_F1_LE_WIDTH                                                    1
#define MSEC55_F1_LE_SHIFT                                                    8
#define MSEC55_F1_LE_MASK                                            0x00008000
#define MSEC55_F1_LE_RD(src)                       (((src) & 0x00008000) >> 15)
#define MSEC55_F1_LE_WR(src)                  (((unsigned int)(src) << 15) & 0x00008000)
#define MSEC55_F1_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*	 Fields MSEC54	 */
#define MSEC54_F1_LE_WIDTH                                                    1
#define MSEC54_F1_LE_SHIFT                                                    9
#define MSEC54_F1_LE_MASK                                            0x00004000
#define MSEC54_F1_LE_RD(src)                       (((src) & 0x00004000) >> 14)
#define MSEC54_F1_LE_WR(src)                  (((unsigned int)(src) << 14) & 0x00004000)
#define MSEC54_F1_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*	 Fields MSEC53	 */
#define MSEC53_F1_LE_WIDTH                                                    1
#define MSEC53_F1_LE_SHIFT                                                   10
#define MSEC53_F1_LE_MASK                                            0x00002000
#define MSEC53_F1_LE_RD(src)                       (((src) & 0x00002000) >> 13)
#define MSEC53_F1_LE_WR(src)                  (((unsigned int)(src) << 13) & 0x00002000)
#define MSEC53_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*	 Fields MSEC52	 */
#define MSEC52_F1_LE_WIDTH                                                    1
#define MSEC52_F1_LE_SHIFT                                                   11
#define MSEC52_F1_LE_MASK                                            0x00001000
#define MSEC52_F1_LE_RD(src)                       (((src) & 0x00001000) >> 12)
#define MSEC52_F1_LE_WR(src)                  (((unsigned int)(src) << 12) & 0x00001000)
#define MSEC52_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*	 Fields MSEC51	 */
#define MSEC51_F1_LE_WIDTH                                                    1
#define MSEC51_F1_LE_SHIFT                                                   12
#define MSEC51_F1_LE_MASK                                            0x00000800
#define MSEC51_F1_LE_RD(src)                       (((src) & 0x00000800) >> 11)
#define MSEC51_F1_LE_WR(src)                  (((unsigned int)(src) << 11) & 0x00000800)
#define MSEC51_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*	 Fields MSEC50	 */
#define MSEC50_F1_LE_WIDTH                                                    1
#define MSEC50_F1_LE_SHIFT                                                   13
#define MSEC50_F1_LE_MASK                                            0x00000400
#define MSEC50_F1_LE_RD(src)                       (((src) & 0x00000400) >> 10)
#define MSEC50_F1_LE_WR(src)                  (((unsigned int)(src) << 10) & 0x00000400)
#define MSEC50_F1_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*	 Fields MSEC49	 */
#define MSEC49_F1_LE_WIDTH                                                    1
#define MSEC49_F1_LE_SHIFT                                                   14
#define MSEC49_F1_LE_MASK                                            0x00000200
#define MSEC49_F1_LE_RD(src)                        (((src) & 0x00000200) >> 9)
#define MSEC49_F1_LE_WR(src)                   (((unsigned int)(src) << 9) & 0x00000200)
#define MSEC49_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*	 Fields MSEC48	 */
#define MSEC48_F1_LE_WIDTH                                                    1
#define MSEC48_F1_LE_SHIFT                                                   15
#define MSEC48_F1_LE_MASK                                            0x00000100
#define MSEC48_F1_LE_RD(src)                        (((src) & 0x00000100) >> 8)
#define MSEC48_F1_LE_WR(src)                   (((unsigned int)(src) << 8) & 0x00000100)
#define MSEC48_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*	 Fields MSEC47	 */
#define MSEC47_F1_LE_WIDTH                                                    1
#define MSEC47_F1_LE_SHIFT                                                   16
#define MSEC47_F1_LE_MASK                                            0x00800000
#define MSEC47_F1_LE_RD(src)                       (((src) & 0x00800000) >> 23)
#define MSEC47_F1_LE_WR(src)                  (((unsigned int)(src) << 23) & 0x00800000)
#define MSEC47_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*	 Fields MSEC46	 */
#define MSEC46_F1_LE_WIDTH                                                    1
#define MSEC46_F1_LE_SHIFT                                                   17
#define MSEC46_F1_LE_MASK                                            0x00400000
#define MSEC46_F1_LE_RD(src)                       (((src) & 0x00400000) >> 22)
#define MSEC46_F1_LE_WR(src)                  (((unsigned int)(src) << 22) & 0x00400000)
#define MSEC46_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*	 Fields MSEC45	 */
#define MSEC45_F1_LE_WIDTH                                                    1
#define MSEC45_F1_LE_SHIFT                                                   18
#define MSEC45_F1_LE_MASK                                            0x00200000
#define MSEC45_F1_LE_RD(src)                       (((src) & 0x00200000) >> 21)
#define MSEC45_F1_LE_WR(src)                  (((unsigned int)(src) << 21) & 0x00200000)
#define MSEC45_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*	 Fields MSEC44	 */
#define MSEC44_F1_LE_WIDTH                                                    1
#define MSEC44_F1_LE_SHIFT                                                   19
#define MSEC44_F1_LE_MASK                                            0x00100000
#define MSEC44_F1_LE_RD(src)                       (((src) & 0x00100000) >> 20)
#define MSEC44_F1_LE_WR(src)                  (((unsigned int)(src) << 20) & 0x00100000)
#define MSEC44_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields MSEC43	 */
#define MSEC43_F1_LE_WIDTH                                                    1
#define MSEC43_F1_LE_SHIFT                                                   20
#define MSEC43_F1_LE_MASK                                            0x00080000
#define MSEC43_F1_LE_RD(src)                       (((src) & 0x00080000) >> 19)
#define MSEC43_F1_LE_WR(src)                  (((unsigned int)(src) << 19) & 0x00080000)
#define MSEC43_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*	 Fields MSEC42	 */
#define MSEC42_F1_LE_WIDTH                                                    1
#define MSEC42_F1_LE_SHIFT                                                   21
#define MSEC42_F1_LE_MASK                                            0x00040000
#define MSEC42_F1_LE_RD(src)                       (((src) & 0x00040000) >> 18)
#define MSEC42_F1_LE_WR(src)                  (((unsigned int)(src) << 18) & 0x00040000)
#define MSEC42_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*	 Fields MSEC41	 */
#define MSEC41_F1_LE_WIDTH                                                    1
#define MSEC41_F1_LE_SHIFT                                                   22
#define MSEC41_F1_LE_MASK                                            0x00020000
#define MSEC41_F1_LE_RD(src)                       (((src) & 0x00020000) >> 17)
#define MSEC41_F1_LE_WR(src)                  (((unsigned int)(src) << 17) & 0x00020000)
#define MSEC41_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*	 Fields MSEC40	 */
#define MSEC40_F1_LE_WIDTH                                                    1
#define MSEC40_F1_LE_SHIFT                                                   23
#define MSEC40_F1_LE_MASK                                            0x00010000
#define MSEC40_F1_LE_RD(src)                       (((src) & 0x00010000) >> 16)
#define MSEC40_F1_LE_WR(src)                  (((unsigned int)(src) << 16) & 0x00010000)
#define MSEC40_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*	 Fields MSEC39	 */
#define MSEC39_F1_LE_WIDTH                                                    1
#define MSEC39_F1_LE_SHIFT                                                   24
#define MSEC39_F1_LE_MASK                                            0x80000000
#define MSEC39_F1_LE_RD(src)                       (((src) & 0x80000000) >> 31)
#define MSEC39_F1_LE_WR(src)                  (((unsigned int)(src) << 31) & 0x80000000)
#define MSEC39_F1_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields MSEC38	 */
#define MSEC38_F1_LE_WIDTH                                                    1
#define MSEC38_F1_LE_SHIFT                                                   25
#define MSEC38_F1_LE_MASK                                            0x40000000
#define MSEC38_F1_LE_RD(src)                       (((src) & 0x40000000) >> 30)
#define MSEC38_F1_LE_WR(src)                  (((unsigned int)(src) << 30) & 0x40000000)
#define MSEC38_F1_LE_SET(dst,src)                     ((dst)&~0x40000000)|\
				(((unsigned int)(src) << 30) & 0x40000000)

/*	 Fields MSEC37	 */
#define MSEC37_F1_LE_WIDTH                                                    1
#define MSEC37_F1_LE_SHIFT                                                   26
#define MSEC37_F1_LE_MASK                                            0x20000000
#define MSEC37_F1_LE_RD(src)                       (((src) & 0x20000000) >> 29)
#define MSEC37_F1_LE_WR(src)                  (((unsigned int)(src) << 29) & 0x20000000)
#define MSEC37_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields MSEC36	 */
#define MSEC36_F1_LE_WIDTH                                                    1
#define MSEC36_F1_LE_SHIFT                                                   27
#define MSEC36_F1_LE_MASK                                            0x10000000
#define MSEC36_F1_LE_RD(src)                       (((src) & 0x10000000) >> 28)
#define MSEC36_F1_LE_WR(src)                  (((unsigned int)(src) << 28) & 0x10000000)
#define MSEC36_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields MSEC35	 */
#define MSEC35_F1_LE_WIDTH                                                    1
#define MSEC35_F1_LE_SHIFT                                                   28
#define MSEC35_F1_LE_MASK                                            0x08000000
#define MSEC35_F1_LE_RD(src)                       (((src) & 0x08000000) >> 27)
#define MSEC35_F1_LE_WR(src)                  (((unsigned int)(src) << 27) & 0x08000000)
#define MSEC35_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields MSEC34	 */
#define MSEC34_F1_LE_WIDTH                                                    1
#define MSEC34_F1_LE_SHIFT                                                   29
#define MSEC34_F1_LE_MASK                                            0x04000000
#define MSEC34_F1_LE_RD(src)                       (((src) & 0x04000000) >> 26)
#define MSEC34_F1_LE_WR(src)                  (((unsigned int)(src) << 26) & 0x04000000)
#define MSEC34_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields MSEC33	 */
#define MSEC33_F1_LE_WIDTH                                                    1
#define MSEC33_F1_LE_SHIFT                                                   30
#define MSEC33_F1_LE_MASK                                            0x02000000
#define MSEC33_F1_LE_RD(src)                       (((src) & 0x02000000) >> 25)
#define MSEC33_F1_LE_WR(src)                  (((unsigned int)(src) << 25) & 0x02000000)
#define MSEC33_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields MSEC32	 */
#define MSEC32_F1_LE_WIDTH                                                    1
#define MSEC32_F1_LE_SHIFT                                                   31
#define MSEC32_F1_LE_MASK                                            0x01000000
#define MSEC32_F1_LE_RD(src)                       (((src) & 0x01000000) >> 24)
#define MSEC32_F1_LE_WR(src)                  (((unsigned int)(src) << 24) & 0x01000000)
#define MSEC32_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register GLBL_MSEC_ERRHMask	*/

/*Mask Register Fields MSEC63Mask	 */
#define MSEC63MASK_F1_LE_WIDTH                                                1
#define MSEC63MASK_F1_LE_SHIFT                                                0
#define MSEC63MASK_F1_LE_MASK                                        0x00000080
#define MSEC63MASK_F1_LE_RD(src)                     (((src) & 0x00000080)<< 7)
#define MSEC63MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 7) & 0x00000080)
#define MSEC63MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*Mask Register Fields MSEC62Mask	 */
#define MSEC62MASK_F1_LE_WIDTH                                                1
#define MSEC62MASK_F1_LE_SHIFT                                                1
#define MSEC62MASK_F1_LE_MASK                                        0x00000040
#define MSEC62MASK_F1_LE_RD(src)                     (((src) & 0x00000040)<< 6)
#define MSEC62MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 6) & 0x00000040)
#define MSEC62MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*Mask Register Fields MSEC61Mask	 */
#define MSEC61MASK_F1_LE_WIDTH                                                1
#define MSEC61MASK_F1_LE_SHIFT                                                2
#define MSEC61MASK_F1_LE_MASK                                        0x00000020
#define MSEC61MASK_F1_LE_RD(src)                     (((src) & 0x00000020)<< 5)
#define MSEC61MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 5) & 0x00000020)
#define MSEC61MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*Mask Register Fields MSEC60Mask	 */
#define MSEC60MASK_F1_LE_WIDTH                                                1
#define MSEC60MASK_F1_LE_SHIFT                                                3
#define MSEC60MASK_F1_LE_MASK                                        0x00000010
#define MSEC60MASK_F1_LE_RD(src)                     (((src) & 0x00000010)<< 4)
#define MSEC60MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 4) & 0x00000010)
#define MSEC60MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*Mask Register Fields MSEC59Mask	 */
#define MSEC59MASK_F1_LE_WIDTH                                                1
#define MSEC59MASK_F1_LE_SHIFT                                                4
#define MSEC59MASK_F1_LE_MASK                                        0x00000008
#define MSEC59MASK_F1_LE_RD(src)                     (((src) & 0x00000008)<< 3)
#define MSEC59MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 3) & 0x00000008)
#define MSEC59MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*Mask Register Fields MSEC58Mask	 */
#define MSEC58MASK_F1_LE_WIDTH                                                1
#define MSEC58MASK_F1_LE_SHIFT                                                5
#define MSEC58MASK_F1_LE_MASK                                        0x00000004
#define MSEC58MASK_F1_LE_RD(src)                     (((src) & 0x00000004)<< 2)
#define MSEC58MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 2) & 0x00000004)
#define MSEC58MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*Mask Register Fields MSEC57Mask	 */
#define MSEC57MASK_F1_LE_WIDTH                                                1
#define MSEC57MASK_F1_LE_SHIFT                                                6
#define MSEC57MASK_F1_LE_MASK                                        0x00000002
#define MSEC57MASK_F1_LE_RD(src)                     (((src) & 0x00000002)<< 1)
#define MSEC57MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 1) & 0x00000002)
#define MSEC57MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*Mask Register Fields MSEC56Mask	 */
#define MSEC56MASK_F1_LE_WIDTH                                                1
#define MSEC56MASK_F1_LE_SHIFT                                                7
#define MSEC56MASK_F1_LE_MASK                                        0x00000001
#define MSEC56MASK_F1_LE_RD(src)                     (((src) & 0x00000001)<< 0)
#define MSEC56MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 0) & 0x00000001)
#define MSEC56MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*Mask Register Fields MSEC55Mask	 */
#define MSEC55MASK_F1_LE_WIDTH                                                1
#define MSEC55MASK_F1_LE_SHIFT                                                8
#define MSEC55MASK_F1_LE_MASK                                        0x00008000
#define MSEC55MASK_F1_LE_RD(src)                   (((src) & 0x00008000) >> 15)
#define MSEC55MASK_F1_LE_WR(src)              (((unsigned int)(src) << 15) & 0x00008000)
#define MSEC55MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*Mask Register Fields MSEC54Mask	 */
#define MSEC54MASK_F1_LE_WIDTH                                                1
#define MSEC54MASK_F1_LE_SHIFT                                                9
#define MSEC54MASK_F1_LE_MASK                                        0x00004000
#define MSEC54MASK_F1_LE_RD(src)                   (((src) & 0x00004000) >> 14)
#define MSEC54MASK_F1_LE_WR(src)              (((unsigned int)(src) << 14) & 0x00004000)
#define MSEC54MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*Mask Register Fields MSEC53Mask	 */
#define MSEC53MASK_F1_LE_WIDTH                                                1
#define MSEC53MASK_F1_LE_SHIFT                                               10
#define MSEC53MASK_F1_LE_MASK                                        0x00002000
#define MSEC53MASK_F1_LE_RD(src)                   (((src) & 0x00002000) >> 13)
#define MSEC53MASK_F1_LE_WR(src)              (((unsigned int)(src) << 13) & 0x00002000)
#define MSEC53MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*Mask Register Fields MSEC52Mask	 */
#define MSEC52MASK_F1_LE_WIDTH                                                1
#define MSEC52MASK_F1_LE_SHIFT                                               11
#define MSEC52MASK_F1_LE_MASK                                        0x00001000
#define MSEC52MASK_F1_LE_RD(src)                   (((src) & 0x00001000) >> 12)
#define MSEC52MASK_F1_LE_WR(src)              (((unsigned int)(src) << 12) & 0x00001000)
#define MSEC52MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*Mask Register Fields MSEC51Mask	 */
#define MSEC51MASK_F1_LE_WIDTH                                                1
#define MSEC51MASK_F1_LE_SHIFT                                               12
#define MSEC51MASK_F1_LE_MASK                                        0x00000800
#define MSEC51MASK_F1_LE_RD(src)                   (((src) & 0x00000800) >> 11)
#define MSEC51MASK_F1_LE_WR(src)              (((unsigned int)(src) << 11) & 0x00000800)
#define MSEC51MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*Mask Register Fields MSEC50Mask	 */
#define MSEC50MASK_F1_LE_WIDTH                                                1
#define MSEC50MASK_F1_LE_SHIFT                                               13
#define MSEC50MASK_F1_LE_MASK                                        0x00000400
#define MSEC50MASK_F1_LE_RD(src)                   (((src) & 0x00000400) >> 10)
#define MSEC50MASK_F1_LE_WR(src)              (((unsigned int)(src) << 10) & 0x00000400)
#define MSEC50MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*Mask Register Fields MSEC49Mask	 */
#define MSEC49MASK_F1_LE_WIDTH                                                1
#define MSEC49MASK_F1_LE_SHIFT                                               14
#define MSEC49MASK_F1_LE_MASK                                        0x00000200
#define MSEC49MASK_F1_LE_RD(src)                    (((src) & 0x00000200) >> 9)
#define MSEC49MASK_F1_LE_WR(src)               (((unsigned int)(src) << 9) & 0x00000200)
#define MSEC49MASK_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*Mask Register Fields MSEC48Mask	 */
#define MSEC48MASK_F1_LE_WIDTH                                                1
#define MSEC48MASK_F1_LE_SHIFT                                               15
#define MSEC48MASK_F1_LE_MASK                                        0x00000100
#define MSEC48MASK_F1_LE_RD(src)                    (((src) & 0x00000100) >> 8)
#define MSEC48MASK_F1_LE_WR(src)               (((unsigned int)(src) << 8) & 0x00000100)
#define MSEC48MASK_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*Mask Register Fields MSEC47Mask	 */
#define MSEC47MASK_F1_LE_WIDTH                                                1
#define MSEC47MASK_F1_LE_SHIFT                                               16
#define MSEC47MASK_F1_LE_MASK                                        0x00800000
#define MSEC47MASK_F1_LE_RD(src)                   (((src) & 0x00800000) >> 23)
#define MSEC47MASK_F1_LE_WR(src)              (((unsigned int)(src) << 23) & 0x00800000)
#define MSEC47MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*Mask Register Fields MSEC46Mask	 */
#define MSEC46MASK_F1_LE_WIDTH                                                1
#define MSEC46MASK_F1_LE_SHIFT                                               17
#define MSEC46MASK_F1_LE_MASK                                        0x00400000
#define MSEC46MASK_F1_LE_RD(src)                   (((src) & 0x00400000) >> 22)
#define MSEC46MASK_F1_LE_WR(src)              (((unsigned int)(src) << 22) & 0x00400000)
#define MSEC46MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*Mask Register Fields MSEC45Mask	 */
#define MSEC45MASK_F1_LE_WIDTH                                                1
#define MSEC45MASK_F1_LE_SHIFT                                               18
#define MSEC45MASK_F1_LE_MASK                                        0x00200000
#define MSEC45MASK_F1_LE_RD(src)                   (((src) & 0x00200000) >> 21)
#define MSEC45MASK_F1_LE_WR(src)              (((unsigned int)(src) << 21) & 0x00200000)
#define MSEC45MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*Mask Register Fields MSEC44Mask	 */
#define MSEC44MASK_F1_LE_WIDTH                                                1
#define MSEC44MASK_F1_LE_SHIFT                                               19
#define MSEC44MASK_F1_LE_MASK                                        0x00100000
#define MSEC44MASK_F1_LE_RD(src)                   (((src) & 0x00100000) >> 20)
#define MSEC44MASK_F1_LE_WR(src)              (((unsigned int)(src) << 20) & 0x00100000)
#define MSEC44MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*Mask Register Fields MSEC43Mask	 */
#define MSEC43MASK_F1_LE_WIDTH                                                1
#define MSEC43MASK_F1_LE_SHIFT                                               20
#define MSEC43MASK_F1_LE_MASK                                        0x00080000
#define MSEC43MASK_F1_LE_RD(src)                   (((src) & 0x00080000) >> 19)
#define MSEC43MASK_F1_LE_WR(src)              (((unsigned int)(src) << 19) & 0x00080000)
#define MSEC43MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*Mask Register Fields MSEC42Mask	 */
#define MSEC42MASK_F1_LE_WIDTH                                                1
#define MSEC42MASK_F1_LE_SHIFT                                               21
#define MSEC42MASK_F1_LE_MASK                                        0x00040000
#define MSEC42MASK_F1_LE_RD(src)                   (((src) & 0x00040000) >> 18)
#define MSEC42MASK_F1_LE_WR(src)              (((unsigned int)(src) << 18) & 0x00040000)
#define MSEC42MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*Mask Register Fields MSEC41Mask	 */
#define MSEC41MASK_F1_LE_WIDTH                                                1
#define MSEC41MASK_F1_LE_SHIFT                                               22
#define MSEC41MASK_F1_LE_MASK                                        0x00020000
#define MSEC41MASK_F1_LE_RD(src)                   (((src) & 0x00020000) >> 17)
#define MSEC41MASK_F1_LE_WR(src)              (((unsigned int)(src) << 17) & 0x00020000)
#define MSEC41MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*Mask Register Fields MSEC40Mask	 */
#define MSEC40MASK_F1_LE_WIDTH                                                1
#define MSEC40MASK_F1_LE_SHIFT                                               23
#define MSEC40MASK_F1_LE_MASK                                        0x00010000
#define MSEC40MASK_F1_LE_RD(src)                   (((src) & 0x00010000) >> 16)
#define MSEC40MASK_F1_LE_WR(src)              (((unsigned int)(src) << 16) & 0x00010000)
#define MSEC40MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*Mask Register Fields MSEC39Mask	 */
#define MSEC39MASK_F1_LE_WIDTH                                                1
#define MSEC39MASK_F1_LE_SHIFT                                               24
#define MSEC39MASK_F1_LE_MASK                                        0x80000000
#define MSEC39MASK_F1_LE_RD(src)                   (((src) & 0x80000000) >> 31)
#define MSEC39MASK_F1_LE_WR(src)              (((unsigned int)(src) << 31) & 0x80000000)
#define MSEC39MASK_F1_LE_SET(dst,src)                      ((dst)&~0x80000000)|\
			(((unsigned int)(src) << 31) & 0x80000000)

/*Mask Register Fields MSEC38Mask	 */
#define MSEC38MASK_F1_LE_WIDTH                                                1
#define MSEC38MASK_F1_LE_SHIFT                                               25
#define MSEC38MASK_F1_LE_MASK                                        0x40000000
#define MSEC38MASK_F1_LE_RD(src)                   (((src) & 0x40000000) >> 30)
#define MSEC38MASK_F1_LE_WR(src)              (((unsigned int)(src) << 30) & 0x40000000)
#define MSEC38MASK_F1_LE_SET(dst,src)                      ((dst)&~0x40000000)|\
			(((unsigned int)(src) << 30) & 0x40000000)

/*Mask Register Fields MSEC37Mask	 */
#define MSEC37MASK_F1_LE_WIDTH                                                1
#define MSEC37MASK_F1_LE_SHIFT                                               26
#define MSEC37MASK_F1_LE_MASK                                        0x20000000
#define MSEC37MASK_F1_LE_RD(src)                   (((src) & 0x20000000) >> 29)
#define MSEC37MASK_F1_LE_WR(src)              (((unsigned int)(src) << 29) & 0x20000000)
#define MSEC37MASK_F1_LE_SET(dst,src)                      ((dst)&~0x20000000)|\
			(((unsigned int)(src) << 29) & 0x20000000)

/*Mask Register Fields MSEC36Mask	 */
#define MSEC36MASK_F1_LE_WIDTH                                                1
#define MSEC36MASK_F1_LE_SHIFT                                               27
#define MSEC36MASK_F1_LE_MASK                                        0x10000000
#define MSEC36MASK_F1_LE_RD(src)                   (((src) & 0x10000000) >> 28)
#define MSEC36MASK_F1_LE_WR(src)              (((unsigned int)(src) << 28) & 0x10000000)
#define MSEC36MASK_F1_LE_SET(dst,src)                      ((dst)&~0x10000000)|\
			(((unsigned int)(src) << 28) & 0x10000000)

/*Mask Register Fields MSEC35Mask	 */
#define MSEC35MASK_F1_LE_WIDTH                                                1
#define MSEC35MASK_F1_LE_SHIFT                                               28
#define MSEC35MASK_F1_LE_MASK                                        0x08000000
#define MSEC35MASK_F1_LE_RD(src)                   (((src) & 0x08000000) >> 27)
#define MSEC35MASK_F1_LE_WR(src)              (((unsigned int)(src) << 27) & 0x08000000)
#define MSEC35MASK_F1_LE_SET(dst,src)                      ((dst)&~0x08000000)|\
			(((unsigned int)(src) << 27) & 0x08000000)

/*Mask Register Fields MSEC34Mask	 */
#define MSEC34MASK_F1_LE_WIDTH                                                1
#define MSEC34MASK_F1_LE_SHIFT                                               29
#define MSEC34MASK_F1_LE_MASK                                        0x04000000
#define MSEC34MASK_F1_LE_RD(src)                   (((src) & 0x04000000) >> 26)
#define MSEC34MASK_F1_LE_WR(src)              (((unsigned int)(src) << 26) & 0x04000000)
#define MSEC34MASK_F1_LE_SET(dst,src)                      ((dst)&~0x04000000)|\
			(((unsigned int)(src) << 26) & 0x04000000)

/*Mask Register Fields MSEC33Mask	 */
#define MSEC33MASK_F1_LE_WIDTH                                                1
#define MSEC33MASK_F1_LE_SHIFT                                               30
#define MSEC33MASK_F1_LE_MASK                                        0x02000000
#define MSEC33MASK_F1_LE_RD(src)                   (((src) & 0x02000000) >> 25)
#define MSEC33MASK_F1_LE_WR(src)              (((unsigned int)(src) << 25) & 0x02000000)
#define MSEC33MASK_F1_LE_SET(dst,src)                      ((dst)&~0x02000000)|\
			(((unsigned int)(src) << 25) & 0x02000000)

/*Mask Register Fields MSEC32Mask	 */
#define MSEC32MASK_F1_LE_WIDTH                                                1
#define MSEC32MASK_F1_LE_SHIFT                                               31
#define MSEC32MASK_F1_LE_MASK                                        0x01000000
#define MSEC32MASK_F1_LE_RD(src)                   (((src) & 0x01000000) >> 24)
#define MSEC32MASK_F1_LE_WR(src)              (((unsigned int)(src) << 24) & 0x01000000)
#define MSEC32MASK_F1_LE_SET(dst,src)                      ((dst)&~0x01000000)|\
			(((unsigned int)(src) << 24) & 0x01000000)

/*	Register GLBL_DED_ERRL	*/

/*	 Fields DED31	 */
#define DED31_F1_LE_WIDTH                                                     1
#define DED31_F1_LE_SHIFT                                                     0
#define DED31_F1_LE_MASK                                             0x00000080
#define DED31_F1_LE_RD(src)                          (((src) & 0x00000080)<< 7)
#define DED31_F1_LE_WR(src)                    (((unsigned int)(src) >> 7) & 0x00000080)
#define DED31_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields DED30	 */
#define DED30_F1_LE_WIDTH                                                     1
#define DED30_F1_LE_SHIFT                                                     1
#define DED30_F1_LE_MASK                                             0x00000040
#define DED30_F1_LE_RD(src)                          (((src) & 0x00000040)<< 6)
#define DED30_F1_LE_WR(src)                    (((unsigned int)(src) >> 6) & 0x00000040)
#define DED30_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields DED29	 */
#define DED29_F1_LE_WIDTH                                                     1
#define DED29_F1_LE_SHIFT                                                     2
#define DED29_F1_LE_MASK                                             0x00000020
#define DED29_F1_LE_RD(src)                          (((src) & 0x00000020)<< 5)
#define DED29_F1_LE_WR(src)                    (((unsigned int)(src) >> 5) & 0x00000020)
#define DED29_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*	 Fields DED28	 */
#define DED28_F1_LE_WIDTH                                                     1
#define DED28_F1_LE_SHIFT                                                     3
#define DED28_F1_LE_MASK                                             0x00000010
#define DED28_F1_LE_RD(src)                          (((src) & 0x00000010)<< 4)
#define DED28_F1_LE_WR(src)                    (((unsigned int)(src) >> 4) & 0x00000010)
#define DED28_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields DED27	 */
#define DED27_F1_LE_WIDTH                                                     1
#define DED27_F1_LE_SHIFT                                                     4
#define DED27_F1_LE_MASK                                             0x00000008
#define DED27_F1_LE_RD(src)                          (((src) & 0x00000008)<< 3)
#define DED27_F1_LE_WR(src)                    (((unsigned int)(src) >> 3) & 0x00000008)
#define DED27_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*	 Fields DED26	 */
#define DED26_F1_LE_WIDTH                                                     1
#define DED26_F1_LE_SHIFT                                                     5
#define DED26_F1_LE_MASK                                             0x00000004
#define DED26_F1_LE_RD(src)                          (((src) & 0x00000004)<< 2)
#define DED26_F1_LE_WR(src)                    (((unsigned int)(src) >> 2) & 0x00000004)
#define DED26_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*	 Fields DED25	 */
#define DED25_F1_LE_WIDTH                                                     1
#define DED25_F1_LE_SHIFT                                                     6
#define DED25_F1_LE_MASK                                             0x00000002
#define DED25_F1_LE_RD(src)                          (((src) & 0x00000002)<< 1)
#define DED25_F1_LE_WR(src)                    (((unsigned int)(src) >> 1) & 0x00000002)
#define DED25_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*	 Fields DED24	 */
#define DED24_F1_LE_WIDTH                                                     1
#define DED24_F1_LE_SHIFT                                                     7
#define DED24_F1_LE_MASK                                             0x00000001
#define DED24_F1_LE_RD(src)                          (((src) & 0x00000001)<< 0)
#define DED24_F1_LE_WR(src)                    (((unsigned int)(src) >> 0) & 0x00000001)
#define DED24_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*	 Fields DED23	 */
#define DED23_F1_LE_WIDTH                                                     1
#define DED23_F1_LE_SHIFT                                                     8
#define DED23_F1_LE_MASK                                             0x00008000
#define DED23_F1_LE_RD(src)                        (((src) & 0x00008000) >> 15)
#define DED23_F1_LE_WR(src)                   (((unsigned int)(src) << 15) & 0x00008000)
#define DED23_F1_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*	 Fields DED22	 */
#define DED22_F1_LE_WIDTH                                                     1
#define DED22_F1_LE_SHIFT                                                     9
#define DED22_F1_LE_MASK                                             0x00004000
#define DED22_F1_LE_RD(src)                        (((src) & 0x00004000) >> 14)
#define DED22_F1_LE_WR(src)                   (((unsigned int)(src) << 14) & 0x00004000)
#define DED22_F1_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*	 Fields DED21	 */
#define DED21_F1_LE_WIDTH                                                     1
#define DED21_F1_LE_SHIFT                                                    10
#define DED21_F1_LE_MASK                                             0x00002000
#define DED21_F1_LE_RD(src)                        (((src) & 0x00002000) >> 13)
#define DED21_F1_LE_WR(src)                   (((unsigned int)(src) << 13) & 0x00002000)
#define DED21_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*	 Fields DED20	 */
#define DED20_F1_LE_WIDTH                                                     1
#define DED20_F1_LE_SHIFT                                                    11
#define DED20_F1_LE_MASK                                             0x00001000
#define DED20_F1_LE_RD(src)                        (((src) & 0x00001000) >> 12)
#define DED20_F1_LE_WR(src)                   (((unsigned int)(src) << 12) & 0x00001000)
#define DED20_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*	 Fields DED19	 */
#define DED19_F1_LE_WIDTH                                                     1
#define DED19_F1_LE_SHIFT                                                    12
#define DED19_F1_LE_MASK                                             0x00000800
#define DED19_F1_LE_RD(src)                        (((src) & 0x00000800) >> 11)
#define DED19_F1_LE_WR(src)                   (((unsigned int)(src) << 11) & 0x00000800)
#define DED19_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*	 Fields DED18	 */
#define DED18_F1_LE_WIDTH                                                     1
#define DED18_F1_LE_SHIFT                                                    13
#define DED18_F1_LE_MASK                                             0x00000400
#define DED18_F1_LE_RD(src)                        (((src) & 0x00000400) >> 10)
#define DED18_F1_LE_WR(src)                   (((unsigned int)(src) << 10) & 0x00000400)
#define DED18_F1_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*	 Fields DED17	 */
#define DED17_F1_LE_WIDTH                                                     1
#define DED17_F1_LE_SHIFT                                                    14
#define DED17_F1_LE_MASK                                             0x00000200
#define DED17_F1_LE_RD(src)                         (((src) & 0x00000200) >> 9)
#define DED17_F1_LE_WR(src)                    (((unsigned int)(src) << 9) & 0x00000200)
#define DED17_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*	 Fields DED16	 */
#define DED16_F1_LE_WIDTH                                                     1
#define DED16_F1_LE_SHIFT                                                    15
#define DED16_F1_LE_MASK                                             0x00000100
#define DED16_F1_LE_RD(src)                         (((src) & 0x00000100) >> 8)
#define DED16_F1_LE_WR(src)                    (((unsigned int)(src) << 8) & 0x00000100)
#define DED16_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*	 Fields DED15	 */
#define DED15_F1_LE_WIDTH                                                     1
#define DED15_F1_LE_SHIFT                                                    16
#define DED15_F1_LE_MASK                                             0x00800000
#define DED15_F1_LE_RD(src)                        (((src) & 0x00800000) >> 23)
#define DED15_F1_LE_WR(src)                   (((unsigned int)(src) << 23) & 0x00800000)
#define DED15_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*	 Fields DED14	 */
#define DED14_F1_LE_WIDTH                                                     1
#define DED14_F1_LE_SHIFT                                                    17
#define DED14_F1_LE_MASK                                             0x00400000
#define DED14_F1_LE_RD(src)                        (((src) & 0x00400000) >> 22)
#define DED14_F1_LE_WR(src)                   (((unsigned int)(src) << 22) & 0x00400000)
#define DED14_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*	 Fields DED13	 */
#define DED13_F1_LE_WIDTH                                                     1
#define DED13_F1_LE_SHIFT                                                    18
#define DED13_F1_LE_MASK                                             0x00200000
#define DED13_F1_LE_RD(src)                        (((src) & 0x00200000) >> 21)
#define DED13_F1_LE_WR(src)                   (((unsigned int)(src) << 21) & 0x00200000)
#define DED13_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*	 Fields DED12	 */
#define DED12_F1_LE_WIDTH                                                     1
#define DED12_F1_LE_SHIFT                                                    19
#define DED12_F1_LE_MASK                                             0x00100000
#define DED12_F1_LE_RD(src)                        (((src) & 0x00100000) >> 20)
#define DED12_F1_LE_WR(src)                   (((unsigned int)(src) << 20) & 0x00100000)
#define DED12_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields DED11	 */
#define DED11_F1_LE_WIDTH                                                     1
#define DED11_F1_LE_SHIFT                                                    20
#define DED11_F1_LE_MASK                                             0x00080000
#define DED11_F1_LE_RD(src)                        (((src) & 0x00080000) >> 19)
#define DED11_F1_LE_WR(src)                   (((unsigned int)(src) << 19) & 0x00080000)
#define DED11_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*	 Fields DED10	 */
#define DED10_F1_LE_WIDTH                                                     1
#define DED10_F1_LE_SHIFT                                                    21
#define DED10_F1_LE_MASK                                             0x00040000
#define DED10_F1_LE_RD(src)                        (((src) & 0x00040000) >> 18)
#define DED10_F1_LE_WR(src)                   (((unsigned int)(src) << 18) & 0x00040000)
#define DED10_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*	 Fields DED9	 */
#define DED9_F1_LE_WIDTH                                                      1
#define DED9_F1_LE_SHIFT                                                     22
#define DED9_F1_LE_MASK                                              0x00020000
#define DED9_F1_LE_RD(src)                         (((src) & 0x00020000) >> 17)
#define DED9_F1_LE_WR(src)                    (((unsigned int)(src) << 17) & 0x00020000)
#define DED9_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*	 Fields DED8	 */
#define DED8_F1_LE_WIDTH                                                      1
#define DED8_F1_LE_SHIFT                                                     23
#define DED8_F1_LE_MASK                                              0x00010000
#define DED8_F1_LE_RD(src)                         (((src) & 0x00010000) >> 16)
#define DED8_F1_LE_WR(src)                    (((unsigned int)(src) << 16) & 0x00010000)
#define DED8_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*	 Fields DED7	 */
#define DED7_F1_LE_WIDTH                                                      1
#define DED7_F1_LE_SHIFT                                                     24
#define DED7_F1_LE_MASK                                              0x80000000
#define DED7_F1_LE_RD(src)                         (((src) & 0x80000000) >> 31)
#define DED7_F1_LE_WR(src)                    (((unsigned int)(src) << 31) & 0x80000000)
#define DED7_F1_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields DED6	 */
#define DED6_F1_LE_WIDTH                                                      1
#define DED6_F1_LE_SHIFT                                                     25
#define DED6_F1_LE_MASK                                              0x40000000
#define DED6_F1_LE_RD(src)                         (((src) & 0x40000000) >> 30)
#define DED6_F1_LE_WR(src)                    (((unsigned int)(src) << 30) & 0x40000000)
#define DED6_F1_LE_SET(dst,src)                     ((dst)&~0x40000000)|\
				(((unsigned int)(src) << 30) & 0x40000000)

/*	 Fields DED5	 */
#define DED5_F1_LE_WIDTH                                                      1
#define DED5_F1_LE_SHIFT                                                     26
#define DED5_F1_LE_MASK                                              0x20000000
#define DED5_F1_LE_RD(src)                         (((src) & 0x20000000) >> 29)
#define DED5_F1_LE_WR(src)                    (((unsigned int)(src) << 29) & 0x20000000)
#define DED5_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields DED4	 */
#define DED4_F1_LE_WIDTH                                                      1
#define DED4_F1_LE_SHIFT                                                     27
#define DED4_F1_LE_MASK                                              0x10000000
#define DED4_F1_LE_RD(src)                         (((src) & 0x10000000) >> 28)
#define DED4_F1_LE_WR(src)                    (((unsigned int)(src) << 28) & 0x10000000)
#define DED4_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields DED3	 */
#define DED3_F1_LE_WIDTH                                                      1
#define DED3_F1_LE_SHIFT                                                     28
#define DED3_F1_LE_MASK                                              0x08000000
#define DED3_F1_LE_RD(src)                         (((src) & 0x08000000) >> 27)
#define DED3_F1_LE_WR(src)                    (((unsigned int)(src) << 27) & 0x08000000)
#define DED3_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields DED2	 */
#define DED2_F1_LE_WIDTH                                                      1
#define DED2_F1_LE_SHIFT                                                     29
#define DED2_F1_LE_MASK                                              0x04000000
#define DED2_F1_LE_RD(src)                         (((src) & 0x04000000) >> 26)
#define DED2_F1_LE_WR(src)                    (((unsigned int)(src) << 26) & 0x04000000)
#define DED2_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields DED1	 */
#define DED1_F1_LE_WIDTH                                                      1
#define DED1_F1_LE_SHIFT                                                     30
#define DED1_F1_LE_MASK                                              0x02000000
#define DED1_F1_LE_RD(src)                         (((src) & 0x02000000) >> 25)
#define DED1_F1_LE_WR(src)                    (((unsigned int)(src) << 25) & 0x02000000)
#define DED1_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields DED0	 */
#define DED0_F1_LE_WIDTH                                                      1
#define DED0_F1_LE_SHIFT                                                     31
#define DED0_F1_LE_MASK                                              0x01000000
#define DED0_F1_LE_RD(src)                         (((src) & 0x01000000) >> 24)
#define DED0_F1_LE_WR(src)                    (((unsigned int)(src) << 24) & 0x01000000)
#define DED0_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register GLBL_DED_ERRLMask	*/

/*Mask Register Fields DED31Mask	 */
#define DED31MASK_F1_LE_WIDTH                                                 1
#define DED31MASK_F1_LE_SHIFT                                                 0
#define DED31MASK_F1_LE_MASK                                         0x00000080
#define DED31MASK_F1_LE_RD(src)                      (((src) & 0x00000080)<< 7)
#define DED31MASK_F1_LE_WR(src)                (((unsigned int)(src) >> 7) & 0x00000080)
#define DED31MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*Mask Register Fields DED30Mask	 */
#define DED30MASK_F1_LE_WIDTH                                                 1
#define DED30MASK_F1_LE_SHIFT                                                 1
#define DED30MASK_F1_LE_MASK                                         0x00000040
#define DED30MASK_F1_LE_RD(src)                      (((src) & 0x00000040)<< 6)
#define DED30MASK_F1_LE_WR(src)                (((unsigned int)(src) >> 6) & 0x00000040)
#define DED30MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*Mask Register Fields DED29Mask	 */
#define DED29MASK_F1_LE_WIDTH                                                 1
#define DED29MASK_F1_LE_SHIFT                                                 2
#define DED29MASK_F1_LE_MASK                                         0x00000020
#define DED29MASK_F1_LE_RD(src)                      (((src) & 0x00000020)<< 5)
#define DED29MASK_F1_LE_WR(src)                (((unsigned int)(src) >> 5) & 0x00000020)
#define DED29MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*Mask Register Fields DED28Mask	 */
#define DED28MASK_F1_LE_WIDTH                                                 1
#define DED28MASK_F1_LE_SHIFT                                                 3
#define DED28MASK_F1_LE_MASK                                         0x00000010
#define DED28MASK_F1_LE_RD(src)                      (((src) & 0x00000010)<< 4)
#define DED28MASK_F1_LE_WR(src)                (((unsigned int)(src) >> 4) & 0x00000010)
#define DED28MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*Mask Register Fields DED27Mask	 */
#define DED27MASK_F1_LE_WIDTH                                                 1
#define DED27MASK_F1_LE_SHIFT                                                 4
#define DED27MASK_F1_LE_MASK                                         0x00000008
#define DED27MASK_F1_LE_RD(src)                      (((src) & 0x00000008)<< 3)
#define DED27MASK_F1_LE_WR(src)                (((unsigned int)(src) >> 3) & 0x00000008)
#define DED27MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*Mask Register Fields DED26Mask	 */
#define DED26MASK_F1_LE_WIDTH                                                 1
#define DED26MASK_F1_LE_SHIFT                                                 5
#define DED26MASK_F1_LE_MASK                                         0x00000004
#define DED26MASK_F1_LE_RD(src)                      (((src) & 0x00000004)<< 2)
#define DED26MASK_F1_LE_WR(src)                (((unsigned int)(src) >> 2) & 0x00000004)
#define DED26MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*Mask Register Fields DED25Mask	 */
#define DED25MASK_F1_LE_WIDTH                                                 1
#define DED25MASK_F1_LE_SHIFT                                                 6
#define DED25MASK_F1_LE_MASK                                         0x00000002
#define DED25MASK_F1_LE_RD(src)                      (((src) & 0x00000002)<< 1)
#define DED25MASK_F1_LE_WR(src)                (((unsigned int)(src) >> 1) & 0x00000002)
#define DED25MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*Mask Register Fields DED24Mask	 */
#define DED24MASK_F1_LE_WIDTH                                                 1
#define DED24MASK_F1_LE_SHIFT                                                 7
#define DED24MASK_F1_LE_MASK                                         0x00000001
#define DED24MASK_F1_LE_RD(src)                      (((src) & 0x00000001)<< 0)
#define DED24MASK_F1_LE_WR(src)                (((unsigned int)(src) >> 0) & 0x00000001)
#define DED24MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*Mask Register Fields DED23Mask	 */
#define DED23MASK_F1_LE_WIDTH                                                 1
#define DED23MASK_F1_LE_SHIFT                                                 8
#define DED23MASK_F1_LE_MASK                                         0x00008000
#define DED23MASK_F1_LE_RD(src)                    (((src) & 0x00008000) >> 15)
#define DED23MASK_F1_LE_WR(src)               (((unsigned int)(src) << 15) & 0x00008000)
#define DED23MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*Mask Register Fields DED22Mask	 */
#define DED22MASK_F1_LE_WIDTH                                                 1
#define DED22MASK_F1_LE_SHIFT                                                 9
#define DED22MASK_F1_LE_MASK                                         0x00004000
#define DED22MASK_F1_LE_RD(src)                    (((src) & 0x00004000) >> 14)
#define DED22MASK_F1_LE_WR(src)               (((unsigned int)(src) << 14) & 0x00004000)
#define DED22MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*Mask Register Fields DED21Mask	 */
#define DED21MASK_F1_LE_WIDTH                                                 1
#define DED21MASK_F1_LE_SHIFT                                                10
#define DED21MASK_F1_LE_MASK                                         0x00002000
#define DED21MASK_F1_LE_RD(src)                    (((src) & 0x00002000) >> 13)
#define DED21MASK_F1_LE_WR(src)               (((unsigned int)(src) << 13) & 0x00002000)
#define DED21MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*Mask Register Fields DED20Mask	 */
#define DED20MASK_F1_LE_WIDTH                                                 1
#define DED20MASK_F1_LE_SHIFT                                                11
#define DED20MASK_F1_LE_MASK                                         0x00001000
#define DED20MASK_F1_LE_RD(src)                    (((src) & 0x00001000) >> 12)
#define DED20MASK_F1_LE_WR(src)               (((unsigned int)(src) << 12) & 0x00001000)
#define DED20MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*Mask Register Fields DED19Mask	 */
#define DED19MASK_F1_LE_WIDTH                                                 1
#define DED19MASK_F1_LE_SHIFT                                                12
#define DED19MASK_F1_LE_MASK                                         0x00000800
#define DED19MASK_F1_LE_RD(src)                    (((src) & 0x00000800) >> 11)
#define DED19MASK_F1_LE_WR(src)               (((unsigned int)(src) << 11) & 0x00000800)
#define DED19MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*Mask Register Fields DED18Mask	 */
#define DED18MASK_F1_LE_WIDTH                                                 1
#define DED18MASK_F1_LE_SHIFT                                                13
#define DED18MASK_F1_LE_MASK                                         0x00000400
#define DED18MASK_F1_LE_RD(src)                    (((src) & 0x00000400) >> 10)
#define DED18MASK_F1_LE_WR(src)               (((unsigned int)(src) << 10) & 0x00000400)
#define DED18MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*Mask Register Fields DED17Mask	 */
#define DED17MASK_F1_LE_WIDTH                                                 1
#define DED17MASK_F1_LE_SHIFT                                                14
#define DED17MASK_F1_LE_MASK                                         0x00000200
#define DED17MASK_F1_LE_RD(src)                     (((src) & 0x00000200) >> 9)
#define DED17MASK_F1_LE_WR(src)                (((unsigned int)(src) << 9) & 0x00000200)
#define DED17MASK_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*Mask Register Fields DED16Mask	 */
#define DED16MASK_F1_LE_WIDTH                                                 1
#define DED16MASK_F1_LE_SHIFT                                                15
#define DED16MASK_F1_LE_MASK                                         0x00000100
#define DED16MASK_F1_LE_RD(src)                     (((src) & 0x00000100) >> 8)
#define DED16MASK_F1_LE_WR(src)                (((unsigned int)(src) << 8) & 0x00000100)
#define DED16MASK_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*Mask Register Fields DED15Mask	 */
#define DED15MASK_F1_LE_WIDTH                                                 1
#define DED15MASK_F1_LE_SHIFT                                                16
#define DED15MASK_F1_LE_MASK                                         0x00800000
#define DED15MASK_F1_LE_RD(src)                    (((src) & 0x00800000) >> 23)
#define DED15MASK_F1_LE_WR(src)               (((unsigned int)(src) << 23) & 0x00800000)
#define DED15MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*Mask Register Fields DED14Mask	 */
#define DED14MASK_F1_LE_WIDTH                                                 1
#define DED14MASK_F1_LE_SHIFT                                                17
#define DED14MASK_F1_LE_MASK                                         0x00400000
#define DED14MASK_F1_LE_RD(src)                    (((src) & 0x00400000) >> 22)
#define DED14MASK_F1_LE_WR(src)               (((unsigned int)(src) << 22) & 0x00400000)
#define DED14MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*Mask Register Fields DED13Mask	 */
#define DED13MASK_F1_LE_WIDTH                                                 1
#define DED13MASK_F1_LE_SHIFT                                                18
#define DED13MASK_F1_LE_MASK                                         0x00200000
#define DED13MASK_F1_LE_RD(src)                    (((src) & 0x00200000) >> 21)
#define DED13MASK_F1_LE_WR(src)               (((unsigned int)(src) << 21) & 0x00200000)
#define DED13MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*Mask Register Fields DED12Mask	 */
#define DED12MASK_F1_LE_WIDTH                                                 1
#define DED12MASK_F1_LE_SHIFT                                                19
#define DED12MASK_F1_LE_MASK                                         0x00100000
#define DED12MASK_F1_LE_RD(src)                    (((src) & 0x00100000) >> 20)
#define DED12MASK_F1_LE_WR(src)               (((unsigned int)(src) << 20) & 0x00100000)
#define DED12MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*Mask Register Fields DED11Mask	 */
#define DED11MASK_F1_LE_WIDTH                                                 1
#define DED11MASK_F1_LE_SHIFT                                                20
#define DED11MASK_F1_LE_MASK                                         0x00080000
#define DED11MASK_F1_LE_RD(src)                    (((src) & 0x00080000) >> 19)
#define DED11MASK_F1_LE_WR(src)               (((unsigned int)(src) << 19) & 0x00080000)
#define DED11MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*Mask Register Fields DED10Mask	 */
#define DED10MASK_F1_LE_WIDTH                                                 1
#define DED10MASK_F1_LE_SHIFT                                                21
#define DED10MASK_F1_LE_MASK                                         0x00040000
#define DED10MASK_F1_LE_RD(src)                    (((src) & 0x00040000) >> 18)
#define DED10MASK_F1_LE_WR(src)               (((unsigned int)(src) << 18) & 0x00040000)
#define DED10MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*Mask Register Fields DED9Mask	 */
#define DED9MASK_F1_LE_WIDTH                                                  1
#define DED9MASK_F1_LE_SHIFT                                                 22
#define DED9MASK_F1_LE_MASK                                          0x00020000
#define DED9MASK_F1_LE_RD(src)                     (((src) & 0x00020000) >> 17)
#define DED9MASK_F1_LE_WR(src)                (((unsigned int)(src) << 17) & 0x00020000)
#define DED9MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*Mask Register Fields DED8Mask	 */
#define DED8MASK_F1_LE_WIDTH                                                  1
#define DED8MASK_F1_LE_SHIFT                                                 23
#define DED8MASK_F1_LE_MASK                                          0x00010000
#define DED8MASK_F1_LE_RD(src)                     (((src) & 0x00010000) >> 16)
#define DED8MASK_F1_LE_WR(src)                (((unsigned int)(src) << 16) & 0x00010000)
#define DED8MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*Mask Register Fields DED7Mask	 */
#define DED7MASK_F1_LE_WIDTH                                                  1
#define DED7MASK_F1_LE_SHIFT                                                 24
#define DED7MASK_F1_LE_MASK                                          0x80000000
#define DED7MASK_F1_LE_RD(src)                     (((src) & 0x80000000) >> 31)
#define DED7MASK_F1_LE_WR(src)                (((unsigned int)(src) << 31) & 0x80000000)
#define DED7MASK_F1_LE_SET(dst,src)                      ((dst)&~0x80000000)|\
			(((unsigned int)(src) << 31) & 0x80000000)

/*Mask Register Fields DED6Mask	 */
#define DED6MASK_F1_LE_WIDTH                                                  1
#define DED6MASK_F1_LE_SHIFT                                                 25
#define DED6MASK_F1_LE_MASK                                          0x40000000
#define DED6MASK_F1_LE_RD(src)                     (((src) & 0x40000000) >> 30)
#define DED6MASK_F1_LE_WR(src)                (((unsigned int)(src) << 30) & 0x40000000)
#define DED6MASK_F1_LE_SET(dst,src)                      ((dst)&~0x40000000)|\
			(((unsigned int)(src) << 30) & 0x40000000)

/*Mask Register Fields DED5Mask	 */
#define DED5MASK_F1_LE_WIDTH                                                  1
#define DED5MASK_F1_LE_SHIFT                                                 26
#define DED5MASK_F1_LE_MASK                                          0x20000000
#define DED5MASK_F1_LE_RD(src)                     (((src) & 0x20000000) >> 29)
#define DED5MASK_F1_LE_WR(src)                (((unsigned int)(src) << 29) & 0x20000000)
#define DED5MASK_F1_LE_SET(dst,src)                      ((dst)&~0x20000000)|\
			(((unsigned int)(src) << 29) & 0x20000000)

/*Mask Register Fields DED4Mask	 */
#define DED4MASK_F1_LE_WIDTH                                                  1
#define DED4MASK_F1_LE_SHIFT                                                 27
#define DED4MASK_F1_LE_MASK                                          0x10000000
#define DED4MASK_F1_LE_RD(src)                     (((src) & 0x10000000) >> 28)
#define DED4MASK_F1_LE_WR(src)                (((unsigned int)(src) << 28) & 0x10000000)
#define DED4MASK_F1_LE_SET(dst,src)                      ((dst)&~0x10000000)|\
			(((unsigned int)(src) << 28) & 0x10000000)

/*Mask Register Fields DED3Mask	 */
#define DED3MASK_F1_LE_WIDTH                                                  1
#define DED3MASK_F1_LE_SHIFT                                                 28
#define DED3MASK_F1_LE_MASK                                          0x08000000
#define DED3MASK_F1_LE_RD(src)                     (((src) & 0x08000000) >> 27)
#define DED3MASK_F1_LE_WR(src)                (((unsigned int)(src) << 27) & 0x08000000)
#define DED3MASK_F1_LE_SET(dst,src)                      ((dst)&~0x08000000)|\
			(((unsigned int)(src) << 27) & 0x08000000)

/*Mask Register Fields DED2Mask	 */
#define DED2MASK_F1_LE_WIDTH                                                  1
#define DED2MASK_F1_LE_SHIFT                                                 29
#define DED2MASK_F1_LE_MASK                                          0x04000000
#define DED2MASK_F1_LE_RD(src)                     (((src) & 0x04000000) >> 26)
#define DED2MASK_F1_LE_WR(src)                (((unsigned int)(src) << 26) & 0x04000000)
#define DED2MASK_F1_LE_SET(dst,src)                      ((dst)&~0x04000000)|\
			(((unsigned int)(src) << 26) & 0x04000000)

/*Mask Register Fields DED1Mask	 */
#define DED1MASK_F1_LE_WIDTH                                                  1
#define DED1MASK_F1_LE_SHIFT                                                 30
#define DED1MASK_F1_LE_MASK                                          0x02000000
#define DED1MASK_F1_LE_RD(src)                     (((src) & 0x02000000) >> 25)
#define DED1MASK_F1_LE_WR(src)                (((unsigned int)(src) << 25) & 0x02000000)
#define DED1MASK_F1_LE_SET(dst,src)                      ((dst)&~0x02000000)|\
			(((unsigned int)(src) << 25) & 0x02000000)

/*Mask Register Fields DED0Mask	 */
#define DED0MASK_F1_LE_WIDTH                                                  1
#define DED0MASK_F1_LE_SHIFT                                                 31
#define DED0MASK_F1_LE_MASK                                          0x01000000
#define DED0MASK_F1_LE_RD(src)                     (((src) & 0x01000000) >> 24)
#define DED0MASK_F1_LE_WR(src)                (((unsigned int)(src) << 24) & 0x01000000)
#define DED0MASK_F1_LE_SET(dst,src)                      ((dst)&~0x01000000)|\
			(((unsigned int)(src) << 24) & 0x01000000)

/*	Register GLBL_DED_ERRH	*/

/*	 Fields DED63	 */
#define DED63_F1_LE_WIDTH                                                     1
#define DED63_F1_LE_SHIFT                                                     0
#define DED63_F1_LE_MASK                                             0x00000080
#define DED63_F1_LE_RD(src)                          (((src) & 0x00000080)<< 7)
#define DED63_F1_LE_WR(src)                    (((unsigned int)(src) >> 7) & 0x00000080)
#define DED63_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields DED62	 */
#define DED62_F1_LE_WIDTH                                                     1
#define DED62_F1_LE_SHIFT                                                     1
#define DED62_F1_LE_MASK                                             0x00000040
#define DED62_F1_LE_RD(src)                          (((src) & 0x00000040)<< 6)
#define DED62_F1_LE_WR(src)                    (((unsigned int)(src) >> 6) & 0x00000040)
#define DED62_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields DED61	 */
#define DED61_F1_LE_WIDTH                                                     1
#define DED61_F1_LE_SHIFT                                                     2
#define DED61_F1_LE_MASK                                             0x00000020
#define DED61_F1_LE_RD(src)                          (((src) & 0x00000020)<< 5)
#define DED61_F1_LE_WR(src)                    (((unsigned int)(src) >> 5) & 0x00000020)
#define DED61_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*	 Fields DED60	 */
#define DED60_F1_LE_WIDTH                                                     1
#define DED60_F1_LE_SHIFT                                                     3
#define DED60_F1_LE_MASK                                             0x00000010
#define DED60_F1_LE_RD(src)                          (((src) & 0x00000010)<< 4)
#define DED60_F1_LE_WR(src)                    (((unsigned int)(src) >> 4) & 0x00000010)
#define DED60_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields DED59	 */
#define DED59_F1_LE_WIDTH                                                     1
#define DED59_F1_LE_SHIFT                                                     4
#define DED59_F1_LE_MASK                                             0x00000008
#define DED59_F1_LE_RD(src)                          (((src) & 0x00000008)<< 3)
#define DED59_F1_LE_WR(src)                    (((unsigned int)(src) >> 3) & 0x00000008)
#define DED59_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*	 Fields DED58	 */
#define DED58_F1_LE_WIDTH                                                     1
#define DED58_F1_LE_SHIFT                                                     5
#define DED58_F1_LE_MASK                                             0x00000004
#define DED58_F1_LE_RD(src)                          (((src) & 0x00000004)<< 2)
#define DED58_F1_LE_WR(src)                    (((unsigned int)(src) >> 2) & 0x00000004)
#define DED58_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*	 Fields DED57	 */
#define DED57_F1_LE_WIDTH                                                     1
#define DED57_F1_LE_SHIFT                                                     6
#define DED57_F1_LE_MASK                                             0x00000002
#define DED57_F1_LE_RD(src)                          (((src) & 0x00000002)<< 1)
#define DED57_F1_LE_WR(src)                    (((unsigned int)(src) >> 1) & 0x00000002)
#define DED57_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*	 Fields DED56	 */
#define DED56_F1_LE_WIDTH                                                     1
#define DED56_F1_LE_SHIFT                                                     7
#define DED56_F1_LE_MASK                                             0x00000001
#define DED56_F1_LE_RD(src)                          (((src) & 0x00000001)<< 0)
#define DED56_F1_LE_WR(src)                    (((unsigned int)(src) >> 0) & 0x00000001)
#define DED56_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*	 Fields DED55	 */
#define DED55_F1_LE_WIDTH                                                     1
#define DED55_F1_LE_SHIFT                                                     8
#define DED55_F1_LE_MASK                                             0x00008000
#define DED55_F1_LE_RD(src)                        (((src) & 0x00008000) >> 15)
#define DED55_F1_LE_WR(src)                   (((unsigned int)(src) << 15) & 0x00008000)
#define DED55_F1_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*	 Fields DED54	 */
#define DED54_F1_LE_WIDTH                                                     1
#define DED54_F1_LE_SHIFT                                                     9
#define DED54_F1_LE_MASK                                             0x00004000
#define DED54_F1_LE_RD(src)                        (((src) & 0x00004000) >> 14)
#define DED54_F1_LE_WR(src)                   (((unsigned int)(src) << 14) & 0x00004000)
#define DED54_F1_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*	 Fields DED53	 */
#define DED53_F1_LE_WIDTH                                                     1
#define DED53_F1_LE_SHIFT                                                    10
#define DED53_F1_LE_MASK                                             0x00002000
#define DED53_F1_LE_RD(src)                        (((src) & 0x00002000) >> 13)
#define DED53_F1_LE_WR(src)                   (((unsigned int)(src) << 13) & 0x00002000)
#define DED53_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*	 Fields DED52	 */
#define DED52_F1_LE_WIDTH                                                     1
#define DED52_F1_LE_SHIFT                                                    11
#define DED52_F1_LE_MASK                                             0x00001000
#define DED52_F1_LE_RD(src)                        (((src) & 0x00001000) >> 12)
#define DED52_F1_LE_WR(src)                   (((unsigned int)(src) << 12) & 0x00001000)
#define DED52_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*	 Fields DED51	 */
#define DED51_F1_LE_WIDTH                                                     1
#define DED51_F1_LE_SHIFT                                                    12
#define DED51_F1_LE_MASK                                             0x00000800
#define DED51_F1_LE_RD(src)                        (((src) & 0x00000800) >> 11)
#define DED51_F1_LE_WR(src)                   (((unsigned int)(src) << 11) & 0x00000800)
#define DED51_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*	 Fields DED50	 */
#define DED50_F1_LE_WIDTH                                                     1
#define DED50_F1_LE_SHIFT                                                    13
#define DED50_F1_LE_MASK                                             0x00000400
#define DED50_F1_LE_RD(src)                        (((src) & 0x00000400) >> 10)
#define DED50_F1_LE_WR(src)                   (((unsigned int)(src) << 10) & 0x00000400)
#define DED50_F1_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*	 Fields DED49	 */
#define DED49_F1_LE_WIDTH                                                     1
#define DED49_F1_LE_SHIFT                                                    14
#define DED49_F1_LE_MASK                                             0x00000200
#define DED49_F1_LE_RD(src)                         (((src) & 0x00000200) >> 9)
#define DED49_F1_LE_WR(src)                    (((unsigned int)(src) << 9) & 0x00000200)
#define DED49_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*	 Fields DED48	 */
#define DED48_F1_LE_WIDTH                                                     1
#define DED48_F1_LE_SHIFT                                                    15
#define DED48_F1_LE_MASK                                             0x00000100
#define DED48_F1_LE_RD(src)                         (((src) & 0x00000100) >> 8)
#define DED48_F1_LE_WR(src)                    (((unsigned int)(src) << 8) & 0x00000100)
#define DED48_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*	 Fields DED47	 */
#define DED47_F1_LE_WIDTH                                                     1
#define DED47_F1_LE_SHIFT                                                    16
#define DED47_F1_LE_MASK                                             0x00800000
#define DED47_F1_LE_RD(src)                        (((src) & 0x00800000) >> 23)
#define DED47_F1_LE_WR(src)                   (((unsigned int)(src) << 23) & 0x00800000)
#define DED47_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*	 Fields DED46	 */
#define DED46_F1_LE_WIDTH                                                     1
#define DED46_F1_LE_SHIFT                                                    17
#define DED46_F1_LE_MASK                                             0x00400000
#define DED46_F1_LE_RD(src)                        (((src) & 0x00400000) >> 22)
#define DED46_F1_LE_WR(src)                   (((unsigned int)(src) << 22) & 0x00400000)
#define DED46_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*	 Fields DED45	 */
#define DED45_F1_LE_WIDTH                                                     1
#define DED45_F1_LE_SHIFT                                                    18
#define DED45_F1_LE_MASK                                             0x00200000
#define DED45_F1_LE_RD(src)                        (((src) & 0x00200000) >> 21)
#define DED45_F1_LE_WR(src)                   (((unsigned int)(src) << 21) & 0x00200000)
#define DED45_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*	 Fields DED44	 */
#define DED44_F1_LE_WIDTH                                                     1
#define DED44_F1_LE_SHIFT                                                    19
#define DED44_F1_LE_MASK                                             0x00100000
#define DED44_F1_LE_RD(src)                        (((src) & 0x00100000) >> 20)
#define DED44_F1_LE_WR(src)                   (((unsigned int)(src) << 20) & 0x00100000)
#define DED44_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields DED43	 */
#define DED43_F1_LE_WIDTH                                                     1
#define DED43_F1_LE_SHIFT                                                    20
#define DED43_F1_LE_MASK                                             0x00080000
#define DED43_F1_LE_RD(src)                        (((src) & 0x00080000) >> 19)
#define DED43_F1_LE_WR(src)                   (((unsigned int)(src) << 19) & 0x00080000)
#define DED43_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*	 Fields DED42	 */
#define DED42_F1_LE_WIDTH                                                     1
#define DED42_F1_LE_SHIFT                                                    21
#define DED42_F1_LE_MASK                                             0x00040000
#define DED42_F1_LE_RD(src)                        (((src) & 0x00040000) >> 18)
#define DED42_F1_LE_WR(src)                   (((unsigned int)(src) << 18) & 0x00040000)
#define DED42_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*	 Fields DED41	 */
#define DED41_F1_LE_WIDTH                                                     1
#define DED41_F1_LE_SHIFT                                                    22
#define DED41_F1_LE_MASK                                             0x00020000
#define DED41_F1_LE_RD(src)                        (((src) & 0x00020000) >> 17)
#define DED41_F1_LE_WR(src)                   (((unsigned int)(src) << 17) & 0x00020000)
#define DED41_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*	 Fields DED40	 */
#define DED40_F1_LE_WIDTH                                                     1
#define DED40_F1_LE_SHIFT                                                    23
#define DED40_F1_LE_MASK                                             0x00010000
#define DED40_F1_LE_RD(src)                        (((src) & 0x00010000) >> 16)
#define DED40_F1_LE_WR(src)                   (((unsigned int)(src) << 16) & 0x00010000)
#define DED40_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*	 Fields DED39	 */
#define DED39_F1_LE_WIDTH                                                     1
#define DED39_F1_LE_SHIFT                                                    24
#define DED39_F1_LE_MASK                                             0x80000000
#define DED39_F1_LE_RD(src)                        (((src) & 0x80000000) >> 31)
#define DED39_F1_LE_WR(src)                   (((unsigned int)(src) << 31) & 0x80000000)
#define DED39_F1_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields DED38	 */
#define DED38_F1_LE_WIDTH                                                     1
#define DED38_F1_LE_SHIFT                                                    25
#define DED38_F1_LE_MASK                                             0x40000000
#define DED38_F1_LE_RD(src)                        (((src) & 0x40000000) >> 30)
#define DED38_F1_LE_WR(src)                   (((unsigned int)(src) << 30) & 0x40000000)
#define DED38_F1_LE_SET(dst,src)                     ((dst)&~0x40000000)|\
				(((unsigned int)(src) << 30) & 0x40000000)

/*	 Fields DED37	 */
#define DED37_F1_LE_WIDTH                                                     1
#define DED37_F1_LE_SHIFT                                                    26
#define DED37_F1_LE_MASK                                             0x20000000
#define DED37_F1_LE_RD(src)                        (((src) & 0x20000000) >> 29)
#define DED37_F1_LE_WR(src)                   (((unsigned int)(src) << 29) & 0x20000000)
#define DED37_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields DED36	 */
#define DED36_F1_LE_WIDTH                                                     1
#define DED36_F1_LE_SHIFT                                                    27
#define DED36_F1_LE_MASK                                             0x10000000
#define DED36_F1_LE_RD(src)                        (((src) & 0x10000000) >> 28)
#define DED36_F1_LE_WR(src)                   (((unsigned int)(src) << 28) & 0x10000000)
#define DED36_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields DED35	 */
#define DED35_F1_LE_WIDTH                                                     1
#define DED35_F1_LE_SHIFT                                                    28
#define DED35_F1_LE_MASK                                             0x08000000
#define DED35_F1_LE_RD(src)                        (((src) & 0x08000000) >> 27)
#define DED35_F1_LE_WR(src)                   (((unsigned int)(src) << 27) & 0x08000000)
#define DED35_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields DED34	 */
#define DED34_F1_LE_WIDTH                                                     1
#define DED34_F1_LE_SHIFT                                                    29
#define DED34_F1_LE_MASK                                             0x04000000
#define DED34_F1_LE_RD(src)                        (((src) & 0x04000000) >> 26)
#define DED34_F1_LE_WR(src)                   (((unsigned int)(src) << 26) & 0x04000000)
#define DED34_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields DED33	 */
#define DED33_F1_LE_WIDTH                                                     1
#define DED33_F1_LE_SHIFT                                                    30
#define DED33_F1_LE_MASK                                             0x02000000
#define DED33_F1_LE_RD(src)                        (((src) & 0x02000000) >> 25)
#define DED33_F1_LE_WR(src)                   (((unsigned int)(src) << 25) & 0x02000000)
#define DED33_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields DED32	 */
#define DED32_F1_LE_WIDTH                                                     1
#define DED32_F1_LE_SHIFT                                                    31
#define DED32_F1_LE_MASK                                             0x01000000
#define DED32_F1_LE_RD(src)                        (((src) & 0x01000000) >> 24)
#define DED32_F1_LE_WR(src)                   (((unsigned int)(src) << 24) & 0x01000000)
#define DED32_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register GLBL_DED_ERRHMask	*/

/*Mask Register Fields DED63Mask	 */
#define DED63MASK_F1_LE_WIDTH                                                 1
#define DED63MASK_F1_LE_SHIFT                                                 0
#define DED63MASK_F1_LE_MASK                                         0x00000080
#define DED63MASK_F1_LE_RD(src)                      (((src) & 0x00000080)<< 7)
#define DED63MASK_F1_LE_WR(src)                (((unsigned int)(src) >> 7) & 0x00000080)
#define DED63MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*Mask Register Fields DED62Mask	 */
#define DED62MASK_F1_LE_WIDTH                                                 1
#define DED62MASK_F1_LE_SHIFT                                                 1
#define DED62MASK_F1_LE_MASK                                         0x00000040
#define DED62MASK_F1_LE_RD(src)                      (((src) & 0x00000040)<< 6)
#define DED62MASK_F1_LE_WR(src)                (((unsigned int)(src) >> 6) & 0x00000040)
#define DED62MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*Mask Register Fields DED61Mask	 */
#define DED61MASK_F1_LE_WIDTH                                                 1
#define DED61MASK_F1_LE_SHIFT                                                 2
#define DED61MASK_F1_LE_MASK                                         0x00000020
#define DED61MASK_F1_LE_RD(src)                      (((src) & 0x00000020)<< 5)
#define DED61MASK_F1_LE_WR(src)                (((unsigned int)(src) >> 5) & 0x00000020)
#define DED61MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*Mask Register Fields DED60Mask	 */
#define DED60MASK_F1_LE_WIDTH                                                 1
#define DED60MASK_F1_LE_SHIFT                                                 3
#define DED60MASK_F1_LE_MASK                                         0x00000010
#define DED60MASK_F1_LE_RD(src)                      (((src) & 0x00000010)<< 4)
#define DED60MASK_F1_LE_WR(src)                (((unsigned int)(src) >> 4) & 0x00000010)
#define DED60MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*Mask Register Fields DED59Mask	 */
#define DED59MASK_F1_LE_WIDTH                                                 1
#define DED59MASK_F1_LE_SHIFT                                                 4
#define DED59MASK_F1_LE_MASK                                         0x00000008
#define DED59MASK_F1_LE_RD(src)                      (((src) & 0x00000008)<< 3)
#define DED59MASK_F1_LE_WR(src)                (((unsigned int)(src) >> 3) & 0x00000008)
#define DED59MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*Mask Register Fields DED58Mask	 */
#define DED58MASK_F1_LE_WIDTH                                                 1
#define DED58MASK_F1_LE_SHIFT                                                 5
#define DED58MASK_F1_LE_MASK                                         0x00000004
#define DED58MASK_F1_LE_RD(src)                      (((src) & 0x00000004)<< 2)
#define DED58MASK_F1_LE_WR(src)                (((unsigned int)(src) >> 2) & 0x00000004)
#define DED58MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*Mask Register Fields DED57Mask	 */
#define DED57MASK_F1_LE_WIDTH                                                 1
#define DED57MASK_F1_LE_SHIFT                                                 6
#define DED57MASK_F1_LE_MASK                                         0x00000002
#define DED57MASK_F1_LE_RD(src)                      (((src) & 0x00000002)<< 1)
#define DED57MASK_F1_LE_WR(src)                (((unsigned int)(src) >> 1) & 0x00000002)
#define DED57MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*Mask Register Fields DED56Mask	 */
#define DED56MASK_F1_LE_WIDTH                                                 1
#define DED56MASK_F1_LE_SHIFT                                                 7
#define DED56MASK_F1_LE_MASK                                         0x00000001
#define DED56MASK_F1_LE_RD(src)                      (((src) & 0x00000001)<< 0)
#define DED56MASK_F1_LE_WR(src)                (((unsigned int)(src) >> 0) & 0x00000001)
#define DED56MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*Mask Register Fields DED55Mask	 */
#define DED55MASK_F1_LE_WIDTH                                                 1
#define DED55MASK_F1_LE_SHIFT                                                 8
#define DED55MASK_F1_LE_MASK                                         0x00008000
#define DED55MASK_F1_LE_RD(src)                    (((src) & 0x00008000) >> 15)
#define DED55MASK_F1_LE_WR(src)               (((unsigned int)(src) << 15) & 0x00008000)
#define DED55MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*Mask Register Fields DED54Mask	 */
#define DED54MASK_F1_LE_WIDTH                                                 1
#define DED54MASK_F1_LE_SHIFT                                                 9
#define DED54MASK_F1_LE_MASK                                         0x00004000
#define DED54MASK_F1_LE_RD(src)                    (((src) & 0x00004000) >> 14)
#define DED54MASK_F1_LE_WR(src)               (((unsigned int)(src) << 14) & 0x00004000)
#define DED54MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*Mask Register Fields DED53Mask	 */
#define DED53MASK_F1_LE_WIDTH                                                 1
#define DED53MASK_F1_LE_SHIFT                                                10
#define DED53MASK_F1_LE_MASK                                         0x00002000
#define DED53MASK_F1_LE_RD(src)                    (((src) & 0x00002000) >> 13)
#define DED53MASK_F1_LE_WR(src)               (((unsigned int)(src) << 13) & 0x00002000)
#define DED53MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*Mask Register Fields DED52Mask	 */
#define DED52MASK_F1_LE_WIDTH                                                 1
#define DED52MASK_F1_LE_SHIFT                                                11
#define DED52MASK_F1_LE_MASK                                         0x00001000
#define DED52MASK_F1_LE_RD(src)                    (((src) & 0x00001000) >> 12)
#define DED52MASK_F1_LE_WR(src)               (((unsigned int)(src) << 12) & 0x00001000)
#define DED52MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*Mask Register Fields DED51Mask	 */
#define DED51MASK_F1_LE_WIDTH                                                 1
#define DED51MASK_F1_LE_SHIFT                                                12
#define DED51MASK_F1_LE_MASK                                         0x00000800
#define DED51MASK_F1_LE_RD(src)                    (((src) & 0x00000800) >> 11)
#define DED51MASK_F1_LE_WR(src)               (((unsigned int)(src) << 11) & 0x00000800)
#define DED51MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*Mask Register Fields DED50Mask	 */
#define DED50MASK_F1_LE_WIDTH                                                 1
#define DED50MASK_F1_LE_SHIFT                                                13
#define DED50MASK_F1_LE_MASK                                         0x00000400
#define DED50MASK_F1_LE_RD(src)                    (((src) & 0x00000400) >> 10)
#define DED50MASK_F1_LE_WR(src)               (((unsigned int)(src) << 10) & 0x00000400)
#define DED50MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*Mask Register Fields DED49Mask	 */
#define DED49MASK_F1_LE_WIDTH                                                 1
#define DED49MASK_F1_LE_SHIFT                                                14
#define DED49MASK_F1_LE_MASK                                         0x00000200
#define DED49MASK_F1_LE_RD(src)                     (((src) & 0x00000200) >> 9)
#define DED49MASK_F1_LE_WR(src)                (((unsigned int)(src) << 9) & 0x00000200)
#define DED49MASK_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*Mask Register Fields DED48Mask	 */
#define DED48MASK_F1_LE_WIDTH                                                 1
#define DED48MASK_F1_LE_SHIFT                                                15
#define DED48MASK_F1_LE_MASK                                         0x00000100
#define DED48MASK_F1_LE_RD(src)                     (((src) & 0x00000100) >> 8)
#define DED48MASK_F1_LE_WR(src)                (((unsigned int)(src) << 8) & 0x00000100)
#define DED48MASK_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*Mask Register Fields DED47Mask	 */
#define DED47MASK_F1_LE_WIDTH                                                 1
#define DED47MASK_F1_LE_SHIFT                                                16
#define DED47MASK_F1_LE_MASK                                         0x00800000
#define DED47MASK_F1_LE_RD(src)                    (((src) & 0x00800000) >> 23)
#define DED47MASK_F1_LE_WR(src)               (((unsigned int)(src) << 23) & 0x00800000)
#define DED47MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*Mask Register Fields DED46Mask	 */
#define DED46MASK_F1_LE_WIDTH                                                 1
#define DED46MASK_F1_LE_SHIFT                                                17
#define DED46MASK_F1_LE_MASK                                         0x00400000
#define DED46MASK_F1_LE_RD(src)                    (((src) & 0x00400000) >> 22)
#define DED46MASK_F1_LE_WR(src)               (((unsigned int)(src) << 22) & 0x00400000)
#define DED46MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*Mask Register Fields DED45Mask	 */
#define DED45MASK_F1_LE_WIDTH                                                 1
#define DED45MASK_F1_LE_SHIFT                                                18
#define DED45MASK_F1_LE_MASK                                         0x00200000
#define DED45MASK_F1_LE_RD(src)                    (((src) & 0x00200000) >> 21)
#define DED45MASK_F1_LE_WR(src)               (((unsigned int)(src) << 21) & 0x00200000)
#define DED45MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*Mask Register Fields DED44Mask	 */
#define DED44MASK_F1_LE_WIDTH                                                 1
#define DED44MASK_F1_LE_SHIFT                                                19
#define DED44MASK_F1_LE_MASK                                         0x00100000
#define DED44MASK_F1_LE_RD(src)                    (((src) & 0x00100000) >> 20)
#define DED44MASK_F1_LE_WR(src)               (((unsigned int)(src) << 20) & 0x00100000)
#define DED44MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*Mask Register Fields DED43Mask	 */
#define DED43MASK_F1_LE_WIDTH                                                 1
#define DED43MASK_F1_LE_SHIFT                                                20
#define DED43MASK_F1_LE_MASK                                         0x00080000
#define DED43MASK_F1_LE_RD(src)                    (((src) & 0x00080000) >> 19)
#define DED43MASK_F1_LE_WR(src)               (((unsigned int)(src) << 19) & 0x00080000)
#define DED43MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*Mask Register Fields DED42Mask	 */
#define DED42MASK_F1_LE_WIDTH                                                 1
#define DED42MASK_F1_LE_SHIFT                                                21
#define DED42MASK_F1_LE_MASK                                         0x00040000
#define DED42MASK_F1_LE_RD(src)                    (((src) & 0x00040000) >> 18)
#define DED42MASK_F1_LE_WR(src)               (((unsigned int)(src) << 18) & 0x00040000)
#define DED42MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*Mask Register Fields DED41Mask	 */
#define DED41MASK_F1_LE_WIDTH                                                 1
#define DED41MASK_F1_LE_SHIFT                                                22
#define DED41MASK_F1_LE_MASK                                         0x00020000
#define DED41MASK_F1_LE_RD(src)                    (((src) & 0x00020000) >> 17)
#define DED41MASK_F1_LE_WR(src)               (((unsigned int)(src) << 17) & 0x00020000)
#define DED41MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*Mask Register Fields DED40Mask	 */
#define DED40MASK_F1_LE_WIDTH                                                 1
#define DED40MASK_F1_LE_SHIFT                                                23
#define DED40MASK_F1_LE_MASK                                         0x00010000
#define DED40MASK_F1_LE_RD(src)                    (((src) & 0x00010000) >> 16)
#define DED40MASK_F1_LE_WR(src)               (((unsigned int)(src) << 16) & 0x00010000)
#define DED40MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*Mask Register Fields DED39Mask	 */
#define DED39MASK_F1_LE_WIDTH                                                 1
#define DED39MASK_F1_LE_SHIFT                                                24
#define DED39MASK_F1_LE_MASK                                         0x80000000
#define DED39MASK_F1_LE_RD(src)                    (((src) & 0x80000000) >> 31)
#define DED39MASK_F1_LE_WR(src)               (((unsigned int)(src) << 31) & 0x80000000)
#define DED39MASK_F1_LE_SET(dst,src)                      ((dst)&~0x80000000)|\
			(((unsigned int)(src) << 31) & 0x80000000)

/*Mask Register Fields DED38Mask	 */
#define DED38MASK_F1_LE_WIDTH                                                 1
#define DED38MASK_F1_LE_SHIFT                                                25
#define DED38MASK_F1_LE_MASK                                         0x40000000
#define DED38MASK_F1_LE_RD(src)                    (((src) & 0x40000000) >> 30)
#define DED38MASK_F1_LE_WR(src)               (((unsigned int)(src) << 30) & 0x40000000)
#define DED38MASK_F1_LE_SET(dst,src)                      ((dst)&~0x40000000)|\
			(((unsigned int)(src) << 30) & 0x40000000)

/*Mask Register Fields DED37Mask	 */
#define DED37MASK_F1_LE_WIDTH                                                 1
#define DED37MASK_F1_LE_SHIFT                                                26
#define DED37MASK_F1_LE_MASK                                         0x20000000
#define DED37MASK_F1_LE_RD(src)                    (((src) & 0x20000000) >> 29)
#define DED37MASK_F1_LE_WR(src)               (((unsigned int)(src) << 29) & 0x20000000)
#define DED37MASK_F1_LE_SET(dst,src)                      ((dst)&~0x20000000)|\
			(((unsigned int)(src) << 29) & 0x20000000)

/*Mask Register Fields DED36Mask	 */
#define DED36MASK_F1_LE_WIDTH                                                 1
#define DED36MASK_F1_LE_SHIFT                                                27
#define DED36MASK_F1_LE_MASK                                         0x10000000
#define DED36MASK_F1_LE_RD(src)                    (((src) & 0x10000000) >> 28)
#define DED36MASK_F1_LE_WR(src)               (((unsigned int)(src) << 28) & 0x10000000)
#define DED36MASK_F1_LE_SET(dst,src)                      ((dst)&~0x10000000)|\
			(((unsigned int)(src) << 28) & 0x10000000)

/*Mask Register Fields DED35Mask	 */
#define DED35MASK_F1_LE_WIDTH                                                 1
#define DED35MASK_F1_LE_SHIFT                                                28
#define DED35MASK_F1_LE_MASK                                         0x08000000
#define DED35MASK_F1_LE_RD(src)                    (((src) & 0x08000000) >> 27)
#define DED35MASK_F1_LE_WR(src)               (((unsigned int)(src) << 27) & 0x08000000)
#define DED35MASK_F1_LE_SET(dst,src)                      ((dst)&~0x08000000)|\
			(((unsigned int)(src) << 27) & 0x08000000)

/*Mask Register Fields DED34Mask	 */
#define DED34MASK_F1_LE_WIDTH                                                 1
#define DED34MASK_F1_LE_SHIFT                                                29
#define DED34MASK_F1_LE_MASK                                         0x04000000
#define DED34MASK_F1_LE_RD(src)                    (((src) & 0x04000000) >> 26)
#define DED34MASK_F1_LE_WR(src)               (((unsigned int)(src) << 26) & 0x04000000)
#define DED34MASK_F1_LE_SET(dst,src)                      ((dst)&~0x04000000)|\
			(((unsigned int)(src) << 26) & 0x04000000)

/*Mask Register Fields DED33Mask	 */
#define DED33MASK_F1_LE_WIDTH                                                 1
#define DED33MASK_F1_LE_SHIFT                                                30
#define DED33MASK_F1_LE_MASK                                         0x02000000
#define DED33MASK_F1_LE_RD(src)                    (((src) & 0x02000000) >> 25)
#define DED33MASK_F1_LE_WR(src)               (((unsigned int)(src) << 25) & 0x02000000)
#define DED33MASK_F1_LE_SET(dst,src)                      ((dst)&~0x02000000)|\
			(((unsigned int)(src) << 25) & 0x02000000)

/*Mask Register Fields DED32Mask	 */
#define DED32MASK_F1_LE_WIDTH                                                 1
#define DED32MASK_F1_LE_SHIFT                                                31
#define DED32MASK_F1_LE_MASK                                         0x01000000
#define DED32MASK_F1_LE_RD(src)                    (((src) & 0x01000000) >> 24)
#define DED32MASK_F1_LE_WR(src)               (((unsigned int)(src) << 24) & 0x01000000)
#define DED32MASK_F1_LE_SET(dst,src)                      ((dst)&~0x01000000)|\
			(((unsigned int)(src) << 24) & 0x01000000)

/*	Register GLBL_MDED_ERRL	*/

/*	 Fields MDED31	 */
#define MDED31_F1_LE_WIDTH                                                    1
#define MDED31_F1_LE_SHIFT                                                    0
#define MDED31_F1_LE_MASK                                            0x00000080
#define MDED31_F1_LE_RD(src)                         (((src) & 0x00000080)<< 7)
#define MDED31_F1_LE_WR(src)                   (((unsigned int)(src) >> 7) & 0x00000080)
#define MDED31_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields MDED30	 */
#define MDED30_F1_LE_WIDTH                                                    1
#define MDED30_F1_LE_SHIFT                                                    1
#define MDED30_F1_LE_MASK                                            0x00000040
#define MDED30_F1_LE_RD(src)                         (((src) & 0x00000040)<< 6)
#define MDED30_F1_LE_WR(src)                   (((unsigned int)(src) >> 6) & 0x00000040)
#define MDED30_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields MDED29	 */
#define MDED29_F1_LE_WIDTH                                                    1
#define MDED29_F1_LE_SHIFT                                                    2
#define MDED29_F1_LE_MASK                                            0x00000020
#define MDED29_F1_LE_RD(src)                         (((src) & 0x00000020)<< 5)
#define MDED29_F1_LE_WR(src)                   (((unsigned int)(src) >> 5) & 0x00000020)
#define MDED29_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*	 Fields MDED28	 */
#define MDED28_F1_LE_WIDTH                                                    1
#define MDED28_F1_LE_SHIFT                                                    3
#define MDED28_F1_LE_MASK                                            0x00000010
#define MDED28_F1_LE_RD(src)                         (((src) & 0x00000010)<< 4)
#define MDED28_F1_LE_WR(src)                   (((unsigned int)(src) >> 4) & 0x00000010)
#define MDED28_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields MDED27	 */
#define MDED27_F1_LE_WIDTH                                                    1
#define MDED27_F1_LE_SHIFT                                                    4
#define MDED27_F1_LE_MASK                                            0x00000008
#define MDED27_F1_LE_RD(src)                         (((src) & 0x00000008)<< 3)
#define MDED27_F1_LE_WR(src)                   (((unsigned int)(src) >> 3) & 0x00000008)
#define MDED27_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*	 Fields MDED26	 */
#define MDED26_F1_LE_WIDTH                                                    1
#define MDED26_F1_LE_SHIFT                                                    5
#define MDED26_F1_LE_MASK                                            0x00000004
#define MDED26_F1_LE_RD(src)                         (((src) & 0x00000004)<< 2)
#define MDED26_F1_LE_WR(src)                   (((unsigned int)(src) >> 2) & 0x00000004)
#define MDED26_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*	 Fields MDED25	 */
#define MDED25_F1_LE_WIDTH                                                    1
#define MDED25_F1_LE_SHIFT                                                    6
#define MDED25_F1_LE_MASK                                            0x00000002
#define MDED25_F1_LE_RD(src)                         (((src) & 0x00000002)<< 1)
#define MDED25_F1_LE_WR(src)                   (((unsigned int)(src) >> 1) & 0x00000002)
#define MDED25_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*	 Fields MDED24	 */
#define MDED24_F1_LE_WIDTH                                                    1
#define MDED24_F1_LE_SHIFT                                                    7
#define MDED24_F1_LE_MASK                                            0x00000001
#define MDED24_F1_LE_RD(src)                         (((src) & 0x00000001)<< 0)
#define MDED24_F1_LE_WR(src)                   (((unsigned int)(src) >> 0) & 0x00000001)
#define MDED24_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*	 Fields MDED23	 */
#define MDED23_F1_LE_WIDTH                                                    1
#define MDED23_F1_LE_SHIFT                                                    8
#define MDED23_F1_LE_MASK                                            0x00008000
#define MDED23_F1_LE_RD(src)                       (((src) & 0x00008000) >> 15)
#define MDED23_F1_LE_WR(src)                  (((unsigned int)(src) << 15) & 0x00008000)
#define MDED23_F1_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*	 Fields MDED22	 */
#define MDED22_F1_LE_WIDTH                                                    1
#define MDED22_F1_LE_SHIFT                                                    9
#define MDED22_F1_LE_MASK                                            0x00004000
#define MDED22_F1_LE_RD(src)                       (((src) & 0x00004000) >> 14)
#define MDED22_F1_LE_WR(src)                  (((unsigned int)(src) << 14) & 0x00004000)
#define MDED22_F1_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*	 Fields MDED21	 */
#define MDED21_F1_LE_WIDTH                                                    1
#define MDED21_F1_LE_SHIFT                                                   10
#define MDED21_F1_LE_MASK                                            0x00002000
#define MDED21_F1_LE_RD(src)                       (((src) & 0x00002000) >> 13)
#define MDED21_F1_LE_WR(src)                  (((unsigned int)(src) << 13) & 0x00002000)
#define MDED21_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*	 Fields MDED20	 */
#define MDED20_F1_LE_WIDTH                                                    1
#define MDED20_F1_LE_SHIFT                                                   11
#define MDED20_F1_LE_MASK                                            0x00001000
#define MDED20_F1_LE_RD(src)                       (((src) & 0x00001000) >> 12)
#define MDED20_F1_LE_WR(src)                  (((unsigned int)(src) << 12) & 0x00001000)
#define MDED20_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*	 Fields MDED19	 */
#define MDED19_F1_LE_WIDTH                                                    1
#define MDED19_F1_LE_SHIFT                                                   12
#define MDED19_F1_LE_MASK                                            0x00000800
#define MDED19_F1_LE_RD(src)                       (((src) & 0x00000800) >> 11)
#define MDED19_F1_LE_WR(src)                  (((unsigned int)(src) << 11) & 0x00000800)
#define MDED19_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*	 Fields MDED18	 */
#define MDED18_F1_LE_WIDTH                                                    1
#define MDED18_F1_LE_SHIFT                                                   13
#define MDED18_F1_LE_MASK                                            0x00000400
#define MDED18_F1_LE_RD(src)                       (((src) & 0x00000400) >> 10)
#define MDED18_F1_LE_WR(src)                  (((unsigned int)(src) << 10) & 0x00000400)
#define MDED18_F1_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*	 Fields MDED17	 */
#define MDED17_F1_LE_WIDTH                                                    1
#define MDED17_F1_LE_SHIFT                                                   14
#define MDED17_F1_LE_MASK                                            0x00000200
#define MDED17_F1_LE_RD(src)                        (((src) & 0x00000200) >> 9)
#define MDED17_F1_LE_WR(src)                   (((unsigned int)(src) << 9) & 0x00000200)
#define MDED17_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*	 Fields MDED16	 */
#define MDED16_F1_LE_WIDTH                                                    1
#define MDED16_F1_LE_SHIFT                                                   15
#define MDED16_F1_LE_MASK                                            0x00000100
#define MDED16_F1_LE_RD(src)                        (((src) & 0x00000100) >> 8)
#define MDED16_F1_LE_WR(src)                   (((unsigned int)(src) << 8) & 0x00000100)
#define MDED16_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*	 Fields MDED15	 */
#define MDED15_F1_LE_WIDTH                                                    1
#define MDED15_F1_LE_SHIFT                                                   16
#define MDED15_F1_LE_MASK                                            0x00800000
#define MDED15_F1_LE_RD(src)                       (((src) & 0x00800000) >> 23)
#define MDED15_F1_LE_WR(src)                  (((unsigned int)(src) << 23) & 0x00800000)
#define MDED15_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*	 Fields MDED14	 */
#define MDED14_F1_LE_WIDTH                                                    1
#define MDED14_F1_LE_SHIFT                                                   17
#define MDED14_F1_LE_MASK                                            0x00400000
#define MDED14_F1_LE_RD(src)                       (((src) & 0x00400000) >> 22)
#define MDED14_F1_LE_WR(src)                  (((unsigned int)(src) << 22) & 0x00400000)
#define MDED14_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*	 Fields MDED13	 */
#define MDED13_F1_LE_WIDTH                                                    1
#define MDED13_F1_LE_SHIFT                                                   18
#define MDED13_F1_LE_MASK                                            0x00200000
#define MDED13_F1_LE_RD(src)                       (((src) & 0x00200000) >> 21)
#define MDED13_F1_LE_WR(src)                  (((unsigned int)(src) << 21) & 0x00200000)
#define MDED13_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*	 Fields MDED12	 */
#define MDED12_F1_LE_WIDTH                                                    1
#define MDED12_F1_LE_SHIFT                                                   19
#define MDED12_F1_LE_MASK                                            0x00100000
#define MDED12_F1_LE_RD(src)                       (((src) & 0x00100000) >> 20)
#define MDED12_F1_LE_WR(src)                  (((unsigned int)(src) << 20) & 0x00100000)
#define MDED12_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields MDED11	 */
#define MDED11_F1_LE_WIDTH                                                    1
#define MDED11_F1_LE_SHIFT                                                   20
#define MDED11_F1_LE_MASK                                            0x00080000
#define MDED11_F1_LE_RD(src)                       (((src) & 0x00080000) >> 19)
#define MDED11_F1_LE_WR(src)                  (((unsigned int)(src) << 19) & 0x00080000)
#define MDED11_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*	 Fields MDED10	 */
#define MDED10_F1_LE_WIDTH                                                    1
#define MDED10_F1_LE_SHIFT                                                   21
#define MDED10_F1_LE_MASK                                            0x00040000
#define MDED10_F1_LE_RD(src)                       (((src) & 0x00040000) >> 18)
#define MDED10_F1_LE_WR(src)                  (((unsigned int)(src) << 18) & 0x00040000)
#define MDED10_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*	 Fields MDED9	 */
#define MDED9_F1_LE_WIDTH                                                     1
#define MDED9_F1_LE_SHIFT                                                    22
#define MDED9_F1_LE_MASK                                             0x00020000
#define MDED9_F1_LE_RD(src)                        (((src) & 0x00020000) >> 17)
#define MDED9_F1_LE_WR(src)                   (((unsigned int)(src) << 17) & 0x00020000)
#define MDED9_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*	 Fields MDED8	 */
#define MDED8_F1_LE_WIDTH                                                     1
#define MDED8_F1_LE_SHIFT                                                    23
#define MDED8_F1_LE_MASK                                             0x00010000
#define MDED8_F1_LE_RD(src)                        (((src) & 0x00010000) >> 16)
#define MDED8_F1_LE_WR(src)                   (((unsigned int)(src) << 16) & 0x00010000)
#define MDED8_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*	 Fields MDED7	 */
#define MDED7_F1_LE_WIDTH                                                     1
#define MDED7_F1_LE_SHIFT                                                    24
#define MDED7_F1_LE_MASK                                             0x80000000
#define MDED7_F1_LE_RD(src)                        (((src) & 0x80000000) >> 31)
#define MDED7_F1_LE_WR(src)                   (((unsigned int)(src) << 31) & 0x80000000)
#define MDED7_F1_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields MDED6	 */
#define MDED6_F1_LE_WIDTH                                                     1
#define MDED6_F1_LE_SHIFT                                                    25
#define MDED6_F1_LE_MASK                                             0x40000000
#define MDED6_F1_LE_RD(src)                        (((src) & 0x40000000) >> 30)
#define MDED6_F1_LE_WR(src)                   (((unsigned int)(src) << 30) & 0x40000000)
#define MDED6_F1_LE_SET(dst,src)                     ((dst)&~0x40000000)|\
				(((unsigned int)(src) << 30) & 0x40000000)

/*	 Fields MDED5	 */
#define MDED5_F1_LE_WIDTH                                                     1
#define MDED5_F1_LE_SHIFT                                                    26
#define MDED5_F1_LE_MASK                                             0x20000000
#define MDED5_F1_LE_RD(src)                        (((src) & 0x20000000) >> 29)
#define MDED5_F1_LE_WR(src)                   (((unsigned int)(src) << 29) & 0x20000000)
#define MDED5_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields MDED4	 */
#define MDED4_F1_LE_WIDTH                                                     1
#define MDED4_F1_LE_SHIFT                                                    27
#define MDED4_F1_LE_MASK                                             0x10000000
#define MDED4_F1_LE_RD(src)                        (((src) & 0x10000000) >> 28)
#define MDED4_F1_LE_WR(src)                   (((unsigned int)(src) << 28) & 0x10000000)
#define MDED4_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields MDED3	 */
#define MDED3_F1_LE_WIDTH                                                     1
#define MDED3_F1_LE_SHIFT                                                    28
#define MDED3_F1_LE_MASK                                             0x08000000
#define MDED3_F1_LE_RD(src)                        (((src) & 0x08000000) >> 27)
#define MDED3_F1_LE_WR(src)                   (((unsigned int)(src) << 27) & 0x08000000)
#define MDED3_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields MDED2	 */
#define MDED2_F1_LE_WIDTH                                                     1
#define MDED2_F1_LE_SHIFT                                                    29
#define MDED2_F1_LE_MASK                                             0x04000000
#define MDED2_F1_LE_RD(src)                        (((src) & 0x04000000) >> 26)
#define MDED2_F1_LE_WR(src)                   (((unsigned int)(src) << 26) & 0x04000000)
#define MDED2_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields MDED1	 */
#define MDED1_F1_LE_WIDTH                                                     1
#define MDED1_F1_LE_SHIFT                                                    30
#define MDED1_F1_LE_MASK                                             0x02000000
#define MDED1_F1_LE_RD(src)                        (((src) & 0x02000000) >> 25)
#define MDED1_F1_LE_WR(src)                   (((unsigned int)(src) << 25) & 0x02000000)
#define MDED1_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields MDED0	 */
#define MDED0_F1_LE_WIDTH                                                     1
#define MDED0_F1_LE_SHIFT                                                    31
#define MDED0_F1_LE_MASK                                             0x01000000
#define MDED0_F1_LE_RD(src)                        (((src) & 0x01000000) >> 24)
#define MDED0_F1_LE_WR(src)                   (((unsigned int)(src) << 24) & 0x01000000)
#define MDED0_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register GLBL_MDED_ERRLMask	*/

/*Mask Register Fields MDED31Mask	 */
#define MDED31MASK_F1_LE_WIDTH                                                1
#define MDED31MASK_F1_LE_SHIFT                                                0
#define MDED31MASK_F1_LE_MASK                                        0x00000080
#define MDED31MASK_F1_LE_RD(src)                     (((src) & 0x00000080)<< 7)
#define MDED31MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 7) & 0x00000080)
#define MDED31MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*Mask Register Fields MDED30Mask	 */
#define MDED30MASK_F1_LE_WIDTH                                                1
#define MDED30MASK_F1_LE_SHIFT                                                1
#define MDED30MASK_F1_LE_MASK                                        0x00000040
#define MDED30MASK_F1_LE_RD(src)                     (((src) & 0x00000040)<< 6)
#define MDED30MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 6) & 0x00000040)
#define MDED30MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*Mask Register Fields MDED29Mask	 */
#define MDED29MASK_F1_LE_WIDTH                                                1
#define MDED29MASK_F1_LE_SHIFT                                                2
#define MDED29MASK_F1_LE_MASK                                        0x00000020
#define MDED29MASK_F1_LE_RD(src)                     (((src) & 0x00000020)<< 5)
#define MDED29MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 5) & 0x00000020)
#define MDED29MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*Mask Register Fields MDED28Mask	 */
#define MDED28MASK_F1_LE_WIDTH                                                1
#define MDED28MASK_F1_LE_SHIFT                                                3
#define MDED28MASK_F1_LE_MASK                                        0x00000010
#define MDED28MASK_F1_LE_RD(src)                     (((src) & 0x00000010)<< 4)
#define MDED28MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 4) & 0x00000010)
#define MDED28MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*Mask Register Fields MDED27Mask	 */
#define MDED27MASK_F1_LE_WIDTH                                                1
#define MDED27MASK_F1_LE_SHIFT                                                4
#define MDED27MASK_F1_LE_MASK                                        0x00000008
#define MDED27MASK_F1_LE_RD(src)                     (((src) & 0x00000008)<< 3)
#define MDED27MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 3) & 0x00000008)
#define MDED27MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*Mask Register Fields MDED26Mask	 */
#define MDED26MASK_F1_LE_WIDTH                                                1
#define MDED26MASK_F1_LE_SHIFT                                                5
#define MDED26MASK_F1_LE_MASK                                        0x00000004
#define MDED26MASK_F1_LE_RD(src)                     (((src) & 0x00000004)<< 2)
#define MDED26MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 2) & 0x00000004)
#define MDED26MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*Mask Register Fields MDED25Mask	 */
#define MDED25MASK_F1_LE_WIDTH                                                1
#define MDED25MASK_F1_LE_SHIFT                                                6
#define MDED25MASK_F1_LE_MASK                                        0x00000002
#define MDED25MASK_F1_LE_RD(src)                     (((src) & 0x00000002)<< 1)
#define MDED25MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 1) & 0x00000002)
#define MDED25MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*Mask Register Fields MDED24Mask	 */
#define MDED24MASK_F1_LE_WIDTH                                                1
#define MDED24MASK_F1_LE_SHIFT                                                7
#define MDED24MASK_F1_LE_MASK                                        0x00000001
#define MDED24MASK_F1_LE_RD(src)                     (((src) & 0x00000001)<< 0)
#define MDED24MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 0) & 0x00000001)
#define MDED24MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*Mask Register Fields MDED23Mask	 */
#define MDED23MASK_F1_LE_WIDTH                                                1
#define MDED23MASK_F1_LE_SHIFT                                                8
#define MDED23MASK_F1_LE_MASK                                        0x00008000
#define MDED23MASK_F1_LE_RD(src)                   (((src) & 0x00008000) >> 15)
#define MDED23MASK_F1_LE_WR(src)              (((unsigned int)(src) << 15) & 0x00008000)
#define MDED23MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*Mask Register Fields MDED22Mask	 */
#define MDED22MASK_F1_LE_WIDTH                                                1
#define MDED22MASK_F1_LE_SHIFT                                                9
#define MDED22MASK_F1_LE_MASK                                        0x00004000
#define MDED22MASK_F1_LE_RD(src)                   (((src) & 0x00004000) >> 14)
#define MDED22MASK_F1_LE_WR(src)              (((unsigned int)(src) << 14) & 0x00004000)
#define MDED22MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*Mask Register Fields MDED21Mask	 */
#define MDED21MASK_F1_LE_WIDTH                                                1
#define MDED21MASK_F1_LE_SHIFT                                               10
#define MDED21MASK_F1_LE_MASK                                        0x00002000
#define MDED21MASK_F1_LE_RD(src)                   (((src) & 0x00002000) >> 13)
#define MDED21MASK_F1_LE_WR(src)              (((unsigned int)(src) << 13) & 0x00002000)
#define MDED21MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*Mask Register Fields MDED20Mask	 */
#define MDED20MASK_F1_LE_WIDTH                                                1
#define MDED20MASK_F1_LE_SHIFT                                               11
#define MDED20MASK_F1_LE_MASK                                        0x00001000
#define MDED20MASK_F1_LE_RD(src)                   (((src) & 0x00001000) >> 12)
#define MDED20MASK_F1_LE_WR(src)              (((unsigned int)(src) << 12) & 0x00001000)
#define MDED20MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*Mask Register Fields MDED19Mask	 */
#define MDED19MASK_F1_LE_WIDTH                                                1
#define MDED19MASK_F1_LE_SHIFT                                               12
#define MDED19MASK_F1_LE_MASK                                        0x00000800
#define MDED19MASK_F1_LE_RD(src)                   (((src) & 0x00000800) >> 11)
#define MDED19MASK_F1_LE_WR(src)              (((unsigned int)(src) << 11) & 0x00000800)
#define MDED19MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*Mask Register Fields MDED18Mask	 */
#define MDED18MASK_F1_LE_WIDTH                                                1
#define MDED18MASK_F1_LE_SHIFT                                               13
#define MDED18MASK_F1_LE_MASK                                        0x00000400
#define MDED18MASK_F1_LE_RD(src)                   (((src) & 0x00000400) >> 10)
#define MDED18MASK_F1_LE_WR(src)              (((unsigned int)(src) << 10) & 0x00000400)
#define MDED18MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*Mask Register Fields MDED17Mask	 */
#define MDED17MASK_F1_LE_WIDTH                                                1
#define MDED17MASK_F1_LE_SHIFT                                               14
#define MDED17MASK_F1_LE_MASK                                        0x00000200
#define MDED17MASK_F1_LE_RD(src)                    (((src) & 0x00000200) >> 9)
#define MDED17MASK_F1_LE_WR(src)               (((unsigned int)(src) << 9) & 0x00000200)
#define MDED17MASK_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*Mask Register Fields MDED16Mask	 */
#define MDED16MASK_F1_LE_WIDTH                                                1
#define MDED16MASK_F1_LE_SHIFT                                               15
#define MDED16MASK_F1_LE_MASK                                        0x00000100
#define MDED16MASK_F1_LE_RD(src)                    (((src) & 0x00000100) >> 8)
#define MDED16MASK_F1_LE_WR(src)               (((unsigned int)(src) << 8) & 0x00000100)
#define MDED16MASK_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*Mask Register Fields MDED15Mask	 */
#define MDED15MASK_F1_LE_WIDTH                                                1
#define MDED15MASK_F1_LE_SHIFT                                               16
#define MDED15MASK_F1_LE_MASK                                        0x00800000
#define MDED15MASK_F1_LE_RD(src)                   (((src) & 0x00800000) >> 23)
#define MDED15MASK_F1_LE_WR(src)              (((unsigned int)(src) << 23) & 0x00800000)
#define MDED15MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*Mask Register Fields MDED14Mask	 */
#define MDED14MASK_F1_LE_WIDTH                                                1
#define MDED14MASK_F1_LE_SHIFT                                               17
#define MDED14MASK_F1_LE_MASK                                        0x00400000
#define MDED14MASK_F1_LE_RD(src)                   (((src) & 0x00400000) >> 22)
#define MDED14MASK_F1_LE_WR(src)              (((unsigned int)(src) << 22) & 0x00400000)
#define MDED14MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*Mask Register Fields MDED13Mask	 */
#define MDED13MASK_F1_LE_WIDTH                                                1
#define MDED13MASK_F1_LE_SHIFT                                               18
#define MDED13MASK_F1_LE_MASK                                        0x00200000
#define MDED13MASK_F1_LE_RD(src)                   (((src) & 0x00200000) >> 21)
#define MDED13MASK_F1_LE_WR(src)              (((unsigned int)(src) << 21) & 0x00200000)
#define MDED13MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*Mask Register Fields MDED12Mask	 */
#define MDED12MASK_F1_LE_WIDTH                                                1
#define MDED12MASK_F1_LE_SHIFT                                               19
#define MDED12MASK_F1_LE_MASK                                        0x00100000
#define MDED12MASK_F1_LE_RD(src)                   (((src) & 0x00100000) >> 20)
#define MDED12MASK_F1_LE_WR(src)              (((unsigned int)(src) << 20) & 0x00100000)
#define MDED12MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*Mask Register Fields MDED11Mask	 */
#define MDED11MASK_F1_LE_WIDTH                                                1
#define MDED11MASK_F1_LE_SHIFT                                               20
#define MDED11MASK_F1_LE_MASK                                        0x00080000
#define MDED11MASK_F1_LE_RD(src)                   (((src) & 0x00080000) >> 19)
#define MDED11MASK_F1_LE_WR(src)              (((unsigned int)(src) << 19) & 0x00080000)
#define MDED11MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*Mask Register Fields MDED10Mask	 */
#define MDED10MASK_F1_LE_WIDTH                                                1
#define MDED10MASK_F1_LE_SHIFT                                               21
#define MDED10MASK_F1_LE_MASK                                        0x00040000
#define MDED10MASK_F1_LE_RD(src)                   (((src) & 0x00040000) >> 18)
#define MDED10MASK_F1_LE_WR(src)              (((unsigned int)(src) << 18) & 0x00040000)
#define MDED10MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*Mask Register Fields MDED9Mask	 */
#define MDED9MASK_F1_LE_WIDTH                                                 1
#define MDED9MASK_F1_LE_SHIFT                                                22
#define MDED9MASK_F1_LE_MASK                                         0x00020000
#define MDED9MASK_F1_LE_RD(src)                    (((src) & 0x00020000) >> 17)
#define MDED9MASK_F1_LE_WR(src)               (((unsigned int)(src) << 17) & 0x00020000)
#define MDED9MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*Mask Register Fields MDED8Mask	 */
#define MDED8MASK_F1_LE_WIDTH                                                 1
#define MDED8MASK_F1_LE_SHIFT                                                23
#define MDED8MASK_F1_LE_MASK                                         0x00010000
#define MDED8MASK_F1_LE_RD(src)                    (((src) & 0x00010000) >> 16)
#define MDED8MASK_F1_LE_WR(src)               (((unsigned int)(src) << 16) & 0x00010000)
#define MDED8MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*Mask Register Fields MDED7Mask	 */
#define MDED7MASK_F1_LE_WIDTH                                                 1
#define MDED7MASK_F1_LE_SHIFT                                                24
#define MDED7MASK_F1_LE_MASK                                         0x80000000
#define MDED7MASK_F1_LE_RD(src)                    (((src) & 0x80000000) >> 31)
#define MDED7MASK_F1_LE_WR(src)               (((unsigned int)(src) << 31) & 0x80000000)
#define MDED7MASK_F1_LE_SET(dst,src)                      ((dst)&~0x80000000)|\
			(((unsigned int)(src) << 31) & 0x80000000)

/*Mask Register Fields MDED6Mask	 */
#define MDED6MASK_F1_LE_WIDTH                                                 1
#define MDED6MASK_F1_LE_SHIFT                                                25
#define MDED6MASK_F1_LE_MASK                                         0x40000000
#define MDED6MASK_F1_LE_RD(src)                    (((src) & 0x40000000) >> 30)
#define MDED6MASK_F1_LE_WR(src)               (((unsigned int)(src) << 30) & 0x40000000)
#define MDED6MASK_F1_LE_SET(dst,src)                      ((dst)&~0x40000000)|\
			(((unsigned int)(src) << 30) & 0x40000000)

/*Mask Register Fields MDED5Mask	 */
#define MDED5MASK_F1_LE_WIDTH                                                 1
#define MDED5MASK_F1_LE_SHIFT                                                26
#define MDED5MASK_F1_LE_MASK                                         0x20000000
#define MDED5MASK_F1_LE_RD(src)                    (((src) & 0x20000000) >> 29)
#define MDED5MASK_F1_LE_WR(src)               (((unsigned int)(src) << 29) & 0x20000000)
#define MDED5MASK_F1_LE_SET(dst,src)                      ((dst)&~0x20000000)|\
			(((unsigned int)(src) << 29) & 0x20000000)

/*Mask Register Fields MDED4Mask	 */
#define MDED4MASK_F1_LE_WIDTH                                                 1
#define MDED4MASK_F1_LE_SHIFT                                                27
#define MDED4MASK_F1_LE_MASK                                         0x10000000
#define MDED4MASK_F1_LE_RD(src)                    (((src) & 0x10000000) >> 28)
#define MDED4MASK_F1_LE_WR(src)               (((unsigned int)(src) << 28) & 0x10000000)
#define MDED4MASK_F1_LE_SET(dst,src)                      ((dst)&~0x10000000)|\
			(((unsigned int)(src) << 28) & 0x10000000)

/*Mask Register Fields MDED3Mask	 */
#define MDED3MASK_F1_LE_WIDTH                                                 1
#define MDED3MASK_F1_LE_SHIFT                                                28
#define MDED3MASK_F1_LE_MASK                                         0x08000000
#define MDED3MASK_F1_LE_RD(src)                    (((src) & 0x08000000) >> 27)
#define MDED3MASK_F1_LE_WR(src)               (((unsigned int)(src) << 27) & 0x08000000)
#define MDED3MASK_F1_LE_SET(dst,src)                      ((dst)&~0x08000000)|\
			(((unsigned int)(src) << 27) & 0x08000000)

/*Mask Register Fields MDED2Mask	 */
#define MDED2MASK_F1_LE_WIDTH                                                 1
#define MDED2MASK_F1_LE_SHIFT                                                29
#define MDED2MASK_F1_LE_MASK                                         0x04000000
#define MDED2MASK_F1_LE_RD(src)                    (((src) & 0x04000000) >> 26)
#define MDED2MASK_F1_LE_WR(src)               (((unsigned int)(src) << 26) & 0x04000000)
#define MDED2MASK_F1_LE_SET(dst,src)                      ((dst)&~0x04000000)|\
			(((unsigned int)(src) << 26) & 0x04000000)

/*Mask Register Fields MDED1Mask	 */
#define MDED1MASK_F1_LE_WIDTH                                                 1
#define MDED1MASK_F1_LE_SHIFT                                                30
#define MDED1MASK_F1_LE_MASK                                         0x02000000
#define MDED1MASK_F1_LE_RD(src)                    (((src) & 0x02000000) >> 25)
#define MDED1MASK_F1_LE_WR(src)               (((unsigned int)(src) << 25) & 0x02000000)
#define MDED1MASK_F1_LE_SET(dst,src)                      ((dst)&~0x02000000)|\
			(((unsigned int)(src) << 25) & 0x02000000)

/*Mask Register Fields MDED0Mask	 */
#define MDED0MASK_F1_LE_WIDTH                                                 1
#define MDED0MASK_F1_LE_SHIFT                                                31
#define MDED0MASK_F1_LE_MASK                                         0x01000000
#define MDED0MASK_F1_LE_RD(src)                    (((src) & 0x01000000) >> 24)
#define MDED0MASK_F1_LE_WR(src)               (((unsigned int)(src) << 24) & 0x01000000)
#define MDED0MASK_F1_LE_SET(dst,src)                      ((dst)&~0x01000000)|\
			(((unsigned int)(src) << 24) & 0x01000000)

/*	Register GLBL_MDED_ERRH	*/

/*	 Fields MDED63	 */
#define MDED63_F1_LE_WIDTH                                                    1
#define MDED63_F1_LE_SHIFT                                                    0
#define MDED63_F1_LE_MASK                                            0x00000080
#define MDED63_F1_LE_RD(src)                         (((src) & 0x00000080)<< 7)
#define MDED63_F1_LE_WR(src)                   (((unsigned int)(src) >> 7) & 0x00000080)
#define MDED63_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*	 Fields MDED62	 */
#define MDED62_F1_LE_WIDTH                                                    1
#define MDED62_F1_LE_SHIFT                                                    1
#define MDED62_F1_LE_MASK                                            0x00000040
#define MDED62_F1_LE_RD(src)                         (((src) & 0x00000040)<< 6)
#define MDED62_F1_LE_WR(src)                   (((unsigned int)(src) >> 6) & 0x00000040)
#define MDED62_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*	 Fields MDED61	 */
#define MDED61_F1_LE_WIDTH                                                    1
#define MDED61_F1_LE_SHIFT                                                    2
#define MDED61_F1_LE_MASK                                            0x00000020
#define MDED61_F1_LE_RD(src)                         (((src) & 0x00000020)<< 5)
#define MDED61_F1_LE_WR(src)                   (((unsigned int)(src) >> 5) & 0x00000020)
#define MDED61_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*	 Fields MDED60	 */
#define MDED60_F1_LE_WIDTH                                                    1
#define MDED60_F1_LE_SHIFT                                                    3
#define MDED60_F1_LE_MASK                                            0x00000010
#define MDED60_F1_LE_RD(src)                         (((src) & 0x00000010)<< 4)
#define MDED60_F1_LE_WR(src)                   (((unsigned int)(src) >> 4) & 0x00000010)
#define MDED60_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*	 Fields MDED59	 */
#define MDED59_F1_LE_WIDTH                                                    1
#define MDED59_F1_LE_SHIFT                                                    4
#define MDED59_F1_LE_MASK                                            0x00000008
#define MDED59_F1_LE_RD(src)                         (((src) & 0x00000008)<< 3)
#define MDED59_F1_LE_WR(src)                   (((unsigned int)(src) >> 3) & 0x00000008)
#define MDED59_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*	 Fields MDED58	 */
#define MDED58_F1_LE_WIDTH                                                    1
#define MDED58_F1_LE_SHIFT                                                    5
#define MDED58_F1_LE_MASK                                            0x00000004
#define MDED58_F1_LE_RD(src)                         (((src) & 0x00000004)<< 2)
#define MDED58_F1_LE_WR(src)                   (((unsigned int)(src) >> 2) & 0x00000004)
#define MDED58_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*	 Fields MDED57	 */
#define MDED57_F1_LE_WIDTH                                                    1
#define MDED57_F1_LE_SHIFT                                                    6
#define MDED57_F1_LE_MASK                                            0x00000002
#define MDED57_F1_LE_RD(src)                         (((src) & 0x00000002)<< 1)
#define MDED57_F1_LE_WR(src)                   (((unsigned int)(src) >> 1) & 0x00000002)
#define MDED57_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*	 Fields MDED56	 */
#define MDED56_F1_LE_WIDTH                                                    1
#define MDED56_F1_LE_SHIFT                                                    7
#define MDED56_F1_LE_MASK                                            0x00000001
#define MDED56_F1_LE_RD(src)                         (((src) & 0x00000001)<< 0)
#define MDED56_F1_LE_WR(src)                   (((unsigned int)(src) >> 0) & 0x00000001)
#define MDED56_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*	 Fields MDED55	 */
#define MDED55_F1_LE_WIDTH                                                    1
#define MDED55_F1_LE_SHIFT                                                    8
#define MDED55_F1_LE_MASK                                            0x00008000
#define MDED55_F1_LE_RD(src)                       (((src) & 0x00008000) >> 15)
#define MDED55_F1_LE_WR(src)                  (((unsigned int)(src) << 15) & 0x00008000)
#define MDED55_F1_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*	 Fields MDED54	 */
#define MDED54_F1_LE_WIDTH                                                    1
#define MDED54_F1_LE_SHIFT                                                    9
#define MDED54_F1_LE_MASK                                            0x00004000
#define MDED54_F1_LE_RD(src)                       (((src) & 0x00004000) >> 14)
#define MDED54_F1_LE_WR(src)                  (((unsigned int)(src) << 14) & 0x00004000)
#define MDED54_F1_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*	 Fields MDED53	 */
#define MDED53_F1_LE_WIDTH                                                    1
#define MDED53_F1_LE_SHIFT                                                   10
#define MDED53_F1_LE_MASK                                            0x00002000
#define MDED53_F1_LE_RD(src)                       (((src) & 0x00002000) >> 13)
#define MDED53_F1_LE_WR(src)                  (((unsigned int)(src) << 13) & 0x00002000)
#define MDED53_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*	 Fields MDED52	 */
#define MDED52_F1_LE_WIDTH                                                    1
#define MDED52_F1_LE_SHIFT                                                   11
#define MDED52_F1_LE_MASK                                            0x00001000
#define MDED52_F1_LE_RD(src)                       (((src) & 0x00001000) >> 12)
#define MDED52_F1_LE_WR(src)                  (((unsigned int)(src) << 12) & 0x00001000)
#define MDED52_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*	 Fields MDED51	 */
#define MDED51_F1_LE_WIDTH                                                    1
#define MDED51_F1_LE_SHIFT                                                   12
#define MDED51_F1_LE_MASK                                            0x00000800
#define MDED51_F1_LE_RD(src)                       (((src) & 0x00000800) >> 11)
#define MDED51_F1_LE_WR(src)                  (((unsigned int)(src) << 11) & 0x00000800)
#define MDED51_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*	 Fields MDED50	 */
#define MDED50_F1_LE_WIDTH                                                    1
#define MDED50_F1_LE_SHIFT                                                   13
#define MDED50_F1_LE_MASK                                            0x00000400
#define MDED50_F1_LE_RD(src)                       (((src) & 0x00000400) >> 10)
#define MDED50_F1_LE_WR(src)                  (((unsigned int)(src) << 10) & 0x00000400)
#define MDED50_F1_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*	 Fields MDED49	 */
#define MDED49_F1_LE_WIDTH                                                    1
#define MDED49_F1_LE_SHIFT                                                   14
#define MDED49_F1_LE_MASK                                            0x00000200
#define MDED49_F1_LE_RD(src)                        (((src) & 0x00000200) >> 9)
#define MDED49_F1_LE_WR(src)                   (((unsigned int)(src) << 9) & 0x00000200)
#define MDED49_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*	 Fields MDED48	 */
#define MDED48_F1_LE_WIDTH                                                    1
#define MDED48_F1_LE_SHIFT                                                   15
#define MDED48_F1_LE_MASK                                            0x00000100
#define MDED48_F1_LE_RD(src)                        (((src) & 0x00000100) >> 8)
#define MDED48_F1_LE_WR(src)                   (((unsigned int)(src) << 8) & 0x00000100)
#define MDED48_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*	 Fields MDED47	 */
#define MDED47_F1_LE_WIDTH                                                    1
#define MDED47_F1_LE_SHIFT                                                   16
#define MDED47_F1_LE_MASK                                            0x00800000
#define MDED47_F1_LE_RD(src)                       (((src) & 0x00800000) >> 23)
#define MDED47_F1_LE_WR(src)                  (((unsigned int)(src) << 23) & 0x00800000)
#define MDED47_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*	 Fields MDED46	 */
#define MDED46_F1_LE_WIDTH                                                    1
#define MDED46_F1_LE_SHIFT                                                   17
#define MDED46_F1_LE_MASK                                            0x00400000
#define MDED46_F1_LE_RD(src)                       (((src) & 0x00400000) >> 22)
#define MDED46_F1_LE_WR(src)                  (((unsigned int)(src) << 22) & 0x00400000)
#define MDED46_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*	 Fields MDED45	 */
#define MDED45_F1_LE_WIDTH                                                    1
#define MDED45_F1_LE_SHIFT                                                   18
#define MDED45_F1_LE_MASK                                            0x00200000
#define MDED45_F1_LE_RD(src)                       (((src) & 0x00200000) >> 21)
#define MDED45_F1_LE_WR(src)                  (((unsigned int)(src) << 21) & 0x00200000)
#define MDED45_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*	 Fields MDED44	 */
#define MDED44_F1_LE_WIDTH                                                    1
#define MDED44_F1_LE_SHIFT                                                   19
#define MDED44_F1_LE_MASK                                            0x00100000
#define MDED44_F1_LE_RD(src)                       (((src) & 0x00100000) >> 20)
#define MDED44_F1_LE_WR(src)                  (((unsigned int)(src) << 20) & 0x00100000)
#define MDED44_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields MDED43	 */
#define MDED43_F1_LE_WIDTH                                                    1
#define MDED43_F1_LE_SHIFT                                                   20
#define MDED43_F1_LE_MASK                                            0x00080000
#define MDED43_F1_LE_RD(src)                       (((src) & 0x00080000) >> 19)
#define MDED43_F1_LE_WR(src)                  (((unsigned int)(src) << 19) & 0x00080000)
#define MDED43_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*	 Fields MDED42	 */
#define MDED42_F1_LE_WIDTH                                                    1
#define MDED42_F1_LE_SHIFT                                                   21
#define MDED42_F1_LE_MASK                                            0x00040000
#define MDED42_F1_LE_RD(src)                       (((src) & 0x00040000) >> 18)
#define MDED42_F1_LE_WR(src)                  (((unsigned int)(src) << 18) & 0x00040000)
#define MDED42_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*	 Fields MDED41	 */
#define MDED41_F1_LE_WIDTH                                                    1
#define MDED41_F1_LE_SHIFT                                                   22
#define MDED41_F1_LE_MASK                                            0x00020000
#define MDED41_F1_LE_RD(src)                       (((src) & 0x00020000) >> 17)
#define MDED41_F1_LE_WR(src)                  (((unsigned int)(src) << 17) & 0x00020000)
#define MDED41_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*	 Fields MDED40	 */
#define MDED40_F1_LE_WIDTH                                                    1
#define MDED40_F1_LE_SHIFT                                                   23
#define MDED40_F1_LE_MASK                                            0x00010000
#define MDED40_F1_LE_RD(src)                       (((src) & 0x00010000) >> 16)
#define MDED40_F1_LE_WR(src)                  (((unsigned int)(src) << 16) & 0x00010000)
#define MDED40_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*	 Fields MDED39	 */
#define MDED39_F1_LE_WIDTH                                                    1
#define MDED39_F1_LE_SHIFT                                                   24
#define MDED39_F1_LE_MASK                                            0x80000000
#define MDED39_F1_LE_RD(src)                       (((src) & 0x80000000) >> 31)
#define MDED39_F1_LE_WR(src)                  (((unsigned int)(src) << 31) & 0x80000000)
#define MDED39_F1_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields MDED38	 */
#define MDED38_F1_LE_WIDTH                                                    1
#define MDED38_F1_LE_SHIFT                                                   25
#define MDED38_F1_LE_MASK                                            0x40000000
#define MDED38_F1_LE_RD(src)                       (((src) & 0x40000000) >> 30)
#define MDED38_F1_LE_WR(src)                  (((unsigned int)(src) << 30) & 0x40000000)
#define MDED38_F1_LE_SET(dst,src)                     ((dst)&~0x40000000)|\
				(((unsigned int)(src) << 30) & 0x40000000)

/*	 Fields MDED37	 */
#define MDED37_F1_LE_WIDTH                                                    1
#define MDED37_F1_LE_SHIFT                                                   26
#define MDED37_F1_LE_MASK                                            0x20000000
#define MDED37_F1_LE_RD(src)                       (((src) & 0x20000000) >> 29)
#define MDED37_F1_LE_WR(src)                  (((unsigned int)(src) << 29) & 0x20000000)
#define MDED37_F1_LE_SET(dst,src)                     ((dst)&~0x20000000)|\
				(((unsigned int)(src) << 29) & 0x20000000)

/*	 Fields MDED36	 */
#define MDED36_F1_LE_WIDTH                                                    1
#define MDED36_F1_LE_SHIFT                                                   27
#define MDED36_F1_LE_MASK                                            0x10000000
#define MDED36_F1_LE_RD(src)                       (((src) & 0x10000000) >> 28)
#define MDED36_F1_LE_WR(src)                  (((unsigned int)(src) << 28) & 0x10000000)
#define MDED36_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields MDED35	 */
#define MDED35_F1_LE_WIDTH                                                    1
#define MDED35_F1_LE_SHIFT                                                   28
#define MDED35_F1_LE_MASK                                            0x08000000
#define MDED35_F1_LE_RD(src)                       (((src) & 0x08000000) >> 27)
#define MDED35_F1_LE_WR(src)                  (((unsigned int)(src) << 27) & 0x08000000)
#define MDED35_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields MDED34	 */
#define MDED34_F1_LE_WIDTH                                                    1
#define MDED34_F1_LE_SHIFT                                                   29
#define MDED34_F1_LE_MASK                                            0x04000000
#define MDED34_F1_LE_RD(src)                       (((src) & 0x04000000) >> 26)
#define MDED34_F1_LE_WR(src)                  (((unsigned int)(src) << 26) & 0x04000000)
#define MDED34_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields MDED33	 */
#define MDED33_F1_LE_WIDTH                                                    1
#define MDED33_F1_LE_SHIFT                                                   30
#define MDED33_F1_LE_MASK                                            0x02000000
#define MDED33_F1_LE_RD(src)                       (((src) & 0x02000000) >> 25)
#define MDED33_F1_LE_WR(src)                  (((unsigned int)(src) << 25) & 0x02000000)
#define MDED33_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields MDED32	 */
#define MDED32_F1_LE_WIDTH                                                    1
#define MDED32_F1_LE_SHIFT                                                   31
#define MDED32_F1_LE_MASK                                            0x01000000
#define MDED32_F1_LE_RD(src)                       (((src) & 0x01000000) >> 24)
#define MDED32_F1_LE_WR(src)                  (((unsigned int)(src) << 24) & 0x01000000)
#define MDED32_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register GLBL_MDED_ERRHMask	*/

/*Mask Register Fields MDED63Mask	 */
#define MDED63MASK_F1_LE_WIDTH                                                1
#define MDED63MASK_F1_LE_SHIFT                                                0
#define MDED63MASK_F1_LE_MASK                                        0x00000080
#define MDED63MASK_F1_LE_RD(src)                     (((src) & 0x00000080)<< 7)
#define MDED63MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 7) & 0x00000080)
#define MDED63MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000080) |\
			 (((unsigned int)(src) >> 7) & 0x00000080)

/*Mask Register Fields MDED62Mask	 */
#define MDED62MASK_F1_LE_WIDTH                                                1
#define MDED62MASK_F1_LE_SHIFT                                                1
#define MDED62MASK_F1_LE_MASK                                        0x00000040
#define MDED62MASK_F1_LE_RD(src)                     (((src) & 0x00000040)<< 6)
#define MDED62MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 6) & 0x00000040)
#define MDED62MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000040) |\
			 (((unsigned int)(src) >> 6) & 0x00000040)

/*Mask Register Fields MDED61Mask	 */
#define MDED61MASK_F1_LE_WIDTH                                                1
#define MDED61MASK_F1_LE_SHIFT                                                2
#define MDED61MASK_F1_LE_MASK                                        0x00000020
#define MDED61MASK_F1_LE_RD(src)                     (((src) & 0x00000020)<< 5)
#define MDED61MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 5) & 0x00000020)
#define MDED61MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000020) |\
			 (((unsigned int)(src) >> 5) & 0x00000020)

/*Mask Register Fields MDED60Mask	 */
#define MDED60MASK_F1_LE_WIDTH                                                1
#define MDED60MASK_F1_LE_SHIFT                                                3
#define MDED60MASK_F1_LE_MASK                                        0x00000010
#define MDED60MASK_F1_LE_RD(src)                     (((src) & 0x00000010)<< 4)
#define MDED60MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 4) & 0x00000010)
#define MDED60MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000010) |\
			 (((unsigned int)(src) >> 4) & 0x00000010)

/*Mask Register Fields MDED59Mask	 */
#define MDED59MASK_F1_LE_WIDTH                                                1
#define MDED59MASK_F1_LE_SHIFT                                                4
#define MDED59MASK_F1_LE_MASK                                        0x00000008
#define MDED59MASK_F1_LE_RD(src)                     (((src) & 0x00000008)<< 3)
#define MDED59MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 3) & 0x00000008)
#define MDED59MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000008) |\
			 (((unsigned int)(src) >> 3) & 0x00000008)

/*Mask Register Fields MDED58Mask	 */
#define MDED58MASK_F1_LE_WIDTH                                                1
#define MDED58MASK_F1_LE_SHIFT                                                5
#define MDED58MASK_F1_LE_MASK                                        0x00000004
#define MDED58MASK_F1_LE_RD(src)                     (((src) & 0x00000004)<< 2)
#define MDED58MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 2) & 0x00000004)
#define MDED58MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000004) |\
			 (((unsigned int)(src) >> 2) & 0x00000004)

/*Mask Register Fields MDED57Mask	 */
#define MDED57MASK_F1_LE_WIDTH                                                1
#define MDED57MASK_F1_LE_SHIFT                                                6
#define MDED57MASK_F1_LE_MASK                                        0x00000002
#define MDED57MASK_F1_LE_RD(src)                     (((src) & 0x00000002)<< 1)
#define MDED57MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 1) & 0x00000002)
#define MDED57MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000002) |\
			 (((unsigned int)(src) >> 1) & 0x00000002)

/*Mask Register Fields MDED56Mask	 */
#define MDED56MASK_F1_LE_WIDTH                                                1
#define MDED56MASK_F1_LE_SHIFT                                                7
#define MDED56MASK_F1_LE_MASK                                        0x00000001
#define MDED56MASK_F1_LE_RD(src)                     (((src) & 0x00000001)<< 0)
#define MDED56MASK_F1_LE_WR(src)               (((unsigned int)(src) >> 0) & 0x00000001)
#define MDED56MASK_F1_LE_SET(dst,src)                   ((dst) & ~0x00000001) |\
			 (((unsigned int)(src) >> 0) & 0x00000001)

/*Mask Register Fields MDED55Mask	 */
#define MDED55MASK_F1_LE_WIDTH                                                1
#define MDED55MASK_F1_LE_SHIFT                                                8
#define MDED55MASK_F1_LE_MASK                                        0x00008000
#define MDED55MASK_F1_LE_RD(src)                   (((src) & 0x00008000) >> 15)
#define MDED55MASK_F1_LE_WR(src)              (((unsigned int)(src) << 15) & 0x00008000)
#define MDED55MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00008000) |  \
				(((unsigned int)(src) << 15) & 0x00008000)

/*Mask Register Fields MDED54Mask	 */
#define MDED54MASK_F1_LE_WIDTH                                                1
#define MDED54MASK_F1_LE_SHIFT                                                9
#define MDED54MASK_F1_LE_MASK                                        0x00004000
#define MDED54MASK_F1_LE_RD(src)                   (((src) & 0x00004000) >> 14)
#define MDED54MASK_F1_LE_WR(src)              (((unsigned int)(src) << 14) & 0x00004000)
#define MDED54MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00004000) |  \
				(((unsigned int)(src) << 14) & 0x00004000)

/*Mask Register Fields MDED53Mask	 */
#define MDED53MASK_F1_LE_WIDTH                                                1
#define MDED53MASK_F1_LE_SHIFT                                               10
#define MDED53MASK_F1_LE_MASK                                        0x00002000
#define MDED53MASK_F1_LE_RD(src)                   (((src) & 0x00002000) >> 13)
#define MDED53MASK_F1_LE_WR(src)              (((unsigned int)(src) << 13) & 0x00002000)
#define MDED53MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00002000) |  \
				(((unsigned int)(src) << 13) & 0x00002000)

/*Mask Register Fields MDED52Mask	 */
#define MDED52MASK_F1_LE_WIDTH                                                1
#define MDED52MASK_F1_LE_SHIFT                                               11
#define MDED52MASK_F1_LE_MASK                                        0x00001000
#define MDED52MASK_F1_LE_RD(src)                   (((src) & 0x00001000) >> 12)
#define MDED52MASK_F1_LE_WR(src)              (((unsigned int)(src) << 12) & 0x00001000)
#define MDED52MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00001000) |  \
				(((unsigned int)(src) << 12) & 0x00001000)

/*Mask Register Fields MDED51Mask	 */
#define MDED51MASK_F1_LE_WIDTH                                                1
#define MDED51MASK_F1_LE_SHIFT                                               12
#define MDED51MASK_F1_LE_MASK                                        0x00000800
#define MDED51MASK_F1_LE_RD(src)                   (((src) & 0x00000800) >> 11)
#define MDED51MASK_F1_LE_WR(src)              (((unsigned int)(src) << 11) & 0x00000800)
#define MDED51MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00000800) |  \
				(((unsigned int)(src) << 11) & 0x00000800)

/*Mask Register Fields MDED50Mask	 */
#define MDED50MASK_F1_LE_WIDTH                                                1
#define MDED50MASK_F1_LE_SHIFT                                               13
#define MDED50MASK_F1_LE_MASK                                        0x00000400
#define MDED50MASK_F1_LE_RD(src)                   (((src) & 0x00000400) >> 10)
#define MDED50MASK_F1_LE_WR(src)              (((unsigned int)(src) << 10) & 0x00000400)
#define MDED50MASK_F1_LE_SET(dst,src)                ((dst) & ~0x00000400) |  \
				(((unsigned int)(src) << 10) & 0x00000400)

/*Mask Register Fields MDED49Mask	 */
#define MDED49MASK_F1_LE_WIDTH                                                1
#define MDED49MASK_F1_LE_SHIFT                                               14
#define MDED49MASK_F1_LE_MASK                                        0x00000200
#define MDED49MASK_F1_LE_RD(src)                    (((src) & 0x00000200) >> 9)
#define MDED49MASK_F1_LE_WR(src)               (((unsigned int)(src) << 9) & 0x00000200)
#define MDED49MASK_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*Mask Register Fields MDED48Mask	 */
#define MDED48MASK_F1_LE_WIDTH                                                1
#define MDED48MASK_F1_LE_SHIFT                                               15
#define MDED48MASK_F1_LE_MASK                                        0x00000100
#define MDED48MASK_F1_LE_RD(src)                    (((src) & 0x00000100) >> 8)
#define MDED48MASK_F1_LE_WR(src)               (((unsigned int)(src) << 8) & 0x00000100)
#define MDED48MASK_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*Mask Register Fields MDED47Mask	 */
#define MDED47MASK_F1_LE_WIDTH                                                1
#define MDED47MASK_F1_LE_SHIFT                                               16
#define MDED47MASK_F1_LE_MASK                                        0x00800000
#define MDED47MASK_F1_LE_RD(src)                   (((src) & 0x00800000) >> 23)
#define MDED47MASK_F1_LE_WR(src)              (((unsigned int)(src) << 23) & 0x00800000)
#define MDED47MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00800000)| \
				(((unsigned int)(src) << 23) & 0x00800000)

/*Mask Register Fields MDED46Mask	 */
#define MDED46MASK_F1_LE_WIDTH                                                1
#define MDED46MASK_F1_LE_SHIFT                                               17
#define MDED46MASK_F1_LE_MASK                                        0x00400000
#define MDED46MASK_F1_LE_RD(src)                   (((src) & 0x00400000) >> 22)
#define MDED46MASK_F1_LE_WR(src)              (((unsigned int)(src) << 22) & 0x00400000)
#define MDED46MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00400000)| \
				(((unsigned int)(src) << 22) & 0x00400000)

/*Mask Register Fields MDED45Mask	 */
#define MDED45MASK_F1_LE_WIDTH                                                1
#define MDED45MASK_F1_LE_SHIFT                                               18
#define MDED45MASK_F1_LE_MASK                                        0x00200000
#define MDED45MASK_F1_LE_RD(src)                   (((src) & 0x00200000) >> 21)
#define MDED45MASK_F1_LE_WR(src)              (((unsigned int)(src) << 21) & 0x00200000)
#define MDED45MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00200000)| \
				(((unsigned int)(src) << 21) & 0x00200000)

/*Mask Register Fields MDED44Mask	 */
#define MDED44MASK_F1_LE_WIDTH                                                1
#define MDED44MASK_F1_LE_SHIFT                                               19
#define MDED44MASK_F1_LE_MASK                                        0x00100000
#define MDED44MASK_F1_LE_RD(src)                   (((src) & 0x00100000) >> 20)
#define MDED44MASK_F1_LE_WR(src)              (((unsigned int)(src) << 20) & 0x00100000)
#define MDED44MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*Mask Register Fields MDED43Mask	 */
#define MDED43MASK_F1_LE_WIDTH                                                1
#define MDED43MASK_F1_LE_SHIFT                                               20
#define MDED43MASK_F1_LE_MASK                                        0x00080000
#define MDED43MASK_F1_LE_RD(src)                   (((src) & 0x00080000) >> 19)
#define MDED43MASK_F1_LE_WR(src)              (((unsigned int)(src) << 19) & 0x00080000)
#define MDED43MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*Mask Register Fields MDED42Mask	 */
#define MDED42MASK_F1_LE_WIDTH                                                1
#define MDED42MASK_F1_LE_SHIFT                                               21
#define MDED42MASK_F1_LE_MASK                                        0x00040000
#define MDED42MASK_F1_LE_RD(src)                   (((src) & 0x00040000) >> 18)
#define MDED42MASK_F1_LE_WR(src)              (((unsigned int)(src) << 18) & 0x00040000)
#define MDED42MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*Mask Register Fields MDED41Mask	 */
#define MDED41MASK_F1_LE_WIDTH                                                1
#define MDED41MASK_F1_LE_SHIFT                                               22
#define MDED41MASK_F1_LE_MASK                                        0x00020000
#define MDED41MASK_F1_LE_RD(src)                   (((src) & 0x00020000) >> 17)
#define MDED41MASK_F1_LE_WR(src)              (((unsigned int)(src) << 17) & 0x00020000)
#define MDED41MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*Mask Register Fields MDED40Mask	 */
#define MDED40MASK_F1_LE_WIDTH                                                1
#define MDED40MASK_F1_LE_SHIFT                                               23
#define MDED40MASK_F1_LE_MASK                                        0x00010000
#define MDED40MASK_F1_LE_RD(src)                   (((src) & 0x00010000) >> 16)
#define MDED40MASK_F1_LE_WR(src)              (((unsigned int)(src) << 16) & 0x00010000)
#define MDED40MASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*Mask Register Fields MDED39Mask	 */
#define MDED39MASK_F1_LE_WIDTH                                                1
#define MDED39MASK_F1_LE_SHIFT                                               24
#define MDED39MASK_F1_LE_MASK                                        0x80000000
#define MDED39MASK_F1_LE_RD(src)                   (((src) & 0x80000000) >> 31)
#define MDED39MASK_F1_LE_WR(src)              (((unsigned int)(src) << 31) & 0x80000000)
#define MDED39MASK_F1_LE_SET(dst,src)                      ((dst)&~0x80000000)|\
			(((unsigned int)(src) << 31) & 0x80000000)

/*Mask Register Fields MDED38Mask	 */
#define MDED38MASK_F1_LE_WIDTH                                                1
#define MDED38MASK_F1_LE_SHIFT                                               25
#define MDED38MASK_F1_LE_MASK                                        0x40000000
#define MDED38MASK_F1_LE_RD(src)                   (((src) & 0x40000000) >> 30)
#define MDED38MASK_F1_LE_WR(src)              (((unsigned int)(src) << 30) & 0x40000000)
#define MDED38MASK_F1_LE_SET(dst,src)                      ((dst)&~0x40000000)|\
			(((unsigned int)(src) << 30) & 0x40000000)

/*Mask Register Fields MDED37Mask	 */
#define MDED37MASK_F1_LE_WIDTH                                                1
#define MDED37MASK_F1_LE_SHIFT                                               26
#define MDED37MASK_F1_LE_MASK                                        0x20000000
#define MDED37MASK_F1_LE_RD(src)                   (((src) & 0x20000000) >> 29)
#define MDED37MASK_F1_LE_WR(src)              (((unsigned int)(src) << 29) & 0x20000000)
#define MDED37MASK_F1_LE_SET(dst,src)                      ((dst)&~0x20000000)|\
			(((unsigned int)(src) << 29) & 0x20000000)

/*Mask Register Fields MDED36Mask	 */
#define MDED36MASK_F1_LE_WIDTH                                                1
#define MDED36MASK_F1_LE_SHIFT                                               27
#define MDED36MASK_F1_LE_MASK                                        0x10000000
#define MDED36MASK_F1_LE_RD(src)                   (((src) & 0x10000000) >> 28)
#define MDED36MASK_F1_LE_WR(src)              (((unsigned int)(src) << 28) & 0x10000000)
#define MDED36MASK_F1_LE_SET(dst,src)                      ((dst)&~0x10000000)|\
			(((unsigned int)(src) << 28) & 0x10000000)

/*Mask Register Fields MDED35Mask	 */
#define MDED35MASK_F1_LE_WIDTH                                                1
#define MDED35MASK_F1_LE_SHIFT                                               28
#define MDED35MASK_F1_LE_MASK                                        0x08000000
#define MDED35MASK_F1_LE_RD(src)                   (((src) & 0x08000000) >> 27)
#define MDED35MASK_F1_LE_WR(src)              (((unsigned int)(src) << 27) & 0x08000000)
#define MDED35MASK_F1_LE_SET(dst,src)                      ((dst)&~0x08000000)|\
			(((unsigned int)(src) << 27) & 0x08000000)

/*Mask Register Fields MDED34Mask	 */
#define MDED34MASK_F1_LE_WIDTH                                                1
#define MDED34MASK_F1_LE_SHIFT                                               29
#define MDED34MASK_F1_LE_MASK                                        0x04000000
#define MDED34MASK_F1_LE_RD(src)                   (((src) & 0x04000000) >> 26)
#define MDED34MASK_F1_LE_WR(src)              (((unsigned int)(src) << 26) & 0x04000000)
#define MDED34MASK_F1_LE_SET(dst,src)                      ((dst)&~0x04000000)|\
			(((unsigned int)(src) << 26) & 0x04000000)

/*Mask Register Fields MDED33Mask	 */
#define MDED33MASK_F1_LE_WIDTH                                                1
#define MDED33MASK_F1_LE_SHIFT                                               30
#define MDED33MASK_F1_LE_MASK                                        0x02000000
#define MDED33MASK_F1_LE_RD(src)                   (((src) & 0x02000000) >> 25)
#define MDED33MASK_F1_LE_WR(src)              (((unsigned int)(src) << 25) & 0x02000000)
#define MDED33MASK_F1_LE_SET(dst,src)                      ((dst)&~0x02000000)|\
			(((unsigned int)(src) << 25) & 0x02000000)

/*Mask Register Fields MDED32Mask	 */
#define MDED32MASK_F1_LE_WIDTH                                                1
#define MDED32MASK_F1_LE_SHIFT                                               31
#define MDED32MASK_F1_LE_MASK                                        0x01000000
#define MDED32MASK_F1_LE_RD(src)                   (((src) & 0x01000000) >> 24)
#define MDED32MASK_F1_LE_WR(src)              (((unsigned int)(src) << 24) & 0x01000000)
#define MDED32MASK_F1_LE_SET(dst,src)                      ((dst)&~0x01000000)|\
			(((unsigned int)(src) << 24) & 0x01000000)

/*	Register GLBL_MERR_ADDR	*/

/*	 Fields ERRADDRL	 */
#define ERRADDRL_F3_LE_WIDTH                                                 32
#define ERRADDRL_F3_LE_SHIFT                                                 31
#define ERRADDRL_F3_LE_MASK                                          0xffffffff
#define ERRADDRL_F3_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define ERRADDRL_F3_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define ERRADDRL_F3_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register GLBL_MERR_REQINFO	*/

/*	 Fields ERRADDRH	 */
#define ERRADDRH_F3_LE_WIDTH                                                 10
#define ERRADDRH_F3_LE_SHIFT                                                  9
#define ERRADDRH_F3_LE_MASK                                          0x0000c0ff
#define ERRADDRH_F3_LE_RD(src)               (((src) & 0x0000c000 )>> 14) | \
				(((src) & 0x000000ff) << 2)
#define ERRADDRH_F3_LE_WR(src)      (((unsigned int)(src) << 14) & 0x0000c000) | \
				(((unsigned int)(src) >> 2) & 0x000000ff)
#define ERRADDRH_F3_LE_SET(dst,src) ((dst) & ~0x0000c0ff) | \
	(((unsigned int)(src) << 14) & 0x0000c000) | (((unsigned int)(src) >> 2) & 0x000000ff)

/*	 Fields MSTRID	 */
#define MSTRID_F3_LE_WIDTH                                                    6
#define MSTRID_F3_LE_SHIFT                                                   15
#define MSTRID_F3_LE_MASK                                            0x00003f00
#define MSTRID_F3_LE_RD(src)                        (((src) & 0x00003f00) >> 8)
#define MSTRID_F3_LE_WR(src)                   (((unsigned int)(src) << 8) & 0x00003f00)
#define MSTRID_F3_LE_SET(dst,src)                 ((dst) & ~0x00003f00) |  \
				(((unsigned int)(src) << 8) & 0x00003f00)

/*	 Fields AUXINFO	 */
#define AUXINFO_F3_LE_WIDTH                                                   6
#define AUXINFO_F3_LE_SHIFT                                                  21
#define AUXINFO_F3_LE_MASK                                           0x00fc0000
#define AUXINFO_F3_LE_RD(src)                      (((src) & 0x00fc0000) >> 18)
#define AUXINFO_F3_LE_WR(src)                 (((unsigned int)(src) << 18) & 0x00fc0000)
#define AUXINFO_F3_LE_SET(dst,src)                  ((dst) & ~0x00fc0000)| \
				(((unsigned int)(src) << 18) & 0x00fc0000)

/*	 Fields REQLEN	 */
#define REQLEN_F3_LE_WIDTH                                                    2
#define REQLEN_F3_LE_SHIFT                                                   27
#define REQLEN_F3_LE_MASK                                            0x30000000
#define REQLEN_F3_LE_RD(src)                       (((src) & 0x30000000) >> 28)
#define REQLEN_F3_LE_WR(src)                  (((unsigned int)(src) << 28) & 0x30000000)
#define REQLEN_F3_LE_SET(dst,src)                     ((dst)&~0x30000000)|\
				(((unsigned int)(src) << 28) & 0x30000000)

/*	 Fields REQSIZE	 */
#define REQSIZE_F3_LE_WIDTH                                                   3
#define REQSIZE_F3_LE_SHIFT                                                  30
#define REQSIZE_F3_LE_MASK                                           0x0e000000
#define REQSIZE_F3_LE_RD(src)                      (((src) & 0x0e000000) >> 25)
#define REQSIZE_F3_LE_WR(src)                 (((unsigned int)(src) << 25) & 0x0e000000)
#define REQSIZE_F3_LE_SET(dst,src)                     ((dst)&~0x0e000000)|\
				(((unsigned int)(src) << 25) & 0x0e000000)

/*	 Fields REQTYPE	 */
#define REQTYPE_F2_LE_WIDTH                                                   1
#define REQTYPE_F2_LE_SHIFT                                                  31
#define REQTYPE_F2_LE_MASK                                           0x01000000
#define REQTYPE_F2_LE_RD(src)                      (((src) & 0x01000000) >> 24)
#define REQTYPE_F2_LE_WR(src)                 (((unsigned int)(src) << 24) & 0x01000000)
#define REQTYPE_F2_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register GLBL_TRANS_ERR	*/

/*	 Fields MSWRPOISON	 */
#define MSWRPOISON_F1_LE_WIDTH                                                1
#define MSWRPOISON_F1_LE_SHIFT                                               19
#define MSWRPOISON_F1_LE_MASK                                        0x00100000
#define MSWRPOISON_F1_LE_RD(src)                   (((src) & 0x00100000) >> 20)
#define MSWRPOISON_F1_LE_WR(src)              (((unsigned int)(src) << 20) & 0x00100000)
#define MSWRPOISON_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*	 Fields SWRPOISON	 */
#define SWRPOISON_F2_LE_WIDTH                                                 1
#define SWRPOISON_F2_LE_SHIFT                                                20
#define SWRPOISON_F2_LE_MASK                                         0x00080000
#define SWRPOISON_F2_LE_RD(src)                    (((src) & 0x00080000) >> 19)
#define SWRPOISON_F2_LE_WR(src)               (((unsigned int)(src) << 19) & 0x00080000)
#define SWRPOISON_F2_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*	 Fields SWRDYTMO	 */
#define SWRDYTMO_F2_LE_WIDTH                                                  1
#define SWRDYTMO_F2_LE_SHIFT                                                 21
#define SWRDYTMO_F2_LE_MASK                                          0x00040000
#define SWRDYTMO_F2_LE_RD(src)                     (((src) & 0x00040000) >> 18)
#define SWRDYTMO_F2_LE_WR(src)                (((unsigned int)(src) << 18) & 0x00040000)
#define SWRDYTMO_F2_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*	 Fields SWRESPTMO	 */
#define SWRESPTMO_F2_LE_WIDTH                                                 1
#define SWRESPTMO_F2_LE_SHIFT                                                22
#define SWRESPTMO_F2_LE_MASK                                         0x00020000
#define SWRESPTMO_F2_LE_RD(src)                    (((src) & 0x00020000) >> 17)
#define SWRESPTMO_F2_LE_WR(src)               (((unsigned int)(src) << 17) & 0x00020000)
#define SWRESPTMO_F2_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*	 Fields MSWRERR	 */
#define MSWRERR_F1_LE_WIDTH                                                   1
#define MSWRERR_F1_LE_SHIFT                                                  23
#define MSWRERR_F1_LE_MASK                                           0x00010000
#define MSWRERR_F1_LE_RD(src)                      (((src) & 0x00010000) >> 16)
#define MSWRERR_F1_LE_WR(src)                 (((unsigned int)(src) << 16) & 0x00010000)
#define MSWRERR_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*	 Fields SWRERR	 */
#define SWRERR_F2_LE_WIDTH                                                    1
#define SWRERR_F2_LE_SHIFT                                                   24
#define SWRERR_F2_LE_MASK                                            0x80000000
#define SWRERR_F2_LE_RD(src)                       (((src) & 0x80000000) >> 31)
#define SWRERR_F2_LE_WR(src)                  (((unsigned int)(src) << 31) & 0x80000000)
#define SWRERR_F2_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields SRRDYTMO	 */
#define SRRDYTMO_F2_LE_WIDTH                                                  1
#define SRRDYTMO_F2_LE_SHIFT                                                 28
#define SRRDYTMO_F2_LE_MASK                                          0x08000000
#define SRRDYTMO_F2_LE_RD(src)                     (((src) & 0x08000000) >> 27)
#define SRRDYTMO_F2_LE_WR(src)                (((unsigned int)(src) << 27) & 0x08000000)
#define SRRDYTMO_F2_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields SRRESPTMO	 */
#define SRRESPTMO_F2_LE_WIDTH                                                 1
#define SRRESPTMO_F2_LE_SHIFT                                                29
#define SRRESPTMO_F2_LE_MASK                                         0x04000000
#define SRRESPTMO_F2_LE_RD(src)                    (((src) & 0x04000000) >> 26)
#define SRRESPTMO_F2_LE_WR(src)               (((unsigned int)(src) << 26) & 0x04000000)
#define SRRESPTMO_F2_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields MSRDERR	 */
#define MSRDERR_F1_LE_WIDTH                                                   1
#define MSRDERR_F1_LE_SHIFT                                                  30
#define MSRDERR_F1_LE_MASK                                           0x02000000
#define MSRDERR_F1_LE_RD(src)                      (((src) & 0x02000000) >> 25)
#define MSRDERR_F1_LE_WR(src)                 (((unsigned int)(src) << 25) & 0x02000000)
#define MSRDERR_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields SRDERR	 */
#define SRDERR_F2_LE_WIDTH                                                    1
#define SRDERR_F2_LE_SHIFT                                                   31
#define SRDERR_F2_LE_MASK                                            0x01000000
#define SRDERR_F2_LE_RD(src)                       (((src) & 0x01000000) >> 24)
#define SRDERR_F2_LE_WR(src)                  (((unsigned int)(src) << 24) & 0x01000000)
#define SRDERR_F2_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register GLBL_TRANS_ERRMask	*/

/*Mask Register Fields MSWRPOISONMask	 */
#define MSWRPOISONMASK_F1_LE_WIDTH                                            1
#define MSWRPOISONMASK_F1_LE_SHIFT                                           19
#define MSWRPOISONMASK_F1_LE_MASK                                    0x00100000
#define MSWRPOISONMASK_F1_LE_RD(src)               (((src) & 0x00100000) >> 20)
#define MSWRPOISONMASK_F1_LE_WR(src)          (((unsigned int)(src) << 20) & 0x00100000)
#define MSWRPOISONMASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00100000)| \
				(((unsigned int)(src) << 20) & 0x00100000)

/*Mask Register Fields SWRPOISONMask	 */
#define SWRPOISONMASK_F1_LE_WIDTH                                             1
#define SWRPOISONMASK_F1_LE_SHIFT                                            20
#define SWRPOISONMASK_F1_LE_MASK                                     0x00080000
#define SWRPOISONMASK_F1_LE_RD(src)                (((src) & 0x00080000) >> 19)
#define SWRPOISONMASK_F1_LE_WR(src)           (((unsigned int)(src) << 19) & 0x00080000)
#define SWRPOISONMASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*Mask Register Fields SWRDYTMOMask	 */
#define SWRDYTMOMASK_F1_LE_WIDTH                                              1
#define SWRDYTMOMASK_F1_LE_SHIFT                                             21
#define SWRDYTMOMASK_F1_LE_MASK                                      0x00040000
#define SWRDYTMOMASK_F1_LE_RD(src)                 (((src) & 0x00040000) >> 18)
#define SWRDYTMOMASK_F1_LE_WR(src)            (((unsigned int)(src) << 18) & 0x00040000)
#define SWRDYTMOMASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*Mask Register Fields SWRESPTMOMask	 */
#define SWRESPTMOMASK_F1_LE_WIDTH                                             1
#define SWRESPTMOMASK_F1_LE_SHIFT                                            22
#define SWRESPTMOMASK_F1_LE_MASK                                     0x00020000
#define SWRESPTMOMASK_F1_LE_RD(src)                (((src) & 0x00020000) >> 17)
#define SWRESPTMOMASK_F1_LE_WR(src)           (((unsigned int)(src) << 17) & 0x00020000)
#define SWRESPTMOMASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*Mask Register Fields MSWRERRMask	 */
#define MSWRERRMASK_F1_LE_WIDTH                                               1
#define MSWRERRMASK_F1_LE_SHIFT                                              23
#define MSWRERRMASK_F1_LE_MASK                                       0x00010000
#define MSWRERRMASK_F1_LE_RD(src)                  (((src) & 0x00010000) >> 16)
#define MSWRERRMASK_F1_LE_WR(src)             (((unsigned int)(src) << 16) & 0x00010000)
#define MSWRERRMASK_F1_LE_SET(dst,src)                  ((dst) & ~0x00010000)| \
				(((unsigned int)(src) << 16) & 0x00010000)

/*Mask Register Fields SWRERRMask	 */
#define SWRERRMASK_F1_LE_WIDTH                                                1
#define SWRERRMASK_F1_LE_SHIFT                                               24
#define SWRERRMASK_F1_LE_MASK                                        0x80000000
#define SWRERRMASK_F1_LE_RD(src)                   (((src) & 0x80000000) >> 31)
#define SWRERRMASK_F1_LE_WR(src)              (((unsigned int)(src) << 31) & 0x80000000)
#define SWRERRMASK_F1_LE_SET(dst,src)                      ((dst)&~0x80000000)|\
			(((unsigned int)(src) << 31) & 0x80000000)

/*Mask Register Fields SRRDYTMOMask	 */
#define SRRDYTMOMASK_F1_LE_WIDTH                                              1
#define SRRDYTMOMASK_F1_LE_SHIFT                                             28
#define SRRDYTMOMASK_F1_LE_MASK                                      0x08000000
#define SRRDYTMOMASK_F1_LE_RD(src)                 (((src) & 0x08000000) >> 27)
#define SRRDYTMOMASK_F1_LE_WR(src)            (((unsigned int)(src) << 27) & 0x08000000)
#define SRRDYTMOMASK_F1_LE_SET(dst,src)                      ((dst)&~0x08000000)|\
			(((unsigned int)(src) << 27) & 0x08000000)

/*Mask Register Fields SRRESPTMOMask	 */
#define SRRESPTMOMASK_F1_LE_WIDTH                                             1
#define SRRESPTMOMASK_F1_LE_SHIFT                                            29
#define SRRESPTMOMASK_F1_LE_MASK                                     0x04000000
#define SRRESPTMOMASK_F1_LE_RD(src)                (((src) & 0x04000000) >> 26)
#define SRRESPTMOMASK_F1_LE_WR(src)           (((unsigned int)(src) << 26) & 0x04000000)
#define SRRESPTMOMASK_F1_LE_SET(dst,src)                      ((dst)&~0x04000000)|\
			(((unsigned int)(src) << 26) & 0x04000000)

/*Mask Register Fields MSRDERRMask	 */
#define MSRDERRMASK_F1_LE_WIDTH                                               1
#define MSRDERRMASK_F1_LE_SHIFT                                              30
#define MSRDERRMASK_F1_LE_MASK                                       0x02000000
#define MSRDERRMASK_F1_LE_RD(src)                  (((src) & 0x02000000) >> 25)
#define MSRDERRMASK_F1_LE_WR(src)             (((unsigned int)(src) << 25) & 0x02000000)
#define MSRDERRMASK_F1_LE_SET(dst,src)                      ((dst)&~0x02000000)|\
			(((unsigned int)(src) << 25) & 0x02000000)

/*Mask Register Fields SRDERRMask	 */
#define SRDERRMASK_F1_LE_WIDTH                                                1
#define SRDERRMASK_F1_LE_SHIFT                                               31
#define SRDERRMASK_F1_LE_MASK                                        0x01000000
#define SRDERRMASK_F1_LE_RD(src)                   (((src) & 0x01000000) >> 24)
#define SRDERRMASK_F1_LE_WR(src)              (((unsigned int)(src) << 24) & 0x01000000)
#define SRDERRMASK_F1_LE_SET(dst,src)                      ((dst)&~0x01000000)|\
			(((unsigned int)(src) << 24) & 0x01000000)

/*	Register GLBL_WDERR_ADDR	*/

/*	 Fields ERRADDRL	 */
#define ERRADDRL_F4_LE_WIDTH                                                 32
#define ERRADDRL_F4_LE_SHIFT                                                 31
#define ERRADDRL_F4_LE_MASK                                          0xffffffff
#define ERRADDRL_F4_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define ERRADDRL_F4_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define ERRADDRL_F4_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register GLBL_WDERR_REQINFO	*/

/*	 Fields ERRADDRH	 */
#define ERRADDRH_F4_LE_WIDTH                                                 10
#define ERRADDRH_F4_LE_SHIFT                                                  9
#define ERRADDRH_F4_LE_MASK                                          0x0000c0ff
#define ERRADDRH_F4_LE_RD(src)               (((src) & 0x0000c000 )>> 14) | \
				(((src) & 0x000000ff) << 2)
#define ERRADDRH_F4_LE_WR(src)      (((unsigned int)(src) << 14) & 0x0000c000) | \
				(((unsigned int)(src) >> 2) & 0x000000ff)
#define ERRADDRH_F4_LE_SET(dst,src) ((dst) & ~0x0000c0ff) | \
	(((unsigned int)(src) << 14) & 0x0000c000) | (((unsigned int)(src) >> 2) & 0x000000ff)

/*	 Fields MSTRID	 */
#define MSTRID_F4_LE_WIDTH                                                    6
#define MSTRID_F4_LE_SHIFT                                                   15
#define MSTRID_F4_LE_MASK                                            0x00003f00
#define MSTRID_F4_LE_RD(src)                        (((src) & 0x00003f00) >> 8)
#define MSTRID_F4_LE_WR(src)                   (((unsigned int)(src) << 8) & 0x00003f00)
#define MSTRID_F4_LE_SET(dst,src)                 ((dst) & ~0x00003f00) |  \
				(((unsigned int)(src) << 8) & 0x00003f00)

/*	 Fields AUXINFO	 */
#define AUXINFO_F4_LE_WIDTH                                                   6
#define AUXINFO_F4_LE_SHIFT                                                  21
#define AUXINFO_F4_LE_MASK                                           0x00fc0000
#define AUXINFO_F4_LE_RD(src)                      (((src) & 0x00fc0000) >> 18)
#define AUXINFO_F4_LE_WR(src)                 (((unsigned int)(src) << 18) & 0x00fc0000)
#define AUXINFO_F4_LE_SET(dst,src)                  ((dst) & ~0x00fc0000)| \
				(((unsigned int)(src) << 18) & 0x00fc0000)

/*	 Fields REQLEN	 */
#define REQLEN_F4_LE_WIDTH                                                    2
#define REQLEN_F4_LE_SHIFT                                                   27
#define REQLEN_F4_LE_MASK                                            0x30000000
#define REQLEN_F4_LE_RD(src)                       (((src) & 0x30000000) >> 28)
#define REQLEN_F4_LE_WR(src)                  (((unsigned int)(src) << 28) & 0x30000000)
#define REQLEN_F4_LE_SET(dst,src)                     ((dst)&~0x30000000)|\
				(((unsigned int)(src) << 28) & 0x30000000)

/*	 Fields REQSIZE	 */
#define REQSIZE_F4_LE_WIDTH                                                   3
#define REQSIZE_F4_LE_SHIFT                                                  30
#define REQSIZE_F4_LE_MASK                                           0x0e000000
#define REQSIZE_F4_LE_RD(src)                      (((src) & 0x0e000000) >> 25)
#define REQSIZE_F4_LE_WR(src)                 (((unsigned int)(src) << 25) & 0x0e000000)
#define REQSIZE_F4_LE_SET(dst,src)                     ((dst)&~0x0e000000)|\
				(((unsigned int)(src) << 25) & 0x0e000000)

/*	Register GLBL_DEVERR_ADDR	*/

/*	 Fields ERRADDRL	 */
#define ERRADDRL_F5_LE_WIDTH                                                 32
#define ERRADDRL_F5_LE_SHIFT                                                 31
#define ERRADDRL_F5_LE_MASK                                          0xffffffff
#define ERRADDRL_F5_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define ERRADDRL_F5_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define ERRADDRL_F5_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register GLBL_DEVERR_REQINFO	*/

/*	 Fields ERRADDRH	 */
#define ERRADDRH_F5_LE_WIDTH                                                 10
#define ERRADDRH_F5_LE_SHIFT                                                  9
#define ERRADDRH_F5_LE_MASK                                          0x0000c0ff
#define ERRADDRH_F5_LE_RD(src)               (((src) & 0x0000c000 )>> 14) | \
				(((src) & 0x000000ff) << 2)
#define ERRADDRH_F5_LE_WR(src)      (((unsigned int)(src) << 14) & 0x0000c000) | \
				(((unsigned int)(src) >> 2) & 0x000000ff)
#define ERRADDRH_F5_LE_SET(dst,src) ((dst) & ~0x0000c0ff) | \
	(((unsigned int)(src) << 14) & 0x0000c000) | (((unsigned int)(src) >> 2) & 0x000000ff)

/*	 Fields MSTRID	 */
#define MSTRID_F5_LE_WIDTH                                                    6
#define MSTRID_F5_LE_SHIFT                                                   15
#define MSTRID_F5_LE_MASK                                            0x00003f00
#define MSTRID_F5_LE_RD(src)                        (((src) & 0x00003f00) >> 8)
#define MSTRID_F5_LE_WR(src)                   (((unsigned int)(src) << 8) & 0x00003f00)
#define MSTRID_F5_LE_SET(dst,src)                 ((dst) & ~0x00003f00) |  \
				(((unsigned int)(src) << 8) & 0x00003f00)

/*	 Fields AUXINFO	 */
#define AUXINFO_F5_LE_WIDTH                                                   6
#define AUXINFO_F5_LE_SHIFT                                                  21
#define AUXINFO_F5_LE_MASK                                           0x00fc0000
#define AUXINFO_F5_LE_RD(src)                      (((src) & 0x00fc0000) >> 18)
#define AUXINFO_F5_LE_WR(src)                 (((unsigned int)(src) << 18) & 0x00fc0000)
#define AUXINFO_F5_LE_SET(dst,src)                  ((dst) & ~0x00fc0000)| \
				(((unsigned int)(src) << 18) & 0x00fc0000)

/*	 Fields REQLEN	 */
#define REQLEN_F5_LE_WIDTH                                                    2
#define REQLEN_F5_LE_SHIFT                                                   27
#define REQLEN_F5_LE_MASK                                            0x30000000
#define REQLEN_F5_LE_RD(src)                       (((src) & 0x30000000) >> 28)
#define REQLEN_F5_LE_WR(src)                  (((unsigned int)(src) << 28) & 0x30000000)
#define REQLEN_F5_LE_SET(dst,src)                     ((dst)&~0x30000000)|\
				(((unsigned int)(src) << 28) & 0x30000000)

/*	 Fields REQSIZE	 */
#define REQSIZE_F5_LE_WIDTH                                                   3
#define REQSIZE_F5_LE_SHIFT                                                  30
#define REQSIZE_F5_LE_MASK                                           0x0e000000
#define REQSIZE_F5_LE_RD(src)                      (((src) & 0x0e000000) >> 25)
#define REQSIZE_F5_LE_WR(src)                 (((unsigned int)(src) << 25) & 0x0e000000)
#define REQSIZE_F5_LE_SET(dst,src)                     ((dst)&~0x0e000000)|\
				(((unsigned int)(src) << 25) & 0x0e000000)

/*	 Fields REQTYPE	 */
#define REQTYPE_F3_LE_WIDTH                                                   1
#define REQTYPE_F3_LE_SHIFT                                                  31
#define REQTYPE_F3_LE_MASK                                           0x01000000
#define REQTYPE_F3_LE_RD(src)                      (((src) & 0x01000000) >> 24)
#define REQTYPE_F3_LE_WR(src)                 (((unsigned int)(src) << 24) & 0x01000000)
#define REQTYPE_F3_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register GLBL_SEC_ERRL_ALS	*/

/*	 Fields SEC	 */
#define SEC_F2_LE_WIDTH                                                      32
#define SEC_F2_LE_SHIFT                                                      31
#define SEC_F2_LE_MASK                                               0xffffffff
#define SEC_F2_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define SEC_F2_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define SEC_F2_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register GLBL_SEC_ERRH_ALS	*/

/*	 Fields SEC	 */
#define SEC_F3_LE_WIDTH                                                      32
#define SEC_F3_LE_SHIFT                                                      31
#define SEC_F3_LE_MASK                                               0xffffffff
#define SEC_F3_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define SEC_F3_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define SEC_F3_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register GLBL_DED_ERRL_ALS	*/

/*	 Fields DED	 */
#define DED_F2_LE_WIDTH                                                      32
#define DED_F2_LE_SHIFT                                                      31
#define DED_F2_LE_MASK                                               0xffffffff
#define DED_F2_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define DED_F2_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define DED_F2_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register GLBL_DED_ERRH_ALS	*/

/*	 Fields DED	 */
#define DED_F3_LE_WIDTH                                                      32
#define DED_F3_LE_SHIFT                                                      31
#define DED_F3_LE_MASK                                               0xffffffff
#define DED_F3_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define DED_F3_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define DED_F3_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register GLBL_TRANS_ERR_ALS	*/

/*	 Fields SWRPOISON	 */
#define SWRPOISON_F3_LE_WIDTH                                                 1
#define SWRPOISON_F3_LE_SHIFT                                                20
#define SWRPOISON_F3_LE_MASK                                         0x00080000
#define SWRPOISON_F3_LE_RD(src)                    (((src) & 0x00080000) >> 19)
#define SWRPOISON_F3_LE_WR(src)               (((unsigned int)(src) << 19) & 0x00080000)
#define SWRPOISON_F3_LE_SET(dst,src)                  ((dst) & ~0x00080000)| \
				(((unsigned int)(src) << 19) & 0x00080000)

/*	 Fields SWRDYTMO	 */
#define SWRDYTMO_F3_LE_WIDTH                                                  1
#define SWRDYTMO_F3_LE_SHIFT                                                 21
#define SWRDYTMO_F3_LE_MASK                                          0x00040000
#define SWRDYTMO_F3_LE_RD(src)                     (((src) & 0x00040000) >> 18)
#define SWRDYTMO_F3_LE_WR(src)                (((unsigned int)(src) << 18) & 0x00040000)
#define SWRDYTMO_F3_LE_SET(dst,src)                  ((dst) & ~0x00040000)| \
				(((unsigned int)(src) << 18) & 0x00040000)

/*	 Fields SWRESPTMO	 */
#define SWRESPTMO_F3_LE_WIDTH                                                 1
#define SWRESPTMO_F3_LE_SHIFT                                                22
#define SWRESPTMO_F3_LE_MASK                                         0x00020000
#define SWRESPTMO_F3_LE_RD(src)                    (((src) & 0x00020000) >> 17)
#define SWRESPTMO_F3_LE_WR(src)               (((unsigned int)(src) << 17) & 0x00020000)
#define SWRESPTMO_F3_LE_SET(dst,src)                  ((dst) & ~0x00020000)| \
				(((unsigned int)(src) << 17) & 0x00020000)

/*	 Fields SWRERR	 */
#define SWRERR_F3_LE_WIDTH                                                    1
#define SWRERR_F3_LE_SHIFT                                                   24
#define SWRERR_F3_LE_MASK                                            0x80000000
#define SWRERR_F3_LE_RD(src)                       (((src) & 0x80000000) >> 31)
#define SWRERR_F3_LE_WR(src)                  (((unsigned int)(src) << 31) & 0x80000000)
#define SWRERR_F3_LE_SET(dst,src)                     ((dst)&~0x80000000)|\
				(((unsigned int)(src) << 31) & 0x80000000)

/*	 Fields SRRDYTMO	 */
#define SRRDYTMO_F3_LE_WIDTH                                                  1
#define SRRDYTMO_F3_LE_SHIFT                                                 28
#define SRRDYTMO_F3_LE_MASK                                          0x08000000
#define SRRDYTMO_F3_LE_RD(src)                     (((src) & 0x08000000) >> 27)
#define SRRDYTMO_F3_LE_WR(src)                (((unsigned int)(src) << 27) & 0x08000000)
#define SRRDYTMO_F3_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields SRRESPTMO	 */
#define SRRESPTMO_F3_LE_WIDTH                                                 1
#define SRRESPTMO_F3_LE_SHIFT                                                29
#define SRRESPTMO_F3_LE_MASK                                         0x04000000
#define SRRESPTMO_F3_LE_RD(src)                    (((src) & 0x04000000) >> 26)
#define SRRESPTMO_F3_LE_WR(src)               (((unsigned int)(src) << 26) & 0x04000000)
#define SRRESPTMO_F3_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields SRDERR	 */
#define SRDERR_F3_LE_WIDTH                                                    1
#define SRDERR_F3_LE_SHIFT                                                   31
#define SRDERR_F3_LE_MASK                                            0x01000000
#define SRDERR_F3_LE_RD(src)                       (((src) & 0x01000000) >> 24)
#define SRDERR_F3_LE_WR(src)                  (((unsigned int)(src) << 24) & 0x01000000)
#define SRDERR_F3_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Global Base Address	*/
#define SLAVE_SHIM_CSR_BASE_ADDR			(QM_CSR_BASE_ADDR + 0xE000)

/*    Address SLAVE_SHIM_CSR  Registers */
#define CFG_SLV_RESP_TMO_CNTR_ADDR                                   0x00000004
#define CFG_SLV_RESP_TMO_CNTR_DEFAULT                                0x0000ffff
#define CFG_SLV_READY_TMO_CNTR_ADDR                                  0x00000008
#define CFG_SLV_READY_TMO_CNTR_DEFAULT                               0x0004ffff
#define INT_SLV_TMO_ADDR                                             0x0000000c
#define INT_SLV_TMO_DEFAULT                                          0x00000000
#define INT_SLV_TMOMASK_ADDR                                         0x00000010
#define CFG_AMA_MODE_ADDR                                            0x00000014
#define CFG_AMA_MODE_DEFAULT                                         0x00000000
#define CFG_SLV_CSR_TMO_CNTR_ADDR                                    0x00000018
#define CFG_SLV_CSR_TMO_CNTR_DEFAULT                                 0x0000ffff
#define CFG_MASK_DEV_ERR_RESP_ADDR                                   0x0000001c
#define CFG_MASK_DEV_ERR_RESP_DEFAULT                                0x00000000

/*	Register CFG_SLV_RESP_TMO_CNTR	*/

/*	 Fields CFG_CSR_POISON	 */
#define CFG_CSR_POISON_F1_LE_WIDTH                                            1
#define CFG_CSR_POISON_F1_LE_SHIFT                                           14
#define CFG_CSR_POISON_F1_LE_MASK                                    0x00000200
#define CFG_CSR_POISON_F1_LE_RD(src)                (((src) & 0x00000200) >> 9)
#define CFG_CSR_POISON_F1_LE_WR(src)           (((unsigned int)(src) << 9) & 0x00000200)
#define CFG_CSR_POISON_F1_LE_SET(dst,src)                 ((dst) & ~0x00000200) |  \
				(((unsigned int)(src) << 9) & 0x00000200)

/*	 Fields CSR_ERR_RESP_EN	 */
#define CSR_ERR_RESP_EN_F1_LE_WIDTH                                           1
#define CSR_ERR_RESP_EN_F1_LE_SHIFT                                          15
#define CSR_ERR_RESP_EN_F1_LE_MASK                                   0x00000100
#define CSR_ERR_RESP_EN_F1_LE_RD(src)               (((src) & 0x00000100) >> 8)
#define CSR_ERR_RESP_EN_F1_LE_WR(src)          (((unsigned int)(src) << 8) & 0x00000100)
#define CSR_ERR_RESP_EN_F1_LE_SET(dst,src)                 ((dst) & ~0x00000100) |  \
				(((unsigned int)(src) << 8) & 0x00000100)

/*	 Fields CFG_CSR_RESP_TMO	 */
#define CFG_CSR_RESP_TMO_F1_LE_WIDTH                                         16
#define CFG_CSR_RESP_TMO_F1_LE_SHIFT                                         31
#define CFG_CSR_RESP_TMO_F1_LE_MASK                                  0xffff0000
#define CFG_CSR_RESP_TMO_F1_LE_RD(src)               	(((src) & 0xff000000) >> 24) |\
				(((src) & 0x00ff0000) >> 8)
#define CFG_CSR_RESP_TMO_F1_LE_WR(src)      	(((unsigned int)(src) << 24) & 0xff000000) |\
				(((unsigned int)(src) << 8) & 0x00ff0000)
#define CFG_CSR_RESP_TMO_F1_LE_SET(dst,src) ((dst)&~0xffff0000)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00ff0000)

/*	Register CFG_SLV_READY_TMO_CNTR	*/

/*	 Fields CFG_CSR_READY_TMO	 */
#define CFG_CSR_READY_TMO_F1_LE_WIDTH                                        32
#define CFG_CSR_READY_TMO_F1_LE_SHIFT                                        31
#define CFG_CSR_READY_TMO_F1_LE_MASK                                 0xffffffff
#define CFG_CSR_READY_TMO_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define CFG_CSR_READY_TMO_F1_LE_WR(src)   (((unsigned int)(src) << 24) & 0xff000000) | \
   	(((unsigned int)(src) << 8) & 0x00ff0000) |(((unsigned int)(src) >> 8) & 0x0000ff00) | \
					(((unsigned int)(src) >> 24) & 0x000000ff)
#define CFG_CSR_READY_TMO_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register INT_SLV_TMO	*/

/*	 Fields STS_CSR_TMO	 */
#define STS_CSR_TMO_F1_LE_WIDTH                                               1
#define STS_CSR_TMO_F1_LE_SHIFT                                              27
#define STS_CSR_TMO_F1_LE_MASK                                       0x10000000
#define STS_CSR_TMO_F1_LE_RD(src)                  (((src) & 0x10000000) >> 28)
#define STS_CSR_TMO_F1_LE_WR(src)             (((unsigned int)(src) << 28) & 0x10000000)
#define STS_CSR_TMO_F1_LE_SET(dst,src)                     ((dst)&~0x10000000)|\
				(((unsigned int)(src) << 28) & 0x10000000)

/*	 Fields STS_ARREADY_TMO	 */
#define STS_ARREADY_TMO_F1_LE_WIDTH                                           1
#define STS_ARREADY_TMO_F1_LE_SHIFT                                          28
#define STS_ARREADY_TMO_F1_LE_MASK                                   0x08000000
#define STS_ARREADY_TMO_F1_LE_RD(src)              (((src) & 0x08000000) >> 27)
#define STS_ARREADY_TMO_F1_LE_WR(src)         (((unsigned int)(src) << 27) & 0x08000000)
#define STS_ARREADY_TMO_F1_LE_SET(dst,src)                     ((dst)&~0x08000000)|\
				(((unsigned int)(src) << 27) & 0x08000000)

/*	 Fields STS_RVALID_TMO	 */
#define STS_RVALID_TMO_F1_LE_WIDTH                                            1
#define STS_RVALID_TMO_F1_LE_SHIFT                                           29
#define STS_RVALID_TMO_F1_LE_MASK                                    0x04000000
#define STS_RVALID_TMO_F1_LE_RD(src)               (((src) & 0x04000000) >> 26)
#define STS_RVALID_TMO_F1_LE_WR(src)          (((unsigned int)(src) << 26) & 0x04000000)
#define STS_RVALID_TMO_F1_LE_SET(dst,src)                     ((dst)&~0x04000000)|\
				(((unsigned int)(src) << 26) & 0x04000000)

/*	 Fields STS_AWREADY_TMO	 */
#define STS_AWREADY_TMO_F1_LE_WIDTH                                           1
#define STS_AWREADY_TMO_F1_LE_SHIFT                                          30
#define STS_AWREADY_TMO_F1_LE_MASK                                   0x02000000
#define STS_AWREADY_TMO_F1_LE_RD(src)              (((src) & 0x02000000) >> 25)
#define STS_AWREADY_TMO_F1_LE_WR(src)         (((unsigned int)(src) << 25) & 0x02000000)
#define STS_AWREADY_TMO_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields STS_BVALID_TMO	 */
#define STS_BVALID_TMO_F1_LE_WIDTH                                            1
#define STS_BVALID_TMO_F1_LE_SHIFT                                           31
#define STS_BVALID_TMO_F1_LE_MASK                                    0x01000000
#define STS_BVALID_TMO_F1_LE_RD(src)               (((src) & 0x01000000) >> 24)
#define STS_BVALID_TMO_F1_LE_WR(src)          (((unsigned int)(src) << 24) & 0x01000000)
#define STS_BVALID_TMO_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register INT_SLV_TMOMask	*/

/*Mask Register Fields STS_CSR_TMOMask	 */
#define STS_CSR_TMOMASK_F1_LE_WIDTH                                           1
#define STS_CSR_TMOMASK_F1_LE_SHIFT                                          27
#define STS_CSR_TMOMASK_F1_LE_MASK                                   0x10000000
#define STS_CSR_TMOMASK_F1_LE_RD(src)              (((src) & 0x10000000) >> 28)
#define STS_CSR_TMOMASK_F1_LE_WR(src)         (((unsigned int)(src) << 28) & 0x10000000)
#define STS_CSR_TMOMASK_F1_LE_SET(dst,src)                      ((dst)&~0x10000000)|\
			(((unsigned int)(src) << 28) & 0x10000000)

/*Mask Register Fields STS_ARREADY_TMOMask	 */
#define STS_ARREADY_TMOMASK_F1_LE_WIDTH                                       1
#define STS_ARREADY_TMOMASK_F1_LE_SHIFT                                      28
#define STS_ARREADY_TMOMASK_F1_LE_MASK                               0x08000000
#define STS_ARREADY_TMOMASK_F1_LE_RD(src)          (((src) & 0x08000000) >> 27)
#define STS_ARREADY_TMOMASK_F1_LE_WR(src)     (((unsigned int)(src) << 27) & 0x08000000)
#define STS_ARREADY_TMOMASK_F1_LE_SET(dst,src)                      ((dst)&~0x08000000)|\
			(((unsigned int)(src) << 27) & 0x08000000)

/*Mask Register Fields STS_RVALID_TMOMask	 */
#define STS_RVALID_TMOMASK_F1_LE_WIDTH                                        1
#define STS_RVALID_TMOMASK_F1_LE_SHIFT                                       29
#define STS_RVALID_TMOMASK_F1_LE_MASK                                0x04000000
#define STS_RVALID_TMOMASK_F1_LE_RD(src)           (((src) & 0x04000000) >> 26)
#define STS_RVALID_TMOMASK_F1_LE_WR(src)      (((unsigned int)(src) << 26) & 0x04000000)
#define STS_RVALID_TMOMASK_F1_LE_SET(dst,src)                      ((dst)&~0x04000000)|\
			(((unsigned int)(src) << 26) & 0x04000000)

/*Mask Register Fields STS_AWREADY_TMOMask	 */
#define STS_AWREADY_TMOMASK_F1_LE_WIDTH                                       1
#define STS_AWREADY_TMOMASK_F1_LE_SHIFT                                      30
#define STS_AWREADY_TMOMASK_F1_LE_MASK                               0x02000000
#define STS_AWREADY_TMOMASK_F1_LE_RD(src)          (((src) & 0x02000000) >> 25)
#define STS_AWREADY_TMOMASK_F1_LE_WR(src)     (((unsigned int)(src) << 25) & 0x02000000)
#define STS_AWREADY_TMOMASK_F1_LE_SET(dst,src)                      ((dst)&~0x02000000)|\
			(((unsigned int)(src) << 25) & 0x02000000)

/*Mask Register Fields STS_BVALID_TMOMask	 */
#define STS_BVALID_TMOMASK_F1_LE_WIDTH                                        1
#define STS_BVALID_TMOMASK_F1_LE_SHIFT                                       31
#define STS_BVALID_TMOMASK_F1_LE_MASK                                0x01000000
#define STS_BVALID_TMOMASK_F1_LE_RD(src)           (((src) & 0x01000000) >> 24)
#define STS_BVALID_TMOMASK_F1_LE_WR(src)      (((unsigned int)(src) << 24) & 0x01000000)
#define STS_BVALID_TMOMASK_F1_LE_SET(dst,src)                      ((dst)&~0x01000000)|\
			(((unsigned int)(src) << 24) & 0x01000000)

/*	Register CFG_AMA_MODE	*/

/*	 Fields CFG_RD2WR_EN	 */
#define CFG_RD2WR_EN_F1_LE_WIDTH                                              1
#define CFG_RD2WR_EN_F1_LE_SHIFT                                             30
#define CFG_RD2WR_EN_F1_LE_MASK                                      0x02000000
#define CFG_RD2WR_EN_F1_LE_RD(src)                 (((src) & 0x02000000) >> 25)
#define CFG_RD2WR_EN_F1_LE_WR(src)            (((unsigned int)(src) << 25) & 0x02000000)
#define CFG_RD2WR_EN_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields CFG_AMA_MODE	 */
#define REGSPEC_CFG_AMA_MODE_F1_LE_WIDTH                                      1
#define REGSPEC_CFG_AMA_MODE_F1_LE_SHIFT                                     31
#define REGSPEC_CFG_AMA_MODE_F1_LE_MASK                              0x01000000
#define REGSPEC_CFG_AMA_MODE_F1_LE_RD(src)         (((src) & 0x01000000) >> 24)
#define REGSPEC_CFG_AMA_MODE_F1_LE_WR(src)    (((unsigned int)(src) << 24) & 0x01000000)
#define REGSPEC_CFG_AMA_MODE_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register CFG_SLV_CSR_TMO_CNTR	*/

/*	 Fields CFG_CSR_TMO	 */
#define CFG_CSR_TMO_F1_LE_WIDTH                                              16
#define CFG_CSR_TMO_F1_LE_SHIFT                                              31
#define CFG_CSR_TMO_F1_LE_MASK                                       0xffff0000
#define CFG_CSR_TMO_F1_LE_RD(src)               	(((src) & 0xff000000) >> 24) |\
				(((src) & 0x00ff0000) >> 8)
#define CFG_CSR_TMO_F1_LE_WR(src)      	(((unsigned int)(src) << 24) & 0xff000000) |\
				(((unsigned int)(src) << 8) & 0x00ff0000)
#define CFG_CSR_TMO_F1_LE_SET(dst,src) ((dst)&~0xffff0000)| \
			(((unsigned int)(src) << 24) & 0xff000000) | (((unsigned int)(src) << 8) & 0x00ff0000)

/*	Register CFG_MASK_DEV_ERR_RESP	*/

/*	 Fields MASK_DEV_ERR_RESP	 */
#define MASK_DEV_ERR_RESP_F1_LE_WIDTH                                         1
#define MASK_DEV_ERR_RESP_F1_LE_SHIFT                                        31
#define MASK_DEV_ERR_RESP_F1_LE_MASK                                 0x01000000
#define MASK_DEV_ERR_RESP_F1_LE_RD(src)            (((src) & 0x01000000) >> 24)
#define MASK_DEV_ERR_RESP_F1_LE_WR(src)       (((unsigned int)(src) << 24) & 0x01000000)
#define MASK_DEV_ERR_RESP_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Global Base Address	*/
#define MASTER_SHIM_CSR_BASE_ADDR			0x9703f000

/*    Address MASTER_SHIM_CSR  Registers */
#define CFG_MST_IOB_SEL_ADDR                                         0x00000004
#define CFG_MST_IOB_SEL_DEFAULT                                      0x00000002
#define CFG_VC0_PREFETCH_ADDR                                        0x00000008
#define CFG_VC0_PREFETCH_DEFAULT                                     0x00000004
#define CFG_VC1_PREFETCH_ADDR                                        0x0000000c
#define CFG_VC1_PREFETCH_DEFAULT                                     0x00000004
#define CFG_VC2_PREFETCH_ADDR                                        0x00000010
#define CFG_VC2_PREFETCH_DEFAULT                                     0x00000004
#define VC0_TOKEN_USED_ADDR                                          0x00000014
#define VC0_TOKEN_USED_DEFAULT                                       0x00000000
#define VC1_TOKEN_USED_ADDR                                          0x00000018
#define VC1_TOKEN_USED_DEFAULT                                       0x00000000
#define VC2_TOKEN_USED_ADDR                                          0x0000001c
#define VC2_TOKEN_USED_DEFAULT                                       0x00000000
#define VC0_TOKEN_REQ_ADDR                                           0x00000020
#define VC0_TOKEN_REQ_DEFAULT                                        0x00000000
#define VC1_TOKEN_REQ_ADDR                                           0x00000024
#define VC1_TOKEN_REQ_DEFAULT                                        0x00000000
#define VC2_TOKEN_REQ_ADDR                                           0x00000028
#define VC2_TOKEN_REQ_DEFAULT                                        0x00000000

/*	Register CFG_MST_IOB_SEL	*/

/*	 Fields CFG_VC_BYPASS	 */
#define CFG_VC_BYPASS_F1_LE_WIDTH                                             1
#define CFG_VC_BYPASS_F1_LE_SHIFT                                            30
#define CFG_VC_BYPASS_F1_LE_MASK                                     0x02000000
#define CFG_VC_BYPASS_F1_LE_RD(src)                (((src) & 0x02000000) >> 25)
#define CFG_VC_BYPASS_F1_LE_WR(src)           (((unsigned int)(src) << 25) & 0x02000000)
#define CFG_VC_BYPASS_F1_LE_SET(dst,src)                     ((dst)&~0x02000000)|\
				(((unsigned int)(src) << 25) & 0x02000000)

/*	 Fields CFG_MST_IOB_SEL	 */
#define CFG_MST_IOB_SEL_F1_LE_WIDTH                                           1
#define CFG_MST_IOB_SEL_F1_LE_SHIFT                                          31
#define CFG_MST_IOB_SEL_F1_LE_MASK                                   0x01000000
#define CFG_MST_IOB_SEL_F1_LE_RD(src)              (((src) & 0x01000000) >> 24)
#define CFG_MST_IOB_SEL_F1_LE_WR(src)         (((unsigned int)(src) << 24) & 0x01000000)
#define CFG_MST_IOB_SEL_F1_LE_SET(dst,src)                     ((dst)&~0x01000000)|\
				(((unsigned int)(src) << 24) & 0x01000000)

/*	Register CFG_VC0_PREFETCH	*/

/*	 Fields CFG_VC0_PREFETCH_CNT	 */
#define CFG_VC0_PREFETCH_CNT_F1_LE_WIDTH                                      4
#define CFG_VC0_PREFETCH_CNT_F1_LE_SHIFT                                     31
#define CFG_VC0_PREFETCH_CNT_F1_LE_MASK                              0x0f000000
#define CFG_VC0_PREFETCH_CNT_F1_LE_RD(src)         (((src) & 0x0f000000) >> 24)
#define CFG_VC0_PREFETCH_CNT_F1_LE_WR(src)    (((unsigned int)(src) << 24) & 0x0f000000)
#define CFG_VC0_PREFETCH_CNT_F1_LE_SET(dst,src)                     ((dst)&~0x0f000000)|\
				(((unsigned int)(src) << 24) & 0x0f000000)

/*	Register CFG_VC1_PREFETCH	*/

/*	 Fields CFG_VC1_PREFETCH_CNT	 */
#define CFG_VC1_PREFETCH_CNT_F1_LE_WIDTH                                      4
#define CFG_VC1_PREFETCH_CNT_F1_LE_SHIFT                                     31
#define CFG_VC1_PREFETCH_CNT_F1_LE_MASK                              0x0f000000
#define CFG_VC1_PREFETCH_CNT_F1_LE_RD(src)         (((src) & 0x0f000000) >> 24)
#define CFG_VC1_PREFETCH_CNT_F1_LE_WR(src)    (((unsigned int)(src) << 24) & 0x0f000000)
#define CFG_VC1_PREFETCH_CNT_F1_LE_SET(dst,src)                     ((dst)&~0x0f000000)|\
				(((unsigned int)(src) << 24) & 0x0f000000)

/*	Register CFG_VC2_PREFETCH	*/

/*	 Fields CFG_VC2_PREFETCH_CNT	 */
#define CFG_VC2_PREFETCH_CNT_F1_LE_WIDTH                                      4
#define CFG_VC2_PREFETCH_CNT_F1_LE_SHIFT                                     31
#define CFG_VC2_PREFETCH_CNT_F1_LE_MASK                              0x0f000000
#define CFG_VC2_PREFETCH_CNT_F1_LE_RD(src)         (((src) & 0x0f000000) >> 24)
#define CFG_VC2_PREFETCH_CNT_F1_LE_WR(src)    (((unsigned int)(src) << 24) & 0x0f000000)
#define CFG_VC2_PREFETCH_CNT_F1_LE_SET(dst,src)                     ((dst)&~0x0f000000)|\
				(((unsigned int)(src) << 24) & 0x0f000000)

/*	Register VC0_TOKEN_USED	*/

/*	 Fields VC0_TOKEN_USED	 */
#define VC0_TOKEN_USED_F1_LE_WIDTH                                           32
#define VC0_TOKEN_USED_F1_LE_SHIFT                                           31
#define VC0_TOKEN_USED_F1_LE_MASK                                    0xffffffff
#define VC0_TOKEN_USED_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define VC0_TOKEN_USED_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register VC1_TOKEN_USED	*/

/*	 Fields VC1_TOKEN_USED	 */
#define VC1_TOKEN_USED_F1_LE_WIDTH                                           32
#define VC1_TOKEN_USED_F1_LE_SHIFT                                           31
#define VC1_TOKEN_USED_F1_LE_MASK                                    0xffffffff
#define VC1_TOKEN_USED_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define VC1_TOKEN_USED_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register VC2_TOKEN_USED	*/

/*	 Fields VC2_TOKEN_USED	 */
#define VC2_TOKEN_USED_F1_LE_WIDTH                                           32
#define VC2_TOKEN_USED_F1_LE_SHIFT                                           31
#define VC2_TOKEN_USED_F1_LE_MASK                                    0xffffffff
#define VC2_TOKEN_USED_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define VC2_TOKEN_USED_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register VC0_TOKEN_REQ	*/

/*	 Fields VC0_TOKEN_REQ	 */
#define VC0_TOKEN_REQ_F1_LE_WIDTH                                            32
#define VC0_TOKEN_REQ_F1_LE_SHIFT                                            31
#define VC0_TOKEN_REQ_F1_LE_MASK                                     0xffffffff
#define VC0_TOKEN_REQ_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define VC0_TOKEN_REQ_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register VC1_TOKEN_REQ	*/

/*	 Fields VC1_TOKEN_REQ	 */
#define VC1_TOKEN_REQ_F1_LE_WIDTH                                            32
#define VC1_TOKEN_REQ_F1_LE_SHIFT                                            31
#define VC1_TOKEN_REQ_F1_LE_MASK                                     0xffffffff
#define VC1_TOKEN_REQ_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define VC1_TOKEN_REQ_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)

/*	Register VC2_TOKEN_REQ	*/

/*	 Fields VC2_TOKEN_REQ	 */
#define VC2_TOKEN_REQ_F1_LE_WIDTH                                            32
#define VC2_TOKEN_REQ_F1_LE_SHIFT                                            31
#define VC2_TOKEN_REQ_F1_LE_MASK                                     0xffffffff
#define VC2_TOKEN_REQ_F1_LE_RD(src) 	(((src) & 0xff000000) >> 24) | \
		   (((src) & 0x00ff0000) >> 8) |(((src)& 0x0000ff00) << 8) | \
					(((src) & 0x000000ff) << 24)
#define VC2_TOKEN_REQ_F1_LE_SET(dst,src) 	((dst)&~0xffffffff)| \
   (((unsigned int)(src) << 8) & 0x00ff0000) | (((unsigned int)(src) >> 8) & 0x0000ff00) | \
				 (((unsigned int)(src) >> 24) & 0x000000ff)
	
#endif /* __vSEC_QM_CSR_H__ */
