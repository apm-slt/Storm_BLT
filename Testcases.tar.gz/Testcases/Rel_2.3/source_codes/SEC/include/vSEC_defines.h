/* Author: ldinh@apm.com
*  Company: Applied Micro Circuits Corporation (AMCC)
*
* Define SEC common values used in test cases
*
*/

#ifndef __vSEC_DEFINES_H__
#define __vSEC_DEFINES_H__

/* Print debugging info?  1 for yes, 0 for no */
#if (1)
	#define DEBUG_SEC
#endif

#ifdef DEBUG_SEC
	#define debug_sec(...)		printf(__VA_ARGS__)
#else
	#define debug_sec
#endif


#define STORM_ASIC_VALIDATION

#if(0)
	#define UBOOT_TEST
#else
	#define VBIOS_TEST
#endif


#define QM_BASE_ADDR		0x1B000000
#define QM_CSR_BASE_ADDR	0x1F200000
#define MEM_BASE_ADDR		0x4200000000//0x4004000000 //DIMM 32GB //0x1D000000: for OCM, 0x80000000: for DDR 2GB, 0x100000000: for DDR 8GB
#define OCM_CSR_BASE		0x1F410000
#define SEC_CSR_BASE		0x1F250000

#define FAIL	1
#define PASS	0

#define REGISTER_WIDTH	32

#define RD_ONLY_MASK				0x0
#define SELF_CLEAR_MASK				0x0
#define RW_ALL_BITS_MASK			0xFFFFFFFF

#define RD_MEM8(a) (*(volatile unsigned char *)(a))
#define WR_MEM8(a, d) *(volatile unsigned char *)(a) = (unsigned char)(d)

#define RD_MEM16(a) (*(volatile unsigned short *)(a))
#define WR_MEM16(a, d) *(volatile unsigned short *)(a) = (unsigned short)(d)

#define RD_MEM32(a) (*(volatile unsigned *)(a))
#define WR_MEM32(a, d) *(volatile unsigned *)(a) = (unsigned )(d)
#define RD_MEM64(a) (*(volatile  long long *)(a))
#define WR_MEM64(a, d) *(volatile unsigned long long*)(a) = (unsigned long long)(d)


#endif /* __vSEC_DEFINES_H__ */

