#ifndef __SEC_TESH_H__
#define __SEC_TESH_H__
#include "../include/vSEC_test_driver.h"
#include "../include/vSEC_globals.h"
#include "../include/vSEC_mem_manager.h"

/* Print debugging info?  1 for yes, 0 for no */
#if (1)
	#define DEBUG_SEC_TEST
#endif

#ifdef DEBUG_SEC_TEST
	#define debug_sec_test(...)		printf(__VA_ARGS__)
#else
	#define debug_sec_test
#endif

typedef struct {
  unsigned char associate_crypto_core; //0: EIP96/EIP62, 1: XTS
  unsigned char num_of_buf;
} sec_buf_num_header;

typedef struct {
  sec_buf_num_header* buf_num_header_ptr;
  unsigned int queue_tail;
  unsigned int queue_head;
  unsigned int no_of_entry;
} sec_buf_num_header_queue;



int chk_result(buf_header_queue *expt_buf_queue_ptr, buf_header_queue *expt_tkn_queue_ptr, 
               buf_header_queue *expt_deallot_queue_ptr, buf_header_queue *expt_cm_queue_ptr,
               int qid, short chk_mode);
void write_buf_num_header(sec_buf_num_header_queue* queue_ptr, unsigned char core_type, unsigned char num_of_buf);
void load_sec_in_ctx_tkn(mem_array_header_queue* ctx_array_header_queue_ptr,
                         mem_array_header_queue* in_tkn_array_header_queue_ptr,
                         sec_buf_num_header_queue* in_buf_num_queue_ptr,
                         unsigned long long* tkn_mem_addr_ptr, unsigned char ctx_reuse_md,unsigned short in_tkn_offset);
void  load_sec_in_data(mem_array_header_queue* in_data_array_header_queue_ptr, queue_mem_manager* in_data_mem_manager_ptr,
						unsigned long long* in_data_addr_ptr, unsigned short* in_data_len_ptr, MEM_ALIGN_CODE align_code);
void load_sec_exp_tkn(mem_array_header_queue* exp_tkn_array_header_queue_ptr, queue_mem_manager* exp_tkn_mem_manager_ptr,
						buf_header_queue *expt_tkn_buf_queue_ptr, MEM_ALIGN_CODE align_code);
void load_sec_exp_data(mem_array_header_queue* exp_data_array_header_queue_ptr, queue_mem_manager* exp_data_mem_manager_ptr,
						buf_header_queue *expt_data_buf_queue_ptr, MEM_ALIGN_CODE align_code);

#endif /*__SEC_TESH_H__*/
