// This file specify SEC address map
#ifndef __SEC_ADDR_MAP_H__
#define __SEC_ADDR_MAP_H__

#include "../include/sm_sec_rsps.h"

// Memory array depth
#define SEC_CTX_MAX_LEN            0x100

#if (0) //////////////////////For OCM test: build type: nor_add_up --> just working for some tests not too much data
	#define SEC_WQ_MSG_SLL_OFST		0x10000
	#define SEC_WQ_MSG_DLL_OFST		0x14000
	#define SEC_CM_MSG_DLL_OFST		0x18000

	#define SEC_TEST_OFST          	0x30000

	#define SEC_TKN_OFST           	0x00000
	#define SEC_TKN_MEM_LEN         0x20000

	#define SEC_EXP_RTKN_OFST      	0x20000
	#define SEC_EXP_RTKN_MEM_LEN   	0x20000

	#define SEC_CTX_OFST           	0x40000
	#define SEC_CTX_MEM_LEN         0x20000

	#define SEC_DAT_IN_OFST        	0x60000
	#define SEC_DAT_IN_MEM_LEN      0x20000

	#define SEC_DAT_OUT_OFST       	0x80000
	#define SEC_DAT_OUT_MEM_LEN     0x20000

	#define SEC_EXP_DAT_OUT_OFST   	0xA0000
	#define SEC_EXP_DAT_OUT_MEM_LEN 0x20000

#else //////////////////////For DDR test////////////////////////////////////////////
	#define SEC_WQ_MSG_SLL_OFST		0x10000
	#define SEC_WQ_MSG_DLL_OFST		0x14000
	#define SEC_CM_MSG_DLL_OFST		0x18000

	#define SEC_TEST_OFST          	0x100000

	#define SEC_TKN_OFST           	0x00000
	#define SEC_TKN_MEM_LEN         0x20000

	#define SEC_EXP_RTKN_OFST      	0x20000
	#define SEC_EXP_RTKN_MEM_LEN   	0x20000

	#define SEC_CTX_OFST           	0x40000
	#define SEC_CTX_MEM_LEN         0x40000

	//#ifdef STORM_ASIC_VALIDATION //For now, SOC env. also used OCM to store code so need to reduce memory for SEC cooperation
	#define SEC_DAT_IN_OFST        	0x100000
	#define SEC_DAT_IN_MEM_LEN      0x180000

	#define SEC_DAT_OUT_OFST       	0x280000
	#define SEC_DAT_OUT_MEM_LEN     0x180000

	#define SEC_EXP_DAT_OUT_OFST   	0x400000
	#define SEC_EXP_DAT_OUT_MEM_LEN 0x180000
#endif
///////////////////////////////////////////////////////////////////////////////

// DIAG
#define SM_SEC_DIAG_SEL_8_6__DEV_ID				0x0
#define SM_SEC_DIAG_SEL_8_6__QMI_EIP96_CRYPTO	0x1
#define SM_SEC_DIAG_SEL_8_6__QMI_XTS_CRYPTO		0x2
#define SM_SEC_DIAG_SEL_8_6__QMI_EIP62_CRYPTO	0x3
#define SM_SEC_DIAG_SEL_8_6__EIP96				0x4
#define SM_SEC_DIAG_SEL_8_6__XTS				0x5
#define SM_SEC_DIAG_SEL_8_6__EIP62				0x6

#define SM_SEC_DIAG_SEL_5_0__EIP62_WDATA_CTL	0x20
#define SM_SEC_DIAG_SEL_5_0__EIP62_WDATA_LEN	0x21
#define SM_SEC_DIAG_SEL_5_0__EIP62_RDATA		0x22
#define SM_SEC_DIAG_SEL_5_0__EIP62_RWCTX_CTL	0x23
#define SM_SEC_DIAG_SEL_5_0__EIP62_RWCTX_LEN	0x24
#define SM_SEC_DIAG_SEL_5_0__EIP62_RTKN			0x25
#define SM_SEC_DIAG_SEL_5_0__EIP62_WTKN			0x26
#define SM_SEC_DIAG_SEL_5_0__EIP62_FIFO_STS		0x27

#define SM_SEC_DIAG_SEL_5_0__AXI_WRITE_0        0x0
#define SM_SEC_DIAG_SEL_5_0__AXI_WRITE_1        0x1
#define SM_SEC_DIAG_SEL_5_0__AXI_WRITE_2        0x2
#define SM_SEC_DIAG_SEL_5_0__AXI_WRITE_3        0x3
#define SM_SEC_DIAG_SEL_5_0__AXI_READ_0         0x4
#define SM_SEC_DIAG_SEL_5_0__AXI_READ_1         0x5
#define SM_SEC_DIAG_SEL_5_0__AXI_READ_WRITE_0   0x6
#define SM_SEC_DIAG_SEL_5_0__AXI_READ_WRITE_1   0x7
#define SM_SEC_DIAG_SEL_5_0__AXI_RD_TKN         0x08
#define SM_SEC_DIAG_SEL_5_0__AXI_RD_WR_CTX      0x09
#define SM_SEC_DIAG_SEL_5_0__AXI_RD_DATA        0x0A
#define SM_SEC_DIAG_SEL_5_0__AXI_WR_TKN         0x0B
#define SM_SEC_DIAG_SEL_5_0__AXI_WR_DATA_0      0x0C
#define SM_SEC_DIAG_SEL_5_0__AXI_WR_DATA_1      0x0D
#define SM_SEC_DIAG_SEL_5_0__AXI_WR_DATA_2      0x0E
#define SM_SEC_DIAG_SEL_5_0__AXI_FIFO_STS_0     0x0F
#define SM_SEC_DIAG_SEL_5_0__AXI_FIFO_STS_1     0x10
#define SM_SEC_DIAG_SEL_5_0__AXI_RD_MSG         0x11

#endif /* __SEC_ADDR_MAP_H__ */
