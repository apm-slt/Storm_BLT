/*
 * common.h
 *
 *  Created on: May 29, 2014
 *      Author: ldinh
 */

#ifndef __COMMON_H__
#define __COMMON_H__

void printPASS(void);
void printFAIL(void);

#endif /*__COMMON_H__*/

