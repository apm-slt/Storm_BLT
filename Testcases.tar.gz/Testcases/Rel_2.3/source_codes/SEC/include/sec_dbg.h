// This file content several SEC debug functions

#ifndef __SEC_DBG_H__
#define __SEC_DBG_H__

#include "../include/vSEC_globals.h"
#include "../include/vSEC_defines.h"
#include "../include/vSEC_regs.h"
#include "../include/sec_addr_map.h"

/* Print debugging info?  1 for yes, 0 for no */
#if (1)
	#define DEBUG_SEC_DBG
#endif

#ifdef DEBUG_SEC_DBG
	#define debug_sec_dbg(...)		printf(__VA_ARGS__)
#else
	#define debug_sec_dbg
#endif

// This function is to start DIAGMOD of SEC
void start_sec_axi_mon(void);

// This function is to stop DIAGMOD
void stop_sec_axi_mon(void);

// This function is to dump out AXI bandwidth information recorded by DIAG
void dump_sec_axi_bw(void);

// This function is to configure DIAGMOD of SEC
// It's used to specify which SEC debug signals to be observed
void config_sec_diag(unsigned int sel_12_11, unsigned int sel_8_6, unsigned int sel_5_0,
                            unsigned int upper_lower_sel);

// This function is to dump out debug registers of DIAGMOD of SEC
void dump_sec_dbg(unsigned int sel_12_11, unsigned int sel_8_6, unsigned int sel_5_0);

// This function is to dump out EIP96 core register
void dump_sec_eip96_core_csr(void);

void dump_sec_xts_core_csr(void);

#endif /* __SEC_DBG_H__ */
