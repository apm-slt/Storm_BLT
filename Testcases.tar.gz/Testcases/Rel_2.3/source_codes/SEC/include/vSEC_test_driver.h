
#ifndef __vSEC_TEST_DRIVER_H__
#define __vSEC_TEST_DRIVER_H__

/* Print debugging info?  1 for yes, 0 for no */
#if (1)
	#define DEBUG_vSEC_TEST_DRIVER
#endif

#ifdef DEBUG_vSEC_TEST_DRIVER
	#define debug_vsec_test_drv(...)		printf(__VA_ARGS__)
#else
	#define debug_vsec_test_drv
#endif


typedef struct
{
	int msg_type;
	int qid;
	int num_of_buf;
} enq_msg_header;

typedef struct
{
	enq_msg_header *enq_msg_header_ptr;
	int queue_tail;
	int queue_head;
	int no_of_entry;
} enq_msg_header_queue;

typedef int header_8b_array[2];

typedef struct
{
	unsigned long long BufDataAddr:42;
	char Reserved0:6;
	int  BufDataLength:15;
	char Reserved1:1;
} buf_header_field;

typedef union
{
	header_8b_array raw;
	buf_header_field field;
} buf_header;

typedef struct
{
	buf_header *buf_header_ptr;
	int   queue_tail; // For writing
	int   queue_head; // For reading
	int   no_of_entry;
} buf_header_queue; 

// This function is to initialized queue pointer
void init_queue_ptr(void);

// This function is to read out 1 entry in enqueue message header queue
enq_msg_header* read_enq_msg_header(enq_msg_header_queue* enq_msg_header_queue_ptr, int max_ptr);

// This function is to write 1 entry into enqueue message header queue
void write_enq_msg_header(enq_msg_header_queue* enq_msg_header_queue_ptr, enq_msg_header write_msg_header,  int max_ptr);

// This function is to print out the content of an enqueue message header queue
void print_enq_msg_header(enq_msg_header_queue* enq_msg_header_queue_ptr);

// This function is to read a buffer header queue
buf_header* read_buf_header(buf_header_queue* buf_header_queue_ptr, int max_ptr);

// This function is to write 1 entry into buffer header queue
void write_buf_header(buf_header_queue* buf_header_queue_ptr, buf_header write_buf_header, int max_ptr);

#endif /*__vSEC_TEST_DRIVER_H__ */


