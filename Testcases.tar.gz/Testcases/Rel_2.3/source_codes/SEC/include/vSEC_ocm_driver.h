#ifndef __vSEC_OCM_DRIVER_H__
#define __vSEC_OCM_DRIVER_H__

#include "../include/vSEC_defines.h"

/* Print debugging info?  1 for yes, 0 for no */
#if (0)
	#define DEBUG_vSEC_OCM_DRIVER
#endif

#ifdef DEBUG_vSEC_OCM_DRIVER
	#define debug_vsec_ocm_drv(...)		printf(__VA_ARGS__)
#else
	#define debug_vsec_ocm_drv
#endif

#define CRCSR_OCM_CLKEN_REG	(OCM_CSR_BASE + 0xC004) //OCM Clock Enable Register
#define OCM_CLKEN_BIT		(1<<1)
#define OCM_CSR_CLKEN_BIT	(1<<0)

#define CRCSR_OCM_SRST_REG	(OCM_CSR_BASE + 0xC000) //OCM Reset Register
#define OCM_RESET_BIT		(1<<1)
#define OCM_CSR_RESET_BIT	(1<<0)


void init_ocm(void);

#endif /* __vSEC_OCM_DRIVER_H__ */
