/* Author: ldinh@apm.com
*  Company: Applied Micro Circuits Corporation (AMCC)
*
* Define SEC common functions used in test cases
*
*/

#ifndef __vSEC_MACROS_H__
#define __vSEC_MACROS_H__


#endif /* __vSEC_MACROS_H__ */

