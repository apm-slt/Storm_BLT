#ifndef __SEC_DAT_STRUCT_H__
#define __SEC_DAT_STRUCT_H__

typedef struct
{
	int   in_pkt_len:17;
	int   rsvd0:1;
	int   ct:2;
	int   rc:2;
	int   too:3;
	int   c:1;
	int   iv:3;
	int   u:1;
	int   rsvd1:2;

	int   tkn_len:14;
	int   rsvd2:1;
	int   num_of_ctx_updt:4;
	int   rsvd3:13;

	int   ctx_ptr_MSBs:6;
	int   rsvd4:26;

	int   ctx_ptr_LSBs:32;
} eip96_tkn_ctl_field;

typedef int eip96_tkn_ctl_raw[4];

typedef union
{
	eip96_tkn_ctl_raw raw;
	eip96_tkn_ctl_field field;
} eip96_tkn_ctl;

typedef struct
{
	int top:4;
	int pkt_based_opt:4;
	int ctx_len:8;
	int key:1;
	int crypto_algo:3;
	int rsvd0:1;
	int digest_type:2;
	int hash_algo:3;
	int rsvd1:1;
	int spi:1;
	int seq:2;
	int mask0:1;
	int mask1:1;

	int crypto_mode:5;
	int iv0:1;
	int iv1:1;
	int iv2:1;
	int iv3:1;
	int digest_cnt:1;
	int iv_format:2;
	int crypto_store:1;
	int rsvd2:1;
	int pad_type:3;
	int enc_hash_rslt:1;
	int kasumi_f9_dir:1;
	int hash_store:1;
	int i_j_pntr:1;
	int state_sel:1;
	int seq_nbr_store:1;
	int dis_mask_updt:1;
	int rsvd3:7;
	int addr_mode:1;
} eip96_ctx_ctl_field;

typedef int eip96_ctx_ctl_raw[2];
typedef union
{
	eip96_ctx_ctl_raw raw;
	eip96_ctx_ctl_field field;
} eip96_ctx_ctl;


typedef struct
{
	eip96_tkn_ctl tkn_ctl;
	eip96_ctx_ctl ctx_ctl;
	int* iv_ptr;
	int  chk_sum;
	int* instr_ptr;
	int* bypass_dat_ptr;
} eip96_tkn;

typedef struct
{
	int rslt_pkt_len:17;
	char  e0:1;
	char  e1:1;
	char  e2:1;
	char  e3:1;
	char  e4:1;
	char  e5:1;
	char  e6:1;
	char  e7:1;
	char  e8:1;
	char  e9:1;
	char  e10:1;
	char  e11:1;
	char  e12:1;
	char  e13:1;
	char  e14:1;
	short bypass_dat:4;
	char  e15:1;
	short num_of_deallot_buf:9;
	char  rsvd0:7;
	char  h:1;
	short hash_byte:6;
	char  b:1;
	char  c:1;
	char  n:1;
	char  l:1;
	short nxt_header_field:8;
	short pad_len:8;
	short rsvd1:16;
} eip96_rslt_tkn_field;

typedef int eip96_rslt_tkn_raw[4];

typedef union
{
	eip96_rslt_tkn_raw raw;
	eip96_rslt_tkn_field field;
} eip96_rslt_tkn_fixed;

typedef struct
{
	eip96_rslt_tkn_fixed rslt_tkn_f;
	int* bypass_dat_ptr;
} eip96_rslt_tkn;

void load_eip96_tkn(unsigned long long tkn_base_addr,  eip96_tkn* eip96_tkn_ptr);
void load_eip96_rslt_tkn(unsigned long long tkn_base_addr,  eip96_rslt_tkn* eip96_rslt_tkn_ptr);
void printf_eip96_tkn(eip96_tkn* eip96_tkn_ptr);
void printf_eip96_rslt_tkn(eip96_rslt_tkn* eip96_rslt_tkn_ptr);

#endif /* __SEC_DAT_STRUCT_H__ */
