#ifndef __vSEC_QM_DRIVER_H__
#define __vSEC_QM_DRIVER_H__

#include "../include/vSEC_globals.h"
#include "../include/vSEC_defines.h"

#include "../include/vSEC_qm_csr.h"
#include "../include/vSEC_msg_format.h"

/* Print debugging info?  1 for yes, 0 for no */
#if (1)
	#define DEBUG_vSEC_QM_DRIVER
#endif

#ifdef DEBUG_vSEC_QM_DRIVER
	#define debug_vsec_qm_drv(...)		printf(__VA_ARGS__)
#else
	#define debug_vsec_qm_drv
#endif

#define Q_START_ADDR      MEM_BASE_ADDR
#define RAID6_MULT        0x10000000
#define BUFPTRS_START_ADDR  (Q_START_ADDR+(MAX_NO_OF_QUEUE*MAX_QUEUE_SIZE))   

#define QM_MAX_MBOX       256

typedef enum
{
	ERR_NONE,
	ERR_MSG_SZ,
	ERR_LEI,
	ERR_ENQ_VQ,
	ERR_ENQ_DIS_Q,
	ERR_Q_OF,
	ERR_ENQ,
	ERR_DEQ,
	//	ERR_DOM=0x9,
	ERR_CODE_MAX = 16,
} err_code_t;

typedef struct
{
	int err:3;
	int rsvd1:5;
	int cmd_acr_enq_err:2;
	int rsvd2:12;
	int cmd_acr_enq_qid:10;
} ui_err6_t;

typedef struct
{
	int err:3;
	int rsvd1:11;
	int deq_slvid_pbn:10;
	int deq_slot_num:8;
} ui_err7_t;

typedef enum
{
	SM_QM_MSG_SZ_NA,
	SM_QM_MSG_SZ_16B = 1,
	SM_QM_MSG_SZ_32B,
	SM_QM_MSG_SZ_64B,
} msg_sz_t;

typedef enum
{
	QSIZE_512B,
	QSIZE_2KB,
	QSIZE_16KB,
	QSIZE_64KB,
	QSIZE_512KB,
} q_size_t;

typedef enum  {
	QM_DEFAULT    = 31,
	QM_ENET_0     = 0,
	QM_ENET_1     = 1,
	QM_ENET_2     = 2,
	QM_DMA        = 3,
	QM_CTM_0      = 4,
	QM_SEC        = 5,
	QM_CLE        = 6,
	QM_COP_0      = 7,
	QM_SLIM_PRO   = 14,
	QM_PROC       = 15,
	QM_XGENET_0   = 16,
	QM_XGENET_1   = 17,
	QM_XGENET_2   = 18,
	QM_XGENET_3   = 19
} qm_SlaveID_e;

typedef enum
{
	WQPBID0 = 0,
	WQPBID1 = 1,
	WQPBID2 = 2,
	WQPBID3 = 3,
	WQPBID4 = 4,
	WQPBID5 = 5,
	WQPBID6 = 6,
	WQPBID7 = 7,

	FPQPBID0 = 32,
	FPQPBID1 = 33,
	FPQPBID2 = 34,
	FPQPBID3 = 35,
	FPQPBID4 = 36,
	FPQPBID5 = 37,
	FPQPBID6 = 38,
	FPQPBID7 = 39,
} qm_pbid_assign_t;

typedef enum
{
	SID_MENET   = 0, //Management
	SID_DMA     = 3,
	SID_SEC     = 5,
	SID_COP     = 7,
	SID_SLIMPRO = 14,
	SID_PROC    = 15,
	SID_MAX,
} qm_sid_assign_t;

typedef enum
{
	WQID0,  //PROC
	WQID1,  //DMA
	WQID2,
	WQID3,
	WQID4,
	WQID5,  //SEC
	WQID6,

	FPQID0,  //PROC
	FPQID1,  //DMA
	FPQID2,
	FPQID3,
	FPQID4,
	FPQID5,
	FPQID6,
	FPQID7,
	FPQID8,
	FPQID9,  //SEC
	FPQID10,
	FPQID11,
	FPQID12,
	FPQID13,
	FPQID14,
	FPQID15,
	FPQID16,

	QID_MAX=1024,
} qm_qid_assign_t;

typedef enum
{
	QM_THR_0,
	QM_THR_1,
	QM_THR_2,
	QM_THR_3,
	QM_THR_4,
	QM_THR_5,
	QM_THR_6,
	QM_THR_7,
} thr_idx_t;

typedef enum
{
	QM_Q_DISABLED,
	QM_PQ,
	QM_FPQ,
	QM_VQ,
	QM_Q_TYPE_MAX,
} qm_q_type_t;

#define IS_QM_BDL_16KB(x) {(x & 0x4000) ? 0 : 1;}

typedef enum
{
	QM_BDL_256B = 0x100,
	QM_BDL_1KB = 0x400,
	QM_BDL_2KB = 0x800,
	QM_BDL_4KB = 0x1000,
	QM_BDL_16KB = 0x4000,
} qm_bdl_t;

typedef enum
{
	QM_RID_EMPTY=0,
	QM_RID_ALMOST_EMPTY,
	QM_RID_ALMOST_FULL,
	QM_RID_FULL,
	QM_RID_MAX,
} qm_rid_t;

typedef enum
{
	QM_CRID_ALMOST,
	QM_CRID_F_OR_E,
	QM_CRID_MAX,
} qm_crid_t;

typedef enum
{
	QM_FP_NOMOD,
	QM_FP_SZ2BOUNDARY,
	QM_FP_SAFIX_DS2BS,
	QM_FP_DS2BS,
	QM_FP_MODE_MAX,
} qm_fp_mode_t;

typedef enum
{
	QM_PROC_NOTNO,
	QM_PROC_NOTPROC0,
	QM_PROC_NOTPROC1,
	QM_PROC_NOTBOTH,
	QM_PROC_NOTENET,
	QM_PROC_NOT_MAX,
} qm_proc_not_t;

typedef enum
{
	DEQ_WQ,
	DEQ_FP,
	DEQ_MAX,
} deq_type_t;

typedef struct
{
	char wq;
	char fq;
} pbn_t;

typedef struct
{
	int sid:	4;
	int pbn:	6;
	int rsvd:	2;
} pb_addr_t;

typedef struct
{
	int mn	:9;
	int qid	:10;
	int tlvq	:1;
	int is_fp	:1;
	int pb_en	:1;
	int slot	:8;
	int pb_busy	:1;
	int pb_size	:1;	/* This bit controls the prefetch buffer size. 1 = 8 slots, 0 = 4 slots deep. The default is 4 slots. */
} pb_data_field_t;

typedef union 
{
	int data;
	pb_data_field_t pb_data;
} pb_data_t;

typedef struct
{
	thr_idx_t	idx;
	int			thr0;
	int			thr1;
	char		hyst;
} thr_cfg_t;

typedef struct
{
	char prt;
	char ue;
	short err_cnt[ERR_CODE_MAX]; // entry 0 is for mismatched ELerr and queue
	int ui[ERR_CODE_MAX];
	char lei[ERR_CODE_MAX];
	char he0[ERR_CODE_MAX];
	char he1[ERR_CODE_MAX];
} err_info_t;

typedef struct
{
	int	ue_eq_en:1;
	int rsvd1:5;
	int	ue_eq_id:10;
	int	e_eq_en:1;
	int rsvd2:5;
	int	e_eq_id:10;
} errq_reg_t;

typedef struct
{
	char	ue_eq_en;
	char	ue_eq_id;
	char	e_eq_en;
	char	e_eq_id;
} errq_cfg_t;

typedef struct
{
	/* word 4 */
	int q_type			:2;
	int half64B_pushed	:1;
	int tm_override_cnt	:4;
	int tm_override_max	:3;
	int rsvd0			:4;
	int supress_cmpl 	:1;
	int th_grp			:3;
	int recomb_timeout	:7;

	/* word 3 */
	int recomb_en	:1;
	int q_lock		:1; 	/* RO */
	q_size_t q_size	:3; 	/* 0: 512B; 1: 2KB; 2: 16KB; 3: 64KB; 4: 512KB */
	int fp_mode		:3; 	/* 0: no mod;
			   1: round the start address down to the buffer boundary and reduce the BufDataLen accordingly; 
			   2: reduce the BufDataLen to the buffer size; 
			   3: ??? */
	int lerr_ok		:1; 	/* 0: send lerr msg to error q; 1: treat lerr msg as normal */
	int rsvd1		:1;
	int stashing	:1;
	int slot_pd     :8;	    /* Enqueue message slots pending. Software must initialize this field to 8'b0. Afterwards, the QM uses these bits to keep track of enqueued messages which have not yet received a write response.  */
	int vcid		:2;

	/* word 2 */
	unsigned long long st_addr     :34;
	int q_c 	:1;     /* Set this bit to instruct the QM to move messages to and from the queue using the coherent access attribute. */
	int rid		:3;
	int crid	:1;

	/* word 1 */
	int hd_ptr	:15;
	int n_msg	:16;
	int qne		:1;

	/* word 0 */
	int proc_sab	:8; 	/* 0: no notification; 1: notify proc0; 2: notify proc1; 255: notify all */
	int sab_en		:1;
	int tmvq		:10;
	int tmvq_en		:1;
	int rs_done		:1;		/* The QM sets this bit to 1 when the queue resize operation is complete. */
	int rs_st		:1;		/* Software sets this bit to 1 to enable an automatic queue resize operation. */
	int rs_q		:10;		/* Software selects the temporary QID to be used during queue resizing. */
} pq_fp_state_t;

static pq_fp_state_t q_state[MAX_NO_OF_QUEUE];

typedef struct
{
	int q_type	:2;
	int th_grp	:3;
	int q0		:10;
	int q0_req	:1;		/* RO */
	int q0_tx	:1;		/* RO */
	int q0_arb	:2;		/* 0: not enabled for deq; 1: strick priority; 2: WRR; 3: AVB */
	int q1		:10;
	int q1_req	:1;		/* RO */
	int q1_tx	:1;		/* RO */
	int q1_arb	:2;		/* 0: not enabled for deq; 1: strick priority; 2: WRR; 3: AVB */
	int q2	    :10;
	int q2_req	:1;		/* RO */
	int q2_tx	:1;		/* RO */
	int q2_arb	:2;		/* 0: not enabled for deq; 1: strick priority; 2: WRR; 3: AVB */
	int q3		:10;
	int q3_req	:1;		/* RO */
	int q3_tx	:1;		/* RO */
	int q3_arb	:2;		/* 0: not enabled for deq; 1: strick priority; 2: WRR; 3: AVB */
	int q4		:10;
	int q4_req	:1;		/* RO */
	int q4_tx	:1;		/* RO */
	int q4_arb  :2;		/* 0: not enabled for deq; 1: strick priority; 2: WRR; 3: AVB */
	int q5		:10;
	int q5_req	:1;		/* RO */
	int q5_tx	:1;		/* RO */
	int q5_arb	:2;		/* 0: not enabled for deq; 1: strick priority; 2: WRR; 3: AVB */
	int q6		:10;
	int q6_req	:1;		/* RO */
	int q6_tx	:1;		/* RO */
	int q6_arb	:2;		/* 0: not enabled for deq; 1: strick priority; 2: WRR; 3: AVB */
	int q7	    :10;
	int q7_req	:1;		/* RO */
	int q7_tx	:1;		/* RO */
	int q7_arb	:2;		/* 0: not enabled for deq; 1: strick priority; 2: WRR; 3: AVB */
	int rid		:3;
	int proc_sab:8; 	/* 0: no notification; 1: notify proc0; 2: notify proc1; 3: notify both */
	int crid	:1;
	int qne		:1;
	int sab_en	:1;
	int n_msg	:18;
} vq_state_t;

typedef union
{
	int				state[5];
	pq_fp_state_t	pqfp;
	vq_state_t		vq;
} q_state_t;
	
typedef struct
{
	short		q_num;
	char		q_inc; // For FPPQ, it should be 0. For VQ, it should be the PQ increment is used.
	// Otherwise, it should be set to any number other than 0i for VQs.
	// For VQs, if q_num is 1, then this field is ignored.
	short		qid_base;
	q_state_t	q_cfg;
} q_cfg_t;

typedef struct
{
	int	rsvd		:21;
	int	ic_h		:11;
	int	ic_l		:10;
	int	cc			:22;
} cc_state_drr_t;

typedef struct
{
	int	rsvd1		:18;
	int	cis_h		:14;
	int	cis_l		:4;
	int	cc			:28;
} cc_state_avb_t;

typedef struct
{
	int	rsvd1		:17;
	int	vq_avb_oh	:7;
	int	q0_add_oh	:1;
	int	q0_hc		:4;
	int	q1_add_oh	:1;
	int	q1_hc_m		:2;
	int	q1_hc_l		:2;
	int	q2_add_oh	:1;
	int	q2_hc		:4;
	int	q3_add_oh	:1;
	int	q3_hc		:4;
	int	q4_add_oh	:1;
	int	q4_hc		:4;
	int	q5_add_oh	:1;
	int	q5_hc		:4;
	int	q6_add_oh	:1;
	int	q6_hc		:4;
	int	q7_add_oh	:1;
	int	q7_hc		:4;
} cc_state_vq_t;

typedef union
{
	int				state[2];
	cc_state_drr_t	drr;
	cc_state_avb_t	avb;
	cc_state_vq_t	vq;
} c_state_t;

typedef struct
{
	short		q_num;
	short	    qid_base;
	c_state_t	c_cfg;
} c_cfg_t;

typedef struct
{
	short			qid;
	char			mbox_idx;
	int				msg_num;
	msg_sz_t	    msg_size;
	char	 		*msgs;
} enq_req_t;


typedef struct
{
	char rt;
	int ui;
	int pl;
	int da;
	short fpqn;
	char hl;
	short qid;
	int mn;
	msg_sz_t ms;
	qm_proc_not_t not;
} enq_cfg_t;

typedef struct
{
	char	num_mbox[2];
	char	curr_mbox[2];
	char	curr_slot[2];
	int	mbox[4][QM_MAX_MBOX];
} enq_mbox_t;

typedef struct
{
	char  coherent[4];
	int base[4];
	char  num_mbox[4];

	int *pmbox;
} enq_mbox_cfg_t;

typedef struct
{
	char	enabled;
	char	curr_slot;
	short	qid;
	int	base;
} deq_mbox_t;

typedef struct
{
	char  mid;
	short  qid;
	char  vq;
} deq_mbox_cfg_t;

typedef struct
{
	short qid;
	char resp;
} msgrd_t;

typedef struct
{
	char sid;
	char pbnum;
} pbm_err_t;

typedef struct
{
	char csr;
	char qp_acr_err;
	char deq_axi_err;
	char pbm_dec_err;
	int sab_proc;
	//	int sab_proc1;
	int qne;
	int mem_err;
	int sab_proc_n[8];
	msgrd_t   msgrd;
	pbm_err_t pbm_err;
} qm_int_t;

/* FP config structure for sm_qm_fp_cfg */
typedef struct
{
	unsigned long long      pool_base;
	qm_bdl_t buf_sz;
	char  rtype;
	q_cfg_t  q_cfg;
} fp_cfg_t;

/* main QM config structure for sm_qm_init */
typedef struct
{
	errq_cfg_t      *errq_cfg;
	int             mbox_base;
	int             fp_deq_mbox_base;
	char		    thr_num;
	thr_cfg_t       *p_thr;
	char		    qgrp_num;
	q_cfg_t         *p_q;
	char		    c_num;
	c_cfg_t         *p_c;
	char            *p_qml_remap_q;
	qm_int_t	    *p_int_mask;
	enq_mbox_cfg_t  *p_enq_mbox;	// enq_mbox_cfg;
	char            deq_mbox_num;
	deq_mbox_cfg_t  *p_deq_mbox;	// deq_mbox_cfg[QM_MAX_MBOX];
	short		    fp_num;
	deq_mbox_cfg_t  *p_fp_deq_mbox; // fp_deq_mbox_cfg[QM_MAX_MBOX];
	fp_cfg_t        *p_fp;
	int		        *cu_tmr;
} qm_cfg_t;

typedef struct
{
	char *msg;  /* Pointer to actual native mode message */
	int qid;    /* QID from which the message was received */
	msg_sz_t ms;   /* Size of message */
} sm_qm_msg_arg_t;

/** qm msg rx registration function pointer */
typedef void (*qm_msg_fn_ptr)(sm_qm_msg_arg_t *fn_arg);

/** qm status rx registration function pointer */
typedef void (*qm_q_state_fn_ptr) (short, int);

#define MAX_BUF_NUM_TO_FREE 16

typedef struct
{
	short  fpqid;
	char  rtype;
	int bn;
	int *bp;
	int buf[MAX_BUF_NUM_TO_FREE];
	int bs;
} qm_buf_t;

#define QM_MC_DRR_MASK 0x1fffff
#define QM_MC_AVB_MASK 0x3ffff
#define QM_MC_U_MASK 0x7fffff
#define QM_MC_L_MASK 0xffffff

typedef enum
{
	QM_MOD_CSTATE_DRR=0,
	QM_MOD_CSTATE_AVB,
	QM_MOD_CSTATE_U,
	QM_MOD_CSTATE_L,
} qm_cmd_mc_t;

typedef enum
{
	QM_ENQ_REQ=0x0,
	QM_MOD_CSTATE=0x1c,
	QM_MOD_VQ=0x20,
	QM_Q_RESIZE=0x24,
	QM_MOD_SAB=0x28,
	QM_ALT_REQ=0x2c,
	QM_DEQ_REQ=0x3c,
} qm_cmd_t;

typedef struct
{
	int sc		:2;
	int scd		:30;
} qm_cmd_mod_sc_data_t;

typedef struct
{
	int rsvd		:15;
	int NodeID		:3;
	int QxSel		:10;
	int QxReqVld	:1;
	int QxTxAllowd	:1;
	int QxSelArb	:2;
} qm_cmd_mod_vq_data_t;

typedef struct
{
	int rsvd			:24;
	int CfgSelThresh	:3;
	int CfgPROCSab		:2;
	int CfgCRID			:1;
	int CfgNotifyQNE	:1;
	int CfgSabEn		:1;
} qm_cmd_mod_sab_data_t;

typedef struct
{
	int	rsvd		:19;
	int send_RID	:3;
	int resize_done	:1;
	int resize_start:1;
	int resize_qid	:10;
} qm_cmd_q_resize_data_t;

typedef struct
{
	int    qm_base	:10;
	int	   rsvd	    :6;
	int	   qid		:10;
	qm_cmd_t cmd	:6;

} qm_cmd_addr_t;

typedef struct
{
	int test_md :2;
	int rsvd	:12;
	int sid	:4;
	int pbn	:6;
	int dec_n	:8;
} qm_dec_msg_t;

typedef struct
{
	int rsvd	:17;
	int mbox	:5;
	int slot	:8;
	int size	:2;
} qm_enq_msg_t;


// Functions
void extern qm_init_clkrst(void);
void extern qm_ecc_init(void);
void extern qm_misc_init(void);
void extern qm_intrmask_init(void);
void extern qm_enable(void);
void extern qm_disable(void);
void extern fp_qstate_init(int qid, int no_of_entry);
void extern wq_qstate_init(int qid);
void extern qm_pb_init(qm_sid_assign_t slaveid, qm_pbid_assign_t pbid, qm_qid_assign_t qid);

void extern init_qm_without_fp(void);
// This function initializes QMLite
// Input: None
// Output: None
// Description: Below are hard configuration used on FPGA
//              You may alter some settings that are specific for your IPs 
void extern init_qm(void);

// This function informs QMLite that CPU has enqueue message to a queue 
// Input:
//  -qid: the queue id
//  -nof_of_entry: number of entries to be enqueues, in case of 16/32 byte messages 1 of each message
//                 in case of 64 byte message 2 for each message
void extern alternate_enqueue(int qid, int no_of_entry);

// This function informs QMLite that CPU has dequeue message from a queue
// Input:
//  -qid: the queue id
//  -no_of_entry: number of entries to be dequeues, in case of 16/32 byte messages 1 of each message
//                 in case of 64 byte message 2 for each message
void extern alternate_dequeue(int qid, int no_of_entry);


// This function is to read out completion message from memory
// Input: 
//   - qid: the qid of queue where completion message is stored
//   - 4 pointers to store read data 
// Output:
//   - 0 if message is 32 byte
//   - 1 if message is 64 bytes and no linked list
//   - 2 if message is 64 bytes with linked list
int read_cm_msg (int qid, msg_16b_t *deq_msg_0, msg_16b_t *deq_msg_1, msg_16b_t *deq_msg_2, msg_16b_t *deq_msg_3);

// This function inform is to read out completion message from memory
// Input: 
//   - qid: the qid of queue where completion message is stored
//   - 1 pointer to store read data 
// Output: None
void read_deallot_msg (int qid, msg_16b_t *deq_msg_0);

// This function is to write 64b msg to corresponding memory for queue
void build_64b_generic_msg (int qid, msg_16b_field_0_t* enq_msg0, msg_16b_field_1_t* enq_msg1,
                                     msg_16b_field_2_t* enq_msg2, msg_16b_field_3_t* enq_msg3);
// This function is to write 32b msg to corresponding memory for queue
void build_32b_generic_msg (int qid, msg_16b_field_0_t* enq_msg0, msg_16b_field_1_t* enq_msg1);

// This function is to build up a linked-list
unsigned int build_linked_list(unsigned long long ll_ptr, unsigned int cur_buf_pos, unsigned char num_of_entry, 
                               unsigned long long* buf_addr_ptr, unsigned short* buf_len_ptr);

// This function is to poll completion messages returned to work queue of CPU 
void extern poll_cm_msg (void); //

// This function is read queue mail box not empty status bit
int read_qm_ne_sts (void);

#endif /* __vSEC_QM_DRIVER_H__ */

