#ifndef __SEC_DBG_C__
#define __SEC_DBG_C__

#include "../include/sec_dbg.h"
#include "armv8.h"

void start_sec_axi_mon(void)
{
	WRITE32(SM_GLBL_DIAG_CSR_CFG_BW_MSTR_STOP_CNT_REG, 0xFFFFFFFF);
	WRITE32(SM_GLBL_DIAG_CSR_CFG_BW_SLV_STOP_CNT_REG, 0xFFFFFFFF);

	WRITE32(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP_REG, 0x0000001f);
	//debug_sec_dbg("\n*** Started SEC AXI Interface monitor ***\n");
}

void stop_sec_axi_mon(void)
{
	WRITE32(SM_GLBL_DIAG_CSR_CFG_DIAG_START_STOP_REG, 0x00000000);
	//debug_sec_dbg("\n*** Stopped SEC AXI Interface monitor ***\n");
}

void dump_sec_axi_bw(void)
{
	int rd_data;

	rd_data = RD_MEM32(SM_GLBL_DIAG_CSR_STS_AXI_MRD_BW_CLK_CNT_REG);
	debug_sec_dbg("\n** SEC AXI Master Read Clock Counter: 0x%08x\n", rd_data);
	rd_data = RD_MEM32(SM_GLBL_DIAG_CSR_STS_AXI_MRD_BW_BYTE_CNT_REG);
	debug_sec_dbg("\n** SEC AXI Master Read Byte Counter: 0x%08x\n", rd_data);
	rd_data = RD_MEM32(SM_GLBL_DIAG_CSR_STS_AXI_MWR_BW_CLK_CNT_REG);
	debug_sec_dbg("\n** SEC AXI Master Write Clock Counter: 0x%08x\n", rd_data);
	rd_data = RD_MEM32(SM_GLBL_DIAG_CSR_STS_AXI_MWR_BW_BYTE_CNT_REG);
	debug_sec_dbg("\n** SEC AXI Master Write Byte Counter: 0x%08x\n", rd_data);

	rd_data = RD_MEM32(SM_GLBL_DIAG_CSR_STS_AXI_SRD_BW_CLK_CNT_REG);
	debug_sec_dbg("\n** SEC AXI Slave Read Clock Counter: 0x%08x\n", rd_data);
	rd_data = RD_MEM32(SM_GLBL_DIAG_CSR_STS_AXI_SRD_BW_BYTE_CNT_REG);
	debug_sec_dbg("\n** SEC AXI Slave Read Byte Counter: 0x%08x\n", rd_data);
	rd_data = RD_MEM32(SM_GLBL_DIAG_CSR_STS_AXI_SWR_BW_CLK_CNT_REG);
	debug_sec_dbg("\n** SEC AXI Slave Write Clock Counter: 0x%08x\n", rd_data);
	rd_data = RD_MEM32(SM_GLBL_DIAG_CSR_STS_AXI_SWR_BW_BYTE_CNT_REG);
	debug_sec_dbg("\n** SEC AXI Slave Write Byte Counter: 0x%08x\n", rd_data);
}

void config_sec_diag(unsigned int sel_12_11, unsigned int sel_8_6, unsigned int sel_5_0, unsigned int upper_lower_sel)
{
	unsigned int diag_sel = (sel_12_11 << 11) | (sel_8_6 << 7) | (sel_5_0 << 1) | upper_lower_sel;

// Below 2 settings are specific for current FPGA RTL configurations
//  WRITE32 (0x97040000, 0x02000000);   // Select this to watch diag out
//  WRITE32 (0x97040004, 0x0000000B);   // Select this to watch diag out of SEC

	WRITE32(SM_GLBL_DIAG_CSR_CFG_DIAG_SEL_REG, diag_sel);
}

void dump_sec_dbg(unsigned int sel_12_11, unsigned int sel_8_6, unsigned int sel_5_0)
{
	int read_data;

	switch (sel_12_11)
	{
		case 0:  // AXI
			read_data = RD_MEM32(SM_GLBL_DIAG_CSR_DBG_BLOCK_AXI_REG);

			switch(sel_8_6)
			{
				case SM_SEC_DIAG_SEL_8_6__DEV_ID:
					debug_sec_dbg("\n*** TO-DO: Not yet supported this 'sel_8_6' settting ***\n");
					break;
				case SM_SEC_DIAG_SEL_8_6__QMI_EIP96_CRYPTO:
					debug_sec_dbg("\n*** TO-DO: Not yet supported this 'sel_8_6' settting ***\n");
					break;
				case SM_SEC_DIAG_SEL_8_6__QMI_XTS_CRYPTO:
					debug_sec_dbg("\n*** TO-DO: Not yet supported this 'sel_8_6' settting ***\n");
					break;
				case SM_SEC_DIAG_SEL_8_6__QMI_EIP62_CRYPTO:
					debug_sec_dbg("\n*** TO-DO: Not yet supported this 'sel_8_6' settting ***\n");
					break;
				case SM_SEC_DIAG_SEL_8_6__EIP96:
					debug_sec_dbg("\n*** TO-DO: Not yet supported this 'sel_8_6' settting ***\n");
					break;
				case SM_SEC_DIAG_SEL_8_6__XTS:
					debug_sec_dbg("\n*** TO-DO: Not yet supported this 'sel_8_6' setting ***\n");
					break;
				case SM_SEC_DIAG_SEL_8_6__EIP62:
					switch (sel_5_0)
					{
						case SM_SEC_DIAG_SEL_5_0__AXI_RD_MSG:
							debug_sec_dbg("\n*** SM_SEC_DIAG_SEL_5_0__AXI_RD_MSG ***\n");
							debug_sec_dbg("qmi_msg_rd_cur_state = 0x%08x\n", (read_data>>29) & 0x7);
							break;
						default:
							debug_sec_dbg("\n*** Not supported yet ***\n");
							break;
					}
					break;
				default:
					debug_sec_dbg("*** Unvalid 'sel_8_6' settting ***");
					break;
			}
			break;
		case 1:  // Non-AXI
			read_data = READ32(SEC_CSR_BASE + SM_GLBL_DIAG_CSR_DBG_BLOCK_NON_AXI__ADDR);
			switch(sel_8_6)
			{
				case SM_SEC_DIAG_SEL_8_6__DEV_ID:
					debug_sec_dbg("\n*** TO-DO: Not yet supported this 'sel_8_6' settting ***\n");
					break;
				case SM_SEC_DIAG_SEL_8_6__QMI_EIP96_CRYPTO:
					debug_sec_dbg("\n*** TO-DO: Not yet supported this 'sel_8_6' settting ***\n");
					break;
				case SM_SEC_DIAG_SEL_8_6__QMI_XTS_CRYPTO:
					debug_sec_dbg("\n*** TO-DO: Not yet supported this 'sel_8_6' settting ***\n");
					break;
				case SM_SEC_DIAG_SEL_8_6__QMI_EIP62_CRYPTO:
					debug_sec_dbg("\n*** TO-DO: Not yet supported this 'sel_8_6' settting ***\n");
					break;
				case SM_SEC_DIAG_SEL_8_6__EIP96:
					debug_sec_dbg("\n*** TO-DO: Not yet supported this 'sel_8_6' settting ***\n");
					break;
				case SM_SEC_DIAG_SEL_8_6__XTS:
					debug_sec_dbg("\n*** TO-DO: Not yet supported this 'sel_8_6' settting ***\n");
					break;
				case SM_SEC_DIAG_SEL_8_6__EIP62:
					switch (sel_5_0)
					{
						case SM_SEC_DIAG_SEL_5_0__EIP62_WDATA_CTL:
							debug_sec_dbg("\n*** TO-DO: Not yet supported this 'sel_5_0' settting ***\n");
							break;
						case SM_SEC_DIAG_SEL_5_0__EIP62_WDATA_LEN:
							debug_sec_dbg("\n*** TO-DO: Not yet supported this 'sel_5_0' settting ***\n");
							break;
						case SM_SEC_DIAG_SEL_5_0__EIP62_RDATA    :
							debug_sec_dbg("\n*** TO-DO: Not yet supported this 'sel_5_0' settting ***\n");
							break;
						case SM_SEC_DIAG_SEL_5_0__EIP62_RWCTX_CTL:
							debug_sec_dbg("\n*** TO-DO: Not yet supported this 'sel_5_0' settting ***\n");
							break;
						case SM_SEC_DIAG_SEL_5_0__EIP62_RWCTX_LEN:
							debug_sec_dbg("\n*** TO-DO: Not yet supported this 'sel_5_0' settting ***\n");
							break;
						case SM_SEC_DIAG_SEL_5_0__EIP62_RTKN     :
							debug_sec_dbg("\n*** TO-DO: Not yet supported this 'sel_5_0' settting ***\n");
							break;
						case SM_SEC_DIAG_SEL_5_0__EIP62_WTKN     :
							debug_sec_dbg("\n*** TO-DO: Not yet supported this 'sel_5_0' settting ***\n");
							break;
						case SM_SEC_DIAG_SEL_5_0__EIP62_FIFO_STS :
							debug_sec_dbg("\n*** SM_SEC_DIAG_SEL_5_0__EIP62_FIFO_STS ***\n");
							debug_sec_dbg("qmi_wqdata_fifo_rd_avail_thr = 0x%08x\n", (read_data>>29) & 0x7);
							debug_sec_dbg("qmi_wqdata_fifo_rd_ready = 0x%08x\n", (read_data>>28) & 0x1);
							debug_sec_dbg("trcf_wr_ready  = 0x%08x\n", (read_data>>27) & 0x1);
							debug_sec_dbg("trdf_rd_ready  = 0x%08x\n", (read_data>>26) & 0x1);
							debug_sec_dbg("crcf_wr_ready  = 0x%08x\n", (read_data>>28) & 0x1);
							debug_sec_dbg("crf_rd_ready   = 0x%08x\n", (read_data>>24) & 0x1);
							debug_sec_dbg("drcf_wr_ready  = 0x%08x\n", (read_data>>23) & 0x1);
							debug_sec_dbg("drf_rd_ready   = 0x%08x\n", (read_data>>22) & 0x1);
							debug_sec_dbg("twcf_wr_ready  = 0x%08x\n", (read_data>>21) & 0x1);
							debug_sec_dbg("twdf_wr_ready  = 0x%08x\n", (read_data>>20) & 0x1);
							debug_sec_dbg("cwcf_wr_ready  = 0x%08x\n", (read_data>>19) & 0x1);
							debug_sec_dbg("cwf_wr_ready   = 0x%08x\n", (read_data>>18) & 0x1);
							debug_sec_dbg("dwcf_wr_ready  = 0x%08x\n", (read_data>>17) & 0x1);
							debug_sec_dbg("dwf_wr_ready   = 0x%08x\n", (read_data>>16) & 0x1);
							debug_sec_dbg("dwszf_wr_ready = 0x%08x\n", (read_data>>15) & 0x1);
							break;
					}
					break;
				default:
						debug_sec_dbg("*** Unvalid 'sel_8_6' settting ***");
					break;
			}
			break;
		case 2:  // SHIM
			debug_sec_dbg("\n*** TO-DO: Not yet supported dumping SHHIM *** \n");
			break;
		default: // Unvalid
			debug_sec_dbg("\n*** Unvalid 'sel_12_11' settting ***\n");
		break;
	}
}

void dump_sec_eip96_core_csr(void)
{
  //int csr_data;
  // Token
  debug_sec_dbg("IPE_ACT_TKN_W0  = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_ACT_TKN_W0_REG));
  debug_sec_dbg("IPE_ACT_TKN_W1  = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_ACT_TKN_W1_REG));
  debug_sec_dbg("IPE_ACT_TKN_W2  = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_ACT_TKN_W2_REG));
  debug_sec_dbg("IPE_ACT_TKN_W3  = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_ACT_TKN_W3_REG));
  debug_sec_dbg("IPE_ACT_TKN_W4  = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_ACT_TKN_W4_REG));
  debug_sec_dbg("IPE_ACT_TKN_W5  = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_ACT_TKN_W5_REG));
  debug_sec_dbg("IPE_ACT_TKN_W6  = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_ACT_TKN_W6_REG));
  debug_sec_dbg("IPE_ACT_TKN_W7  = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_ACT_TKN_W7_REG));
  debug_sec_dbg("IPE_ACT_TKN_W8  = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_ACT_TKN_W8_REG));
  debug_sec_dbg("IPE_ACT_TKN_W9  = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_ACT_TKN_W9_REG));
  debug_sec_dbg("IPE_ACT_TKN_W10 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_ACT_TKN_W10_REG));
  debug_sec_dbg("IPE_ACT_TKN_W11 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_ACT_TKN_W11_REG));
  debug_sec_dbg("IPE_ACT_TKN_W12 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_ACT_TKN_W12_REG));
  debug_sec_dbg("IPE_ACT_TKN_W13 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_ACT_TKN_W13_REG));
  debug_sec_dbg("IPE_ACT_TKN_W14 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_ACT_TKN_W14_REG));
  debug_sec_dbg("IPE_ACT_TKN_W15 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_ACT_TKN_W15_REG));

  // Context
  debug_sec_dbg("IPE_ACT_CTX_CMD0 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_ACT_CTX_CMD0_REG));
  debug_sec_dbg("IPE_ACT_CTX_CMD1 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_ACT_CTX_CMD1_REG));

  // IV
  debug_sec_dbg("IPE_IV0 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_IV0_REG));
  debug_sec_dbg("IPE_IV1 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_IV1_REG));
  debug_sec_dbg("IPE_IV2 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_IV2_REG));
  debug_sec_dbg("IPE_IV3 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_IV3_REG));

  // Key 
  debug_sec_dbg("IPE_KEY0 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_KEY0_REG));
  debug_sec_dbg("IPE_KEY1 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_KEY1_REG));
  debug_sec_dbg("IPE_KEY2 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_KEY2_REG));
  debug_sec_dbg("IPE_KEY3 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_KEY3_REG));
  debug_sec_dbg("IPE_KEY4 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_KEY4_REG));
  debug_sec_dbg("IPE_KEY5 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_KEY5_REG));
  debug_sec_dbg("IPE_KEY6 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_KEY6_REG));
  debug_sec_dbg("IPE_KEY7 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_KEY7_REG));

  // Inner digest
  debug_sec_dbg("IPE Inner Digest 0 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_IN_DGST0_REG));
  debug_sec_dbg("IPE Inner Digest 1 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_IN_DGST1_REG));
  debug_sec_dbg("IPE Inner Digest 2 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_IN_DGST2_REG));
  debug_sec_dbg("IPE Inner Digest 3 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_IN_DGST3_REG));
  debug_sec_dbg("IPE Inner Digest 4 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_IN_DGST4_REG));
  debug_sec_dbg("IPE Inner Digest 5 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_IN_DGST5_REG));
  debug_sec_dbg("IPE Inner Digest 6 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_IN_DGST6_REG));
  debug_sec_dbg("IPE Inner Digest 7 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_IN_DGST7_REG));


  // Outer digest
  debug_sec_dbg("IPE Outer Digest 0 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_OUT_DGST0_REG));
  debug_sec_dbg("IPE Outer Digest 1 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_OUT_DGST1_REG));
  debug_sec_dbg("IPE Outer Digest 2 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_OUT_DGST2_REG));
  debug_sec_dbg("IPE Outer Digest 3 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_OUT_DGST3_REG));
  debug_sec_dbg("IPE Outer Digest 4 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_OUT_DGST4_REG));
  debug_sec_dbg("IPE Outer Digest 5 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_OUT_DGST5_REG));
  debug_sec_dbg("IPE Outer Digest 6 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_OUT_DGST6_REG));
  debug_sec_dbg("IPE Outer Digest 7 = 0x%08x\n", RD_MEM32(SM_SEC_EIP96_CORE_CSR_IPE_OUT_DGST7_REG));

  return;
}

void dump_sec_xts_core_csr(void)
{
  debug_sec_dbg("XTS_CSR_CSR_XTS_CONTROL_REG           = ", RD_MEM32(SM_SEC_XTS_CORE_CSR_CSR_XTS_CONTROL_REG));
  debug_sec_dbg("XTS_CSR_CSR_XTS_CONFIGURATION_REG     = ", RD_MEM32(SM_SEC_XTS_CORE_CSR_CSR_XTS_CONFIGURATION_REG));
  debug_sec_dbg("XTS_CSR_CSR_XTS_STATUS                  = ", RD_MEM32(SM_SEC_XTS_CORE_CSR_CSR_XTS_STATUS_REG));
  debug_sec_dbg("XTS_CSR_CSR_XTS_TOKEN_CONTROL_WORD      = ", RD_MEM32(SM_SEC_XTS_CORE_CSR_CSR_XTS_TOKEN_CONTROL_WORD_REG));
  debug_sec_dbg("XTS_CSR_CSR_XTS_TOKEN_CONTEXT_POINTER   = ", RD_MEM32(SM_SEC_XTS_CORE_CSR_CSR_XTS_TOKEN_CONTEXT_POINTER_REG));
  debug_sec_dbg("XTS_CSR_CSR_XTS_TOKEN_DMA_LENGTH        = ", RD_MEM32(SM_SEC_XTS_CORE_CSR_CSR_XTS_TOKEN_DMA_LENGTH_REG));
  debug_sec_dbg("XTS_CSR_CSR_XTS_TOKEN_IV_DWORD0         = ", RD_MEM32(SM_SEC_XTS_CORE_CSR_CSR_XTS_TOKEN_IV_DWORD0_REG));
  debug_sec_dbg("XTS_CSR_CSR_XTS_TOKEN_IV_DWORD1         = ", RD_MEM32(SM_SEC_XTS_CORE_CSR_CSR_XTS_TOKEN_IV_DWORD1_REG));
  debug_sec_dbg("XTS_CSR_CSR_XTS_TOKEN_IV_DWORD2         = ", RD_MEM32(SM_SEC_XTS_CORE_CSR_CSR_XTS_TOKEN_IV_DWORD2_REG));
  debug_sec_dbg("XTS_CSR_CSR_XTS_TOKEN_IV_DWORD3         = ", RD_MEM32(SM_SEC_XTS_CORE_CSR_CSR_XTS_TOKEN_IV_DWORD3_REG));
  debug_sec_dbg("XTS_CSR_CSR_XTS_CONTEXT_KEY1_DWORD0     = ", RD_MEM32(SM_SEC_XTS_CORE_CSR_CSR_XTS_CONTEXT_KEY1_DWORD0_REG));
  debug_sec_dbg("XTS_CSR_CSR_XTS_CONTEXT_KEY1_DWORD1     = ", RD_MEM32(SM_SEC_XTS_CORE_CSR_CSR_XTS_CONTEXT_KEY1_DWORD1_REG));
  debug_sec_dbg("XTS_CSR_CSR_XTS_CONTEXT_KEY1_DWORD2     = ", RD_MEM32(SM_SEC_XTS_CORE_CSR_CSR_XTS_CONTEXT_KEY1_DWORD2_REG));
  debug_sec_dbg("XTS_CSR_CSR_XTS_CONTEXT_KEY1_DWORD3     = ", RD_MEM32(SM_SEC_XTS_CORE_CSR_CSR_XTS_CONTEXT_KEY1_DWORD3_REG));
  debug_sec_dbg("XTS_CSR_CSR_XTS_CONTEXT_KEY1_DWORD4     = ", RD_MEM32(SM_SEC_XTS_CORE_CSR_CSR_XTS_CONTEXT_KEY1_DWORD4_REG));
  debug_sec_dbg("XTS_CSR_CSR_XTS_CONTEXT_KEY1_DWORD5     = ", RD_MEM32(SM_SEC_XTS_CORE_CSR_CSR_XTS_CONTEXT_KEY1_DWORD5_REG));
  debug_sec_dbg("XTS_CSR_CSR_XTS_CONTEXT_KEY1_DWORD6     = ", RD_MEM32(SM_SEC_XTS_CORE_CSR_CSR_XTS_CONTEXT_KEY1_DWORD6_REG));
  debug_sec_dbg("XTS_CSR_CSR_XTS_CONTEXT_KEY1_DWORD7     = ", RD_MEM32(SM_SEC_XTS_CORE_CSR_CSR_XTS_CONTEXT_KEY1_DWORD7_REG));
  debug_sec_dbg("XTS_CSR_CSR_XTS_CONTEXT_KEY2_DWORD0     = ", RD_MEM32(SM_SEC_XTS_CORE_CSR_CSR_XTS_CONTEXT_KEY2_DWORD0_REG));
  debug_sec_dbg("XTS_CSR_CSR_XTS_CONTEXT_KEY2_DWORD1     = ", RD_MEM32(SM_SEC_XTS_CORE_CSR_CSR_XTS_CONTEXT_KEY2_DWORD1_REG));
  debug_sec_dbg("XTS_CSR_CSR_XTS_CONTEXT_KEY2_DWORD2     = ", RD_MEM32(SM_SEC_XTS_CORE_CSR_CSR_XTS_CONTEXT_KEY2_DWORD2_REG));
  debug_sec_dbg("XTS_CSR_CSR_XTS_CONTEXT_KEY2_DWORD3     = ", RD_MEM32(SM_SEC_XTS_CORE_CSR_CSR_XTS_CONTEXT_KEY2_DWORD3_REG));
  debug_sec_dbg("XTS_CSR_CSR_XTS_CONTEXT_KEY2_DWORD4     = ", RD_MEM32(SM_SEC_XTS_CORE_CSR_CSR_XTS_CONTEXT_KEY2_DWORD4_REG));
  debug_sec_dbg("XTS_CSR_CSR_XTS_CONTEXT_KEY2_DWORD5     = ", RD_MEM32(SM_SEC_XTS_CORE_CSR_CSR_XTS_CONTEXT_KEY2_DWORD5_REG));
  debug_sec_dbg("XTS_CSR_CSR_XTS_CONTEXT_KEY2_DWORD6     = ", RD_MEM32(SM_SEC_XTS_CORE_CSR_CSR_XTS_CONTEXT_KEY2_DWORD6_REG));
  debug_sec_dbg("XTS_CSR_CSR_XTS_CONTEXT_KEY2_DWORD7     = ", RD_MEM32(SM_SEC_XTS_CORE_CSR_CSR_XTS_CONTEXT_KEY2_DWORD7_REG));
  debug_sec_dbg("XTS_CSR_CSR_XTS_DIN_XFR_COUNT           = ", RD_MEM32(SM_SEC_XTS_CORE_CSR_CSR_XTS_DIN_XFR_COUNT_REG));
  debug_sec_dbg("XTS_CSR_CSR_XTS_DOUT_XFR_COUNT          = ", RD_MEM32(SM_SEC_XTS_CORE_CSR_CSR_XTS_DOUT_XFR_COUNT_REG));
}                                            
                                             
#endif /*__SEC_DBG_C__*/
