#ifndef __vSEC_QM_DRIVER_C__
#define __vSEC_QM_DRIVER_C__

#include "../include/vSEC_globals.h"
#include "../include/vSEC_qm_driver.h"
#include "armv8.h"

//Tinh-SLT:
#define qm_init_clkrst qm_init_clkrst_slt_sec
#define qm_ecc_init qm_ecc_init_slt_sec
#define qm_misc_init qm_misc_init_slt_sec
#define qm_intrmask_init qm_intrmask_init_slt_sec
#define qm_enable qm_enable_slt_sec
#define get_queue_size_code get_queue_size_code_slt_sec
#define fp_qstate_init fp_qstate_init_slt_sec
#define wq_qstate_init wq_qstate_init_slt_sec
#define qm_pb_init qm_pb_init_slt_sec
//End of Tinh-SLT

extern unsigned long long enq_ptr[MAX_NO_OF_QUEUE];
extern unsigned long long deq_ptr[MAX_NO_OF_QUEUE];

void qm_init_clkrst(void)
{
	debug_vsec_qm_drv("\nStart %s()\n", __FUNCTION__);
	WRITE32((QM_CLKRST_CSR_BASE_ADDR + QM_CLKEN_ADDR) , 0x0); //Disable
	arch_timer_msdelay(200);
	WRITE32((QM_CLKRST_CSR_BASE_ADDR + QM_CLKEN_ADDR) , 0x3); //Enable QM Core clock and QM CSR clock

	//Soft reset QM
	WRITE32((QM_CLKRST_CSR_BASE_ADDR + QM_SRST_ADDR) , 0x3);
	arch_timer_msdelay(200);
	WRITE32((QM_CLKRST_CSR_BASE_ADDR + QM_SRST_ADDR) , 0x0);

	debug_vsec_qm_drv("\n%s: QM_CLKEN_REG: 0x%08x\n", __FUNCTION__, READ32(QM_CLKRST_CSR_BASE_ADDR + QM_CLKEN_ADDR));
	debug_vsec_qm_drv("\n%s: QM_SRST_REG: 0x%08x\n", __FUNCTION__, READ32(QM_CLKRST_CSR_BASE_ADDR + QM_SRST_ADDR));

	debug_vsec_qm_drv("\nExit %s()\n", __FUNCTION__);
}

void qm_ecc_init(void)
{
	unsigned int rdata;

	debug_vsec_qm_drv("\nStart %s()\n", __FUNCTION__);

	WRITE32((REGSPEC_GLBL_DIAG_CSR_BASE_ADDR + REGSPEC_CFG_MEM_RAM_SHUTDOWN_ADDR) , 0x00000000);

	do
	{
		rdata = READ32((REGSPEC_GLBL_DIAG_CSR_BASE_ADDR + REGSPEC_BLOCK_MEM_RDY_ADDR));
	}while (rdata != 0xffffffff);

	//configure BYPASS
	WRITE32(REGSPEC_GLBL_DIAG_CSR_BASE_ADDR + REGSPEC_CFG_MEM_ECC_BYPASS_ADDR, 0x22a60000);

	//wait for ready
	do
	{
		rdata = READ32((REGSPEC_GLBL_DIAG_CSR_BASE_ADDR + REGSPEC_BLOCK_MEM_RDY_ADDR));
	} while ( rdata != 0xffffffff);

	debug_vsec_qm_drv("\nExit %s()\n", __FUNCTION__);
}

void qm_misc_init(void)
{
	debug_vsec_qm_drv("\nStart %s()\n", __FUNCTION__);

	WRITE32((QM_CSR_BASE_ADDR + CSR_PBM_COAL_ADDR), 0x88019103); //QM prefetch buffer manager: interrupt coalescence base timer control
	WRITE32((QM_CSR_BASE_ADDR + CSR_QM_MBOX_NE_INT_MODE_ADDR), 0xffffffff); //CPU mailbox Interrupt Mode
	WRITE32((QM_CSR_BASE_ADDR + CSR_ACR_FIFO_CTRL_ADDR), 0xc0e0812a); //ACR FIFO control register
	WRITE32((QM_CSR_BASE_ADDR + CSR_DEQ_CTRL_0_ADDR), 0x00000008); //Dequeue Control Register 0
	WRITE32((QM_CSR_BASE_ADDR + CSR_RECOMB_CTRL_0_ADDR), 0x00000204); //QM Recombination Logic Control 0
	WRITE32((QM_CSR_BASE_ADDR + CSR_QM_STATS_CFG_ADDR), 0x00050005); //QM enqueue dequeue statistics counters QID assignment register.
	WRITE32((SLAVE_SHIM_CSR_BASE_ADDR + CFG_AMA_MODE_ADDR), 0x00000001 );
	WRITE32((QM_CSR_BASE_ADDR + CSR_ERRQ_ADDR) , 0x80008000); //QM Error queue config register

	//SLIMPRO uses pbn0 and pbn1 while cop, abd cpu each use pbn0
	//WRITE32((QM_CSR_BASE_ADDR + CSR_QMLITE_PBN_MAP_0_ADDR) , 0x00000000);
	//WRITE32((QM_CSR_BASE_ADDR + CSR_QMLITE_PBN_MAP_1_ADDR) , 0x00000021);
	debug_vsec_qm_drv("\nExit %s()\n", __FUNCTION__);
}

void qm_intrmask_init(void)
{
	debug_vsec_qm_drv("\nStart %s()\n", __FUNCTION__);
 
	WRITE32((QM_CSR_BASE_ADDR + QM_INTERRUPTMASK_ADDR) , 0x00000008);

	debug_vsec_qm_drv("\nExit %s()\n", __FUNCTION__);
}

void qm_enable(void)
{
	debug_vsec_qm_drv("\nStart %s()\n", __FUNCTION__);

	WRITE32((QM_CSR_BASE_ADDR + CSR_QM_CONFIG_ADDR) , 0xe0000000);

	debug_vsec_qm_drv("\nExit %s()\n", __FUNCTION__);
}

void qm_disable(void)
{
	debug_vsec_qm_drv("\nStart %s()\n", __FUNCTION__);

	WRITE32((QM_CSR_BASE_ADDR + CSR_QM_CONFIG_ADDR) , 0x00000000);

	debug_vsec_qm_drv("\nExit %s()\n", __FUNCTION__);
}

int get_queue_size_code (int actual_queue_size)
{
	int queue_size_code;

	switch (actual_queue_size)
	{
		case 0x200:  // 0.5KB
			queue_size_code = 0;
			break;
		case 0x800:  // 2KB
			queue_size_code = 1;
			break;
		case 0x4000: // 16KB
			queue_size_code = 2;
			break;
		case 0x10000: // 64KB
			queue_size_code = 3;
			break;
		case 0x80000: // 512KB
			queue_size_code = 4;
			break;
		default: //Unsupported setting, forced to 2KB
			queue_size_code = 1;
  }
  return queue_size_code;
}

void fp_qstate_init(int qid, int no_of_entry)
{
	pq_fp_state_t fp_state;
	q_state_t     intstream;
	int q_type ;
	int q_size;
	unsigned long long st_addr;
	int n_msg ;
	int fp_mode;

	debug_vsec_qm_drv("\nStart %s()\n", __FUNCTION__);

	// Formation of Queue state data
	q_type = 2;
	q_size = get_queue_size_code(MAX_QUEUE_SIZE);
	fp_mode = 2;
	st_addr = (unsigned long long)((MEM_BASE_ADDR + (MAX_QUEUE_SIZE * qid)) >> 8);
	n_msg = no_of_entry;
	fp_state.q_type = q_type;
	fp_state.q_size = q_size;
	fp_state.st_addr = st_addr;
	fp_state.n_msg = n_msg;
	fp_state.fp_mode = fp_mode;

	WRITE32((QM_CSR_BASE_ADDR + CSR_QSTATE_ADDR), qid);
	WRITE32((QM_CSR_BASE_ADDR + CSR_QSTATE_WR_0_ADDR), 0x00000000);
	WRITE32((QM_CSR_BASE_ADDR + CSR_QSTATE_WR_1_ADDR), (unsigned int)(n_msg << 1));
	WRITE32((QM_CSR_BASE_ADDR + CSR_QSTATE_WR_2_ADDR), (unsigned int)(st_addr << 5));
	WRITE32((QM_CSR_BASE_ADDR + CSR_QSTATE_WR_3_ADDR), (((unsigned int)(q_size << 23)) | ((unsigned int)(fp_mode << 20)) | ((unsigned int)(st_addr >> 27))));
	WRITE32((QM_CSR_BASE_ADDR + CSR_QSTATE_WR_4_ADDR), (unsigned int)(q_type << 19));

	q_state[qid] = fp_state;

	debug_vsec_qm_drv("\nExit %s()\n", __FUNCTION__);
}

void wq_qstate_init(int qid)
{
	pq_fp_state_t wq_state;
	q_state_t     intstream;
	int q_type ;
	int q_size;
	unsigned long long st_addr;
	int lerr_ok;

	debug_vsec_qm_drv("\nStart %s()\n", __FUNCTION__);

	// Formation of Queue state data
	q_type = 1;
	q_size = get_queue_size_code(MAX_QUEUE_SIZE);
	lerr_ok = 0;
	st_addr = (unsigned long long)((MEM_BASE_ADDR + (MAX_QUEUE_SIZE * qid)) >> 8);
	wq_state.q_type = q_type;
	wq_state.q_size = q_size;
	wq_state.st_addr = st_addr;
	wq_state.lerr_ok = lerr_ok;

	WRITE32((QM_CSR_BASE_ADDR + CSR_QSTATE_ADDR), qid);
	WRITE32((QM_CSR_BASE_ADDR + CSR_QSTATE_WR_0_ADDR), 0x00000000);
	WRITE32((QM_CSR_BASE_ADDR + CSR_QSTATE_WR_1_ADDR), 0x00000000);
	WRITE32((QM_CSR_BASE_ADDR + CSR_QSTATE_WR_2_ADDR), (unsigned int)(st_addr << 5));
	WRITE32((QM_CSR_BASE_ADDR + CSR_QSTATE_WR_3_ADDR), ((q_size << 23) | ((unsigned int)(lerr_ok << 19))| ((unsigned int)(st_addr >> 27))));
	WRITE32((QM_CSR_BASE_ADDR + CSR_QSTATE_WR_4_ADDR), (q_type << 19));

	q_state[qid] = wq_state;

	debug_vsec_qm_drv("\nExit %s()\n", __FUNCTION__);
}

void qm_pb_init(qm_sid_assign_t slaveid, qm_pbid_assign_t pbid, qm_qid_assign_t qid)
{
	pb_data_field_t pb_data;
	pb_data_t intstream;
	unsigned int pbmem_start_addr;

	debug_vsec_qm_drv("\nStart %s()\n", __FUNCTION__);

	pb_data.slot = 0;
	pb_data.pb_size = 0;
	pb_data.pb_en = 1;
	pb_data.tlvq = 0;
	pb_data.qid = qid;
	pb_data.mn = 0;

	intstream.pb_data = pb_data;

	//MEM
	pbmem_start_addr = QM_CSR_BASE_ADDR + 0x1000;
	WRITE32((pbmem_start_addr + ((slaveid<<8) | ((pbid & 0x3f) << 2))) , intstream.data);

	debug_vsec_qm_drv("\nExit %s()\n", __FUNCTION__);
}

void init_qm_without_fp(void)
{
	debug_vsec_qm_drv("\nStart %s()\n", __FUNCTION__);
	// CSR
	qm_init_clkrst();

	qm_ecc_init();

	qm_misc_init();
	qm_intrmask_init();

	//Queue state

//	//Free Pool Queue
//	//proc
//	fp_qstate_init(FPQID0, 0);
//
//	//dma
//	fp_qstate_init(FPQID1, 0);
//	fp_qstate_init(FPQID2, 0);
//	fp_qstate_init(FPQID3, 0);
//	fp_qstate_init(FPQID4, 0);
//	fp_qstate_init(FPQID5, 0);
//	fp_qstate_init(FPQID6, 0);
//	fp_qstate_init(FPQID7, 0);
//	fp_qstate_init(FPQID8, 0);
//
//	//sec
//	fp_qstate_init(FPQID9, 0);
//	fp_qstate_init(FPQID10, 0);
//	fp_qstate_init(FPQID11, 0);
//	fp_qstate_init(FPQID12, 0);
//	fp_qstate_init(FPQID13, 0);
//	fp_qstate_init(FPQID14, 0);
//	fp_qstate_init(FPQID15, 0);
//	fp_qstate_init(FPQID16, 0);

	//Work queue
	//proc
	wq_qstate_init(WQID0);

	//dma
	wq_qstate_init(WQID1);
	wq_qstate_init(WQID2);
	wq_qstate_init(WQID3);
	wq_qstate_init(WQID4);

	//sec
	wq_qstate_init(WQID5);
	wq_qstate_init(WQID6);

	//Prefetch buffer
	//proc
	qm_pb_init(SID_PROC, WQPBID0, WQID0);
	qm_pb_init(SID_PROC, FPQPBID0, FPQID0);

	//dma
	qm_pb_init(SID_DMA, WQPBID0, WQID1);
	qm_pb_init(SID_DMA, WQPBID1, WQID2);
	qm_pb_init(SID_DMA, WQPBID2, WQID3);
	qm_pb_init(SID_DMA, WQPBID3, WQID4);
	qm_pb_init(SID_DMA, FPQPBID0, FPQID1);
	qm_pb_init(SID_DMA, FPQPBID1, FPQID2);
	qm_pb_init(SID_DMA, FPQPBID2, FPQID3);
	qm_pb_init(SID_DMA, FPQPBID3, FPQID4);
	qm_pb_init(SID_DMA, FPQPBID4, FPQID5);
	qm_pb_init(SID_DMA, FPQPBID5, FPQID6);
	qm_pb_init(SID_DMA, FPQPBID6, FPQID7);
	qm_pb_init(SID_DMA, FPQPBID7, FPQID8);

	//sec
	qm_pb_init(SID_SEC, WQPBID0, WQID5);
	qm_pb_init(SID_SEC, WQPBID1, WQID6);
	qm_pb_init(SID_SEC, FPQPBID0, FPQID9);
	qm_pb_init(SID_SEC, FPQPBID1, FPQID10);
	qm_pb_init(SID_SEC, FPQPBID2, FPQID11);
	qm_pb_init(SID_SEC, FPQPBID3, FPQID12);
	qm_pb_init(SID_SEC, FPQPBID4, FPQID13);
	qm_pb_init(SID_SEC, FPQPBID5, FPQID14);
	qm_pb_init(SID_SEC, FPQPBID6, FPQID15);
	qm_pb_init(SID_SEC, FPQPBID7, FPQID16);

	debug_vsec_qm_drv("\nExit %s()\n", __FUNCTION__);
}

void init_qm(void)
{
	debug_vsec_qm_drv("\nStart %s()\n", __FUNCTION__);
	// CSR
	qm_init_clkrst();

	qm_ecc_init();

	qm_misc_init();
	qm_intrmask_init();

	//Queue state

	//Free Pool Queue
	//proc
	fp_qstate_init(FPQID0, 0);

	//dma
	fp_qstate_init(FPQID1, 0);
	fp_qstate_init(FPQID2, 0);
	fp_qstate_init(FPQID3, 0);
	fp_qstate_init(FPQID4, 0);
	fp_qstate_init(FPQID5, 0);
	fp_qstate_init(FPQID6, 0);
	fp_qstate_init(FPQID7, 0);
	fp_qstate_init(FPQID8, 0);

	//sec
	fp_qstate_init(FPQID9, 0);
	fp_qstate_init(FPQID10, 0);
	fp_qstate_init(FPQID11, 0);
	fp_qstate_init(FPQID12, 0);
	fp_qstate_init(FPQID13, 0);
	fp_qstate_init(FPQID14, 0);
	fp_qstate_init(FPQID15, 0);
	fp_qstate_init(FPQID16, 0);

	//Work queue
	//proc
	wq_qstate_init(WQID0);

	//dma
	wq_qstate_init(WQID1);
	wq_qstate_init(WQID2);
	wq_qstate_init(WQID3);
	wq_qstate_init(WQID4);

	//sec
	wq_qstate_init(WQID5);
	wq_qstate_init(WQID6);

	//Prefetch buffer
	//proc
	qm_pb_init(SID_PROC, WQPBID0, WQID0);
	qm_pb_init(SID_PROC, FPQPBID0, FPQID0);

	//dma
	qm_pb_init(SID_DMA, WQPBID0, WQID1);
	qm_pb_init(SID_DMA, WQPBID1, WQID2);
	qm_pb_init(SID_DMA, WQPBID2, WQID3);
	qm_pb_init(SID_DMA, WQPBID3, WQID4);
	qm_pb_init(SID_DMA, FPQPBID0, FPQID1);
	qm_pb_init(SID_DMA, FPQPBID1, FPQID2);
	qm_pb_init(SID_DMA, FPQPBID2, FPQID3);
	qm_pb_init(SID_DMA, FPQPBID3, FPQID4);
	qm_pb_init(SID_DMA, FPQPBID4, FPQID5);
	qm_pb_init(SID_DMA, FPQPBID5, FPQID6);
	qm_pb_init(SID_DMA, FPQPBID6, FPQID7);
	qm_pb_init(SID_DMA, FPQPBID7, FPQID8);

	//sec
	qm_pb_init(SID_SEC, WQPBID0, WQID5);
	qm_pb_init(SID_SEC, WQPBID1, WQID6);
	qm_pb_init(SID_SEC, FPQPBID0, FPQID9);
	qm_pb_init(SID_SEC, FPQPBID1, FPQID10);
	qm_pb_init(SID_SEC, FPQPBID2, FPQID11);
	qm_pb_init(SID_SEC, FPQPBID3, FPQID12);
	qm_pb_init(SID_SEC, FPQPBID4, FPQID13);
	qm_pb_init(SID_SEC, FPQPBID5, FPQID14);
	qm_pb_init(SID_SEC, FPQPBID6, FPQID15);
	qm_pb_init(SID_SEC, FPQPBID7, FPQID16);

	debug_vsec_qm_drv("\nExit %s()\n", __FUNCTION__);
}

void alternate_enqueue(int qid, int no_of_entry)
{
	long alt_enq_addr;

	alt_enq_addr = ((CPU_OFFSET_ADDR + QM_BASE_ADDR) | (QMTM1_ID << 16) | (qid << 6) | 0x2C);

	WRITE32(alt_enq_addr, no_of_entry);
}

void alternate_dequeue(int qid, int no_of_entry)
{
	long alt_deq_addr;

	alt_deq_addr = ((CPU_OFFSET_ADDR + QM_BASE_ADDR) | (QMTM1_ID << 16) | (qid << 6) | 0x2C);

	WRITE32(alt_deq_addr, -no_of_entry);
}

void poll_cm_msg(void)
{
	int intr_stat;

	do
	{
		intr_stat = READ32((QM_CSR_BASE_ADDR + CSR_QM_MBOX_NE_ADDR));
	} while(intr_stat != 0x00000001);
}

int read_qm_ne_sts (void)
{
	int ne_sts;

	ne_sts = READ32((QM_CSR_BASE_ADDR + CSR_QM_MBOX_NE_ADDR));
	return ne_sts;
}

int read_cm_msg(int qid, msg_16b_t *deq_msg_0, msg_16b_t *deq_msg_1, msg_16b_t *deq_msg_2, msg_16b_t *deq_msg_3)
{
	int i;
	int cm_msg_type;
	unsigned long long queue_ptr = 0;

	queue_ptr = CPU_OFFSET_ADDR + MEM_BASE_ADDR + (MAX_QUEUE_SIZE * qid) + deq_ptr[qid];

	#ifdef PRINT_DBG_MSG
		printf(" *** Start read_cm_msg ***\n\r");
	#endif

	// read first 32 byte
	for (i = 0; i< 4; i++)
	{
		(*deq_msg_0).raw[i] = READ32(queue_ptr);
		queue_ptr +=4;
	}

	for (i = 0; i< 4; i++)
	{
		(*deq_msg_1).raw[i] = READ32(queue_ptr);
		queue_ptr +=4;
	}
	deq_ptr[qid] += 32;

	///Debug
	#ifdef PRINT_DBG_MSG
		printf(" *** queue_ptr = 0x%08x\n", queue_ptr);
		for (i = 0; i < 4; i++)
		{
			printf(" *** word[%d] = 0x%08x\n", i, (*deq_msg_0).raw[i]);
		}
		for (i = 0; i < 4; i++)
		{
			printf(" *** word[%d] = 0x%08x\n", i+4, (*deq_msg_1).raw[i]);
		}
	#endif

	if (deq_ptr[qid] >= MAX_QUEUE_SIZE)
	{
		deq_ptr[qid] = deq_ptr[qid] - MAX_QUEUE_SIZE; //wrap arrow
	}

	debug_vsec_qm_drv(" *** deq_ptr[qid] = 0x%08x = %d\n", deq_ptr[qid], deq_ptr[qid]);
	debug_vsec_qm_drv(" *** NV = 0x%08x = %d\n", (*deq_msg_0).field0.NV, (*deq_msg_0).field0.NV);

	// Check NV field to decide if it should read next 32 byptes
	if (((*deq_msg_0).field0.NV) == 0) // 32 byte messages
	{
		#ifdef PRINT_DBG_MSG
			printf("Completion message is 32 byte message\n\r");
		#endif
		cm_msg_type = 0;
	}
	else // 64 byte messages
	{
		#ifdef PRINT_DBG_MSG
			printf("Completion message is 64 byte message\n\r");
		#endif
			// Read next 32 byte messages
		for (i = 0; i< 4; i++)
		{
			(*deq_msg_2).raw[i] = READ32(queue_ptr);
			queue_ptr +=4;
		}
		for (i = 0; i< 4; i++)
		{
			(*deq_msg_3).raw[i] = READ32(queue_ptr);
			queue_ptr +=4;
		}
		deq_ptr[qid] += 32;
		if (deq_ptr[qid] >= MAX_QUEUE_SIZE)
		{
			deq_ptr[qid] = deq_ptr[qid] - MAX_QUEUE_SIZE; // wrap arrow
		}

		#ifdef PRINT_DBG_MSG
			printf(" *** queue_ptr = 0x%08x\n", queue_ptr);
			for (i = 0; i < 4; i++)
			{
				printf(" *** word[%d] = 0x%08x\n", i+8, (*deq_msg_2).raw[i]);
			}
			for (i = 0; i < 4; i++)
			{
				printf(" *** word[%d] = 0x%08x\n", i+12, (*deq_msg_3).raw[i]);
			}
		#endif

		if (((*deq_msg_0).field0.LL) == 0) // No linked list
		{
			cm_msg_type = 1;
		}
		else
		{
			cm_msg_type = 2;
		}
	}

	#ifdef PRINT_DBG_MSG
		printf(" *** End   read_cm_msg ***\n\r");
	#endif

	return cm_msg_type;
}

void read_deallot_msg (int qid, msg_16b_t *deq_msg_0)
{
  int i;
  int queue_ptr;

  queue_ptr = CPU_OFFSET_ADDR + MEM_BASE_ADDR + (MAX_QUEUE_SIZE * qid) + deq_ptr[qid];

  for (i = 0; i< 4; i++)
  {
    (*deq_msg_0).raw[i] = READ32(queue_ptr);
    queue_ptr +=4;
  }

  deq_ptr[qid] += 16;
  if (deq_ptr[qid] >= MAX_QUEUE_SIZE)
  {
	  deq_ptr[qid] = deq_ptr[qid] - MAX_QUEUE_SIZE; // wrap arrow
  }
}

void build_64b_generic_msg(int qid, msg_16b_field_0_t* enq_msg0, msg_16b_field_1_t* enq_msg1,
                          msg_16b_field_2_t* enq_msg2, msg_16b_field_3_t* enq_msg3)
{
	int i;
	msg_16b_t intstream;

	if (enq_ptr[qid] >= MAX_QUEUE_SIZE)
	{
		enq_ptr[qid] = 0;
	}

	intstream.field0 = *enq_msg0;
	for(i = 0; i< 4; i++)
	{
		WRITE32((CPU_OFFSET_ADDR + ((MEM_BASE_ADDR + (MAX_QUEUE_SIZE * qid))) + enq_ptr[qid]), intstream.raw[i]);
		enq_ptr[qid] += 4;
		if (enq_ptr[qid] >= MAX_QUEUE_SIZE)
		{
			enq_ptr[qid] = 0;
		}
	}

	intstream.field1 = *enq_msg1;

	for(i = 0; i < 4; i++)
	{
		WRITE32((CPU_OFFSET_ADDR + ((MEM_BASE_ADDR + (MAX_QUEUE_SIZE * qid))) + enq_ptr[qid]), intstream.raw[i]);
		enq_ptr[qid] += 4;
		if (enq_ptr[qid] >= MAX_QUEUE_SIZE)
		{
			enq_ptr[qid] = 0;
		}
	}

	intstream.field2 = *enq_msg2;
	for(i = 0; i< 4; i++)
	{
		WRITE32((CPU_OFFSET_ADDR + ((MEM_BASE_ADDR + (MAX_QUEUE_SIZE * qid))) + enq_ptr[qid]), intstream.raw[i]);
		enq_ptr[qid] += 4;
		if (enq_ptr[qid] >= MAX_QUEUE_SIZE)
		{
			enq_ptr[qid] = 0;
		}
	}

	intstream.field3 = *enq_msg3;
	for(i = 0; i< 4; i++)
	{
		WRITE32((CPU_OFFSET_ADDR + ((MEM_BASE_ADDR + (MAX_QUEUE_SIZE * qid))) + enq_ptr[qid]), intstream.raw[i]);
		enq_ptr[qid] += 4;
		if (enq_ptr[qid] >= MAX_QUEUE_SIZE)
		{
			enq_ptr[qid] = 0;
		}
	}
}

void build_32b_generic_msg(int qid, msg_16b_field_0_t* enq_msg0, msg_16b_field_1_t* enq_msg1)
{
	int i;
	msg_16b_t intstream;
	
	if (enq_ptr[qid] >= MAX_QUEUE_SIZE)
	{
		enq_ptr[qid] = 0;
	}

	intstream.field0 = *enq_msg0;
	for(i = 0; i < 4; i++)
	{
		WRITE32((CPU_OFFSET_ADDR + ((MEM_BASE_ADDR + (MAX_QUEUE_SIZE * qid))) + enq_ptr[qid]), intstream.raw[i]);
		enq_ptr[qid] += 4;
		if (enq_ptr[qid] >= MAX_QUEUE_SIZE)
		{
			enq_ptr[qid] = 0;
		}
	}

	intstream.field1 = *enq_msg1;
	for(i = 0; i < 4; i++)
	{
		WRITE32((CPU_OFFSET_ADDR + ((MEM_BASE_ADDR + (MAX_QUEUE_SIZE * qid))) + enq_ptr[qid]), intstream.raw[i]);
		enq_ptr[qid] += 4;
		if (enq_ptr[qid] >= MAX_QUEUE_SIZE)
		{
			enq_ptr[qid] = 0;
		}
	}
}

unsigned int build_linked_list(unsigned long long ll_ptr, unsigned int cur_buf_pos, unsigned char num_of_entry, 
                               unsigned long long* buf_addr_ptr, unsigned short* buf_len_ptr)
{
	unsigned int i;
	unsigned int upper_index = cur_buf_pos + num_of_entry;
	unsigned int total_data_length = 0;
	buf_header ll_entry;

	for (i = cur_buf_pos; i < upper_index; i = i+2)
	{
		ll_entry.field.BufDataAddr = buf_addr_ptr[i];
		ll_entry.field.BufDataLength = buf_len_ptr[i];
		total_data_length += buf_len_ptr[i];

		WRITE32(CPU_OFFSET_ADDR+ll_ptr+0x08, ll_entry.raw[0]);
		WRITE32(CPU_OFFSET_ADDR+ll_ptr+0x0C, ll_entry.raw[1]);

		if (i+1 >= upper_index)
		{
			break;
		}

		ll_entry.field.BufDataAddr = buf_addr_ptr[i+1];
		ll_entry.field.BufDataLength = buf_len_ptr[i+1];
		total_data_length += buf_len_ptr[i+1];

		WRITE32(CPU_OFFSET_ADDR+ll_ptr+0x00, ll_entry.raw[0]);
		WRITE32(CPU_OFFSET_ADDR+ll_ptr+0x04, ll_entry.raw[1]);

		ll_ptr += 0x10;
	}
	return total_data_length;
}

#endif /*__vSEC_QM_DRIVER_C__*/
