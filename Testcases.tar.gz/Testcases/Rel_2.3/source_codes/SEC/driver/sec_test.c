#ifndef ____SEC_TEST_C__
#define ____SEC_TEST_C__

#include "../include/vSEC_globals.h"
#include "../include/vSEC_defines.h"
#include "../include/vSEC_test_driver.h"

#include "../include/sec_addr_map.h"
#include "../include/sec_driver.h"
#include "../include/sec_test.h"
#include "armv8.h"

//Tinh-SLT
//function call
#define load_mem load_mem_slt_sec
//End of Tinh-SLT

int chk_result(buf_header_queue *expt_buf_queue_ptr, buf_header_queue *expt_tkn_queue_ptr,
               buf_header_queue *expt_deallot_queue_ptr, buf_header_queue *expt_cm_queue_ptr,
               int qid, short chk_mode)
{
	int no_of_error;
	int acc_no_of_error;
	int cm_msg_type;
	int expt_buf_len;
	int rslt_buf_len;

	unsigned long long ll_ptr;
	int ll_length;
	msg_16b_t ll_entry;

	int i;

	buf_header* expt_msg_header;
	buf_header* expt_buf_header;

	msg_16b_t deq_msg_0, deq_msg_1, deq_msg_2, deq_msg_3;

	no_of_error = 0;
	acc_no_of_error = 0;

	#ifdef PRINT_DBG_MSG
		debug_sec_test(" *** Start chk_result ***\n");
	#endif

	cm_msg_type = read_cm_msg(qid, &deq_msg_0, &deq_msg_1, &deq_msg_2, &deq_msg_3);

	#ifdef PRINT_DBG_MSG
		debug_sec_test("chk_result: cm_msg_type = 0x%08x\n", cm_msg_type);
		print_sec_cm_msg_err_info(&deq_msg_0);
	#endif

	// Check completion message
	if (chk_mode != 0)
	{
		no_of_error = chk_cm_msg(qid, (*expt_msg_header).field.BufDataAddr, cm_msg_type);
	}

	if (cm_msg_type == 0)
	{
		alternate_dequeue(qid, 1);
	}
	else
	{
		alternate_dequeue (qid, 2);
	}

	if (no_of_error > 0)
	{
		debug_sec_test("*** ERROR: Failed to check completion message ***\n");
		acc_no_of_error += no_of_error;
		return acc_no_of_error; // Stop checking if completion message is wrong
	}

	// Check result token (SEC specific)
	expt_buf_header = read_buf_header(expt_tkn_queue_ptr, MAX_MEM_BUF);
	no_of_error = chk_rslt_tkn(&deq_msg_1, (*expt_buf_header).field.BufDataAddr, (*expt_buf_header).field.BufDataLength);
	acc_no_of_error += no_of_error;

	// Check output data
	// First check 1st buffer
	expt_buf_header = read_buf_header (expt_buf_queue_ptr, MAX_MEM_BUF);
	expt_buf_len = get_buf_len((*expt_buf_header).field.BufDataLength);
	rslt_buf_len = get_buf_len(deq_msg_0.field0.BufDataLength);
	if (expt_buf_len != rslt_buf_len)
	{
		no_of_error = expt_buf_len;

		// DEBUG: Start debugging dump code
		debug_sec_test("*** ERROR: Expected output data length of 1st buffer is different from expectation ***\n\r");
		debug_sec_test("*** ERROR: expt_buf_len = 0x%08x; rstl_buf_len = 0x%08x ***\n", expt_buf_len, rslt_buf_len);
		// Add more dump code here
		// DEBUG: End debugging dump code

		acc_no_of_error += no_of_error;
		return acc_no_of_error; // Stop checking if length is different
	}
	else
	{
		no_of_error = chk_mem(CPU_OFFSET_ADDR+deq_msg_0.field0.DataAddr, (*expt_buf_header).field.BufDataAddr, expt_buf_len);
		// Note: in completion message output buffer pointer is for SEC to store
		// data, so need to add offset to access by CPU
		if (no_of_error > 0)
		{
			debug_sec_test("*** ERROR: Failed to check 1st buffer expected data ***\n");
		}
		acc_no_of_error += no_of_error;
	}

	// Check second buffer (only do when message length is larger than 32)
	if (cm_msg_type > 0)
	{
		expt_buf_header = read_buf_header (expt_buf_queue_ptr, MAX_MEM_BUF);
		expt_buf_len = get_buf_len((*expt_buf_header).field.BufDataLength);
		rslt_buf_len = get_buf_len(deq_msg_2.field2.NxtBufDataLength1 & 0x7fff);

		if (expt_buf_len != rslt_buf_len)
		{
			no_of_error = expt_buf_len;

			// DEBUG: Start debugging dump code
			debug_sec_test("*** ERROR: Expected output data length of 2nd buffer is different from expectation ***\n\r");
			debug_sec_test("*** ERROR: expt_buf_len = 0x%08x; rstl_buf_len = 0x%08x ***\n", expt_buf_len, rslt_buf_len);
			// Add more dump code here
			// DEBUG: End debugging dump code
			acc_no_of_error += no_of_error;
			return acc_no_of_error; // Stop checking if completion message is wrong
		}

		no_of_error = chk_mem(CPU_OFFSET_ADDR+deq_msg_2.field2.NxtDataAddr1, (*expt_buf_header).field.BufDataAddr, expt_buf_len);

		if (no_of_error > 0)
		{
			debug_sec_test("*** Failed to check 2nd expected buffer data ***\n\r");
		}
		acc_no_of_error += no_of_error;

		// Check the 3rd buffer
		rslt_buf_len = deq_msg_2.field2.NxtBufDataLength2 & 0x7fff;
		if (rslt_buf_len == 0x7800) //This means only 2 output buffer in this CM message
		{
			return acc_no_of_error;
		}

		rslt_buf_len = get_buf_len(rslt_buf_len);
		expt_buf_header = read_buf_header (expt_buf_queue_ptr, MAX_MEM_BUF);
		expt_buf_len = get_buf_len((*expt_buf_header).field.BufDataLength);

		if (expt_buf_len != rslt_buf_len)
		{
			no_of_error = expt_buf_len;

			// DEBUG: Start debugging dump code
			debug_sec_test("*** ERROR: Expected output data length of 3rd buffer is different from expectation ***\n\r");
			debug_sec_test("*** ERROR: expt_buf_len = 0x%08x; rstl_buf_len = 0x%08x ***\n", expt_buf_len, rslt_buf_len);
			// Add more dump code here
			// DEBUG: End debugging dump code

			acc_no_of_error += no_of_error;
			return acc_no_of_error; // Stop checking if completion message is wrong
		}

		no_of_error = chk_mem(CPU_OFFSET_ADDR+deq_msg_2.field2.NxtDataAddr2, (*expt_buf_header).field.BufDataAddr, expt_buf_len);

		if (no_of_error > 0)
		{
			debug_sec_test("*** Failed to check 3rd expected buffer data ***\n\r");
		}
		acc_no_of_error += no_of_error;

		// Check the 4th buffer
		rslt_buf_len = deq_msg_3.field3.NxtBufDataLength3 & 0x7fff;

		if (rslt_buf_len == 0x7800) //This means only 3 output buffers in this CM message
		{
			return acc_no_of_error;
		}
		rslt_buf_len = get_buf_len(rslt_buf_len);
		expt_buf_header = read_buf_header(expt_buf_queue_ptr, MAX_MEM_BUF);
		expt_buf_len = get_buf_len((*expt_buf_header).field.BufDataLength);
		if (expt_buf_len != rslt_buf_len)
		{
			no_of_error = expt_buf_len;

			// DEBUG: Start debugging dump code
			debug_sec_test("*** ERROR: Expected output data length of 4th buffer is different from expectation ***\n\r");
			debug_sec_test("*** ERROR: expt_buf_len = 0x%08x; rstl_buf_len = 0x%08x ***\n", expt_buf_len, rslt_buf_len);
			// Add more dump code here
			// DEBUG: End debugging dump code

			acc_no_of_error += no_of_error;
			return acc_no_of_error; // Stop checking if completion message is wrong
		}
		no_of_error = chk_mem(CPU_OFFSET_ADDR+deq_msg_3.field3.NxtDataAddr3, (*expt_buf_header).field.BufDataAddr, expt_buf_len);
		if (no_of_error > 0)
		{
			debug_sec_test("*** Failed to check 4th expected buffer data ***\n\r");
		}
		acc_no_of_error += no_of_error;

		// Check the 5th buffer
		if (cm_msg_type == 1) // Only does in case of w/o LL {
		{
			rslt_buf_len = (deq_msg_3.field3.NxtBufDataLength4) & 0x7fff;
			if (rslt_buf_len == 0x7800) //This means only 4 output buffers in this CM message
			{
				return acc_no_of_error;
			}
			rslt_buf_len = get_buf_len (rslt_buf_len);
			expt_buf_header = read_buf_header (expt_buf_queue_ptr, MAX_MEM_BUF);
			expt_buf_len = get_buf_len((*expt_buf_header).field.BufDataLength);
			if (expt_buf_len != rslt_buf_len)
			{
				no_of_error = expt_buf_len;

				// DEBUG: Start debugging dump code
				debug_sec_test("*** ERROR: Expected output data length of 5th buffer is different from expectation ***\n\r");
				debug_sec_test("*** ERROR: expt_buf_len = 0x%08x; rstl_buf_len = 0x%08x ***\n", expt_buf_len, rslt_buf_len);
				// Add more dump code here
				// DEBUG: End debugging dump code

				acc_no_of_error += no_of_error;
				return acc_no_of_error; // Stop checking if completion message is wrong
			}

			no_of_error = chk_mem(CPU_OFFSET_ADDR+deq_msg_3.field3.NxtDataAddr4, (*expt_buf_header).field.BufDataAddr, expt_buf_len);

			if (no_of_error > 0)
			{
				debug_sec_test("*** Failed to check 5th expected buffer data ***\n");
			}

			acc_no_of_error += no_of_error;
		}
	}

	// Check linked list buffers (only execute in case of linked list message)
	if (cm_msg_type > 1)
	{
		ll_ptr    = deq_msg_3.field3.NxtDataAddr4;
		ll_length = deq_msg_3.field3.NxtBufDataLength4 & 0xFF;
		for (i = 0; i < ll_length; i=i+2) // Read two pointer at one time
		{
			#ifdef PRINT_DBG_MSG
				debug_sec_test("ll_ptr = 0x%08x; ll_length = 0x%08x\n", ll_ptr, ll_length);
			#endif
			// Get 2 entriest (16 byte at once)
			ll_entry.raw[0] = READ32(CPU_OFFSET_ADDR+ll_ptr);
			ll_entry.raw[1] = READ32(CPU_OFFSET_ADDR+ll_ptr+0x4);
			ll_entry.raw[2] = READ32(CPU_OFFSET_ADDR+ll_ptr+0x8);
			ll_entry.raw[3] = READ32(CPU_OFFSET_ADDR+ll_ptr+0xc);
			ll_ptr += 16; // Update linked list pointer

			// Check 1st entry
			expt_buf_header = read_buf_header(expt_buf_queue_ptr, MAX_MEM_BUF);
			expt_buf_len = get_buf_len((*expt_buf_header).field.BufDataLength);
			//rslt_buf_len = get_buf_len(ll_entry.field2.NxtBufDataLength1);
			rslt_buf_len = get_buf_len(ll_entry.field0.BufDataLength);
			if (expt_buf_len != rslt_buf_len)
			{
				no_of_error = expt_buf_len;

				// DEBUG: Start debugging dump code
				debug_sec_test("*** ERROR: Expected output data length of linked list buffer entry %d is different from expectation ***\n", i);
				debug_sec_test("*** ERROR: expt_buf_len = 0x%08x; rstl_buf_len = 0x%08x\n", expt_buf_len, rslt_buf_len);
				// Add more dump code here for debugging
				// DEBUG: End debugging dump code

				acc_no_of_error += no_of_error;
				return acc_no_of_error; // Stop checking if completion message is wrong
			}

			no_of_error = chk_mem(CPU_OFFSET_ADDR+ll_entry.field2.NxtDataAddr1, (*expt_buf_header).field.BufDataAddr, expt_buf_len);

			if (no_of_error > 0)
			{
				debug_sec_test("*** Failed to check linked list expected buffer data ***\n\r");
			}
			acc_no_of_error += no_of_error;
			// Check 2nd entry
			if (i+1 < ll_length)
			{
				expt_buf_header = read_buf_header(expt_buf_queue_ptr, MAX_MEM_BUF);
				expt_buf_len = get_buf_len((*expt_buf_header).field.BufDataLength);
				rslt_buf_len = get_buf_len(ll_entry.field2.NxtBufDataLength2);
				if (expt_buf_len != rslt_buf_len)
				{
					no_of_error = expt_buf_len;

					// DEBUG: Start debugging dump code
					debug_sec_test("*** ERROR: Expected output data length of linked list buffer entry %d is different from expectation ***\n", i+1);
					debug_sec_test("*** ERROR: expt_buf_len = 0x%08x; rstl_buf_len = 0x%08x\n", expt_buf_len, rslt_buf_len);
					// Add more dump code here for debugging
					// DEBUG: End debugging dump code

					acc_no_of_error += no_of_error;
					return acc_no_of_error; // Stop checking if completion message is wrong
				}
				no_of_error = chk_mem(CPU_OFFSET_ADDR+ll_entry.field2.NxtDataAddr2, (*expt_buf_header).field.BufDataAddr, expt_buf_len);
				if (no_of_error > 0)
				{
					debug_sec_test("*** Failed to check linked list expected buffer data ***\n\r");
				}
				acc_no_of_error += no_of_error;
			}
		}
	}

//	// Check de-allocation message (SEC specific);
//	// For now simply dump out to debug, have not checked
//	#ifdef DUMP_DEALLOT_MSG
//		read_deallot_msg(FPQID0, &deq_msg_0);
//		for (i = 0; i < 4; i++)
//		{
//			debug_sec_test(" *** De-allot MSG Word[%d] = 0x%08x\n", i, deq_msg_0.raw[i]);
//		}
//	#endif

	#ifdef PRINT_DBG_MSG
		debug_sec_test(" *** End chk_result ***\n");
	#endif

	return acc_no_of_error;
}

//int get_result(buf_header_queue *expt_buf_queue_ptr, buf_header_queue *expt_tkn_queue_ptr, //ldinh: modified for measure performance
//               buf_header_queue *expt_deallot_queue_ptr, buf_header_queue *expt_cm_queue_ptr,
//               int qid, short chk_mode)
//{
//	int no_of_error;
//	int acc_no_of_error;
//	int cm_msg_type;
//	int expt_buf_len;
//	int rslt_buf_len;
//
//	unsigned long long ll_ptr;
//	int ll_length;
//	msg_16b_t ll_entry;
//
//	int i;
//
//	buf_header* expt_msg_header;
//	buf_header* expt_buf_header;
//
//	msg_16b_t deq_msg_0, deq_msg_1, deq_msg_2, deq_msg_3;
//
//	no_of_error = 0;
//	acc_no_of_error = 0;
//
//	//*** Start chk_result ***
//
//	cm_msg_type = read_cm_msg(qid, &deq_msg_0, &deq_msg_1, &deq_msg_2, &deq_msg_3);
//
//	// Check completion message
//	if (chk_mode != 0)
//	{
//		no_of_error = chk_cm_msg(qid, (*expt_msg_header).field.BufDataAddr, cm_msg_type);
//	}
//
//	if (cm_msg_type == 0)
//	{
//		alternate_dequeue(qid, 1);
//	}
//	else
//	{
//		alternate_dequeue (qid, 2);
//	}
//
////	if (no_of_error > 0)
////	{
////		//debug_sec_test("*** ERROR: Failed to check completion message ***\n");
////		acc_no_of_error += no_of_error;
////		return acc_no_of_error; // Stop checking if completion message is wrong
////	}
////
////	// Check result token (SEC specific)
////	expt_buf_header = read_buf_header(expt_tkn_queue_ptr, MAX_MEM_BUF);
////	//no_of_error = chk_rslt_tkn(&deq_msg_1, (*expt_buf_header).field.BufDataAddr, (*expt_buf_header).field.BufDataLength);
////	//acc_no_of_error += no_of_error;
////
////	// Check output data
////	// First check 1st buffer
////	expt_buf_header = read_buf_header (expt_buf_queue_ptr, MAX_MEM_BUF);
////	expt_buf_len = get_buf_len((*expt_buf_header).field.BufDataLength);
////	rslt_buf_len = get_buf_len(deq_msg_0.field0.BufDataLength);
////	if (expt_buf_len != rslt_buf_len)
////	{
////		no_of_error = expt_buf_len;
////
////		// DEBUG: Start debugging dump code
////		//debug_sec_test("*** ERROR: Expected output data length of 1st buffer is different from expectation ***\n\r");
////		//debug_sec_test("*** ERROR: expt_buf_len = 0x%08x; rstl_buf_len = 0x%08x ***\n", expt_buf_len, rslt_buf_len);
////		// Add more dump code here
////		// DEBUG: End debugging dump code
////
////		acc_no_of_error += no_of_error;
////		return acc_no_of_error; // Stop checking if length is different
////	}
////	else
////	{
////		//no_of_error = chk_mem(deq_msg_0.field0.DataAddr, (*expt_buf_header).field.BufDataAddr, expt_buf_len);
////		// Note: in completion message output buffer pointer is for SEC to store
////		// data, so need to add offset to access by CPU
////		if (no_of_error > 0)
////		{
////			//debug_sec_test("*** ERROR: Failed to check 1st buffer expected data ***\n");
////		}
////		acc_no_of_error += no_of_error;
////	}
////
////	// Check second buffer (only do when message length is larger than 32)
////	if (cm_msg_type > 0)
////	{
////		expt_buf_header = read_buf_header (expt_buf_queue_ptr, MAX_MEM_BUF);
////		expt_buf_len = get_buf_len((*expt_buf_header).field.BufDataLength);
////		rslt_buf_len = get_buf_len(deq_msg_2.field2.NxtBufDataLength1 & 0x7fff);
////
////		if (expt_buf_len != rslt_buf_len)
////		{
////			no_of_error = expt_buf_len;
////
////			// DEBUG: Start debugging dump code
////			//debug_sec_test("*** ERROR: Expected output data length of 2nd buffer is different from expectation ***\n\r");
////			//debug_sec_test("*** ERROR: expt_buf_len = 0x%08x; rstl_buf_len = 0x%08x ***\n", expt_buf_len, rslt_buf_len);
////			// Add more dump code here
////			// DEBUG: End debugging dump code
////			acc_no_of_error += no_of_error;
////			return acc_no_of_error; // Stop checking if completion message is wrong
////		}
////
////		//no_of_error = chk_mem(deq_msg_2.field2.NxtDataAddr1, (*expt_buf_header).field.BufDataAddr, expt_buf_len);
////
////		if (no_of_error > 0)
////		{
////			//debug_sec_test("*** Failed to check 2nd expected buffer data ***\n\r");
////		}
////		acc_no_of_error += no_of_error;
////
////		// Check the 3rd buffer
////		rslt_buf_len = deq_msg_2.field2.NxtBufDataLength2 & 0x7fff;
////		if (rslt_buf_len == 0x7800) //This means only 2 output buffer in this CM message
////		{
////			return acc_no_of_error;
////		}
////
////		rslt_buf_len = get_buf_len(rslt_buf_len);
////		expt_buf_header = read_buf_header (expt_buf_queue_ptr, MAX_MEM_BUF);
////		expt_buf_len = get_buf_len((*expt_buf_header).field.BufDataLength);
////
////		if (expt_buf_len != rslt_buf_len)
////		{
////			no_of_error = expt_buf_len;
////
////			// DEBUG: Start debugging dump code
////			//debug_sec_test("*** ERROR: Expected output data length of 3rd buffer is different from expectation ***\n\r");
////			//debug_sec_test("*** ERROR: expt_buf_len = 0x%08x; rstl_buf_len = 0x%08x ***\n", expt_buf_len, rslt_buf_len);
////			// Add more dump code here
////			// DEBUG: End debugging dump code
////
////			acc_no_of_error += no_of_error;
////			return acc_no_of_error; // Stop checking if completion message is wrong
////		}
////
////		//no_of_error = chk_mem(deq_msg_2.field2.NxtDataAddr2, (*expt_buf_header).field.BufDataAddr, expt_buf_len);
////
////		if (no_of_error > 0)
////		{
////			//debug_sec_test("*** Failed to check 3rd expected buffer data ***\n\r");
////		}
////		acc_no_of_error += no_of_error;
////
////		// Check the 4th buffer
////		rslt_buf_len = deq_msg_3.field3.NxtBufDataLength3 & 0x7fff;
////
////		if (rslt_buf_len == 0x7800) //This means only 3 output buffers in this CM message
////		{
////			return acc_no_of_error;
////		}
////		rslt_buf_len = get_buf_len(rslt_buf_len);
////		expt_buf_header = read_buf_header(expt_buf_queue_ptr, MAX_MEM_BUF);
////		expt_buf_len = get_buf_len((*expt_buf_header).field.BufDataLength);
////		if (expt_buf_len != rslt_buf_len)
////		{
////			no_of_error = expt_buf_len;
////
////			// DEBUG: Start debugging dump code
////			//debug_sec_test("*** ERROR: Expected output data length of 4th buffer is different from expectation ***\n\r");
////			//debug_sec_test("*** ERROR: expt_buf_len = 0x%08x; rstl_buf_len = 0x%08x ***\n", expt_buf_len, rslt_buf_len);
////			// Add more dump code here
////			// DEBUG: End debugging dump code
////
////			acc_no_of_error += no_of_error;
////			return acc_no_of_error; // Stop checking if completion message is wrong
////		}
////		//no_of_error = chk_mem(deq_msg_3.field3.NxtDataAddr3, (*expt_buf_header).field.BufDataAddr, expt_buf_len);
////		if (no_of_error > 0)
////		{
////			//debug_sec_test("*** Failed to check 4th expected buffer data ***\n\r");
////		}
////		acc_no_of_error += no_of_error;
////
////		// Check the 5th buffer
////		if (cm_msg_type == 1) // Only does in case of w/o LL {
////		{
////			rslt_buf_len = (deq_msg_3.field3.NxtBufDataLength4) & 0x7fff;
////			if (rslt_buf_len == 0x7800) //This means only 4 output buffers in this CM message
////			{
////				return acc_no_of_error;
////			}
////			rslt_buf_len = get_buf_len (rslt_buf_len);
////			expt_buf_header = read_buf_header (expt_buf_queue_ptr, MAX_MEM_BUF);
////			expt_buf_len = get_buf_len((*expt_buf_header).field.BufDataLength);
////			if (expt_buf_len != rslt_buf_len)
////			{
////				no_of_error = expt_buf_len;
////
////				// DEBUG: Start debugging dump code
////				//debug_sec_test("*** ERROR: Expected output data length of 5th buffer is different from expectation ***\n\r");
////				//debug_sec_test("*** ERROR: expt_buf_len = 0x%08x; rstl_buf_len = 0x%08x ***\n", expt_buf_len, rslt_buf_len);
////				// Add more dump code here
////				// DEBUG: End debugging dump code
////
////				acc_no_of_error += no_of_error;
////				return acc_no_of_error; // Stop checking if completion message is wrong
////			}
////
////			//no_of_error = chk_mem(deq_msg_3.field3.NxtDataAddr4, (*expt_buf_header).field.BufDataAddr, expt_buf_len);
////
////			if (no_of_error > 0)
////			{
////				//debug_sec_test("*** Failed to check 5th expected buffer data ***\n");
////			}
////
////			acc_no_of_error += no_of_error;
////		}
////	}
////
////	// Check linked list buffers (only execute in case of linked list message)
////	if (cm_msg_type > 1)
////	{
////		ll_ptr    = deq_msg_3.field3.NxtDataAddr4;
////		ll_length = deq_msg_3.field3.NxtBufDataLength4 & 0xFF;
////		for (i = 0; i < ll_length; i=i+2) // Read two pointer at one time
////		{
////			//#ifdef PRINT_DBG_MSG
////			//	debug_sec_test("ll_ptr = 0x%08x; ll_length = 0x%08x\n", ll_ptr, ll_length);
////			//#endif
////			// Get 2 entriest (16 byte at once)
////			ll_entry.raw[0] = READ32(ll_ptr);
////			ll_entry.raw[1] = READ32(ll_ptr+0x4);
////			ll_entry.raw[2] = READ32(ll_ptr+0x8);
////			ll_entry.raw[3] = READ32(ll_ptr+0xc);
////			ll_ptr += 16; // Update linked list pointer
////
////			// Check 1st entry
////			expt_buf_header = read_buf_header(expt_buf_queue_ptr, MAX_MEM_BUF);
////			expt_buf_len = get_buf_len((*expt_buf_header).field.BufDataLength);
////			//rslt_buf_len = get_buf_len(ll_entry.field2.NxtBufDataLength1);
////			rslt_buf_len = get_buf_len(ll_entry.field0.BufDataLength);
////			if (expt_buf_len != rslt_buf_len)
////			{
////				no_of_error = expt_buf_len;
////
////				// DEBUG: Start debugging dump code
////				//debug_sec_test("*** ERROR: Expected output data length of linked list buffer entry %d is different from expectation ***\n", i);
////				//debug_sec_test("*** ERROR: expt_buf_len = 0x%08x; rstl_buf_len = 0x%08x\n", expt_buf_len, rslt_buf_len);
////				// Add more dump code here for debugging
////				// DEBUG: End debugging dump code
////
////				acc_no_of_error += no_of_error;
////				return acc_no_of_error; // Stop checking if completion message is wrong
////			}
////
////			//no_of_error = chk_mem(ll_entry.field2.NxtDataAddr1, (*expt_buf_header).field.BufDataAddr, expt_buf_len);
////
////			if (no_of_error > 0)
////			{
////				//debug_sec_test("*** Failed to check linked list expected buffer data ***\n\r");
////			}
////			acc_no_of_error += no_of_error;
////			// Check 2nd entry
////			if (i+1 < ll_length)
////			{
////				expt_buf_header = read_buf_header(expt_buf_queue_ptr, MAX_MEM_BUF);
////				expt_buf_len = get_buf_len((*expt_buf_header).field.BufDataLength);
////				rslt_buf_len = get_buf_len(ll_entry.field2.NxtBufDataLength2);
////				if (expt_buf_len != rslt_buf_len)
////				{
////					no_of_error = expt_buf_len;
////
////					//debug_sec_test("*** ERROR: Expected output data length of linked list buffer entry %d is different from expectation ***\n", i+1);
////					//debug_sec_test("*** ERROR: expt_buf_len = 0x%08x; rstl_buf_len = 0x%08x\n", expt_buf_len, rslt_buf_len);
////
////					acc_no_of_error += no_of_error;
////					return acc_no_of_error; // Stop checking if completion message is wrong
////				}
////				//no_of_error = chk_mem(CPU_OFFSET_ADDR+ll_entry.field2.NxtDataAddr2, (*expt_buf_header).field.BufDataAddr, expt_buf_len);
////				if (no_of_error > 0)
////				{
////					//debug_sec_test("*** Failed to check linked list expected buffer data ***\n\r");
////				}
////				acc_no_of_error += no_of_error;
////			}
////		}
////	}
//
//	return acc_no_of_error;
//}
//
//
void write_buf_num_header(sec_buf_num_header_queue* queue_ptr, unsigned char core_type, unsigned char num_of_buf)
{
	unsigned int write_pos, no_of_entry;
	sec_buf_num_header write_header;

	write_header.associate_crypto_core = core_type;
	write_header.num_of_buf = num_of_buf;

	write_pos = (*queue_ptr).queue_tail;
	no_of_entry = (*queue_ptr).no_of_entry;
	#ifdef PRINT_DBG_MSG
		debug_sec_test("write_: write_pos = 0x%08x; no_of_entry = 0x%08x; max_ptr = 0x%08x\n", write_pos, no_of_entry, MAX_MEM_BUF);
	#endif
	(*queue_ptr).buf_num_header_ptr[write_pos] = write_header;
	write_pos++;
	if (write_pos == MAX_MEM_BUF)
	{
		write_pos = 0;
	}
	no_of_entry++;
	(*queue_ptr).queue_tail = write_pos;
	(*queue_ptr).no_of_entry = no_of_entry;
}


void load_sec_in_ctx_tkn(mem_array_header_queue* ctx_array_header_queue_ptr,
                         mem_array_header_queue* in_tkn_array_header_queue_ptr,
                         sec_buf_num_header_queue* in_buf_num_queue_ptr,
                         unsigned long long* tkn_mem_addr_ptr, unsigned char ctx_reuse_md,unsigned short in_tkn_offset)
{
	int num_of_array, i;
	unsigned long long mem_addr;
	unsigned long long mem_len;
	unsigned char crypto_core_type;


	num_of_array = (*ctx_array_header_queue_ptr).no_of_entry;

	debug_sec_test("\nnum_of_array = 0x%08x\n", num_of_array);

	for (i = 0; i < num_of_array; i++)
	{
		mem_len = (*ctx_array_header_queue_ptr).mem_array_header_ptr[i].mem_len;
		mem_addr = alot_mem(in_ctx_mem_manager_ptr, mem_len, A_32BYTE);
		//mem_addr = alot_mem(in_ctx_mem_manager_ptr, 0x100, A_32BYTE); // Allocate 256byte for sure
		//Check if not enough allowed memory
		if (mem_addr == 0)
		{
			debug_sec_test("[load_sec_in_ctx_tkn] [WARNING]: Not enough memory. ");
			debug_sec_test("Trying to de-allocate from the begin of allocated entry. ");
			debug_sec_test("Some data-in-used may be overwritten\n");
		}

		while(mem_addr == 0) // Try to de-allocate till can get enough free-memory
		{
			if (dlot_mem(in_ctx_mem_manager_ptr) == 0) // This case happen when try to deallocate when no entry to de-allocate
			{
				debug_sec_test("FATAL ERROR: Canot allocate memory!!!\n\r");
				return;
			}
			mem_addr = alot_mem(in_ctx_mem_manager_ptr, 0x100, A_32BYTE); // Allocate 256byte for sure
		}

		load_mem(mem_addr, mem_len, (*ctx_array_header_queue_ptr).mem_array_header_ptr[i].mem_array_ptr);
		//dump_mem(mem_addr, mem_len);

		//// This code is to adjust context pointer in input token
		//// Currently has not care context re-use
		crypto_core_type = ((*in_buf_num_queue_ptr).buf_num_header_ptr[i]).associate_crypto_core;
		if (crypto_core_type == XTS_CORE_TYPE)
		{
			((*in_tkn_array_header_queue_ptr).mem_array_header_ptr[i].mem_array_ptr)[0] =
					((*in_tkn_array_header_queue_ptr).mem_array_header_ptr[i].mem_array_ptr)[0] & 0xff807FFF; // Clear bit 22:15
			((*in_tkn_array_header_queue_ptr).mem_array_header_ptr[i].mem_array_ptr)[0] =
					((*in_tkn_array_header_queue_ptr).mem_array_header_ptr[i].mem_array_ptr)[0] | ((unsigned int)((mem_addr >> 21) & 0x007f8000));
			((*in_tkn_array_header_queue_ptr).mem_array_header_ptr[i].mem_array_ptr)[1] = (unsigned int)((mem_addr >> 4)&0xffffffff);
			#ifdef PRINT_DBG_MSG
				debug_sec_test("Adjusted context pointer for XTS token\n\r");
			#endif
		}
		else //EIP96 or EIP62, in this case, to distinguish, we need to check token len, if token is 16 then it's EIP96
		{
			if(((*in_tkn_array_header_queue_ptr).mem_array_header_ptr[i].mem_len) == 16) // EIP62
			{
				((*in_tkn_array_header_queue_ptr).mem_array_header_ptr[i].mem_array_ptr)[2] = (unsigned int)((mem_addr >> 14) & 0x0fC00000);
				((*in_tkn_array_header_queue_ptr).mem_array_header_ptr[i].mem_array_ptr)[1] = (unsigned int)((mem_addr >> 4) & 0xffffffff);

				#ifdef PRINT_DBG_MSG
					debug_sec_test("Adjusted context pointer for EIP62 token\n\r");
				#endif
			}
			else // EIP96
			{
				((*in_tkn_array_header_queue_ptr).mem_array_header_ptr[i].mem_array_ptr)[2] = (unsigned int)((mem_addr >> 36) & 0x0000003f);
				((*in_tkn_array_header_queue_ptr).mem_array_header_ptr[i].mem_array_ptr)[3] = (unsigned int)((mem_addr >> 4) & 0xffffffff);

				#ifdef PRINT_DBG_MSG
					debug_sec_test("Adjusted context pointer for EIP96 token\n\r");
				#endif
			}
		}
	}

	debug_sec_test(" *** End loading context ***\n\r");
	debug_sec_test("\n\r *** Start loading token***\n\r");
	load_in_array_mem(in_tkn_array_header_queue_ptr, in_tkn_mem_manager_ptr, tkn_mem_addr_ptr, 0, A_32BYTE, in_tkn_offset);
	debug_sec_test("\n\r *** End loading token***\n\r");
}

void  load_sec_in_data(mem_array_header_queue* in_data_array_header_queue_ptr, queue_mem_manager* in_data_mem_manager_ptr,
						unsigned long long* in_data_addr_ptr, unsigned short* in_data_len_ptr, MEM_ALIGN_CODE align_code)
{
	debug_sec_test("\n\r *** Start loading input data ***\n\r");
	load_in_array_mem(in_data_array_header_queue_ptr, in_data_mem_manager_ptr,
						in_data_addr_ptr, in_data_len_ptr, align_code, 0); // For data, no offset if is required as input token
	debug_sec_test("\n\r *** End loading input data ***\n\r");
}

void load_sec_exp_tkn(mem_array_header_queue* exp_tkn_array_header_queue_ptr, queue_mem_manager* exp_tkn_mem_manager_ptr,
						buf_header_queue *expt_tkn_buf_queue_ptr, MEM_ALIGN_CODE align_code)
{
	debug_sec_test("\n\r *** Start loading expected token ***\n\r");
	load_exp_array_mem(exp_tkn_array_header_queue_ptr, exp_tkn_mem_manager_ptr,
						expt_tkn_buf_queue_ptr, align_code);
	debug_sec_test("\n\r *** End   loading expected token ***\n\r");
}

void load_sec_exp_data(mem_array_header_queue* exp_data_array_header_queue_ptr, queue_mem_manager* exp_data_mem_manager_ptr,
						buf_header_queue *expt_data_buf_queue_ptr, MEM_ALIGN_CODE align_code)
{
	debug_sec_test("\n\r *** Start loading expected data ***\n\r");
	load_exp_array_mem(exp_data_array_header_queue_ptr, exp_data_mem_manager_ptr,
						expt_data_buf_queue_ptr, align_code);
	debug_sec_test("\n\r *** End   loading expected data ***\n\r");
}

#endif /*____SEC_TEST_C__*/

