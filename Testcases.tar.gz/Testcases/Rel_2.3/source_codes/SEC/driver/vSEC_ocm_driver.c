#ifndef __vSEC_OCM_DRIVER_C__
#define __vSEC_OCM_DRIVER_C__

#include "../include/vSEC_ocm_driver.h"
#include "armv8.h"

void init_ocm(void)
{
	int i;

	debug_vsec_ocm_drv("\n%s\n", __FUNCTION__);

	WRITE32(CRCSR_OCM_CLKEN_REG, RD_MEM32(CRCSR_OCM_CLKEN_REG) & (~OCM_CLKEN_BIT) | (~OCM_CSR_CLKEN_BIT));  //OCM clock enable
	arch_timer_msdelay(50);
	WRITE32(CRCSR_OCM_CLKEN_REG, RD_MEM32(CRCSR_OCM_CLKEN_REG) | OCM_CLKEN_BIT | OCM_CSR_CLKEN_BIT);  //OCM clock enable

	WRITE32(CRCSR_OCM_SRST_REG, RD_MEM32(CRCSR_OCM_SRST_REG) | OCM_CLKEN_BIT | OCM_CSR_CLKEN_BIT);
	arch_timer_msdelay(50);
	WRITE32(CRCSR_OCM_SRST_REG, RD_MEM32(CRCSR_OCM_SRST_REG) & (~OCM_RESET_BIT) & (~OCM_CSR_RESET_BIT));  //OCM reset

	debug_vsec_ocm_drv("\n%s: CRCSR_OCM_CLKEN_REG: 0x%08x\n", __FUNCTION__, RD_MEM32(CRCSR_OCM_CLKEN_REG));
	debug_vsec_ocm_drv("\n%s: CRCSR_OCM_SRST_REG: 0x%08x\n", __FUNCTION__, RD_MEM32(CRCSR_OCM_SRST_REG));
};

#endif /*__vSEC_OCM_DRIVER_C__*/
