#ifndef __vSEC_MEM_MANAGER_C__
#define __vSEC_MEM_MANAGER_C__

#include "../include/vSEC_globals.h"
#include "../include/vSEC_qm_driver.h"
#include "../include/vSEC_mem_manager.h"
#include "armv8.h"

//Tinh-SLT:
//real function here
#define load_mem load_mem_slt_sec
#define dump_mem dump_mem_slt_sec

void init_queue_mem_manager(queue_mem_manager* mem_manager, unsigned long long start_base, unsigned long long mem_len)
{
	int i;

	(*mem_manager).mem_start = start_base; // This should be un-changed till next initialized time
	(*mem_manager).mem_len  = mem_len;    // This should be un-changed till next initialized time
	(*mem_manager).alot_base = start_base;
	(*mem_manager).free_len = mem_len;
	(*mem_manager).alot_pos = 0;
	(*mem_manager).dlot_pos = 0; //No buffer to deallocated at first
	(*mem_manager).num_of_entry = 0;

	for (i = 0; i < MAX_MEM_BUF; i++)
	{
		(*mem_manager).alot_entry[i] = 0;
	}
}

unsigned int get_mem_align(unsigned long long mem_addr, MEM_ALIGN_CODE  align_code)
{
	unsigned int align_len;

	switch (align_code)
	{
	case A_BYTE :
		align_len = 0;
		break;
	case A_4BYTE :
		align_len = (0x04-(mem_addr & 0x03)) & 0x03;
		break;
	case A_8BYTE :
		align_len = (0x08-(mem_addr & 0x07)) & 0x07;
		break;
	case A_16BYTE :
		align_len = (0x10-(mem_addr & 0x0f)) & 0x0f;
		break;
	case A_32BYTE :
		align_len = (0x20 - (mem_addr & 0x1f)) & 0x1f;
		break;
	case A_64BYTE :
		align_len = (0x40 - (mem_addr & 0x3f)) & 0x3f;
		break;
	case A_128BYTE :
		align_len = (0x80 - (mem_addr & 0x7f)) & 0x7f;
		break;
	default :
		align_len = 0;
		break;
	}
	return align_len;
}

unsigned long long alot_mem(queue_mem_manager* mem_manager, unsigned long long mem_len, MEM_ALIGN_CODE align_code)
{
	unsigned int align_len;
	unsigned long long alot_addr;
	unsigned long long alot_len;
	unsigned long long pos;

	#ifdef PRINT_DBG_MSG
		debug_vsec_mem_manager ("========= alot_mem: alot_base = 0x%08x\n\r", (*mem_manager).alot_base);
	#endif

	// Availability checking
	if ((*mem_manager).num_of_entry == MAX_MEM_BUF)
	{
		debug_vsec_mem_manager("\nalot_mem: allocate memory is failed\n");
		return 0;  // This means failed to allocate memory
	}
	align_len = get_mem_align((*mem_manager).alot_base, align_code);
	alot_len = mem_len + align_len; // align_len is number of byte needs to be skipped so that the returned based address is aligned
	if ((*mem_manager).free_len < alot_len)
	{
		debug_vsec_mem_manager("\nalot_mem: Free length is not enough\n");
		return 0; // Free length is not enough
	}

	// Specify returned address
	alot_addr = (*mem_manager).alot_base + align_len;

	// Check if memory space is wrap-arround
	if ((alot_addr + mem_len) > ((*mem_manager).mem_start + (*mem_manager).mem_len))
	{
		#ifdef PRINT_DBG_MSG
			debug_vsec_mem_manager("Info: Detected wrap-around condition!\n\r");
		#endif

		// Intentionally modify the length of previous allocated buffer so that allocate pointer is reset to start point
		alot_len = align_len + ((*mem_manager).mem_start + (*mem_manager).mem_len - alot_addr);
		pos = (*mem_manager).alot_pos - 1;
		(*mem_manager).alot_entry[pos] += alot_len;
		(*mem_manager).alot_base = (*mem_manager).mem_start;

		return 0; // Can not allocate
	}

	// Update control info.
	(*mem_manager).alot_base += alot_len;
	if ((*mem_manager).alot_base == ((*mem_manager).mem_start + (*mem_manager).mem_len)) // Wrap-around
	{
		(*mem_manager).alot_base = (*mem_manager).mem_start;
	}

	(*mem_manager).free_len  -= alot_len;
	pos = (*mem_manager).alot_pos;
	(*mem_manager).alot_entry[pos] = alot_len; // Save length of allocated len (may larger then requested length)
	pos++;

	if(pos == MAX_MEM_BUF)
	{
		pos = 0;
	}
	(*mem_manager).alot_pos = pos;
	(*mem_manager).num_of_entry ++;

	return alot_addr;
}

int dlot_mem(queue_mem_manager* mem_manager)
{
	unsigned long long pos;
	if ((*mem_manager).num_of_entry == 0)
	{
		return 0; // Nothing to de-allocate
	}

	pos = (*mem_manager).dlot_pos;
	(*mem_manager).free_len += (*mem_manager).alot_entry[pos];
	pos++;

	if(pos == MAX_MEM_BUF)
	{
		pos = 0;
	}

	(*mem_manager).dlot_pos = pos;
	(*mem_manager).num_of_entry--;
	return 1;
}

unsigned long long alot_free_mem(queue_mem_manager* mem_manager, unsigned long long mem_len, MEM_ALIGN_CODE align_code)
{
	unsigned long long mem_addr;

	while ((mem_addr = alot_mem(mem_manager, mem_len, align_code)) == 0)
	{
		debug_vsec_mem_manager("Can not allocate memory, trying to de-allocate previously allocated mem \n\r");
		if (dlot_mem(mem_manager) == 0)
		{
			// This case happen when try to deallocate when no entry to de-allocate
			debug_vsec_mem_manager("FATAL ERROR: Can not allocate memory b/c requested size is too big!!");
			debug_vsec_mem_manager("Requested size = 0x%08x; Memory size = 0x%08x", mem_len, (*mem_manager).mem_len);
			return 0;
		}
	}

	return mem_addr;
}

int gen_buf_len_code (unsigned long long buf_len, BUF_TYPE_CODE buf_type)
{
  int buf_code;
  switch (buf_type)
  {
    case B_16KB:
		if (buf_len > QM_BDL_16KB)
		{
			debug_vsec_mem_manager("ERROR: Buffer length is over 16KB !\n\r");
			buf_code = -1;
		}
		else if (buf_len == QM_BDL_16KB)
		{
			buf_code = 0;
		}
		else
		{
			buf_code = buf_len;
		}
		break;
    case B_4KB:
		if (buf_len > QM_BDL_4KB)
		{
			debug_vsec_mem_manager("ERROR: Buffer length is over 4KB !\n\r");
			buf_code = -1;
		}
		else if (buf_len == QM_BDL_4KB)
		{
			buf_code = (4 << 12);
		}
		else
		{
			buf_code = buf_len | (4 << 12);
		}
		break;
    case B_2KB:
		if (buf_len > QM_BDL_2KB)
		{
			debug_vsec_mem_manager("ERROR: Buffer length is over 2KB !\n\r");
			buf_code = -1;
		}
		else
		{
			buf_code = buf_len | (5 << 12);
		}
		break;
    case B_1KB:
		if (buf_len > QM_BDL_1KB)
		{
			debug_vsec_mem_manager("ERROR: Buffer length is over 1KB !\n\r");
			buf_code = -1;
		}
		else
		{
			buf_code = buf_len | (6 << 12);
		}
		break;
    case B_256B:
		if (buf_len > QM_BDL_256B)
		{
			debug_vsec_mem_manager("ERROR: Buffer length is over 256B !\n\r");
			buf_code = -1;
		}
		else
		{
			buf_code = buf_len | (7 << 12);
		}
		break;
    default: // Fixed assignement
		if (buf_len > QM_BDL_16KB)
		{
			debug_vsec_mem_manager("ERROR: Buffer length is over 16KB !\n\r");
			buf_code = -1;
		}
		else if (buf_len == QM_BDL_16KB)
		{
			buf_code = 0;
		}
		else if ((buf_len < QM_BDL_16KB) & (buf_len > QM_BDL_4KB))
		{
			buf_code = buf_len;
		}
		else if (buf_len == QM_BDL_4KB)
		{
			buf_code = (4 << 12);
		}
		else if ((buf_len < QM_BDL_4KB) & (buf_len > QM_BDL_2KB))
		{
			buf_code = buf_len | (4 << 12);
		}
		else if ((buf_len <= QM_BDL_2KB) & (buf_len > QM_BDL_1KB))
		{
			buf_code = buf_len | (5 << 12);
		}
		else if ((buf_len <= QM_BDL_1KB) & (buf_len > QM_BDL_256B))
		{
			buf_code = buf_len | (6 << 12);
		}
		else
		{
			buf_code = buf_len | (7 << 12);
		}
		break;
  }
  return buf_code;
}


unsigned long long gen_rand_buf_len_code(unsigned long long buf_len)
{
	BUF_TYPE_CODE buf_type;

	if (rand() % 2)
	{
		buf_type = B_FIT;
	}
	else if (buf_len > QM_BDL_16KB)
	{
		debug_vsec_mem_manager("FATAL ERROR: Buffer length is over 16KB !\n\r");
		buf_type = B_FIT;
	}
	else if ((buf_len <= QM_BDL_16KB) & (buf_len > QM_BDL_4KB))
	{
		buf_type = rand() % 2;
		switch(buf_type)
		{
			case 0:
				buf_type = B_16KB;
				break;
			default:
				buf_type = B_FIT;
				break;
		}
	}
	else if ((buf_len <= QM_BDL_4KB) & (buf_len > QM_BDL_2KB))
	{
		buf_type = rand() % 3;
		switch(buf_type)
		{
		case 0:
			buf_type = B_16KB;
			break;
		case 1:
			buf_type = B_4KB;
			break;
		default:
			buf_type = B_FIT;
			break;
		}
	}
	else if ((buf_len <= QM_BDL_2KB) & (buf_len > QM_BDL_1KB))
	{
		buf_type = rand() % 4;
		switch(buf_type)
		{
			case 0:
				buf_type = B_16KB;
				break;
			case 1:
				buf_type = B_4KB;
				break;
			case 2:
				buf_type = B_2KB;
				break;
			default:
				buf_type = B_FIT;
				break;
		}
	}
	else if ((buf_len <= QM_BDL_1KB) & (buf_len > QM_BDL_256B))
	{
		buf_type = rand() % 5;
		switch(buf_type)
		{
			case 0:
				buf_type = B_16KB;
				break;
			case 1:
				buf_type = B_4KB;
				break;
			case 2:
				buf_type = B_2KB;
				break;
			case 3:
				buf_type = B_1KB;
				break;
			default:
				buf_type = B_FIT;
				break;
		}
	}
	else
	{
		buf_type = rand() % 5;
		switch(buf_type)
		{
			case 0:
				buf_type = B_16KB;
				break;
			case 1:
				buf_type = B_4KB;
				break;
			case 2:
				buf_type = B_2KB;
				break;
			case 3:
				buf_type = B_1KB;
				break;
			case 4:
				buf_type = B_256B;
				break;
			default:
				buf_type = B_FIT;
				break;
		}
	}

	return gen_buf_len_code(buf_len, buf_type);
}

unsigned long long get_buf_len (unsigned long long buf_len_code)
{
	int buf_len;

	if (((buf_len_code >> 14) & 0x1) == 0x0) //16KB
	{
		if ((buf_len_code & 0x3fff) == 0x0)
		{
			buf_len = 0x4000;
		}
		else
		{
			buf_len = buf_len_code & 0x3fff;
		}
	}
	else
	{
		switch ((buf_len_code >> 12) & 0x7)
		{
		case 4:  //4KB
			if ((buf_len_code & 0xfff) == 0x0)
			{
				buf_len = 0x1000;
			}
			else
			{
				buf_len = buf_len_code & 0xfff;
			}
			break;
		case 5:  //2KB
			buf_len = buf_len_code & 0xfff;
			if (buf_len > 0x800)
			{
				buf_len = 0x800;
			}
			break;
		case 6:  //1KB
			buf_len = buf_len_code & 0xfff;
			if (buf_len > 0x400)
			{
				buf_len = 0x400;
			}
			break;
		case 7:  //256 byte
			if (buf_len > 0x100)
			{
				buf_len = 0x100;
			}
			buf_len = buf_len_code & 0xfff;
			break;
		default:
			buf_len = buf_len_code & 0xfff;
			break;
		}
	}
	//debug_vsec_mem_manager(" *** buf_len_code = 0x%08x; buf_len = 0x%08x\n\r", buf_len_code, buf_len);
	return buf_len;
}

void load_mem(unsigned long long mem_addr, unsigned long long mem_len, unsigned int *mem_array_ptr)
{
	unsigned int un_aligned_addr;
	unsigned char mem_byte;
	unsigned int mem_word;
	unsigned int remaining_mem;

	int mem_pos;
	int i;

	un_aligned_addr = (unsigned int)(mem_addr % 4);
	#ifdef PRINT_DBG_MSG
		debug_vsec_mem_manager("Start load_mem\n\r");
		debug_vsec_mem_manager("mem_addr = 0x%08x\n\r", mem_addr);
		debug_vsec_mem_manager("mem_len = 0x%08x\n\r", mem_len);
		//debug_vsec_mem_manager("un_aligned_addr = 0x%08x\n\r",un_aligned_addr);
	#endif

	mem_pos = 0;
	remaining_mem = 0x0;

	// Write un-aligned address
	if (un_aligned_addr != 0)
	{
		mem_word = mem_array_ptr[mem_pos];
		//debug_vsec_mem_manager("mem_array[%d] = 0x%08x\n\r", mem_pos, mem_word);
		for (i = 0; i < (4-un_aligned_addr); i++)
		{
			if (mem_len <= 0)
			{
				return;
			}
			mem_byte = mem_word & 0xff;
			mem_word = mem_word >> 8;
			WRITE8(mem_addr, mem_byte);
			mem_addr++;
			mem_len --;
		}
		remaining_mem = mem_word;
		mem_pos++;
//		debug_vsec_mem_manager("mem_addr = 0x%08x\n\r", mem_addr);
//		debug_vsec_mem_manager("mem_word = 0x%08x\n\r", mem_word);
//		debug_vsec_mem_manager("remaining_mem = 0x%08x\n\r", remaining_mem);
//		debug_vsec_mem_manager("Finish writing un-aligned address\n");
//		debug_vsec_mem_manager("mem_len = 0x%08x", mem_len);
	}

	// Write at aligned address
	while(mem_len >= 4)
	{
		mem_word = mem_array_ptr[mem_pos];
		//debug_vsec_mem_manager("mem_array[%d] = 0x%08x\n\r", mem_pos, mem_word);
		mem_word = (mem_word << (un_aligned_addr*8)) | remaining_mem;
		if (un_aligned_addr > 0)
		{
			remaining_mem = (mem_array_ptr[mem_pos] >> ((4-un_aligned_addr)*8)) & 0xfffffff;
		}
//		debug_vsec_mem_manager("mem_addr = 0x%08x\n\r", mem_addr);
//		debug_vsec_mem_manager("mem_word = 0x%08x", mem_word);
//		debug_vsec_mem_manager("remaining_mem = 0x%08x\n\r", remaining_mem);
		WRITE32(mem_addr, mem_word);
		mem_addr += 4;
		mem_len = mem_len - 4;
		mem_pos++;
	}
	//debug_vsec_mem_manager("mem_len = 0x%08x\n\r", mem_len);

	// Write last un_aligned byte if any
	if (mem_len > 0)
	{
		for (i = 0; i < un_aligned_addr; i++)
		{
			mem_byte = remaining_mem & 0xff;
			remaining_mem = remaining_mem >> 8;
			WRITE8(mem_addr, mem_byte);
			mem_addr++;
			mem_len --;
			if (mem_len <= 0)
			{
				return;
			}
		}
	}

	mem_word = mem_array_ptr[mem_pos++];
	while (mem_len > 0)
	{
		//debug_vsec_mem_manager("mem_array[%d] = 0x%08x\n", mem_pos-1, mem_word);
		mem_byte = mem_word & 0xff;
		mem_word = mem_word >> 8;
		WRITE8(mem_addr, mem_byte);
		mem_addr++;
		mem_len --;
	}

	#ifdef PRINT_DBG_MSG
		debug_vsec_mem_manager("End load_mem\n\r");
	#endif

	return;
}

void dump_mem(unsigned long long mem_addr, unsigned long long mem_len)
{
	int i;
	unsigned int num_of_unaligned_addr;
	unsigned long long mem_addr_4b_aligned;
	unsigned int num_of_unaligned_len;

	num_of_unaligned_addr = (unsigned int)(mem_addr % 4);
	mem_addr_4b_aligned = mem_addr - (mem_addr % 4);

	debug_vsec_mem_manager("*** Start memr dump, mem_addr = 0x%08x; mem_len = 0x%08x ***\n", mem_addr, mem_len);
	debug_vsec_mem_manager("num_of_unaligned_addr = 0x%08x\n", num_of_unaligned_addr);

	if (num_of_unaligned_addr > 0)
	{
		debug_vsec_mem_manager("Mem dump in byte unit\n\r");

		for (i = 0; i < (4-num_of_unaligned_addr); i++)
		{
			if (mem_len <= 0)
			{
				break;
			}
			debug_vsec_mem_manager("mem_addr[0x%08x] = 0x%08x\n", mem_addr, READ8(mem_addr));
			mem_addr ++;
			mem_len --;
		}
	}

	num_of_unaligned_len = (mem_len % 4);
	mem_len = (mem_len - num_of_unaligned_len)/4;

	if (mem_len > 0)
	{
		debug_vsec_mem_manager("Mem dump in 4-byte unit\n\r");
	}
	for (i = 0; i < mem_len; i++)
	{
		debug_vsec_mem_manager("mem_addr[0x%08x] = 0x%08x\n", mem_addr, READ32(mem_addr));
		mem_addr += 4;
	}

	if (num_of_unaligned_len == 0)
	{
		return;
	}

	debug_vsec_mem_manager("Mem dump in byte unit \n\r");
	for (i = 0; i < num_of_unaligned_len; i++)
	{
		debug_vsec_mem_manager("mem_addr[0x%08x] = 0x%08x\n", mem_addr, READ8(mem_addr));
		mem_addr ++;
	}
	return;
}

void write_mem_array_header(mem_array_header_queue* mem_array_header_queue_ptr, unsigned int *mem_array_ptr, unsigned int mem_len)
{
	int write_pos, no_of_entry;
	mem_array_header write_mem_array_header;

	write_mem_array_header.mem_array_ptr = mem_array_ptr;
	write_mem_array_header.mem_len = mem_len;

	write_pos = (*mem_array_header_queue_ptr).queue_tail;
	no_of_entry = (*mem_array_header_queue_ptr).no_of_entry;

	#ifdef PRINT_DBG_MSG
		debug_vsec_mem_manager("write_mem_array_header: write_pos = 0x%08x; no_of_entry = 0x%08x;  max_ptr = 0x%08x\n\r",write_pos, no_of_entry, MAX_MEM_BUF);
	#endif

	(*mem_array_header_queue_ptr).mem_array_header_ptr[write_pos] = write_mem_array_header;
	write_pos++;

	if (write_pos == MAX_MEM_BUF)
	{
		write_pos = 0;
	}
	no_of_entry++;
	(*mem_array_header_queue_ptr).queue_tail = write_pos;
	(*mem_array_header_queue_ptr).no_of_entry = no_of_entry;
	return;
}


mem_array_header* read_mem_array_header(mem_array_header_queue* mem_array_header_queue_ptr)
{
	mem_array_header* result = 0;
	int read_pos;
	int no_of_entry = (*mem_array_header_queue_ptr).no_of_entry;

	if (no_of_entry > 0)
	{
		read_pos = (*mem_array_header_queue_ptr).queue_head;
		result = &((*mem_array_header_queue_ptr).mem_array_header_ptr[read_pos]);
		read_pos = read_pos + 1;
		if (read_pos == MAX_MEM_BUF)
		{
			read_pos = 0;
		}
		no_of_entry--;
		(*mem_array_header_queue_ptr).queue_head = read_pos;
		(*mem_array_header_queue_ptr).no_of_entry = no_of_entry;
	}
	return result;
}

int chk_mem_a_4byte(unsigned long long result_base_addr, unsigned long long expect_base_addr, unsigned int mem_len)
{
  unsigned long long result_addr = result_base_addr;
  unsigned long long expect_addr = expect_base_addr;
  unsigned int result_data, expect_data;

  int no_of_error = 0;

  int i;

  #ifdef PRINT_DBG_MSG 
  debug_vsec_mem_manager("*** Start chk_mem_a_4byte ***\n\r");
  debug_vsec_mem_manager("*** result_base_addr = 0x%08x; expect_base_addr = 0x%08x; mem_len= 0x%08x\n\r", result_base_addr, expect_base_addr, mem_len);
  #endif

  for (i = 0; i < mem_len; i = i+4)
  {
	result_data = READ32(result_addr);
	expect_data = READ32(expect_addr);

	if (result_data != expect_data)
	{
		// DEBUG: Start debugging dump code
		debug_vsec_mem_manager("*** ERROR : Memory check failure result_addr = 0x%08x, result_data = 0x%08x, expect_addr = 0x%08x, expect_data = 0x%08x ***\n\r",
		result_addr, result_data, expect_addr, expect_data);
		// DEBUG: End debugging dump code

		no_of_error += 4;
		if (no_of_error >= MAX_NO_OF_ERROR)
		{
			// DEBUG: Start debugging dump code
			debug_vsec_mem_manager("*** TO0 MANY ERRORS AT MEMORY CHECKING ***\n\r");
			// DEBUG: End debugging dump code
			return no_of_error;
		}
	}
	else
	{
		debug_vsec_mem_manager("*** Info : Memory check OK result_addr = 0x%08x, result_data = 0x%08x, expect_addr = 0x%08x, expect_data = 0x%08x\n\r",
		result_addr, result_data, expect_addr, expect_data);
	}
	result_addr += 4;
	expect_addr += 4;
  }
  #ifdef PRINT_DBG_MSG 
  	  debug_vsec_mem_manager("*** End   chk_mem_a_4byte *** \n\r");
  #endif

  return no_of_error;
}

int chk_mem(unsigned long long result_base_addr, unsigned long long expect_base_addr, unsigned int mem_len)
{
	unsigned long long result_addr = result_base_addr;
	unsigned long long expect_addr = expect_base_addr;
	unsigned char result_data, expect_data;

	int no_of_error = 0;

	int i;

	if (((result_base_addr & 0x3) == 0x0) & ((expect_base_addr & 0x3) == 0x0) & ((mem_len & 0x3) == 0x0))
	{
		// In case address is 4-byte aligned, call this function to acclerate checking speed
		no_of_error = chk_mem_a_4byte(result_base_addr, expect_base_addr, mem_len);
		return no_of_error;
	}

	#ifdef PRINT_DBG_MSG
		debug_vsec_mem_manager("*** Start chk_mem *** \n\r");
		debug_vsec_mem_manager("*** result_base_addr = 0x%08x; expect_base_addr = 0x%08x; mem_len= 0x%08x\n\r", result_base_addr, expect_base_addr, mem_len);
	#endif

	for (i = 0; i < mem_len; i++)
	{
		result_data = READ8(result_addr);
		expect_data = READ8(expect_addr);
		if (result_data != expect_data)
		{
			// DEBUG: Start debugging dump code
			debug_vsec_mem_manager("*** ERROR : Memory check failure result_addr = 0x%08x, result_data = 0x%08x, expect_addr = 0x%08x, expect_data = 0x%08x ***\n",
			result_addr, result_data, expect_addr, expect_data);
			// DEBUG: End debugging dump code

			no_of_error ++;
			if (no_of_error >= MAX_NO_OF_ERROR)
			{
				// DEBUG: Start debugging dump code
				debug_vsec_mem_manager("*** TOO MANY ERRORS AT MEMORY CHECKING ***\n\r");
				// DEBUG: End debugging dump code
				return no_of_error;
			}
		}
		else
		{
			//debug_vsec_mem_manager("*** Info : Memory check OK result_addr = 0x%08x, result_data = 0x%08x, expect_addr = 0x%08x, expect_data = 0x%08x ***\n",
			//						result_addr, result_data, expect_addr, expect_data);
		}
		result_addr++;
		expect_addr++;
	}
	#ifdef PRINT_DBG_MSG
		debug_vsec_mem_manager("*** End   chk_mem *** \n\r");
	#endif

	return no_of_error;
}

void load_in_array_mem(mem_array_header_queue* mem_array_header_queue_ptr, queue_mem_manager* mem_manager_ptr,
					unsigned long long* mem_addr_ptr, unsigned long long* mem_len_ptr,
					MEM_ALIGN_CODE align_code, unsigned int base_offset)
{
	int num_of_array;
	int i;
	unsigned long long mem_addr;
	unsigned long long mem_len;

	#ifdef PRINT_DBG_MSG
		debug_vsec_mem_manager("*** load_in_array_mem, base_offset = 0x%08x ***\n", base_offset);
	#endif

	num_of_array= (*mem_array_header_queue_ptr).no_of_entry;

	for (i= 0; i < num_of_array; i++)
	{
		mem_len = (*mem_array_header_queue_ptr).mem_array_header_ptr[i].mem_len;
		mem_addr = alot_mem(mem_manager_ptr, (unsigned long long)(mem_len+base_offset), align_code);

		if (mem_addr == 0)
		{
			debug_vsec_mem_manager("[load_in_array] [WARNING]: Not enough memory. ");
			debug_vsec_mem_manager("Trying to de-allocate from the begin of allocated entry. ");
			debug_vsec_mem_manager("Some data-in-used may be overwritten\n");
		}
		while(mem_addr == 0) // Try to de-allocate till can get enough free-memory
		{
			#ifdef PRINT_DBG_MSG
				debug_vsec_mem_manager("Can not allocate memory, trying to de-allocate previously allocated mem \n\r");
			#endif
			if (dlot_mem(mem_manager_ptr) == 0) // This case happen when try to deallocate when no entry to de-allocate
			{
				debug_vsec_mem_manager("FATAL ERROR: Canot allocate memory!!!\n\r");
				return;
			}
			mem_addr = alot_mem(mem_manager_ptr, (unsigned long long) (mem_len+base_offset), align_code);
		}

		load_mem((unsigned long long) (mem_addr+base_offset), mem_len, (*mem_array_header_queue_ptr).mem_array_header_ptr[i].mem_array_ptr);
		//dump_mem(mem_addr, mem_len+base_offset);
		if(mem_addr_ptr != 0)
		{
			mem_addr_ptr[i]  = mem_addr; // If the  pointer is null then does not needs to save length
		}
		if(mem_len_ptr  != 0)
		{
			mem_len_ptr[i]   = mem_len;  // If the  pointer is null then does not needs to save length
		}
	}
}

void load_exp_array_mem(mem_array_header_queue* mem_array_header_queue_ptr, queue_mem_manager* mem_manager_ptr,
                  buf_header_queue *expt_buf_queue_ptr,
                  MEM_ALIGN_CODE align_code)
{
	int num_of_array;
	int i;
	unsigned long long mem_addr;
	unsigned long long mem_len;
	buf_header expt_buf_header;

	num_of_array= (*mem_array_header_queue_ptr).no_of_entry;
	for (i= 0; i < num_of_array; i++)
	{
		mem_len = (*mem_array_header_queue_ptr).mem_array_header_ptr[i].mem_len;
		mem_addr = alot_mem(mem_manager_ptr, mem_len, align_code);
		if (mem_addr == 0)
		{
			debug_vsec_mem_manager("[load_exp_array_mem] [WARNING]: Not enough memory. ");
			debug_vsec_mem_manager("Trying to de-allocate from the begin of allocated entry. ");
			debug_vsec_mem_manager("Some data-in-used may be overwritten\n");
		}
		while(mem_addr == 0) // Try to de-allocate till can get enough free-memory
		{
			#ifdef PRINT_DBG_MSG
				debug_vsec_mem_manager("Can not allocate memory, trying to de-allocate previously allocated mem \n\r");
			#endif
			if (dlot_mem(mem_manager_ptr) == 0) // This case happen when try to deallocate when no entry to de-allocate
			{
				debug_vsec_mem_manager("FATAL ERROR: Canot allocate memory!!!\n\r");
				return;
			}
			mem_addr = alot_mem(mem_manager_ptr, mem_len, align_code);
		}

		load_mem(mem_addr, mem_len, (*mem_array_header_queue_ptr).mem_array_header_ptr[i].mem_array_ptr);
		expt_buf_header.field.BufDataLength = mem_len;
		expt_buf_header.field.BufDataAddr =   mem_addr;
		write_buf_header(expt_buf_queue_ptr, expt_buf_header, MAX_MEM_BUF);
	}
}

#endif /*__vSEC_MEM_MANAGER_C__*/
