#ifndef __vSEC_TEST_DRIVER_C__
#define __vSEC_TEST_DRIVER_C__

#include "../include/vSEC_globals.h"
#include "../include/vSEC_qm_driver.h"
#include "../include/vSEC_test_driver.h"
#include "armv8.h"

extern unsigned long long enq_ptr[MAX_NO_OF_QUEUE];
extern unsigned long long deq_ptr[MAX_NO_OF_QUEUE];

enq_msg_header * read_enq_msg_header(enq_msg_header_queue * enq_msg_header_queue_ptr, int max_ptr)
{
	enq_msg_header *result = 0;
	int read_pos;

	int no_of_entry;

	no_of_entry = (*enq_msg_header_queue_ptr).no_of_entry;

	if (no_of_entry > 0)
	{
		read_pos = (*enq_msg_header_queue_ptr).queue_head;
		result = &((*enq_msg_header_queue_ptr).enq_msg_header_ptr[read_pos]);
		read_pos = read_pos + 1;

		if (read_pos == max_ptr)
		{
			read_pos = 0;
		}
		no_of_entry--;
		(*enq_msg_header_queue_ptr).queue_head = read_pos;
		(*enq_msg_header_queue_ptr).no_of_entry = no_of_entry;
	}

	return result;
}

void write_enq_msg_header(enq_msg_header_queue* enq_msg_header_queue_ptr, enq_msg_header write_msg_header,  int max_ptr)
{
	int write_pos, no_of_entry;

	write_pos = (*enq_msg_header_queue_ptr).queue_tail;
	no_of_entry = (*enq_msg_header_queue_ptr).no_of_entry;

	//(*enq_msg_header_queue_ptr).enq_msg_header_ptr[write_pos] = write_msg_header;
	(*enq_msg_header_queue_ptr).enq_msg_header_ptr[write_pos].msg_type = write_msg_header.msg_type;
	(*enq_msg_header_queue_ptr).enq_msg_header_ptr[write_pos].num_of_buf = write_msg_header.num_of_buf;
	(*enq_msg_header_queue_ptr).enq_msg_header_ptr[write_pos].qid = write_msg_header.qid;
	write_pos++;

	if (write_pos == max_ptr)
	{
		write_pos = 0;
	}
	no_of_entry++;

	(*enq_msg_header_queue_ptr).queue_tail = write_pos;
	(*enq_msg_header_queue_ptr).no_of_entry = no_of_entry;
}

void print_enq_msg_header(enq_msg_header_queue* enq_msg_header_queue_ptr)
{
	int i;
	enq_msg_header read_header;
	int read_pos;
	int no_of_entry;

	read_pos = (*enq_msg_header_queue_ptr).queue_head;
	no_of_entry = (*enq_msg_header_queue_ptr).no_of_entry;

	debug_vsec_test_drv("Below is content of msg_header_queue: \n\r");
	debug_vsec_test_drv("queue_header = 0x%08x\n", (*enq_msg_header_queue_ptr).queue_head);
	debug_vsec_test_drv("queue_tail   = 0x%08x\n", (*enq_msg_header_queue_ptr).queue_tail);

	for (i = 0; i < no_of_entry; i++)
	{
		read_header =(*enq_msg_header_queue_ptr).enq_msg_header_ptr[read_pos];
		debug_vsec_test_drv("entry %d: qid = 0x%08x, msg_type = 0x%08x\n", i, read_header.qid, read_header.msg_type);
	}
}


buf_header* read_buf_header(buf_header_queue *buf_header_queue_ptr, int max_ptr)
{
	buf_header *result = 0;
	int read_pos;
	int no_of_entry;

	no_of_entry = (*buf_header_queue_ptr).no_of_entry;

	if (no_of_entry > 0)
	{
		read_pos = (*buf_header_queue_ptr).queue_head;
		result = &((*buf_header_queue_ptr).buf_header_ptr[read_pos]);
		read_pos = read_pos + 1;

		if (read_pos == max_ptr)
		{
			read_pos = 0;
		}

		no_of_entry--;
		(*buf_header_queue_ptr).queue_head = read_pos;
		(*buf_header_queue_ptr).no_of_entry = no_of_entry;
	}
	return result;
}

void write_buf_header(buf_header_queue* buf_header_queue_ptr, buf_header write_buf_header, int max_ptr)
{
	int write_pos, no_of_entry;

	write_pos = (*buf_header_queue_ptr).queue_tail;
	no_of_entry = (*buf_header_queue_ptr).no_of_entry;

	#ifdef PRINT_DBG_MSG
		debug_vsec_test_drv("write_buf_header: write_pos = 0x%08x; no_of_entry = 0x%08x; max_ptr = 0x%08x\n", write_pos, no_of_entry, max_ptr);
	#endif

	(*buf_header_queue_ptr).buf_header_ptr[write_pos] = write_buf_header;
	write_pos++;

	if (write_pos == max_ptr)
	{
		write_pos = 0;
	}

	no_of_entry++;
	(*buf_header_queue_ptr).queue_tail = write_pos;
	(*buf_header_queue_ptr).no_of_entry = no_of_entry;
}


void init_queue_ptr(void)
{
	int i;

	for (i = 0; i < MAX_NO_OF_QUEUE; i++)
	{
		enq_ptr[i] = 0;
		deq_ptr[i] = 0;
	}
};

int chk_cm_msg (int qid, unsigned long long expt_msg_ptr, int msg_type)
{
	unsigned int result_data, expect_data;
	int no_of_error = 0;
	int i;

	// For now, simply compare all address space, but later should change to ignore reserved field
	int msg_len;
	unsigned long long cm_msg_ptr_offset= deq_ptr[qid];
	unsigned long long cm_msg_ptr = CPU_OFFSET_ADDR + ((MEM_BASE_ADDR + (MAX_QUEUE_SIZE * qid)));

	if (msg_type == 0)
	{
		msg_len = 32;
	}
	else
	{
		msg_len = 64;
	}

	for (i = 0; i < msg_len; i+=4)
	{
		result_data = READ32(cm_msg_ptr+cm_msg_ptr_offset);
		expect_data = READ32(expt_msg_ptr);

		if (result_data != expect_data)
		{
			// DEBUG: Start debugging dump code
			debug_vsec_test_drv("*** ERROR : Completion message check failure result_addr = 0x%08x, result_data = 0x%08x, expect_addr = 0x%08x, expect_data = 0x%08x ***\n",
			cm_msg_ptr+cm_msg_ptr_offset, result_data, expt_msg_ptr, expect_data);
			// DEBUG: End debugging dump code
			no_of_error ++;

			if (no_of_error >= MAX_NO_OF_ERROR)
			{
				// DEBUG: Start debugging dump code
				debug_vsec_test_drv("*** TO0 MANY ERRORS AT COMPLETION MESSAGE CHECKING ***\n\r");
				// DEBUG: End debugging dump code
				return no_of_error;
			}
		}

		cm_msg_ptr_offset += 4;
		if (cm_msg_ptr_offset >= MAX_QUEUE_SIZE)
		{
			cm_msg_ptr_offset = 0;
		}

		expt_msg_ptr +=4;
	}
	return no_of_error;
}

#endif /*__vSEC_TEST_DRIVER_C__*/
