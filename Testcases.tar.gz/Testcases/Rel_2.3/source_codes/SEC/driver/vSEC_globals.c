#ifndef __vSEC_GLOBAL_C__
#define __vSEC_GLOBAL_C__

#include "../include/vSEC_globals.h"

//Tinh-SLT: 
#define random random_slt_sec
//End of Tinh-SLT

int random(void)
{

  static int a = 69069;
  static int c = 0;
  static int m = 429496729;

  seed = (a*seed + c) % m;

  return seed;
}

#endif /*__vSEC_GLOBAL_C__*/





