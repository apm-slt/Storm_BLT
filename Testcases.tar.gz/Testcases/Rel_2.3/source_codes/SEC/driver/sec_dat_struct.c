#ifndef __SEC_DAT_STRUCT_C__
#define __SEC_DAT_STRUCT_C__

#include "../include/sec_dat_struct.h"
#include "armv8.h"

void load_eip96_tkn(unsigned long long tkn_base_addr,  eip96_tkn* eip96_tkn_ptr)
	{
	int i;
	int instr_array[20];

	int tkn_len;
	int num_of_iv;
	printf ("*** Start load_eip96_tkn ***\n\r");
	printf ("tkn_base_addr = 0x%08x\n", tkn_base_addr);
	// Load token control words
	for (i = 0; i < 4; i++)
	{
		(*eip96_tkn_ptr).tkn_ctl.raw[i] = READ32(tkn_base_addr);
		tkn_base_addr += 4;
		printf ("Token control word [0x%08x] = 0x%08x\n", i, (*eip96_tkn_ptr).tkn_ctl.raw[i]);
	}
	printf ("Input length = 0x%08x\n", (*eip96_tkn_ptr).tkn_ctl.field.in_pkt_len);
	tkn_len = (*eip96_tkn_ptr).tkn_ctl.field.tkn_len & 0x3fff;
	printf ("Token length = 0x%08x\n", tkn_len);
	// Load context control words if required
	if (((*eip96_tkn_ptr).tkn_ctl.field.c & 0x1) == 0x1)
	{
		for (i = 0; i < 2; i++)
		{
			(*eip96_tkn_ptr).ctx_ctl.raw[i] = READ32(tkn_base_addr);
			tkn_base_addr += 4;
		}
		tkn_len = tkn_len - 6;
	}
	else
	{
		tkn_len = tkn_len - 4;
	}
	// Load IV (does not supported)
	if (((*eip96_tkn_ptr).tkn_ctl.field.c & 0x7) != 0)
	{
		printf(" *** ERROR: Currently does not support token with IV != 3'b000 *** \n\rn");
		return;
	}

	// Load check sum
	if (((*eip96_tkn_ptr).tkn_ctl.field.u & 0x1) != 0)
	{
		printf(" *** INFO: Checksum word exists in token *** \n\rn");
		(*eip96_tkn_ptr).chk_sum = READ32(tkn_base_addr);
		tkn_base_addr += 4;
		tkn_len = tkn_len - 1;
	}
	else
	{
		(*eip96_tkn_ptr).chk_sum = 0;
	}

	// Load instruction
	//(*eip96_tkn_ptr).instr_ptr = (int*)  malloc(4*tkn_len); // This dynamic mem. allocation may not be used
	(*eip96_tkn_ptr).instr_ptr = instr_array;
	if ((*eip96_tkn_ptr).instr_ptr == 0)
	{
		printf("*** ERROR: Can not allocate memory ***\n\r");
		return;
	}
	else
	{
		printf ("instr_ptr = 0x%08x\n", (*eip96_tkn_ptr).instr_ptr);
	}

	printf("Token instruction length = 0x%08x\n", tkn_len);
	printf("Token instruction base = 0x%08x\n", tkn_base_addr);
	for (i = 0; i < tkn_len; i++)
	{
		printf("Token instruction word [0x%08x] = 0x%08x\n", i, READ32(tkn_base_addr));
		(*eip96_tkn_ptr).instr_ptr[i] = READ32(tkn_base_addr);
		printf("Token instruction word [0x%08x] = 0x%08x\n", i, (*eip96_tkn_ptr).instr_ptr[i]);
		tkn_base_addr += 4;
	}
	printf("*** End load_eip96_tkn ***\n\r");
}

void load_eip96_rslt_tkn(unsigned long long tkn_base_addr,  eip96_rslt_tkn* eip96_rslt_tkn_ptr) {
  int i;
  short bypass_dat;
  for (i = 0; i < 4; i++)
  {
    (*eip96_rslt_tkn_ptr).rslt_tkn_f.raw[i] = READ32(tkn_base_addr);
    tkn_base_addr += 4;
  }
  bypass_dat = (*eip96_rslt_tkn_ptr).rslt_tkn_f.field.bypass_dat;

  if (bypass_dat == 0) {
    (*eip96_rslt_tkn_ptr).bypass_dat_ptr = 0;
    return;
  }

  //(*eip96_rslt_tkn_ptr).bypass_dat_ptr = (int*) malloc(4*bypass_dat); // This dynamic mem. allocation may not be used
  if ((*eip96_rslt_tkn_ptr).bypass_dat_ptr == 0) {
    printf ("*** EORROR: Can not allocate memory for bypass data ***\n\r");
    return;
  }
  for (i = 0; i < bypass_dat; i++) {
    (*eip96_rslt_tkn_ptr).bypass_dat_ptr[i] = READ32(tkn_base_addr);
    tkn_base_addr += 4;
  }
}

void printf_eip96_tkn(eip96_tkn* eip96_tkn_ptr)
{// For debugging purpose
  short tkn_len;
  int i;

  printf ("*** Start dumpping EIP96 token ***\n\r");
  // printf 4 fixed control words
  printf ("Below is content of token control words : \n\r");
  printf ("Input packet length = 0x%08x", (*eip96_tkn_ptr).tkn_ctl.field.in_pkt_len & 0x1ffff);

  printf ("CT = 0x%08x; ", (*eip96_tkn_ptr).tkn_ctl.field.ct & 0x3);
  printf ("RC = 0x%08x; ", (*eip96_tkn_ptr).tkn_ctl.field.rc & 0x3);
  printf ("ToO = 0x%08x; ", (*eip96_tkn_ptr).tkn_ctl.field.too & 0x7);
  printf ("C = 0x%08x; ", (*eip96_tkn_ptr).tkn_ctl.field.c & 0x1);
  printf ("IV = 0x%08x; ", (*eip96_tkn_ptr).tkn_ctl.field.iv & 0x7);
  printf ("U = 0x%08x\n", (*eip96_tkn_ptr).tkn_ctl.field.u & 0x1);

  tkn_len = (*eip96_tkn_ptr).tkn_ctl.field.tkn_len & 0x3fff;
  printf ("Token length = 0x%08x;", tkn_len);
  printf ("Number of context updates = 0x%08x ;",(*eip96_tkn_ptr).tkn_ctl.field.num_of_ctx_updt & 0xf);
  printf ("Context pointer MSBs = 0x%08x;", (*eip96_tkn_ptr).tkn_ctl.field.ctx_ptr_MSBs & 0x3f);
  printf ("Context pointer LSBs = 0x%08x\n", (*eip96_tkn_ptr).tkn_ctl.field.ctx_ptr_LSBs);

  tkn_len = tkn_len - 4;
  // printf context control words;
  if (((*eip96_tkn_ptr).tkn_ctl.field.c & 0x1) == 0x1)
  {
    printf("Below is content of context control words : \n\r");
    printf("ToP = 0x%08x; ", (*eip96_tkn_ptr).ctx_ctl.field.top & 0xf);
    printf("Packet-based options = 0x%08x; ", (*eip96_tkn_ptr).ctx_ctl.field.pkt_based_opt & 0xf);
    printf("Context length = 0x%08x; ", (*eip96_tkn_ptr).ctx_ctl.field.ctx_len & 0xff);
    printf("Key = 0x%08x; ", (*eip96_tkn_ptr).ctx_ctl.field.key & 0x1);
    printf ("Crypto algorithm = 0x%08x;", (*eip96_tkn_ptr).ctx_ctl.field.crypto_algo & 0x7);
    printf ("Digest type = 0x%08x;", (*eip96_tkn_ptr).ctx_ctl.field.digest_type & 0x3);
    printf ("Hash algorithm = 0x%08x;", (*eip96_tkn_ptr).ctx_ctl.field.hash_algo & 0x7);
    printf ("SPI = 0x%08x;", (*eip96_tkn_ptr).ctx_ctl.field.spi & 0x1);
    printf ("SEQ = 0x%08x;", (*eip96_tkn_ptr).ctx_ctl.field.seq & 0x3);
    printf ("MASK0 = 0x%08x;", (*eip96_tkn_ptr).ctx_ctl.field.mask0 & 0x1);
    printf ("MASK1 = 0x%08x\n", (*eip96_tkn_ptr).ctx_ctl.field.mask1 & 0x1);

    printf ("Crypto mode = 0x%08x;", (*eip96_tkn_ptr).ctx_ctl.field.crypto_mode & 0x1f);
    printf ("IV0 = 0x%08x;", (*eip96_tkn_ptr).ctx_ctl.field.iv0 & 0x1);
    printf ("IV1 = 0x%08x;", (*eip96_tkn_ptr).ctx_ctl.field.iv1 & 0x1);
    printf ("IV2 = 0x%08x;", (*eip96_tkn_ptr).ctx_ctl.field.iv2 & 0x1);
    printf ("IV3 = 0x%08x;", (*eip96_tkn_ptr).ctx_ctl.field.iv3 & 0x1);
    printf ("Digest cnt = 0x%08x;", (*eip96_tkn_ptr).ctx_ctl.field.digest_cnt & 0x1);
    printf ("IV format = 0x%08x;", (*eip96_tkn_ptr).ctx_ctl.field.iv_format & 0x3);
    printf ("Crypto store = 0x%08x;", (*eip96_tkn_ptr).ctx_ctl.field.crypto_store & 0x1);
    printf ("Pad type = 0x%08x;", (*eip96_tkn_ptr).ctx_ctl.field.pad_type & 0x7);
    printf ("Enc. hash result = 0x%08x;", (*eip96_tkn_ptr).ctx_ctl.field.enc_hash_rslt & 0x1);
    printf ("Kasumi F9 direction = 0x%08x;", (*eip96_tkn_ptr).ctx_ctl.field.kasumi_f9_dir & 0x1);
    printf ("Hash store = 0x%08x;", (*eip96_tkn_ptr).ctx_ctl.field.hash_store & 0x1);
    printf ("i-j-pntr = 0x%08x;", (*eip96_tkn_ptr).ctx_ctl.field.i_j_pntr & 0x1);
    printf ("State selection = 0x%08x;", (*eip96_tkn_ptr).ctx_ctl.field.state_sel & 0x1);
    printf ("Seq. nbr store = 0x%08x;", (*eip96_tkn_ptr).ctx_ctl.field.seq_nbr_store & 0x1);
    printf ("Disable mask update = 0x%08x;", (*eip96_tkn_ptr).ctx_ctl.field.dis_mask_updt & 0x1);
    printf ("Address mode = 0x%08x;", (*eip96_tkn_ptr).ctx_ctl.field.addr_mode & 0x1);
  }
  tkn_len = tkn_len - 2;
  if (tkn_len == 0)
  {
	  return;
  }

  // Instruction in token
  printf ("Below is content of instructions in token\n\r");
  for (i = 0; i < tkn_len; i++)
  {
	  printf("instr_word[0x%08x] = 0x%08x\n", i, (*eip96_tkn_ptr).instr_ptr[i]);
  }
  printf ("*** End dumpping EIP96 token ***\n\r");
}

void printf_eip96_rslt_tkn(eip96_rslt_tkn* eip96_rslt_tkn_ptr)
{
  int i;
  short bypass_dat;

  printf ("*** Start dumpping EIP96 result token ***\n\r");
  printf ("Below is content of fixed part in result token\n\r");
  printf ("Result packet length = 0x%08x;", (*eip96_rslt_tkn_ptr).rslt_tkn_f.field.rslt_pkt_len & 0x1ffff);
  printf ("E0 = 0x%08x;", (*eip96_rslt_tkn_ptr).rslt_tkn_f.field.e0 & 0x1);
  printf ("E1 = 0x%08x;", (*eip96_rslt_tkn_ptr).rslt_tkn_f.field.e1 & 0x1);
  printf ("E2 = 0x%08x;", (*eip96_rslt_tkn_ptr).rslt_tkn_f.field.e2 & 0x1);
  printf ("E3 = 0x%08x;", (*eip96_rslt_tkn_ptr).rslt_tkn_f.field.e3 & 0x1);
  printf ("E4 = 0x%08x;", (*eip96_rslt_tkn_ptr).rslt_tkn_f.field.e4 & 0x1);
  printf ("E5 = 0x%08x;", (*eip96_rslt_tkn_ptr).rslt_tkn_f.field.e5 & 0x1);
  printf ("E6 = 0x%08x;", (*eip96_rslt_tkn_ptr).rslt_tkn_f.field.e6 & 0x1);
  printf ("E7 = 0x%08x;", (*eip96_rslt_tkn_ptr).rslt_tkn_f.field.e7 & 0x1);
  printf ("E8 = 0x%08x;", (*eip96_rslt_tkn_ptr).rslt_tkn_f.field.e8 & 0x1);
  printf ("E9 = 0x%08x;", (*eip96_rslt_tkn_ptr).rslt_tkn_f.field.e9 & 0x1);
  printf ("E10 = 0x%08x;", (*eip96_rslt_tkn_ptr).rslt_tkn_f.field.e10 & 0x1);
  printf ("E11 = 0x%08x;", (*eip96_rslt_tkn_ptr).rslt_tkn_f.field.e11 & 0x1);
  printf ("E12 = 0x%08x;", (*eip96_rslt_tkn_ptr).rslt_tkn_f.field.e12 & 0x1);
  printf ("E13 = 0x%08x;", (*eip96_rslt_tkn_ptr).rslt_tkn_f.field.e13 & 0x1);
  printf ("E14 = 0x%08x\n", (*eip96_rslt_tkn_ptr).rslt_tkn_f.field.e14 & 0x1);

  bypass_dat = (*eip96_rslt_tkn_ptr).rslt_tkn_f.field.bypass_dat & 0xf;
  printf ("Bypass data = 0x%08x;", bypass_dat);
  printf ("E15 = 0x%08x;", (*eip96_rslt_tkn_ptr).rslt_tkn_f.field.e15 & 0x1);
  printf ("Number of deallocated buffers = 0x%08x;", (*eip96_rslt_tkn_ptr).rslt_tkn_f.field.num_of_deallot_buf & 0x1ff);
  printf ("H = 0x%08x;", (*eip96_rslt_tkn_ptr).rslt_tkn_f.field.h & 0x1);
  printf ("Hash bytes = 0x%08x;", (*eip96_rslt_tkn_ptr).rslt_tkn_f.field.hash_byte & 0x3f);
  printf ("B = 0x%08x;", (*eip96_rslt_tkn_ptr).rslt_tkn_f.field.b & 0x1);
  printf ("C = 0x%08x;", (*eip96_rslt_tkn_ptr).rslt_tkn_f.field.c & 0x1);
  printf ("N = 0x%08x;", (*eip96_rslt_tkn_ptr).rslt_tkn_f.field.n & 0x1);
  printf ("L = 0x%08x\n", (*eip96_rslt_tkn_ptr).rslt_tkn_f.field.l & 0x1);

  printf ("Next header field = 0x%08x;", (*eip96_rslt_tkn_ptr).rslt_tkn_f.field.nxt_header_field & 0xff);
  printf ("Pad length = 0x%08x;", (*eip96_rslt_tkn_ptr).rslt_tkn_f.field.pad_len& 0xff); printf ("\n\r");
  printf ("*** End dumpping EIP96 result token ***\n");

  if (bypass_dat == 0) return; // Return if there is not bypass data in result token

  printf ("Below is content of bypass data in result token\n");
  for (i = 0; i < bypass_dat; i++)
  {
	  printf ("Word[0x%08x] = 0x%08x\n", i, (*eip96_rslt_tkn_ptr).bypass_dat_ptr[i]);
  }
}

#endif /*__SEC_DAT_STRUCT_C__*/
