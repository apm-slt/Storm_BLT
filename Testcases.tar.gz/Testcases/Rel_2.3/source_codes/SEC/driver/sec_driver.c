#ifndef __SEC_DRIVER_C__
#define __SEC_DRIVER_C__

#include "../include/sec_driver.h"
#include "armv8.h"

//Tinh-SLT
//function call
#define dump_mem dump_mem_slt_sec
//End of Tinh-SLT

extern unsigned long long enq_ptr[MAX_NO_OF_QUEUE];
extern unsigned long long deq_ptr[MAX_NO_OF_QUEUE];

void rst_sec(unsigned int rst_pattern)
{
	int i;
	int rd_data;

	debug_sec_drv(" *** Asssert reset ***\n");
	WRITE32(SM_SEC_CLK_RST_CSR_CSR_SEC_SRST_REG, rst_pattern);

	for (i = 0; i < 100; i = i+1) {}

	rd_data = RD_MEM32(SM_SEC_CLK_RST_CSR_CSR_SEC_SRST_REG);

	debug_sec_drv(" *** Release all reset ***\n");
	WRITE32(SM_SEC_CLK_RST_CSR_CSR_SEC_SRST_REG, rd_data & (~rst_pattern));

	for (i = 0; i < 100; i = i+1) {}

	return;
}

void extern rst_sec_csr(void)
{
	rst_sec(0x01);
}

void extern rst_sec_axi(void)
{
	rst_sec(0x02);
}

void extern rst_sec_eip96(void)
{
	rst_sec(0x04);
}
void extern rst_sec_ext(void)
{
	rst_sec(0x08);
}

void extern rst_sec_eip62(void)
{
	rst_sec(0x10);
}

void stp_sec(int stp_pattern)
{
	debug_sec_drv(" *** Stop all CLK: EIP62, EIP96, EIP38, CSR ***\n");
	WRITE32(SM_SEC_CLK_RST_CSR_CSR_SEC_CLKEN_REG, stp_pattern);
}

void extern stp_sec_csr(void)
{
	stp_sec(0x01);
}

void extern stp_sec_axi(void)
{
	stp_sec(0x02);
}

void extern stp_sec_eip96(void)
{
	stp_sec(0x04);
}

void extern stp_sec_ext(void)
{
	stp_sec(0x08);
}

void extern stp_sec_eip62(void)
{
	stp_sec(0x10);
}

void resume_sec(void)
{
	debug_sec_drv(" *** Resume all CLK: EIP62, EIP96, EIP38, CSR ***\n");
	WRITE32(SM_SEC_CLK_RST_CSR_CSR_SEC_CLKEN_REG, 0x0); //Disable
	arch_timer_msdelay(200);
	WRITE32(SM_SEC_CLK_RST_CSR_CSR_SEC_CLKEN_REG, 0x1F); //Enable
}

void init_sec(void)
{
    int wr_addr, wr_data;

    debug_sec_drv(" *** Enable all CLK: EIP62, EIP96, EIP38, CSR ***\n");
    resume_sec();

    debug_sec_drv(" *** Release all reset: EIP62, EIP96, EIP38, CSR ***\n");
    WRITE32(SM_SEC_CLK_RST_CSR_CSR_SEC_SRST_REG, 0x1f);
    arch_timer_msdelay(200);
    WRITE32(SM_SEC_CLK_RST_CSR_CSR_SEC_SRST_REG, 0x0);

    wr_data = RD_MEM32(SM_SEC_CLK_RST_CSR_CSR_SEC_CLKEN_REG);
    debug_sec_drv(" *** SM_SEC_CLK_RST_CSR_CSR_SEC_CLKEN__ADDR = 0x%08x\n", wr_data);

    debug_sec_drv(" *** Set associated QM ***\n");
    WRITE32(SM_QMI_SLAVE_CFGSSQMIFPQASSOC_REG, 0xffffffff);

    WRITE32(SM_QMI_SLAVE_CFGSSQMIWQASSOC_REG, 0xffffffff);
    
    //SEC is associated with QMTM1
    //By default QMTM1 is selected so no setting is required

    // Init ECC
    sm_sec_init_ecc();
} 

void sm_sec_init_ecc(void)
{
	int rd_data;
	int wr_data;
	int ecc_bypass;
	int j;

	debug_sec_drv("===========================\n");
	debug_sec_drv("INIT_ECC starting\n");
	debug_sec_drv("===========================\n");

	//de-assert RAM SHUTDOWN
	rd_data = READ32(SM_GLBL_DIAG_CSR_CFG_MEM_RAM_SHUTDOWN_REG);
	debug_sec_drv("SM_GLBL_DIAG_CSR_CFG_MEM_RAM_SHUTDOWN = 0x%08x\n", rd_data);

	WRITE32(SM_GLBL_DIAG_CSR_CFG_MEM_RAM_SHUTDOWN_REG, 0);
	rd_data = READ32(SM_GLBL_DIAG_CSR_CFG_MEM_RAM_SHUTDOWN_REG);
	debug_sec_drv("SM_GLBL_DIAG_CSR_CFG_MEM_RAM_SHUTDOWN = 0x%08x\n", rd_data);

	//wait for ready
	rd_data = READ32(SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY_REG);
	debug_sec_drv("SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY = 0x%08x\n", rd_data);
	while (rd_data != 0xFFFFFFFF)
	{
		rd_data = READ32(SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY_REG);
		debug_sec_drv("SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY = 0x%08x\n", rd_data);
	}

	//configure BYPASS
	WRITE32(SM_GLBL_DIAG_CSR_CFG_MEM_ECC_BYPASS_REG, 0x22A60000);

	//wait for ready
	rd_data = READ32(SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY_REG);
	debug_sec_drv("SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY = 0x%08x\n", rd_data);
	while (rd_data != 0xFFFFFFFF)
	{
		rd_data = READ32(SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY_REG);
		debug_sec_drv("SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY = 0x%08x\n", rd_data);
	}

	for (j = 0; j < 5; j++)
	{
		rd_data = RD_MEM32(SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY_REG);
		debug_sec_drv("SM_GLBL_DIAG_CSR_BLOCK_MEM_RDY__ADDR = 0x%08x\n", rd_data);
	}

	debug_sec_drv("===========================\n");
	debug_sec_drv("INIT_ECC done\n");
	debug_sec_drv("===========================\n");
}

void build_sec_32b_src2sm_wq_msg(int qid, int fpqnum, int henqnum, int hfpsel, 
                                      unsigned int bufdatalen, unsigned long long bufaddr,
                                      unsigned long long tknaddr, unsigned long long dstaddr, int user_info,
                                      enq_msg_header_queue* msg_header_queue_ptr)
{
	msg_16b_field_0_t  enq_msg0;
	msg_16b_field_1_t  enq_msg1;
	msg_16b_t          intstream;
	enq_msg_header     sec_32b_msg;

	int                i;
	unsigned long long tmp;
	unsigned long long hopinfo_lsbs;
	unsigned long long hopinfo_msbs = dstaddr;
	unsigned long long msg_ptr;

	// Form enqueue message
	enq_msg0.UserInfo = user_info;
	//enq_msg0.FPQNum = (0x3 << 10) | fpqnum;
	enq_msg0.FPQNum = (SEC_ASSOC_QM_ID << 10) | fpqnum;
	enq_msg0.HL = 0;
	enq_msg0.LL = 0;
	enq_msg0.NV = 0;
	enq_msg0.C  = 0;

	enq_msg0.ELErr = 0;
	enq_msg0.LEI   = 0;
	enq_msg0.LErr= 0;

	enq_msg0.BufDataLength = bufdatalen;
	enq_msg0.DataAddr = bufaddr;

	#ifdef DUMP_DEALLOT_MSG
		enq_msg1.HR = 1;
	#else
		enq_msg1.HR = 0;
	#endif

	enq_msg1.HFPSel = hfpsel;
	//enq_msg1.HEnqNum = (0x3 << 10) |  henqnum;
	enq_msg1.HEnqNum = (SEC_ASSOC_QM_ID << 10) |  henqnum;

	tmp = 0x2; tmp = tmp << 46;
	hopinfo_lsbs = (tknaddr >> 4) & 0x3FFFFFFFFF;
	hopinfo_lsbs = hopinfo_lsbs | tmp;
	enq_msg1.HopInfoLSBs = hopinfo_lsbs;
	enq_msg1.HopInfoMSBs = hopinfo_msbs;

	if (enq_ptr[qid] >= MAX_QUEUE_SIZE)
	{
		enq_ptr[qid] = 0;
	}

	// Pack & Write
	build_32b_generic_msg(qid, &enq_msg0, &enq_msg1);

	// Write one entry to message header
	sec_32b_msg.qid = qid;
	sec_32b_msg.msg_type = 0;
	write_enq_msg_header(msg_header_queue_ptr, sec_32b_msg, MAX_WK_MSG);

//	printf("\nenq_msg0.UserInfo = 0x%x", enq_msg0.UserInfo);
//	printf("\nenq_msg0.FPQNum = 0x%x", enq_msg0.FPQNum);
//	printf("\nenq_msg0.RSVD2 = 0x%x", enq_msg0.RSVD2);
//	printf("\nenq_msg0.ELErr = 0x%x", enq_msg0.ELErr);
//	printf("\nenq_msg0.LEI = 0x%x", enq_msg0.LEI);
//	printf("\nenq_msg0.NV = 0x%x", enq_msg0.NV);
//	printf("\nenq_msg0.LL = 0x%x", enq_msg0.LL);
//	printf("\nenq_msg0.PB = 0x%x", enq_msg0.PB);
//	printf("\nenq_msg0.HB = 0x%x", enq_msg0.HB);
//	printf("\nenq_msg0.RType = 0x%x", enq_msg0.RType);
//	printf("\nenq_msg0.IN = 0x%x", enq_msg0.IN);
//	printf("\nenq_msg0.LErr = 0x%x", enq_msg0.LErr);
//	printf("\nenq_msg0.HL = 0x%x", enq_msg0.HL);
//	printf("\nenq_msg0.DataAddr = 0x%x", enq_msg0.DataAddr);
//	printf("\nenq_msg0.RSVD0 = 0x%x", enq_msg0.RSVD0);
//	printf("\nenq_msg0.BufDataLength = 0x%x", enq_msg0.BufDataLength);
//	printf("\nenq_msg0.C = 0x%x", enq_msg0.C);
//
//
//	printf("\nenq_msg1.HopInfoMSBs = 0x%x", enq_msg1.HopInfoMSBs);
//	printf("\nenq_msg1.TotDataLengthLinkListLSBs = 0x%x", enq_msg1.TotDataLengthLinkListLSBs);
//	printf("\nenq_msg1.RSVD4 = 0x%x", enq_msg1.RSVD4);
//	printf("\nenq_msg1.DR = 0x%x", enq_msg1.DR);
//	printf("\nenq_msg1.RSVD3 = 0x%x", enq_msg1.RSVD3);
//	printf("\nenq_msg1.HR = 0x%x", enq_msg1.HR);
//	printf("\nenq_msg1.HopInfoLSBs = 0x%x", enq_msg1.HopInfoLSBs);
//	printf("\nenq_msg1.HEnqNum = 0x%x", enq_msg1.HEnqNum);
//	printf("\nenq_msg1.HFPSel = 0x%x", enq_msg1.HFPSel);

	debug_sec_drv("wqid = 0x%08x; hfpsel = 0x%08x\n", qid, hfpsel);
	msg_ptr = enq_ptr[qid] - 32;
	for (i = 0; i < 8; i++)
	{
		debug_sec_drv("WQ_MSG_[%08x] = 0x%08x\n", i, READ32(CPU_OFFSET_ADDR + MEM_BASE_ADDR + qid*MAX_QUEUE_SIZE + msg_ptr+ i*4));
	}

}

void extern build_sec_32b_src2mm_wq_msg(int qid, int fpqnum, int henqnum, int hfpsel, 
                                      unsigned int bufdatalen, unsigned long long bufaddr,
                                      unsigned long long tknaddr, unsigned long long dstlistptr, int listlen, 
                                      int user_info,
                                      enq_msg_header_queue* msg_header_queue_ptr)
{
	msg_16b_field_0_t  enq_msg0;
	msg_16b_field_1_t  enq_msg1;
	msg_16b_t          intstream;
	enq_msg_header     sec_32b_msg;

	int                i;
	unsigned long long tmp;
	unsigned long long hopinfo_lsbs;
	unsigned long long hopinfo_msbs;

	// Form enqueue message
	enq_msg0.BufDataLength = bufdatalen;
	enq_msg0.DataAddr = bufaddr;
	enq_msg0.FPQNum = (SEC_ASSOC_QM_ID << 10) | fpqnum;
	enq_msg0.HL = 0;
	enq_msg0.LL = 0;
	enq_msg0.NV = 0;

	enq_msg0.ELErr = 0;
	enq_msg0.LEI   = 0;
	enq_msg0.LErr= 0;

	enq_msg0.UserInfo = user_info;

	enq_msg1.HR = 0;
	enq_msg1.HFPSel = hfpsel;
	enq_msg1.HEnqNum = (SEC_ASSOC_QM_ID << 10) |  henqnum;

	tmp = 0x3; tmp = tmp << 46;
	hopinfo_lsbs = (tknaddr >> 4) & 0x3FFFFFFFFF;
	hopinfo_lsbs = hopinfo_lsbs | tmp;
	tmp = listlen & 0xf; tmp = (tmp << 38) & 0x3fffffffff;
	hopinfo_lsbs = hopinfo_lsbs | tmp;
	enq_msg1.HopInfoLSBs = hopinfo_lsbs;

	tmp = ((listlen >> 4) & 0xf);
	tmp = (tmp << 44) & 0xfffffffffff;
	hopinfo_msbs = (dstlistptr & 0x3ffffffffff);
	hopinfo_msbs = hopinfo_msbs | tmp;
	enq_msg1.HopInfoMSBs = hopinfo_msbs;

	if (enq_ptr[qid] >= MAX_QUEUE_SIZE)
	{
		enq_ptr[qid] = 0;
	}

	// Pack & Write
	build_32b_generic_msg(qid, &enq_msg0, &enq_msg1);

	// Write one entry to message header
	sec_32b_msg.qid = qid;
	sec_32b_msg.msg_type = 0;
	write_enq_msg_header(msg_header_queue_ptr, sec_32b_msg, MAX_WK_MSG);
}

void build_sec_32b_src2buf_wq_msg(int qid, int fpqnum, int henqnum, int hfpsel,
                                  unsigned int bufdatalen, unsigned long long bufaddr,
                                  unsigned long long tknaddr, int user_info,
                                  enq_msg_header_queue* msg_header_queue_ptr)
{
	msg_16b_field_0_t  enq_msg0;
	msg_16b_field_1_t  enq_msg1;
	msg_16b_t          intstream;
	enq_msg_header     sec_32b_msg;

	int                i;
	unsigned long long tmp;
	unsigned long long hopinfo_lsbs;

	#ifdef PRINT_DBG_MSG
		debug_sec_drv (" *** Start build_sec_32b_src2buf_wq_msg *** \n");
		debug_sec_drv("\n===== DEBUG: tknaddr = 0x%08x\n", (tknaddr >> 4) & 0x0fffffff);
		debug_sec_drv("\n");
	#endif

	// Form enqueue message
	enq_msg0.BufDataLength = bufdatalen;
	enq_msg0.DataAddr = bufaddr;
	enq_msg0.FPQNum = (SEC_ASSOC_QM_ID << 10) | fpqnum;
	enq_msg0.UserInfo = user_info;
	enq_msg0.HL = 0;
	enq_msg0.LL = 0;
	enq_msg0.NV = 0;

	enq_msg0.ELErr = 0;
	enq_msg0.LEI   = 0;
	enq_msg0.LErr= 0;

	enq_msg1.HR = 0; // It's OK to set this to 1
	enq_msg1.HFPSel = hfpsel;
	enq_msg1.HEnqNum = (SEC_ASSOC_QM_ID << 10) |  henqnum;

	tmp = 0x00; tmp = tmp << 46;
	hopinfo_lsbs = (tknaddr >> 4) & 0x3FFFFFFFFF;
	hopinfo_lsbs = hopinfo_lsbs | tmp;
	enq_msg1.HopInfoLSBs = hopinfo_lsbs;

	if (enq_ptr[qid] >= MAX_QUEUE_SIZE)
	{
		enq_ptr[qid] = 0;
	}

	// Pack & Write
	build_32b_generic_msg(qid, &enq_msg0, &enq_msg1);

	// Write one entry to message header
	sec_32b_msg.qid = qid;
	sec_32b_msg.msg_type = 0;
	write_enq_msg_header(msg_header_queue_ptr, sec_32b_msg, MAX_WK_MSG);

	#ifdef PRINT_DBG_MSG
		debug_sec_drv (" *** End build_sec_32b_src2buf_wq_msg *** \n");
		debug_sec_drv("\n");
	#endif
}

void build_sec_64b_src2buf_wq_msg(int qid, int fpqnum, int henqnum, int hfpsel,
                                    int nxt_bufnum,
                                    unsigned int bufdatalen, unsigned long long bufaddr,
                                    unsigned int nxt_bufdatalen_1, unsigned long long nxt_bufaddr_1,
                                    unsigned int nxt_bufdatalen_2, unsigned long long nxt_bufaddr_2,
                                    unsigned int nxt_bufdatalen_3, unsigned long long nxt_bufaddr_3,
                                    unsigned int nxt_bufdatalen_4, unsigned long long nxt_bufaddr_4,
                                    unsigned long long tknaddr, int user_info,
                                    enq_msg_header_queue*  msg_header_queue_ptr)
{
	msg_16b_field_0_t  enq_msg0;
	msg_16b_field_1_t  enq_msg1;
	msg_16b_field_2_t  enq_msg2;
	msg_16b_field_3_t  enq_msg3;
	msg_16b_t          intstream;
	enq_msg_header     sec_64b_msg;

	int                i;
	unsigned long long tmp;
	unsigned long long hopinfo_lsbs;

	debug_sec_drv (" *** Start build_sec_64b_src2buf_wq_msg *** \n");

	// Form enqueue message
	enq_msg0.BufDataLength = bufdatalen;
	enq_msg0.DataAddr = bufaddr;
	enq_msg0.FPQNum = (SEC_ASSOC_QM_ID << 10) | fpqnum;
	enq_msg0.UserInfo = user_info;
	enq_msg0.NV = 1;
	enq_msg0.LL = 0;
	enq_msg0.ELErr = 0;
	enq_msg0.LEI   = 0;
	enq_msg0.LErr= 0;


	tmp = 0x00; tmp = tmp << 46;
	hopinfo_lsbs = (tknaddr >> 4) & 0x3FFFFFFFFF;
	hopinfo_lsbs = hopinfo_lsbs | tmp;
	enq_msg1.HopInfoLSBs = hopinfo_lsbs;
	enq_msg1.HR = 0; // It's OK to set this to 1, but try later
	enq_msg1.HFPSel = hfpsel;
	enq_msg1.HEnqNum = (SEC_ASSOC_QM_ID << 10) |  henqnum;

	enq_msg2.NxtBufDataLength1 = nxt_bufdatalen_1;
	enq_msg2.NxtDataAddr1      = nxt_bufaddr_1;

	if (nxt_bufnum >= 2)
	{
		enq_msg2.NxtBufDataLength2 = nxt_bufdatalen_2;
		enq_msg2.NxtDataAddr2      = nxt_bufaddr_2;
	}
	else
	{
		enq_msg2.NxtBufDataLength2 = 0x7800;
		enq_msg2.NxtDataAddr2      = 0x7ffffffffff;
	}

	if (nxt_bufnum >= 3)
	{
		enq_msg3.NxtBufDataLength3 = nxt_bufdatalen_3;
		enq_msg3.NxtDataAddr3      = nxt_bufaddr_3;
	}
	else
	{
		enq_msg3.NxtBufDataLength3 = 0x7800;
		enq_msg3.NxtDataAddr3      = 0x7ffffffffff;
	}

	if (nxt_bufnum >= 4)
	{
		enq_msg3.NxtBufDataLength4 = nxt_bufdatalen_4;
		enq_msg3.NxtDataAddr4      = nxt_bufaddr_4;
	}
	else
	{
		enq_msg3.NxtBufDataLength4 = 0x7800;
		enq_msg3.NxtDataAddr4      = 0x7ffffffffff;
	}

	// Pack & Write
	build_64b_generic_msg(qid, &enq_msg0, &enq_msg1, &enq_msg2, &enq_msg3);

	// Write one entry to message header
	sec_64b_msg.qid = qid;
	sec_64b_msg.msg_type = 1;
	write_enq_msg_header(msg_header_queue_ptr, sec_64b_msg, MAX_WK_MSG);

	debug_sec_drv (" *** enq_ptr = 0x%08x\n", enq_ptr[qid]);
	debug_sec_drv (" *** user_info = 0x%08x\n", user_info);

	debug_sec_drv (" *** End   build_sec_64b_src2buf_wq_msg *** \n");
}

void build_sec_16b_fp_msg(int qid, unsigned int bufdatalen, unsigned long long bufaddr, int user_info,
                          enq_msg_header_queue* msg_header_queue_ptr)
{
	msg_16b_field_0_t  enq_msg0;
	msg_16b_t          intstream;
	enq_msg_header     sec_16b_msg;

	int                i;

	// Form enqueue message
	enq_msg0.BufDataLength = bufdatalen;
	enq_msg0.DataAddr = bufaddr;
	enq_msg0.ELErr = 0;
	enq_msg0.LEI   = 0;
	enq_msg0.LErr= 0;
	enq_msg0.UserInfo = user_info;
	enq_msg0.HL = 0;
	enq_msg0.LL = 0;
	enq_msg0.NV = 0;

	if (enq_ptr[qid] >= MAX_QUEUE_SIZE)
	{
		enq_ptr[qid] = 0;
	}

	// Pack & Write
	intstream.field0 = enq_msg0;

	for(i = 0; i < 4; i++)
	{
		WRITE32((CPU_OFFSET_ADDR + ((MEM_BASE_ADDR + (MAX_QUEUE_SIZE * qid))) + enq_ptr[qid]), intstream.raw[i]);
		enq_ptr[qid] += 4;
		if (enq_ptr[qid] >= MAX_QUEUE_SIZE)
		{
			enq_ptr[qid] = 0;
		}
	}

	// Write one entry to message header
	sec_16b_msg.qid = qid;
	sec_16b_msg.msg_type = 0;
	write_enq_msg_header(msg_header_queue_ptr, sec_16b_msg, MAX_FP_MSG);
}

int chk_rslt_tkn(msg_16b_t* cm_msg_field1_ptr, unsigned long long expect_base_addr, int mem_len)
{
	unsigned long long rslt_tkn_base_addr;
	int no_of_error;

	#ifdef PRINT_DBG_MSG
		debug_sec_drv (" *** Start chk_rslt_tkn *** \n");
	#endif

	rslt_tkn_base_addr = ((*cm_msg_field1_ptr).field1.HopInfoLSBs) << 4;
	rslt_tkn_base_addr = rslt_tkn_base_addr & 0x3ffffffffff;
	rslt_tkn_base_addr = rslt_tkn_base_addr + CPU_OFFSET_ADDR;

	#ifdef PRINT_DBG_MSG
		debug_sec_drv (" *** rslt_tkn_base_addr = 0x%08x\n", rslt_tkn_base_addr);
		debug_sec_drv ("; expect_tkn_base_addr = 0x%08x\n", expect_base_addr);
		debug_sec_drv ("; mem_len = 0x%08x\n", mem_len);
	#endif

	// Check word0
	no_of_error = chk_mem(rslt_tkn_base_addr, expect_base_addr, 4);
	// For now, does not check words 1, 2 of result token due to context address hack, number of deallocated buffer
	mem_len = mem_len - 16;
	// Check word3 and upper if any

	if (mem_len > 0)
	{
		no_of_error += chk_mem(rslt_tkn_base_addr+16, expect_base_addr+16, mem_len);
	}

	if (no_of_error > 0)
	{
		debug_sec_drv (" *** ERROR in checking result token *** \n");
	}

	#ifdef PRINT_DBG_MSG
		debug_sec_drv (" *** End   chk_rslt_tkn *** \n");
	#endif

	return no_of_error;
}

void build_sec_64b_sll_dll_wq_msg(int qid, int fpqnum, int henqnum, int hfpsel,
                                    int bufdatalen, unsigned long long bufaddr, 
                                    int total_datalen_ll,
                                    int nxt_bufdatalen_1, unsigned long long nxt_bufaddr_1, 
                                    int nxt_bufdatalen_2, unsigned long long nxt_bufaddr_2, 
                                    int nxt_bufdatalen_3, unsigned long long nxt_bufaddr_3, 
                                    unsigned long long sll_ptr, int sll_len,
                                    unsigned long long dll_ptr, int dll_len,
                                    unsigned long long tknaddr, int user_info,
                                    enq_msg_header_queue*  msg_header_queue_ptr)
{
	msg_16b_field_0_t  enq_msg0;
	msg_16b_field_1_t  enq_msg1;
	msg_16b_field_2_t  enq_msg2;
	msg_16b_field_3_t  enq_msg3;
	msg_16b_t          intstream;

	enq_msg_header     sec_64b_msg;

	int                i;
	unsigned long long tmp;
	unsigned long long hopinfo_lsbs;
	unsigned long long hopinfo_msbs;

	// Form enqueue message
	enq_msg0.BufDataLength = bufdatalen;
	enq_msg0.DataAddr = bufaddr;
	enq_msg0.FPQNum = (SEC_ASSOC_QM_ID << 10) | fpqnum;
	enq_msg0.UserInfo = user_info;
	enq_msg0.NV = 1;
	enq_msg0.LL = 1;

	enq_msg0.ELErr = 0;
	enq_msg0.LEI   = 0;
	enq_msg0.LErr= 0;

	tmp = 0x3;
	tmp = tmp << 46;
	hopinfo_lsbs = (tknaddr >> 4) & 0x3FFFFFFFFF;
	hopinfo_lsbs = hopinfo_lsbs | tmp;
	tmp = dll_len&0xf;
	tmp = (tmp << 38) & 0x3fffffffff;
	hopinfo_lsbs = hopinfo_lsbs | tmp;
	enq_msg1.HopInfoLSBs = hopinfo_lsbs;

	tmp = ((dll_len>> 4) & 0xf);
	tmp = (tmp << 44) & 0xfffffffffff;
	hopinfo_msbs = (dll_ptr& 0x3ffffffffff);
	hopinfo_msbs = hopinfo_msbs | tmp;
	enq_msg1.HopInfoMSBs = hopinfo_msbs;

	enq_msg1.HR = 0; // It's OK to set this to 1, but try later
	enq_msg1.HFPSel = hfpsel;
	enq_msg1.HEnqNum = (SEC_ASSOC_QM_ID << 10) |  henqnum;
	enq_msg1.TotDataLengthLinkListLSBs = total_datalen_ll & 0x00fff;

	enq_msg2.NxtBufDataLength1 = nxt_bufdatalen_1;
	enq_msg2.NxtDataAddr1      = nxt_bufaddr_1;

	enq_msg2.NxtBufDataLength2 = nxt_bufdatalen_2;
	enq_msg2.NxtDataAddr2      = nxt_bufaddr_2;

	enq_msg3.NxtBufDataLength3 = nxt_bufdatalen_3;
	enq_msg3.NxtDataAddr3      = nxt_bufaddr_3;

	enq_msg3.NxtBufDataLength4 = (sll_len & 0xff) | ((total_datalen_ll & 0xff000) >> 4);
	enq_msg3.NxtDataAddr4      = sll_ptr;

	// Pack & Write
	build_64b_generic_msg(qid, &enq_msg0, &enq_msg1, &enq_msg2, &enq_msg3);

	// Write one entry to message header
	sec_64b_msg.qid = qid;
	sec_64b_msg.msg_type = 2;
	write_enq_msg_header(msg_header_queue_ptr, sec_64b_msg, MAX_WK_MSG);

	debug_sec_drv (" *** enq_ptr = 0x%08x\n", enq_ptr[qid]);
	debug_sec_drv (" *** user_info = 0x%08x\n", user_info);
}

void build_sec_64b_sll_bufmd_wq_msg(int qid, int fpqnum, int henqnum, int hfpsel,
                                    int bufdatalen, unsigned long long bufaddr, 
                                    int total_datalen_ll,
                                    int nxt_bufdatalen_1, unsigned long long nxt_bufaddr_1, 
                                    int nxt_bufdatalen_2, unsigned long long nxt_bufaddr_2, 
                                    int nxt_bufdatalen_3, unsigned long long nxt_bufaddr_3, 
                                    unsigned long long sll_ptr, int sll_len,
                                    unsigned long long tknaddr, int user_info,
                                    enq_msg_header_queue*  msg_header_queue_ptr)
{
	msg_16b_field_0_t  enq_msg0;
	msg_16b_field_1_t  enq_msg1;
	msg_16b_field_2_t  enq_msg2;
	msg_16b_field_3_t  enq_msg3;
	msg_16b_t          intstream;

	enq_msg_header     sec_64b_msg;

	int                i;

	unsigned long long tmp;
	unsigned long long hopinfo_lsbs;
	unsigned long long hopinfo_msbs;

	// Form enqueue message
	enq_msg0.BufDataLength = bufdatalen;
	enq_msg0.DataAddr = bufaddr;
	enq_msg0.FPQNum = (SEC_ASSOC_QM_ID << 10) | fpqnum;
	enq_msg0.UserInfo = user_info;
	enq_msg0.NV = 1;
	enq_msg0.LL = 1;
	enq_msg0.HL = 0;
	enq_msg0.C  = 0;

	enq_msg0.ELErr = 0;
	enq_msg0.LEI   = 0;
	enq_msg0.LErr  = 0;

	tmp = 0x00; tmp = tmp << 46;
	hopinfo_lsbs = (tknaddr >> 4) & 0x3FFFFFFFFF;
	hopinfo_lsbs = hopinfo_lsbs | tmp;
	enq_msg1.HopInfoLSBs = hopinfo_lsbs;

	//enq_msg1.HR = rand() & 0x1;
	enq_msg1.HR = 0x1;
	enq_msg1.HFPSel = hfpsel;
	enq_msg1.HEnqNum = (SEC_ASSOC_QM_ID << 10) |  henqnum;
	enq_msg1.TotDataLengthLinkListLSBs = total_datalen_ll & 0x00fff;

	enq_msg2.NxtBufDataLength1 = nxt_bufdatalen_1;
	enq_msg2.NxtDataAddr1      = nxt_bufaddr_1;

	enq_msg2.NxtBufDataLength2 = nxt_bufdatalen_2;
	enq_msg2.NxtDataAddr2      = nxt_bufaddr_2;

	enq_msg2.NxtFPQNumMsbs = (enq_msg0.FPQNum >> 8) & 0x0f;

	enq_msg3.NxtBufDataLength3 = nxt_bufdatalen_3;
	enq_msg3.NxtDataAddr3      = nxt_bufaddr_3;

	enq_msg3.NxtBufDataLength4 = (sll_len & 0xff) | ((total_datalen_ll && 0xff000) >> 4);
	enq_msg3.NxtDataAddr4      = sll_ptr;

	enq_msg3.NxtFPQNum = (enq_msg0.FPQNum >> 4) & 0x0f;
	enq_msg3.NxtFPQNumLsbs = enq_msg0.FPQNum & 0x00f;
	// Pack & Write
	build_64b_generic_msg(qid, &enq_msg0, &enq_msg1, &enq_msg2, &enq_msg3);

	// Write one entry to message header
	sec_64b_msg.qid = qid;
	sec_64b_msg.msg_type = 2;
	write_enq_msg_header(msg_header_queue_ptr, sec_64b_msg, MAX_WK_MSG);

	debug_sec_drv (" *** enq_ptr = 0x%08x\n", enq_ptr[qid]);
	debug_sec_drv (" *** user_info = 0x%08x\n", user_info);
}

void build_sec_bufmd_wq_msg(int qid, int fpqnum, int henqnum, int hfpsel,
                                    unsigned int num_of_buf, unsigned int cur_buf_pos, 
                                    unsigned short* buf_len_ptr, unsigned long long* buf_addr_ptr,
                                    unsigned long long sll_ptr,
                                    unsigned long long tknaddr, int user_info,
                                    enq_msg_header_queue*  msg_header_queue_ptr)
{
	int i;
	int TotDataLengthLinkList;

	#ifdef PRINT_DBG_MSG
		unsigned long long msg_ptr;
	#endif

	if (num_of_buf > 5) //Need to build linked-list
	{
		TotDataLengthLinkList = build_linked_list(sll_ptr, cur_buf_pos+4, num_of_buf-4, buf_addr_ptr, buf_len_ptr);
		#ifdef PRINT_DBG_MSG
			debug_sec_drv(" build_sec_bufmd_wq_msg: TotDataLengthLinkList = 0x%08x\n", TotDataLengthLinkList);
			dump_mem(sll_ptr + CPU_OFFSET_ADDR, ((((num_of_buf - 4) >> 1) + 1) << 1) << 3);
		#endif

		build_sec_64b_sll_bufmd_wq_msg(qid, fpqnum, henqnum, hfpsel,
										gen_rand_buf_len_code(buf_len_ptr[cur_buf_pos]),   buf_addr_ptr[cur_buf_pos]  - CPU_OFFSET_ADDR,
										TotDataLengthLinkList,
										gen_rand_buf_len_code(buf_len_ptr[cur_buf_pos+1]), buf_addr_ptr[cur_buf_pos+1]- CPU_OFFSET_ADDR,
										gen_rand_buf_len_code(buf_len_ptr[cur_buf_pos+2]), buf_addr_ptr[cur_buf_pos+2]- CPU_OFFSET_ADDR,
										gen_rand_buf_len_code(buf_len_ptr[cur_buf_pos+3]), buf_addr_ptr[cur_buf_pos+3]- CPU_OFFSET_ADDR,
										sll_ptr, num_of_buf-4, tknaddr - CPU_OFFSET_ADDR, user_info, msg_header_queue_ptr);
		#ifdef PRINT_DBG_MSG
			debug_sec_drv("wqid = 0x%08x; hfpsel = 0x%08x\n", qid, hfpsel);
			msg_ptr = enq_ptr[qid] - 64;
			for (i = 0; i < 16; i++)
			{
				debug_sec_drv("WQ_MSG_[%d] = 0x%08x\n", i, RD_MEM32(CPU_OFFSET_ADDR + MEM_BASE_ADDR + qid*MAX_QUEUE_SIZE + msg_ptr+ i*4));
			}
			debug_sec_drv("\n");
		#endif
	}
	else if (num_of_buf > 1)
	{
		build_sec_64b_src2buf_wq_msg (qid, fpqnum, henqnum, hfpsel,
										num_of_buf,
										gen_rand_buf_len_code(buf_len_ptr[cur_buf_pos]),   buf_addr_ptr[cur_buf_pos]  - CPU_OFFSET_ADDR,
										gen_rand_buf_len_code(buf_len_ptr[cur_buf_pos+1]), buf_addr_ptr[cur_buf_pos+1]- CPU_OFFSET_ADDR,
										gen_rand_buf_len_code(buf_len_ptr[cur_buf_pos+2]), buf_addr_ptr[cur_buf_pos+2]- CPU_OFFSET_ADDR,
										gen_rand_buf_len_code(buf_len_ptr[cur_buf_pos+3]), buf_addr_ptr[cur_buf_pos+3]- CPU_OFFSET_ADDR,
										gen_rand_buf_len_code(buf_len_ptr[cur_buf_pos+4]), buf_addr_ptr[cur_buf_pos+4]- CPU_OFFSET_ADDR,
										tknaddr - CPU_OFFSET_ADDR, user_info, msg_header_queue_ptr);
		#ifdef PRINT_DBG_MSG
			debug_sec_drv("wqid = 0x%08x; hfpsel = 0x%08x\n", qid, hfpsel);
			msg_ptr = enq_ptr[qid] - 64;
			for (i = 0; i < 16; i++)
			{
				debug_sec_drv("WQ_MSG_[%d] = 0x%08x\n", i, RD_MEM32(CPU_OFFSET_ADDR + MEM_BASE_ADDR + qid*MAX_QUEUE_SIZE + msg_ptr+ i*4));
			}
			debug_sec_drv ("\n");
		#endif
	}
	else if (num_of_buf = 1)
	{
		build_sec_32b_src2buf_wq_msg (qid, fpqnum, henqnum, hfpsel,
		gen_rand_buf_len_code(buf_len_ptr[cur_buf_pos]), buf_addr_ptr[cur_buf_pos] - CPU_OFFSET_ADDR,
		tknaddr, user_info, msg_header_queue_ptr);
		#ifdef PRINT_DBG_MSG
			debug_sec_drv("wqid = 0x%08x; hfpsel = 0x%08x\n", qid, hfpsel);
			msg_ptr = enq_ptr[qid] - 32;
			for (i = 0; i < 8; i++)
			{
				debug_sec_drv ("WQ_MSG_[%d] = 0x%08x\n", i, RD_MEM32(CPU_OFFSET_ADDR + MEM_BASE_ADDR + qid*MAX_QUEUE_SIZE + msg_ptr+ i*4));
			}
			debug_sec_drv ("\n");
		#endif
	}
	else
	{
		debug_sec_drv ("FATAL ERROR: Number of buffer is zero or smaller than 0");
	}
}

void print_sec_cm_msg_err_info (msg_16b_t *deq_msg_0)
{
	int error_code;

	error_code = (((*deq_msg_0).field0.ELErr & 0x3) << 3) | ((*deq_msg_0).field0.LErr& 0x7);

	switch (error_code)
	{
		case 0:
			debug_sec_drv ("Info: No error in completion message\n");
			break;
		case 17:
			debug_sec_drv ("ERROR: Crypto error(wrong token/context config, etc.) in completion message\n");
			break;
		case 13:
			debug_sec_drv ("ERROR: Incorrect token length error in completion message\n");
			break;
		case 3:
			debug_sec_drv ("ERROR: Freelpool running out error in completion message\n");
			break;
		case 4:
			debug_sec_drv ("ERROR: Read AXI error in completion message\n");
			break;
		case 5:
			debug_sec_drv ("ERROR: Write AXI error in completion message\n");
			break;
		case 7:
			debug_sec_drv ("ERROR: Invalid work message error in completion message\n");
			break;
		case 6:
			debug_sec_drv ("ERROR: Destination linked list read error in completion message\n");
			break;
		case 1:
			debug_sec_drv ("ERROR: Note enough entry in destination linked list error in completion message\n");
			break;
		default:
			debug_sec_drv ("ERROR: Unknown error code in completion message, {ELErr, LErr}= 0x%08x\n", error_code);
			break;
	}
}

int gen_sec_user_info(unsigned char crypto_core_type)
{
	int user_info;
	int random_num;

	random_num = rand() & 0xfffff;

	if((crypto_core_type == EIP96_CORE_TYPE) || (crypto_core_type == EIP62_CORE_TYPE))
	{
		user_info = random_num;
	}
	else
	{
		user_info = (1 << 21) | random_num;
	}
	random_num = rand() & 0xfffe00000;
	user_info = user_info | random_num;

	return user_info;
}

int get_sec_wqid(unsigned char crypto_core_type)
{
	int wqid;

	if (crypto_core_type == XTS_CORE_TYPE)
	{
		wqid = WQID6;
	}
	else //EIP96/EIP62
	{
		wqid = WQID5;
	}

	return wqid;
}

int gen_sec_fpqid()
{
	int fpqid;
	int random_num = rand();

	fpqid = FPQID9 + (random_num & 0x7);

	return fpqid;
}

int get_sec_hfpsel(int fpqid)
{
	int hfpsel;

	hfpsel = (fpqid - FPQID9) & 0x7;

	return hfpsel;
}

#endif /*__SEC_DRIVER_C__*/

