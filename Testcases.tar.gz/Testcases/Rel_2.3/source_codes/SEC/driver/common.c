/*
 * common.c
 *
 *  Created on: May 29, 2014
 *      Author: ldinh
 */

//Tinh-SLT:
#define printPASS printPASS_slt_sec
#define printFAIL printFAIL_slt_sec

//End of Tinh-SLT

void printPASS(void) {

	printf("\n\n");
	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
	printf ("$$$$ RESULT: TEST PASS $$$$\n");
	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
	printf("\n\n");
}

void printFAIL(void) {

    printf("\n\n");
	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
	printf ("$$$$ RESULT: TEST FAILED $$$$\n");
	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
	printf("\n\n");
}
