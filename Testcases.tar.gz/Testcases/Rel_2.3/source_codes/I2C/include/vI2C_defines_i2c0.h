#ifndef __APM_I2C_H__
#define __APM_I2C_H__

//#include "apm_i2c_regmap.h" //__tp__

/***************
 * I2C port
 ***************/
#define MAMBA_I2C0		0
#define MAMBA_I2C1		1

#define I2C_TIMEOUT		0x100000

/***************
 * I2C mode
 ***************/

#define	I2C_STANDARD_SPEED		1	/* 100kHz */
#define	I2C_FAST_SPEED			2	/* 400kHz */
#define	I2C_FAST_PLUS			4	/* 400kHz */
#define	I2C_HIGH_SPEED			3	/* 3.4MHz */

/***************
 * Address mode
 ***************/
#define	ADDRESSING_7BIT			0
#define	ADDRESSING_10BIT		1

/***************
 * Other define
 ***************/
#define I2C_NO_BYTES_RW_TEST			14
#define I2C_NO_BYTES_RX_OVER			8
#define I2C_ADDR_RW_TEST1				0x6000
#define I2C_ADDR_RW_TEST2				0x6000
#define I2C_NO_BYTES_SLAVE_TRANSMIT		0x1
#define I2C_NO_BYTES_TX_OVER			9

/***************
 * Device Adress
 ***************/
#define I2C_GENCALL_ADDR		0
#define I2C0_DEVICE_ADDR10		0x300
#define I2C0_DEVICE_ADDR		0x30
#define I2C0_EEPROM_ADDR		0x51
#define I2C1_EEPROM_ADDR		0x52
#define I2C_DDR_EEPROM_ADDR		0x51
#define I2C_LCD_ADDR 			0x3A
#define I2C_CORE_VOLT_ADC_ADDR	0x19
#define I2C_TEMPSENSOR_ADDR		0x19 /* place holder */
#define I2C_AARDVARK_ADDR		0x60



#endif
