#ifndef I2C_REG
#define I2C_REG
/*    Address I2C_REG  Registers */
//#define CONFIG_SYS_PERIPHERAL_BASE  0xE0000000
/*#define I2C0_BASE  					0x10512000*/
#define I2C1_BASE  					0x10511000
#define I2C0_BASE  					0x10512000

#define SCU_CLKCFGSEL				0x17000240

/*    Address I2C_REG  Registers */
#define I2C_CON_ADDR                                                 0x00000000		//RW
#define I2C_CON_DEFAULT                                              0x00000045
#define I2C_TAR_ADDR                                                 0x00000004
#define I2C_TAR_DEFAULT                                              0x00000056
#define I2C_SAR_ADDR                                                 0x00000008
#define I2C_SAR_DEFAULT                                              0x00000055
#define I2C_HS_MADDR_ADDR                                            0x0000000c
#define I2C_HS_MADDR_DEFAULT                                         0x00000001
#define I2C_DATA_CMD_ADDR                                            0x00000010
#define I2C_DATA_CMD_DEFAULT                                         0x00000000
#define I2C_SS_SCL_HCNT_ADDR                                         0x00000014
#define I2C_SS_SCL_HCNT_DEFAULT                                      0x00000190
#define I2C_SS_SCL_LCNT_ADDR                                         0x00000018
#define I2C_SS_SCL_LCNT_DEFAULT                                      0x000001d6
#define I2C_FS_SCL_HCNT_ADDR                                         0x0000001c
#define I2C_FS_SCL_HCNT_DEFAULT                                      0x0000003c
#define I2C_FS_SCL_LCNT_ADDR                                         0x00000020
#define I2C_FS_SCL_LCNT_DEFAULT                                      0x00000082
#define I2C_HS_SCL_HCNT_ADDR                                         0x00000024
#define I2C_HS_SCL_HCNT_DEFAULT                                      0x00000006
#define I2C_HS_SCL_LCNT_ADDR                                         0x00000028
#define I2C_HS_SCL_LCNT_DEFAULT                                      0x00000010

#define I2C_INTR_STAT_ADDR                                           0x0000002c		//RO
#define I2C_INTR_STAT_DEFAULT                                        0x00000000

#define I2C_INTR_MASK_ADDR                                           0x00000030		//RW
#define I2C_INTR_MASK_DEFAULT                                        0x00000000

#define I2C_RAW_INTR_STAT_ADDR                                       0x00000034		//RO
#define I2C_RAW_INTR_STAT_DEFAULT                                    0x00000000

#define I2C_RX_TL_ADDR                                               0x00000038		//RW
#define I2C_RX_TL_DEFAULT                                            0x00000000
#define I2C_TX_TL_ADDR                                               0x0000003c
#define I2C_TX_TL_DEFAULT                                            0x00000000

#define I2C_CLR_INTR_ADDR                                            0x00000040		//RO
#define I2C_CLR_INTR_DEFAULT                                         0x00000000
#define I2C_CLR_RX_UNDER_ADDR                                        0x00000044
#define I2C_CLR_RX_UNDER_DEFAULT                                     0x00000000
#define I2C_CLR_RX_OVER_ADDR                                         0x00000048
#define I2C_CLR_RX_OVER_DEFAULT                                      0x00000000
#define I2C_CLR_TX_OVER_ADDR                                         0x0000004c
#define I2C_CLR_TX_OVER_DEFAULT                                      0x00000000
#define I2C_CLR_RD_REQ_ADDR                                          0x00000050
#define I2C_CLR_RD_REQ_DEFAULT                                       0x00000000
#define I2C_CLR_TX_ABRT_ADDR                                         0x00000054
#define I2C_CLR_TX_ABRT_DEFAULT                                      0x00000000
#define I2C_CLR_RX_DONE_ADDR                                         0x00000058
#define I2C_CLR_RX_DONE_DEFAULT                                      0x00000000
#define I2C_CLR_ACTIVITY_ADDR                                        0x0000005c
#define I2C_CLR_ACTIVITY_DEFAULT                                     0x00000000
#define I2C_CLR_STOP_DET_ADDR                                        0x00000060
#define I2C_CLR_STOP_DET_DEFAULT                                     0x00000000
#define I2C_CLR_START_DET_ADDR                                       0x00000064
#define I2C_CLR_START_DET_DEFAULT                                    0x00000000
#define I2C_CLR_GEN_CALL_ADDR                                        0x00000068
#define I2C_CLR_GEN_CALL_DEFAULT                                     0x00000000

#define I2C_ENABLE_ADDR                                              0x0000006c		//RW
#define I2C_ENABLE_DEFAULT                                           0x00000000

#define I2C_STATUS_ADDR                                              0x00000070		//RO
#define I2C_STATUS_DEFAULT                                           0x00000006
#define I2C_TXFLR_ADDR                                               0x00000074
#define I2C_TXFLR_DEFAULT                                            0x00000000
#define I2C_RXFLR_ADDR                                               0x00000078
#define I2C_SDA_HOLD_ADDR											 0x0000007c
#define I2C_SDA_HOLD_DEFAULT										 0x00000000

#define I2C_RXFLR_DEFAULT                                            0x00000000
#define I2C_TX_ABRT_SOURCE_ADDR                                      0x00000080
#define I2C_TX_ABRT_SOURCE_DEFAULT                                   0x00000000

#define I2C_SLV_DATA_NACK_ONLY_ADDR                                  0x00000084		//RW
#define I2C_SLV_DATA_NACK_ONLY_DEFAULT                               0x00000000
#define I2C_SDA_SETUP_ADDR                                           0x00000094
#define I2C_SDA_SETUP_DEFAULT                                        0x00000064
#define I2C_ACK_GENERAL_CALL_ADDR                                    0x00000098
#define I2C_ACK_GENERAL_CALL_DEFAULT                                 0x00000001

#define I2C_ENABLE_STATUS_ADDR                                       0x0000009c		//RO
#define I2C_ENABLE_STATUS_DEFAULT                                    0x00000000
#define I2C_COMP_PARAM_1_ADDR                                        0x000000f4
#define I2C_COMP_PARAM_1_DEFAULT                                     0x000303aa
#define I2C_COMP_VERSION_ADDR                                        0x000000f8
#define I2C_COMP_VERSION_DEFAULT                                     0x00000000
#define I2C_COMP_TYPE_ADDR                                           0x000000fc
#define I2C_COMP_TYPE_DEFAULT                                        0x44570140
#endif
