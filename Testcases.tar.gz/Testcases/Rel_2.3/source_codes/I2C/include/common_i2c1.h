/* Author: automation@apm.com
*  Company: Applied Micro Circuits Corporation (AMCC)
*
* Describe the purpose of your Test here
*   - Include all common functions here
*/

#define OCM_RESULT_ADDR 0x1D009000
#define OCM_FINISH_ADDR 0x1D00A900

#define OCM_READ(add) (*(volatile unsigned *)(add))
#define OCM_WRITE(add, data) *(unsigned *)(add) = (unsigned )(data)

void printPASS_i2c1(void) {

	printf("\n\n");
	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
	printf ("$$$$ RESULT: TEST PASS $$$$\n");
	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
	printf("\n\n");

#ifdef OCM 
    OCM_WRITE(OCM_RESULT_ADDR,0x0);                 //Clear Addr first
    printf("Read=0x%08x\n",OCM_READ(OCM_RESULT_ADDR));
    OCM_WRITE(OCM_RESULT_ADDR,0xCAFECAFE);          //Test PASS
    printf("Read=0x%08x\n",OCM_READ(OCM_RESULT_ADDR));

    OCM_WRITE(OCM_FINISH_ADDR,0x3);                 //Test Complete
    printf("Read=0x%08x\n",OCM_READ(OCM_FINISH_ADDR));
#endif
}

void printFAIL_i2c1(void) {

    printf("\n\n");
    printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
    printf ("$$$$ RESULT: TEST FAILED $$$$\n");
    printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
	printf("\n\n");

#ifdef OCM
    OCM_WRITE(OCM_RESULT_ADDR,0x0);                 //Clear Addr first
    printf("Read=0x%08x\n",OCM_READ(OCM_RESULT_ADDR));
    OCM_WRITE(OCM_RESULT_ADDR,0xDEADBEEF);          //Test FAIL
    printf("Read=0x%08x\n",OCM_READ(OCM_RESULT_ADDR));
    
    OCM_WRITE(OCM_FINISH_ADDR,0x3);                 //Test Complete
    printf("Read=0x%08x\n",OCM_READ(OCM_FINISH_ADDR));
#endif
}

