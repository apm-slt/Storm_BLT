int intr_det = 0;
int buf_sla_rcv[16];
void v_delayms(u32_s count)
{
	int i;
	for (i=0;i<10*count;i++);
}

void i2c0_startdet_intr(void){
	u32_s base;
	base = I2C0_BASE;
	APM_NOTICE("interrupt i2c0 start_det detect\n");
	i2c_read32(base + I2C_CLR_START_DET_ADDR);
	intr_det = 1;
}
void i2c1_startdet_intr(void){
	u32_s base;
	base = I2C1_BASE;
	APM_NOTICE("interrupt i2c1 start_det detect\n");
	i2c_read32(base + I2C_CLR_START_DET_ADDR);
	intr_det = 1;
}

void i2c0_stopdet_intr(void){
	u32_s base;
	base = I2C0_BASE;
	APM_NOTICE("interrupt i2c0 stopdet detect\n");
	i2c_read32(base + I2C_CLR_STOP_DET_ADDR);
	intr_det = 1;
}
void i2c1_stopdet_intr(void){
	u32_s base;
	base = I2C1_BASE;
	APM_NOTICE("interrupt i2c1 stopdet detect\n");
	i2c_read32(base + I2C_CLR_STOP_DET_ADDR);
	intr_det = 1;
}

void i2c0_activity_intr(void){
	u32_s base;
	base = I2C0_BASE;
	APM_NOTICE("interrupt i2c0 activity detect\n");
	i2c_read32(base + I2C_CLR_ACTIVITY_ADDR);
	intr_det = 1;

}
void i2c1_activity_intr(void){
	u32_s base;
	base = I2C1_BASE;
	APM_NOTICE("interrupt i2c1 activity detect\n");
	i2c_read32(base + I2C_CLR_ACTIVITY_ADDR);
	intr_det = 1;
}

void i2c0_txempty_intr(void){
	u32_s base;
	base = I2C0_BASE;
	APM_NOTICE("interrupt i2c0 txempty detect\n");
	i2c_write32(base + I2C_INTR_MASK_ADDR , 0);
	intr_det = 1;

}
void i2c1_txempty_intr(void){
	u32_s base;
	base = I2C1_BASE;
	APM_NOTICE("interrupt i2c1 txempty detect\n");
	i2c_write32(base + I2C_INTR_MASK_ADDR , 0);
	intr_det = 1;
}

void i2c0_txover_intr(void){
	u32_s base;
	base = I2C0_BASE;
	APM_NOTICE("interrupt i2c0 txover detect\n");
	i2c_read32(base + I2C_CLR_TX_OVER_ADDR);
	intr_det = 1;

}
void i2c1_txover_intr(void){
	u32_s base;
	base = I2C1_BASE;
	APM_NOTICE("interrupt i2c1 txover detect\n");
	i2c_read32(base + I2C_CLR_TX_OVER_ADDR);
	intr_det = 1;
}

void i2c0_rxfull_intr(void){
	u32_s base;
	base = I2C0_BASE;
	int data,i;
	v_delayms(10000);
	APM_NOTICE("interrupt i2c0 rxfull detect\n");
	intr_det = 1;
	for(i=0;i<8;i++){
		data = i2c_read32(base + I2C_DATA_CMD_ADDR);
	}

}
void i2c1_rxfull_intr(void){
	u32_s base;
	base = I2C1_BASE;
	int data,i;

	v_delayms(10000);
	APM_NOTICE("interrupt i2c1 rxfull detect\n");
	intr_det = 1;
	for(i=0;i<8;i++){
		data = i2c_read32(base + I2C_DATA_CMD_ADDR);
	}

}
void i2c0_rxover_intr(void){
	u32_s base;
	base = I2C0_BASE;
	APM_NOTICE("interrupt i2c0 rxover detect\n");
	i2c_read32(base + I2C_CLR_RX_OVER_ADDR);
	intr_det = 1;

}
void i2c1_rxover_intr(void){
	u32_s base;
	base = I2C1_BASE;
	APM_NOTICE("interrupt i2c1 rxover detect\n");
	i2c_read32(base + I2C_CLR_RX_OVER_ADDR);
	intr_det = 1;

}

void i2c0_rxunder_intr(void){
	u32_s base;
	base = I2C0_BASE;
	APM_NOTICE("interrupt i2c0 rxunder detect\n");
	i2c_read32(base + I2C_CLR_RX_UNDER_ADDR);
	intr_det = 1;

}
void i2c1_rxunder_intr(void){
	u32_s base;
	base = I2C1_BASE;
	APM_NOTICE("interrupt i2c1 rxunder detect\n");
	i2c_read32(base + I2C_CLR_RX_UNDER_ADDR);
	intr_det = 1;

}

void i2c0_rdreq_intr(void){
	u32_s base,data=I2C_PATTERN;
	base = I2C0_BASE;
	int i,j;
	i2c_read32(base + I2C_CLR_RD_REQ_ADDR);
	for(i=0;i<16;i++){
		i2c_write32(base + I2C_DATA_CMD_ADDR, data++);
	}
	APM_NOTICE("Interrupt i2c0 RD_REQ detect\n");

	intr_det = 1;
}

void i2c0_rdreq_rxdone_intr(void){
	u32_s base,data=I2C_PATTERN;
	base = I2C0_BASE;
	int i,j,error;
	i2c_read32(base + I2C_CLR_RD_REQ_ADDR);
	error = I2C0_RXDONE_interrupt_config();

	for(i=0;i<16;i++){
		i2c_write32(base + I2C_DATA_CMD_ADDR, data++);
	}
	APM_NOTICE("Interrupt i2c0 RD_REQ detect\n");

	intr_det = 1;
}

void i2c0_rxdone_intr(void){
	u32_s base;
	base = I2C0_BASE;
	APM_NOTICE("interrupt i2c0 RXDONE detect\n");
	i2c_read32(base + I2C_CLR_RX_DONE_ADDR);

	printf("i2c_read32(base + I2C_INTR_STAT_ADDR):%x\n",i2c_read32(base + I2C_INTR_STAT_ADDR));

	intr_det = 1;
}
void i2c0_abrt_7b_addr_noack(void){
	u32_s base;
	base = I2C0_BASE;
	int check;
	APM_NOTICE("Interrupt i2c0 TX_ABRT detect --- i2c0_abrt_7b_addr_noack\n");
	check = i2c_read32(base + I2C_TX_ABRT_SOURCE_ADDR);
	printf("check: %x\n",check);
	if (check & 0x01)
		intr_det = 1;
	else
		intr_det = 0;

	i2c_read32(base + I2C_CLR_TX_ABRT_ADDR);

}
void i2c1_abrt_7b_addr_noack(void){
	u32_s base;
	base = I2C1_BASE;
	int check;
	APM_NOTICE("Interrupt i2c1 TX_ABRT detect --- i2c1_abrt_7b_addr_noack\n");
	check = i2c_read32(base + I2C_TX_ABRT_SOURCE_ADDR);
	if (check & 0x01)
		intr_det = 1;
	else
		intr_det = 0;

	i2c_read32(base + I2C_CLR_TX_ABRT_ADDR);

}

void i2c0_abrt_master_dis(void){
	u32_s base;
	base = I2C0_BASE;
	int check;
	APM_NOTICE("Interrupt i2c0 TX_ABRT detect --- i2c0_abrt_master_dis\n");
	check = i2c_read32(base + I2C_TX_ABRT_SOURCE_ADDR);
	if (check & 0x800)
		intr_det = 1;
	else
		intr_det = 0;

	i2c_read32(base + I2C_CLR_TX_ABRT_ADDR);
}
void i2c1_abrt_master_dis(void){
	u32_s base;
	base = I2C1_BASE;
	int check;
	APM_NOTICE("Interrupt i2c1 TX_ABRT detect --- i2c1_abrt_master_dis\n");
	check = i2c_read32(base + I2C_TX_ABRT_SOURCE_ADDR);
	if (check & 0x800)
		intr_det = 1;
	else
		intr_det = 0;

	i2c_read32(base + I2C_CLR_TX_ABRT_ADDR);
}
void i2c1_abrt_master_gencall_read(void){
	u32_s base;
	base = I2C1_BASE;
	int check;
	APM_NOTICE("Interrupt i2c1 TX_ABRT_MASTER_GENCALL_READ detect\n");
	check = i2c_read32(base + I2C_TX_ABRT_SOURCE_ADDR);
//	printf("check :%x\n",check);
	if (check & 0x80)
		intr_det = 1;
	else
		intr_det = 0;

	i2c_read32(base + I2C_CLR_TX_ABRT_ADDR);
}
void i2c0_abrt_slvflush_txfifo(void){
	u32_s base;
	base = I2C0_BASE;
	int check;
	APM_NOTICE("Interrupt i2c0 TX_ABRT detect --- i2c0_abrt_slvflush_txfifo\n");
	check = i2c_read32(base + I2C_TX_ABRT_SOURCE_ADDR);
	if (check & (1<<13))
		intr_det = 1;
	else
		intr_det = 0;

	i2c_read32(base + I2C_CLR_TX_ABRT_ADDR);

}
void i2c0_rdreq_txabrt_slvflush_intr(void){
	u32_s base,data=I2C_PATTERN;
	base = I2C0_BASE;
	int i,j,error;
	i2c_read32(base + I2C_CLR_RD_REQ_ADDR);   //clear RDREQ interrupt

	i2c_write32(I2C0_BASE + I2C_INTR_MASK_ADDR , 0x1<<6);
	register_irq_handler(100, i2c0_abrt_slvflush_txfifo);

	for(i=0;i<16;i++){
		i2c_write32(base + I2C_DATA_CMD_ADDR, data++);
	}
	APM_NOTICE("Interrupt i2c0 RD_REQ detect\n");
}
void i2c0_abrt_slvrd_intx(void){
	u32_s base;
	base = I2C0_BASE;
	int check;
	APM_NOTICE("Interrupt i2c0 TX_ABRT detect --- i2c0_abrt_slvrd_intx\n");
	check = i2c_read32(base + I2C_TX_ABRT_SOURCE_ADDR);
	if (check & 0x8000)
		intr_det = 1;
	else
		intr_det = 0;

	i2c_read32(base + I2C_CLR_TX_ABRT_ADDR);

}
void i2c0_abrt_arb_lost(void){
	u32_s base;
	base = I2C0_BASE;
	int check;
	APM_NOTICE("Interrupt i2c0 TX_ABRT detect --- i2c0_abrt_arb_lost\n");
	check = i2c_read32(base + I2C_TX_ABRT_SOURCE_ADDR);
	if (check & 0x1000)
		intr_det = 1;
	else
		intr_det = 0;

	i2c_read32(base + I2C_CLR_TX_ABRT_ADDR);

}
void i2c1_abrt_arb_lost(void){
	u32_s base;
	base = I2C1_BASE;
	int check;
	APM_NOTICE("Interrupt i2c1 TX_ABRT detect --- i2c1_abrt_arb_lost\n");
	check = i2c_read32(base + I2C_TX_ABRT_SOURCE_ADDR);
	if (check & 0x1000)
		intr_det = 1;
	else
		intr_det = 0;

	i2c_read32(base + I2C_CLR_TX_ABRT_ADDR);

}
void i2c0_rdreq_slvrd_intx_txabrt_intr(void){
	u32_s base,data=0x5a;
	base = I2C0_BASE;
	int i,j;
	i2c_read32(base + I2C_CLR_RD_REQ_ADDR);

	i2c_write32(I2C0_BASE + I2C_INTR_MASK_ADDR , 0x1<<6);
	register_irq_handler(100, i2c0_abrt_slvrd_intx);
	mdelay(1000);

	i2c_write32(base + I2C_DATA_CMD_ADDR, 0x100);

}

void i2c0_abrt_10b_addr_noack(void){
	u32_s base;
	base = I2C0_BASE;
	int check;
	APM_NOTICE("Interrupt i2c0 TX_ABRT detect --- i2c0_abrt_10b_addr_noack\n");
	check = i2c_read32(base + I2C_TX_ABRT_SOURCE_ADDR);
	if (check & 0x02)
		intr_det = 1;
	else
		intr_det = 0;

	i2c_read32(base + I2C_CLR_TX_ABRT_ADDR);

}
void i2c1_abrt_10b_addr_noack(void){
	u32_s base;
	base = I2C1_BASE;
	int check;
	APM_NOTICE("Interrupt i2c1 TX_ABRT detect --- i2c1_abrt_10b_addr_noack\n");
	check = i2c_read32(base + I2C_TX_ABRT_SOURCE_ADDR);
	if (check & 0x02)
		intr_det = 1;
	else
		intr_det = 0;

	i2c_read32(base + I2C_CLR_TX_ABRT_ADDR);

}
void i2c1_txabrt_intr(void){
	u32_s base;
	base = I2C1_BASE;
	APM_NOTICE("Interrupt i2c1 TX_ABRT detect\n");
	while(1);
	i2c_read32(base + I2C_CLR_TX_ABRT_ADDR);

	intr_det = 1;
}

void i2c0_gencall_intr(void){
	u32_s base,data=0xa5;
	base = I2C0_BASE;
	APM_NOTICE("Interrupt i2c0 GEN_CALL detect\n");
	i2c_read32(base + I2C_CLR_GEN_CALL_ADDR);

	intr_det = 1;
}

void i2c0_slaveReceive(void){
	u32_s base;
	base = I2C0_BASE;
	int data[20],i,nob;

	for(i=0;i<16;i++)
		buf_sla_rcv[i]=0;
	arch_timer_msdelay(500);
	nob = i2c_read32(base + I2C_RXFLR_ADDR);

	APM_NOTICE("interrupt i2c0 rxfull detect\n");
	intr_det = 1;
	for(i=0;i<nob;i++){
		buf_sla_rcv[i] = i2c_read32(base + I2C_DATA_CMD_ADDR);
	}
}

/*
 *  @Description Generate startdet interrupt for I2C0 and I2C1
 */
void generate_startdet_interrupt(u32_s base){
	u32_s ic_data_cmd;
	ic_data_cmd = base + I2C_DATA_CMD_ADDR;
	i2c_write32(ic_data_cmd, 0x00);  //start addr
}
int start_det_interrupt_test(port){
	printf("%s\n",__FUNCTION__);
	u32_s base,time_out=1000;
	intr_det = 0;
	
	if (port == MAMBA_I2C0){
		base	= I2C0_BASE;
		register_irq_handler(100, i2c0_startdet_intr);
	}
	else if (port == MAMBA_I2C1){
		base 	= I2C1_BASE;
		register_irq_handler(101, i2c1_startdet_intr);
	}
	i2c_write32(base + I2C_INTR_MASK_ADDR , 0x1<<10);		//mask start_det interrupt
	
	generate_startdet_interrupt(base);
	
	while(time_out--){
		if (intr_det == 1)
			break;
	}
	if (intr_det == 0)
		return -1;
	return 0;
}

/*
 * @Description Generate stopdet interrupt for I2C0 and I2C1
 */
void generate_stopdet_interrupt(u32_s base){
	u32_s ic_data_cmd;
	ic_data_cmd = base + I2C_DATA_CMD_ADDR;
	i2c_write32(ic_data_cmd, 0x00);  //start addr
}
int stop_det_interrupt_test(port){
	printf("%s\n",__FUNCTION__);
	u32_s base,time_out=1000;
	intr_det = 0;

	if (port == MAMBA_I2C0){
		base	= I2C0_BASE;
		register_irq_handler(100, i2c0_stopdet_intr);
	}
	else if (port == MAMBA_I2C1){
		base 	= I2C1_BASE;
		register_irq_handler(101, i2c1_stopdet_intr);
	}
	i2c_write32(base + I2C_INTR_MASK_ADDR , 0x1<<9);		//mask stop_det interrupt

	generate_stopdet_interrupt(base);

	while(time_out--){
		if (intr_det == 1)
			break;
	}
	printf("intr_det:%x\n",intr_det);
	if (intr_det == 0)
		return -1;
	return 0;
}
/*
 * @Description Generate activity interrupt for I2C0 and I2C1
 */
void generate_activity_interrupt(u32_s base){
	u32_s ic_data_cmd;
	ic_data_cmd = base + I2C_DATA_CMD_ADDR;
	i2c_write32(ic_data_cmd, 0x00);  //start addr
}
int activity_interrupt_test(port){
	u32_s base,time_out=1000;
	intr_det = 0;
	printf("%s\n",__FUNCTION__);

	if (port == MAMBA_I2C0){
		base	= I2C0_BASE;
		register_irq_handler(100, i2c0_activity_intr);
	}
	else if (port == MAMBA_I2C1){
		base 	= I2C1_BASE;
		register_irq_handler(101, i2c1_activity_intr);
	}
	i2c_write32(base + I2C_INTR_MASK_ADDR , 0x1<<8);		//mask stop_det interrupt

	generate_activity_interrupt(base);

	while(time_out--){
		if (intr_det == 1)
			break;
	}
	if (intr_det == 0)
		return -1;
	return 0;
}
/*
 * @Description Generate txempty interrupt for I2C0 and I2C1
 */
void generate_txempty_interrupt(u32_s base){
	u32_s ic_data_cmd;
	ic_data_cmd = base + I2C_DATA_CMD_ADDR;
	i2c_write32(ic_data_cmd, 0x00);  //start addr
}
int txempty_interrupt_test(port){
	u32_s base,time_out=1000;
	intr_det = 0;
	printf("%s\n",__FUNCTION__);

	if (port == MAMBA_I2C0){
		base	= I2C0_BASE;
		register_irq_handler(100, i2c0_txempty_intr);
	}
	else if (port == MAMBA_I2C1){
		base 	= I2C1_BASE;
		register_irq_handler(101, i2c1_txempty_intr);
	}
	i2c_write32(base + I2C_INTR_MASK_ADDR , 0x1<<4);		//mask stop_det interrupt

	generate_txempty_interrupt(base);

	while(time_out--){
		if (intr_det == 1)
			break;
	}
	if (intr_det == 0)
		return -1;
	return 0;
}
/*
 * @Description Generate txover interrupt for I2C0 and I2C1
 */
void generate_txover_interrupt(u32_s base){
	u32_s ic_data_cmd;
	int i;
	ic_data_cmd = base + I2C_DATA_CMD_ADDR;
	for(i=0;i<=100;i++)
		i2c_write32(ic_data_cmd, 0x00);  //start addr
}
int txover_interrupt_test(port){
	u32_s base,time_out=1000;
	intr_det = 0;
	printf("%s\n",__FUNCTION__);

	if (port == MAMBA_I2C0){
		base	= I2C0_BASE;
		register_irq_handler(100, i2c0_txover_intr);
	}
	else if (port == MAMBA_I2C1){
		base 	= I2C1_BASE;
		register_irq_handler(101, i2c1_txover_intr);
	}
	i2c_write32(base + I2C_INTR_MASK_ADDR , 0x1<<3);		//mask stop_det interrupt

	generate_txover_interrupt(base);

	while(time_out--){
		if (intr_det == 1)
			break;
	}
	if (intr_det == 0)
		return -1;
	return 0;
}
/*
 * @Description Generate txfull interrupt for I2C0 and I2C1
 */
void generate_rxfull_interrupt(u32_s base){
	u32_s ic_data_cmd;
	int i,rc,data[8];
	ic_data_cmd = base + I2C_DATA_CMD_ADDR;

	for (i=0; i<9; i++)
		i2c_write32(ic_data_cmd, 0x100); // read command (data to buffer will be read in the interrupt service func)

}
int rxfull_interrupt_test(port){
	u32_s base,time_out=100000;
	int datadump,i;
	intr_det = 0;
	printf("%s\n",__FUNCTION__);

	if (port == MAMBA_I2C0){
		base	= I2C0_BASE;
		register_irq_handler(100, i2c0_rxfull_intr);
	}
	else if (port == MAMBA_I2C1){
		base 	= I2C1_BASE;
		register_irq_handler(101, i2c1_rxfull_intr);
	}
	for(i=0;i<16;i++){
		datadump = i2c_read32(base + I2C_DATA_CMD_ADDR);
	}

	i2c_write32(base + I2C_RX_TL_ADDR , 8);					//threshold 8

	i2c_write32(base + I2C_INTR_MASK_ADDR , 0x1<<2);		//mask rxfull interrupt

	generate_rxfull_interrupt(base);

	while(time_out--){
		if (intr_det == 1)
			break;
	}
	if (intr_det == 0)
		return -1;
	return 0;
}

/*
 * @Description Generate rxover interrupt for I2C0 and I2C1
 */
void generate_rxover_interrupt(u32_s base){
	u32_s ic_data_cmd;
	int i,rc,data[8],rxflv;
	ic_data_cmd = base + I2C_DATA_CMD_ADDR;
	if (base == I2C0_BASE){
		i2c_write32(ic_data_cmd, 0);
	}
	else{
		i2c_write32(ic_data_cmd, 0);
		i2c_write32(ic_data_cmd, 0);
	}
	for (i=0; i<16; i++){
		i2c_write32(ic_data_cmd, 0x100); // read command (data to buffer will be read in the interrupt service func) fifo deepth = 16
		v_delayms(10000);
	}
	i2c_write32(ic_data_cmd, 0x100); 	// trigger interrupt
}
int rxover_interrupt_test(port){
	u32_s base,time_out=100000;
	int datadump,i;
	intr_det = 0;
	printf("%s\n",__FUNCTION__);

	if (port == MAMBA_I2C0){
		base	= I2C0_BASE;
		register_irq_handler(100, i2c0_rxover_intr);
	}
	else if (port == MAMBA_I2C1){
		base 	= I2C1_BASE;
		register_irq_handler(101, i2c1_rxover_intr);
	}
	for(i=0;i<16;i++){
		datadump = i2c_read32(base + I2C_DATA_CMD_ADDR);
	}

	i2c_write32(base + I2C_RX_TL_ADDR , 8);					//threshold 8

	i2c_write32(base + I2C_INTR_MASK_ADDR , 0x1<<1);		//mask rxover interrupt

	generate_rxover_interrupt(base);

	while(time_out--){
		if (intr_det == 1)
			break;
	}

	if (intr_det == 0)
		return -1;
	return 0;
}
/*
 * @Description Generate rxunder interrupt for I2C0 and I2C1
 */
void generate_rxunder_interrupt(u32_s base){
	u32_s ic_data_cmd;
	int i,rc,data[8],trigger;
	ic_data_cmd = base + I2C_DATA_CMD_ADDR;
	trigger=i2c_read32(ic_data_cmd); 		// trigger interrupt
}
int rxunder_interrupt_test(port){
	u32_s base,time_out=100000;
	int datadump,i,rxflv;
	intr_det = 0;
	printf("%s\n",__FUNCTION__);

	if (port == MAMBA_I2C0){
		base	= I2C0_BASE;
		register_irq_handler(100, i2c0_rxunder_intr);
	}
	else if (port == MAMBA_I2C1){
		base 	= I2C1_BASE;
		register_irq_handler(101, i2c1_rxunder_intr);
	}
	do{
		v_delayms(10000);
		rxflv = i2c_read32(base + I2C_RXFLR_ADDR);
		if (rxflv > 0)
			datadump = i2c_read32(base + I2C_DATA_CMD_ADDR);
	}while(rxflv>0);

	i2c_write32(base + I2C_INTR_MASK_ADDR , 0x1<<0);

	generate_rxunder_interrupt(base);

	while(time_out--){
		if (intr_det == 1)
			break;
	}

	if (intr_det == 0)
		return -1;
	return 0;
}
void i2c0_intr(void){
	int irq;
	irq = i2c_read32(I2C0_BASE + I2C_INTR_STAT_ADDR);
	if (irq & (0x1<<2))
		irq = 2;
	else
		irq = 1;
	switch (irq){
		case 1:
			i2c0_rdreq_intr();
			break;
		case 2:
			i2c0_slaveReceive();
			break;
	}

}

void I2C0_interrupt_config(void){
	u32_s base	= I2C0_BASE;
	int data = 0xa5;
	int time_out = 10000,i,nob=10;
	intr_det=0;

	register_irq_handler(100, i2c0_intr);
	i2c_write32(base + I2C_RX_TL_ADDR , 4);					//threshold 1

	i2c_write32(base + I2C_INTR_MASK_ADDR , (0x1<<2)|(1<<5));		//mask interrupt
	return 0;
}
int I2C0_RDREQ_RXDONE_interrupt_config(void){
	u32_s base	= I2C0_BASE;
	int data = 0xa5;
	int time_out = 10000,i,nob=10;
	intr_det=0;

	register_irq_handler(100, i2c0_rdreq_rxdone_intr);

	i2c_write32(base + I2C_INTR_MASK_ADDR , 0x1<<5);

	return 0;
}
int I2C0_RDREQ_interrupt_config(void){
	u32_s base	= I2C0_BASE;
	int data = 0xa5;
	int time_out = 10000,i,nob=10;
	intr_det=0;

	register_irq_handler(100, i2c0_rdreq_intr);

	i2c_write32(base + I2C_INTR_MASK_ADDR , 0x1<<5);

	return 0;
}
int I2C0_RDREQ_TXABRT_SLVRD_INTX_interrupt_config(void){
	u32_s base	= I2C0_BASE;
	intr_det=0;

	register_irq_handler(100, i2c0_rdreq_slvrd_intx_txabrt_intr);

	i2c_write32(base + I2C_INTR_MASK_ADDR , 0x1<<5);

	return 0;
}
int I2C0_RDREQ_TXABRT_SLVFLUSH_interrupt_config(void){
	u32_s base	= I2C0_BASE;
	int data = 0xa5;
	int time_out = 10000,i,nob=10;
	intr_det=0;

	register_irq_handler(100, i2c0_rdreq_txabrt_slvflush_intr);

	i2c_write32(base + I2C_INTR_MASK_ADDR , 0x1<<5);

	return 0;
}

int I2C0_RXDONE_interrupt_config(void){
	u32_s base	= I2C0_BASE;
	int data = 0xa5;
	int time_out = 10000,i,nob=10;

	intr_det = 0;
	register_irq_handler(100, i2c0_rxdone_intr);
	i2c_write32(base + I2C_INTR_MASK_ADDR , 0x1<<7);

	for(i=0;i<10;i++){
		i2c_write32(base + I2C_DATA_CMD_ADDR, data++);
	}

	return 0;
}


/*
int I2C0_TXABRT_interrupt_config(void){
	u32_s base	= I2C0_BASE;
	int data = 0xa5;
	int time_out = 10000,i,nob=10;
	intr_det=0;
	register_irq_handler(100, i2c0_rdreq_intr);

	i2c_write32(base + I2C_INTR_MASK_ADDR , 0x1<<5 | 0x1<<6);

	printf("Using Aardvark to generate RD_REQ read 5bytes.....\n");

	while(time_out --){
		for (i=0;i<10000;i++);
		if (intr_det==1)
			break;
	}
	if (intr_det == 0){
		printf("TIME OUT FOR THE INTERRUPT RD_REQ...\n");
		return -1;
	}
	register_irq_handler(100, i2c0_txabrt_intr);

	for(i=0;i<10;i++){
		i2c_write32(base + I2C_DATA_CMD_ADDR, data++);
	}
	return 0;
}
*/

int I2C0_GenCall_interrupt_config(void){
	u32_s base	= I2C0_BASE;
	int data = 0xa5;
	int time_out = 10000,i,nob=10;
	intr_det=0;
	register_irq_handler(100, i2c0_gencall_intr);

	i2c_write32(base + I2C_INTR_MASK_ADDR , 0x1<<11);

	return 0;
}

int i2c0_slave_receive_test(void){
	u32_s base	= I2C0_BASE;
	intr_det=0;

	i2c_write32(base + I2C_RX_TL_ADDR , 15);					//threshold 1
	i2c_write32(base + I2C_INTR_MASK_ADDR , 0x1<<2);		//mask rxfull interrupt
	register_irq_handler(100, i2c0_slaveReceive);

	return 0;
}










