unsigned int str2val_i2c1(char* s)
{
        int i = 0;
        int j = 0;
        u32_s val;
        while(s[i] != '\0')
                i++;
                i++;
                val = 0;
        for( j = 0; j< i; j++)
        {
                switch(s[j])
                {
                        case '0': val = 10* val + 0; break;
                        case '1': val = 10* val + 1; break;
                        case '2': val = 10* val + 2; break;
                        case '3': val = 10* val + 3; break;
                        case '4': val = 10* val + 4; break;
                        case '5': val = 10* val + 5; break;
                        case '6': val = 10* val + 6; break;
                        case '7': val = 10* val + 7; break;
                        case '8': val = 10* val + 8; break;
                        case '9': val = 10* val + 9; break;
                        default: break;
                }
        }

        return val;
}


int get_freq_i2c1(u32_s *pApbFreq, u32_s *pSlimProFreq, void * pReserved)
{
	int rc = 0;
   	uint32_t_s scu_pinstrap;
   	uint32_t_s io_clkcfg;
	    	*pSlimProFreq = 125*1000;
		   	*pApbFreq = 50*1000;

/*
	scu_pinstrap = my_in_be32(REG_SCU_PINSTRAP);
   	io_clkcfg = ((scu_pinstrap & IO_CLKCFG_MASK)>>24);
*/
	io_clkcfg = 1;

   	switch (io_clkcfg) {
		case 0:
	    	*pSlimProFreq = 125*1000;
		   	*pApbFreq = 50*1000;
   	    	break;
   	   case 1:
		    *pSlimProFreq = 250*1000;
		   	*pApbFreq = 100*1000;
   		    break;
   	   case 2:
		    *pSlimProFreq = 214*1000;
		   	*pApbFreq = 100*1000;
   		    break;
		default:
	    	*pSlimProFreq = 125*1000;
		   	*pApbFreq = 50*1000;
   			return -1;
   	}
	return rc;
}
void enable_i2c1_i2c1(void){
	printf("SCU_CLKCFGSEL :%x\n",i2c_read32(SCU_CLKCFGSEL));
	i2c_write32(SCU_CLKCFGSEL, 0x1);
	printf("SCU_CLKCFGSEL :%x\n",i2c_read32(SCU_CLKCFGSEL));
}
/*
*************************************************************************
* I2C Config
**************************************************************************
*/
int config_i2c_i2c1(int port, uint32_t_s speed, uint32_t_s taraddr, uint32_t_s addressing)
{
//while(1);
	int rc = 0;
		uint32_t_s ic_enable;
		uint32_t_s ic_intr_mask;
		uint32_t_s ic_ss_scl_hcnt;
		uint32_t_s ic_ss_scl_lcnt;
		uint32_t_s ic_fs_scl_hcnt;
		uint32_t_s ic_fs_scl_lcnt;
		uint32_t_s ic_hs_scl_hcnt;
		uint32_t_s ic_hs_scl_lcnt;
		uint32_t_s ic_con;
		uint32_t_s ic_tar;
		uint32_t_s ic_sar;
		uint32_t_s tmp;
		uint32_t_s soc_apb_clk;
		uint32_t_s slimpro_apb_clk;
		uint32_t_s apb_clk;
		uint32_t_s ss_hcnt;
		uint32_t_s ss_lcnt;
		uint32_t_s fs_hcnt;
		uint32_t_s fs_lcnt;
		uint32_t_s base;
		uint32_t_s ic_sda_hold;
		//#S# DEBUGMSG_I2C(ZONE_I2C_TRACE, "entering %s\n",__FUNCTION__);
		//#SS# CHK_PORT(I2C, port, rc);

		if (port == MAMBA_I2C0){
			base 		   = I2C0_BASE;
		}
		else if (port == MAMBA_I2C1){
			base 		   = I2C1_BASE;
		}
		ic_enable		= base + I2C_ENABLE_ADDR;
		ic_intr_mask	= base + I2C_INTR_MASK_ADDR;
		ic_ss_scl_hcnt	= base + I2C_SS_SCL_HCNT_ADDR;
		ic_ss_scl_lcnt	= base + I2C_SS_SCL_LCNT_ADDR;
		ic_fs_scl_hcnt	= base + I2C_FS_SCL_HCNT_ADDR;
		ic_fs_scl_lcnt	= base + I2C_FS_SCL_LCNT_ADDR;
		ic_con			= base + I2C_CON_ADDR;
		ic_tar			= base + I2C_TAR_ADDR;
		ic_sar			= base + I2C_SAR_ADDR;
		ic_sda_hold		= base + I2C_SDA_HOLD_ADDR;

		i2c_write32(ic_enable, 0x00); 	// disable i2c
		i2c_write32(ic_intr_mask, 0x00); 	// disable all interrupts

		i2c_write32(ic_ss_scl_hcnt, 0x430);
		i2c_write32(ic_ss_scl_lcnt, 0x4e1);

		if (speed == I2C_FAST_PLUS){
			i2c_write32(ic_fs_scl_hcnt, 0x50);
			i2c_write32(ic_fs_scl_lcnt, 0x80);

		}else{
/*for 1Mhz*/
			i2c_write32(ic_fs_scl_hcnt, 0x100);
			i2c_write32(ic_fs_scl_lcnt, 0x148);
		}

		if (speed == I2C_STANDARD_SPEED){
			if(addressing == ADDRESSING_7BIT)
				i2c_write32(ic_con, 0x43);
			else
				i2c_write32(ic_con, 0x53);
		}
		else if ((speed == I2C_FAST_SPEED)| (speed = I2C_FAST_PLUS)){
			if(addressing == ADDRESSING_7BIT)
				i2c_write32(ic_con, 0x45);
			else
				i2c_write32(ic_con, 0x55);
		}

		i2c_write32(ic_tar, taraddr);
		i2c_write32(ic_sar, 0x55);
		i2c_write32(ic_sda_hold, 1);
		i2c_write32(ic_enable, 0x1);  	// enable i2c
		//#S# DEBUGMSG_I2C(ZONE_I2C_TRACE, "Leaving %s\n",__FUNCTION__);
		return rc;
}
int config_i2c_masterdis_i2c1(int port, uint32_t_s speed, uint32_t_s taraddr, uint32_t_s addressing)
{
//while(1);
	int rc = 0;
		uint32_t_s ic_enable;
		uint32_t_s ic_intr_mask;
		uint32_t_s ic_ss_scl_hcnt;
		uint32_t_s ic_ss_scl_lcnt;
		uint32_t_s ic_fs_scl_hcnt;
		uint32_t_s ic_fs_scl_lcnt;
		uint32_t_s ic_hs_scl_hcnt;
		uint32_t_s ic_hs_scl_lcnt;
		uint32_t_s ic_con;
		uint32_t_s ic_tar;
		uint32_t_s ic_sar;
		uint32_t_s tmp;
		uint32_t_s soc_apb_clk;
		uint32_t_s slimpro_apb_clk;
		uint32_t_s apb_clk;
		uint32_t_s ss_hcnt;
		uint32_t_s ss_lcnt;
		uint32_t_s fs_hcnt;
		uint32_t_s fs_lcnt;
		uint32_t_s base;
		uint32_t_s ic_sda_hold;
		//#S# DEBUGMSG_I2C(ZONE_I2C_TRACE, "entering %s\n",__FUNCTION__);
		//#SS# CHK_PORT(I2C, port, rc);

		if (port == MAMBA_I2C0){
			base 		   = I2C0_BASE;
		}
		else if (port == MAMBA_I2C1){
			base 		   = I2C1_BASE;
		}
		ic_enable		= base + I2C_ENABLE_ADDR;
		ic_intr_mask	= base + I2C_INTR_MASK_ADDR;
		ic_ss_scl_hcnt	= base + I2C_SS_SCL_HCNT_ADDR;
		ic_ss_scl_lcnt	= base + I2C_SS_SCL_LCNT_ADDR;
		ic_fs_scl_hcnt	= base + I2C_FS_SCL_HCNT_ADDR;
		ic_fs_scl_lcnt	= base + I2C_FS_SCL_LCNT_ADDR;
		ic_con			= base + I2C_CON_ADDR;
		ic_tar			= base + I2C_TAR_ADDR;
		ic_sar			= base + I2C_SAR_ADDR;
		ic_sda_hold		= base + I2C_SDA_HOLD_ADDR;

		i2c_write32(ic_enable, 0x00); 	// disable i2c
		i2c_write32(ic_intr_mask, 0x00); 	// disable all interrupts

		i2c_write32(ic_ss_scl_hcnt, 0x430);
		i2c_write32(ic_ss_scl_lcnt, 0x4e1);

		if (speed == I2C_FAST_PLUS){
			i2c_write32(ic_fs_scl_hcnt, 0x50);
			i2c_write32(ic_fs_scl_lcnt, 0x80);

		}else{
/*for 1Mhz*/
			i2c_write32(ic_fs_scl_hcnt, 0x100);
			i2c_write32(ic_fs_scl_lcnt, 0x148);
		}

		if (speed == I2C_STANDARD_SPEED){
			if(addressing == ADDRESSING_7BIT)
				i2c_write32(ic_con, 0x42);
			else
				i2c_write32(ic_con, 0x52);
		}
		else if ((speed == I2C_FAST_SPEED)| (speed = I2C_FAST_PLUS)){
			if(addressing == ADDRESSING_7BIT)
				i2c_write32(ic_con, 0x44);
			else
				i2c_write32(ic_con, 0x54);
		}

		i2c_write32(ic_tar, taraddr);
		i2c_write32(ic_sar, 0x55);
		i2c_write32(ic_sda_hold, 1);
		i2c_write32(ic_enable, 0x1);  	// enable i2c
		//#S# DEBUGMSG_I2C(ZONE_I2C_TRACE, "Leaving %s\n",__FUNCTION__);
		return rc;
}

/*
*************************************************************************
* I2C0 Slave Mode Config
**************************************************************************
*/
int i2c0_slave_cfg_i2c1(uint32_t_s speed, uint32_t_s slave_addr, uint32_t_s addressing)
{
	int rc = 0;
		uint32_t_s ic_enable;
		uint32_t_s ic_intr_mask;
		uint32_t_s ic_ss_scl_hcnt;
		uint32_t_s ic_ss_scl_lcnt;
		uint32_t_s ic_fs_scl_hcnt;
		uint32_t_s ic_fs_scl_lcnt;
		uint32_t_s ic_hs_scl_hcnt;
		uint32_t_s ic_hs_scl_lcnt;

		uint32_t_s ic_con;
		uint32_t_s ic_tar;
		uint32_t_s ic_sar;
		uint32_t_s tmp;
		uint32_t_s soc_apb_clk;
		uint32_t_s slimpro_apb_clk;
		uint32_t_s apb_clk;
		uint32_t_s ss_hcnt;
		uint32_t_s ss_lcnt;
		uint32_t_s fs_hcnt;
		uint32_t_s fs_lcnt;
		uint32_t_s base;

		//#S# DEBUGMSG_I2C(ZONE_I2C_TRACE, "entering %s\n",__FUNCTION__);
		//#SS# CHK_PORT(I2C, port, rc);

		base 		   = I2C0_BASE;

		ic_enable		= base + I2C_ENABLE_ADDR;
		ic_intr_mask	= base + I2C_INTR_MASK_ADDR;
		ic_ss_scl_hcnt	= base + I2C_SS_SCL_HCNT_ADDR;
		ic_ss_scl_lcnt	= base + I2C_SS_SCL_LCNT_ADDR;
		ic_fs_scl_hcnt	= base + I2C_FS_SCL_HCNT_ADDR;
		ic_fs_scl_lcnt	= base + I2C_FS_SCL_LCNT_ADDR;
		ic_hs_scl_hcnt  = base + I2C_HS_SCL_HCNT_ADDR;
		ic_hs_scl_lcnt  = base + I2C_HS_SCL_LCNT_ADDR;

		ic_con			= base + I2C_CON_ADDR;
		ic_tar			= base + I2C_TAR_ADDR;
		ic_sar			= base + I2C_SAR_ADDR;

		i2c_write32(ic_enable, 0x00); 	// disable i2c
		i2c_write32(ic_intr_mask, 0x00); 	// disable all interrupts

		i2c_write32(ic_ss_scl_hcnt, 0x430);
		i2c_write32(ic_ss_scl_lcnt, 0x4e1);

		i2c_write32(ic_fs_scl_hcnt, 0x100);
		i2c_write32(ic_fs_scl_lcnt, 0x148);

		if (speed == I2C_STANDARD_SPEED){
			if(addressing == ADDRESSING_7BIT)
				i2c_write32(ic_con, 0x02);
			else
				i2c_write32(ic_con, 0x0a);
		}
		else if (speed == I2C_FAST_SPEED){
			if(addressing == ADDRESSING_7BIT)
				i2c_write32(ic_con, 0x04);
			else
				i2c_write32(ic_con, 0x0c);
		}

		i2c_write32(ic_tar, 0x56);				//by default
		i2c_write32(ic_sar, slave_addr);
		i2c_write32(ic_enable, 0x1);  			// enable i2c
		//#S# DEBUGMSG_I2C(ZONE_I2C_TRACE, "Leaving %s\n",__FUNCTION__);
		return rc;
}

/*
*************************************************************************
* I2C Check status txfifo empty
**************************************************************************
*/
int i2c_check_status_txfifo_empty_i2c1(int port)
{
	int rc = 0;
	u32_s i2c_status;
	u32_s base;
	u32_s timeout = I2C_TIMEOUT;

	if (port == MAMBA_I2C0){
		base = I2C0_BASE;
	}
	else if (port == MAMBA_I2C1){
		base = I2C1_BASE;
	}
    do{
    	i2c_status = i2c_read32(base + I2C_STATUS_ADDR);
    	timeout--;
    	if (timeout == 0)
    		return 1;
    } while(((i2c_status & 0x4)>>2)!=1);

	return rc;
}
/*
*************************************************************************
* I2C Check status rxfifo not full
**************************************************************************
*/
int i2c_check_status_rxfifo_notfull_i2c1(int port)
{
	int rc = 0;
	u32_s i2c_status;
	u32_s timeout = I2C_TIMEOUT;
	u32_s base;

	if (port == MAMBA_I2C0){
		base = I2C0_BASE;
	}
	else if (port == MAMBA_I2C1){
		base = I2C1_BASE;
	}
    do {
    	i2c_status = i2c_read32(base + I2C_STATUS_ADDR);
    	timeout--;
    	if (timeout ==0)
    		return 1;
    }while(((i2c_status & 0x8)>>3)!=1);

    return rc;
}
/*
 *
 */
int i2c_check_activity_status_i2c1(int port){
	int rc = 0;
	u32_s i2c_status;
	u32_s timeout = I2C_TIMEOUT;
	u32_s base;
	if (port == MAMBA_I2C0){
		base = I2C0_BASE;
	}
	else if (port == MAMBA_I2C1){
		base = I2C1_BASE;
	}
    do {
    	i2c_status = i2c_read32(base + I2C_STATUS_ADDR);
    	timeout--;
    	if (timeout ==0){
    		printf("check activity error\n");
    		return 1;
    	}
    }while(((i2c_status & 0x20)>>5)==1);
    return 0;
}
/*
*************************************************************************
* I2C WRITE
**************************************************************************
*/
int i2c_write_h_i2c1(int port, u32_s start_addr, u32_s no_of_bytes, u32_s* pdata)
{
	int rc = 0;
	int i;
	u32_s ic_data_cmd;
	u8 addr_hi;
	u8 addr_lo;
	u32_s base;
	addr_hi = (start_addr & 0xFF00) >> 8;
	addr_lo = start_addr & 0xFF;
	if (port == MAMBA_I2C0){
		base = I2C0_BASE;
	}
	else if (port == MAMBA_I2C1){
		base = I2C1_BASE;
	}
	ic_data_cmd = base + I2C_DATA_CMD_ADDR;
	if (port == MAMBA_I2C0){
		i2c_write32(ic_data_cmd, (u8)start_addr);
	}
	else{
		i2c_write32(ic_data_cmd, addr_hi);
		i2c_write32(ic_data_cmd, addr_lo);
	}
	//this is data
	for(i=0;i<no_of_bytes;i++){
		i2c_write32(ic_data_cmd,pdata[i] );

	}

	rc = i2c_check_status_txfifo_empty_i2c1(port);
	if (rc !=0)
			return rc;
	rc = i2c_check_activity_status_i2c1(port);

	return rc;
}
int i2c_write_to_aardvark_i2c1(int port)
{
	int rc = 0;
	int i;
	u32_s ic_data_cmd;
	u8 addr_hi;
	u8 addr_lo;
	u32_s base;
	int data = 0x5A;
	if (port == MAMBA_I2C0){
		base = I2C0_BASE;
	}
	else if (port == MAMBA_I2C1){
		base = I2C1_BASE;
	}
	ic_data_cmd = base + I2C_DATA_CMD_ADDR;
	//this is data
	for(i=0;i<4;i++){
		//printf("data:%x\n",data);
		i2c_write32(ic_data_cmd,data++ );
	}
	rc = i2c_check_status_txfifo_empty_i2c1(port);

// This is just temp delay because we dont have any delay func for the test at the moment
	mdelay(200);
	return rc;
}
/*
*************************************************************************
* I2C READ
**************************************************************************
*/int i2c_read_h_i2c1(int port, u32_s start_addr, u32_s no_of_bytes, u32_s *pdata)
{
	int rc = 0;
	int rd_data = 0;
	int i;
	u32_s ic_data_cmd;
	u32_s base;
	u8 addr_hi;
	u8 addr_lo;
	addr_hi = (start_addr & 0xFF00) >> 8;
	addr_lo = start_addr & 0xFF;
	if (port == MAMBA_I2C0){
		base = I2C0_BASE;
	}
	else if (port == MAMBA_I2C1){
		base = I2C1_BASE;
	}
	ic_data_cmd = base + I2C_DATA_CMD_ADDR;
	if (port == MAMBA_I2C0){
		i2c_write32(ic_data_cmd, (u8)start_addr);
	}
	else{
		i2c_write32(ic_data_cmd, addr_hi);
		i2c_write32(ic_data_cmd, addr_lo);
	}

	for (i=0; i<no_of_bytes; i++)
		i2c_write32(ic_data_cmd, 0x100); // read command

	rc = i2c_check_activity_status_i2c1(port);
	if (rc !=0)
		return rc;
	for(i=0;i<no_of_bytes;i++){
		rc = i2c_check_status_rxfifo_notfull_i2c1(port);
		if (rc != 0){
			return rc;
		}
		rd_data = i2c_read32(ic_data_cmd);
		pdata[i]=rd_data;
	}
	return rc;
}

/*
*************************************************************************
* I2C APPLICATION FUNCS
**************************************************************************
*/
int i2c_rw_test_i2c1(int port,u32_s rw_addr, u32_s no_of_bytes, u32_s *pTxdata, u32_s *pRxdata)
{
	int rc = 0;
	int i,j;
	static u32_s data_modifier=0;
	u8 offset=2;
	rc = i2c_check_activity_status_i2c1(port);
	if (rc !=0)
		return rc;

	rc = i2c_write_h_i2c1(port, rw_addr, no_of_bytes, pTxdata);
	if (rc !=0)
		return rc;

	mdelay(100);

	rc = i2c_read_h_i2c1(port, rw_addr, no_of_bytes, pRxdata);
	if (rc !=0)
		return rc;

	return 0;
}
