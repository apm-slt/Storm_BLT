//////////////////////////////////////////////////////////////////////////////////////////
//file name:    eth_common.h
//create date:  25-Jun-2014
//description:  basic xgenet define.
///////////////////////////////////////////////////////////////////////////////////////////

#ifndef __ETH_COMMON_H_
#define __ETH_COMMON_H_

#include <types.h>

#define uint32_t unsigned int

#define RANDOMIZE_SLT    

#define UART_BAUD 9600
#define ARGV_SIZE 10
#define MAX_INDCMD_DONE_COUNTER 100
#define SLT_MSG_NUM 4
#define SLT_FP_SIZE  2048

/*
#define  READ8(add)         (*(volatile unsigned char *)(add))
#define  READ16(add)         (*(volatile unsigned short *)(add))
#define  READ32(add)        (*(volatile unsigned *)(add))
#define  WRITE8(add, data)     *(unsigned char *)(add) = (unsigned char)(data)
#define  WRITE16(add, data)    *(unsigned short *)(add) = (unsigned short  )(data)
#define  WRITE32(add, data)    *(unsigned *)(add) = (unsigned )(data)
*/

char  read8(char *address);
void  write8(char *address,char data);

short read16(short *address);
void  write16(short *address, short data);

extern u64 read_64(u64 *address);
extern u32 read_word(u64 *address);

extern int   read32(unsigned int *address);
extern void  write32(unsigned int *address, int data);
extern int   read(unsigned int *address);
extern void  write(unsigned int *address, int data);

void qm_reg_wr(int address, int data);
int  qm_reg_rd(int address);

extern void error(int exit);
extern void end_test();
extern int  get_val();
extern void get_file(int *start_address, int size_in_bytes);
extern void ddr_init();
//void set_hinfo();

// ----------------------------------
// Ethernet CSR Read-Write Functions
// ----------------------------------
enum {PORT0, PORT1, PORT2, PORT3} PORT;
enum {MENET, ENET,  XGENET } ETH_TYPE;

static int display_all = 0;
static int display_serdes = 0;

// Initial Values Defined in *_serdes.c
extern int pll_manualcal; // 0 = Autocalibration, 1 = Manual Calibration
extern int man_pvt_cal;   // Only for XGENET, unused in SATA_ENET
                          // 0 = From SM, 1 = Manual Calibration
//extern int vco_momsel_init; // 0 = Autocalibration, 1 = Manual Calibration
extern int vco_momsel_init_xfi; // 0 = Autocalibration, 1 = Manual Calibration
                            
// -- Direct Address
extern int eth_rd(int offset, int eth_type, int port, int display);


struct cmd {
   char *str;
   int (*cmd_func)(int , char*[]);
   char *help_msg;
};

//void putnum(int num);
int putnum(int num);

//global val
#define ENET_01_BASE_ADDR  0x1f210000
#define ENET_23_BASE_ADDR  0x1f220000
#define XGENET_0_BASE_ADDR 0x1f610000
#define XGENET_1_BASE_ADDR 0x1f620000
#define XGENET_2_BASE_ADDR 0x1f710000
#define XGENET_3_BASE_ADDR 0x1f720000
#define MENET_BASE_ADDR    0x17020000 //md: 

#define FIRST_PORT 0
#define LAST_PORT  3

//from xgenet 
//#define CONFIG_XGENET_IF_XGMII //else SGMII //md:	// DEFINED in 'Makefile'
//#define CONFIG_XGENET_XGBASER_TX2RX_LPBK //after PCS and before serdes
//#define  CONFIG_XGENET_XGBASER_RX2TX_LPBK //after PCS and before Rx MAC

//#define CONFIG_XGENET_RX2TSO_TX_LPBK 
//#define CONFIG_XGENET_QM_RX2TX_LPBK

//#define CONFIG_RX2TSO_TX_LPBK       // FIFO level loopback test //md: 
//#define CONFIG_QM_RX2TX_LPBK      // QM level loopback test
//#define CONFIG_CPU_RX2TX_LPBK     // CPU level loopback test
//#define CONFIG_SNAKE_RX2TX_LPBK   // SNAKE test 


//#define XFI_SGMII_PORTS         // All 4 1 gig XFI_SGMII Ports  
//#define SATA_SGMII_PORTS        // All 4 1 gig SATA_SGMII Ports 
#define XFI_XGMII_PORTS         // All 4 10 gig XFI ports

//#define XGENET_CLE_ENABLE

//#define CONFIG_SDS_SERDES_RX_CLK_INV //rx_clk_inv in serdes
#define CMU   0x0000

//from qm
#define QM_XGESOC_BASE_ADDR 0x1f200000
#define QM_XGE01_BASE_ADDR 0x1f600000
#define QM_XGE23_BASE_ADDR 0x1f700000

// Comment out for normal operation without pauseframes
//#define SW_HACK_FOR_CRC 

// Comment out below define to go back to Autoneg mode after sending pause frames.
#define SW_HACK_STAY_LOOPBACK

#define QM_TEST_MSG_NUM 1 //48
#define PKT_SIZE 128 //256 //128 //64 
#define PKT_NUM 1 //4 //20 //200
extern u64 buf[]; 
extern u64 buf_xfi[]; 
extern u64 buf1[]; 

extern void qmi_config(void);
extern void bypass_cle_config(void);


extern void qm_n_function_xfi_dummy_1();
extern void external_tx2rx_p2p_loopback_test_4_ports();
extern int eth_tx2rx_p2p_lpbk_test_xfi_1g();
extern int eth_tx2rx_lpbk_test_xfi_1g();
extern int eth_tx2rx_lpbk_xfi_10g_p2p();
extern void no_test_dueto_link_error();
extern void sfp_plus_laser_off();
extern int  external_tx2rx_p2p_new_loopback_test_4_ports();
extern void pll_status_xg();
extern void rst_sds_rxa_xg();
extern void rst_sds_rxda_xg();
extern void rst_sds_xg();
extern void gen_avg_val_xfi();
extern void reset_pcs();
extern void sweep_port_xfi();
extern void read_ber_port();
extern void printf_test_suite_header();
extern void init_and_configure_xfi_ports();
extern void sfp_laser_enable_top_level_function();
extern void external_tx2rx_loopback_test_4_ports();
extern void stat_dump_per_port();
extern void cle_bypass_function_xfi();
extern void qmi_config_local_xfi();
extern int  pkt_compare_xfi_p2p();
extern void sata_enet_bist_port();
extern void kc_macro_pdown_force_vco();
extern void xgenet_sds_CMU_cfg();
extern void xgenet_sds_rxtx_cfg();
extern void total_err_count_result_xfi();
extern void send_pause_frame_xg();
extern void fix_crc_xg();
extern void cleanup_crc_xg();
extern void mac_stat_xg();
extern int  pkt_compare_xfi_new();
extern int  pkt_compare_xfi();




#endif // __ETH_COMMON_H_

