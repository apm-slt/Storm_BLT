#ifndef __ETH_CLE_DRV_H_
#define __ETH_CLE_DRV_H_

#define INDCMD_WR      0x1
#define INDCMD_RD      0x2
#define INDCMD_AVL_ADD 0x8
#define INDCMD_AVL_DEL 0x10

struct cle_pt_dn {
  // Word 0
  unsigned int NodeType:2;
  unsigned int LastNode:1;
  unsigned int HdrLStr:1;
  unsigned int HdrExt:2;
  unsigned int ByteStr:2;
  unsigned int SrchBStr:2;
  unsigned int rsvd0:2;
  unsigned int def_ptr:12;
  unsigned int rsvd1:8;

  struct cle_pt_branch {
    // Word 1
    unsigned int br_vld:1;
    unsigned int next_2B_data_ptr:9;
    unsigned int jmp_bw:1;
    unsigned int jmp_rel:1;
    unsigned int operation:3;
    unsigned int next_node_ptr:9;
    unsigned int next_brky_ptr:5;
    unsigned int rsvd0:3;

    // Word 2
    unsigned int cmp_data:16;
    unsigned int mask:16;
  } branch[8];
};

struct cle_pt_kn {
  // Word 0
  unsigned int NodeType:2;
  unsigned int rsvd0:30;

  // Word 1-16 as 32 Half-Words
  struct cle_pt_key {
    // Half-Word
    unsigned short int priority:3;
    unsigned short int dbptr:10;
    unsigned short int rsvd0:3;
  } key[32];
};

struct cle_avl_node {
  // Word 0-7
  unsigned int srch_str[8];

  // Word 8
  unsigned int dbptr:10;
  unsigned int rsvd0:22;

  // Word 9
  unsigned int priority:3;
  unsigned int rsvd1:29;

  // Word 10
  unsigned int valid:1;
  unsigned int balance:3;
  unsigned int right_ptr:11;
  unsigned int left_ptr:11;
  unsigned int rsvd2:6;
};

struct cle_dbram {
  // Word 0
  unsigned int split_boundary:8;
  unsigned int mirror_nxtfpsel:4;
  unsigned int mirror_fpsel:4;
  unsigned int mirror_dstqid:12;
  unsigned int drop:1;
  unsigned int mirror:1;
  unsigned int hdr_data_split:1;
  unsigned int hopinfomsbs0:1;

  // Word 1
  unsigned int hopinfomsbs1:32;

  // Word 2
  unsigned int hopinfomsbs2:15;
  unsigned int dr:1;
  unsigned int hr:1;
  unsigned int hopinfolsbs0:15;

  // Word 3
  unsigned int hopinfolsbs1:32;

  // Word 4
  unsigned int hopinfolsbs2:1;
  unsigned int henqnum:12;
  unsigned int hfpsel:4;
  unsigned int nxtfpsel:4;
  unsigned int fpsel:4;
  unsigned int dstqid0:7;

  // Word 5
  unsigned int dstqid1:5;
  unsigned int priority:3;
  unsigned int flowgroup:4;
  unsigned int perflow:6;
  unsigned int insert_timestamp:1;
  unsigned int stash:2;
  unsigned int in:1;
  unsigned int PerPrioEn:1;
  unsigned int PerFlowGroupEn:1;
  unsigned int PerFlowEn:1;
  unsigned int SelHash:1;
  unsigned int SelHdrExt:1;
  unsigned int rsvd0:5;
};

//// CLE-3InLine
//struct cle_ptram {
//  // Decision Nodes
//  struct cle_pt_dn dnode[480];
//
//  // Key Nodes
//  struct cle_pt_kn knode[32];
//};

//// CLE-2InLine, CLE-LA
//struct cle_ptram {
//  // Decision Nodes
//  struct cle_pt_dn dnode[96];
//
//  // Key Nodes
//  struct cle_pt_kn knode[32];
//};

//// CLE-Lite
//struct cle_ptram {
//  // Decision Nodes
//  struct cle_pt_dn dnode[127];
//
//  // Key Nodes
//  struct cle_pt_kn knode;
//};

#endif // __ETH_CLE_DRV_H_
