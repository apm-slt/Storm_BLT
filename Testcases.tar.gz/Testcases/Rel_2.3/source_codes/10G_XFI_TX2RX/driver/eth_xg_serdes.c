//////////////////////////////////////////////////////////////////////////////////////////
// *********************************************************************************
//file name:    xgenet_serdes.c
//create date:  1/6/2013
//author:       jufang zhang
//description:  indirectory routine to access serdes.
//              configure xgenet serdes in storm
//              This is for XFI-SGMII (1G ONly)
//////////////////////////////////////////////////////////////////////////////////////////
int pll_manualcal = 0;
int man_pvt_cal = 1;
int vco_momsel_init = 0xd; 
//int vco_momsel_init = 0x11; // chidvilas 6/24 for Manual Calibration use 0x11 for momsel md:
#include <stdio.h>
#include "eth_common.h"
#include "eth_xg_csr.h"

extern int xgenet_base_addr;

/////////////////////////////////////////////////////////////////////////////////
// SERDES config
// the xgenet (that include enet module) will have both xfi (10G) and 1G mode running at LSPLL ONLY.
// infmode: 0: SGMII(1G), 1: XGMII(10G)
// NOTE: Storm_CLock_and_Reset_EAS.pdf
// Section 3.2.4 ETH_PLL clocks: ETH_CLK sources the Serdes reference clock for both Ethernet ports.
// Therefore, configurations where one port is SGMII and the other is XFI are not supported.
////////////////////////////////////////////////////////////////////////////////
// function taken from SATA code-Satish 25/02/2013
void  serdes_pdown_force_vco_xg (int port, int display) {
    uint32_t data32;
    int delay;
     printf (" serdes_pdown_force_vco () \n");
     data32 = enet_sds_ind_csr_reg_rd("CMU_reg0", CMU + 2*0,XGENET,port,display);
     /* data32 = FIELD_CMU_REG0_PDOWN_SET(data32, 1); */
     data32 = sm_enet_set(data32, 1, 14, 14);
     enet_sds_ind_csr_reg_wr("CMU_reg0", CMU + 2*0, data32,XGENET,port,display);

     for(delay=0;delay<10000;delay++);
     data32 = enet_sds_ind_csr_reg_rd("CMU_reg0", CMU + 2*0,XGENET,port,display);
     data32 = sm_enet_set(data32, 0, 14, 14);
     enet_sds_ind_csr_reg_wr("CMU_reg0", CMU + 2*0, data32,XGENET,port,display);

     data32 = enet_sds_ind_csr_reg_rd("CMU_reg32", CMU + 2*32,XGENET,port,display);
     /* data32 = FIELD_CMU_REG32_FORCE_VCOCAL_START_SET(data32, 1); */
     data32 = sm_enet_set(data32, 1, 14, 14);
     enet_sds_ind_csr_reg_wr("CMU_reg32", CMU + 2*32, data32,XGENET,port,display);

     for(delay=0;delay<10000;delay++);
     //data32 = enet_sds_ind_csr_reg_rd("CMU_reg32", CMU + 2*32,XGENET,port,display);
     /* data32 = FIELD_CMU_REG32_FORCE_VCOCAL_START_SET(data32, 1); */
     data32 = sm_enet_set(data32, 0, 14, 14);
     enet_sds_ind_csr_reg_wr("CMU_reg32", CMU + 2*32, data32,XGENET,port,display);

}
void serdes_reset_rxd_rxa_xg (int eth_type, int port, int display) {
  unsigned int  wr_val, rd_val;
  int timeout;
  int inst_base;

  inst_base = 0x0400;
  printf (" CH0 RX Reset Digital ...\n\r");
  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2, eth_type, port, display);
  wr_val = sm_enet_set(rd_val, 0, 8, 8); // digital reset == 1'b0
  enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val, eth_type, port, display);

  inst_base = 0x0400;
  printf (" CH0 RX Reset Analog ...\n\r");
  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2, eth_type, port, display);
  wr_val = sm_enet_set(rd_val, 0, 7, 7); // analog reset == 1'b0
  enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val, eth_type, port, display);

  for(timeout=0; timeout<0x8000; ++timeout);

  inst_base = 0x0400;
  printf (" CH0 RX Remove Reset Analog ...\n\r");
  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2, eth_type, port, display);
  wr_val = sm_enet_set(rd_val, 1, 7, 7); // analog reset == 1'b1
  enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val, eth_type, port, display);

  for(timeout=0; timeout<0x16000; ++timeout);

  inst_base = 0x0400;
  printf (" CH0 RX Remove Reset Digital ...\n\r");
  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2, eth_type, port, display);
  wr_val = sm_enet_set(rd_val, 1, 8, 8); // digital reset == 1'b1
  enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val, eth_type, port, display);

}

void serdes_reset_rxa_xg (int eth_type, int port, int display) {
  unsigned int  wr_val, rd_val;
  int timeout;
  int inst_base;

  inst_base = 0x0400;
  printf (" CH0 RX Reset Analog ...\n\r");
  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2, eth_type, port, display);
  wr_val = sm_enet_set(rd_val, 0, 7, 7); // analog reset == 1'b0
  enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val, eth_type, port, display);

  for(timeout=0; timeout<0x8000; ++timeout);

  inst_base = 0x0400;
  printf (" CH0 RX Remove Reset Analog ...\n\r");
  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2, eth_type, port, display);
  wr_val = sm_enet_set(rd_val, 1, 7, 7); // analog reset == 1'b1
  enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val, eth_type, port, display);

}

void force_lat_summer_cal_xg (int eth_type, int port, int display) {

  uint32_t inst, inst_base;
  unsigned int data32 = 0;
    int          timeout = 0;
    int          forcephyrdy = 0;   // REMOVE LATER POLY
    printf ("force_lat_summer_cal() ====>  Put Lane in Tx2Rx loopback and do a force Latch and Summer calib\n\r");
    // ***************************
    // SUMMER CALIBRATION CH0
    // ***************************
    inst = 0;
    inst_base = 0x0400 + inst*0x0200;
    // SUMMer calib toggle
    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2, eth_type, port, display);
    /* data32 = FIELD_CH0_RXTX_REG127_FORCE_SUM_CAL_START_SET(data32,0x1); */
    data32 = sm_enet_set(data32, 1, 1, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, data32, eth_type, port, display);
    for(timeout=0; timeout<0x40000; ++timeout);
    //------------------------------
    // SUMMer calib toggle
    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2, eth_type, port, display);
    data32 = sm_enet_set(data32, 0, 1, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, data32, eth_type, port, display);

    for(timeout=0; timeout<0x40000; ++timeout);
    /* data32 = kc_serdes_rd (KC_SERDES_X2_RXTX_REGS_CH0_RXTX_REG121__ADDR); */
    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg121", inst_base + 121*2, eth_type, port, display);
    printf("********1. DEBUG************\n");
    printf("********1. DEBUG************ ====> CH0_RXTX_REG121 = %x \n", data32);
    printf("********1. DEBUG************\n");

   // latch calib toggle
    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2, eth_type, port, display);
    /* data32 = FIELD_CH0_RXTX_REG127_FORCE_LAT_CAL_START_SET(data32,0x1); */
    data32 = sm_enet_set(data32, 1, 2, 2);
    enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, data32, eth_type, port, display);
    for(timeout=0; timeout<0x40000; ++timeout);

    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2, eth_type, port, display);
    /* data32 = FIELD_CH0_RXTX_REG127_FORCE_LAT_CAL_START_SET(data32,0x1); */
    data32 = sm_enet_set(data32, 0, 2, 2);
    enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, data32, eth_type, port, display);

 // DFE : Check with Poly
 //----------------------------------------
 //  // Anil request 5-2-2012
 //  // CH 0 
 //  kc_serdes_wr( KC_SERDES_X2_RXTX_REGS_CH0_RXTX_REG28__ADDR + 0x0, 0x7);  
 //  kc_serdes_wr( KC_SERDES_X2_RXTX_REGS_CH0_RXTX_REG31__ADDR + 0x0, 0x7e00);  
 //  //**************
 //  // CH0
 //  //**************
 //  //  removing loopback after calibration cycle
 //  // Added 05/06/2013
 //  #ifdef SERDES_PRINT
 //   printf(" sata_sm_sds_validation_rxtx_cfg() ====> CH0_RXTX_REG4[6:6]   (tx_loopback_buf-en) = 0x0\n");
 //  #endif
 //   data32 = kc_serdes_rd( KC_SERDES_X2_RXTX_REGS_CH0_RXTX_REG4__ADDR );
 //   data32 = FIELD_CH0_RXTX_REG4_TX_LOOPBACK_BUF_EN_SET(data32,0x0);
 //   kc_serdes_wr( KC_SERDES_X2_RXTX_REGS_CH0_RXTX_REG4__ADDR , data32);
 //   // Added on 05/06/2013
 //  #ifdef SERDES_PRINT
 //   printf(" sata_sm_sds_validation_rxtx_cfg() ====> CH0_RXTX_REG7[14:14]   (loop_back_ena_ctle) = 0x0 \n");
 //  #endif
 //   data32 = kc_serdes_rd( KC_SERDES_X2_RXTX_REGS_CH0_RXTX_REG7__ADDR );
 //   data32 = FIELD_CH0_RXTX_REG7_LOOP_BACK_ENA_CTLE_SET(data32,0x0);
 //   kc_serdes_wr( KC_SERDES_X2_RXTX_REGS_CH0_RXTX_REG7__ADDR , data32);
 //  //RXTX_REG38
 //   
 // User Pattern : Check with Poly
 //----------------------------------------
 //  if (forcephyrdy) {
 //    printf(" sata_sm_sds_validation_rxtx_cfg() ====> CH0_RXTX_REG38[15:1]   (customer_pinmode_inv) = 0x1 \n");
 //    printf(" sata_sm_sds_validation_rxtx_cfg() ====> CH0_RXTX_REG38[0]      (TX_user_patt_sel) = 0 \n");
 //    kc_serdes_wr( KC_SERDES_X2_RXTX_REGS_CH0_RXTX_REG38__ADDR , 0x2);  
 //  }
 //  else {
 //    printf(" sata_sm_sds_validation_rxtx_cfg() ====> CH0_RXTX_REG38[15:1]   (customer_pinmode_inv) = 0x0 \n");
 //    printf(" sata_sm_sds_validation_rxtx_cfg() ====> CH0_RXTX_REG38[0]      (TX_user_patt_sel) = 0 \n");
 //    kc_serdes_wr( KC_SERDES_X2_RXTX_REGS_CH0_RXTX_REG38__ADDR , 0x0);  
 //  }
 //----------------------------------------
 // kc_serdes_wr( KC_SERDES_X2_RXTX_REGS_CH0_RXTX_REG39__ADDR , 0xff00);  
 // kc_serdes_wr( KC_SERDES_X2_RXTX_REGS_CH0_RXTX_REG40__ADDR , 0xffff);  
 // kc_serdes_wr( KC_SERDES_X2_RXTX_REGS_CH0_RXTX_REG41__ADDR , 0xffff);  
 // kc_serdes_wr( KC_SERDES_X2_RXTX_REGS_CH0_RXTX_REG42__ADDR , 0xffff);  
 // kc_serdes_wr( KC_SERDES_X2_RXTX_REGS_CH0_RXTX_REG43__ADDR , 0xffff);  
 // kc_serdes_wr( KC_SERDES_X2_RXTX_REGS_CH0_RXTX_REG44__ADDR , 0xffff);  
 // kc_serdes_wr( KC_SERDES_X2_RXTX_REGS_CH0_RXTX_REG45__ADDR , 0xffff);  
 // kc_serdes_wr( KC_SERDES_X2_RXTX_REGS_CH0_RXTX_REG46__ADDR , 0xffff);  
 // 
 // kc_serdes_wr( KC_SERDES_X2_RXTX_REGS_CH0_RXTX_REG47__ADDR , 0xfffc);  
 // 
 // kc_serdes_wr( KC_SERDES_X2_RXTX_REGS_CH0_RXTX_REG48__ADDR , 0x0);  
 // kc_serdes_wr( KC_SERDES_X2_RXTX_REGS_CH0_RXTX_REG49__ADDR , 0x0);  
 // kc_serdes_wr( KC_SERDES_X2_RXTX_REGS_CH0_RXTX_REG50__ADDR , 0x0);  
 // kc_serdes_wr( KC_SERDES_X2_RXTX_REGS_CH0_RXTX_REG51__ADDR , 0x0);  
 // kc_serdes_wr( KC_SERDES_X2_RXTX_REGS_CH0_RXTX_REG52__ADDR , 0x0);  
 // kc_serdes_wr( KC_SERDES_X2_RXTX_REGS_CH0_RXTX_REG53__ADDR , 0x0);  
 // kc_serdes_wr( KC_SERDES_X2_RXTX_REGS_CH0_RXTX_REG54__ADDR , 0x0);  
 // kc_serdes_wr( KC_SERDES_X2_RXTX_REGS_CH0_RXTX_REG55__ADDR , 0x0);  

}

void serdes_calib_xg(int eth_type, int port, int display){
  unsigned int data32, timeout, rd_val, wr_val; 
  int inst_base;
  int infmode = 0;
  
  
  // CMU_reg6  : Enable Manual PVT calibration - Anil
  printf("\nPVT Calibration mode set to %s \n", man_pvt_cal ? "MANUAL" : "AUTOMATIC");
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg6", CMU + 2*6,eth_type,port,display);
  wr_val = sm_enet_set(rd_val,infmode ? man_pvt_cal : man_pvt_cal, 2, 2);
  enet_sds_ind_csr_reg_wr("CMU_reg6", CMU + 2*6, wr_val,eth_type,port,display);

  // TERM CALIBRATION KC_SERDES_CMU_REGS_CMU_REG17__ADDR
  data32 = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17, eth_type, port, display);
  data32 &= ~(0x7F << 8);
  data32 |= 0x0D << 8;
  data32 &= ~(3 << 5);
  enet_sds_ind_csr_reg_wr("CMU_reg17", CMU + 2*17, data32, eth_type, port, display);
  data32 = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17, eth_type, port, display);

  data32 = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17, eth_type, port, display);
  data32 |= 1 << 15;
  enet_sds_ind_csr_reg_wr("CMU_reg17", CMU + 2*17, data32, eth_type, port, display);
  data32 = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17, eth_type, port, display);
 
  data32 = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17, eth_type, port, display);
  data32 &= ~(1 << 15);
  enet_sds_ind_csr_reg_wr("CMU_reg17", CMU + 2*17, data32, eth_type, port, display);
  data32 = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17, eth_type, port, display);

  // DOWN CALIBRATION
  data32 = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17, eth_type, port, display);
  data32 &= ~(0x7F << 8);
  data32 |= 0x26 << 8;
  data32 &= ~(3 << 5);
  enet_sds_ind_csr_reg_wr("CMU_reg17", CMU + 2*17, data32, eth_type, port, display);
  data32 = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17, eth_type, port, display);

  data32 = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16, eth_type, port, display);
  data32 |= 1;
  enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, data32, eth_type, port, display);
  data32 = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16, eth_type, port, display);

  data32 = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16, eth_type, port, display);
  data32 &= ~1;
  enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, data32, eth_type, port, display);
  data32 = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16, eth_type, port, display);
 
  // UP CALIBRATION
  data32 = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17, eth_type, port, display);
  data32 &= ~(0x7F << 8);
  data32 |= 0x27 << 8;
  data32 &= ~(3 << 5);
  enet_sds_ind_csr_reg_wr("CMU_reg17", CMU + 2*17, data32, eth_type, port, display);
  data32 = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17, eth_type, port, display);

  data32 = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16, eth_type, port, display);
  data32 |= (1 << 1);
  enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, data32, eth_type, port, display);
  data32 = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16, eth_type, port, display);

  data32 = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16, eth_type, port, display);
  data32 &= ~(1 << 1);
  enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, data32, eth_type, port, display);
  data32 = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16, eth_type, port, display);

  ////////////////////////////////////////////////////////////////////////////////
  // Anil adding 5-2-2013
  //// STARTED/////
  //  printf ("ANIL ADDING THIS CODE .....\n\r");
  inst_base = 0x0400;
  data32 = enet_sds_ind_csr_reg_rd("rxtx_reg14", inst_base + 14*2, eth_type, port, display);
  data32 &= ~0x7F;  // mask
  data32 |= 0x0E; //Anil 02/08/13
  enet_sds_ind_csr_reg_wr("rxtx_reg14",inst_base + 14*2, data32, eth_type, port, display);

//   // force_lat_cal_start CH0
//   inst_base = 0x0400;
//   data32 = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2, eth_type, port, display);
//   data32 &= ~0x4;
//   data32 |= 0x4;
//   enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, data32, eth_type, port, display);
//   data32 &= ~0x4;
//   enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, data32, eth_type, port, display);
//  
  for(timeout=0; timeout<0x8000; ++timeout);	//Anil 020813
}
void sm_xgenet_module_program_all_regs(uint32_t infmode,int eth_type, int port, int display) {
  uint32_t wr_val, rd_val, inst, inst_base;

  xgenet_sds_CMU_cfg(infmode, eth_type, port, display);
  xgenet_sds_rxtx_cfg(infmode, eth_type, port, display);
  return;
}

void xgenet_sds_CMU_cfg(uint32_t infmode,int eth_type, int port, int display) {
  uint32_t wr_val, rd_val, inst, inst_base, internal_ref_clk;

  //////////////////////////
  // LSPLL Controls
  /////////////
  internal_ref_clk = 0;

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg12", CMU + 2*12,eth_type,port,display);
  /* data32 = FIELD_CMU_REG12_STATE_DELAY9_SET(data32, 0x1);  // Anil 0718 */
  wr_val = sm_enet_set(rd_val, 1, 7, 4);
  enet_sds_ind_csr_reg_wr("CMU_reg12", CMU + 2*12, wr_val,eth_type,port,display);
  /////////////
  // CMU_reg13
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg13", CMU + 2*13,eth_type,port,display);
  // Delay time between state transition.
  /* wr_val = sm_enet_set(rd_val,infmode ? 15 : 15, 15, 12); */
  wr_val = sm_enet_set(rd_val,infmode ? 15 : 15, 15, 12);
  // Delay time between state transition.
  /* wr_val = sm_enet_set(wr_val,infmode ? 15 : 15, 11, 8); */
  wr_val = sm_enet_set(wr_val,infmode ? 15 : 1, 11, 8);
  // Delay time between state transition.
  /* wr_val = sm_enet_set(wr_val,infmode ? 15 : 15, 7, 4); */
  wr_val = sm_enet_set(wr_val,infmode ? 15 : 2, 7, 4);
  // Delay time between state transition.
  /* wr_val = sm_enet_set(wr_val,infmode ? 15 : 15, 3, 0); */
  wr_val = sm_enet_set(wr_val,infmode ? 15 : 2, 3, 0);
  enet_sds_ind_csr_reg_wr("CMU_reg13", CMU + 2*13, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg14
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg14", CMU + 2*14,eth_type,port,display);
  // Delay time between state transition.
  /* wr_val = sm_enet_set(rd_val,infmode ? 15 : 15, 15, 12); */
  wr_val = sm_enet_set(rd_val,infmode ? 15 : 2, 15, 12);
  // Delay time between state transition.
  /* wr_val = sm_enet_set(wr_val,infmode ? 15 : 15, 11, 8); */
  wr_val = sm_enet_set(wr_val,infmode ? 15 : 2, 11, 8);
  // Delay time between state transition.
  /* wr_val = sm_enet_set(wr_val,infmode ? 15 : 15, 7, 4); */
  wr_val = sm_enet_set(wr_val,infmode ? 15 : 1, 7, 4);
  // Delay time between state transition.
  /* wr_val = sm_enet_set(wr_val,infmode ? 15 : 15, 3, 0); */
  wr_val = sm_enet_set(wr_val,infmode ? 15 : 4, 3, 0);
  enet_sds_ind_csr_reg_wr("CMU_reg14", CMU + 2*14, wr_val,eth_type,port,display);
                                               
  if(internal_ref_clk){
    printf(" ***** CMU_REG1[0]= 0 selects Internal REFCLK ****** \n");
    //CMU_reg1
    rd_val =  enet_sds_ind_csr_reg_rd("CMU_reg1", CMU + 2*1,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 1, 0, 0);
    enet_sds_ind_csr_reg_wr("CMU_reg1", CMU + 2*1, wr_val,eth_type,port,display);
   
    // CMU_reg12, nnguyen added
    // rd_val =  enet_sds_ind_csr_reg_rd("CMU_reg12", CMU + 2*12,eth_type,port,display);
    // wr_val = sm_enet_set(rd_val,infmode ? 3 : 7, 7, 4); // State_delay9 Check with Anil
    // enet_sds_ind_csr_reg_wr("CMU_reg12", CMU + 2*12, wr_val,eth_type,port,display);
  }
  else{
    printf(" ***** CMU_REG1[0]= 0 selects Ext REFCLK ****** \n");  // POLY PLEASE DONT CHANGE THIS
    //CMU_reg1
    rd_val =  enet_sds_ind_csr_reg_rd("CMU_reg1", CMU + 2*1,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 0, 0, 0);
    enet_sds_ind_csr_reg_wr("CMU_reg1", CMU + 2*1, wr_val,eth_type,port,display);
  }

  // CMU_reg2
  rd_val =  enet_sds_ind_csr_reg_rd("CMU_reg2", CMU + 2*2,eth_type,port,display);
  // Ref clk divider setting
  wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 15, 14);
  // Feedback divider setting
  wr_val = sm_enet_set(wr_val,infmode ? 32 : 49, 13, 5);
  enet_sds_ind_csr_reg_wr("CMU_reg2", CMU + 2*2, wr_val,eth_type,port,display);


  /////////////
  // CMU_reg9
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg9", CMU + 2*9,eth_type,port,display);
  // Post Divider
  wr_val = sm_enet_set(rd_val,infmode ? 0 : 1, 3, 3);
  // Word mode for PClk
  wr_val = sm_enet_set(wr_val,infmode ? 6 : 1, 6, 4);
  enet_sds_ind_csr_reg_wr("CMU_reg9", CMU + 2*9, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg1
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg1", CMU + 2*1,eth_type,port,display);
  // PLL BW setting
  // wr_val = sm_enet_set(rd_val,infmode ? 7 : 11, 13, 10); // xls
  // wr_val = sm_enet_set(rd_val,infmode ? 7 : 0, 13, 10); // Anil
  wr_val = sm_enet_set(rd_val,infmode ? 7 : 10, 13, 10); // Anil
  // PLL BW setting
  //wr_val = sm_enet_set(wr_val,infmode ? 2 : 2, 9, 5); // xls
  wr_val = sm_enet_set(wr_val,infmode ? 2 : 1, 9, 5); // Anil
  enet_sds_ind_csr_reg_wr("CMU_reg1", CMU + 2*1, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg3
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg3", CMU + 2*3,eth_type,port,display);
  // PLL BW setting
  wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 3, 0);
  enet_sds_ind_csr_reg_wr("CMU_reg3", CMU + 2*3, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg2
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg2", CMU + 2*2,eth_type,port,display);
  // PLL BW setting
  //wr_val = sm_enet_set(rd_val,infmode ? 7 : 7, 4, 1); // xls
  wr_val = sm_enet_set(rd_val,infmode ? 7 : 15, 4, 1); // xls
  enet_sds_ind_csr_reg_wr("CMU_reg2", CMU + 2*2, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg5
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg5", CMU + 2*5,eth_type,port,display);
  // PLL BW setting
  //wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 15, 14); // xls
  wr_val = sm_enet_set(rd_val,infmode ? 0 : 3, 15, 14); // Anil
  // PLL BW setting
  //wr_val = sm_enet_set(wr_val,infmode ? 0 : 0, 13, 12); // xls
  wr_val = sm_enet_set(wr_val,infmode ? 0 : 3, 13, 12); // Anil
  wr_val = sm_enet_set(wr_val,infmode ? 4 : 7, 3, 1); // pll_lock_resolution. Provided by Anil
  enet_sds_ind_csr_reg_wr("CMU_reg5", CMU + 2*5, wr_val,eth_type,port,display);
   
  /*                                                                                         
/////////////
// CMU_reg4
rd_val = enet_sds_ind_csr_reg_rd("CMU_reg4", CMU + 2*4,eth_type,port,display);
// PLL BW setting for PCIE
wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 3, 0);
enet_sds_ind_csr_reg_wr("CMU_reg4", CMU + 2*4, wr_val,eth_type,port,display);
  */

  /////////////
  // CMU_reg8
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg8", CMU + 2*8,eth_type,port,display);
  wr_val = sm_enet_set(rd_val,infmode ? 7 : 7, 7, 5); // ucdiv. added by satish for correct usr clock - 01 Feb
  wr_val = sm_enet_set(wr_val, 0xAA, 15, 8); // tx_data_rate_ch3,2,1,0 = 2'h2
  enet_sds_ind_csr_reg_wr("CMU_reg8", CMU + 2*8, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg6
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg6", CMU + 2*6,eth_type,port,display);
  wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 10, 9); // pll_vregtrim
  wr_val = sm_enet_set(wr_val,infmode ? 1 : 0, 3, 3); // Added by Satish to enable user clock in xgmii mode
  enet_sds_ind_csr_reg_wr("CMU_reg6", CMU + 2*6, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg32
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg32", CMU + 2*32,eth_type,port,display);
  // Bias Current adj
  wr_val = sm_enet_set(rd_val,infmode ? 3 : 3, 8, 7);
  enet_sds_ind_csr_reg_wr("CMU_reg32", CMU + 2*32, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg1
  printf("\nCalibration mode set to %s \n", pll_manualcal ? "MANUAL" : "AUTOMATIC");
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg1", CMU + 2*1,eth_type,port,display);
  // Manual cal enable
  wr_val = sm_enet_set(rd_val,infmode ? pll_manualcal : pll_manualcal, 3, 3);
  enet_sds_ind_csr_reg_wr("CMU_reg1", CMU + 2*1, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg3
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg3", CMU + 2*3,eth_type,port,display);
  // Manual cal value
  //wr_val = sm_enet_set(rd_val,infmode ? 5 : 25, 15, 10); // xls
  //wr_val = sm_enet_set(rd_val,infmode ? 5 : 28, 15, 10); // Anil
  wr_val = sm_enet_set(rd_val,vco_momsel_init, 15, 10); // Anil
  // Init Momsel
  /* wr_val = sm_enet_set(wr_val,infmode ? 16 : 16, 9, 4); */
  wr_val = sm_enet_set(wr_val,vco_momsel_init, 9, 4);
  enet_sds_ind_csr_reg_wr("CMU_reg3", CMU + 2*3, wr_val,eth_type,port,display);

  /*
/////////////
// CMU_reg4
rd_val = enet_sds_ind_csr_reg_rd("CMU_reg4", CMU + 2*4,eth_type,port,display);
// Manual cal value for PCIE - don't care
// Init Momsel Fro 8G
wr_val = sm_enet_set(rd_val,infmode ? 16 : 16, 9, 4);
enet_sds_ind_csr_reg_wr("CMU_reg4", CMU + 2*4, wr_val,eth_type,port,display);
  */

  /////////////
  // CMU_reg34
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg34", CMU + 2*34,eth_type,port,display);
  // Threshold setting for VCO cal
  wr_val = sm_enet_set(rd_val,infmode ? 2 : 2, 15, 12);
  // Threshold setting for VCO cal
  wr_val = sm_enet_set(wr_val,infmode ? 10 : 10, 11, 8);
  // Threshold setting for VCO cal
  wr_val = sm_enet_set(wr_val,infmode ? 2 : 2, 7, 4);
  // Threshold setting for VCO cal
  wr_val = sm_enet_set(wr_val,infmode ? 10 : 10, 3, 0);
  enet_sds_ind_csr_reg_wr("CMU_reg34", CMU + 2*34, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg0
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg0", CMU + 2*0,eth_type,port,display);
  // Pll lock calibration resolution
  wr_val = sm_enet_set(rd_val,infmode ? 7 : 7, 7, 5);
  enet_sds_ind_csr_reg_wr("CMU_reg0", CMU + 2*0, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg16
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
  // VCO Calib wait time
  wr_val = sm_enet_set(rd_val,infmode ? 7 : 7, 4, 2);
  enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg30
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg30", CMU + 2*30,eth_type,port,display);
  // Lock count Wait time
  wr_val = sm_enet_set(rd_val,infmode ? 3 : 3, 2, 1);
  enet_sds_ind_csr_reg_wr("CMU_reg30", CMU + 2*30, wr_val,eth_type,port,display);
 
  /////////////
  // CMU_reg30
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg30", CMU + 2*30,eth_type,port,display);
  // PCIE mode enable
  wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 3, 3);
  // Ref Divider for PCI Gen3 mode - dont care
  // FB divider for Gen3 mode - dont care
  // Post Divider for Gen3 mode - dont care
  enet_sds_ind_csr_reg_wr("CMU_reg30", CMU + 2*30, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg0
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg0", CMU + 2*0,eth_type,port,display);
  // PCIE gen3 , driven by Pipe
  wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 0, 0);
  enet_sds_ind_csr_reg_wr("CMU_reg0", CMU + 2*0, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg32
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg32", CMU + 2*32,eth_type,port,display);
  // PVT Calibration Wait time
  wr_val = sm_enet_set(rd_val,infmode ? 3 : 3, 2, 1);
  enet_sds_ind_csr_reg_wr("CMU_reg32", CMU + 2*32, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg31
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg31", CMU + 2*31,eth_type,port,display);
  // LOS override for State machine
  wr_val = sm_enet_set(rd_val,infmode ? 15 : 15, 3, 0);
  enet_sds_ind_csr_reg_wr("CMU_reg31", CMU + 2*31, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg37
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg37", CMU + 2*37,eth_type,port,display);
  // CTLE Calibration Done state Override
  wr_val = sm_enet_set(rd_val,infmode ? 15 : 15, 15, 12);
  // FT tap search done Override.
  wr_val = sm_enet_set(wr_val,infmode ? 15 : 15, 3, 0);
  enet_sds_ind_csr_reg_wr("CMU_reg37", CMU + 2*37, wr_val,eth_type,port,display);
  ///////////////////////////////////

}

void xgenet_sds_rxtx_cfg(uint32_t infmode,int eth_type, int port, int display) {
  uint32_t wr_val, rd_val, inst, inst_base;

  for(inst = 0;inst < 1;inst++) {
    inst_base = 0x0400 + 0x200*inst;

    ///////////////////////////////////
    // Tx CONTROL
    ///////////////
    //rxtx_reg4
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 4*2,eth_type,port,display);
    // TX rate Setting
    wr_val = sm_enet_set(rd_val,infmode ? 0 : 2, 15, 14);
    // TX word mode setting
    wr_val = sm_enet_set(wr_val,infmode ? 6 : 1, 13, 11);
    // PRBS Select
    wr_val = sm_enet_set(wr_val,infmode ? 4 : 4, 10, 8);
    enet_sds_ind_csr_reg_wr("rxtx_reg4",inst_base + 4*2, wr_val,eth_type,port,display);

    /////////////
    // CMU_reg16
    // TX Rate Change enable: Toggle 0-1-0
    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU +2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 0, 15, 15);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 1, 15, 15);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val,0, 15, 15);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU +2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 0, 13, 13);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 1, 13, 13);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val,0, 13, 13);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU +2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 0, 11, 11);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 1, 11, 11);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val,0, 11, 11);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU +2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 0, 9, 9);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 1, 9, 9);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val,0, 9, 9);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg2
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2,eth_type,port,display);
    // Fifo Mode enable
    wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 5, 5);
    enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg6
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2,eth_type,port,display);
    // TX output amplitude enable
    wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 6, 6);
    // TX Amplitude control
    //POLY     wr_val = sm_enet_set(wr_val,infmode ? 8 : 8, 10, 7);
    wr_val = sm_enet_set(wr_val,infmode ? 11 : 8, 10, 7); // Anil
    enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg5
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg5", inst_base + 5*2,eth_type,port,display);
    // TX FIR pre cursor
    //wr_val = sm_enet_set(rd_val,infmode ? 6 : 6, 15, 11); // xls
    wr_val = sm_enet_set(rd_val,infmode ? 6 : 0, 15, 11); // Anil
    // TX FIR post Cursor
    //POLY    wr_val = sm_enet_set(wr_val,infmode ? 4 : 4, 10, 5);
    //wr_val = sm_enet_set(wr_val,infmode ? 6 : 6, 10, 5); // xls
    wr_val = sm_enet_set(wr_val,infmode ? 6 : 0, 10, 5); // Anil
    // TX FIR pre 2 Cursor
    wr_val = sm_enet_set(wr_val,infmode ? 0 : 0, 4, 0);
    enet_sds_ind_csr_reg_wr("rxtx_reg5", inst_base + 5*2, wr_val,eth_type,port,display);
                      
    /////////////
    // rxtx_reg61 - Don't Care

    /////////////
    // rxtx_reg2
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2,eth_type,port,display);
    // TX Resetn
    wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 12, 12);
    enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, wr_val,eth_type,port,display);
    
    /////////////
    // rxtx_reg4
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 4*2,eth_type,port,display);
    // TX Forward Loopback enable
    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 6, 6);
    enet_sds_ind_csr_reg_wr("rxtx_reg4", inst_base + 4*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg2
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2,eth_type,port,display);
    // TX Bist enable for PRBS transfer
    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 11, 11);
    enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg6
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2,eth_type,port,display);
    // TX Idle Control
    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 3, 3);
    enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg145
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg145", inst_base + 145*2,eth_type,port,display);
    // TX Idle Control
    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 0, 0);
    enet_sds_ind_csr_reg_wr("rxtx_reg145", inst_base + 145*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg2
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2,eth_type,port,display);
    // TX Serial Data swap
    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 10, 10);
    enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, wr_val,eth_type,port,display);

    //////////////////////////
    // RX Control
    /////////////
    // rxtx_reg2
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2,eth_type,port,display);
    // RX termination Reset
    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 14, 14);
    // RX Termination voltage setting enable
    wr_val = sm_enet_set(wr_val,infmode ? 1 : 1, 8, 8);
    // RX Termination voltage setting Select
    wr_val = sm_enet_set(wr_val,infmode ? 1 : 1, 7, 6);
    enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg1
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg1", inst_base + 1*2,eth_type,port,display);
    // RX AC common model select
    wr_val = sm_enet_set(rd_val,infmode ? 7 : 7, 15, 12);
    enet_sds_ind_csr_reg_wr("rxtx_reg1", inst_base + 1*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg12
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg12", inst_base + 12*2,eth_type,port,display);
    // RX Hi-Z termination enable
    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 1, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg12", inst_base + 12*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg61 - Don't care

    /////////////
    // rxtx_reg7
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 7*2,eth_type,port,display);
    // RX PRBS Select
    wr_val = sm_enet_set(rd_val,infmode ? 4 : 4, 5, 3);
    // RX Word Mode
    wr_val = sm_enet_set(wr_val,infmode ? 6 : 1, 13, 11);
    // RX Data rate select
    wr_val = sm_enet_set(wr_val,infmode ? 0 : 2, 10, 9);
    enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 7*2, wr_val,eth_type,port,display);
                                                                           
   
    /////////////
    // CMU_reg16
    // RX rate change enable: Toggle 0-1-0
    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 0, 14, 14);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 1, 14, 14);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 0, 14, 14);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 0, 12, 12);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 1, 12, 12);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 0, 12, 12);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 0, 10, 10);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 1, 10, 10);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 0, 10, 10);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 0, 8, 8);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 1, 8, 8);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 0, 8, 8);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg148
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg148", inst_base + 148*2,eth_type,port,display);
    // BISt Word Count
    wr_val = sm_enet_set(rd_val,infmode ? 0xFFFF : 0xFFFF, 15, 0);
    enet_sds_ind_csr_reg_wr("rxtx_reg148", inst_base + 148*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg149
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg149", inst_base + 149*2,eth_type,port,display);
    // BISt Word Count
    wr_val = sm_enet_set(rd_val,infmode ? 0xFFFF : 0xFFFF, 15, 0);
    enet_sds_ind_csr_reg_wr("rxtx_reg149", inst_base + 149*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg150
    rd_val =  enet_sds_ind_csr_reg_rd("rxtx_reg150", inst_base + 150*2,eth_type,port,display);
    // BISt Word Count
    wr_val = sm_enet_set(rd_val,infmode ? 0xFFFF : 0xFFFF, 15, 0);
    enet_sds_ind_csr_reg_wr("rxtx_reg150", inst_base + 150*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg151
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg151", inst_base + 151*2,eth_type,port,display);
    // BISt Word Count
    wr_val = sm_enet_set(rd_val,infmode ? 0xFFFF : 0xFFFF, 15, 0);
    enet_sds_ind_csr_reg_wr("rxtx_reg151", inst_base + 151*2, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg147", inst_base + 147*2,eth_type,port,display);
    // State Machine Override controls
    wr_val = sm_enet_set(rd_val,infmode ? 6 : 6, 15, 0);
    enet_sds_ind_csr_reg_wr("rxtx_reg147", inst_base + 147*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg1
    rd_val =  enet_sds_ind_csr_reg_rd("rxtx_reg1", inst_base + 1*2,eth_type,port,display);
    // CTLE Full rate Control
    wr_val = sm_enet_set(rd_val,infmode ? 28 : 28, 11, 7);
    enet_sds_ind_csr_reg_wr("rxtx_reg1", inst_base + 1*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg0
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg0", inst_base + 0*2,eth_type,port,display);
    // CTLE Half rate Control
    //wr_val = sm_enet_set(rd_val,infmode ? 16 : 16, 15, 11); // xls
    wr_val = sm_enet_set(rd_val,infmode ? 16 : 13, 15, 11); // Anil
    // CTLE Quarter rate Control
    //wr_val = sm_enet_set(wr_val,infmode ? 16 : 16, 10, 6); // xls
    wr_val = sm_enet_set(wr_val,infmode ? 16 : 13, 10, 6); // Anil
    // CTLE Fifth rate Control
    //wr_val = sm_enet_set(wr_val,infmode ? 16 : 16, 5, 1); // xls
    wr_val = sm_enet_set(wr_val,infmode ? 16 : 13, 5, 1); // Anil
    enet_sds_ind_csr_reg_wr("rxtx_reg0", inst_base + 0*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg14
    rd_val =  enet_sds_ind_csr_reg_rd("rxtx_reg14", inst_base + 14*2,eth_type,port,display);
    // CTLE Man Mode Select
    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 6, 6);
    enet_sds_ind_csr_reg_wr("rxtx_reg14", inst_base + 14*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg12
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg12", inst_base + 12*2,eth_type,port,display);
    // SUM Offset enable
    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 2, 2);
    enet_sds_ind_csr_reg_wr("rxtx_reg12", inst_base + 12*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg12
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg12", inst_base + 12*2,eth_type,port,display);
    // Latch Offset Enable
    wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 13, 13);
    enet_sds_ind_csr_reg_wr("rxtx_reg12", inst_base + 12*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg128
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg128", inst_base + 128*2,eth_type,port,display);
    // Latch Cal Wait Select
    wr_val = sm_enet_set(rd_val,infmode ? 3 : 3, 3, 2);
    enet_sds_ind_csr_reg_wr("rxtx_reg128", inst_base + 128*2, wr_val,eth_type,port,display);

    // /////////////
    // // rxtx_reg127
    // rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2,eth_type,port,display);
    // // Latch Manual Cal enable
    // wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 3, 3);
    // enet_sds_ind_csr_reg_wr("rxtx_reg127", inst_base + 127*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg8
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg8", inst_base + 8*2,eth_type,port,display);
    // CDR Phase Loop enable
    wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 14, 14);
    // CDR Bypass RXLOS signal
    //wr_val = sm_enet_set(wr_val,infmode ? 0 : 0, 11, 11); // xls
    wr_val = sm_enet_set(wr_val,infmode ? 0 : 1, 11, 11); // Anil
    enet_sds_ind_csr_reg_wr("rxtx_reg8", inst_base + 8*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg61
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg61", inst_base + 61*2,eth_type,port,display);
    // CDR Clock Speed Select
    //wr_val = sm_enet_set(rd_val,infmode ? 7 : 2, 13, 10); // xls
    wr_val = sm_enet_set(rd_val,infmode ? 7 : 1, 13, 10); // Anil
    enet_sds_ind_csr_reg_wr("rxtx_reg61", inst_base + 61*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg125
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg125", inst_base + 125*2,eth_type,port,display);
    // IQ phase different
    //wr_val = sm_enet_set(rd_val,infmode ? 20 : 6, 15, 9); // xls
    wr_val = sm_enet_set(rd_val,infmode ? 20 : 0, 15, 9); // Anil
    // Phase loop adaptation manual enable
    wr_val = sm_enet_set(wr_val,infmode ? 1 : 1, 1, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg125", inst_base + 125*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg11
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg11", inst_base + 11*2,eth_type,port,display);
    // Limit for Phase loop adaptation
    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 15, 11);
    enet_sds_ind_csr_reg_wr("rxtx_reg11", inst_base + 11*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg61
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg61", inst_base + 61*2,eth_type,port,display);
    // Freq loop Disable
    //wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 3, 3); // xls
    wr_val = sm_enet_set(rd_val,infmode ? 1 : 0, 3, 3); // Anil
    enet_sds_ind_csr_reg_wr("rxtx_reg61", inst_base + 61*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg102
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg102", inst_base + 102*2,eth_type,port,display);
    // Freq offset limit setting
    wr_val = sm_enet_set(rd_val,infmode ? 3 : 3, 6, 5);
    enet_sds_ind_csr_reg_wr("rxtx_reg102", inst_base + 102*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg8
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg8", inst_base + 8*2,eth_type,port,display);
    // SSC enable - CDR
    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 9, 9);
    enet_sds_ind_csr_reg_wr("rxtx_reg8", inst_base + 8*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg96
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg96", inst_base + 96*2,eth_type,port,display);
    // Freq Loop BW
    wr_val = sm_enet_set(rd_val,infmode ? 16 : 16, 15, 11);
    // Freq Loop BW
    wr_val = sm_enet_set(wr_val,infmode ? 16 : 16, 10, 6);
    // Freq Loop BW
    wr_val = sm_enet_set(wr_val,infmode ? 16 : 16, 5, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg96", inst_base + 96*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg97
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg97", inst_base + 97*2,eth_type,port,display);
    // Freq Loop BW
    wr_val = sm_enet_set(rd_val,infmode ? 16 : 16, 15, 11);
    // Freq Loop BW
    wr_val = sm_enet_set(wr_val,infmode ? 16 : 16, 10, 6);
    // Freq Loop BW
    wr_val = sm_enet_set(wr_val,infmode ? 16 : 16, 5, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg97", inst_base + 97*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg98
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg98", inst_base + 98*2,eth_type,port,display);
    // Freq Loop BW
    wr_val = sm_enet_set(rd_val,infmode ? 16 : 16, 15, 11);
    // Freq Loop BW
    wr_val = sm_enet_set(wr_val,infmode ? 16 : 16, 10, 6);
    // Freq Loop BW
    wr_val = sm_enet_set(wr_val,infmode ? 16 : 16, 5, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg98", inst_base + 98*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg99
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg99", inst_base + 99*2,eth_type,port,display);
    // CDR Phase Loop BW
    //wr_val = sm_enet_set(rd_val,infmode ? 5 : 5, 15, 11); // xls
    wr_val = sm_enet_set(rd_val,infmode ? 5 : 8, 15, 11); // updated on 04/03
    // CDR Phase Loop BW
    //wr_val = sm_enet_set(wr_val,infmode ? 5 : 5, 10, 6); // xls
    wr_val = sm_enet_set(wr_val,infmode ? 5 : 8, 10, 6); // Anil
    // CDR Phase Loop BW
    //wr_val = sm_enet_set(wr_val,infmode ? 5 : 5, 5, 1); // xls
    wr_val = sm_enet_set(wr_val,infmode ? 5 : 8, 5, 1); // Anil
    enet_sds_ind_csr_reg_wr("rxtx_reg99", inst_base + 99*2, wr_val,eth_type,port,display);
    
    /////////////
    // rxtx_reg100
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg100", inst_base + 100*2,eth_type,port,display);
    // CDR Phase Loop BW
    //wr_val = sm_enet_set(rd_val,infmode ? 5 : 5, 15, 11); // xls
    wr_val = sm_enet_set(rd_val,infmode ? 5 : 8, 15, 11); // Anil
    // CDR Phase Loop BW
    //wr_val = sm_enet_set(wr_val,infmode ? 5 : 5, 10, 6); // xls
    wr_val = sm_enet_set(wr_val,infmode ? 5 : 8, 10, 6); // Anil
    // CDR Phase Loop BW
    //wr_val = sm_enet_set(wr_val,infmode ? 5 : 5, 5, 1); // xls
    wr_val = sm_enet_set(wr_val,infmode ? 5 : 8, 5, 1); // Anil
    enet_sds_ind_csr_reg_wr("rxtx_reg100", inst_base + 100*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg101
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg101", inst_base + 101*2,eth_type,port,display);
    // CDR Phase Loop BW
    //wr_val = sm_enet_set(rd_val,infmode ? 5 : 5, 15, 11); // xls
    wr_val = sm_enet_set(rd_val,infmode ? 5 : 8, 15, 11); // Anil
    // CDR Phase Loop BW
    //wr_val = sm_enet_set(wr_val,infmode ? 5 : 5, 10, 6); // xls
    wr_val = sm_enet_set(wr_val,infmode ? 5 : 8, 10, 6); // Anil
    // CDR Phase Loop BW
    //wr_val = sm_enet_set(wr_val,infmode ? 5 : 5, 5, 1); // xls
    wr_val = sm_enet_set(wr_val,infmode ? 5 : 8, 5, 1); // Anil
    enet_sds_ind_csr_reg_wr("rxtx_reg101", inst_base + 101*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg8
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg8", inst_base + 8*2,eth_type,port,display);
    // RX los disable
    wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 8, 8);
    enet_sds_ind_csr_reg_wr("rxtx_reg8", inst_base + 8*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg26
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg26", inst_base + 26*2,eth_type,port,display);
    // BLWC Enable
    wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 3, 3);
    enet_sds_ind_csr_reg_wr("rxtx_reg26", inst_base + 26*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg31  --> Added by Poly on 04/03/2013
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg31", inst_base + 31*2,eth_type,port,display);
    // H0 preset 
    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 15, 9);
    enet_sds_ind_csr_reg_wr("rxtx_reg31", inst_base + 31*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg81
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg81", inst_base + 81*2,eth_type,port,display);
    // DFE BW select
    wr_val = sm_enet_set(rd_val,infmode ? 14 : 14, 15, 11);
    // DFE BW select
    wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 10, 6);
    // DFE BW select
    wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 5, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg81", inst_base + 81*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg82
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg82", inst_base + 82*2,eth_type,port,display);
    // DFE BW select
    wr_val = sm_enet_set(rd_val,infmode ? 14 : 14, 15, 11);
    // DFE BW select
    wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 10, 6);
    // DFE BW select
    wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 5, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg82", inst_base + 82*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg83
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg83", inst_base + 83*2,eth_type,port,display);
    // DFE BW select
    wr_val = sm_enet_set(rd_val,infmode ? 14 : 14, 15, 11);
    // DFE BW select
    wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 10, 6);
    // DFE BW select
    wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 5, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg83", inst_base + 83*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg84
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg84", inst_base + 84*2,eth_type,port,display);
    // CDR phase Adaptation Loop BW
    wr_val = sm_enet_set(rd_val,infmode ? 14 : 14, 15, 11);
    // CDR phase Adaptation Loop BW
    wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 10, 6);
    // CDR phase Adaptation Loop BW
    wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 5, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg84", inst_base + 84*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg85
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg85", inst_base + 85*2,eth_type,port,display);
    // CDR phase Adaptation Loop BW
    wr_val = sm_enet_set(rd_val,infmode ? 14 : 14, 15, 11);
    // CDR phase Adaptation Loop BW
    wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 10, 6);
    // CDR phase Adaptation Loop BW
    wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 5, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg85", inst_base + 85*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg86
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg86", inst_base + 86*2,eth_type,port,display);
    // CDR phase Adaptation Loop BW
    wr_val = sm_enet_set(rd_val,infmode ? 14 : 14, 15, 11);
    // CDR phase Adaptation Loop BW
    wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 10, 6);
    // CDR phase Adaptation Loop BW
    wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 5, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg86", inst_base + 86*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg87
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg87", inst_base + 87*2,eth_type,port,display);
    // DFE Main Tap (Threshold) BW
    wr_val = sm_enet_set(rd_val,infmode ? 14 : 14, 15, 11);
    // DFE Main Tap (Threshold) BW
    wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 10, 6);
    // DFE Main Tap (Threshold) BW
    wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 5, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg87", inst_base + 87*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg88
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg88", inst_base + 88*2,eth_type,port,display);
    // DFE Main Tap (Threshold) BW
    wr_val = sm_enet_set(rd_val,infmode ? 14 : 14, 15, 11);
    // DFE Main Tap (Threshold) BW
    wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 10, 6);
    // DFE Main Tap (Threshold) BW
    wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 5, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg88", inst_base + 88*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg89
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg89", inst_base + 89*2,eth_type,port,display);
    // DFE Main Tap (Threshold) BW
    wr_val = sm_enet_set(rd_val,infmode ? 14 : 14, 15, 11);
    // DFE Main Tap (Threshold) BW
    wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 10, 6);
    // DFE Main Tap (Threshold) BW
    wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 5, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg89", inst_base + 89*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg145
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg145", inst_base + 145*2,eth_type,port,display);
    // DFE Configuration Selection
    wr_val = sm_enet_set(rd_val,infmode ? 3 : 3, 15, 14);
    enet_sds_ind_csr_reg_wr("rxtx_reg145", inst_base + 145*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg28
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg28", inst_base + 28*2,eth_type,port,display);
    // DFE tap enables
    //   wr_val = sm_enet_set(rd_val,infmode ? 0xFFFF : 0xFFFF, 15, 0); // xls
    wr_val = sm_enet_set(rd_val,infmode ? 0xFFFF : 0x0, 15, 0); // Anil
    enet_sds_ind_csr_reg_wr("rxtx_reg28", inst_base + 28*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg7
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 7*2,eth_type,port,display);
    // RX Resetn
    wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 8, 8);
    // RX Forward Loopback enable
    wr_val = sm_enet_set(wr_val,infmode ? 0 : 0, 14, 14);
    // RX Bist enable for PRBS transfer
    wr_val = sm_enet_set(wr_val,infmode ? 0 : 0, 6, 6);
    enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 7*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg61
    // Bert Reset Active Low: Toggle0-1-0
    //rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg61", inst_base + 61*2,eth_type,port,display);
    //wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 5, 5);
    //enet_sds_ind_csr_reg_wr("rxtx_reg61", inst_base + 61*2, wr_val,eth_type,port,display);

    //rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg61", inst_base + 61*2,eth_type,port,display);
    //wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 5, 5);
    //enet_sds_ind_csr_reg_wr("rxtx_reg61", inst_base + 61*2, wr_val,eth_type,port,display);

    //rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg61", inst_base + 61*2,eth_type,port,display);
    //wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 5, 5);
    //enet_sds_ind_csr_reg_wr("rxtx_reg61", inst_base + 61*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg6
    // Bert PRBS resync: Toggle0-1-0
    //rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2,eth_type,port,display);
    //wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 1, 1);
    //enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val,eth_type,port,display);

    //rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2,eth_type,port,display);
    //wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 1, 1);
    //enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val,eth_type,port,display);

    //rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2,eth_type,port,display);
    //wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 1, 1);
    //enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg6
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2,eth_type,port,display);
    // Bert Error count capture
    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 0, 0);
    enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg12
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg12", inst_base + 12*2,eth_type,port,display);
    // RX Serial Data swap(P and N polarity)
    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 11, 11);
    enet_sds_ind_csr_reg_wr("rxtx_reg12", inst_base + 12*2, wr_val,eth_type,port,display);
  }
}

//refclk_cmos_sel = 0; - External differential clk
//refclk_cmos_sel = 1; - Internal single ended (cmos) clk

int sm_xgenet_module_init_enet_serdes( uint32_t infmode, uint32_t refclk_cmos_sel, uint32_t tx2rx_serdes_lb,int eth_type, int port, int display) {
  uint32_t wr_val, rd_val, loop;
  uint32_t customer_pin_mode;
  uint32_t pll_ready, pll_lock, vco_calibration, tx_ready, rx_ready, rx_clk_inv;
  uint32_t refclksel, rndrefclk;
  uint32_t offset_addr;
  uint32_t inst, inst_base;
  uint32_t data32;
  
  printf("C> ======================================================================= \n");
  printf("C> sm_xgenet_module_init_enet_serdes()\n");

  printf("INIT_SERDES : program PLL for base addr: %h\n",xgenet_base_addr);

  //get clk
  // rndrefclk = 0, refclksel = 0; refclk_cmos_sel = 0; - External differential clk
  // rndrefclk = 1, refclksel = 0; refclk_cmos_sel = 1; - Internal single ended (cmos) clk
  refclksel = 0;
  rndrefclk = (refclksel << 1) | refclk_cmos_sel;

  printf("INIT_SERDES : Config Ref Clock");
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg0", CMU + 2*0,eth_type,port,display);
  wr_val = sm_enet_set(rd_val, refclksel, 13, 13);
  enet_sds_ind_csr_reg_wr("CMU_reg0", CMU + 2*0, wr_val,eth_type,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg1", CMU + 2*1,eth_type,port,display);
  wr_val = sm_enet_set(rd_val, refclk_cmos_sel, 0, 0);
  enet_sds_ind_csr_reg_wr("CMU_reg1", CMU + 2*1, wr_val,eth_type,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg37", CMU + 2*37,eth_type,port,display);
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg36", CMU + 2*36,eth_type,port,display);
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);

  // step 0: setup ETH_PLL which will provide internal reference clock to serdes
  if (infmode)
    wr_val = 0x306430; 
  else
    wr_val = 0x305030; 

  if (((xgenet_base_addr & 0x00100000)>> 20) == 0x1) {offset_addr = XGENET_0_BASE_ADDR;} 
  else {offset_addr = XGENET_2_BASE_ADDR;}

  write(offset_addr + SM_XGENET_CLKRST_CSR_XGENET_PLL_CFG__ADDR, wr_val);

  if(refclk_cmos_sel) {	
    //wait for PLL lock
    do{
      rd_val = read(offset_addr + SM_XGENET_CLKRST_CSR_XGENET_PLL_STAT__ADDR);
      printf("INIT_SERDES : waiting for XGENET_PLL to lock\n");
      //sm_host_delay_ns(200);
    } while(rd_val == 0);
  }

  // program PLL output clock divider value after PLL has locked
  if (infmode)
    wr_val = 0x4; 
  else
    wr_val = 0x5; 

  write(offset_addr + SM_XGENET_CLKRST_CSR_XGENET_PLL_DIV_CFG__ADDR, wr_val);

  // step 1: De-assert all the SerDes power down, (txpd, rxpd, pllpd). Can be	tied high
  // step 2: De-assert i_hresetn (SerDes register reset, active low signal/ step 3: Use the SerDs main reset(i_resetb) to start the reset sequencer
  // which generate internal rx/tx and pll resets
  printf("INIT_SERDES : assert all reset\n");
  // XGENET_SDS_RST_CTL
  //eth_wr(SM_XGENET_SDS_CSR_REGS_XGENET_SDS_RST_CTL__ADDR, 0x0,eth_type,port,display); // Original
  //eth_wr(SM_XGENET_SDS_CSR_REGS_XGENET_SDS_RST_CTL__ADDR, 0xFE,eth_type,port,display);  // Anil
  eth_wr(SM_XGENET_SDS_CSR_REGS_XGENET_SDS_RST_CTL__ADDR, 0xDE,eth_type,port,display);  // Anil

  write( 0x17001398,0x001E1E1E); // Give control to Slave MDIO
  data32 = read(0x17001398);
  printf (" READ MPA_MDIO_IOCTL : 0x%08x\n", data32);
	
  //delay after forcing reset
  //sm_host_delay_ns(2000);

  //step 4:A) SGMII/ENET (1G) can use LSPLL PLL, native data rate need to set to 10G for LSPLL (Refclk = 100Mhz)
  // REFDIV = 0, N Divider = 1, Post_divider for LS PLL = 1, data_rate = 10 (1/4th rate)
  // i_rx_hsls_sel_l* and i_rx_hsls_sel_l* = 1, Rx and TX wordmode = 001 (10bit mode)
  //step 4:B) XGMII (10G) uses LS PLL, PLL native data rate need to be 10G
  // REFDIV = 0, N Divider = 1, Post_divider for LS PLL = 1, data_rate = 00 (full rate)
  // i_rx_hsls_sel_l* and i_rx_hsls_sel_l* = 1, Rx and TX wordmode = 110 (64bit mode) or 111 (66bit mode)

  printf("INIT_SERDES : REFCLK using -- %s\n",(rndrefclk == 0) ? "External differential clk" : "Internal single ended (cmos) clk");
  printf("INIT_SERDES : %s/ENET using -- LSPLL\n",infmode ? "XGMII" : "SGMII");

  // set cfg_i_customer_pin_mode = 0, as all register are directly programmed through indirect programming
  eth_wr(SM_XGENET_SDS_CSR_REGS_XGENET_SDS_CTL0__ADDR, 0,eth_type,port,display); // Ask Anil 

  //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  // This function programs the serdes as per KC_serdes_40nm_setting_0v25.xls
  sm_xgenet_module_program_all_regs(infmode,eth_type,port,display);

  //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	

#ifdef CONFIG_SDS_SERDES_RX_CLK_INV
  rx_clk_inv = 1;
#else 
  rx_clk_inv = 0;
#endif   

  if(rx_clk_inv) {
    printf("INIT_SERDES : Enable RXCLK Inversion.");
    for (inst = 0; inst < 1;  inst++) {
      printf("INIT_SERDES : RXTX Inst %x\n", inst);
      inst_base = 0x0400 + inst*0x0200;
      rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg13", inst_base + 0xD*2,eth_type,port,display);
      wr_val = sm_enet_set(rd_val, 1, 13, 13);
      enet_sds_ind_csr_reg_wr("rxtx_reg13",  inst_base + 0xD*2, wr_val,eth_type,port,display);
    } 
  }

  if (tx2rx_serdes_lb) {
    printf("INIT_SERDES : SERDES Tx2Rx Loopback\n");
    for (inst = 0; inst < 1;  inst++) {
      printf("INIT_SERDES : RXTX Inst %x\n", inst);
      inst_base = 0x0400 + inst*0x0200;
      rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,eth_type,port,display);
      wr_val = sm_enet_set(rd_val, 1, 6, 6);
      enet_sds_ind_csr_reg_wr("rxtx_reg4",  inst_base + 0x4*2, wr_val,eth_type,port,display);

      rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,eth_type,port,display);
      wr_val = sm_enet_set(rd_val, 1, 14, 14);
      enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,eth_type,port,display);
    }
  }

  int rx2tx_serdes_lb = 0;
  if (rx2tx_serdes_lb) {
    printf("INIT_SERDES : SERDES Rx2Tx Loopback\n");
    for (inst = 0; inst < 1;  inst++) {
      printf("INIT_SERDES : RXTX Inst %x\n", inst);
      inst_base = 0x0400 + inst*0x0200;
      rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg8", inst_base + 0x8*2,eth_type,port,display);
      wr_val = sm_enet_set(rd_val, 1, 15, 15); //rxtx_rev_par_lpbk
      enet_sds_ind_csr_reg_wr("rxtx_reg8",  inst_base + 0x8*2, wr_val,eth_type,port,display);
    }
  }


  printf("INIT_SERDES : de-assert all reset\n");
  // XGENET_SDS_RST_CTL
  wr_val = 0xDF; // Original
  eth_wr(SM_XGENET_SDS_CSR_REGS_XGENET_SDS_RST_CTL__ADDR, wr_val,eth_type,port,display);

  serdes_calib_xg(eth_type,port,display);
  serdes_reset_rxd_rxa_xg(eth_type,port,display);


  printf("INIT_SERDES : Check PLL Ready/LOCK and VCO Calibration status\n");
  loop = 1000;
  pll_ready = 0;
  while (pll_ready == 0) {
    // sm_host_delay_ns(200);
    rd_val = eth_rd(SM_XGENET_SDS_CSR_REGS_XGENET_SDS_CMU_STATUS0__ADDR,eth_type,port,display); 
    // memory_barrier();
    pll_ready = FIELD_XGENET_SDS_CMU_STATUS0_CFG_CMU_O_PLL_READY_RD(rd_val);
    pll_lock = FIELD_XGENET_SDS_CMU_STATUS0_CFG_CMU_O_PLL_LOCK_RD(rd_val);
    vco_calibration = FIELD_XGENET_SDS_CMU_STATUS0_CFG_CMU_O_VCO_CALDONE_RD(rd_val);

    if (loop == 0)
      break;
    loop--;
  }

  printf("INIT_SERDES : PLL is %sREADY\n", pll_ready ? "" : "not ");
  printf("INIT_SERDES : PLL %sLOCKed\n", pll_lock ? "" : "not ");
  printf("INIT_SERDES : PLL VCO Calibration %s\n", vco_calibration ? "Successful" : "not Successful");

  printf("INIT_SERDES : Check TX/RX Ready\n");
  rd_val = eth_rd(SM_XGENET_SDS_CSR_REGS_XGENET_SDS_RXTX_STATUS__ADDR,eth_type,port,display); 
  //memory_barrier();
  tx_ready = FIELD_XGENET_SDS_RXTX_STATUS_CFG_TX_O_TX_READY_RD(rd_val);
  rx_ready = FIELD_XGENET_SDS_RXTX_STATUS_CFG_RX_O_RX_READY_RD(rd_val);
	
  printf("INIT_SERDES : TX is %sready\n", tx_ready ? "" : "not ");
  printf("INIT_SERDES : RX is %sready\n", rx_ready ? "" : "not ");	

  //// ********************************************************************
  ////  PRBS Sequence
  //// ********************************************************************
  //// 1. Tx forward loopback enable, enables the loopabck buffer"
  //    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 4*2,eth_type,port,display);
  //    wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 6, 6);
  //    enet_sds_ind_csr_reg_wr("rxtx_reg4", inst_base + 4*2, wr_val,eth_type,port,display);
  //
  ////2. RX Forward Loopback enable
  ////3. RX Bist enable for PRBS transfer
  //   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 7*2,eth_type,port,display);
  //   wr_val = sm_enet_set(wr_val,infmode ? 1 : 1, 14, 14);
  //   wr_val = sm_enet_set(wr_val,infmode ? 1 : 1, 6, 6);
  //   enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 7*2, wr_val,eth_type,port,display);
  //
  ////4. TX Bist enable for PRBS transfer
  //    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2,eth_type,port,display);
  //    wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 11, 11);
  //    enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, wr_val,eth_type,port,display);
  //
  ////5. Toggle Re-sync the RX bert logic, without reset
  //    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2,eth_type,port,display);
  //    wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 1, 1);
  //    enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val,eth_type,port,display);
  //    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2,eth_type,port,display);
  //    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 1, 1);
  //    enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val,eth_type,port,display);
  //    
  ////6. Reset bert logic  (0->1)
  //   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg61", inst_base + 61*2,eth_type,port,display);
  //   wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 5, 5);
  //   enet_sds_ind_csr_reg_wr("rxtx_reg61", inst_base + 61*2, wr_val,eth_type,port,display);
  //   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg61", inst_base + 61*2,eth_type,port,display);
  //   wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 5, 5);
  //   enet_sds_ind_csr_reg_wr("rxtx_reg61", inst_base + 61*2, wr_val,eth_type,port,display);
  //
  ////7. Check for BERT PASS/FAIL bert passes
  //   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg158", inst_base + 158*2,eth_type,port,display);
  //
  ////8. Read internal Bist error counter value (1->0) 
  //    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2,eth_type,port,display);
  //    wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 0, 0);
  //    enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val,eth_type,port,display);
  //    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2,eth_type,port,display);
  //    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 0, 0);
  //    enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val,eth_type,port,display);
  //
  ////9. Bist err count (LSB)
  //   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg153", inst_base + 153*2,eth_type,port,display);
  ////10. Bist err count (MSB)
  //   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg152", inst_base + 152*2,eth_type,port,display);
  //
  //
  //
  ////11. INject error (Write 1)
  //    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg8", inst_base + 8*2,eth_type,port,display);
  //    wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 3, 3);
  //    enet_sds_ind_csr_reg_wr("rxtx_reg8", inst_base + 8*2, wr_val,eth_type,port,display);
  ////12. INject error (Write 0)
  //    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg8", inst_base + 8*2,eth_type,port,display);
  //    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 3, 3);
  //    enet_sds_ind_csr_reg_wr("rxtx_reg8", inst_base + 8*2, wr_val,eth_type,port,display);
  //
  ////13. Read internal Bist error counter value (1->0) 
  //    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2,eth_type,port,display);
  //    wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 0, 0);
  //    enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val,eth_type,port,display);
  //    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2,eth_type,port,display);
  //    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 0, 0);
  //    enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val,eth_type,port,display);
  //
  ////14. Bist err count (LSB)
  //   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg153", inst_base + 153*2,eth_type,port,display);
  ////15. Bist err count (MSB)
  //   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg152", inst_base + 152*2,eth_type,port,display);

  return pll_ready;
  
}

