Use only one of the below xfi driver files :
--------------------------------------------

Driver File : eth_xfi_serdes_case_1.c
XFI SERDES Driver case used : CASE_1 [Finisar LR on BB2_RevC or Finisar SR on BB1_RevD]


Driver File : eth_xfi_serdes_case_2.c
XFI SERDES Driver case used : CASE_2 [Finisar SR on BB2_RevC or Finisar LR on
BB3_RevA]


Driver File : eth_xfi_serdes_case_3.c
XFI SERDES Driver case used : CASE_3 [Finisar SR on BB3_RevA - Socketed]


Driver File : eth_xfi_serdes_case_4.c
XFI SERDES Driver case used : CASE_4 [Copy of CASE_3 : This is used ONLY for debug, DONT use this file for normal testing]


