//////////////////////////////////////////////////////////////////////////////////////////
// *********************************************************************************
//file name:    xgenet_serdes.c
//create date:  1/6/2013
//author:       jufang zhang
//description:  indirectory routine to access serdes.
//              configure xgenet serdes in storm
//              This is for XFI (10 G ONly)
//////////////////////////////////////////////////////////////////////////////////////////
int pll_manualcal_xfi = 0;
int man_pvt_cal_xfi = 0;
int vco_momsel_init_xfi = 0xd;

//Added to keep in sync with eth_xg_serdes.c
int pll_manualcal = 0;
int man_pvt_cal = 0;
int vco_momsel_init_xg = 0xd;
//Added to keep in sync with eth_xg_serdes.c

#include <stdio.h>
#include <common.h>
//#include "test_util.h"
//#include "sm_enet_rsps.h"
//#include "sm_xgenet_rsps.h"
#include "eth_common.h"
#include "eth_xg_csr.h"


extern int xgenet_base_addr;

/////////////////////////////////////////////////////////////////////////////////
// SERDES config
// the xgenet (that include enet module) will have both xfi (10G) and 1G mode running at LSPLL ONLY.
// infmode: 0: SGMII(1G), 1: XGMII(10G)
// NOTE: Storm_CLock_and_Reset_EAS.pdf
// Section 3.2.4 ETH_PLL clocks: ETH_CLK sources the Serdes reference clock for both Ethernet ports.
// Therefore, configurations where one port is SGMII and the other is XFI are not supported.
////////////////////////////////////////////////////////////////////////////////
// function taken from SATA code-Satish 25/02/2013

//void  serdes_pdown_force_vco (int eth_type, int port,int display) {
void  serdes_pdown_force_vco_xfi (int eth_type, int port,int display) {
  unsigned int data32,rd_val,wr_val;
  int timeout;
  int inst_base;
  inst_base = 0x0400;
  //--------------------
  // POWER DOWN
  //--------------------

  if(display==1)
  printf (" serdes_pdown_force_vco_xfi () \n");
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg0", CMU + 2*0,eth_type,port,display);
  // FIELD_CMU_REG0_PDOWN_SET
  wr_val = sm_enet_set(rd_val, 1, 14, 14);
  enet_sds_ind_csr_reg_wr("CMU_reg0", CMU + 2*0, wr_val,eth_type,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg0", CMU + 2*0,eth_type,port,display);
  // FIELD_CMU_REG5_PLL_RESETB_SET
  wr_val = sm_enet_set(rd_val, 0, 15, 15);
  enet_sds_ind_csr_reg_wr("CMU_reg0", CMU + 2*0, wr_val,eth_type,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2, eth_type, port, display);
  // TX power down
  wr_val = sm_enet_set(rd_val, 1, 4, 4);
  enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, wr_val, eth_type, port, display);

  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg11", inst_base + 2*11, eth_type, port, display);
  // Power down RX current gen Block
  wr_val = sm_enet_set(rd_val, 1, 0, 0);
  enet_sds_ind_csr_reg_wr("rxtx_reg11", inst_base + 2*11, wr_val, eth_type, port, display);

  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg12", inst_base + 2*12, eth_type, port, display);
  // RX powerdown
  wr_val = sm_enet_set(rd_val, 1, 12, 12);
  enet_sds_ind_csr_reg_wr("rxtx_reg12", inst_base + 2*12, wr_val, eth_type, port, display);

  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2, eth_type, port, display);
  // Soft main reset
  wr_val = sm_enet_set(rd_val, 0, 15, 15);
  enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, wr_val, eth_type, port, display);

  //for(timeout=0; timeout<0x800000; ++timeout);
  USDELAY(8000);
 //--------------------
  // POWER UP
  //--------------------

  if(display==1)
  printf ("Powering up ...\n");
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg0", CMU + 2*0,eth_type,port,display);
  // FIELD_CMU_REG0_PDOWN_SET
  wr_val = sm_enet_set(rd_val, 0, 14, 14);
  enet_sds_ind_csr_reg_wr("CMU_reg0", CMU + 2*0, wr_val,eth_type,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg0", CMU + 2*0,eth_type,port,display);
  // FIELD_CMU_REG5_PLL_RESETB_SET
  wr_val = sm_enet_set(rd_val, 1, 15, 15);
  enet_sds_ind_csr_reg_wr("CMU_reg0", CMU + 2*0, wr_val,eth_type,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2, eth_type, port, display);
  // TX power down
  wr_val = sm_enet_set(rd_val, 0, 4, 4);
  enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, wr_val, eth_type, port, display);

  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg11", inst_base + 2*11, eth_type, port, display);
  // Power down RX current gen Block
  wr_val = sm_enet_set(rd_val, 0, 0, 0);
  enet_sds_ind_csr_reg_wr("rxtx_reg11", inst_base + 2*11, wr_val, eth_type, port, display);

  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg12", inst_base + 2*12, eth_type, port, display);
  // RX powerdown
  wr_val = sm_enet_set(rd_val, 0, 12, 12);
  enet_sds_ind_csr_reg_wr("rxtx_reg12", inst_base + 2*12, wr_val, eth_type, port, display);

  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2, eth_type, port, display);
  // Soft main reset
  wr_val = sm_enet_set(rd_val, 1, 15, 15);
  enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, wr_val, eth_type, port, display);

  //for(timeout=0; timeout<0x800000; ++timeout);
  USDELAY(8000);
  //--------------------
  //
  //--------------------

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg32", CMU + 2*32,eth_type,port,display);
  // FIELD_CMU_REG32_FORCE_VCOCAL_START_SET
  wr_val = sm_enet_set(rd_val, 1, 14, 14);
  enet_sds_ind_csr_reg_wr("CMU_reg32", CMU + 2*32, wr_val,eth_type,port,display);

  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg32", CMU + 2*32,eth_type,port,display);
  // FIELD_CMU_REG32_FORCE_VCOCAL_START_SET
  wr_val = sm_enet_set(rd_val, 0, 14, 14);
  enet_sds_ind_csr_reg_wr("CMU_reg32", CMU + 2*32, wr_val,eth_type,port,display);

  //for(timeout=0; timeout<0x800000; ++timeout);
  USDELAY(8000);
}


void serdes_reset_rxd_rxa_xg (int eth_type, int port, int display) {
  unsigned int  wr_val, rd_val;
  int timeout;
  int inst_base;

  inst_base = 0x0400;
  if(display==1)
  printf (" CH0 RX Reset Digital ...\n\r");
  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2, eth_type, port, display);
  wr_val = sm_enet_set(rd_val, 0, 8, 8); // digital reset == 1'b0
  enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val, eth_type, port, display);

  inst_base = 0x0400;
  if(display==1)
  printf (" CH0 RX Reset Analog ...\n\r");
  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2, eth_type, port, display);
  wr_val = sm_enet_set(rd_val, 0, 7, 7); // analog reset == 1'b0
  enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val, eth_type, port, display);

  //for(timeout=0; timeout<0x8000; ++timeout);
  USDELAY(800);
  
  inst_base = 0x0400;
  if(display==1)
  printf (" CH0 RX Remove Reset Digital ...\n\r");
  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2, eth_type, port, display);
  wr_val = sm_enet_set(rd_val, 1, 8, 8); // digital reset == 1'b1
  enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val, eth_type, port, display);

  //for(timeout=0; timeout<0x8000; ++timeout);
  USDELAY(800);

  inst_base = 0x0400;
  if(display==1)
  printf (" CH0 RX Remove Reset Analog ...\n\r");
  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2, eth_type, port, display);
  wr_val = sm_enet_set(rd_val, 1, 7, 7); // analog reset == 1'b1
  enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val, eth_type, port, display);

}

//void serdes_reset_rxd (int eth_type, int port, int display) {
void serdes_reset_rxd_xg (int eth_type, int port, int display) {
  unsigned int  wr_val, rd_val;
  int timeout;
  int inst_base;

  inst_base = 0x0400;
  if(display==1)
  printf (" CH0 RX Reset Digital ...\n\r");
  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2, eth_type, port, display);
  wr_val = sm_enet_set(rd_val, 0, 8, 8); // digital reset == 1'b0
  enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val, eth_type, port, display);

  //for(timeout=0; timeout<0x8000; ++timeout);
  USDELAY(800);

  inst_base = 0x0400;
  if(display==1)
  printf (" CH0 RX Remove Reset Digital ...\n\r");
  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2, eth_type, port, display);
  wr_val = sm_enet_set(rd_val, 1, 8, 8); // digital reset == 1'b1
  enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val, eth_type, port, display);
  //for(timeout=0; timeout<0x8000; ++timeout);
  USDELAY(800);


}

void serdes_reset_rxa_xg (int eth_type, int port, int display) {
  unsigned int  wr_val, rd_val;
  int timeout;
  int inst_base;

  inst_base = 0x0400;
  printf (" CH0 RX Reset Analog ...\n\r");
  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2, eth_type, port, display);
  wr_val = sm_enet_set(rd_val, 0, 7, 7); // analog reset == 1'b0
  enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val, eth_type, port, display);

  //for(timeout=0; timeout<0x8000; ++timeout);
  USDELAY(800);

  inst_base = 0x0400;
  printf (" CH0 RX Remove Reset Analog ...\n\r");
  rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2, eth_type, port, display);
  wr_val = sm_enet_set(rd_val, 1, 7, 7); // analog reset == 1'b1
  enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val, eth_type, port, display);

}

//void force_lat_summer_cal (int eth_type, int port, int display) {//currently used for normal 10GE compile
void force_lat_summer_cal_xg (int eth_type, int port, int display) {//To make it same as xg_serdes time being

  uint32_t inst, inst_base;
  unsigned int data32 = 0;
    int         timeout = 0;
  unsigned int  wr_val, rd_val;
  int summ_cal;
//printf ("force_lat_summer_cal() ====>  Put Lane in Tx2Rx loopback and do a force Latch and Summer calib\n\r");

    inst = 0;
    inst_base = 0x0400 + inst*0x0200;
    // ***************************
    // Enable Tx2Rx Loopback
    // ***************************
    /*data32 = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 4*2, eth_type, port, display);
    data32 = sm_enet_set(data32, 1, 6, 6);
    enet_sds_ind_csr_reg_wr("rxtx_reg4",inst_base + 4*2, data32, eth_type, port, display);
    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 7*2, eth_type, port, display);
    data32 = sm_enet_set(data32, 1, 14, 14);
    enet_sds_ind_csr_reg_wr("rxtx_reg7",inst_base + 7*2, data32, eth_type, port, display);
    for(timeout=0; timeout<0x400000; ++timeout);*/

#if 0
  //printf ("force_lat_summer_cal() =====> FORCING LATCH/SUMMER CALIBRATION\n\r");
// Enable RX Hi-Z termination enable
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg12", inst_base + 12*2,eth_type,port,display);
    wr_val = sm_enet_set(rd_val,1, 1, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg12", inst_base + 12*2, wr_val,eth_type,port,display);
   // Turn off DFE
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg28", inst_base + 28*2,eth_type,port,display);
   wr_val = sm_enet_set(rd_val, 0x0, 15, 0);
   enet_sds_ind_csr_reg_wr("rxtx_reg28", inst_base + 28*2, wr_val,eth_type,port,display);

   // DFE Presets to zero
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg31", inst_base + 31*2,eth_type,port,display);
   wr_val = sm_enet_set(rd_val, 0x0, 15, 0);
   enet_sds_ind_csr_reg_wr("rxtx_reg31", inst_base + 31*2, wr_val,eth_type,port,display);
#endif


//   // Send IDLE from Tx (set txIdle = 1)
//    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2,eth_type,port,display);
//    wr_val = sm_enet_set(rd_val, 1, 3, 3);
//    enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val,eth_type,port,display);

//   // Enable BIST
//   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2,eth_type,port,display);
//   wr_val = sm_enet_set(rd_val, 0x1, 11, 11);
//   enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, wr_val,eth_type,port,display);

// PCS PRBS enable in Tx and Rx(Monitor)
//   data32 = 0x30; // PRBS31
//   xgbaser_ind_write(0x54,data32,port,0);
//   // data32 = 0xe; // Square
//   // xgbaser_ind_write(0x54,data32,port,0);
//   // PRBS9
//   // data32 = 0x40;
//   // xgbaser_ind_write(0x54,data32,port,0);
//   // data32 = 0x4;
//   // xgbaser_ind_write(0x014008,data32,port,0);

    // ***************************
    // SUMMER CALIBRATION CH0
    // ***************************
    // SUMMer calib toggle
//    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2, eth_type, port, display);
//    data32 = sm_enet_set(data32, 1, 1, 1);
//    enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, data32, eth_type, port, display);
//    for(timeout=0; timeout<0x400000; ++timeout);
//    //------------------------------
//    // SUMMer calib toggle
//    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2, eth_type, port, display);
//    data32 = sm_enet_set(data32, 0, 1, 1);
//    enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, data32, eth_type, port, display);
//    for(timeout=0; timeout<0x400000; ++timeout);
    // Manual Summer Cal
/*    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg14", inst_base + 14*2, eth_type, port, display);
    data32 = sm_enet_set(data32, 1, 6, 6);
    if(port == 0)
      summ_cal = 0x9;
    else if(port == 3)
      summ_cal = 0xb;
    else
      summ_cal = 0xf;

    data32 = sm_enet_set(data32,summ_cal , 5, 0);
    enet_sds_ind_csr_reg_wr("rxtx_reg14",inst_base + 14*2, data32, eth_type, port, display);*/
//    for(timeout=0; timeout<0x400000; ++timeout);

   // latch calib toggle
/*
    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2, eth_type, port, display);
    data32 = sm_enet_set(data32, 1, 2, 2);
    enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, data32, eth_type, port, display);
    for(timeout=0; timeout<0x4000000; ++timeout);

    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2, eth_type, port, display);
    data32 = sm_enet_set(data32, 0, 2, 2);
    enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, data32, eth_type, port, display);
    for(timeout=0; timeout<0x4000000; ++timeout);
*/

   // SUMMer calib 1
    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2, eth_type, port, display);
    data32 = sm_enet_set(data32, 1, 1, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, data32, eth_type, port, display);
    //for(timeout=0; timeout<0x400000; ++timeout);
    USDELAY(4000);
    // SUMMer calib 0
    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2, eth_type, port, display);
    data32 = sm_enet_set(data32, 0, 1, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, data32, eth_type, port, display);
    //for(timeout=0; timeout<0x400000; ++timeout);
    USDELAY(4000);
   // Latch calib 1
    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2, eth_type, port, display);
    data32 = sm_enet_set(data32, 1, 2, 2);
    enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, data32, eth_type, port, display);
    //for(timeout=0; timeout<0x4000000; ++timeout);
    USDELAY(40000);
   // Latch calib 0
    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2, eth_type, port, display);
    data32 = sm_enet_set(data32, 0, 2, 2);
    enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, data32, eth_type, port, display);
    //for(timeout=0; timeout<0x4000000; ++timeout);
    USDELAY(40000);

   // Turn on DFE
/*   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg28", inst_base + 28*2,eth_type,port,display);
   wr_val = sm_enet_set(rd_val,0x7, 15, 0);
   enet_sds_ind_csr_reg_wr("rxtx_reg28", inst_base + 28*2, wr_val,eth_type,port,display);*/

   // DFE Presets to 0x2a00(default)
//   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg31", inst_base + 31*2,eth_type,port,display);
//   wr_val = sm_enet_set(rd_val, 0x2a00, 15, 0);
   //wr_val = sm_enet_set(rd_val, 0x2a2a, 15, 0);
//   enet_sds_ind_csr_reg_wr("rxtx_reg31", inst_base + 31*2, wr_val,eth_type,port,display);

    // ***************************
    // Disable Tx2Rx Loopback
    // ***************************
/*    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 4*2, eth_type, port, display);
    data32 = sm_enet_set(data32, 0, 6, 6);
    enet_sds_ind_csr_reg_wr("rxtx_reg4",inst_base + 4*2, data32, eth_type, port, display);
    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 7*2, eth_type, port, display);
    data32 = sm_enet_set(data32, 0, 14, 14);
    enet_sds_ind_csr_reg_wr("rxtx_reg7",inst_base + 7*2, data32, eth_type, port, display);
    for(timeout=0; timeout<0x400000; ++timeout);*/

//   // Remove IDLE from Tx (set txIdle = 1)
//    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2,eth_type,port,display);
//    wr_val = sm_enet_set(rd_val, 0, 3, 3);
//    enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val,eth_type,port,display);

//   // Remove BIST
//   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2,eth_type,port,display);
//   wr_val = sm_enet_set(rd_val, 0x0, 11, 11);
//   enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, wr_val,eth_type,port,display);

// PCS PRBS enable in Tx and Rx(Monitor)
//   //data32 = xgbaser_ind_read(0x54,port,0);
//   data32 = 0x0;
//   xgbaser_ind_write(0x54,data32,port,0);
//   data32 = 0x0;
//   xgbaser_ind_write(0x014008,data32,port,0);


/*
    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg121", inst_base + 121*2, eth_type, port, display);
    printf("********1. DEBUG************\n");
    printf("********1. DEBUG************ ====> CH0_RXTX_REG121 = %x \n", (data32>>1));
    printf("********1. DEBUG************\n");


  serdes_reset_rxd_rxa_xg(XGENET,port,0);

  for(timeout=0; timeout<0x400000; ++timeout);
  xgbaser_ind_write(SM_XGENET_XGBASER_PCS_PCS_CONTROL_1__ADDR,0xa640,port,1);
  for(timeout=0; timeout<0x400000; ++timeout);
  xgbaser_ind_write(SM_XGENET_XGBASER_PCS_PCS_CONTROL_1__ADDR,0x2640,port,1);
*/

#if 0
   // Turn on DFE
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg28", inst_base + 28*2,eth_type,port,display);
   wr_val = sm_enet_set(rd_val,0x7, 15, 0);
   enet_sds_ind_csr_reg_wr("rxtx_reg28", inst_base + 28*2, wr_val,eth_type,port,display);
   // DFE Presets to 0x2a00(default)
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg31", inst_base + 31*2,eth_type,port,display);
   wr_val = sm_enet_set(rd_val, 0x2a00, 15, 0);
   enet_sds_ind_csr_reg_wr("rxtx_reg31", inst_base + 31*2, wr_val,eth_type,port,display);
   // Disable RX Hi-Z termination enable
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg12", inst_base + 12*2,eth_type,port,display);
   wr_val = sm_enet_set(rd_val,0, 1, 1);
   enet_sds_ind_csr_reg_wr("rxtx_reg12", inst_base + 12*2, wr_val,eth_type,port,display);
   for(timeout=0;timeout<1000000;timeout++);
   data32 = enet_sds_ind_csr_reg_rd("rxtx_reg121", inst_base + 121*2, eth_type, port, display);
#endif


}

/*
void force_lat_summer_cal_poly (int eth_type, int port, int display) {

  uint32_t inst, inst_base;
  unsigned int data32 = 0;
    int         timeout = 0;
  unsigned int  wr_val, rd_val;
  int summ_cal;
    inst = 0;
    inst_base = 0x0400 + inst*0x0200;*/

// Enable RX Hi-Z termination enable
/*    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg12", inst_base + 12*2,eth_type,port,display);
    wr_val = sm_enet_set(rd_val,1, 1, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg12", inst_base + 12*2, wr_val,eth_type,port,display);
    for(timeout=0;timeout<1000000;timeout++);*/

// SUMMer calib toggle
/*    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2, eth_type, port, display);
    data32 = sm_enet_set(data32, 1, 1, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, data32, eth_type, port, display);
    for(timeout=0; timeout<0x400000; ++timeout);
    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2, eth_type, port, display);
    data32 = sm_enet_set(data32, 0, 1, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, data32, eth_type, port, display);
    for(timeout=0; timeout<0x400000; ++timeout);*/

// Latch calib toggle
/*    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2, eth_type, port, display);
    data32 = sm_enet_set(data32, 1, 2, 2);
    enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, data32, eth_type, port, display);
    for(timeout=0; timeout<0x4000000; ++timeout);
    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2, eth_type, port, display);
    data32 = sm_enet_set(data32, 0, 2, 2);
    enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 127*2, data32, eth_type, port, display);
    for(timeout=0; timeout<0x4000000; ++timeout);

    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg121", inst_base + 121*2, eth_type, port, display);
    printf("********1. DEBUG************\n");
    printf("********1. DEBUG************ ====> CH0_RXTX_REG121 = %x \n", (data32>>1));
    printf("********1. DEBUG************\n");*/

// Disable RX Hi-Z termination enable
/*   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg12", inst_base + 12*2,eth_type,port,display);
   wr_val = sm_enet_set(rd_val,0, 1, 1);
   enet_sds_ind_csr_reg_wr("rxtx_reg12", inst_base + 12*2, wr_val,eth_type,port,display);
   for(timeout=0;timeout<1000000;timeout++);

  xgbaser_ind_write(SM_XGENET_XGBASER_PCS_PCS_CONTROL_1__ADDR,0xa640,port,1);
  for(timeout=0; timeout<0x400000; ++timeout);
  xgbaser_ind_write(SM_XGENET_XGBASER_PCS_PCS_CONTROL_1__ADDR,0x2640,port,1);
}
*/



void serdes_calib_xg(int infmode, int eth_type, int port, int display){
  unsigned int data32, timeout, rd_val, wr_val; 
  int inst_base;
  
//  if(infmode){
    // Added by Poly Jan 29th 2013
    /////////////
    // CMU_reg6  : Enable Manual PVT calibration
//    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg6", CMU + 2*6,eth_type,port,display);
//    wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 2, 2);
//    enet_sds_ind_csr_reg_wr("CMU_reg6", CMU + 2*6, wr_val,eth_type,port,display);
    // CMU_reg18   : channel sel
//    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg18", CMU + 2*18,eth_type,port,display);
//    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 3, 0);
//    enet_sds_ind_csr_reg_wr("CMU_reg18", CMU + 2*18, wr_val,eth_type,port,display);
    // CMU_reg17  : Binary coded pull up/dn and term compensation 
    //              bus for manual code entry,manual programming
//    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17,eth_type,port,display);
//    wr_val = sm_enet_set(rd_val,infmode ? 38 : 38, 14, 8);
//    enet_sds_ind_csr_reg_wr("CMU_reg17", CMU + 2*17, wr_val,eth_type,port,display);
    // CMU_reg16  : Enable pull up calibration manual mode  WRITE=1
//    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
//    wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 1, 1);
//    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);
    // CMU_reg16  : Enable pull up calibration manual mode  WRITE=1
//    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
//    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 1, 1);
//    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);
//  }
//  else{ 
    if(display==1)
    printf("\nPVT Calibration mode set to %s \n", man_pvt_cal_xfi ? "MANUAL" : "AUTOMATIC");
    // CMU_reg6  : Enable Manual PVT calibration - Anil
    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg6", CMU + 2*6,eth_type,port,display);
//    wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 2, 2);
    wr_val = sm_enet_set(rd_val,infmode ? man_pvt_cal_xfi : man_pvt_cal_xfi, 2, 2);//24-Jul
    enet_sds_ind_csr_reg_wr("CMU_reg6", CMU + 2*6, wr_val,eth_type,port,display);

    // TERM CALIBRATION KC_SERDES_CMU_REGS_CMU_REG17__ADDR
    data32 = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17, eth_type, port, display);
    data32 &= ~(0x7F << 8);
//    data32 |= 0x0D << 8;
    data32 |= 0x12 << 8;//As per Poly's mail dated 22-Oct-2013
//    data32 &= ~(3 << 5);
    data32 &= ~(7 << 5);//24-Jul
    enet_sds_ind_csr_reg_wr("CMU_reg17", CMU + 2*17, data32, eth_type, port, display);
    data32 = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17, eth_type, port, display);

    data32 = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17, eth_type, port, display);
    data32 |= 1 << 15;
    enet_sds_ind_csr_reg_wr("CMU_reg17", CMU + 2*17, data32, eth_type, port, display);
    data32 = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17, eth_type, port, display);
 
    data32 = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17, eth_type, port, display);
    data32 &= ~(1 << 15);
    enet_sds_ind_csr_reg_wr("CMU_reg17", CMU + 2*17, data32, eth_type, port, display);
    data32 = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17, eth_type, port, display);

    // DOWN CALIBRATION
    data32 = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17, eth_type, port, display);
    data32 &= ~(0x7F << 8);
//    data32 |= 0x26 << 8;
//    data32 &= ~(3 << 5);
    data32 |= 0x2A << 8; // 07/31/2013
    data32 &= ~(7 << 5);//24-Jul
    enet_sds_ind_csr_reg_wr("CMU_reg17", CMU + 2*17, data32, eth_type, port, display);
    data32 = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17, eth_type, port, display);

    data32 = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16, eth_type, port, display);
    data32 |= 1;
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, data32, eth_type, port, display);
    data32 = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16, eth_type, port, display);

    data32 = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16, eth_type, port, display);
    data32 &= ~1;
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, data32, eth_type, port, display);
    data32 = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16, eth_type, port, display);
 
    // UP CALIBRATION
    data32 = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17, eth_type, port, display);
    data32 &= ~(0x7F << 8);
//    data32 |= 0x27 << 8;
//    data32 |= 0x28 << 8;//24-Jul
//    data32 &= ~(3 << 5);
    data32 |= 0x2B << 8; // 07/31/2013
    data32 &= ~(7 << 5);//24-Jul
    enet_sds_ind_csr_reg_wr("CMU_reg17", CMU + 2*17, data32, eth_type, port, display);
    data32 = enet_sds_ind_csr_reg_rd("CMU_reg17", CMU + 2*17, eth_type, port, display);

    data32 = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16, eth_type, port, display);
    data32 |= (1 << 1);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, data32, eth_type, port, display);
    data32 = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16, eth_type, port, display);

    data32 = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16, eth_type, port, display);
    data32 &= ~(1 << 1);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, data32, eth_type, port, display);
    data32 = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16, eth_type, port, display);

    ////////////////////////////////////////////////////////////////////////////////
    // Anil adding 5-2-2013
    //// STARTED/////
    //  printf ("ANIL ADDING THIS CODE .....\n\r");
    inst_base = 0x0400;
    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg14", inst_base + 14*2, eth_type, port, display);
    data32 &= ~0x7F;  // mask
//    data32 |= 0x4E; //Anil 02/08/13
    data32 |= 0x0E; //Anil 02/08/13  //24-Jul
    enet_sds_ind_csr_reg_wr("rxtx_reg14",inst_base + 14*2, data32, eth_type, port, display);

    // force_lat_cal_start CH0
/*  //Removed in 24-Jul
    inst_base = 0x0400;
    data32 = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2, eth_type, port, display);
    data32 &= ~0x4;
    data32 |= 0x4;
    enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 14*2, data32, eth_type, port, display);
    data32 &= ~0x4;
    enet_sds_ind_csr_reg_wr("rxtx_reg127",inst_base + 14*2, data32, eth_type, port, display);
*/

//  } //End of 'else' part
 
  //for(timeout=0; timeout<0x8000; ++timeout);	//Anil 020813
  USDELAY(800);
}

void sm_xgenet_module_program_all_regs(uint32_t infmode,int eth_type, int port, int display) {
  uint32_t wr_val, rd_val, inst, inst_base;

  xgenet_sds_CMU_cfg(infmode, eth_type, port, display);
  xgenet_sds_rxtx_cfg(infmode, eth_type, port, display);
  return;
}

void xgenet_sds_CMU_cfg(uint32_t infmode,int eth_type, int port, int display) {
  uint32_t wr_val, rd_val, inst, inst_base, internal_ref_clk;

  //////////////////////////
  // LSPLL Controls
  /////////////
  internal_ref_clk = 0;

  if(internal_ref_clk){
    printf(" ***** CMU_REG1[0]= 0 selects Internal REFCLK ****** \n");
    //CMU_reg1
    rd_val =  enet_sds_ind_csr_reg_rd("CMU_reg1", CMU + 2*1,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 1, 0, 0);
    enet_sds_ind_csr_reg_wr("CMU_reg1", CMU + 2*1, wr_val,eth_type,port,display);
   
    // CMU_reg12, nnguyen added
    rd_val =  enet_sds_ind_csr_reg_rd("CMU_reg12", CMU + 2*12,eth_type,port,display);
    wr_val = sm_enet_set(rd_val,infmode ? 3 : 7, 7, 4); // State_delay9 Check with Anil
    enet_sds_ind_csr_reg_wr("CMU_reg12", CMU + 2*12, wr_val,eth_type,port,display);
  }
  else{
    if(display==1)
    printf(" ***** CMU_REG1[0]= 0 selects Ext REFCLK ****** \n");  // POLY PLEASE DONT CHANGE THIS
    //CMU_reg1
    rd_val =  enet_sds_ind_csr_reg_rd("CMU_reg1", CMU + 2*1,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 0, 0, 0);
    enet_sds_ind_csr_reg_wr("CMU_reg1", CMU + 2*1, wr_val,eth_type,port,display);
  }

  // CMU_reg2
  rd_val =  enet_sds_ind_csr_reg_rd("CMU_reg2", CMU + 2*2,eth_type,port,display);
  // Ref clk divider setting
  wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 15, 14);
  // Feedback divider setting
  wr_val = sm_enet_set(wr_val,infmode ? 32 : 49, 13, 5);
  enet_sds_ind_csr_reg_wr("CMU_reg2", CMU + 2*2, wr_val,eth_type,port,display);


  /////////////
  // CMU_reg9
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg9", CMU + 2*9,eth_type,port,display);
  // Post Divider
  wr_val = sm_enet_set(rd_val,infmode ? 0 : 1, 3, 3);
  // Word mode for PClk
  wr_val = sm_enet_set(wr_val,infmode ? 6 : 1, 6, 4);
  enet_sds_ind_csr_reg_wr("CMU_reg9", CMU + 2*9, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg1
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg1", CMU + 2*1,eth_type,port,display);
  // PLL BW setting
  // wr_val = sm_enet_set(rd_val,infmode ? 7 : 11, 13, 10); // xls
  wr_val = sm_enet_set(rd_val,infmode ? 11 : 11, 13, 10); // Anil
  // CP SEL
  //wr_val = sm_enet_set(wr_val,infmode ? 2 : 2, 9, 5); // xls
  //wr_val = sm_enet_set(wr_val,infmode ? 2 : 1, 9, 5); // Anil
  wr_val = sm_enet_set(wr_val,5, 9, 5); // Anil 07/31/2013
  enet_sds_ind_csr_reg_wr("CMU_reg1", CMU + 2*1, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg3
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg3", CMU + 2*3,eth_type,port,display);
  // PLL BW setting
//  wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 3, 0);
  wr_val = sm_enet_set(rd_val,15, 3, 0);  // Anil 07/31/2013
  enet_sds_ind_csr_reg_wr("CMU_reg3", CMU + 2*3, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg2
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg2", CMU + 2*2,eth_type,port,display);
  // LF_RES
  //wr_val = sm_enet_set(rd_val,infmode ? 7 : 7, 4, 1); // xls
//  wr_val = sm_enet_set(rd_val,infmode ? 7 : 15, 4, 1); // xls
  wr_val = sm_enet_set(rd_val,5, 4, 1); // Anil 07/31/2013
  enet_sds_ind_csr_reg_wr("CMU_reg2", CMU + 2*2, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg5
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg5", CMU + 2*5,eth_type,port,display);
  // PLL BW setting
  //wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 15, 14); // xls
  wr_val = sm_enet_set(rd_val,infmode ? 0 : 3, 15, 14); // Anil
  // PLL BW setting
  //wr_val = sm_enet_set(wr_val,infmode ? 0 : 0, 13, 12); // xls
  wr_val = sm_enet_set(wr_val,infmode ? 0 : 3, 13, 12); // Anil
  wr_val = sm_enet_set(wr_val,infmode ? 4 : 7, 3, 1); // pll_lock_resolution. Provided by Anil
  enet_sds_ind_csr_reg_wr("CMU_reg5", CMU + 2*5, wr_val,eth_type,port,display);
   
/*                                                                                         
  /////////////
  // CMU_reg4
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg4", CMU + 2*4,eth_type,port,display);
  // PLL BW setting for PCIE
  wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 3, 0);
  enet_sds_ind_csr_reg_wr("CMU_reg4", CMU + 2*4, wr_val,eth_type,port,display);
*/

  /////////////
  // CMU_reg8
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg8", CMU + 2*8,eth_type,port,display);
  wr_val = sm_enet_set(rd_val,infmode ? 7 : 7, 7, 5); // ucdiv. added by satish for correct usr clock - 01 Feb
  wr_val = sm_enet_set(wr_val, infmode ? 0 : 0xAA, 15, 8); // tx_data_rate_ch3,2,1,0 = 2'h0 or 2'h2
  enet_sds_ind_csr_reg_wr("CMU_reg8", CMU + 2*8, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg6
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg6", CMU + 2*6,eth_type,port,display);
  wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 10, 9); // pll_vregtrim
  wr_val = sm_enet_set(wr_val,infmode ? 1 : 0, 3, 3); // Added by Satish to enable user clock in xgmii mode
  enet_sds_ind_csr_reg_wr("CMU_reg6", CMU + 2*6, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg32
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg32", CMU + 2*32,eth_type,port,display);
  // Bias Current adj
  wr_val = sm_enet_set(rd_val,infmode ? 3 : 3, 8, 7);
  enet_sds_ind_csr_reg_wr("CMU_reg32", CMU + 2*32, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg1
  if(display==1)
  printf("\nCalibration mode set to %s \n", pll_manualcal_xfi ? "MANUAL" : "AUTOMATIC");
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg1", CMU + 2*1,eth_type,port,display);
  // Manual cal enable
//  wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 3, 3);
  wr_val = sm_enet_set(rd_val,infmode ? pll_manualcal_xfi : pll_manualcal_xfi, 3, 3);//24-Jul
  enet_sds_ind_csr_reg_wr("CMU_reg1", CMU + 2*1, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg3
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg3", CMU + 2*3,eth_type,port,display);
  // Manual cal value
  //wr_val = sm_enet_set(rd_val,infmode ? 5 : 25, 15, 10); // xls
  wr_val = sm_enet_set(rd_val,infmode ? 5 : 28, 15, 10); // Anil
  // Init Momsel
  wr_val = sm_enet_set(wr_val,infmode ? 16 : 16, 9, 4);
  enet_sds_ind_csr_reg_wr("CMU_reg3", CMU + 2*3, wr_val,eth_type,port,display);

/*
  /////////////
  // CMU_reg4
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg4", CMU + 2*4,eth_type,port,display);
  // Manual cal value for PCIE - don't care
  // Init Momsel Fro 8G
  wr_val = sm_enet_set(rd_val,infmode ? 16 : 16, 9, 4);
  enet_sds_ind_csr_reg_wr("CMU_reg4", CMU + 2*4, wr_val,eth_type,port,display);
*/

  /////////////
  // CMU_reg34
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg34", CMU + 2*34,eth_type,port,display);
  // Threshold setting for VCO cal
  wr_val = sm_enet_set(rd_val,infmode ? 2 : 2, 15, 12);
  // Threshold setting for VCO cal
  wr_val = sm_enet_set(wr_val,infmode ? 10 : 10, 11, 8);
  // Threshold setting for VCO cal
  wr_val = sm_enet_set(wr_val,infmode ? 2 : 2, 7, 4);
  // Threshold setting for VCO cal
  wr_val = sm_enet_set(wr_val,infmode ? 10 : 10, 3, 0);
  enet_sds_ind_csr_reg_wr("CMU_reg34", CMU + 2*34, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg0
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg0", CMU + 2*0,eth_type,port,display);
  // Pll lock calibration resolution
  wr_val = sm_enet_set(rd_val,infmode ? 7 : 7, 7, 5);
  enet_sds_ind_csr_reg_wr("CMU_reg0", CMU + 2*0, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg16
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
  // VCO Calib wait time
  wr_val = sm_enet_set(rd_val,infmode ? 7 : 7, 4, 2);
  enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg30
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg30", CMU + 2*30,eth_type,port,display);
  // Lock count Wait time
  wr_val = sm_enet_set(rd_val,infmode ? 3 : 3, 2, 1);
  enet_sds_ind_csr_reg_wr("CMU_reg30", CMU + 2*30, wr_val,eth_type,port,display);
 
  /////////////
  // CMU_reg13
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg13", CMU + 2*13,eth_type,port,display);
  // Delay time between state transition.
  wr_val = sm_enet_set(rd_val,infmode ? 15 : 15, 15, 12);
  // Delay time between state transition.
  wr_val = sm_enet_set(wr_val,infmode ? 15 : 15, 11, 8);
  // Delay time between state transition.
  wr_val = sm_enet_set(wr_val,infmode ? 15 : 15, 7, 4);
  // Delay time between state transition.
  wr_val = sm_enet_set(wr_val,infmode ? 15 : 15, 3, 0);
  enet_sds_ind_csr_reg_wr("CMU_reg13", CMU + 2*13, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg14
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg14", CMU + 2*14,eth_type,port,display);
  // Delay time between state transition.
  wr_val = sm_enet_set(rd_val,infmode ? 15 : 15, 15, 12);
  // Delay time between state transition.
  wr_val = sm_enet_set(wr_val,infmode ? 15 : 15, 11, 8);
  // Delay time between state transition.
  wr_val = sm_enet_set(wr_val,infmode ? 15 : 15, 7, 4);
  // Delay time between state transition.
  wr_val = sm_enet_set(wr_val,infmode ? 15 : 15, 3, 0);
  enet_sds_ind_csr_reg_wr("CMU_reg14", CMU + 2*14, wr_val,eth_type,port,display);
                                               
  /////////////
  // CMU_reg30
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg30", CMU + 2*30,eth_type,port,display);
  // PCIE mode enable
  wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 3, 3);
  // Ref Divider for PCI Gen3 mode - dont care
  // FB divider for Gen3 mode - dont care
  // Post Divider for Gen3 mode - dont care
  enet_sds_ind_csr_reg_wr("CMU_reg30", CMU + 2*30, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg0
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg0", CMU + 2*0,eth_type,port,display);
  // PCIE gen3 , driven by Pipe
  wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 0, 0);
  enet_sds_ind_csr_reg_wr("CMU_reg0", CMU + 2*0, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg32
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg32", CMU + 2*32,eth_type,port,display);
  // PVT Calibration Wait time
  wr_val = sm_enet_set(rd_val,infmode ? 3 : 3, 2, 1);
  enet_sds_ind_csr_reg_wr("CMU_reg32", CMU + 2*32, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg31
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg31", CMU + 2*31,eth_type,port,display);
  // LOS override for State machine
  wr_val = sm_enet_set(rd_val,infmode ? 15 : 15, 3, 0);
  enet_sds_ind_csr_reg_wr("CMU_reg31", CMU + 2*31, wr_val,eth_type,port,display);

  /////////////
  // CMU_reg37
  rd_val = enet_sds_ind_csr_reg_rd("CMU_reg37", CMU + 2*37,eth_type,port,display);
  // CTLE Calibration Done state Override
  wr_val = sm_enet_set(rd_val,infmode ? 15 : 15, 15, 12);
  // FT tap search done Override.
  wr_val = sm_enet_set(wr_val,infmode ? 15 : 15, 3, 0);
  enet_sds_ind_csr_reg_wr("CMU_reg37", CMU + 2*37, wr_val,eth_type,port,display);
   ///////////////////////////////////

}

void xgenet_sds_rxtx_cfg(uint32_t infmode,int eth_type, int port, int display) {
  uint32_t wr_val, rd_val, inst, inst_base;
  uint32_t ctle_full_rate;

  int tx_amplitude , ctle_eq , cn1 , cp1 , cn2 ;

   for(inst = 0;inst < 1;inst++) {
   inst_base = 0x0400 + 0x200*inst;

   ///////////////////////////////////
   // Tx CONTROL
   ///////////////
     //rxtx_reg4
     rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 4*2,eth_type,port,display);
     // TX rate Setting
     wr_val = sm_enet_set(rd_val,infmode ? 0 : 2, 15, 14);
     // TX word mode setting
     wr_val = sm_enet_set(wr_val,infmode ? 6 : 1, 13, 11);
     // PRBS Select
     wr_val = sm_enet_set(wr_val,infmode ? 4 : 4, 10, 8);
     enet_sds_ind_csr_reg_wr("rxtx_reg4",inst_base + 4*2, wr_val,eth_type,port,display);

    /////////////
    // CMU_reg16
    // TX Rate Change enable: Toggle 0-1-0
    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU +2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 0, 15, 15);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 1, 15, 15);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val,0, 15, 15);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU +2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 0, 13, 13);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 1, 13, 13);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val,0, 13, 13);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU +2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 0, 11, 11);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 1, 11, 11);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val,0, 11, 11);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU +2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 0, 9, 9);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val, 1, 9, 9);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

    rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
    wr_val = sm_enet_set(rd_val,0, 9, 9);
    enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

     /////////////
     // rxtx_reg2
     rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2,eth_type,port,display);
     // Fifo Mode enable
     wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 5, 5);
     enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, wr_val,eth_type,port,display);

     /////////////
     // rxtx_reg6
     rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2,eth_type,port,display);
     // TX output amplitude enable
     wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 6, 6);
     // TX Amplitude control
//     wr_val = sm_enet_set(wr_val,infmode ? 8 : 8, 10, 7); // Anil
/*     if(port == 2 ) //25-Jul
       wr_val = sm_enet_set(wr_val,infmode ? 0 : 0, 10, 7); // chidvilas 7/25 : To remove coupling on TxRx as the traces aretoo close.
     else   //25-Jul
       wr_val = sm_enet_set(wr_val,infmode ? 8 : 8, 10, 7); // chidvilas 7/25
*/
     //wr_val = sm_enet_set(wr_val,15, 10, 7); // ANil 07/31/2013 // -- ORIGINAL CODE --
     
     #if 1
     if(port == 0) {
       //printf("\nEnter Tx_Amplitude for XGE-0 (0x0 - 0xf) : 0x"); tx_amplitude = get_val();
       //printf("\t(You entered 0x%x)\n",tx_amplitude);
       tx_amplitude = 15;
     }
     else tx_amplitude = 15;
     wr_val = sm_enet_set(wr_val, tx_amplitude , 10, 7); // Hrishikesh 03-Jul-2014 // For Socketed BB3 Board
     #endif

     enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val,eth_type,port,display);

     /////////////
     // rxtx_reg5
     rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg5", inst_base + 5*2,eth_type,port,display);
     // TX FIR pre cursor CN1
     //wr_val = sm_enet_set(rd_val,infmode ? 6 : 6, 15, 11); // xls
     //wr_val = sm_enet_set(rd_val,infmode ? 6 : 0, 15, 11); // Anil
     //wr_val = sm_enet_set(rd_val,2, 15, 11); // -- ORIGINAL CODE --
     #if 1
     if(port == 0) {
	//printf("\nEnter CN1 for XGE-0 : 0x"); cn1 = get_val();
	//printf("\t(You entered %d)\n",cn1);
	cn1 = 2;
	}
     else cn1 = 2;
     wr_val = sm_enet_set(rd_val,cn1, 15, 11); // -- TEMP
     #endif
     // TX FIR post Cursor CP1
    //wr_val = sm_enet_set(wr_val,infmode ? 6 : 6, 10, 5); // xls
    //wr_val = sm_enet_set(wr_val,infmode ? 6 : 0, 10, 5); // Anil
    //wr_val = sm_enet_set(wr_val,15, 10, 5); // -- ORIGINAL CODE --
     #if 1
     if(port == 0) {
	//printf("\nEnter CP1 for XGE-0 : 0x"); cp1 = get_val();
	//printf("\t(You entered %d)\n",cp1);
	cp1 = 15;
	}
     else cp1 = 15;
     wr_val = sm_enet_set(rd_val,cp1, 10, 5); // -- TEMP
     #endif
     // TX FIR pre 2 Cursor CN2
     //wr_val = sm_enet_set(wr_val,infmode ? 0 : 0, 4, 0);
     //wr_val = sm_enet_set(wr_val,2, 4, 0); // -- ORIGINAL CODE --
     #if 1
     if(port == 0) {
	//printf("\nEnter CN2 for XGE-0 : 0x"); cn2 = get_val();
	//printf("\t(You entered %d)\n",cn2);
	cn2 = 2;
	}
     else cn2 = 2;
     wr_val = sm_enet_set(rd_val,cn2, 4, 0); // -- TEMP
     #endif
     enet_sds_ind_csr_reg_wr("rxtx_reg5", inst_base + 5*2, wr_val,eth_type,port,display);
                      
     /////////////
     // rxtx_reg61 - Don't Care

    /////////////
    // rxtx_reg2
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2,eth_type,port,display);
    // TX Resetn
    wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 12, 12);
    enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, wr_val,eth_type,port,display);
    
    /////////////
    // rxtx_reg4
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 4*2,eth_type,port,display);
    // TX Forward Loopback enable
    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 6, 6);
    enet_sds_ind_csr_reg_wr("rxtx_reg4", inst_base + 4*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg2
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2,eth_type,port,display);
    // TX Bist enable for PRBS transfer
    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 11, 11);
    enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg6
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2,eth_type,port,display);
    // TX Idle Control
    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 3, 3);
    enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg145
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg145", inst_base + 145*2,eth_type,port,display);
    // TX Idle Control
    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 0, 0);
    enet_sds_ind_csr_reg_wr("rxtx_reg145", inst_base + 145*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg2
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2,eth_type,port,display);
    // TX Serial Data swap
    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 10, 10);
    enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, wr_val,eth_type,port,display);

    //////////////////////////
    // RX Control
    /////////////
    // rxtx_reg2
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2,eth_type,port,display);
    // RX termination Reset
    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 14, 14);
    // RX Termination voltage setting enable
    wr_val = sm_enet_set(wr_val,infmode ? 1 : 1, 8, 8);
    // RX Termination voltage setting Select
    wr_val = sm_enet_set(wr_val,infmode ? 1 : 1, 7, 6);
    enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg1
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg1", inst_base + 1*2,eth_type,port,display);
    
    // RX AC common model select
    wr_val = sm_enet_set(rd_val,infmode ? 7 : 7, 15, 12);
    // RXIREF_ADJ
    //wr_val = sm_enet_set(rd_val,3, 4, 1);   // Added 07/31/2013
    wr_val = sm_enet_set(wr_val,3, 4, 1);   // Added 07/31/2013
    if(port == 3) wr_val = sm_enet_set(wr_val,1, 4, 1);   // Added 07/31/2013

    enet_sds_ind_csr_reg_wr("rxtx_reg1", inst_base + 1*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg12
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg12", inst_base + 12*2,eth_type,port,display);
    // RX Hi-Z termination enable
    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 1, 1);
    enet_sds_ind_csr_reg_wr("rxtx_reg12", inst_base + 12*2, wr_val,eth_type,port,display);

    /////////////
    // rxtx_reg61 - Don't care

    /////////////
    // rxtx_reg7
    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 7*2,eth_type,port,display);
    // RX PRBS Select
    wr_val = sm_enet_set(rd_val,infmode ? 4 : 4, 5, 3);
    // RX Word Mode
    wr_val = sm_enet_set(wr_val,infmode ? 6 : 1, 13, 11);
    // RX Data rate select
    wr_val = sm_enet_set(wr_val,infmode ? 0 : 2, 10, 9);
    enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 7*2, wr_val,eth_type,port,display);
                                                                           
   
   /////////////
   // CMU_reg16
   // RX rate change enable: Toggle 0-1-0
   rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
   wr_val = sm_enet_set(rd_val, 0, 14, 14);
   enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

   rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
   wr_val = sm_enet_set(rd_val, 1, 14, 14);
   enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

   rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
   wr_val = sm_enet_set(rd_val, 0, 14, 14);
   enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

   rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
   wr_val = sm_enet_set(rd_val, 0, 12, 12);
   enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

   rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
   wr_val = sm_enet_set(rd_val, 1, 12, 12);
   enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

   rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
   wr_val = sm_enet_set(rd_val, 0, 12, 12);
   enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

   rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
   wr_val = sm_enet_set(rd_val, 0, 10, 10);
   enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

   rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
   wr_val = sm_enet_set(rd_val, 1, 10, 10);
   enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

   rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
   wr_val = sm_enet_set(rd_val, 0, 10, 10);
   enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

   rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
   wr_val = sm_enet_set(rd_val, 0, 8, 8);
   enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

   rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
   wr_val = sm_enet_set(rd_val, 1, 8, 8);
   enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

   rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);
   wr_val = sm_enet_set(rd_val, 0, 8, 8);
   enet_sds_ind_csr_reg_wr("CMU_reg16", CMU + 2*16, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg148
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg148", inst_base + 148*2,eth_type,port,display);
   // BISt Word Count
   wr_val = sm_enet_set(rd_val,infmode ? 0xFFFF : 0xFFFF, 15, 0);
   enet_sds_ind_csr_reg_wr("rxtx_reg148", inst_base + 148*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg149
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg149", inst_base + 149*2,eth_type,port,display);
   // BISt Word Count
   wr_val = sm_enet_set(rd_val,infmode ? 0xFFFF : 0xFFFF, 15, 0);
   enet_sds_ind_csr_reg_wr("rxtx_reg149", inst_base + 149*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg150
   rd_val =  enet_sds_ind_csr_reg_rd("rxtx_reg150", inst_base + 150*2,eth_type,port,display);
   // BISt Word Count
   wr_val = sm_enet_set(rd_val,infmode ? 0xFFFF : 0xFFFF, 15, 0);
   enet_sds_ind_csr_reg_wr("rxtx_reg150", inst_base + 150*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg151
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg151", inst_base + 151*2,eth_type,port,display);
   // BISt Word Count
   wr_val = sm_enet_set(rd_val,infmode ? 0xFFFF : 0xFFFF, 15, 0);
   enet_sds_ind_csr_reg_wr("rxtx_reg151", inst_base + 151*2, wr_val,eth_type,port,display);

   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg147", inst_base + 147*2,eth_type,port,display);
   // State Machine Override controls
   wr_val = sm_enet_set(rd_val,infmode ? 6 : 6, 15, 0);
   enet_sds_ind_csr_reg_wr("rxtx_reg147", inst_base + 147*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg1
   rd_val =  enet_sds_ind_csr_reg_rd("rxtx_reg1", inst_base + 1*2,eth_type,port,display);
   // CTLE Full rate Control
#if 0	// CTLE_EQ ac_gain=4, dc_gain=0
      if(port == 0) wr_val = sm_enet_set(rd_val,infmode ? 16 : 16, 11, 7);
      if(port == 1) wr_val = sm_enet_set(rd_val,infmode ? 16 : 16, 11, 7);
      if(port == 2) wr_val = sm_enet_set(rd_val,infmode ? 16 : 16, 11, 7);
      if(port == 3) wr_val = sm_enet_set(rd_val,infmode ? 16 : 16, 11, 7);
#endif
#if 1	// CTLE_EQ ac_gain=4, dc_gain=1 // This was introduced around 17-Sep-2014 as per discussions with Jitu
      if(port == 0) wr_val = sm_enet_set(rd_val,infmode ? 17 : 17, 11, 7);
      if(port == 1) wr_val = sm_enet_set(rd_val,infmode ? 17 : 17, 11, 7);
      if(port == 2) wr_val = sm_enet_set(rd_val,infmode ? 17 : 17, 11, 7);
      if(port == 3) wr_val = sm_enet_set(rd_val,infmode ? 17 : 17, 11, 7);
#endif
		    #if 0
		    {
			printf("\nEnter CTLE_EQ val for XGE-%d : 0x",port); ctle_eq = get_val();
			printf("\t(You entered %d)\n",ctle_eq);
			//ctle_eq = 16;
			wr_val = sm_enet_set(rd_val,infmode ? ctle_eq : 16, 11, 7);
		    }
		    #endif

   int xge_phys = 0; 
 	if (((xgenet_base_addr & 0x00100000)>> 20) == 0x1) {xge_phys = 0;} 
 	else                                               {xge_phys = 1;}
   if (xge_phys==0 && inst_base==0) { wr_val = sm_enet_set(rd_val,infmode ? 24 : 24, 11, 7);} // PORT0 
   if (xge_phys==0 && inst_base==1) { wr_val = sm_enet_set(rd_val,infmode ? 28 : 28, 11, 7);} // PORT1
   if (xge_phys==1 && inst_base==0) { wr_val = sm_enet_set(rd_val,infmode ? 16 : 16, 11, 7);} // PORT2
   if (xge_phys==1 && inst_base==1) { wr_val = sm_enet_set(rd_val,infmode ? 28 : 18, 11, 7);} // PORT3

//Added by Hrishikesh
/*
    if(port == 2)
      wr_val = 0x7200;
    if(port == 3)
      wr_val = 0x7200;
*/
//Added by Hrishikesh


   enet_sds_ind_csr_reg_wr("rxtx_reg1", inst_base + 1*2, wr_val,eth_type,port,display);

//Added by Hrishikesh
//   rd_val =  enet_sds_ind_csr_reg_rd("rxtx_reg1", inst_base + 1*2,eth_type,port,display);
//   printf("\n\n==================================================> XGE-%d RXTX_REG1 value set : 0x%x\n\n",port,rd_val);
//Added by Hrishikesh


   /////////////
   // rxtx_reg0
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg0", inst_base + 0*2,eth_type,port,display);
   // CTLE Half rate Control
   //wr_val = sm_enet_set(rd_val,infmode ? 16 : 16, 15, 11); // xls
   wr_val = sm_enet_set(rd_val,infmode ? 16 : 1, 15, 11); // Anil
   // CTLE Quarter rate Control
   //wr_val = sm_enet_set(wr_val,infmode ? 16 : 16, 10, 6); // xls
   wr_val = sm_enet_set(wr_val,infmode ? 16 : 1, 10, 6); // Anil
   // CTLE Fifth rate Control
   //wr_val = sm_enet_set(wr_val,infmode ? 16 : 16, 5, 1); // xls
   wr_val = sm_enet_set(wr_val,infmode ? 16 : 1, 5, 1); // Anil
   enet_sds_ind_csr_reg_wr("rxtx_reg0", inst_base + 0*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg14
   rd_val =  enet_sds_ind_csr_reg_rd("rxtx_reg14", inst_base + 14*2,eth_type,port,display);
   // CTLE Man Mode Select
   wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 6, 6);
   enet_sds_ind_csr_reg_wr("rxtx_reg14", inst_base + 14*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg12
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg12", inst_base + 12*2,eth_type,port,display);
   // SUM Offset enable
   wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 2, 2);
   enet_sds_ind_csr_reg_wr("rxtx_reg12", inst_base + 12*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg12
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg12", inst_base + 12*2,eth_type,port,display);
   // Latch Offset Enable
   wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 13, 13);
   enet_sds_ind_csr_reg_wr("rxtx_reg12", inst_base + 12*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg128
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg128", inst_base + 128*2,eth_type,port,display);
   // Latch Cal Wait Select
   wr_val = sm_enet_set(rd_val,infmode ? 3 : 3, 3, 2);
   enet_sds_ind_csr_reg_wr("rxtx_reg128", inst_base + 128*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg127
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg127", inst_base + 127*2,eth_type,port,display);
   // Latch Manual Cal enable
   wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 3, 3);
   enet_sds_ind_csr_reg_wr("rxtx_reg127", inst_base + 127*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg8
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg8", inst_base + 8*2,eth_type,port,display);
   // CDR Phase Loop enable
   wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 14, 14);
   // CDR Bypass RXLOS signal
   //wr_val = sm_enet_set(wr_val,infmode ? 0 : 0, 11, 11); // xls
   wr_val = sm_enet_set(wr_val,infmode ? 0 : 1, 11, 11); // Anil
   enet_sds_ind_csr_reg_wr("rxtx_reg8", inst_base + 8*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg61
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg61", inst_base + 61*2,eth_type,port,display);
   // CDR Clock Speed Select
   //wr_val = sm_enet_set(rd_val,infmode ? 7 : 2, 13, 10); // xls
   wr_val = sm_enet_set(rd_val,infmode ? 7 : 0, 13, 10); // Anil
   enet_sds_ind_csr_reg_wr("rxtx_reg61", inst_base + 61*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg125

//Added by Hrishikesh
   int sign_pq;
   sign_pq = 0;
   //if(port == 3) sign_pq = 1;//Default is '0'
//Added by Hrishikesh

   int pq_reg;//24-Jul
#if 0
   pq_reg = (port == 0) ? 0xa  ://24-Jul
            (port == 1) ? 0x12 ://24-Jul
            //(port == 1) ? 0xe ://22-Oct --- Hrishikesh
            (port == 2) ? 0xd  : 0x10;//24-Jul
            //(port == 2) ? 0xd  : 0x11;//22-Oct --- Hrishikesh
   //pq_reg = 0xa;
   pq_reg = (port == 3) ? 0x10  :0xa;
#endif

   if(port == 0) pq_reg = 0xa; 
   if(port == 1) pq_reg = 0xa; 
   if(port == 2) pq_reg = 0xa; 
   if(port == 3) pq_reg = 0x10; 
#if 0
   if(port == 3) {
                        printf("\nEnter pq_reg val for XGE-%d : 0x",port); pq_reg = get_val();
                        printf("\t(You entered 0x%x)\n",pq_reg);
                        //pq_reg = 0x10;
                    }
#endif

   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg125", inst_base + 125*2,eth_type,port,display);
   // IQ phase different
   //wr_val = sm_enet_set(rd_val,infmode ? 20 : 6, 15, 9); // xls
//   wr_val = sm_enet_set(rd_val,infmode ? 20 : 0, 15, 9); // Anil
   wr_val = sm_enet_set(rd_val,pq_reg, 15, 9);//24-Jul
   //wr_val = sm_enet_set(wr_val,sign_pq, 8, 8);//4-Jul-2014 // Added by Hrishikesh

   // Phase loop adaptation manual enable
   wr_val = sm_enet_set(wr_val,infmode ? 1 : 1, 1, 1);
   enet_sds_ind_csr_reg_wr("rxtx_reg125", inst_base + 125*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg11
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg11", inst_base + 11*2,eth_type,port,display);
   // Limit for Phase loop adaptation
   wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 15, 11);
   enet_sds_ind_csr_reg_wr("rxtx_reg11", inst_base + 11*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg61
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg61", inst_base + 61*2,eth_type,port,display);
   // Freq loop Disable
   //wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 3, 3); // xls
   wr_val = sm_enet_set(rd_val,infmode ? 1 : 0, 3, 3); // Anil
   enet_sds_ind_csr_reg_wr("rxtx_reg61", inst_base + 61*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg102
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg102", inst_base + 102*2,eth_type,port,display);
   // Freq offset limit setting
   wr_val = sm_enet_set(rd_val,infmode ? 3 : 3, 6, 5);
   enet_sds_ind_csr_reg_wr("rxtx_reg102", inst_base + 102*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg8
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg8", inst_base + 8*2,eth_type,port,display);
   // SSC enable - CDR
   wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 9, 9);
   enet_sds_ind_csr_reg_wr("rxtx_reg8", inst_base + 8*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg96
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg96", inst_base + 96*2,eth_type,port,display);
   // Freq Loop BW
   wr_val = sm_enet_set(rd_val,infmode ? 16 : 16, 15, 11);
   // Freq Loop BW
   wr_val = sm_enet_set(wr_val,infmode ? 16 : 16, 10, 6);
   // Freq Loop BW
   wr_val = sm_enet_set(wr_val,infmode ? 16 : 16, 5, 1);
   enet_sds_ind_csr_reg_wr("rxtx_reg96", inst_base + 96*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg97
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg97", inst_base + 97*2,eth_type,port,display);
   // Freq Loop BW
   wr_val = sm_enet_set(rd_val,infmode ? 16 : 16, 15, 11);
   // Freq Loop BW
   wr_val = sm_enet_set(wr_val,infmode ? 16 : 16, 10, 6);
   // Freq Loop BW
   wr_val = sm_enet_set(wr_val,infmode ? 16 : 16, 5, 1);
   enet_sds_ind_csr_reg_wr("rxtx_reg97", inst_base + 97*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg98
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg98", inst_base + 98*2,eth_type,port,display);
   // Freq Loop BW
   wr_val = sm_enet_set(rd_val,infmode ? 16 : 16, 15, 11);
   // Freq Loop BW
   wr_val = sm_enet_set(wr_val,infmode ? 16 : 16, 10, 6);
   // Freq Loop BW
   wr_val = sm_enet_set(wr_val,infmode ? 16 : 16, 5, 1);
   enet_sds_ind_csr_reg_wr("rxtx_reg98", inst_base + 98*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg99
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg99", inst_base + 99*2,eth_type,port,display);
   // CDR Phase Loop BW
   //wr_val = sm_enet_set(rd_val,infmode ? 5 : 5, 15, 11); // xls
   wr_val = sm_enet_set(rd_val,infmode ? 5 : 7, 15, 11); // Anil
   // CDR Phase Loop BW
   //wr_val = sm_enet_set(wr_val,infmode ? 5 : 5, 10, 6); // xls
   wr_val = sm_enet_set(wr_val,infmode ? 5 : 7, 10, 6); // Anil
   // CDR Phase Loop BW
   //wr_val = sm_enet_set(wr_val,infmode ? 5 : 5, 5, 1); // xls
   wr_val = sm_enet_set(wr_val,infmode ? 5 : 7, 5, 1); // Anil
   enet_sds_ind_csr_reg_wr("rxtx_reg99", inst_base + 99*2, wr_val,eth_type,port,display);
    
   /////////////
   // rxtx_reg100
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg100", inst_base + 100*2,eth_type,port,display);
   // CDR Phase Loop BW
   //wr_val = sm_enet_set(rd_val,infmode ? 5 : 5, 15, 11); // xls
   wr_val = sm_enet_set(rd_val,infmode ? 5 : 7, 15, 11); // Anil
   // CDR Phase Loop BW
   //wr_val = sm_enet_set(wr_val,infmode ? 5 : 5, 10, 6); // xls
   wr_val = sm_enet_set(wr_val,infmode ? 5 : 7, 10, 6); // Anil
   // CDR Phase Loop BW
   //wr_val = sm_enet_set(wr_val,infmode ? 5 : 5, 5, 1); // xls
   wr_val = sm_enet_set(wr_val,infmode ? 5 : 7, 5, 1); // Anil
   enet_sds_ind_csr_reg_wr("rxtx_reg100", inst_base + 100*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg101
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg101", inst_base + 101*2,eth_type,port,display);
   // CDR Phase Loop BW
   //wr_val = sm_enet_set(rd_val,infmode ? 5 : 5, 15, 11); // xls
   wr_val = sm_enet_set(rd_val,infmode ? 5 : 7, 15, 11); // Anil
   // CDR Phase Loop BW
   //wr_val = sm_enet_set(wr_val,infmode ? 5 : 5, 10, 6); // xls
   wr_val = sm_enet_set(wr_val,infmode ? 5 : 7, 10, 6); // Anil
   // CDR Phase Loop BW
   //wr_val = sm_enet_set(wr_val,infmode ? 5 : 5, 5, 1); // xls
   wr_val = sm_enet_set(wr_val,infmode ? 5 : 7, 5, 1); // Anil
   enet_sds_ind_csr_reg_wr("rxtx_reg101", inst_base + 101*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg8
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg8", inst_base + 8*2,eth_type,port,display);
   // RX los disable
   wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 8, 8);
   enet_sds_ind_csr_reg_wr("rxtx_reg8", inst_base + 8*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg26
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg26", inst_base + 26*2,eth_type,port,display);
   // BLWC Enable
   wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 3, 3);
   enet_sds_ind_csr_reg_wr("rxtx_reg26", inst_base + 26*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg81
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg81", inst_base + 81*2,eth_type,port,display);
   // DFE BW select
   wr_val = sm_enet_set(rd_val,infmode ? 14 : 14, 15, 11);
   // DFE BW select
   wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 10, 6);
   // DFE BW select
   wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 5, 1);
   enet_sds_ind_csr_reg_wr("rxtx_reg81", inst_base + 81*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg82
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg82", inst_base + 82*2,eth_type,port,display);
   // DFE BW select
   wr_val = sm_enet_set(rd_val,infmode ? 14 : 14, 15, 11);
   // DFE BW select
   wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 10, 6);
   // DFE BW select
   wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 5, 1);
   enet_sds_ind_csr_reg_wr("rxtx_reg82", inst_base + 82*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg83
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg83", inst_base + 83*2,eth_type,port,display);
   // DFE BW select
   wr_val = sm_enet_set(rd_val,infmode ? 14 : 14, 15, 11);
   // DFE BW select
   wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 10, 6);
   // DFE BW select
   wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 5, 1);
   enet_sds_ind_csr_reg_wr("rxtx_reg83", inst_base + 83*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg84
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg84", inst_base + 84*2,eth_type,port,display);
   // CDR phase Adaptation Loop BW
   wr_val = sm_enet_set(rd_val,infmode ? 14 : 14, 15, 11);
   // CDR phase Adaptation Loop BW
   wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 10, 6);
   // CDR phase Adaptation Loop BW
   wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 5, 1);
   enet_sds_ind_csr_reg_wr("rxtx_reg84", inst_base + 84*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg85
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg85", inst_base + 85*2,eth_type,port,display);
   // CDR phase Adaptation Loop BW
   wr_val = sm_enet_set(rd_val,infmode ? 14 : 14, 15, 11);
   // CDR phase Adaptation Loop BW
   wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 10, 6);
   // CDR phase Adaptation Loop BW
   wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 5, 1);
   enet_sds_ind_csr_reg_wr("rxtx_reg85", inst_base + 85*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg86
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg86", inst_base + 86*2,eth_type,port,display);
   // CDR phase Adaptation Loop BW
   wr_val = sm_enet_set(rd_val,infmode ? 14 : 14, 15, 11);
   // CDR phase Adaptation Loop BW
   wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 10, 6);
   // CDR phase Adaptation Loop BW
   wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 5, 1);
   enet_sds_ind_csr_reg_wr("rxtx_reg86", inst_base + 86*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg87
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg87", inst_base + 87*2,eth_type,port,display);
   // DFE Main Tap (Threshold) BW
   wr_val = sm_enet_set(rd_val,infmode ? 14 : 14, 15, 11);
   // DFE Main Tap (Threshold) BW
   wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 10, 6);
   // DFE Main Tap (Threshold) BW
   wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 5, 1);
   enet_sds_ind_csr_reg_wr("rxtx_reg87", inst_base + 87*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg88
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg88", inst_base + 88*2,eth_type,port,display);
   // DFE Main Tap (Threshold) BW
   wr_val = sm_enet_set(rd_val,infmode ? 14 : 14, 15, 11);
   // DFE Main Tap (Threshold) BW
   wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 10, 6);
   // DFE Main Tap (Threshold) BW
   wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 5, 1);
   enet_sds_ind_csr_reg_wr("rxtx_reg88", inst_base + 88*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg89
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg89", inst_base + 89*2,eth_type,port,display);
   // DFE Main Tap (Threshold) BW
   wr_val = sm_enet_set(rd_val,infmode ? 14 : 14, 15, 11);
   // DFE Main Tap (Threshold) BW
   wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 10, 6);
   // DFE Main Tap (Threshold) BW
   wr_val = sm_enet_set(wr_val,infmode ? 14 : 14, 5, 1);
   enet_sds_ind_csr_reg_wr("rxtx_reg89", inst_base + 89*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg145
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg145", inst_base + 145*2,eth_type,port,display);
   // DFE Configuration Selection
   wr_val = sm_enet_set(rd_val,infmode ? 3 : 3, 15, 14);
   enet_sds_ind_csr_reg_wr("rxtx_reg145", inst_base + 145*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg28
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg28", inst_base + 28*2,eth_type,port,display);
   // DFE tap enables
//   wr_val = sm_enet_set(rd_val,infmode ? 0xFFFF : 0xFFFF, 15, 0); // xls
//   wr_val = sm_enet_set(rd_val,infmode ? 0xFFFF : 0x0, 15, 0); // Anil
   wr_val = sm_enet_set(rd_val,infmode ? 0x7 : 0x7, 15, 0); //24-Jul
   enet_sds_ind_csr_reg_wr("rxtx_reg28", inst_base + 28*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg7
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 7*2,eth_type,port,display);
   // RX Resetn
   wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 8, 8);
   // RX Forward Loopback enable
   wr_val = sm_enet_set(wr_val,infmode ? 0 : 0, 14, 14);
   // RX Bist enable for PRBS transfer
   wr_val = sm_enet_set(wr_val,infmode ? 0 : 0, 6, 6);
   enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 7*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg61
   // Bert Reset Active Low: Toggle0-1-0
   //rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg61", inst_base + 61*2,eth_type,port,display);
   //wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 5, 5);
   //enet_sds_ind_csr_reg_wr("rxtx_reg61", inst_base + 61*2, wr_val,eth_type,port,display);

   //rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg61", inst_base + 61*2,eth_type,port,display);
   //wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 5, 5);
   //enet_sds_ind_csr_reg_wr("rxtx_reg61", inst_base + 61*2, wr_val,eth_type,port,display);

   //rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg61", inst_base + 61*2,eth_type,port,display);
   //wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 5, 5);
   //enet_sds_ind_csr_reg_wr("rxtx_reg61", inst_base + 61*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg6
   // Bert PRBS resync: Toggle0-1-0
   //rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2,eth_type,port,display);
   //wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 1, 1);
   //enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val,eth_type,port,display);

   //rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2,eth_type,port,display);
   //wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 1, 1);
   //enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val,eth_type,port,display);

   //rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2,eth_type,port,display);
   //wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 1, 1);
   //enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg6
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2,eth_type,port,display);
   // Bert Error count capture
   wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 0, 0);
   enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val,eth_type,port,display);

   /////////////
   // rxtx_reg12
   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg12", inst_base + 12*2,eth_type,port,display);
   // RX Serial Data swap(P and N polarity)
   wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 11, 11);
   enet_sds_ind_csr_reg_wr("rxtx_reg12", inst_base + 12*2, wr_val,eth_type,port,display);
  }
}

//refclk_cmos_sel = 0; - External differential clk
//refclk_cmos_sel = 1; - Internal single ended (cmos) clk

void sm_xgenet_module_init_enet_serdes( uint32_t infmode, uint32_t refclk_cmos_sel, uint32_t tx2rx_serdes_lb,int eth_type, int port, int display) {
  	uint32_t wr_val, rd_val, loop;
	uint32_t customer_pin_mode;
	uint32_t pll_ready, pll_lock, vco_calibration, tx_ready, rx_ready, rx_clk_inv;
	uint32_t refclksel, rndrefclk;
	uint32_t offset_addr;
  	uint32_t inst, inst_base;
  	uint32_t data32;
	int timeout;
 
	printf("\n<Using XGENET Driver with CASE_3 [Finisar SR on BB3_RevA]>\n");
 
        if(display==1)
	printf("C> ======================================================================= \n");
        if(display==1)
	printf("C> sm_xgenet_module_init_enet_serdes()\n");

        if(display==1)
	printf("INIT_SERDES : program PLL for base addr: %h\n",xgenet_base_addr);

	//get clk
  	// rndrefclk = 0, refclksel = 0; refclk_cmos_sel = 0; - External differential clk
	// rndrefclk = 1, refclksel = 0; refclk_cmos_sel = 1; - Internal single ended (cmos) clk
	refclksel = 0;
	rndrefclk = (refclksel << 1) | refclk_cmos_sel;

        if(display==1)
	printf("INIT_SERDES : Config Ref Clock");
	rd_val = enet_sds_ind_csr_reg_rd("CMU_reg0", CMU + 2*0,eth_type,port,display);
	wr_val = sm_enet_set(rd_val, refclksel, 13, 13);
	enet_sds_ind_csr_reg_wr("CMU_reg0", CMU + 2*0, wr_val,eth_type,port,display);

	rd_val = enet_sds_ind_csr_reg_rd("CMU_reg1", CMU + 2*1,eth_type,port,display);
	wr_val = sm_enet_set(rd_val, refclk_cmos_sel, 0, 0);
	enet_sds_ind_csr_reg_wr("CMU_reg1", CMU + 2*1, wr_val,eth_type,port,display);

	rd_val = enet_sds_ind_csr_reg_rd("CMU_reg37", CMU + 2*37,eth_type,port,display);
	rd_val = enet_sds_ind_csr_reg_rd("CMU_reg36", CMU + 2*36,eth_type,port,display);
	rd_val = enet_sds_ind_csr_reg_rd("CMU_reg16", CMU + 2*16,eth_type,port,display);

	// step 0: setup ETH_PLL which will provide internal reference clock to serdes
	if (infmode)
	  	wr_val = 0x306430; 
  	else
	  	wr_val = 0x305030; 

 	if (((xgenet_base_addr & 0x00100000)>> 20) == 0x1) {offset_addr = XGENET_0_BASE_ADDR;} 
 	else {offset_addr = XGENET_2_BASE_ADDR;}

	write(offset_addr + SM_XGENET_CLKRST_CSR_XGENET_PLL_CFG__ADDR, wr_val);

	if(refclk_cmos_sel) {	
      	//wait for PLL lock
      		do{
			rd_val = read(offset_addr + SM_XGENET_CLKRST_CSR_XGENET_PLL_STAT__ADDR);
			printf("INIT_SERDES : waiting for XGENET_PLL to lock\n");
			//sm_host_delay_ns(200);
		} while(rd_val == 0);
	}

   	// program PLL output clock divider value after PLL has locked
	if (infmode)
	    	wr_val = 0x4; 
   	else
	    	wr_val = 0x5; 

   	write(offset_addr + SM_XGENET_CLKRST_CSR_XGENET_PLL_DIV_CFG__ADDR, wr_val);

	// step 1: De-assert all the SerDes power down, (txpd, rxpd, pllpd). Can be	tied high
	// step 2: De-assert i_hresetn (SerDes register reset, active low signal/ step 3: Use the SerDs main reset(i_resetb) to start the reset sequencer
	// which generate internal rx/tx and pll resets
        if(display==1)
	printf("INIT_SERDES : assert all reset\n");
	// XGENET_SDS_RST_CTL
  	//eth_wr(SM_XGENET_SDS_CSR_REGS_XGENET_SDS_RST_CTL__ADDR, 0x0,eth_type,port,display); // Original
  	//eth_wr(SM_XGENET_SDS_CSR_REGS_XGENET_SDS_RST_CTL__ADDR, 0xFE,eth_type,port,display);  // Anil
  	eth_wr(SM_XGENET_SDS_CSR_REGS_XGENET_SDS_RST_CTL__ADDR, 0xDE,eth_type,port,display);  // Anil

	write( 0x17001398,0x001E1E1E); // Give control to Slave MDIO
	data32 = read(0x17001398);
        if(display==1)
        printf (" READ MPA_MDIO_IOCTL : 0x%08x\n", data32);
	
	//delay after forcing reset
	//sm_host_delay_ns(2000);

	//step 4:A) SGMII/ENET (1G) can use LSPLL PLL, native data rate need to set to 10G for LSPLL (Refclk = 100Mhz)
	          // REFDIV = 0, N Divider = 1, Post_divider for LS PLL = 1, data_rate = 10 (1/4th rate)
	          // i_rx_hsls_sel_l* and i_rx_hsls_sel_l* = 1, Rx and TX wordmode = 001 (10bit mode)
	//step 4:B) XGMII (10G) uses LS PLL, PLL native data rate need to be 10G
	          // REFDIV = 0, N Divider = 1, Post_divider for LS PLL = 1, data_rate = 00 (full rate)
	          // i_rx_hsls_sel_l* and i_rx_hsls_sel_l* = 1, Rx and TX wordmode = 110 (64bit mode) or 111 (66bit mode)

        if(display==1)
	printf("INIT_SERDES : REFCLK using -- %s\n",(rndrefclk == 0) ? "External differential clk" : "Internal single ended (cmos) clk");
        if(display==1)
	printf("INIT_SERDES : %s/ENET using -- LSPLL\n",infmode ? "XGMII" : "SGMII");

        // set cfg_i_customer_pin_mode = 0, as all register are directly programmed through indirect programming
	eth_wr(SM_XGENET_SDS_CSR_REGS_XGENET_SDS_CTL0__ADDR, 0,eth_type,port,display); // Ask Anil 

	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // This function programs the serdes as per KC_serdes_40nm_setting_0v25.xls
	sm_xgenet_module_program_all_regs(infmode,eth_type,port,display);

	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	

#ifdef CONFIG_SDS_SERDES_RX_CLK_INV
   rx_clk_inv = 1;
#else 
   rx_clk_inv = 0;
#endif   

	if(rx_clk_inv) {
		printf("INIT_SERDES : Enable RXCLK Inversion.");
    		for (inst = 0; inst < 1;  inst++) {
     			printf("INIT_SERDES : RXTX Inst %x\n", inst);
      			inst_base = 0x0400 + inst*0x0200;
	    		rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg13", inst_base + 0xD*2,eth_type,port,display);
                        wr_val = sm_enet_set(rd_val, 1, 13, 13);
	    		enet_sds_ind_csr_reg_wr("rxtx_reg13",  inst_base + 0xD*2, wr_val,eth_type,port,display);
     		} 
	}

	if (tx2rx_serdes_lb) {
		printf("INIT_SERDES : SERDES Tx2Rx Loopback Enable\n");
    		for (inst = 0; inst < 1;  inst++) {
		  	printf("INIT_SERDES : RXTX Inst %x\n", inst);
      			inst_base = 0x0400 + inst*0x0200;
	  		rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,eth_type,port,display);
                        wr_val = sm_enet_set(rd_val, 1, 6, 6);
		  	enet_sds_ind_csr_reg_wr("rxtx_reg4",  inst_base + 0x4*2, wr_val,eth_type,port,display);

		  	rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,eth_type,port,display);
                        wr_val = sm_enet_set(rd_val, 1, 14, 14);
		  	enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,eth_type,port,display);
    		}
  	}
	else {
                printf("INIT_SERDES : SERDES Tx2Rx Loopback Disable\n");
                for (inst = 0; inst < 1;  inst++) {
                        printf("INIT_SERDES : RXTX Inst %x\n", inst);
                        inst_base = 0x0400 + inst*0x0200;
                        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 0x4*2,eth_type,port,display);
                        wr_val = sm_enet_set(rd_val, 0, 6, 6);
                        enet_sds_ind_csr_reg_wr("rxtx_reg4",  inst_base + 0x4*2, wr_val,eth_type,port,display);

                        rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 0x7*2,eth_type,port,display);
                        wr_val = sm_enet_set(rd_val, 0, 14, 14);
                        enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 0x7*2, wr_val,eth_type,port,display);
                }
	}

        int rx2tx_serdes_lb = 0;
	if (rx2tx_serdes_lb) {
		printf("INIT_SERDES : SERDES Rx2Tx Loopback\n");
    		for (inst = 0; inst < 1;  inst++) {
		  	printf("INIT_SERDES : RXTX Inst %x\n", inst);
      			inst_base = 0x0400 + inst*0x0200;
	  		rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg8", inst_base + 0x8*2,eth_type,port,display);
                        wr_val = sm_enet_set(rd_val, 1, 15, 15); //rxtx_rev_par_lpbk
		  	enet_sds_ind_csr_reg_wr("rxtx_reg8",  inst_base + 0x8*2, wr_val,eth_type,port,display);
    		}
  	}


        if(display==1)
	printf("INIT_SERDES : de-assert all reset\n");
	// XGENET_SDS_RST_CTL
	wr_val = 0xDF; // Original
  	eth_wr(SM_XGENET_SDS_CSR_REGS_XGENET_SDS_RST_CTL__ADDR, wr_val,eth_type,port,display);

//	serdes_pdown_force_vco(eth_type,port,display);//24-Jul
        if(man_pvt_cal_xfi)
        serdes_calib_xg(infmode,eth_type,port,display);

//        serdes_reset_rxd_rxa_xg(eth_type,port,display);


        if(display==1)
	printf("INIT_SERDES : Check PLL Ready/LOCK and VCO Calibration status\n");
	loop = 1000;
	pll_ready = 0;
	while (pll_ready == 0) {
		// sm_host_delay_ns(200);
		rd_val = eth_rd(SM_XGENET_SDS_CSR_REGS_XGENET_SDS_CMU_STATUS0__ADDR,eth_type,port,display); 
  		// memory_barrier();
		pll_ready = FIELD_XGENET_SDS_CMU_STATUS0_CFG_CMU_O_PLL_READY_RD(rd_val);
		pll_lock = FIELD_XGENET_SDS_CMU_STATUS0_CFG_CMU_O_PLL_LOCK_RD(rd_val);
		vco_calibration = FIELD_XGENET_SDS_CMU_STATUS0_CFG_CMU_O_VCO_CALDONE_RD(rd_val);

		if (loop == 0)
			break;
		loop--;
	}

        if(display==1) {
	printf("INIT_SERDES : PLL is %sREADY\n", pll_ready ? "" : "not ");
	printf("INIT_SERDES : PLL %sLOCKed\n", pll_lock ? "" : "not ");
	printf("INIT_SERDES : PLL VCO Calibration %s\n", vco_calibration ? "Successful" : "not Successful");

	printf("INIT_SERDES : Check TX/RX Ready\n");
        }
	rd_val = eth_rd(SM_XGENET_SDS_CSR_REGS_XGENET_SDS_RXTX_STATUS__ADDR,eth_type,port,display); 
	//memory_barrier();
	tx_ready = FIELD_XGENET_SDS_RXTX_STATUS_CFG_TX_O_TX_READY_RD(rd_val);
	rx_ready = FIELD_XGENET_SDS_RXTX_STATUS_CFG_RX_O_RX_READY_RD(rd_val);
	
        if(display==1) {
	printf("INIT_SERDES : TX is %sready\n", tx_ready ? "" : "not ");
	printf("INIT_SERDES : RX is %sready\n", rx_ready ? "" : "not ");	
        }

//// ********************************************************************
////  PRBS Sequence
//// ********************************************************************
//// 1. Tx forward loopback enable, enables the loopabck buffer"
//    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg4", inst_base + 4*2,eth_type,port,display);
//    wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 6, 6);
//    enet_sds_ind_csr_reg_wr("rxtx_reg4", inst_base + 4*2, wr_val,eth_type,port,display);
//
////2. RX Forward Loopback enable
////3. RX Bist enable for PRBS transfer
//   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg7", inst_base + 7*2,eth_type,port,display);
//   wr_val = sm_enet_set(wr_val,infmode ? 1 : 1, 14, 14);
//   wr_val = sm_enet_set(wr_val,infmode ? 1 : 1, 6, 6);
//   enet_sds_ind_csr_reg_wr("rxtx_reg7", inst_base + 7*2, wr_val,eth_type,port,display);
//
////4. TX Bist enable for PRBS transfer
//    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg2", inst_base + 2*2,eth_type,port,display);
//    wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 11, 11);
//    enet_sds_ind_csr_reg_wr("rxtx_reg2", inst_base + 2*2, wr_val,eth_type,port,display);
//
////5. Toggle Re-sync the RX bert logic, without reset
//    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2,eth_type,port,display);
//    wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 1, 1);
//    enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val,eth_type,port,display);
//    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2,eth_type,port,display);
//    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 1, 1);
//    enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val,eth_type,port,display);
//    
////6. Reset bert logic  (0->1)
//   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg61", inst_base + 61*2,eth_type,port,display);
//   wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 5, 5);
//   enet_sds_ind_csr_reg_wr("rxtx_reg61", inst_base + 61*2, wr_val,eth_type,port,display);
//   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg61", inst_base + 61*2,eth_type,port,display);
//   wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 5, 5);
//   enet_sds_ind_csr_reg_wr("rxtx_reg61", inst_base + 61*2, wr_val,eth_type,port,display);
//
////7. Check for BERT PASS/FAIL bert passes
//   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg158", inst_base + 158*2,eth_type,port,display);
//
////8. Read internal Bist error counter value (1->0) 
//    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2,eth_type,port,display);
//    wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 0, 0);
//    enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val,eth_type,port,display);
//    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2,eth_type,port,display);
//    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 0, 0);
//    enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val,eth_type,port,display);
//
////9. Bist err count (LSB)
//   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg153", inst_base + 153*2,eth_type,port,display);
////10. Bist err count (MSB)
//   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg152", inst_base + 152*2,eth_type,port,display);
//
//
//
////11. INject error (Write 1)
//    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg8", inst_base + 8*2,eth_type,port,display);
//    wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 3, 3);
//    enet_sds_ind_csr_reg_wr("rxtx_reg8", inst_base + 8*2, wr_val,eth_type,port,display);
////12. INject error (Write 0)
//    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg8", inst_base + 8*2,eth_type,port,display);
//    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 3, 3);
//    enet_sds_ind_csr_reg_wr("rxtx_reg8", inst_base + 8*2, wr_val,eth_type,port,display);
//
////13. Read internal Bist error counter value (1->0) 
//    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2,eth_type,port,display);
//    wr_val = sm_enet_set(rd_val,infmode ? 1 : 1, 0, 0);
//    enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val,eth_type,port,display);
//    rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg6", inst_base + 6*2,eth_type,port,display);
//    wr_val = sm_enet_set(rd_val,infmode ? 0 : 0, 0, 0);
//    enet_sds_ind_csr_reg_wr("rxtx_reg6", inst_base + 6*2, wr_val,eth_type,port,display);
//
////14. Bist err count (LSB)
//   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg153", inst_base + 153*2,eth_type,port,display);
////15. Bist err count (MSB)
//   rd_val = enet_sds_ind_csr_reg_rd("rxtx_reg152", inst_base + 152*2,eth_type,port,display);


}

