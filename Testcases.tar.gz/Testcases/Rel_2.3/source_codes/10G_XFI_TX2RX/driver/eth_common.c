//////////////////////////////////////////////////////////////////////////////////////////
//file name:    eth_common.c
//create date:  1/6/2013
//description:  basic xgenet write and read function.
//              read(unsigned int *addresss)             read16(short *address, short data)    
//              write(unsigned int *address, int data)   write16(short *address, short data)   
//              read32(unsigned int *address)            read8(char *address)
//              write32(unsigned int *address, int data) write(char *address, char data)
//
//              xgenet_reg_wr()   xgenet_reg_rd()
//              enet_reg_wr()   enet_reg_rd()
//              qm_reg_wr()     qm_reg_rd()
//
//              get_val()       get_file()
//              error()         end_test()
//              ddr_init()
//////////////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include "eth_common.h"
#include "eth_1g_csr.h"
#include "eth_xg_csr.h"
#include "eth_mg_csr.h"

int enet_base_addr	= ENET_01_BASE_ADDR;
int xgenet_base_addr	= XGENET_0_BASE_ADDR;
int qm_base_addr	= QM_XGE01_BASE_ADDR;

int error_counter = 0;

int putnum(int num) {
  printf("%08x", num);
  return 0;
}

//---------------------------------------
//Basic Related Functions
//---------------------------------------
int read32(unsigned int *address){
  unsigned int *addr_int;
  int rdata;
  addr_int = address;
  rdata = *addr_int;
  //printf("Read32  @ 0x:"); putnum(addr_int); printf(" is 0x");  putnum(rdata);  printf("\n\r");
  return(rdata);
}

u64 read_64(u64 *address){
  u64 *addr_int;
  u64 rdata;
  addr_int = address;
  rdata = *addr_int;
  //printf("Read32  @ 0x:"); putnum(addr_int); printf(" is 0x");  putnum(rdata);  printf("\n\r");
  return(rdata);
}

u32 read_word(u64 *address){
  u64 *addr_int;
  u32 rdata;
  addr_int = address;
  rdata = (u32)*addr_int;
  //printf("Read32  @ 0x:"); putnum(addr_int); printf(" is 0x");  putnum(rdata);  printf("\n\r");
  return(rdata);
}

void write32(unsigned int *address, int data){
  unsigned int *addr_int;
  addr_int = address;
  *addr_int = data;
  //printf("Write32 @ 0x:"); putnum(address); printf(" is 0x");  putnum(data);  printf("\n\r");
}

int read(unsigned int *address){
  unsigned int *addr_int;
  int rdata;
  addr_int = address;
  rdata = *addr_int;
  //printf("Read32  @ 0x:"); putnum(addr_int); printf(" is 0x");  putnum(rdata);  printf("\n\r");
  return(rdata);
}

void write(unsigned int *address, int data){
  unsigned int *addr_int;
  addr_int = address;
  *addr_int = data;
  //printf("Write32 @ 0x:"); putnum(address); printf(" is 0x");  putnum(data);  printf("\n\r");
}

short read16(short *address){
  short *addr_int;
  short rdata;
  addr_int = address;
  rdata = *addr_int;
  //short rdata = *addr_int;
  //printf("Read16  @ 0x:"); putnum(address); printf(" is 0x");  putnum(rdata);  printf("\n\r");
  return(rdata);
}

void write16(short *address, short data){
  short *addr_int;
  addr_int = address;
  *addr_int = data;
  //printf("Write16 @ 0x:"); putnum(address); printf(" is 0x");  putnum(data);  printf("\n\r");
}

char read8(char *address){
  char *addr_int;
  char rdata;
  addr_int = address;
  //	char rdata = *addr_int;
  rdata = *addr_int;
  //printf("Read8  @ 0x:"); putnum(address); printf(" is 0x");  putnum(rdata);  printf("\n\r");
  return(rdata);
}

void write8(char *address, char data){
  char *addr_int;
  addr_int = address;
  *addr_int = data;
  //printf("Write8 @ 0x:"); putnum(address); printf(" is 0x");  putnum(data);  printf("\n\r");
}

//++++++++++++++++++++++++++++++++
//---------------------------------------
//Enet Related Functions
//---------------------------------------
int eth_base(int eth_type, int port){
  int address;
  switch(eth_type)
    {
    case ENET :
      switch(port){
      case PORT0:
      case PORT1:
	address = ENET_01_BASE_ADDR;
	break;
      case PORT2:
      case PORT3:
	address = ENET_23_BASE_ADDR;
	break;
      default :
	address = ENET_01_BASE_ADDR;
	break;
      }
      break;
    case XGENET :
      switch(port){
      case PORT0:
	address = XGENET_0_BASE_ADDR;
	break;
      case PORT1:
	address = XGENET_1_BASE_ADDR;
	break;
      case PORT2:
	address = XGENET_2_BASE_ADDR;
	break;
      case PORT3:
	address = XGENET_3_BASE_ADDR;
	break;
      default :
	address = XGENET_0_BASE_ADDR;
	break;
      }
      break;
    case MENET:
	address = MENET_BASE_ADDR;  //md:
    break;
    }
  return address;
}

int eth_rd(int offset, int eth_type, int port, int display){
  int address = eth_base(eth_type,port) + offset;
  int rd_data;
  rd_data = read(address);

  if(display_all | display) {
    printf("ENET_REG_RD : [0x%x] -> 0x%x \n\r",address,rd_data);
 }

  return rd_data;
}

void eth_wr(int offset, int wr_data, int eth_type, int port, int display){
  int address = eth_base(eth_type,port) + offset;
  write(address,wr_data);

  if(display_all | display) {   
     printf("ENET_REG_WR : [0x%x] <- 0x%x \n\r",address,wr_data); 
  }

}

int mcxmac_stat_rd(int offset, int port){
  int read_data;
  int display = 0;
  int counter;
  eth_wr(SM_XGENET_MCXMACIP_IND_CSR_STAT_IND_ADDR_0__ADDR, offset,XGENET,port,display);
  eth_wr(SM_XGENET_MCXMACIP_IND_CSR_STAT_IND_COMMAND_0__ADDR, 0x40000000,XGENET,port,display);
  do {
    read_data = eth_rd(SM_XGENET_MCXMACIP_IND_CSR_STAT_IND_COMMAND_DONE_0__ADDR,XGENET,port,display);
    counter++;
  } while (read_data != 0x00000001 && counter != MAX_INDCMD_DONE_COUNTER);
  
  if(read_data != 0x1) { printf("ERROR : XGENET_INDIRECT MCXMAC WR timeout");printf("\n\r"); }
  
  eth_wr(SM_XGENET_MCXMACIP_IND_CSR_STAT_IND_COMMAND_0__ADDR, 0x0,XGENET,port,display);
  read_data = eth_rd(SM_XGENET_MCXMACIP_IND_CSR_STAT_IND_RDATA_0__ADDR,XGENET,port,display); 
//  printf("0x");putnum(offset);printf(" = 0x");putnum(read_data);printf(" \t"); //md:

  return read_data;
  
}
int mac_stat_rd(int offset, int port){
  int read_data;
  int display = 0;
  int counter;
  if(port == 0 || port == 2){
    eth_wr(SM_ENET_MACIP_IND_CSR_STAT_IND_ADDR_0__ADDR, offset,ENET,port,display);
    eth_wr(SM_ENET_MACIP_IND_CSR_STAT_IND_COMMAND_0__ADDR, 0x40000000,ENET,port,display);
    do {
      read_data = eth_rd(SM_ENET_MACIP_IND_CSR_STAT_IND_COMMAND_DONE_0__ADDR,ENET,port,display);
      counter++;
    } while (read_data != 0x00000001 && counter != MAX_INDCMD_DONE_COUNTER);
  
    if(read_data != 0x1) { printf("ERROR : ENET_INDIRECT STAT RD timeout");printf("\n\r"); }
  
    eth_wr(SM_ENET_MACIP_IND_CSR_STAT_IND_COMMAND_0__ADDR, 0x0,ENET,port,display);
    read_data = eth_rd(SM_ENET_MACIP_IND_CSR_STAT_IND_RDATA_0__ADDR,ENET,port,display); 
  }
  else {
        eth_wr(SM_ENET_MACIP_IND_CSR_STAT_IND_ADDR_1__ADDR, offset,ENET,port,display);
    eth_wr(SM_ENET_MACIP_IND_CSR_STAT_IND_COMMAND_1__ADDR, 0x40000000,ENET,port,display);
    do {
      read_data = eth_rd(SM_ENET_MACIP_IND_CSR_STAT_IND_COMMAND_DONE_1__ADDR,ENET,port,display);
      counter++;
    } while (read_data != 0x00000001 && counter != MAX_INDCMD_DONE_COUNTER);
  
    if(read_data != 0x1) { printf("ERROR : ENET_INDIRECT STAT RD timeout");printf("\n\r"); }
  
    eth_wr(SM_ENET_MACIP_IND_CSR_STAT_IND_COMMAND_1__ADDR, 0x0,ENET,port,display);
    read_data = eth_rd(SM_ENET_MACIP_IND_CSR_STAT_IND_RDATA_1__ADDR,ENET,port,display); 
  }

//  printf("0x");putnum(offset);printf(" = 0x");putnum(read_data);printf(" \t"); //md:

  return read_data;
  
}

int  mcxmac_ind(int rnw, int offset, int wr_data, int eth_type, int port, int display){
  int addr_reg,cmd_reg,rdata_reg,wdata_reg, cmdsts_reg;
  int RD_CMD = 0x40000000;
  int WR_CMD = 0x80000000;
  int rd_data = 0;

  int counter = MAX_INDCMD_DONE_COUNTER;

  switch (eth_type)
    {
    case ENET :
      if(port == 0 || port == 2) {
	addr_reg   = SM_ENET_MACIP_IND_CSR_MAC_IND_ADDR_0__ADDR;
	cmd_reg    = SM_ENET_MACIP_IND_CSR_MAC_IND_COMMAND_0__ADDR;
	cmdsts_reg = SM_ENET_MACIP_IND_CSR_MAC_IND_COMMAND_DONE_0__ADDR; 
	rdata_reg  = SM_ENET_MACIP_IND_CSR_MAC_IND_RDATA_0__ADDR;
	wdata_reg  = SM_ENET_MACIP_IND_CSR_MAC_IND_WDATA_0__ADDR;
      } else {
	addr_reg   = SM_ENET_MACIP_IND_CSR_MAC_IND_ADDR_1__ADDR;
	cmd_reg    = SM_ENET_MACIP_IND_CSR_MAC_IND_COMMAND_1__ADDR;
	cmdsts_reg = SM_ENET_MACIP_IND_CSR_MAC_IND_COMMAND_DONE_1__ADDR; 
	rdata_reg  = SM_ENET_MACIP_IND_CSR_MAC_IND_RDATA_1__ADDR;
	wdata_reg  = SM_ENET_MACIP_IND_CSR_MAC_IND_WDATA_1__ADDR;
      }
      
      break;
    case XGENET :
      addr_reg   = SM_XGENET_MCXMACIP_IND_CSR_MAC_IND_ADDR_0__ADDR;
      cmd_reg    = SM_XGENET_MCXMACIP_IND_CSR_MAC_IND_COMMAND_0__ADDR;
      cmdsts_reg = SM_XGENET_MCXMACIP_IND_CSR_MAC_IND_COMMAND_DONE_0__ADDR; 
      rdata_reg  = SM_XGENET_MCXMACIP_IND_CSR_MAC_IND_RDATA_0__ADDR;
      wdata_reg  = SM_XGENET_MCXMACIP_IND_CSR_MAC_IND_WDATA_0__ADDR;

      break;
    case MENET : //md: for accessing MDIO via MGMT port 
      	addr_reg   = SM_MENET_MACIP_IND_CSR_MAC_IND_ADDR_0__ADDR;
      	cmd_reg    = SM_MENET_MACIP_IND_CSR_MAC_IND_COMMAND_0__ADDR;
      	cmdsts_reg = SM_MENET_MACIP_IND_CSR_MAC_IND_COMMAND_DONE_0__ADDR; 
      	rdata_reg  = SM_MENET_MACIP_IND_CSR_MAC_IND_RDATA_0__ADDR;
      	wdata_reg  = SM_MENET_MACIP_IND_CSR_MAC_IND_WDATA_0__ADDR;
      break;
    }

  eth_wr(addr_reg ,offset ,eth_type,port,0); // Indirect Address

  if(rnw) {
    eth_wr(cmd_reg,RD_CMD,eth_type,port,0); // Indirect Command
  } else {
    eth_wr(wdata_reg,wr_data,eth_type,port,0); // Indirect Write Data
    eth_wr(cmd_reg, WR_CMD,eth_type,port,0); // Indirect Command
  }

  do {
    rd_data = eth_rd(cmdsts_reg,eth_type,port,0); // Indirect Command Status
    counter--;
  } while (rd_data != 0x00000001 && counter != 0);

  if(rnw) 
    rd_data = eth_rd(rdata_reg,eth_type,port,0); // Indirect Read Data

  eth_wr(cmd_reg,0x0,eth_type,port,0);     // Indirect Clear Command

  if(counter == 0)
    printf("MCXMAC %s : [0x%x] FAILED \n\r",rnw ? "RD" : "WR", offset);
  else if (display_all|display)
    printf("MCXMAC %s : [0x%x] -> 0x%x \n\r",rnw ? "RD" : "WR", offset, rnw ? rd_data : wr_data);

  return(rd_data);
}

int mcxmac_ind_rd(int offset, int eth_type, int port, int display){
  int rnw = 1 ;
  return mcxmac_ind(rnw, offset, 0x0    , eth_type, port, display);
}

void mcxmac_ind_wr(int offset, int wr_data, int eth_type, int port, int display){
  int rnw = 0 ;
  mcxmac_ind(rnw, offset, wr_data, eth_type, port, display);
}

void mdio_wr(int phy_reg, int wr_data, int eth_type, int port, int display){
  int rd_data;
  //int counter = 10;
  int counter = 1000; //md:
  mcxmac_ind_wr(PE_MCXMAC_MII_MGMT_ADDRESS__ADDR,phy_reg   , eth_type, port, 0);
  mcxmac_ind_wr(PE_MCXMAC_MII_MGMT_CONTROL__ADDR,wr_data   , eth_type, port, 0);
  do {
    rd_data = mcxmac_ind_rd(PE_MCXMAC_MII_MGMT_INDICATORS__ADDR, eth_type, port, 0);
    counter--;
  }while(rd_data != 0x0 && counter != 0);

  if(counter == 0)
    printf("MDIO WR P%x FAILED : [0x%x] <- 0x%x \n\r",port,phy_reg,wr_data);
  else if(display_all|display) {
    printf("MDIO WR P%x : [0x%x] <- 0x%x \n\r",port,phy_reg,wr_data);
    mdio_rd(phy_reg, eth_type, port, 1); // check written value
  }

}

int mdio_rd(int phy_reg, int eth_type, int port, int display){
  int rd_data;
  //int counter = 10;
  int counter = 1000; //md:
  mcxmac_ind_wr(PE_MCXMAC_MII_MGMT_ADDRESS__ADDR,phy_reg   , eth_type, port, 0);
  mcxmac_ind_wr(PE_MCXMAC_MII_MGMT_COMMAND__ADDR,0x00000001, eth_type, port, 0);
  do {
    rd_data = mcxmac_ind_rd(PE_MCXMAC_MII_MGMT_INDICATORS__ADDR, eth_type, port, 0);
    counter--;
  }while(rd_data != 0x0 && counter != 0);

  rd_data = mcxmac_ind_rd(PE_MCXMAC_MII_MGMT_STATUS__ADDR, eth_type, port, 0);
  if(counter == 0)
    printf("MDIO RD P%x FAILED: [0x%x] -> 0x%x \n\r",port,phy_reg,rd_data);
  else if(display_all|display) {
    printf("MDIO RD P%x : [0x%x] -> 0x%x \n\r",port,phy_reg,rd_data);
  }
  mcxmac_ind_wr(PE_MCXMAC_MII_MGMT_COMMAND__ADDR,0x00000000, eth_type, port, 0);
  return rd_data;
}

void axgmac_ind_write (int addr, int data, int port, int display) {
  int read_data;
  int counter = 0;
//  int display = 0;
//  int port = 0; //FIXME
  eth_wr(SM_XGENET_AXGMACIP_IND_CSR_MAC_IND_ADDR_0__ADDR   ,addr       ,XGENET,port,display);
  eth_wr(SM_XGENET_AXGMACIP_IND_CSR_MAC_IND_WDATA_0__ADDR  ,data       ,XGENET,port,display);
  eth_wr(SM_XGENET_AXGMACIP_IND_CSR_MAC_IND_COMMAND_0__ADDR,0x80000000 ,XGENET,port,display);
  // wait till command done
  do {
    read_data = eth_rd(SM_XGENET_AXGMACIP_IND_CSR_MAC_IND_COMMAND_DONE_0__ADDR, XGENET,port,display);
    counter++;
  } while (read_data != 0x00000001 && counter != MAX_INDCMD_DONE_COUNTER);

  if(read_data != 0x1) { printf("ERROR : XGENET_INDIRECT AXGMAC WR timeout");printf("\n\r"); }

  //printf("XGENET_INDIRECT AXGMAC WR @ 0x:"); putnum(addr); printf(" is 0x");  putnum(data);  printf("\n\r");
  eth_wr(SM_XGENET_AXGMACIP_IND_CSR_MAC_IND_COMMAND_0__ADDR, 0x00000000,XGENET,port,display);
}

int axgmac_ind_read(int addr){
  int read_data;
  int counter = 0;

  int display = 0;
  int port = 0; //FIXME
  eth_wr(SM_XGENET_AXGMACIP_IND_CSR_MAC_IND_ADDR_0__ADDR,addr,XGENET,port,display);
  eth_wr(SM_XGENET_AXGMACIP_IND_CSR_MAC_IND_COMMAND_0__ADDR,0x40000000,XGENET,port,display);
  // wait till command done
  do {
    read_data = eth_rd(SM_XGENET_AXGMACIP_IND_CSR_MAC_IND_COMMAND_DONE_0__ADDR, XGENET,port,display);
    counter++;
  } while (read_data != 0x00000001 && counter != MAX_INDCMD_DONE_COUNTER);

  if(read_data != 0x1) { printf("ERROR : XGENET_INDIRECT AXGMAC RD timeout");printf("\n\r"); }

  read_data = eth_rd(SM_XGENET_AXGMACIP_IND_CSR_MAC_IND_RDATA_0__ADDR,  XGENET,port,display);
  eth_wr(SM_XGENET_AXGMACIP_IND_CSR_MAC_IND_COMMAND_0__ADDR,0x00000000,XGENET,port,display);

  printf("XGENET_INDIRECT AXGMAC RD -- [0x");putnum(addr);printf("] -> [0x");putnum(read_data);printf("]\n\r");
  return read_data;
}




//---------------------------------------
//QM Related Functions
//---------------------------------------
#if 1
void qm_reg_wr(int address, int data){
  int addr_int;
  addr_int = qm_base_addr + address;
  write(addr_int,data);
  //  printf("QM_REG_WR @ 0x:"); putnum(addr_int); printf(" is 0x");  putnum(data);  printf("\n\r");
}

int qm_reg_rd(int address){
  int addr_int;
  int read_data;
  addr_int = qm_base_addr + address;
  read_data = read(addr_int);
  printf("QM_REG_RD  @ 0x:"); putnum(addr_int); printf(" is 0x");  putnum(read_data);  printf("\n\r");
  return(read_data);
}
#endif

//++++++++++++++++++++++++++++++++

void error(int stoptest) {
  error_counter = error_counter + 1;
  if(stoptest){
    printf("Ending Tests with error count = "); putnum(error_counter);  printf("\n\r\n\r");
    printf("********************************************************");  printf("\n\r");
    printf("******************** Test Failed ***********************");  printf("\n\r");
    printf("********************************************************");  printf("\n\r");
    return;
  }
}


void end_test() {
  if(error_counter !=0)
    error(1);
  else {
    printf("********************************************************");  printf("\n\r");
    printf("******************** Test Passed ***********************");  printf("\n\r");
    printf("********************************************************");  printf("\n\r");
    return;
  }
};

int get_val(){
  int i = 0;
  char s[100];
  int j,val;
  do{
    //s[i++] = inbyte();
    s[i++] = getchar();
  } while ((s[i-1] != '\n') && (s[i-1] != '\r'));

  s[i] = '\0';

  val = 0x00000000;
  for (j=0; j<(i-1); j++) {
    if (s[j] > 0x40)
      {val = (val<<4) + s[j] - 0x57;}
    else
      {val = (val<<4) + s[j] - 0x30;}
  } 
  return val;
}

void get_file (int *start_address, int size_in_bytes) {
  int nibble_counter = 0;
  unsigned char in_ch;
  int word = 0;
  int hx = 0;
  unsigned char check;
  int *addr = start_address;
  while((nibble_counter) < size_in_bytes*2){
    check = 1;
    while(check){
      // in_ch = inbyte(); 
      in_ch = getchar(); 
      check = 0;
      if(in_ch>0x29 && in_ch<0x3a)
        hx = in_ch-0x30;
      else if((in_ch>0x40 && in_ch<0x47))
        hx = in_ch-0x37;
      else if((in_ch>0x60 && in_ch<0x67))
        hx = in_ch-0x57;
      else check = 1;
    }
    word = (word<<4) | hx;
    nibble_counter++;
    if(nibble_counter%8 == 0){
      *start_address = word;
      start_address++;
    }
  }
  printf("0x"); putnum(nibble_counter/2); printf(" bytes transferred");printf("\n\r");

}

//++++++++Serdes indirect write++++++++++++++++++++++++++++
void enet_sds_ind_csr_reg_wr(const char *name, uint32_t offset, uint32_t data, int eth_type, int port, int display )
{
  uint32_t wr_val, rd_val;
  uint32_t SDS_Ind_Command_Addr;
  uint32_t SDS_Ind_Command_Done;
  if(eth_type == ENET ) {
    // write 1 to clear indirect error detected/ind cmd done
    wr_val = (	FIELD_SATA_ENET_SDS_IND_CMD_REG_CFG_IND_ADDR_WR(0)
		| FIELD_SATA_ENET_SDS_IND_CMD_REG_CFG_IND_ERR_WR(1)
		| FIELD_SATA_ENET_SDS_IND_CMD_REG_CFG_IND_CMD_DONE_WR(1)
		| FIELD_SATA_ENET_SDS_IND_CMD_REG_CFG_IND_RD_CMD_WR(0)
		| FIELD_SATA_ENET_SDS_IND_CMD_REG_CFG_IND_WR_CMD_WR(0));

    eth_wr(SM_SATA_ENET_SDS_CSR_REGS_SATA_ENET_SDS_IND_CMD_REG__ADDR, wr_val,eth_type,port,0);

    wr_val = (FIELD_SATA_ENET_SDS_IND_WDATA_REG_CFG_IND_WDATA_WR(data));
    eth_wr(SM_SATA_ENET_SDS_CSR_REGS_SATA_ENET_SDS_IND_WDATA_REG__ADDR, wr_val,eth_type,port,0);

    SDS_Ind_Command_Addr = 0;
    SDS_Ind_Command_Addr = (0<<17) | (0<<16) | offset; //offset = offset[15:0]

    wr_val = (	FIELD_SATA_ENET_SDS_IND_CMD_REG_CFG_IND_ADDR_WR(SDS_Ind_Command_Addr)
		| FIELD_SATA_ENET_SDS_IND_CMD_REG_CFG_IND_ERR_WR(0)
		| FIELD_SATA_ENET_SDS_IND_CMD_REG_CFG_IND_CMD_DONE_WR(0)
		| FIELD_SATA_ENET_SDS_IND_CMD_REG_CFG_IND_RD_CMD_WR(0)
		| FIELD_SATA_ENET_SDS_IND_CMD_REG_CFG_IND_WR_CMD_WR(1));

    eth_wr(SM_SATA_ENET_SDS_CSR_REGS_SATA_ENET_SDS_IND_CMD_REG__ADDR, wr_val,eth_type,port,0);

    //memory_barrier();

    SDS_Ind_Command_Done = 0;
    while (SDS_Ind_Command_Done == 0) {
      rd_val = eth_rd(SM_SATA_ENET_SDS_CSR_REGS_SATA_ENET_SDS_IND_CMD_REG__ADDR,eth_type,port,0);
      SDS_Ind_Command_Done = FIELD_SATA_ENET_SDS_IND_CMD_REG_CFG_IND_CMD_DONE_RD(rd_val);
    }

  } else {
    // write 1 to clear indirect error detected/ind cmd done
    wr_val = (    FIELD_XGENET_SDS_IND_CMD_REG_CFG_IND_ADDR_WR(0)
		  | FIELD_XGENET_SDS_IND_CMD_REG_CFG_IND_ERR_WR(1)
		  | FIELD_XGENET_SDS_IND_CMD_REG_CFG_IND_CMD_DONE_WR(1)
		  | FIELD_XGENET_SDS_IND_CMD_REG_CFG_IND_RD_CMD_WR(0)
		  | FIELD_XGENET_SDS_IND_CMD_REG_CFG_IND_WR_CMD_WR(0));

    eth_wr(SM_XGENET_SDS_CSR_REGS_XGENET_SDS_IND_CMD_REG__ADDR, wr_val,eth_type,port,0);
 
    wr_val = (FIELD_XGENET_SDS_IND_WDATA_REG_CFG_IND_WDATA_WR(data));
    eth_wr(SM_XGENET_SDS_CSR_REGS_XGENET_SDS_IND_WDATA_REG__ADDR, wr_val,eth_type,port,0);

    SDS_Ind_Command_Addr = 0;
    SDS_Ind_Command_Addr = (0<<17) | (0<<16) | offset; //offset = offset[15:0]

    wr_val = (      FIELD_XGENET_SDS_IND_CMD_REG_CFG_IND_ADDR_WR(SDS_Ind_Command_Addr)
		    | FIELD_XGENET_SDS_IND_CMD_REG_CFG_IND_ERR_WR(0)
		    | FIELD_XGENET_SDS_IND_CMD_REG_CFG_IND_CMD_DONE_WR(0)
		    | FIELD_XGENET_SDS_IND_CMD_REG_CFG_IND_RD_CMD_WR(0)
		    | FIELD_XGENET_SDS_IND_CMD_REG_CFG_IND_WR_CMD_WR(1));

    eth_wr(SM_XGENET_SDS_CSR_REGS_XGENET_SDS_IND_CMD_REG__ADDR, wr_val,eth_type,port,0);

    // memory_barrier();

    SDS_Ind_Command_Done = 0;
    while (SDS_Ind_Command_Done == 0) {
      rd_val = eth_rd(SM_XGENET_SDS_CSR_REGS_XGENET_SDS_IND_CMD_REG__ADDR,eth_type,port,0);
      SDS_Ind_Command_Done = FIELD_XGENET_SDS_IND_CMD_REG_CFG_IND_CMD_DONE_RD(rd_val);
    }
    
 }

    if(display | display_all) {
      printf("Write to KoolChip Serdes %s: addr = 0x%x, writevalue 0x%x done\n", name, offset, data);
    }
	

}

//++++++++Serdes indirect read++++++++++++++++++++++++++++
uint32_t enet_sds_ind_csr_reg_rd(const char *name, uint32_t  offset, int eth_type, int port, int display)
{
  uint32_t 	wr_val, rd_val;
  uint32_t SDS_Ind_Command_Addr;
  uint32_t SDS_Ind_Command_Done;
  if(eth_type == ENET) {
    // write 1 to clear indirect error detected/ind cmd done
    wr_val = (	FIELD_SATA_ENET_SDS_IND_CMD_REG_CFG_IND_ADDR_WR(0)
		| FIELD_SATA_ENET_SDS_IND_CMD_REG_CFG_IND_ERR_WR(1)
		| FIELD_SATA_ENET_SDS_IND_CMD_REG_CFG_IND_CMD_DONE_WR(1)
		| FIELD_SATA_ENET_SDS_IND_CMD_REG_CFG_IND_RD_CMD_WR(0)
		| FIELD_SATA_ENET_SDS_IND_CMD_REG_CFG_IND_WR_CMD_WR(0));

    eth_wr(SM_SATA_ENET_SDS_CSR_REGS_SATA_ENET_SDS_IND_CMD_REG__ADDR, wr_val,eth_type,port,0);

    SDS_Ind_Command_Addr = 0;
    SDS_Ind_Command_Addr = (0<<17) | (0<<16) | offset; //offset = offset[15:0]

    wr_val = (	FIELD_SATA_ENET_SDS_IND_CMD_REG_CFG_IND_ADDR_WR(SDS_Ind_Command_Addr)
		| FIELD_SATA_ENET_SDS_IND_CMD_REG_CFG_IND_ERR_WR(0)
		| FIELD_SATA_ENET_SDS_IND_CMD_REG_CFG_IND_CMD_DONE_WR(0)
		| FIELD_SATA_ENET_SDS_IND_CMD_REG_CFG_IND_RD_CMD_WR(1)
		| FIELD_SATA_ENET_SDS_IND_CMD_REG_CFG_IND_WR_CMD_WR(0));

    eth_wr(SM_SATA_ENET_SDS_CSR_REGS_SATA_ENET_SDS_IND_CMD_REG__ADDR, wr_val,eth_type,port,0);

    //memory_barrier();

    SDS_Ind_Command_Done = 0;
    while (SDS_Ind_Command_Done == 0) {
      rd_val = eth_rd(SM_SATA_ENET_SDS_CSR_REGS_SATA_ENET_SDS_IND_CMD_REG__ADDR,eth_type,port,0);
      SDS_Ind_Command_Done = FIELD_SATA_ENET_SDS_IND_CMD_REG_CFG_IND_CMD_DONE_RD(rd_val);
    }

    rd_val = eth_rd(SM_SATA_ENET_SDS_CSR_REGS_SATA_ENET_SDS_IND_RDATA_REG__ADDR,eth_type,port,0);
  } else {
    wr_val = (      FIELD_XGENET_SDS_IND_CMD_REG_CFG_IND_ADDR_WR(0)
		    | FIELD_XGENET_SDS_IND_CMD_REG_CFG_IND_ERR_WR(1)
		    | FIELD_XGENET_SDS_IND_CMD_REG_CFG_IND_CMD_DONE_WR(1)
		    | FIELD_XGENET_SDS_IND_CMD_REG_CFG_IND_RD_CMD_WR(0)
		    | FIELD_XGENET_SDS_IND_CMD_REG_CFG_IND_WR_CMD_WR(0));

    eth_wr(SM_XGENET_SDS_CSR_REGS_XGENET_SDS_IND_CMD_REG__ADDR, wr_val,eth_type,port,0);

    SDS_Ind_Command_Addr = 0;
    SDS_Ind_Command_Addr = (0<<17) | (0<<16) | offset; //offset = offset[15:0]

    wr_val = (      FIELD_XGENET_SDS_IND_CMD_REG_CFG_IND_ADDR_WR(SDS_Ind_Command_Addr)
		    | FIELD_XGENET_SDS_IND_CMD_REG_CFG_IND_ERR_WR(0)
		    | FIELD_XGENET_SDS_IND_CMD_REG_CFG_IND_CMD_DONE_WR(0)
		    | FIELD_XGENET_SDS_IND_CMD_REG_CFG_IND_RD_CMD_WR(1)
		    | FIELD_XGENET_SDS_IND_CMD_REG_CFG_IND_WR_CMD_WR(0));

    eth_wr(SM_XGENET_SDS_CSR_REGS_XGENET_SDS_IND_CMD_REG__ADDR, wr_val,eth_type,port,0);

    //memory_barrier();

    SDS_Ind_Command_Done = 0;
    while (SDS_Ind_Command_Done == 0) {
      rd_val = eth_rd(SM_XGENET_SDS_CSR_REGS_XGENET_SDS_IND_CMD_REG__ADDR,eth_type,port,0);
      SDS_Ind_Command_Done = FIELD_XGENET_SDS_IND_CMD_REG_CFG_IND_CMD_DONE_RD(rd_val);
    }

    rd_val = eth_rd(SM_XGENET_SDS_CSR_REGS_XGENET_SDS_IND_RDATA_REG__ADDR,eth_type,port,0);
  }

  if(display || display_all)	{
    printf("Read from KoolChip Serdes %s: addr = 0x%x, readvalue 0x%x done\n", name, offset,rd_val);
  }
  return(rd_val);
}

uint32_t sm_enet_set(uint32_t ori_val,uint32_t set_val,uint32_t end,uint32_t start) {
  uint32_t mask = 0, new_val;
  int i;
  for(i = 0; i < 16;i++) {
    if((i < start)||(i > end)) 
      mask = mask | (1 << i);
    else
      mask = mask | (0 << i);
  }
  new_val = (ori_val & mask) | (set_val << start);
  return new_val;
}

void delay(int val){
  int timeout;
  for(timeout=0;timeout<(1000*val);timeout++);
}

