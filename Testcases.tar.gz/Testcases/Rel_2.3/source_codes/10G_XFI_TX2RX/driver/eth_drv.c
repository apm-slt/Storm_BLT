//////////////////////////////////////////////////////////////////////////////////////////
//file name:    xgenet_mac.c
//create date:  1/9/2013
//description:  indirectory routine to access serdes.
//              configure xgenet serdes in storm
//////////////////////////////////////////////////////////////////////////////////////////
#include <stdio.h>
#include "eth_common.h"
#include "eth_xg_csr.h"
#include "eth_1g_csr.h"

#include "sm_xxx_serdes.h"

//#include "eth_1g_csr.h" //md: removed warnings

//#define MAX_INDCMD_DONE_COUNTER 100

static int  read_data = 0x00000000;

// +++++++++++++++++++++++
// +++++++++++++++++++++++

// +++++++++++++++++++++++
int xgbaser_ind_read(int addr, int port, int display){  // md: for 10gig mode
  int read_data;
  int counter = 0;

//  int port, display = 0;
  eth_wr(SM_XGENET_XGBASER_PCS_IND_CSR_IND_ADDR_0__ADDR,addr,XGENET,port,display);
  eth_wr(SM_XGENET_XGBASER_PCS_IND_CSR_IND_COMMAND_0__ADDR,0x40000000,XGENET,port,display);
  // wait till command done
  do {
     read_data = eth_rd(SM_XGENET_XGBASER_PCS_IND_CSR_IND_COMMAND_DONE_0__ADDR,XGENET,port,display);
     counter++;
  } while (read_data != 0x00000001 && counter != MAX_INDCMD_DONE_COUNTER);

  if(read_data != 0x1) { printf("ERROR : XGENET_INDIRECT XGBASER RD timeout");printf("\n\r"); }

  read_data = eth_rd(SM_XGENET_XGBASER_PCS_IND_CSR_IND_RDATA_0__ADDR,XGENET,port,display);
  eth_wr(SM_XGENET_XGBASER_PCS_IND_CSR_IND_COMMAND_0__ADDR,0x00000000,XGENET,port,display);

//  printf("XGENET_INDIRECT XGBASER RD -- [0x");putnum(addr);printf("] -> [0x");putnum(read_data);printf("]\n\r");//Commented by Hrishikesh
  return read_data;
}

void xgbaser_ind_write (int addr, int data, int port, int display) {  // md: for 10gig mode
  int read_data;
  int counter = 0;
//  int port = 0;
//  int display =0;

  eth_wr(SM_XGENET_XGBASER_PCS_IND_CSR_IND_ADDR_0__ADDR,addr,XGENET,port,display);
  eth_wr(SM_XGENET_XGBASER_PCS_IND_CSR_IND_WDATA_0__ADDR,data,XGENET,port,display);
  eth_wr(SM_XGENET_XGBASER_PCS_IND_CSR_IND_COMMAND_0__ADDR,0x80000000,XGENET,port,display);
  // wait till command done
  do {
    read_data = eth_rd(SM_XGENET_XGBASER_PCS_IND_CSR_IND_COMMAND_DONE_0__ADDR,XGENET,port,display);
    counter++;
  } while (read_data != 0x00000001 && counter != MAX_INDCMD_DONE_COUNTER);

  if(read_data != 0x1) { printf("ERROR : XGENET_INDIRECT XGBASER WR timeout");printf("\n\r"); }

  //printf("XGENET_INDIRECT XGBASER WR @ 0x:"); putnum(addr); printf(" is 0x");  putnum(data);  printf("\n\r");
  eth_wr(SM_XGENET_XGBASER_PCS_IND_CSR_IND_COMMAND_0__ADDR, 0x00000000,XGENET,port,display);
}


void qmi_config(void) {

    unsigned int reg,tmp;

    printf("\n------- QMI Configuration for XFI-SGMII Ports Starts-------\n");
    // QMI configuration for Port-2/3
    printf("\r\nQMI configuration for Port-2 & Port-3\r\n");
    printf("Before write\r\n");
    reg = 0x1f7190dc;       
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7190e0;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7190f0;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7190f4;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);

    reg = 0x1f7290dc;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7290e0;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7290f0;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7290f4;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);

    // Port-2
    //write((unsigned int *)(0x1f7190dc), 0xffffffff); // CfgSsQmiFPQAssoc 
    //write((unsigned int *)(0x1f7190e0), 0xffffffff); // CfgSsQmiWQQAssoc 
    write((unsigned int *)(0x1f7190f0), 0xffffffff); // CfgSsQmiQMLiteFPQAssoc 
    write((unsigned int *)(0x1f7190f4), 0xffffffff); // CfgSsQmiQMLiteWQAssoc 

    // Port-3
    //write((unsigned int *)(0x1f7290dc), 0xffffffff); // CfgSsQmiFPQAssoc 
    //write((unsigned int *)(0x1f7290e0), 0xffffffff); // CfgSsQmiWQAssoc 
    write((unsigned int *)(0x1f7290f0), 0xffffffff); // CfgSsQmiQMLitePFQAssoc
    write((unsigned int *)(0x1f7290f4), 0xffffffff); // CfgSsQmiQMLiteWQAssoc

    printf("\r\nAftre write\r\n");
    reg = 0x1f7190dc;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7190e0;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7190f0;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7190f4;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);

    reg = 0x1f7290dc;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7290e0;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7290f0;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f7290f4;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    printf("------- QMI Configuration for XFI-SGMII Ports Ends -------\n");

    printf("\n------- QMI Configuration for SATA-SGMII Ports Starts -------\n");
    // Debug only; 
    // HAck Disable LError //11/04/2013; Recomendation from Satish
    printf("\r\nHach HAck SATA Ports for the PAcket Drops!!!!!!! \r\n");
    printf("Disable the LErrr from ENET\r\n");
    printf("Before write\r\n");
    reg = 0x1f212098;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f222098;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);

    write((unsigned int *)(0x1f212098), 0x0); 
    write((unsigned int *)(0x1f222098), 0x0); 

    printf("After write\r\n");
    reg = 0x1f212098;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f222098;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);

    printf("\nUn Mask the RSIF & TSIF Interrupts\r\n");
    write((unsigned int *)(0x1f212058), 0x0); 
    write((unsigned int *)(0x1f212060), 0x0); 
    write((unsigned int *)(0x1f2120a0), 0x0); 
    write((unsigned int *)(0x1f2120a8), 0x0);
    write((unsigned int *)(0x1f212130), 0x0);
    write((unsigned int *)(0x1f212138), 0x0);
     
    write((unsigned int *)(0x1f222058), 0x0); 
    write((unsigned int *)(0x1f222060), 0x0); 
    write((unsigned int *)(0x1f2220a0), 0x0); 
    write((unsigned int *)(0x1f2220a8), 0x0); 
    write((unsigned int *)(0x1f222130), 0x0); 
    write((unsigned int *)(0x1f222138), 0x0); 

    printf("\nUn Mask the QMI Interrupts\r\n");
    write((unsigned int *)(0x1f2190a0), 0x0); 
    write((unsigned int *)(0x1f2190a8), 0x0); 
    write((unsigned int *)(0x1f2190b0), 0x0); 
    write((unsigned int *)(0x1f2190b8), 0x0);
    write((unsigned int *)(0x1f2190c0), 0x0);
     
    write((unsigned int *)(0x1f2290a0), 0x0); 
    write((unsigned int *)(0x1f2290a8), 0x0); 
    write((unsigned int *)(0x1f2290b0), 0x0); 
    write((unsigned int *)(0x1f2290b8), 0x0);
    write((unsigned int *)(0x1f2290c0), 0x0);

    printf("\r\nQMI Configuration for Port-2 & Port-3\r\n");
    printf("Before write\r\n");
    reg = 0x1f2190dc;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f2190e0;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);

    reg = 0x1f2290dc;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f2290e0;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);

    reg = 0x1f2290f0;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);

    reg = 0x1f2290f4;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);

    write((unsigned int *)(0x1f2190dc), 0xffffffff); 
    write((unsigned int *)(0x1f2190e0), 0xffffffff); 
    //write((unsigned int *)(0x1f2190f0), 0xffffffff); 
    //write((unsigned int *)(0x1f2190f4), 0xffffffff); 

    write((unsigned int *)(0x1f2290dc), 0xffffffff);  // CfgSsQmiFPQAssoc
    write((unsigned int *)(0x1f2290e0), 0xffffffff);  // CfgSsQmiWQAssoc
    //write((unsigned int *)(0x1f2290f0), 0xffffffff);  // CfgSsQmiQMLiteWQAssoc
    //write((unsigned int *)(0x1f2290f4), 0xffffffff);  // CfgSsQmiQMLiteFPQAssoc

    printf("\r\nAfter write\r\n");
    reg = 0x1f2190dc;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f2190e0;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);

    reg = 0x1f2290dc;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    reg = 0x1f2290e0;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);

    reg = 0x1f2290f0;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);

    reg = 0x1f2290f4;
    tmp = read32(reg);
    printf("reg:0x%x tmp:0x%x\r\n",reg,tmp);
    
    printf("------- QMI Configuration for SATA-SGMII Ports Ends -------\n");
}


void bypass_cle_config() {

    u32 read_data; 
    int port, display=0; 
    
    printf("\n------- Bypass-CLE Config for XFI-SGMII Ports Starts -------\n");
    for (port=0; port<4; port++) {
#ifdef CONFIG_QM_RX2TX_LPBK // md: QM-Level-lpbk-test
    printf("QM lavel lpbk config for Port:%d\n",port);
    if(port == 0) {    
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
        printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110020,XGENET,port,display);
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110020,XGENET,port,display);

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data); 

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data); 

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
        eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
        // cfg to enable capture of Rx cntrl wd's
        eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
    }
    else if(port == 1) {    
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
        printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110021,XGENET,port,display);
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110021,XGENET,port,display);

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data); 

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data); 
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
        eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
        // cfg to enable capture of Rx cntrl wd's
        eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
    }
    else if(port == 2) {    
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1
        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
        printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110820,XGENET,port,display);
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110820,XGENET,port,display);

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data); 

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data); 

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
        eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
        // cfg to enable capture of Rx cntrl wd's
        eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
    }
    else if(port == 3) {    
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
        printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110821,XGENET,port,display);
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110821,XGENET,port,display);

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data); 

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data); 

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
        eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
        eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
    }
#endif
#ifdef CONFIG_CPU_RX2TX_LPBK // md: CPU-Level-lpbk-test
    printf("\nCPU lavel lpbk config for Port:%d\n",port);
    if(port == 0) {    
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
        printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110040,XGENET,port,display);
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110040,XGENET,port,display);

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data);
        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data);

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
        eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
        // cfg to enable capture of Rx cntrl wd's
        eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
    }
    else if(port == 1) {    
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
        printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110041,XGENET,port,display);
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110041,XGENET,port,display);

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data);
        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data);

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
        eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
        // cfg to enable capture of Rx cntrl wd's
        eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
    }
    else if(port == 2) {    
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
        printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110840,XGENET,port,display);
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110840,XGENET,port,display);

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data);
        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data);

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
        eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
        // cfg to enable capture of Rx cntrl wd's
        eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
    }
    else if(port == 3) {    
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
        printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110841,XGENET,port,display);
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110841,XGENET,port,display);

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data);
        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data);

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
        eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
        // cfg to enable capture of Rx cntrl wd's
        eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
    }
#endif
#ifdef CONFIG_SNAKE_RX2TX_LPBK // md: Snake-test
    printf("\nSNAKE test config for Port:%d\n",port);
    if(port == 0) {    
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
        printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110021,XGENET,port,display);
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110021,XGENET,port,display);

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data); 

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data); 

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
        eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
        // cfg to enable capture of Rx cntrl wd's
        eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
    }
    else if(port == 1) {    
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
        printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110020,XGENET,port,display);
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110020,XGENET,port,display);

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data); 

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data); 
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
        eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
        // cfg to enable capture of Rx cntrl wd's
        eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
    }
    else if(port == 2) {    
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1
        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
        printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110821,XGENET,port,display);
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110821,XGENET,port,display);

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data); 

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data); 

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
        eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
        // cfg to enable capture of Rx cntrl wd's
        eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
    }
    else if(port == 3) {    
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR, 0xa000050e,XGENET,port,display);//cfg_cle_bypass=1

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,XGENET,port,display);
        printf("\r\nport:%d SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG0__ADDR,read_data);

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR, 0x00110820,XGENET,port,display);
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR, 0x00110820,XGENET,port,display);

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,XGENET,port,display);
        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG1__ADDR,read_data); 

        read_data = eth_rd(SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,XGENET,port,display);
        printf("port:%d SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR:0x%x read_data:0x%x\r\n",port,SM_XGENET_CSR_CLE_BYPASS_REG2__ADDR,read_data); 

        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG6__ADDR, 0x00101000,XGENET,port,display);//hopinfolsbs_msb=0x1000,cle_hr =0x1
        eth_wr(SM_XGENET_CSR_CLE_BYPASS_REG8__ADDR, 0x0c000000,XGENET,port,display);//henqnum=0xc00
        eth_wr(SM_XGENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,XGENET,port,display);
        eth_wr(SM_XGENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,XGENET,port,display);
    }
#endif // snake test
    }
    printf("------- Bypass-CLE Config for XFI-SGMII Ports Endss -------\n");
    
    printf("\n------- Bypass-CLE Config for SATA-SGMII Ports Starts -------\n");
    for (port=0; port<4; port++) {
#ifdef CONFIG_QM_RX2TX_LPBK // md: QM-level-lpbk-test
        printf("\nQM lavel lpbk config for  Port:%d\n",port);
        if(port == 0) { //Port-0/1    
            // Port-0  
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR, 0xa000050e,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR, 0xa000000e,ENET,port,display);
            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,ENET,port,display);
            printf("\r\nport:%d SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR, 0x00110420,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR, 0x00110420,ENET,port,display);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,read_data);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,read_data);

            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR, 0x00000c05,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG3_0__ADDR, 0x20000000,ENET,port,display); // Policer
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_0__ADDR, 0x00000040,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG5_0__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_0__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_0__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_0__ADDR, 0x0c000000,ENET,port,display);

            //Port-1  
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR, 0xa000050e,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR, 0xa000000e,ENET,port,display);
            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR,ENET,port,display);
            printf("\r\nport:%d SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR, 0x00110421,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR, 0x00110421,ENET,port,display);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,read_data);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR,read_data);

            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR, 0x00000c05,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG3_1__ADDR, 0x20000000,ENET,port,display); // Policer
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_1__ADDR, 0x00000040,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG5_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_1__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_1__ADDR, 0x0c000000,ENET,port,display);

            eth_wr(SM_ENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,ENET,port,display);
            eth_wr(SM_ENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,ENET,port,display);         
        }
        if(port == 2) { //Port-2/3    
            // Port-2  
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR, 0xa000050e,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR, 0xa000000e,ENET,port,display);
            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,ENET,port,display);
            printf("\r\nport:%d SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR, 0x00110422,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR, 0x00110422,ENET,port,display);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,read_data);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,read_data);

            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR, 0x00000c05,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG3_0__ADDR, 0x20000000,ENET,port,display); // Policer
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_0__ADDR, 0x00000040,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG5_0__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_0__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_0__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_0__ADDR, 0x0c000000,ENET,port,display);

            //Port-3  
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR, 0xa000050e,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR, 0xa000000e,ENET,port,display);
            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR,ENET,port,display);
            printf("\r\nport:%d SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR, 0x00110423,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR, 0x00110423,ENET,port,display);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,read_data);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR,read_data);

            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR, 0x00000c05,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG3_1__ADDR, 0x20000000,ENET,port,display); // Policer
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_1__ADDR, 0x00000040,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG5_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_1__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_1__ADDR, 0x0c000000,ENET,port,display);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_1__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_1__ADDR, 0x0c000000,ENET,port,display);

            eth_wr(SM_ENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,ENET,port,display);
            eth_wr(SM_ENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,ENET,port,display);         
        }
#endif
#ifdef CONFIG_CPU_RX2TX_LPBK // md: CPU-level-lpbk-test
        printf("\nCPU lavel lpbk config for Port:%d\n",port);
        if(port == 0) { //Port-0/1    
            // Port-0  
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR, 0xa000000e,ENET,port,display);
            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,ENET,port,display);
            printf("\r\nport:%d SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR, 0x00110440,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR, 0x00110440,ENET,port,display);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,read_data);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,read_data);

            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR, 0x00000c05,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG3_0__ADDR, 0x20000000,ENET,port,display); // Policer
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_0__ADDR, 0x00000040,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG5_0__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_0__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_0__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_0__ADDR, 0x0c000000,ENET,port,display);

            //Port-1  
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR, 0xa000000e,ENET,port,display);
            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR,ENET,port,display);
            printf("\r\nport:%d SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR, 0x00110441,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR, 0x00110441,ENET,port,display);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,read_data);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR,read_data);

            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR, 0x00000c05,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG3_1__ADDR, 0x20000000,ENET,port,display); // Policer
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_1__ADDR, 0x00000040,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG5_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_1__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_1__ADDR, 0x0c000000,ENET,port,display);

            eth_wr(SM_ENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,ENET,port,display);
            eth_wr(SM_ENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,ENET,port,display);         
        }
        if(port == 2) { //Port-2/3    
            // Port-2  
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR, 0xa000000e,ENET,port,display);
            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,ENET,port,display);
            printf("\r\nport:%d SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR, 0x00110442,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR, 0x00110442,ENET,port,display);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,read_data);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,read_data);

            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR, 0x00000c05,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG3_0__ADDR, 0x20000000,ENET,port,display); // Policer
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_0__ADDR, 0x00000040,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG5_0__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_0__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_0__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_0__ADDR, 0x0c000000,ENET,port,display);

            //Port-3  
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR, 0xa000000e,ENET,port,display);
            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR,ENET,port,display);
            printf("\r\nport:%d SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR, 0x00110443,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR, 0x00110443,ENET,port,display);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,read_data);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR,read_data);

            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR, 0x00000c05,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG3_1__ADDR, 0x20000000,ENET,port,display); // Policer
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_1__ADDR, 0x00000040,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG5_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_1__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_1__ADDR, 0x0c000000,ENET,port,display);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_1__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_1__ADDR, 0x0c000000,ENET,port,display);

            eth_wr(SM_ENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,ENET,port,display);
            eth_wr(SM_ENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,ENET,port,display);         
        }
#endif
#ifdef CONFIG_SNAKE_RX2TX_LPBK // md: Snake-test
        printf("\nSNAKE-Test config for Port:%d\n",port);
        if(port == 0) { //Port-0/1    
            // Port-0  
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR, 0xa000050e,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR, 0xa000000e,ENET,port,display);
            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,ENET,port,display);
            printf("\r\nport:%d SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR, 0x00110421,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR, 0x00110421,ENET,port,display);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,read_data);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,read_data);

            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR, 0x00000c05,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG3_0__ADDR, 0x20000000,ENET,port,display); // Policer
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_0__ADDR, 0x00000040,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG5_0__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_0__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_0__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_0__ADDR, 0x0c000000,ENET,port,display);

            //Port-1  
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR, 0xa000050e,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR, 0xa000000e,ENET,port,display);
            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR,ENET,port,display);
            printf("\r\nport:%d SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR, 0x00110422,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR, 0x00110422,ENET,port,display);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,read_data);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR,read_data);

            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR, 0x00000c05,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG3_1__ADDR, 0x20000000,ENET,port,display); // Policer
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_1__ADDR, 0x00000040,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG5_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_1__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_1__ADDR, 0x0c000000,ENET,port,display);

            eth_wr(SM_ENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,ENET,port,display);
            eth_wr(SM_ENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,ENET,port,display);         
        }
        if(port == 2) { //Port-2/3    
            // Port-2  
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR, 0xa000050e,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR, 0xa000000e,ENET,port,display);
            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,ENET,port,display);
            printf("\r\nport:%d SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG0_0__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR, 0x00110423,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR, 0x00110423,ENET,port,display);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG1_0__ADDR,read_data);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR,read_data);

            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_0__ADDR, 0x00000c05,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG3_0__ADDR, 0x20000000,ENET,port,display); // Policer
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_0__ADDR, 0x00000040,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG5_0__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_0__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_0__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_0__ADDR, 0x0c000000,ENET,port,display);

            //Port-3  
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR, 0xa000050e,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR, 0xa000000e,ENET,port,display);
            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR,ENET,port,display);
            printf("\r\nport:%d SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG0_1__ADDR,read_data);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR, 0x00110420,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR, 0x00110420,ENET,port,display);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG1_1__ADDR,read_data);

            read_data = eth_rd(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR,ENET,port,display);
            printf("port:%d SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR:0x%x read_data:0x%x\r\n",port,SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR,read_data);

            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG2_1__ADDR, 0x00000c05,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG3_1__ADDR, 0x20000000,ENET,port,display); // Policer
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG4_1__ADDR, 0x00000040,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG5_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_1__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_1__ADDR, 0x0c000000,ENET,port,display);

            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG6_1__ADDR, 0x00101000,ENET,port,display);
            //eth_wr(SM_ENET_CSR_CLE_BYPASS_REG7_1__ADDR, 0x00000000,ENET,port,display);
            eth_wr(SM_ENET_CSR_CLE_BYPASS_REG8_1__ADDR, 0x0c000000,ENET,port,display);

            eth_wr(SM_ENET_CSR_RSIF_CONFIG_REG__ADDR, 0xff010044,ENET,port,display);
            eth_wr(SM_ENET_CSR_PCKWD_REG0__ADDR, 0x0003870c,ENET,port,display);         
        }
#endif // snake test
        } // for loop
    printf("------- Bypass-CLE Config for SATA-SGMII Ports Ends -------\n");
}

//Added by Hrishikesh -- Copied from sata_sgmii/driver/eth_drv.c
void es_singlephase(int vRange, int vskip, int port) {

    int vm;
    int fullFlag;
    int es_data;
    int es_data1;
    int es_data2;
    int est_data;
    int est_data1;
    int est_data2,data;
    uint32_t inst, inst_base;
	int display =0;

    inst = 0;
    //inst = port & 0x1;
    inst_base = 0x0400 + inst*0x0200;

    // function to sweep voltage level
    for (vm=0; vm < vRange; vm = vm + vskip) {
        // set vmargin to new value
        //   WriteReg('escan_vmargin',vm) 
        data = enet_sds_ind_csr_reg_rd("RXTX_REG19", inst_base + 19*2,XGENET,port,display);
        data = FIELD_RXTX_REG19_ESCAN_VMARGIN_SET(data, vm);
        enet_sds_ind_csr_reg_wr("RXTX_REG19", inst_base + 19*2, data,XGENET,port,display);

        // toggle resetb
        data = enet_sds_ind_csr_reg_rd("RXTX_REG61", inst_base + 61*2,XGENET,port,display);
        data = FIELD_RXTX_REG61_EYE_ACC_RESETB_SET(data, 0);
        enet_sds_ind_csr_reg_wr("RXTX_REG61", inst_base + 61*2, data,XGENET,port,display);

        data = enet_sds_ind_csr_reg_rd("RXTX_REG61", inst_base + 61*2,XGENET,port,display);
        data = FIELD_RXTX_REG61_EYE_ACC_RESETB_SET(data, 1);
        enet_sds_ind_csr_reg_wr("RXTX_REG61", inst_base + 61*2, data,XGENET,port,display);

        // poll for data full flag
        do {
            data = enet_sds_ind_csr_reg_rd("RXTX_REG118", inst_base + 118*2,XGENET,port,display);
            fullFlag = FIELD_RXTX_REG118_ACC_FULL_FLAG_RD(data);
            //printf("waiting full flag \n");
        } while (fullFlag == 0);

        // trigger data capture
        data = enet_sds_ind_csr_reg_rd("RXTX_REG61", inst_base + 61*2,XGENET,port,display);
        data = FIELD_RXTX_REG61_EYE_MONITOR_CAPTURE_SET(data, 1);
        enet_sds_ind_csr_reg_wr("RXTX_REG61", inst_base + 61*2, data,XGENET,port,display);

        data = enet_sds_ind_csr_reg_rd("RXTX_REG61", inst_base + 61*2,XGENET,port,display);
        data = FIELD_RXTX_REG61_EYE_MONITOR_CAPTURE_SET(data, 0);
        enet_sds_ind_csr_reg_wr("RXTX_REG61", inst_base + 61*2, data,XGENET,port,display);

        // read data to string
        es_data1 = enet_sds_ind_csr_reg_rd("RXTX_REG123", inst_base + 123*2,XGENET,port,display);
        es_data2 = enet_sds_ind_csr_reg_rd("RXTX_REG124", inst_base + 124*2,XGENET,port,display);

        //es_data = es_data1*(2**16)+es_data2;
        es_data = es_data1*65536+es_data2;
        est_data1 = enet_sds_ind_csr_reg_rd("RXTX_REG161", inst_base + 161*2,XGENET,port,display);
        est_data2 = enet_sds_ind_csr_reg_rd("RXTX_REG162", inst_base + 162*2,XGENET,port,display);
        //est_data = est_data1*(2**16)+est_data2;
        est_data = est_data1*65536+est_data2;

        printf ("es_str: %d \n", es_data);
        printf ("est_str: %d \n", est_data);
    }
}


int eyescan_sub_xfi_10g(int port) {

    int vRange;
    int qinit;
    int qend;
    int qskip;
    int num_of_steps;
    int increment;
    int barVal;
    int qi;
    int pqsign, pqval,data;
    uint32_t inst, inst_base;
	int display =0;

    inst = 0;
    //inst = port & 0x1;
    inst_base = 0x0400 + inst*0x0200;

    vRange = 64;
    qinit = -64;
    qend = 64;
    qskip = 1;

    printf("\nCapture eye plot using eyescan for port-%d\n",port);

#if 0	// Moved this to main code : at the start of xgene_phy_gen_avg_val() ==> as per Chidvilas's discussion with Poly on [28-Aug-2014]
    data = enet_sds_ind_csr_reg_rd("RXTX_REG145", inst_base + 145*2,XGENET,port,display);
    data = FIELD_RXTX_REG145_RXVWES_LATENA_SET(data, 1);
    data = FIELD_RXTX_REG145_RXES_ENA_SET(data, 1);
    enet_sds_ind_csr_reg_wr("RXTX_REG145", inst_base + 145*2, data,XGENET,port,display);
#endif

    data = enet_sds_ind_csr_reg_rd("RXTX_REG62", inst_base + 62*2,XGENET,port,display);
    data = FIELD_RXTX_REG62_PERIOD_H1_QLATCH_SET(data, 2);
    data = FIELD_RXTX_REG62_SWITCH_H1_QLATCH_SET(data, 1);
    data = FIELD_RXTX_REG62_H1_QLATCH_SIGN_INV_SET(data, 0);
    enet_sds_ind_csr_reg_wr("RXTX_REG62", inst_base + 62*2, data,XGENET,port,display);

    data = enet_sds_ind_csr_reg_rd("RXTX_REG61", inst_base + 61*2,XGENET,port,display);
    data = FIELD_RXTX_REG61_EYE_COUNT_WIDTH_SEL_SET(data, 2);
    enet_sds_ind_csr_reg_wr("RXTX_REG61", inst_base + 61*2, data,XGENET,port,display);

    //qi_move(qinit,2, port); // Move to qinit from current qi in step of 2

    //for qi from qinit to qend 
    printf("CHANNEL %d START \n", port);
    for (qi = qinit ; qi < qend; qi= qi+qskip) 
    {
        //qi_move(qi,qskip, port);

        data = enet_sds_ind_csr_reg_rd("RXTX_REG126", inst_base + 126*2,XGENET,port,display);

        if(qi<0){
            pqsign = 1;
            pqval = qi * -1;
        } else {
            pqsign = 0;
            pqval = qi;
        };
        data = FIELD_RXTX_REG126_SIGN_QI_REG_SET(data, pqsign);
        data = FIELD_RXTX_REG126_QI_REG_SET(data, pqval);

        printf("qi %d sign_qi %d\n", pqval, pqsign);
        enet_sds_ind_csr_reg_wr("RXTX_REG126", inst_base + 126*2, data,XGENET,port,display);

        es_singlephase(vRange, qskip, port);
        printf("endscan \n");
    }
    //qi_move(0,2, port);
    printf("CHANNEL %d END \n", port);

    data = enet_sds_ind_csr_reg_rd("RXTX_REG19", inst_base + 19*2,XGENET,port,display);
    data = FIELD_RXTX_REG19_ESCAN_VMARGIN_SET(data, 0);
    enet_sds_ind_csr_reg_wr("RXTX_REG19", inst_base + 19*2, data,XGENET,port,display);

    return 0;
}

//Added by Hrishikesh -- Copied from sata_sgmii/driver/eth_drv.c
