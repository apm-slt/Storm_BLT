//#include <stdio.h>
#include "../include/platform.h"
#include "../include/test_util.h"
#include "../include/gfc_common.h"
#include "../include/gfc_nand.h"
#include "../include/gfc_nor.h"
#include "../include/gfc_dma.h"
#include "../include/gfc_sram.h"
#include "../include/gfc_interleave.h"


//Tinh-SLT
#define read read_gfc
#define write write_gfc
#define read8 read8_gfc
#define write8 write8_gfc
#define read16 read16_gfc
#define write16 write16_gfc



unsigned int  sram_test(){
	  unsigned int bstatus = 1;
  //// Uncomment this out if needed to use/reconfigure existing configuraiton:-
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  ////                           bank_id, burst_en, mux_en, twt, fwt, bwt, csn, oen, wbn, wbf, th,  aln, alh, bem)
  //nor_sram_timing_param_change(BANK1,   0x1,      0x0,    0x4, 0x4, 0x2, 0x1, 0x1, 0x1, 0x1, 0x1, 0x7, 0x2, 0x1);

  //// BME = 0
  //sram_BME_enable_disabled(BANK1, 0x0);
  //// BME = 1
  ////sram_BME_enable_disabled(BANK1, 0x1);

  //// BEM = 0
  //sram_BEM_enable_disabled(BANK1, 0x0);
  //// BEM = 1
  ////sram_BEM_enable_disabled(BANK1, 0x1);

  ////print_SRAM_NOR_ctrl_regs(BANK1);
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  //// Configure existing SRAM as 8bit device
  ////write (0x17012004 + (BANK1<<12), );

  //sram_test_default0(BANK1, SRAM, BUS_WIDTH_16,NUMONYX, 0x0, 0x100); 
//	  bstatus = sram_test_basic0(BANK4, SRAM, BUS_WIDTH_16,NUMONYX, 0x00, 0x4000);
//	  bstatus = sram_test_basic0(BANK4, SRAM, BUS_WIDTH_8,NUMONYX, 0x00, 0x4000);
	  bstatus = sram_test_basic0(BANK3, SRAM, BUS_WIDTH_8,NUMONYX, 0x00, 0x4000);
	  //bstatus = sram_test_basic0(BANK5, SRAM, BUS_WIDTH_8,NUMONYX, 0x00, 0x4000);

//	  bstatus = sram_test_basic0(BANK3, SRAM, BUS_WIDTH_8,NUMONYX, 0x00000000, 0x0FFFFFFF);
//	  bstatus = sram_test_basic0(BANK5, SRAM, BUS_WIDTH_16,NUMONYX, 0x00, 0x4000);
//	  bstatus = sram_test_default0_32(BANK4, SRAM, BUS_WIDTH_16,NUMONYX, 0x10, 0x100); // datnguyen BANK1 -> BANK3 ,   0x00, 0x100 -> , 0x10, 0xff

  return bstatus;
}

void sram_test_default0 (int bank_id, int device_type, int bus_width, int vendor, int device_startadd_bit29to16, int device_endadd_bit29to16) {

   unsigned int test_startadd;
   unsigned int test_endadd;
   unsigned int i;
   unsigned int tmp;
   unsigned int test_startblock;
   unsigned int test_endblock; 
   unsigned int device_startadd;
   unsigned int incr_size;
   int          user_pattern = 0x20d0;
   int          block_erase_en = 1;
   
   //Disable default BANK address range first
   disable_norsram_banks(BANK0);
   disable_norsram_banks(BANK1);
   disable_norsram_banks(BANK2);
   disable_norsram_banks(BANK3);
   disable_norsram_banks(BANK4);
   disable_norsram_banks(BANK5);

   //setup bank1
   device_setup_w_add (bank_id, 1, device_type, READ_WRITE, bus_width, device_startadd_bit29to16, device_endadd_bit29to16);

   //GFC CSR Read: IP Rev
   read (0x17010004);

   //shif address by 1
   if (bus_width == BUS_WIDTH_16)  {
     write (0x17010074, 0x60008);
   }
   //FPGA_MISC_0
   if (bank_id == BANK0) {
     write (0x17040000, 0x00000010); //FPGA_MISC_0, set to FPGA flash   / chipsope bus 2 selected
   }
   else {
     write (0x17040000, 0x00000011); //FPGA_MISC_0, set to Daughter card   / chipsope bus 2 selected
   }
  
   //Get Device Start Add
   device_startadd = (get_device_startadd32bit(bank_id)+GFC_BASE);
   //print("\n\rdevice_startadd = %0x"); putnum(device_startadd);


   //work     gfc_write_read (bank_id, (device_startadd+0x00000000),(device_startadd+0x00000040), block_erase_en, (device_startadd+0x00000000),(device_startadd+0x00000002),device_type, bus_width, pattern_rand       , vendor, user_pattern) ;


   gfc_write_read (bank_id, (device_startadd+0x00000000),(device_startadd+0x00000002), block_erase_en, (device_startadd+0x00000000),(device_startadd+0x00000002),device_type, bus_width, pattern_rand       , vendor, user_pattern) ;
   gfc_write_read (bank_id, (device_startadd+0x00001004),(device_startadd+0x00001006), block_erase_en, (device_startadd+0x00001004),(device_startadd+0x00001006),device_type, bus_width, pattern_walking0   , vendor, user_pattern) ;
   gfc_write_read (bank_id, (device_startadd+0x00020060),(device_startadd+0x0002006a), block_erase_en, (device_startadd+0x00020060),(device_startadd+0x0002006a),device_type, bus_width, pattern_walking1   , vendor, user_pattern) ;
   gfc_write_read (bank_id, (device_startadd+0x0007fffc),(device_startadd+0x0007fffe), block_erase_en, (device_startadd+0x0007fffc),(device_startadd+0x0007fffe),device_type, bus_width, pattern_incremental, vendor, user_pattern) ;
   
   //fail: 16bit device needs to have aligned address
   //gfc_write_read (bank_id, (device_startadd+0x0008023f),(device_startadd+0x00080241), block_erase_en, (device_startadd+0x0008023f),(device_startadd+0x00080241),device_type, bus_width, pattern_a          , vendor, user_pattern) ;   
   gfc_write_read (bank_id, (device_startadd+0x0008023e),(device_startadd+0x00080240), block_erase_en, (device_startadd+0x0008023e),(device_startadd+0x00080240),device_type, bus_width, pattern_a          , vendor, user_pattern) ;
  
   //fail: //OCM size = 1MB only
   //gfc_write_read (bank_id, (device_startadd+0x0008023f),(device_startadd+0x00080241), block_erase_en, (device_startadd+0x0008023f),(device_startadd+0x00080241),device_type, bus_width, pattern_a          , vendor, user_pattern) ;
   gfc_write_read (bank_id, (device_startadd+0x00091100),(device_startadd+0x00091102), block_erase_en, (device_startadd+0x00091100),(device_startadd+0x00091102),device_type, bus_width, pattern_0, vendor, user_pattern) ;

   gfc_write_read (bank_id, (device_startadd+0x0007250a),(device_startadd+0x0007250c), block_erase_en, (device_startadd+0x0007250a),(device_startadd+0x0007250c),device_type, bus_width, pattern_f, vendor, user_pattern) ;
   gfc_write_read (bank_id, (device_startadd+0x0000090e),(device_startadd+0x00000910), block_erase_en, (device_startadd+0x0000090e),(device_startadd+0x00000910),device_type, bus_width, pattern_5, vendor, user_pattern) ;
   gfc_write_read (bank_id, (device_startadd+0x00000000),(device_startadd+0x00000002), block_erase_en, (device_startadd+0x00000000),(device_startadd+0x00000002),device_type, bus_width, pattern_a, vendor, user_pattern) ;
   //return 0;

}
unsigned int sram_test_basic0 (int bank_id, int device_type, int bus_width, int vendor, int device_startadd_bit29to16, int device_endadd_bit29to16){
   unsigned int test_startadd;
   unsigned int test_endadd;
   unsigned int i;
   unsigned int tmp;
   unsigned int test_startblock;
   unsigned int test_endblock; 
   unsigned int device_startadd;
   unsigned int incr_size;
   int          user_pattern = 0x02d0;
   int          block_erase_en = 1;
   unsigned int bstatus = 1;
   int error = 0;
	  short data_16bit, temp_val = 0x1234;


   //Disable default BANK address range first
//   disable_norsram_banks(BANK0);
//   disable_norsram_banks(BANK1);
//   disable_norsram_banks(BANK2);
//   disable_norsram_banks(BANK3);
//   disable_norsram_banks(BANK4);
//   disable_norsram_banks(BANK5);

   //setup bank1


   device_setup_w_add (bank_id, 1, device_type, READ_WRITE, bus_width, device_startadd_bit29to16, device_endadd_bit29to16);
   nor_sram_setup (bank_id, BURST_EN, MUX_DIS, N_TWT, N_FWT, N_BWT, N_CSN, N_OEN, N_WBN, N_WBF, N_TH, N_ALN, N_ALH);

   //GFC CSR Read: IP Rev
   read (0x17010004);
   
   if(bus_width == BUS_WIDTH_16) {
     //shif address by 1
     write (0x17010074, 0x60008);
   }
  
   //FPGA_MISC_0
   if (bank_id == BANK0) {
     write (0x17040000, 0x00000010); //FPGA_MISC_0, set to FPGA flash   / chipsope bus 2 selected
   }
   else {
     write (0x17040000, 0x00000011); //FPGA_MISC_0, set to Daughter card   / chipsope bus 2 selected
   }
   //Get Device Start Add
//   device_startadd = (get_device_startadd32bit(bank_id)+GFC_BASE);
//   printf("\n---------device_startadd = 0x%08x-------\r\n",device_startadd);
   device_startadd = get_device_startadd32bit(bank_id) + GFC_SRAM_BASE;
   printf("\n---------device_startadd = 0x%08x-------\r\n",device_startadd);

//	  printf("//---------------------- Test DATA in SRAM -------------------//\r\n");
//	  write8(device_startadd + 0x00000000, temp_val);
//	  data_16bit = read8 (device_startadd + 0x00000000);
//	  printf("device_startadd = 0x%08x, data_16bit =0x%08x \n", device_startadd+ 0x00000000, data_16bit);
//
//	  write8(device_startadd + 0x00200000, temp_val);
//	  data_16bit = read8 (device_startadd + 0x00200000);
//	  printf("device_startadd = 0x%08x, data_16bit =0x%08x \n", device_startadd+ 0x00200000, data_16bit);
//
//	  write8(device_startadd + 0x00400000, temp_val);
//	  data_16bit = read8 (device_startadd + 0x00400000);
//	  printf("device_startadd = 0x%08x, data_16bit =0x%08x \n", device_startadd+ 0x00400000, data_16bit);
//
//	  write8(device_startadd + 0x00600000, temp_val);
//	  data_16bit = read8 (device_startadd + 0x00600000);
//	  printf("device_startadd = 0x%08x, data_16bit =0x%08x \n", device_startadd+ 0x00600000, data_16bit);
//
//	  write8(device_startadd + 0x00800000, temp_val);
//	  data_16bit = read8 (device_startadd + 0x00800000);
//	  printf("device_startadd = 0x%08x, data_16bit =0x%08x \n", device_startadd+ 0x00800000, data_16bit);
//
//	  write8(device_startadd + 0x00a00000, temp_val);
//	  data_16bit = read8 (device_startadd + 0x00a00000);
//	  printf("device_startadd = 0x%08x, data_16bit =0x%08x \n", device_startadd+ 0x00a00000, data_16bit);
//
//	  write8(device_startadd + 0x00c00000, temp_val);
//	  data_16bit = read8 (device_startadd + 0x00c00000);
//	  printf("device_startadd = 0x%08x, data_16bit =0x%08x \n", device_startadd+ 0x00c00000, data_16bit);
//
//	  write8(device_startadd + 0x00e00000, temp_val);
//	  data_16bit = read8 (device_startadd + 0x00e00000);
//	  printf("device_startadd = 0x%08x, data_16bit =0x%08x \n", device_startadd+ 0x00e00000, data_16bit);
//
//	  write8(device_startadd + 0x00f00000, temp_val);
//	  data_16bit = read8 (device_startadd + 0x00f00000);
//	  printf("device_startadd = 0x%08x, data_16bit =0x%08x \n", device_startadd+ 0x00f00000, data_16bit);

	  //multiple block erase. write and read
//   gfc_write_read (bank_id, (device_startadd+0x00004f30),(device_startadd+0x00004f40),block_erase_en, (device_startadd+0x00004f30),(device_startadd+0x00004f40), device_type, bus_width, pattern_userdefine , vendor, user_pattern) ;
//   gfc_write_read (bank_id, (device_startadd+0x00053f30),(device_startadd+0x00053f40),block_erase_en, (device_startadd+0x00053f30),(device_startadd+0x00053f40), device_type, bus_width, pattern_rand , vendor, user_pattern) ;
//
//   //within the same block as above, multiple single write and one single read

   printf("\n xxxxxxxxxxxxxxxxxxxxxxxxxx Erase/Read/Write SRAM 1 = 0x%08x xxxxxxxxxxxxxxxxxxxxxxxxxx\r\n", bstatus);
   printf("\n --- Erase 0xFFFFFFFF in SRAM  ---\r\n");
   gfc_write_pattern(bank_id,(device_startadd+0x00000000), (device_startadd+0x00000002), pattern_f, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Write 0x0000AAAA in SRAM ---\r\n");
   gfc_write_pattern(bank_id,(device_startadd+0x00000000), (device_startadd+0x00000002), pattern_a, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Erase 0xFFFFFFFF in SRAM  ---\r\n");
   gfc_write_pattern(bank_id,(device_startadd+0x00000000), (device_startadd+0x00000002), pattern_f, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Write = 0x%08x in SRAM ---\r\n", pattern_1234);
   gfc_write_pattern(bank_id,(device_startadd+0x00000000), (device_startadd+0x00000002), pattern_1234, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Reading data in SRAM     ---\r\n");
   bstatus = gfc_read_pattern( bank_id,(device_startadd+0x00000000), (device_startadd+0x00000002), pattern_1234, device_type, bus_width, vendor, user_pattern) ;
   if (bstatus)
	   error++;

   printf("\n xxxxxxxxxxxxxxxxxxxxxxxxxx Erase/Read/Write SRAM 2 = 0x%08x xxxxxxxxxxxxxxxxxxxxxxxxxx\r\n", bstatus);
   printf("\n --- Erase 0xFFFFFFFF in SRAM  ---\r\n");
   gfc_write_pattern(bank_id,(device_startadd+0x00200000), (device_startadd+0x00200002), pattern_f, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Write 0x0000AAAA in SRAM ---\r\n");
   gfc_write_pattern(bank_id,(device_startadd+0x00200000), (device_startadd+0x00200002), pattern_a, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Erase 0xFFFFFFFF in SRAM  ---\r\n");
   gfc_write_pattern(bank_id,(device_startadd+0x00200000), (device_startadd+0x00200002), pattern_f, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Write = 0x%08x in SRAM ---\r\n", pattern_1234);
   gfc_write_pattern(bank_id,(device_startadd+0x00200000), (device_startadd+0x00200002), pattern_1234, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Reading data in SRAM     ---\r\n");
   bstatus = gfc_read_pattern( bank_id,(device_startadd+0x00200000), (device_startadd+0x00200002), pattern_1234, device_type, bus_width, vendor, user_pattern) ;
   if (bstatus)
	   error++;

   printf("\n xxxxxxxxxxxxxxxxxxxxxxxxxx Erase/Read/Write SRAM 3 = 0x%08x xxxxxxxxxxxxxxxxxxxxxxxxxx\r\n", bstatus);
   printf("\n --- Erase 0xFFFFFFFF in SRAM  ---\r\n");
   gfc_write_pattern(bank_id,(device_startadd+0x00400000), (device_startadd+0x00400002), pattern_f, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Write 0x0000AAAA in SRAM ---\r\n");
   gfc_write_pattern(bank_id,(device_startadd+0x00400000), (device_startadd+0x00400002), pattern_a, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Erase 0xFFFFFFFF in SRAM  ---\r\n");
   gfc_write_pattern(bank_id,(device_startadd+0x00400000), (device_startadd+0x00400002), pattern_f, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Write = 0x%08x in SRAM ---\r\n", pattern_1234);
   gfc_write_pattern(bank_id,(device_startadd+0x00400000), (device_startadd+0x00400002), pattern_1234, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Reading data in SRAM     ---\r\n");
   bstatus = gfc_read_pattern( bank_id,(device_startadd+0x00400000), (device_startadd+0x00400002), pattern_1234, device_type, bus_width, vendor, user_pattern) ;
   if (bstatus)
	   error++;

   printf("\n xxxxxxxxxxxxxxxxxxxxxxxxxx Erase/Read/Write SRAM 4 = 0x%08x xxxxxxxxxxxxxxxxxxxxxxxxxx\r\n", bstatus);
   printf("\n --- Erase 0xFFFFFFFF in SRAM  ---\r\n");
   gfc_write_pattern(bank_id,(device_startadd+0x00600000), (device_startadd+0x00600002), pattern_f, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Write 0x0000AAAA in SRAM ---\r\n");
   gfc_write_pattern(bank_id,(device_startadd+0x00600000), (device_startadd+0x00600002), pattern_a, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Erase 0xFFFFFFFF in SRAM  ---\r\n");
   gfc_write_pattern(bank_id,(device_startadd+0x00600000), (device_startadd+0x00600002), pattern_f, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Write = 0x%08x in SRAM ---\r\n", pattern_1234);
   gfc_write_pattern(bank_id,(device_startadd+0x00600000), (device_startadd+0x00600002), pattern_1234, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Reading data in SRAM     ---\r\n");
   bstatus = gfc_read_pattern( bank_id,(device_startadd+0x00600000), (device_startadd+0x00600002), pattern_1234, device_type, bus_width, vendor, user_pattern) ;
   if (bstatus)
	   error++;

   printf("\n xxxxxxxxxxxxxxxxxxxxxxxxxx Erase/Read/Write SRAM 5 xxxxxxxxxxxxxxxxxxxxxxxxxx\r\n");
   printf("\n --- Erase 0xFFFFFFFF in SRAM  ---\r\n");
   gfc_write_pattern(bank_id,(device_startadd+0x00800000), (device_startadd+0x00800002), pattern_f, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Write 0x0000AAAA in SRAM ---\r\n");
   gfc_write_pattern(bank_id,(device_startadd+0x00800000), (device_startadd+0x00800002), pattern_a, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Erase 0xFFFFFFFF in SRAM  ---\r\n");
   gfc_write_pattern(bank_id,(device_startadd+0x00800000), (device_startadd+0x00800002), pattern_f, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Write = 0x%08x in SRAM ---\r\n", pattern_1234);
   gfc_write_pattern(bank_id,(device_startadd+0x00800000), (device_startadd+0x00800002), pattern_1234, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Reading data in SRAM     ---\r\n");
   bstatus = gfc_read_pattern( bank_id,(device_startadd+0x00800000), (device_startadd+0x00800002), pattern_1234, device_type, bus_width, vendor, user_pattern) ;
   if (bstatus)
	   error++;

   printf("\n xxxxxxxxxxxxxxxxxxxxxxxxxx Erase/Read/Write SRAM 6 xxxxxxxxxxxxxxxxxxxxxxxxxx\r\n");
   printf("\n --- Erase 0xFFFFFFFF in SRAM  ---\r\n");
   gfc_write_pattern(bank_id,(device_startadd+0x00a00000), (device_startadd+0x00a00002), pattern_f, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Write 0x0000AAAA in SRAM ---\r\n");
   gfc_write_pattern(bank_id,(device_startadd+0x00a00000), (device_startadd+0x00a00002), pattern_a, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Erase 0xFFFFFFFF in SRAM  ---\r\n");
   gfc_write_pattern(bank_id,(device_startadd+0x00a00000), (device_startadd+0x00a00002), pattern_f, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Write = 0x%08x in SRAM ---\r\n", pattern_1234);
   gfc_write_pattern(bank_id,(device_startadd+0x00a00000), (device_startadd+0x00a00002), pattern_1234, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Reading data in SRAM     ---\r\n");
   bstatus = gfc_read_pattern( bank_id,(device_startadd+0x00a00000), (device_startadd+0x00a00002), pattern_1234, device_type, bus_width, vendor, user_pattern) ;
   if (bstatus)
	   error++;

   printf("\n xxxxxxxxxxxxxxxxxxxxxxxxxx Erase/Read/Write SRAM 7 xxxxxxxxxxxxxxxxxxxxxxxxxx\r\n");
   printf("\n --- Erase 0xFFFFFFFF in SRAM  ---\r\n");
   gfc_write_pattern(bank_id,(device_startadd+0x00c00000), (device_startadd+0x00c00002), pattern_f, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Write 0x0000AAAA in SRAM ---\r\n");
   gfc_write_pattern(bank_id,(device_startadd+0x00c00000), (device_startadd+0x00c00002), pattern_a, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Erase 0xFFFFFFFF in SRAM  ---\r\n");
   gfc_write_pattern(bank_id,(device_startadd+0x00c00000), (device_startadd+0x00c00002), pattern_f, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Write = 0x%08x in SRAM ---\r\n", pattern_1234);
   gfc_write_pattern(bank_id,(device_startadd+0x00c00000), (device_startadd+0x00c00002), pattern_1234, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Reading data in SRAM     ---\r\n");
   bstatus = gfc_read_pattern( bank_id,(device_startadd+0x00c00000), (device_startadd+0x00c00002), pattern_1234, device_type, bus_width, vendor, user_pattern) ;
   if (bstatus)
	   error++;

   printf("\n xxxxxxxxxxxxxxxxxxxxxxxxxx Erase/Read/Write SRAM 8 xxxxxxxxxxxxxxxxxxxxxxxxxx\r\n");
   printf("\n --- Erase 0xFFFFFFFF in SRAM  ---\r\n");
   gfc_write_pattern(bank_id,(device_startadd+0x00e00000), (device_startadd+0x00e00002), pattern_f, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Write 0x0000AAAA in SRAM ---\r\n");
   gfc_write_pattern(bank_id,(device_startadd+0x00e00000), (device_startadd+0x00e00002), pattern_a, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Erase 0xFFFFFFFF in SRAM  ---\r\n");
   gfc_write_pattern(bank_id,(device_startadd+0x00e00000), (device_startadd+0x00e00002), pattern_f, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Write = 0x%08x in SRAM ---\r\n", pattern_1234);
   gfc_write_pattern(bank_id,(device_startadd+0x00e00000), (device_startadd+0x00e00002), pattern_1234, device_type, bus_width, vendor, user_pattern) ;
   printf("\n --- Reading data in SRAM     ---\r\n");
   bstatus = gfc_read_pattern( bank_id,(device_startadd+0x00e00000), (device_startadd+0x00e00002), pattern_1234, device_type, bus_width, vendor, user_pattern) ;
   if (bstatus)
	   error++;
   return error;

}


void sram_write(int bank_id,void *address, int data, int bus_width){
    int *add_32bit;
    int data_32bit;
    int *OCMadd_32bit;
    
    short *add_16bit;
    short data_16bit;
    short *OCMadd_16bit;
    
    char *add_8bit;
    char data_8bit;
    char *OCMadd_8bit;

    unsigned int add_temp = address;
    unsigned int device_startadd = (get_device_startadd32bit(bank_id)+GFC_BASE);
    unsigned int temp = (add_temp - device_startadd);

    unsigned int outOfOCM_bound = over_ocm_boundry(bank_id, temp);
    temp = ocm_bank_base(bank_id) + (temp&0x00ffffff);
//    printf("\n ;=;=;=;=;= add_temp = 0x%08x, device_startadd = 0x%08x  ;=;=;=;=;= \r\n", add_temp, device_startadd );
//    printf("\n ;=;=;=;=;= outOfOCM_bound = 0x%08x, OCMadd_32bit = 0x%08x  ;=;=;=;=;= \r\n", outOfOCM_bound, OCMadd_32bit );

    OCMadd_32bit = temp;
    OCMadd_16bit = temp;
    OCMadd_8bit  = temp;
    
//    if (outOfOCM_bound == 1) {
//      printf("\n===== Warning: SRAM WRITE, No data write to OCM, out of OCM bounday\n\r");
//      if (bus_width == BUS_WIDTH_32){
//        add_32bit = address;
//        data_32bit = data;
//        write (add_32bit, data_32bit);
//      }
//      else if (bus_width == BUS_WIDTH_16){
//        add_16bit = address;
//        data_16bit = data;
//        write16 (add_16bit, data_16bit);
//      }
//      else {
//        add_8bit = address;
//        data_8bit = data;
//        write8 (add_8bit, data_8bit);
//      }
//
//    }
//    else {
   
      if (bus_width == BUS_WIDTH_32){
        add_32bit = address;
        data_32bit = data;
        write (add_32bit, data_32bit);   
//        write (OCMadd_32bit, data_32bit);
//        printf("\n ;=;=;=;=;= add_32bit = 0x%08x, data_32bit = 0x%08x  ;=;=;=;=;= \r\n", add_32bit, data_32bit );
//        printf("\n ;=;=;=;=;= OCMadd_32bit = 0x%08x, data_32bit = 0x%08x  ;=;=;=;=;= \r\n", OCMadd_32bit, data_32bit );

      }
      else if (bus_width == BUS_WIDTH_16){
        add_16bit = address;
        data_16bit = data;
        write16 (add_16bit, data_16bit);   
//        write16 (OCMadd_16bit, data_16bit);
        printf("\n ---- add_16bit = 0x%08x, data_16bit = 0x%08x  ---- \r\n", add_16bit, data_16bit );
//        printf("\n ;=;=;=;=;= OCMadd_16bit = 0x%08x, data_16bit = 0x%08x  ;=;=;=;=;= \r\n", OCMadd_16bit, data_16bit );

      }
      else {
        add_8bit = address;
        data_8bit = data;
        write8 (add_8bit, data_8bit);   
//        write8 (OCMadd_8bit, data_8bit);
        printf("\n ;=;=;=;=;= add_8bit = 0x%08x, data_8bit = 0x%08x  ;=;=;=;=;= \r\n", add_8bit, data_8bit );
        printf("\n");
//        printf("\n ;=;=;=;=;= OCMadd_8bit = 0x%08x, data_8bit = 0x%08x  ;=;=;=;=;= \r\n", OCMadd_8bit, data_8bit );

      }
//    }

}

unsigned int sram_read(int bank_id,void *address, int testpattern, int bus_width){
  int *add_32bit;
  int data_32bit;
  int *OCMadd_32bit;
  int OCMdata_32bit;

  short *add_16bit;
  short data_16bit;
  short *OCMadd_16bit;
  short OCMdata_16bit;

  char *add_8bit;
  char data_8bit;
  char *OCMadd_8bit;
  char OCMdata_8bit;
  unsigned int bstatus = 1;

  unsigned int add_temp = address;
  unsigned int device_startadd = (get_device_startadd32bit(bank_id)+GFC_BASE);
  unsigned int temp = (add_temp - device_startadd);

  unsigned int outOfOCM_bound = over_ocm_boundry(bank_id, temp);
  temp = ocm_bank_base(bank_id) + (temp&0x00ffffff);
//  printf("\n ------- add_temp = 0x%08x, device_startadd = 0x%08x  ------- \r\n", add_temp, device_startadd );
//  printf("\n ;=;=;=;=;= outOfOCM_bound = 0x%08x, OCMadd_32bit = 0x%08x  ;=;=;=;=;= \r\n", outOfOCM_bound, OCMadd_32bit );

  OCMadd_32bit = temp;
  OCMadd_16bit = temp;
  OCMadd_8bit  = temp;


    if  (bus_width == BUS_WIDTH_32) {
//	  printf("\n==================== BUS_WIDTH_32 ========================\n\r");
      add_32bit  = address; 
      data_32bit = read (add_32bit);
      printf("\n- add_32bit = 0x%08x, data_32bit = 0x%08x, Expected testpattern = 0x%08x -\r\n", add_32bit, data_32bit, testpattern);
      if(data_32bit != testpattern)  //data_32bit == pattern_5
			bstatus = 1;
      else
			bstatus = 0;
    }
    else if  (bus_width == BUS_WIDTH_16) {
//  	  printf("\n==================== BUS_WIDTH_16 ========================\n\r");
      add_16bit  = address; 
      data_16bit = read16 (add_16bit);
      printf("\n- add_16bit = 0x%08x, data_16bit = 0x%08x, Expected testpattern = 0x%08x -\r\n", add_16bit, data_16bit, testpattern);
      if(data_16bit != (testpattern & 0x0000FFFF)) //0x00005678)  //data_16bit == pattern_5
			bstatus = 1;
      else
			bstatus = 0;
    
    }
    else {
  	  printf("\n");
      add_8bit  = address; 
      data_8bit = read8 (add_8bit);
      printf("\n- add_8bit = 0x%08x, data_8bit = 0x%08x, testpattern = 0x%08x-\r\n", add_8bit, data_8bit, testpattern );
      if(data_8bit != (testpattern & 0x000000FF) )  //data_8bit == pattern_5
			bstatus = 1;
      else
			bstatus = 0;
    }

  return bstatus;
}
void sram_write_32(int bank_id,void *address, int data, int bus_width){
    int *add_32bit;
    int data_32bit;
    int *OCMadd_32bit;
    
    unsigned int add_temp = address;
    unsigned int device_startadd = (get_device_startadd32bit(bank_id)+GFC_BASE);
    unsigned int temp = (add_temp - device_startadd);
//    device_startadd = (get_device_startadd32bit(bank_id)+GFC_BASE);
    unsigned int outOfOCM_bound = over_ocm_boundry(bank_id, temp);
    temp = ocm_bank_base(bank_id) + (temp&0x00ffffff);
    printf("\n ;=;=;=;=;= add_temp = 0x%08x, device_startadd = 0x%08x  ;=;=;=;=;= \r\n", add_temp, device_startadd );
    printf("\n ;=;=;=;=;= outOfOCM_bound = 0x%08x, OCMadd_32bit = 0x%08x  ;=;=;=;=;= \r\n", outOfOCM_bound, OCMadd_32bit );

    OCMadd_32bit = temp;
    
    if (outOfOCM_bound == 1) {
        printf("\n===== Warning: SRAM WRITE, No data write to OCM, out of OCM bounday\r\n");
        add_32bit = address;
        data_32bit = data;
        write (add_32bit, data_32bit);   
    }
    else {
        add_32bit = address;
        data_32bit = data;
        write (add_32bit, data_32bit);   
        write (OCMadd_32bit, data_32bit); 
        printf("\n ;=;=;=;=;= add_32bit = 0x%08x, data_32bit = 0x%08x  ;=;=;=;=;= \r\n", add_32bit, data_32bit );
        printf("\n ;=;=;=;=;= OCMadd_32bit = 0x%08x, data_32bit = 0x%08x  ;=;=;=;=;= \r\n", OCMadd_32bit, data_32bit );

    }
}

unsigned int sram_read_32(int bank_id,void *address, int bus_width){
  int *add_32bit;
  int data_32bit;
  int *OCMadd_32bit;
  int OCMdata_32bit;
  unsigned int bstatus = 1;

  unsigned int add_temp = address;
  unsigned int device_startadd = (get_device_startadd32bit(bank_id)+GFC_BASE);
  unsigned int temp = (add_temp - device_startadd);

  unsigned int outOfOCM_bound = over_ocm_boundry(bank_id, temp);
  temp = ocm_bank_base(bank_id) + (temp&0x00ffffff);

  OCMadd_32bit = temp;
  printf("\n ;=;=;=;=;= add_temp = 0x%08x, device_startadd = 0x%08x  ;=;=;=;=;= \r\n", add_temp, device_startadd );
  printf("\n ;=;=;=;=;= outOfOCM_bound = 0x%08x, OCMadd_32bit = 0x%08x  ;=;=;=;=;= \r\n", outOfOCM_bound, OCMadd_32bit );

  if (outOfOCM_bound == 1) {
    printf("\n===== Warning: SRAM READ, No data read from OCM, out of OCM bounday\n\r");
    add_32bit  = address; 
    data_32bit = read (add_32bit);
    
  }
  else {
    add_32bit  = address; 
    data_32bit = read (add_32bit);
    OCMdata_32bit = read( OCMadd_32bit); 
    printf("\n ;=;=;=;=;= add_32bit = 0x%08x, data_32bit = 0x%08x  ;=;=;=;=;= \r\n", add_32bit, data_32bit );
    printf("\n ;=;=;=;=;= OCMadd_32bit = 0x%08x, OCMdata_32bit = 0x%08x  ;=;=;=;=;= \r\n", OCMadd_32bit, OCMdata_32bit );

    if(OCMdata_32bit != data_32bit)
    {
      //print("ERROR: SRAM Read Data Mismatch: Expected = %0x"); putnum(OCMdata_32bit); //print(" Actual = %0x");  putnum(data_32bit);  //print("\n\r");
      // datnguyen      error(0);
	    printf("\n==================== SRAM FAIL ========================\n\r");
		bstatus = 1;
    }
    else
    {
	    printf("\n==================== SRAM PASS ========================\n\r");
    	bstatus = 0;
    }
  } 
  return bstatus;
}




unsigned int  sram_test_default0_32 (int bank_id, int device_type, int bus_width, int vendor, int device_startadd_bit29to16, int device_endadd_bit29to16) {
  
   unsigned int test_startadd;
   unsigned int test_endadd;
   unsigned int i;
   unsigned int tmp;
   unsigned int test_startblock;
   unsigned int test_endblock; 
   unsigned int device_startadd;
   unsigned int incr_size;
   int          user_pattern = 0x20d0;
   int          block_erase_en = 1;
   unsigned int bstatus = 1;
 
   //!!!, chip select
   write (0x17040000, 0x02000011); //FPGA_MISC_0, set to Daughter card   / chipscope bus 2 selected
  
   //Disable default BANK address range first
   disable_norsram_banks(BANK0);
   disable_norsram_banks(BANK1);
   disable_norsram_banks(BANK2);
   disable_norsram_banks(BANK3);
   disable_norsram_banks(BANK4);
   disable_norsram_banks(BANK5);

   //setup bank1
   device_setup_w_add (bank_id, 1, device_type, READ_WRITE, bus_width, device_startadd_bit29to16, device_endadd_bit29to16);
   nor_sram_setup (bank_id, BURST_DIS, MUX_DIS, N_TWT, N_FWT, N_BWT, N_CSN, N_OEN, N_WBN, N_WBF, N_TH, N_ALN, N_ALH);

   //GFC CSR Read: IP Rev
   read (0x17010004);
 
   

   //shif address by 1
   if (bus_width == BUS_WIDTH_16)  {
     write (0x17010074, 0x60008);
   }
   //FPGA_MISC_0
   if (bank_id == BANK0) {
     write (0x17040000, 0x00000010); //FPGA_MISC_0, set to FPGA flash   / chipsope bus 2 selected
   }
   else {
     write (0x17040000, 0x02000011); //FPGA_MISC_0, set to Daughter card   / chipsope bus 2 selected, //!!!
     //write (0x17040000, 0x00000011); //FPGA_MISC_0, set to Daughter card   / chipsope bus 2 selected
   }
  
   //Get Device Start Add
   device_startadd = (get_device_startadd32bit(bank_id)+GFC_BASE);
   //print("\n\rdevice_startadd = %0x"); putnum(device_startadd);
   
   //simple burst
   printf("\n ======================== device_startadd = 0x%08x ====================", device_startadd);
   printf("\n ========================= checking write SRAM =========================  \r\n");
   sram_write(bank_id,(device_startadd+0x0), 0x12345678, bus_width);
//   sram_write_32(bank_id,(device_startadd+0x0), 0x12345678, bus_width);
//   sram_write_32(bank_id,(device_startadd+0x4), 0xdeadbeef, bus_width);
   printf("\n ========================= checking Read SRAM =========================  \r\n");
   bstatus = sram_read(bank_id,(device_startadd+0x0), pattern_1234, bus_width);
//   bstatus = sram_read_32(bank_id,(device_startadd+0x0), bus_width);
//   bstatus = sram_read_32(bank_id,(device_startadd+0x4), bus_width);
//   bstatus = sram_read_32(bank_id,(device_startadd+0x0), bus_width);
//   bstatus = sram_read_32(bank_id,(device_startadd+0x4), bus_width);
   

   return bstatus;

}

