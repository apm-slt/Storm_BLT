/*
 */
//#include <stdio.h>
#include "../include/platform.h"
#include "../include/test_util.h"
#include "../include/gfc_common.h"
#include "../include/gfc_nand.h"
#include "../include/gfc.h"
#define DSB_SY_CALL1() asm volatile("dsb sy")
#define __iomem
#define OUTLE_32(addr,val) __raw_writel(val,(void *)(u64 )(addr))
#define INLE_32(addr) __raw_readl((void*) (u64)( addr))
#define CONFIG_SYS_GFC_BASE			  0x17010000
#define CONFIG_SYS_NAND_CS				2

//Tinh-SLT:
#define read read_gfc
#define write write_gfc
#define read8 read8_gfc
#define write8 write8_gfc
#define read16 read16_gfc
#define write16 write16_gfc

int nand_ecc_even_bound;
static inline u32 __raw_readl(const volatile void __iomem *addr)
{
	u32 val;
	asm volatile("ldr %w0, [%1]" : "=r" (val) : "r" (addr));
	return val;
}
static inline void __raw_writel(u32 val, volatile void __iomem *addr)
{
	asm volatile("str %w0, [%1]" : : "r" (val), "r" (addr));
}
unsigned int nand(){
	unsigned int bstatus = 1;
	int nand_buffer_startadd = GFC_NAND_BASE ; //NAND_BUFFER_STARTADD ;
	int nand_buffer_endadd   = GFC_NAND_BASE + 0x1000000; //NAND_BUFFER_ENDADD ;
	char c;

	device_setup(BANK2, BANKVALID, NAND, READ_WRITE, BUS_WIDTH_8);
	nand_buffer_addr(nand_buffer_startadd, nand_buffer_endadd);
	nand_ecc_setup(BANK2, 0, 0, 0);

//	nand_pio_reset(BANK2);
//	nand_device_id(BANK2, BUS_WIDTH_8);

	nand_pio_reset(BANK2);
	nand_pio_erase(BANK2, 0x00000000);
	arch_timer_usdelay(1000);
	wait_completion();
	nand_pio_force_status_read(BANK2);

	nand_pio_reset(BANK2);
	nand_pio_wr_setup(BANK2, 0x00000000, 0x0, 0x800, 0xABABABAB);
	arch_timer_usdelay(1000);
	wait_completion();
	nand_pio_force_status_read(BANK2);

	bstatus = nand_pio_rd_setup(BANK2, 0x00000000, 0x0, 0x40);
	arch_timer_usdelay(1000);
	wait_completion();
	nand_pio_force_status_read(BANK2);

	return bstatus;
};

unsigned int nand_test() {

  int bstatus = 1;
  bstatus = nand_test_default1 (BANK2, NAND, BUS_WIDTH_8, ECC_OFF, HAMMING, ECC_BCH4);
  //nand_test_default1 (BANK3, NAND, BUS_WIDTH_16, ECC_ON, HAMMING, ECC_BCH4);
  //nand_test_default1 (BANK3, NAND, BUS_WIDTH_16, ECC_ON, BCH, ECC_BCH4);
  //nand_test_default1 (BANK3, NAND, BUS_WIDTH_16, ECC_ON, BCH, ECC_BCH8);
  return bstatus;
};
unsigned int nand_test_default1 (int bank_id, int device_type, int bus_width, int ecc_on_off, int ecc_alg, int bcht) {
  
   int nand_buffer_startadd = NAND_BUFFER_STARTADD ;
   int nand_buffer_endadd   = NAND_BUFFER_ENDADD ;
   int nand_rowadd          = 0x0;
   int nand_coladd          = 0x0;
   int data_byte_size;
   int bstatus = 1;
   
   unsigned int i;
   unsigned int tmp;
   unsigned int incr_size;
   int          user_pattern = 0x20d0;
   int          block_erase_en = 1;
   
   int test_startadd;
   int test_endadd;
  
   int device_size = 0x1000;
   int block_size  = 0x80;
   int page_size   = 0x1000;
    
   device_setup(bank_id, BANKVALID, NAND, READ_WRITE, bus_width);
   nand_setup (bank_id, ecc_on_off, ecc_alg, bcht, device_size, block_size, page_size);
   
   //GFC CSR Read: IP Rev
   read (0x17010004);

   //shif address by 1
   write (0x17010074, 0xe0008);  //even bound = 1  //temp kumar
 
    
   //FPGA_MISC_0
   if (bank_id == BANK0) {
     write (0x17040000, 0x00000010); //FPGA_MISC_0, set to FPGA flash   / chipsope bus 2 selected
   }
   else {
     write (0x17040000, 0x00000011); //FPGA_MISC_0, set to Daughter card   / chipsope bus 2 selected
   }
   
   //PIO setup
  nand_buffer_addr(nand_buffer_startadd, nand_buffer_endadd);

  nand_pio_reset(bank_id);
  

  printf("============= nand_device_id =============");
  bstatus = nand_device_id(bank_id, bus_width);
  if (ecc_on_off == ECC_OFF) {
	  bstatus = nand_device_id(bank_id, bus_width);
  }


  int k;

  nand_pio_erase(bank_id, nand_rowadd);

  nand_pio_force_status_read(bank_id);

  for(k=0; k<1; k++){
  //========== pattern_rand
  //nand write
  if (ecc_on_off == ECC_ON) {
    data_byte_size = 512;
  }
  else {
    data_byte_size = 16;
  }
  test_startadd  = (nand_buffer_startadd)|GFC_BASE;
  test_endadd    = test_startadd+data_byte_size;

  nand_pio_wr_setup(bank_id, nand_rowadd, nand_coladd, data_byte_size, 0xABABABAB);
  gfc_write_pattern(bank_id, test_startadd, test_endadd,  pattern_rand, NAND, bus_width, VENDOR_INFO_NONEED, user_pattern) ;
  wait_completion(); 

  //correupt data on purpose
  if((ecc_on_off == ECC_ON) & (NAND0_ECC_ERRTEST == 1)) {
    for (i=0;i<k; i++)  {
	  if  (bus_width == BUS_WIDTH_16)
         while(nand_corrupt_single_bit (bank_id,nand_rowadd,nand_coladd+(rand()%0x100),0,15));
	  else
         while(nand_corrupt_single_bit (bank_id,nand_rowadd,nand_coladd+(rand()%0x200),0,7));
    }
  }
 }
// read one more time
  for(k=0; k<1; k++){
  nand_pio_rd_setup(bank_id, nand_rowadd, nand_coladd, data_byte_size);
  gfc_read_pattern(bank_id,test_startadd, test_endadd,pattern_f, NAND, bus_width, VENDOR_INFO_NONEED, user_pattern) ;
  wait_completion(); 
  flush_pio_rd_buffer();
  gfc_status_check();
  nand_rowadd++;
 }

/*
  //========== pattern_0 
  //nand write
  nand_pio_erase(bank_id, nand_rowadd);
  nand_pio_wr_setup(bank_id, nand_rowadd, nand_coladd, data_byte_size, 0xABABABAB);
  gfc_write_pattern(bank_id,test_startadd, test_endadd,  pattern_0, NAND, bus_width, VENDOR_INFO_NONEED, user_pattern) ;
  wait_completion(); 

  //nand read
  nand_pio_rd_setup(bank_id, nand_rowadd, nand_coladd, data_byte_size);
  gfc_read_pattern(bank_id,test_startadd, test_endadd,pattern_f, NAND, bus_width, VENDOR_INFO_NONEED, user_pattern) ;
  wait_completion(); 
  flush_pio_rd_buffer();

  
  //========== pattern_f 
  //nand write
  nand_pio_erase(bank_id, nand_rowadd);

  nand_pio_wr_setup(bank_id, nand_rowadd, nand_coladd, data_byte_size, 0xABABABAB);
  gfc_write_pattern(bank_id,test_startadd, test_endadd,  pattern_f, NAND, bus_width, VENDOR_INFO_NONEED, user_pattern) ;
  wait_completion(); 

  //nand read
  nand_pio_rd_setup(bank_id, nand_rowadd, nand_coladd, data_byte_size);
  gfc_read_pattern(bank_id,test_startadd, test_endadd,pattern_f, NAND, bus_width, VENDOR_INFO_NONEED, user_pattern) ;
  wait_completion(); 
  flush_pio_rd_buffer();  

//nand read
  nand_pio_rd_setup(bank_id, nand_rowadd, nand_coladd, data_byte_size);
  gfc_read_pattern(bank_id,test_startadd, test_endadd,pattern_f, NAND, bus_width, VENDOR_INFO_NONEED, user_pattern) ;
  wait_completion(); 
  flush_pio_rd_buffer();

  
  //========== pattern_5 
  //nand write
  nand_pio_erase(bank_id, nand_rowadd);

  nand_pio_wr_setup(bank_id, nand_rowadd, nand_coladd, data_byte_size, 0xABABABAB);
  gfc_write_pattern(bank_id,test_startadd, test_endadd,  pattern_5, NAND, bus_width, VENDOR_INFO_NONEED, user_pattern) ;
  wait_completion(); 

  //nand read
  nand_pio_rd_setup(bank_id, nand_rowadd, nand_coladd, data_byte_size);
  gfc_read_pattern(bank_id,test_startadd, test_endadd,pattern_f, NAND, bus_width, VENDOR_INFO_NONEED, user_pattern) ;
  wait_completion(); 
  flush_pio_rd_buffer();


  //========== pattern_a 
  //nand write
  nand_pio_erase(bank_id, nand_rowadd);

  nand_pio_wr_setup(bank_id, nand_rowadd, nand_coladd, data_byte_size, 0xABABABAB);
  gfc_write_pattern(bank_id,test_startadd, test_endadd,  pattern_a, NAND, bus_width, VENDOR_INFO_NONEED, user_pattern) ;
  wait_completion(); 

  //nand read
  nand_pio_rd_setup(bank_id, nand_rowadd, nand_coladd, data_byte_size);
  gfc_read_pattern(bank_id,test_startadd, test_endadd,pattern_f, NAND, bus_width, VENDOR_INFO_NONEED, user_pattern) ;
  wait_completion(); 
  flush_pio_rd_buffer();  

  //========== pattern_incremental
  //nand write
  nand_pio_erase(bank_id, nand_rowadd);
  
  nand_pio_wr_setup(bank_id, nand_rowadd, nand_coladd, data_byte_size, 0xABABABAB);
  gfc_write_pattern(bank_id,test_startadd, test_endadd,  pattern_incremental, NAND, bus_width, VENDOR_INFO_NONEED, user_pattern) ;
  wait_completion(); 

  //nand read
  nand_pio_rd_setup(bank_id, nand_rowadd, nand_coladd, data_byte_size);
  gfc_read_pattern(bank_id,test_startadd, test_endadd,pattern_f, NAND, bus_width, VENDOR_INFO_NONEED, 0x00001234) ;
  wait_completion(); 
  flush_pio_rd_buffer();  
*/
  // datnguyen return 0;
  return bstatus;
}


void nand_test_interleave (int bank_id, int test_type, int bus_width, int ecc_on_off, int ecc_alg, int bcht, int nand_rowadd, int nand_coladd, int data_byte_size, int user_pattern, int nand_buffer_startadd, int nand_buffer_endadd) {
/*
   unsigned int i;
   unsigned int tmp;
   unsigned int incr_size;
   int          block_erase_en = 1;
   
   int test_startadd;
   int test_endadd;

   //PIO setup
   nand_buffer_addr(nand_buffer_startadd, nand_buffer_endadd);
   nand_pio_reset(bank_id);
  
   //device_ID
   if (ecc_on_off == ECC_OFF) { nand_device_id(bank_id, bus_width); }

  int k;

  nand_pio_erase(bank_id, nand_rowadd);

  if (ecc_on_off == ECC_ON) { data_byte_size = 512; }
  else                      { data_byte_size = 16;  }


  if (test_type = WRITE_TEST) {
    for(k=0; k<1; k++){
      //========== pattern_rand
      //nand write
    
      test_startadd  = (nand_buffer_startadd)|GFC_BASE;
      test_endadd    = test_startadd+data_byte_size;
      
      nand_pio_wr_setup(bank_id, nand_rowadd, nand_coladd, data_byte_size, 0xABABABAB);
      gfc_write_pattern(bank_id, test_startadd, test_endadd,  pattern_rand, NAND, bus_width, VENDOR_INFO_NONEED, user_pattern) ;
      wait_completion(); 
      
      //correupt data on purpose
      if((ecc_on_off == ECC_ON) & (NAND0_ECC_ERRTEST == 1)) {
        for (i=0;i<k; i++)  { 
	      if(bus_width == BUS_WIDTH_16)
		    while(nand_corrupt_single_bit (bank_id,nand_rowadd,nand_coladd+(rand()%0x200),0,15)); 
		  else
		    while(nand_corrupt_single_bit (bank_id,nand_rowadd,nand_coladd+(rand()%0x200),0,7)); 
		}
      }
    }
  }

  // Both write/read test need this part
  for(k=0; k<1; k++){
    nand_pio_rd_setup(bank_id, nand_rowadd, nand_coladd, data_byte_size);
    gfc_read_pattern(bank_id,test_startadd, test_endadd,pattern_f, NAND, bus_width, VENDOR_INFO_NONEED, 0x00001234) ;
    wait_completion(); 
    flush_pio_rd_buffer();
    nand_rowadd++;
  }

  return 0;   
*/
}

void nand_pio_ecc_test (int bank_id, int bus_width ) {
/*
   int nand_buffer_startadd = NAND_BUFFER_STARTADD ;
   int nand_buffer_endadd   = NAND_BUFFER_ENDADD ;
   int nand_rowadd          = 0x0;
   int nand_coladd          = 0x0;
   int data_byte_size;
   
   unsigned int i;
   unsigned int tmp;
   unsigned int incr_size;
   int          user_pattern = 0x20d0;
   int          block_erase_en = 1;
   
   int test_startadd;
   int test_endadd;
  
   int device_size = 0x1000;
   int block_size  = 0x80;
   int page_size   = 2048;
   int ecc_on_off = ECC_ON;
   int ecc_alg = 0;
   int bcht =0;
    
   nand_init();
   device_setup(bank_id, BANKVALID, NAND, READ_WRITE, bus_width);
   nand_setup (bank_id, ecc_on_off, ecc_alg, bcht, device_size, block_size, page_size);
   
   //GFC CSR Read: IP Rev
   read (0x17010004);

   //shif address by 1
   write (0x17010074, 0xe0008);  //even bound = 1  //temp kumar
   nand_ecc_even_bound = 1;
 
    
   //FPGA_MISC_0
   if (bank_id == BANK0) {
     write (0x17040000, 0x00000010); //FPGA_MISC_0, set to FPGA flash   / chipsope bus 2 selected
   }
   else {
     write (0x17040000, 0x00000011); //FPGA_MISC_0, set to Daughter card at svdc  / chipsope bus 2 selected
     //write (0x17040000, 0x00000005); //FPGA_MISC_0, set to Daughter card at pnq
   }
   
   //PIO setup
  nand_buffer_addr(nand_buffer_startadd, nand_buffer_endadd);

  nand_pio_reset(bank_id);
  
  nand_pio_erase(bank_id, nand_rowadd);
  pio_ecc_err_data_spare(bank_id,bus_width,1,0);
  pio_ecc_err_data_spare(bank_id,bus_width,1,1);
  pio_ecc_err_data_spare(bank_id,bus_width,1,2);

  return 0;   
*/
}

void pio_ecc_err_data_spare(int bank_id, int bus_width, int num_trans, int data_spare) {
/*
  int indx;
  int row_addr,col_addr;
  int pio_data_size;

  //row_addr = 0x000000bf;
  row_addr = rand_num(1,0x1ff);
  col_addr = 0;
  nand_pio_erase(bank_id, row_addr);
  pio_data_size = 512;

  for (indx=0; indx<num_trans; indx=indx+1) {

    // Single-bit Hamming
     //print ("=== 1-bit Hamming ===\n\r");
    nand_pio_ecc(bank_id,row_addr,col_addr,pio_data_size,bus_width, 0, 1, data_spare);

    // Double-bit Hamming  
    ////print ("=== 2-bit Hamming   ===\n\r");
    //nand_pio_ecc(bank_id,row_addr,col_addr,pio_data_size,bus_width, 0, 2, data_spare);
    
    // 1-bit BCH_4
    //print ("=== 1-bit BCH_4 ===\n\r");
    nand_pio_ecc(bank_id,row_addr,col_addr,pio_data_size,bus_width, 1, 1, data_spare);
    
    // 2-bit BCH_4
    //print ("=== 2-bit BCH_4 ===\n\r");
    nand_pio_ecc(bank_id,row_addr,col_addr,pio_data_size,bus_width, 1, 2, data_spare);

    // 3-bit BCH_4
    //print ("=== 3-bit BCH_4 ===\n\r");
    nand_pio_ecc(bank_id,row_addr,col_addr,pio_data_size,bus_width, 1, 3, data_spare);
    
    // 4-bit BCH_4
    //print ("=== 4-bit BCH_4 ===\n\r");
    nand_pio_ecc(bank_id,row_addr,col_addr,pio_data_size,bus_width, 1, 4, data_spare);

    // 1-bit BCH_8
    //print ("=== 1-bit BCH_8 ===\n\r");
    nand_pio_ecc(bank_id,row_addr,col_addr,pio_data_size,bus_width, 2, 1, data_spare);
    
    // 2-bit BCH_8
    //print ("=== 2-bit BCH_8 ===\n\r");
    nand_pio_ecc(bank_id,row_addr,col_addr,pio_data_size,bus_width, 2, 2, data_spare);
    
    // 3-bit BCH_8
    //print ("=== 3-bit BCH_8 ===\n\r");
    nand_pio_ecc(bank_id,row_addr,col_addr,pio_data_size,bus_width, 2, 3, data_spare);
    
    // 4-bit BCH_8
    //print ("=== 4-bit BCH_8 ===\n\r");
    nand_pio_ecc(bank_id,row_addr,col_addr,pio_data_size,bus_width, 2, 4, data_spare);
    
    // 5-bit BCH_8
    //print ("=== 5-bit BCH_8 ===\n\r");
    nand_pio_ecc(bank_id,row_addr,col_addr,pio_data_size,bus_width, 2, 5, data_spare);
    
    // 6-bit BCH_8
    //print ("=== 6-bit BCH_8 ===\n\r");
    nand_pio_ecc(bank_id,row_addr,col_addr,pio_data_size,bus_width, 2, 6, data_spare);
    
    // 7-bit BCH_8
    //print ("=== 7-bit BCH_8 ===\n\r");
    nand_pio_ecc(bank_id,row_addr,col_addr,pio_data_size,bus_width, 2, 7, data_spare);
    
    // 8-bit BCH_8
    //print ("=== 8-bit BCH_8 ===\n\r");
    nand_pio_ecc(bank_id,row_addr,col_addr,pio_data_size,bus_width, 2, 8, data_spare);

  };
*/
};
void nand_pio_ecc(int bank_id, int row_addr, int col_addr, int pio_size, int bus_width, int ecc_algo, int num_errors, int err_loc){

  int i;
  int success, act_num_errors = 0;
  int col = 0x0000;
  int row;
  int pass;
  int togl;
  // Which chunk you want the errors.
  int chunk_no = 1;
  int chunk_size = 512;
  int max_corr_err = 1;
  int force_spare_offset = 0;
  int act_cor_err_t,act_uncor_err_t;
  int exp_cor_err_t,exp_uncor_err_t;

   int nand_buffer_startadd = NAND_BUFFER_STARTADD ;
   int nand_buffer_endadd   = NAND_BUFFER_ENDADD ;
   int test_startadd;
   int test_endadd;
   int ecc_type,bch_type;
   int user_pattern = 0x20d0;
   int page_size = 2048;
   // setup the ecc configuration
   if(ecc_algo == 0) {
      ecc_type = HAMMING;
	  bch_type = ECC_BCH4;
   }
   else if(ecc_algo == 1) {
      ecc_type = BCH;
	  bch_type = ECC_BCH4;
   }
   else if(ecc_algo == 2) {
      ecc_type = BCH;
	  bch_type = ECC_BCH8;
   }
  nand_bank_ctrl0 (bank_id, ECC_ON, ecc_type, force_spare_offset);
  nand_bank_bch (bank_id, NAND0_BCH_N, bch_type, NAND0_BCH_K);
  // Erase the block before running test so that we don't have any pre-written "corrupt data". It would result in to more errors than expected.
  nand_pio_erase(bank_id, row_addr);

  // Set chunk parameters.
  switch(ecc_algo) {
  case 0:
    chunk_size = 256;
    break;
  case 1:
    chunk_size = 512;
    break;
  case 2:
    chunk_size = 512;
    break;
  };

  //chunk_no = rand_num(1, (((dma_size*64)%page_size)/chunk_size));
  chunk_no = rand_num(1, (pio_size/chunk_size));

  // Put DMA Write and Read functionality in function.

  ////print("Writing NAND Device: row_addr = ."); putnum(row_addr); //print("col_addr=");putnum(col_addr);//print("\n\r");
  test_startadd  = (nand_buffer_startadd)|GFC_BASE;
  test_endadd    = test_startadd+pio_size;

  nand_pio_wr_setup(bank_id, row_addr, col_addr, pio_size, 0xABABABAB);
  gfc_write_pattern(bank_id, test_startadd, test_endadd,  pattern_rand, NAND, bus_width, VENDOR_INFO_NONEED, user_pattern) ;
  wait_completion();

  // void nand_corrupt_single_bit (int bank_id,int dev_addr_addr,int col_addr, int bit_position){
  for (i=0; i<num_errors; i=i+1) {
    if (err_loc > 1) { // Data, Spare Mix. Insert altearnate errors in data and spare.
       //print ("Inserting Err in Data+Spare Area");//print("\n\r");
    	togl = rand()%2;
       //print("togl = ");putnum(togl);//print("\n\r");
       if(togl == 1) {
	      col = rand_num((chunk_size*(chunk_no-1)), (chunk_size*chunk_no)-1);
		   //print("corrupting in the data area\n\r ");
	      if(bus_width == 1) {
            col = col/2;
            //print("Calling corrupt function: row = "); putnum(row_addr); //print("col=");putnum(col);//print("\n\r");
            success = nand_corrupt_single_bit (bank_id, row_addr, col,0,15);
	      }
	      else
            success = nand_corrupt_single_bit (bank_id, row_addr, col,0,7);
       } 
	   else { 
		  //print("corrupting in the ecc area\n\r ");
	     success = corrupt_ecc_area(bank_id,ecc_algo,chunk_no,nand_ecc_even_bound,page_size,row_addr,bus_width);
	   }
       
    } else {
      if (err_loc == 1) { // Data Area
	     //print ("Inserting Err in Data Area");//print("\n\r");
    	 col = rand_num((chunk_size*(chunk_no-1)), (chunk_size*chunk_no)-1);
		 if(bus_width == 1) {
           col = col/2;
           //print("Calling corrupt function: row = "); putnum(row_addr); //print("col=");putnum(col);//print("\n\r");
           success = nand_corrupt_single_bit (bank_id, row_addr, col,0,15);
		 }
		 else
           success = nand_corrupt_single_bit (bank_id, row_addr, col,0,7);
      } else { // Spare Area
	     //print ("Inserting Err in spare Area");//print("\n\r");
		 success = corrupt_ecc_area(bank_id,ecc_algo,chunk_no,nand_ecc_even_bound,page_size,row_addr,bus_width);
      };    
    };
    if (success == 0) {
      ////print("Incrementing act_num_errors ...\n\r");
      act_num_errors = act_num_errors + 1;
    };

  };

  //print("Actual Inserted Errors = ");putnum(act_num_errors);//print("\tWhereas num_errors = ");putnum(num_errors);//print("\n\r");

  // Recover the configuration if it is changed in corrupt function.
  nand_bank_ctrl0 (bank_id, ECC_ON, ecc_type, force_spare_offset);
  nand_bank_bch (bank_id, NAND0_BCH_N, bch_type, NAND0_BCH_K);

  ////print("Reading NAND Device: row_addr = ."); putnum(row_addr); //print("col_addr=");putnum(col_addr);//print("\n\r");
  nand_pio_rd_setup(bank_id, row_addr, col_addr, pio_size);
  wait_completion(); 
  gfc_read_pattern(bank_id,test_startadd, test_endadd,pattern_f, NAND, bus_width, VENDOR_INFO_NONEED, 0x00001234) ;
  flush_pio_rd_buffer();

  //print("Reading ECC Err Counters ::\n\r");
  act_cor_err_t = read(0x1701223c + bank_id*0x1000);
  ////print("Reading ECC Uncor Counter ::\n\r");
  act_uncor_err_t = read(0x17012240 + bank_id*0x1000);

  //failed_addr_t = (dev_addr)|col;

  switch (ecc_algo) {
  case 0:
    if (num_errors == 1) {
      exp_cor_err_t = act_num_errors;
      exp_uncor_err_t = 0;
      if (act_cor_err_t != 1) {
	//print ("ERROR: Hamming: SEC Error Count: Exp: 1 Act: ");putnum(act_cor_err_t);//print("\n\r");
	pass = 0;
	// datnguyen exit(1);
      }
    } else if (num_errors == 2) {

      exp_cor_err_t = 0;
      exp_uncor_err_t = 1;

      if (act_uncor_err_t != 1) {
	//print ("ERROR: Hamming: DED Error Count: Exp: 1 Act: ");putnum(act_uncor_err_t);//print("\n\r");
	pass = 0;
	// datnguyen     exit(1);
      } else {
	pass = 1;
      };
    } 
    
    break;
    
  case 1:
    if (num_errors <= 4) {
      exp_cor_err_t = act_num_errors;
      exp_uncor_err_t = 0;

      if (act_cor_err_t != act_num_errors) {
	//print ("ERROR: BCH_4: SEC Error Count: Exp: ");putnum(act_num_errors);//print("Act: ");putnum(act_cor_err_t);//print("\n\r");
	pass = 0;
	// datnguyen exit(1);
      }
    } else {

      // Logic for Uncorrectable Error: In this case, ignore Data Errors.
      pass = 1;

      exp_cor_err_t = 0;
      exp_uncor_err_t = 1;

      if (act_uncor_err_t != 1) {
	//print ("ERROR: BCH_4: DED Error Count: Exp: 1 Act: ");putnum(act_uncor_err_t);//print("\n\r");
	pass = 0;
	// datnguyen     exit(1);
      }
    };

    break;

  case 2:

    if (num_errors <= 8) {
      exp_cor_err_t = act_num_errors;
      exp_uncor_err_t = 0;

      if (act_cor_err_t != act_num_errors) {
	//print ("ERROR: BCH_8: SEC Error Count: Exp: ");putnum(act_num_errors);//print("\tAct: ");putnum(act_cor_err_t);//print("\n\r");
	pass = 0;
	// datnguyen     exit(1);
      }
    } else {

      // Logic for Uncorrectable Error: In this case, ignore Data Errors.
      pass = 1;

      exp_cor_err_t = 0;
      exp_uncor_err_t = 1;

      if (act_uncor_err_t != 1) {
	//print ("ERROR: BCH_8: DED Error Count: Exp: 1 Act: ");putnum(act_uncor_err_t);//print("\n\r");
	pass = 0;
	// datnguyen     exit(1);
      }
    };
    
   break;
    
  };

};

void nand_buffer_addr(int start_addr, int end_addr){
  write(0x17010048, start_addr);       // Nand Buffer Address:
  write(0x1701004c, end_addr);         // Nand Buffer Address:
};

void nand_ecc_setup (int bank_id, int ecc_on_off, int ecc_algo, int bcht) {
  write(0x17012200+(bank_id<<12), 0x00000000 | ecc_on_off<<7 | ecc_algo<<8); // Nand ECC Setup    1'b0: Hamming, 1'b1: BCH
  write(0x1701220c+(bank_id<<12), 0x00000000 | bcht);                       // Nand ECC Setup 4'b0000:4 bit ecc,4'b0001:8 bit
};


void nand_pio_reset(int bank_id){
  //print("Nand Reset\n\r");
  write(0x17010018, 0x00000008);
  write(0x1701001c, 0x00000000);
  write(0x17010020, 0x00000000);
  write(0x17010024, OPCODE_RESET);
  write(0x17010014, (0x00000011|(bank_id<<1)));
  wait_completion();
};

void nand_pio_force_status_read(int bank_id) {
  int bank_num;
  int rd_data,cnt;
  //print("Nand PIO forced Status Read\n\r");
  bank_num = 0x3f^(0x1<<bank_id);
  write(0x17010050,0x0|(0x1<<26)|(bank_num<<20)|(0x1<<19)|(0x70));

  rd_data=read(0x17010050);
  cnt = 0x0;
  while (rd_data&0x00080000 != 0x0) {
    rd_data=read(0x17010050);
    cnt = cnt+1;
    if(cnt > 10) {
	  //print("ERROR: Manual readstatus timeout\n\r");
    	// datnguyen 	  error(1);
	  break;
    }
  }
  rd_data=read(0x17010054);
  //print("Nand Read Status Value=");putnum(rd_data);//print("\n\r");
}

void nand_pio_erase(int bank_id, int row_addr){
  //print("Nand Erase\n\r");

  int r0_bus_field,r1_bus_field,r2_bus_field,r3_bus_field,r4_bus_field,r5_bus_field;
  int pio_reg0,pio_reg1,pio_reg2,pio_reg8,pio_ctrl;
  int i;

  r0_bus_field = OPCODE_ERASE;
  r1_bus_field = 0x000000FF&row_addr;
  r1_bus_field = r1_bus_field << 16;
  pio_reg0 = r0_bus_field | r1_bus_field;

  r2_bus_field = 0x0000FF00&row_addr;
  r2_bus_field = r2_bus_field >> 8;
  r3_bus_field = 0x00FF0000&row_addr;
  r3_bus_field = r3_bus_field >> 8;
  pio_reg1     = r2_bus_field | r3_bus_field;

  r4_bus_field = OPCODE_ERASE_LAST;
  pio_reg2     = r4_bus_field;

  // ctrl fields 
  write(0x17010018, 0x00089998);
  write(0x1701001c, 0x00000000);
  write(0x17010020, 0x00000000);

  // data fields
  write(0x17010024, pio_reg0);
  write(0x17010028, pio_reg1);
  write(0x1701002c, pio_reg2);

  // setup start
  write(0x17010014, (0x00000091|(bank_id<<1)));
  wait_completion();
};


// this CSR contain the full address of the NAND PIO buffer.
// Different from the device start address
unsigned int get_nand_piobuffer_startadd32bit () {
  unsigned int read_data;
  unsigned int nand_piobuffer_startadd32bit;

  //print("\n=== Get NAND PIO Buffer Start Addr \n\r");
  read_data = read(0x17010048);
  nand_piobuffer_startadd32bit = read_data;
  return(nand_piobuffer_startadd32bit);

}

unsigned int nand_device_id(int bank_id, int bus_width){
  unsigned int rdata;
  unsigned int device_id;
  unsigned int nand_piobuffer_startadd32bit = get_nand_piobuffer_startadd32bit()| GFC_BASE;
  int bstatus = 1;

  //Setup command
  //print("Nand Read Device ID\n\r");
  write(0x17010018, 0x00000098);// gfc_nand_pio_reg_ctrl0
  write(0x1701001c, 0x00000000);// gfc_nand_pio_reg_ctrl1
  write(0x17010020, 0x00000000);// gfc_nand_pio_reg_ctrl2
  write(0x17010024, OPCODE_RD_DEVICE_ID); // recieve "ONFI"
  

  //GFC PIO control
  if (bus_width== BUS_WIDTH_8) {
    write(0x17010014, (0x00000431|(bank_id<<1)));
    wait_completion();

    rdata = read8(nand_piobuffer_startadd32bit + 0); device_id = (device_id <<8 | (0xff & rdata));
    rdata = read8(nand_piobuffer_startadd32bit + 1); device_id = (device_id <<8 | (0xff & rdata));
    rdata = read8(nand_piobuffer_startadd32bit + 2); device_id = (device_id <<8 | (0xff & rdata));
    rdata = read8(nand_piobuffer_startadd32bit + 3); device_id = (device_id <<8 | (0xff & rdata));
    
  }
  else if (bus_width== BUS_WIDTH_16) {
    write(0x17010014, (0x00000830|(bank_id<<1)));
    wait_completion();

    rdata = read16(nand_piobuffer_startadd32bit + 0); device_id = (device_id <<8 | (0xffff & rdata));
    rdata = read16(nand_piobuffer_startadd32bit + 2); device_id = (device_id <<8 | (0xffff & rdata));
    rdata = read16(nand_piobuffer_startadd32bit + 4); device_id = (device_id <<8 | (0xffff & rdata));
    rdata = read16(nand_piobuffer_startadd32bit + 6); device_id = (device_id <<8 | (0xffff & rdata));
  }
  else {

    printf("\n NAND Buswidth Error: bus_width_32 \n\r");
  }
  
  
  flush_pio_rd_buffer();

  printf("\n--- NAND Read Device ID = 0x%08x\r\n", device_id);  // ID parameter = "ONFI" PASS
  if(device_id != 0x4f4e4649){
      printf("\n--- NAND Read Device FAIL\r\n");
	  bstatus = 1;
  }
  else {
      printf("\n--- NAND Read Device PASS\r\n");
	  bstatus = 0;
  }
  
return bstatus;
};

void wait_completion(){
  int  cnt = 0;
  int  a = 0x10;
  
  a = read(0x17010014);
  cnt =0;
  while((a & 0x10) == 0x10) {
    a = read(0x17010014);
    cnt = cnt+1;
    if (cnt >10) {
     break;
	}
  }

};

//  ******** code added by sandeep ************
void nand_pio_wr_setup(int bank_id,int row_addr,int col_addr,int data_size, int data_patern)
{
	int r0_bus_field,r1_bus_field,r2_bus_field,r3_bus_field,r4_bus_field,r5_bus_field;
	int pio_reg0,pio_reg1,pio_reg2,pio_reg8,pio_ctrl,temp_val = 0,temp_val1 = 0;
	int *pio_buff_start_addr;
	int *wr_data;
	int i, read_data, temp_val2;
	int start_address = GFC_NAND_BASE;
	int timeout = 10000;
	int block_size;
	int block = 0x200;
	int len;
	int reg_val ;
	int w = 0, val = 0;
	r0_bus_field = OPCODE_PROGRAM;
	r1_bus_field = 0x000000FF&col_addr;
	r1_bus_field = r1_bus_field << 16;
	pio_reg0 = r0_bus_field | r1_bus_field;

	r2_bus_field = 0x0000FF00&col_addr;
	r2_bus_field = r2_bus_field >> 8;
	r3_bus_field = 0x000000FF&row_addr;
	r3_bus_field = r3_bus_field << 16;
	temp_val = r3_bus_field;
	pio_reg1     = r2_bus_field | r3_bus_field;

	r4_bus_field = 0x0000FF00&row_addr;
	temp_val = temp_val | r4_bus_field;
	r4_bus_field = r4_bus_field >>8;
	r5_bus_field = 0x00FF0000&row_addr;
	pio_reg2     = r4_bus_field | r5_bus_field;
	temp_val = temp_val | ((r5_bus_field)>>16);

	write(0x17010018, 0x00999998);// gfc_nand_pio_reg_ctrl0
	write(0x1701001c, 0x00000000);// gfc_nand_pio_reg_ctrl1
	write(0x17010020, 0x00000000);// 0x00000008 gfc_nand_pio_reg_ctrl2

	// data fields
	write(0x17010024, pio_reg0);
	write(0x17010028, pio_reg1);
	write(0x1701002c, pio_reg2);
	write(0x17010030, 0x00000000);
	write(0x17010034, 0x00000000);
	write(0x17010038, 0x00000000);
	write(0x1701003c, 0x00000000);
	write(0x17010040, 0x00000000);
	write(0x17010044, 0x00000000);

	//setting the start bit
	pio_ctrl = 0x0;
	//pio_ctrl = pio_ctrl | 0x1 ;            // set lock bit
	pio_ctrl = pio_ctrl | (bank_id<<1) ;   // config bank_id
	pio_ctrl = pio_ctrl | (data_size<<8) ; // config size
	pio_ctrl = pio_ctrl | 0x40 ;           // set write bit
	pio_ctrl = pio_ctrl | 0x10 ;           // set start bit
	write(0x17010014, pio_ctrl);
	arch_timer_usdelay(100);
//	gfc_dump_reg();
	len = 0x800;
	block = 0x200;
	if (len > block) {
		block_size = len / block;
		for (i = 0; i < block_size; i++) {
			do {
				reg_val = read(0x17010058);
				if ((timeout--) <= 0) {
					printf("GFC CHECK GFC_NAND_PIO_STATUS__rfifo_empty 0x%08x ERR", reg_val);
				}
			} while ((reg_val & ((0x1)<<10)) != ((0x1)<<10));
			int w = 0;
			for(w = 0; w<block ;w++)
			{
				write(GFC_NAND_BASE, 0xABABABAB);
				arch_timer_usdelay(100);
				DSB_SY_CALL1();
			}
			write(0x17010068, 0x8);  // flush read buffer
			temp_val = read(0x17010068);
			//buf = buf + block;
			len = len - block;

		}
	}
//	gfc_dump_reg();
	write(0x17010018, 0x00000008);
	write(0x1701001c, 0x00000000);
	write(0x17010020, 0x00000000);

// data fields
	write(0x17010024, 0x00000010);
	write(0x17010028, 0x00000000);
	write(0x1701002c, 0x00000000);
	write(0x17010030, 0x00000000);
	write(0x17010034, 0x00000000);
	write(0x17010038, 0x00000000);
	write(0x1701003c, 0x00000000);
	write(0x17010040, 0x00000000);
	write(0x17010044, 0x00000000);

	write(0x17010014, 0x00000014);
}

void nand_pio_wr_data(int *start_addr, int* data, int data_size_in_bytes) {
  int i,num_of_4B_words;
  num_of_4B_words = data_size_in_bytes >>  2;
  for(i= 0; i<num_of_4B_words; i=i+1) {
	 printf("\n\r==================   data[0x%08x] =  0x%08x =============== \r\n",start_addr, data[i]);
     write(start_addr,data[i]);
     start_addr++;
  }

}

unsigned int nand_pio_rd_data(int *start_addr,int data_size_in_bytes)
{
  int i, num_of_4B_words;
  unsigned int rd_data[2049];
  unsigned int bstatus = 1;

  num_of_4B_words = data_size_in_bytes >>  2;
  for(i= 0; i<num_of_4B_words; i=i+1)
  {
     rd_data[i] = INLE_32(start_addr);
     printf("\n\r=== rd_data[0x%08x] =  0x%08x, size = 0x%08x === \r\n",start_addr, rd_data[i],num_of_4B_words);
     start_addr++;
  }
  if (rd_data[0] == 0xABABABAB)
	  bstatus = 0;
  else
	  bstatus = 1;

  return bstatus;
}
unsigned int nand_pio_rd_setup(int bank_id,int row_addr2,int col_addr2,int data_size)
{
	int r0_bus_field,r1_bus_field,r2_bus_field,r3_bus_field,r4_bus_field,r5_bus_field;
	int pio_reg0,pio_reg1,pio_reg2,pio_reg3,pio_ctrl, temp_val = 0, temp_val1;
	//  int *pio_buff_start_addr;
	//  int *rd_data;
	unsigned int bstatus = 1;

	r0_bus_field = 0x00000000;
	r1_bus_field = 0x000000FF&col_addr2;
	r1_bus_field = r1_bus_field << 16;
	pio_reg0 = r0_bus_field | r1_bus_field;

	r2_bus_field = 0x0000FF00&col_addr2;
	r2_bus_field = r2_bus_field >> 8;
	r3_bus_field = 0x000000FF&row_addr2;
	r3_bus_field = r3_bus_field << 16;
	temp_val = r3_bus_field;
	pio_reg1     = r2_bus_field | r3_bus_field;

	r4_bus_field = 0x0000FF00&row_addr2;
	temp_val = temp_val | r4_bus_field;
	r4_bus_field = r4_bus_field >>8;
	r5_bus_field = 0x00FF0000&row_addr2;
	pio_reg2     = r4_bus_field | r5_bus_field;
	temp_val = temp_val | ((r5_bus_field)>>16);

	pio_reg3     = 0x00000030;

	// ctrl fields
	OUTLE_32(0x17010018, 0x08999998);
	OUTLE_32(0x1701001c, 0x00000000);
	OUTLE_32(0x17010020, 0x00000000);

	// data fields
	OUTLE_32(0x17010024, pio_reg0);
	OUTLE_32(0x17010028, pio_reg1);
	OUTLE_32(0x1701002c, pio_reg2);
	OUTLE_32(0x17010030, pio_reg3);
	OUTLE_32(0x17010034, 0x00000000);
	OUTLE_32(0x17010038, 0x00000000);
	OUTLE_32(0x1701003c, 0x00000000);
	OUTLE_32(0x17010040, 0x00000000);
	OUTLE_32(0x17010044, 0x00000000);

	//setting the start bit
	pio_ctrl = 0x0;
	//  pio_ctrl = pio_ctrl | 0x1 ;            // set lock bit
	pio_ctrl = pio_ctrl | (bank_id<<1) ;   // config bank_id
	pio_ctrl = pio_ctrl | (data_size<<8) ; // config size
	pio_ctrl = pio_ctrl | 0x20 ;           // set read bit
	pio_ctrl = pio_ctrl | 0x10 ;           // set start bit

	OUTLE_32(0x17010014, pio_ctrl);

	wait_completion();
	bstatus = nand_pio_rd_data(GFC_NAND_BASE, data_size); //GFC_BASE

	write(0x17010068, 0x1);  // flush read buffer

	return bstatus;
}





void nand_write(int bank_id,void *address, int data, int bus_width){
    short *add_16bit;
    short data_16bit;
    short *OCMadd_16bit;
    
    char *add_8bit;
    char data_8bit;
    char *OCMadd_8bit;
    unsigned int add_temp = address;
    unsigned int temp = (add_temp - NAND_BUFFER_STARTADD);

    unsigned int outOfOCM_bound = over_ocm_boundry(bank_id, temp);
    temp = ocm_bank_base(bank_id) + (temp&0x00ffffff);    

    OCMadd_16bit = temp;
    OCMadd_8bit  = temp;

    if (bus_width == BUS_WIDTH_32){
// datnguyen      error(1);
      printf("\n NAND Buswidth Error: bus_width_32 \n\r");
    }
    else if (bus_width == BUS_WIDTH_16){
      add_16bit = address;
      data_16bit = data;
      write16 (add_16bit, data_16bit);   
      if (outOfOCM_bound == 1) { printf("\n= Warning: NAND WRITE, No data write to OCM, out of OCM  \n\r");}
      else {                     write16 (OCMadd_16bit, data_16bit); }
    }
    else {
      add_8bit = address;
      data_8bit = data;
      write8 (add_8bit, data_8bit);   
      if (outOfOCM_bound == 1) { printf("\n= Warning: NAND WRITE, No data write to OCM, out of OCM  \n\r");}
      else {                     write8 (OCMadd_8bit, data_8bit);}
    }
}


void nand_read(int bank_id,void *address, int bus_width){
  short *add_16bit;
  short data_16bit;
  short *OCMadd_16bit;
  short OCMdata_16bit;

  char *add_8bit;
  char data_8bit;
  char *OCMadd_8bit;
  char OCMdata_8bit;
  unsigned int add_temp = address;
  unsigned int temp = (add_temp - NAND_BUFFER_STARTADD);

  unsigned int outOfOCM_bound = over_ocm_boundry(bank_id, temp);
  temp = ocm_bank_base(bank_id) + (temp&0x00ffffff);
  
  OCMadd_16bit = temp;
  OCMadd_8bit  = temp;

  if  (bus_width == BUS_WIDTH_32) {
    // datnguyen error(1);
    //print("\n NAND Buswidth Error: bus_width_32 \n\r");
  }
  else if  (bus_width == BUS_WIDTH_16) {
    add_16bit  = address; 
    data_16bit = read16 (add_16bit);

    if (outOfOCM_bound == 1) { 
      //print("\n= Warning: NAND READ, No data read from OCM, out of OCM bounday\n\r");
    }
    else {
      OCMdata_16bit = read16( OCMadd_16bit); 
      
      if(OCMdata_16bit != data_16bit){
        //print("ERROR: NAND 16bit Read Data Mismatch: Expected = %0x"); putnum(OCMdata_16bit); //print(" Actual = %0x");  putnum(data_16bit);  //print("\n\r");
    	  // datnguyen         error(0);
      }
    }

  }
  else {
    add_8bit  = address; 
    data_8bit = read8 (add_8bit);

    if (outOfOCM_bound == 1) {
        //print("\n= Warning: NAND READ, No data read from OCM, out of OCM bounday\n\r");
    }
    else { 
      OCMdata_8bit = read8( OCMadd_8bit); 

      if(OCMdata_8bit != data_8bit){
        //print("ERROR: NAND 8bit Read Data Mismatch: Expected = %0x"); putnum(OCMdata_8bit); //print(" Actual = %0x");  putnum(data_8bit);  //print("\n\r");
    	  // datnguyen         error(0);
      }
    }
  }
}

void flush_pio_rd_buffer() {
  write(0x17010068, 0x1);  // flush read buffer
};


void nand_setup (int bank_id, int ecc_on_off, int ecc_alg, int bcht, int device_size, int block_size, int page_size) {
  int force_spare_offset = 0; 
  nand_bank_ctrl0 (bank_id, ecc_on_off, ecc_alg, force_spare_offset);
  nand_bank_bch (bank_id, NAND0_BCH_N, bcht, NAND0_BCH_K);
  nand_size_setup (bank_id, device_size, block_size, page_size);
  nand_timing_para_setup (bank_id,
                          NAND0_T_CCS,   NAND0_T_RHW,  NAND0_T_WB,        NAND0_T_ADL,
                          NAND0_T_DH_WH, NAND0_T_DS_WP,NAND0_T_ALS_CLS_CS,NAND0_T_ALH_CLH_CH, 
			  NAND0_T_RP,    NAND0_T_REH,  NAND0_T_RR,        NAND0_T_AR_CLR_WHR_IR);
}

void nand_bank_ctrl0 (int bank_id, int ecc_on_off, int ecc_alg, int force_spare_offset){
  int write_data;
  int read_data;
  int spare_offset = 0x400;
  read_data = read(0x17012200 + (bank_id<<12));
  write_data = (read_data & 0x0000fc7f) | (ecc_on_off<<7 | ecc_alg<<8 | force_spare_offset<<9 | spare_offset<<16);
  write (0x17012200 + (bank_id<<12), write_data);
}

void nand_bank_bch (int bank_id, int bchn, int bcht, int bchk){
  int write_data;  
  int read_data;
  read_data = read(0x1701220c + (bank_id<<12));
  write_data = (read_data & 0xff800000) | (bchn | bcht<<16 |  bchk<<20 );
  write (0x1701220c + (bank_id<<12), write_data);
}

void nand_dma_ctrl1 (int bank_id, int dma_data_size){ //dma_data_size unit: 64byte
  unsigned int write_data;
  unsigned int read_data;
  unsigned int ecc_on;
  unsigned int ecc_alg;

  read_data = read(0x17012200 + (bank_id<<12));
  ecc_on =  (read_data & 0x80) >> 7;

  read_data = read(0x17012200 + (bank_id<<12));
  ecc_alg =  (read_data & 0x100) >> 8;
  
  if((ecc_on==ECC_ON) & (ecc_alg== HAMMING) ) {
    if (dma_data_size%4 !=0 ) { 
    	// datnguyen       error(0);
      //print("ERROR: DMA data size for HAMMING needs to be multiple of 256 Byte \n\r");
    }
  }
  else if((ecc_on==ECC_ON) & (ecc_alg== BCH) ) {
    if (dma_data_size%8 !=0 ) { 
// datnguyen      error(0);
      //print("ERROR: DMA data size for HAMMING needs to be multiple of 256 Byte \n\r");
    }
  }

  write_data = ((read_data & 0xff000000) | dma_data_size );
  write (0x17012220 + (bank_id<<12), write_data);
}

void nand_size_setup (int bank_id, int device_size, int block_size, int page_size){ 
  unsigned int write_data;

  write (0x17012224 + (bank_id<<12), page_size);
  write (0x17012228 + (bank_id<<12), (device_size <<16 | block_size));
}

void nand_timing_para_setup (int bank_id,
                             int t_ccs, int t_rhw, int t_wb, int t_adl,
                             int t_dh_wh, int t_ds_wp, int t_als_cls_cs, int t_alh_clh_ch, 
                             int t_rp, int t_reh, int t_rr, int t_ar_clr_whr_ir) {

  write (0x1701222c + (bank_id<<12), (t_ccs | t_rhw<<8 | t_wb<<16 | t_adl<<24));
  write (0x17012230 + (bank_id<<12), (t_dh_wh | t_ds_wp<<8 | t_als_cls_cs<<16 | t_alh_clh_ch<<24));
  write (0x17012234 + (bank_id<<12), (t_rp | t_reh<<8 | t_rr<<16 | t_ar_clr_whr_ir<<24));
}
