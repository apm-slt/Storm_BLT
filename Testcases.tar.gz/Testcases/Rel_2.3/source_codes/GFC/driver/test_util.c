/*
 *
 */

//#include <stdio.h>

//Tinh-SLT:
//give full path to include header files
#include "../include/platform.h"
#include "../include/test_util.h"
#define error_counter error_counter_gfc
#define read read_gfc
#define write write_gfc
#define ocm_init ocm_init_gfc
#define error error_gfc
#define end_test end_test_gfc
#define get_file get_file_gfc

int error_counter = 0;

//int read32(unsigned int *address){
//  unsigned int *addr_int;
//  int rdata;
//  addr_int = address;
//  //unsigned int rdata = *addr_int;
//
//  rdata = *addr_int;
//	//// datnguyen print("Read32  @ 0x:"); putnum(addr_int); // datnguyen print(" is 0x");  putnum(rdata);  // datnguyen print("\n\r");
//	return(rdata);
//}
//
//void write32(unsigned int *address, int data){
//  unsigned int *addr_int;
//  addr_int = address;
//	*addr_int = data;
//	//// datnguyen print("Write32 @ 0x:"); putnum(address); // datnguyen print(" is 0x");  putnum(data);  // datnguyen print("\n\r");
//}

//int read(unsigned int *address){
//  unsigned int *addr_int;
//  int rdata;
//  addr_int = address;
//  rdata = *addr_int;
//	// datnguyen print("Read32  @ 0x:"); putnum(addr_int); // datnguyen print(" is 0x");  putnum(rdata);  // datnguyen print("\n\r");
//	return(rdata);
//}
//
//void write(unsigned int *address, int data){
//  unsigned int *addr_int;
//  addr_int = address;
//	*addr_int = data;
//	// datnguyen print("Write32 @ 0x:"); putnum(address); // datnguyen print(" is 0x");  putnum(data);  // datnguyen print("\n\r");
//}
//
//short read16(short *address){
//  short *addr_int;
//  short rdata;
//  addr_int = address;
//  rdata = *addr_int;
//  //short rdata = *addr_int;
//	// datnguyen print("Read16  @ 0x:"); putnum(address); // datnguyen print(" is 0x");  putnum(rdata);  // datnguyen print("\n\r");
//	return(rdata);
//}
//
//void write16(short *address, short data){
//  short *addr_int;
//  addr_int = address;
//	*addr_int = data;
//	// datnguyen print("Write16 @ 0x:"); putnum(address); // datnguyen print(" is 0x");  putnum(data);  // datnguyen print("\n\r");
//}
//
//char read8(char *address){
//  char *addr_int;
//  char rdata;
//  addr_int = address;
//  //	char rdata = *addr_int;
//  	rdata = *addr_int;
//	// datnguyen print("Read8  @ 0x:"); putnum(address); // datnguyen print(" is 0x");  putnum(rdata);  // datnguyen print("\n\r");
//	return(rdata);
//}
//
//void write8(char *address, char data){
//  char *addr_int;
//  addr_int = address;
//	*addr_int = data;
//	// datnguyen print("Write8 @ 0x:"); putnum(address); // datnguyen print(" is 0x");  putnum(data);  // datnguyen print("\n\r");
//}


void read_svn_id () {
  int read_data;
  read_data = read((unsigned int *)(0x17040008));
  // datnguyen print("SVN Rev = "); putnum(read_data); // datnguyen print("\n\r");
}

void ocm_init() {
 
  write((unsigned int *)(0x9f41c004),3);  // OCM clken
  write((unsigned int *)(0x9f41c000),0);  // OCM rst deassertion
};

void error(int stoptest) {
  error_counter = error_counter + 1;
  if(stoptest){
	  // datnguyen print("Ending Tests with error count = "); putnum(error_counter);  // datnguyen print("\n\r\n\r");
    // datnguyen print("********************************************************");  // datnguyen print("\n\r");
    // datnguyen print("******************** Test Failed ***********************");  // datnguyen print("\n\r");
    // datnguyen print("********************************************************");  // datnguyen print("\n\r");
#ifndef ARM_CC
// datnguyen    exit(0);
#endif
  }
};


void end_test() {
  if(error_counter !=0)
    error(1);
  else {
    // datnguyen print("********************************************************");  // datnguyen print("\n\r");
    // datnguyen print("******************** Test Passed ***********************");  // datnguyen print("\n\r");
    // datnguyen print("********************************************************");  // datnguyen print("\n\r");
#ifndef ARM_CC
	  // datnguyen     exit(0);
#endif
  }
};
#ifndef ARM_CC
void get_file (int *start_address, int size_in_bytes) {
  int nibble_counter = 0;
  unsigned char in_ch;
  int word = 0;
  int hx = 0;
  unsigned char check;
  int *addr = start_address;
  while((nibble_counter) < size_in_bytes*2){
    check = 1;
    while(check){
// datnguyen      in_ch = inbyte();
      check = 0;
      if(in_ch>0x29 && in_ch<0x3a)
        hx = in_ch-0x30;
      else if((in_ch>0x40 && in_ch<0x47))
        hx = in_ch-0x37;
      else if((in_ch>0x60 && in_ch<0x67))
        hx = in_ch-0x57;
      else check = 1;
    }
    word = (word<<4) | hx;
    nibble_counter++;
    if(nibble_counter%8 == 0){
	    *start_address = word;
      start_address++;
    }
  }
  // datnguyen print("0x"); putnum(nibble_counter/2); // datnguyen print(" bytes transferred");// datnguyen print("\n\r");

  //int i;
  //for(i=0; i<size_in_bytes/4; i++)
    //read32(addr+i);
}
#endif

void ddr_init(){
  int rdata;
  
  write((unsigned int *)(0xc200c03c), 0x0);         //kumar:
  write((unsigned int *)(0xc200c040), 0x200D0000);
  write((unsigned int *)(0xc200c060), 0x04403000);  // changed read latency here changing LSB nibble from 6 to 7
  write((unsigned int *)(0xc200c02c), 0xe4a48361);  // changed Write latency here changing LSB nibble from 4 to 5
  write((unsigned int *)(0xc200c010), 0x01421109);  // remove ddrc reset
  write((unsigned int *)(0xc200c0b0), 0x00000010);

  rdata = read((unsigned int *)0xc200c3A8);
  while(!((rdata & 0x07000000) == 0x01000000))
    
    rdata = read((unsigned int *)0xc200c3A8);
  
  write((unsigned int *)0xc0000000, 0x12345678);
  read ((unsigned int *)0xc0000000);
};
