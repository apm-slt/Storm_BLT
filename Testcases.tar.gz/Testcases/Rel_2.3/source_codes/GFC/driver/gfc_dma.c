// #include <stdio.h>
#include "../include/platform.h"
#include "../include/test_util.h"
#include "../include/gfc_common.h"
#include "../include/gfc_nand.h"
#include "../include/gfc_nor.h"
#include "../include/gfc_dma.h"

#define GLBL_MASK 0x00003d00
#define MAX_TESTS 1000
#define CLK_PERIOD 20

//Tinh-SLT
#define read read_gfc
#define write write_gfc

// SMV: 071312
int b = 0;
int i;
int read_data;
int write_data;
int pass = 1;
int pass_vec = 1;
int ocm_wr_addr = 0x1D000000;
int ocm_rd_addr = 0x1D004000;
int dev_addr = 0X007f0000;
int block_num = 0x0000;

int bank_id = 3;
int bus_width = 1;
int page_size = 2048;
int dma_size = 4;
int tot_failed_tests = 0; 
int failed_test_indx = 0; 
int exit_on_first_err = 1;
int num_data_err = 0;

// Error Recording
struct test_stat {
  int test_pass;
  int err_code; // 0: Data, 1: Glbl Int, 2, Bank Int
  int data_err_location;
  int exp_data;
  int act_data;
  int glbl_int;
  int bank_int;
};

int test_cnt = 0;
int failed_addr_t;
int test_err_arr[MAX_TESTS];
int act_cor_err[MAX_TESTS];
int act_uncor_err[MAX_TESTS];
int exp_cor_err[MAX_TESTS];
int exp_uncor_err[MAX_TESTS];
int failed_addr[MAX_TESTS];
int failed_test_no[MAX_TESTS];
int tot_act_cor_err = 0;
int tot_act_uncor_err = 0;
int tot_exp_cor_err = 0;
int tot_exp_uncor_err = 0;
int page_count = 0;
int row_addr = 0x0000;
int act_cor_err_t;
int act_uncor_err_t;
int exp_cor_err_t;
int exp_uncor_err_t;

// ===
// == Tests.
// ===

unsigned int dma_test(){

  int indx = 0;
  int bstatus = 1;

  block_num = dev_addr >> 16;

  // NAND DMA
  // datnguyen print("Hello World-SMV\n\r");
  //// datnguyen print("Configuration to enable second daughter card on which NAND is connected on Bank0.\n\r");
  //write(0x17040000, 0x00000005);
  // data_out 
  // config to select the daughter card on which nand/nor/sram are
  // there.(cascade of TMA0030 & TMA0031 daughter cards)
  write(0x17040000, 0x00000011);
  // data_in
  // write(0x17040000, 0x01000005);

  /*
  // Byte Swap Enabled for changed settings.
  read_data = read(0x17010074);
  // Set Bit 23: 2-Byte Nand Swap.
  write_data = read_data | 0x00800000;
  write(0x17010074, write_data);
  */

  nand_init();
  // void device_setup (int bank_id, int bank_valid, int bank_type, int bank_usage , int bus_width)
  device_setup(bank_id, 1, 0, 3, bus_width);

  // ocm_init();

  // Initialize Test Error Counter.
  /*
  for (i=0; i<MAX_TESTS; i=i+1) {
    test_err_arr[i] = 0;
    act_cor_err[i] = 0;
    act_uncor_err[i] = 0;
  };
  */
  // == Basic Test Suite. ==
  /*
  nand_erase(bank_id, block_num);
  nand_erase(bank_id, block_num+1);
  nand_dma(8);
  */

  // dma_op(WRITE, ocm_wr_addr, ocm_rd_addr, dev_addr+0x10000, dma_size, 1, 512);
  // dma_op(READ, ocm_wr_addr, ocm_rd_addr, dev_addr+0x10000, dma_size, 1, 512);
  // dma_op(WRITE, ocm_wr_addr, ocm_rd_addr, dev_addr+0x20000, dma_size, 1, 1023);
  // dma_op(READ, ocm_wr_addr, ocm_rd_addr, dev_addr+0x20000, dma_size, 1, 1023);
  // dma_op(WRITE, ocm_wr_addr, ocm_rd_addr, dev_addr+0x50000, dma_size, 1, 111);
  // dma_op(READ, ocm_wr_addr, ocm_rd_addr, dev_addr+0x50000, dma_size, 1, 111);
  

  // For ECC Tests, we need to corrupt the data/ecc using PIO functions.
  nand_buffer_addr(NAND_BUFFER_STARTADD, NAND_BUFFER_ENDADD);

  // == ECC All Algorithm Test Suite. ==
  // // datnguyen print(" All ECC 16X. ==");// datnguyen print("\n\r");
  // =
  // Notes: Index (Column Address) is multiplied by 2 to take care of 16-bit device.
  // =
  // ecc_err_data_spare(1, 1);
   //ecc_err_data_spare(3, 0);
  ecc_err_data_spare(1, 2);
  
  // void nand_dma_ecc(int dev_addr, int dma_size, int ecc_algo, int num_errors, int err_loc)
  /*
  // 1-bit BCH_8
  row_addr = 0x7407;
  nand_erase(bank_id, row_addr);
  // datnguyen print ("=== 1-bit BCH_8 ===\n\r");
  nand_dma_ecc((0x00000000+((row_addr)<<16)), 16, 2, 1, 1);
  */

  // dma_size = 2;

  // == Interrupt Test Suite. ==
  // // datnguyen print(" Override Test. ==");// datnguyen print("\n\r");
  // override_test();
  // 
  // // datnguyen print(" Device Protection Test. ==");// datnguyen print("\n\r");
  // devprot_test();

  // // datnguyen print(" DMA Abort Test. ==");// datnguyen print("\n\r");
  // dma_abort_test();
  // 
  // // datnguyen print(" DMA Timing Abort Test. ==");// datnguyen print("\n\r");
  // dma_timing_abort_test();

  // == Result. ==
  // // datnguyen print("Final Result::  @ 0x:"); putnum(pass_vec); // datnguyen print("\n\r");
  // datnguyen print(" ==");// datnguyen print("\n\r");
  // datnguyen print("  Final Result:: ==");// datnguyen print("\n\r");
  // datnguyen print(" ==");// datnguyen print("\n\r");


    tot_failed_tests = 0;
    for (i=0; i<failed_test_indx; i++) {
  // datnguyen print("  Final Result:: ==");// datnguyen print("\n\r");
      // datnguyen print ("Failed Test No.:  ");putnum(i);// datnguyen print("\t dev_addr = \t");putnum(failed_addr[i]);// datnguyen print("\n\r");
      // datnguyen print ("Correctable Error::  Exp: ");putnum(exp_cor_err[i]); // datnguyen print ("\tAct:\t"); putnum(act_cor_err[i]);// datnguyen print("\n\r");
      // datnguyen print ("Uncorrectable Error::  Exp: ");putnum(exp_uncor_err[i]); // datnguyen print ("\tAct:\t"); putnum(act_uncor_err[i]);// datnguyen print("\n\r");
      // datnguyen print("  Final Result:: ==");// datnguyen print("\n\r");
    };

    tot_failed_tests = failed_test_indx;

    // datnguyen print("\n\r");
    //// datnguyen print(" ==");// datnguyen print("\n\r");
    
    // datnguyen print(" ==");// datnguyen print("\n\r");
    // datnguyen print ("Total Failed Tests = ");putnum(tot_failed_tests);// datnguyen print("\n\r");
    // datnguyen print(" ==");// datnguyen print("\n\r");
    // Clear GFC_INTERRUPT
    write(0x1701000c, 0xffffffff);
    
// datnguyen    return 0;
    return bstatus;
}
unsigned int nand_dma_multibank_ecc() {
  int bstatus = 1;
  // datnguyen print("Hello World-SMV\n\r");
  // config to select the daughter card on which nand/nor/sram are
  // there.(cascade of TMA0030 & TMA0031 daughter cards)
  write(0x17040000, 0x02000011);

  nand_init();
  device_setup(BANK2, 1, 0, 3, 0);
  device_setup(BANK3, 1, 0, 3, 1);

  nand_buffer_addr(NAND_BUFFER_STARTADD, NAND_BUFFER_ENDADD);

  row_addr = rand_num(1,0x1ff);
  // datnguyen print ("=== Single-bit Hamming ON BANK-3 ===\n\r");
  nand_dma_ecc((0x00000000+((row_addr)<<16)), 32, 0, 1, 1);

  row_addr = rand_num(1,0x1ff);
  bank_id = 2;
  bus_width = 0;
  // datnguyen print ("=== 8-bit BCH_8 ON BANK-2 ===\n\r");
  nand_dma_ecc((0x00000000+((row_addr)<<16)), 32, 2, 8, 1);

  return bstatus;
}

void nand_dma_wpn_test() {
  int ocm_act_wr_addr, ocm_tmp_wr_addr;
  int ocm_local_rd_addr, page_num;
  // datnguyen print("Hello World-SMV\n\r");
  // config to select the daughter card on which nand/nor/sram are
  // there.(cascade of TMA0030 & TMA0031 daughter cards)
  write(0x17040000, 0x02000011);

  nand_init();
  device_setup(BANK3, 1, 0, 3, 1);

  nand_buffer_addr(NAND_BUFFER_STARTADD, NAND_BUFFER_ENDADD);
  ocm_act_wr_addr = ocm_bank_base(bank_id);
  ocm_act_wr_addr = ocm_act_wr_addr&0x7fffffff;
  ocm_local_rd_addr = ocm_act_wr_addr + 0x10000;
  ocm_local_rd_addr = ocm_local_rd_addr &0x7fffffff;
  page_num = rand_num(1,1000); 
  //write data into NAND
  dma_op(WRITE, ocm_act_wr_addr, ocm_local_rd_addr, 0x0|(page_num<<16), 32, 1, 0);
  // enable wpn
  config_wp_n(bank_id,0x1); // 1- to enable wp_n
  //read data and compare
  dma_op(READ, ocm_act_wr_addr, ocm_local_rd_addr, 0x0|(page_num<<16), 32, 1, 0);
  //block erase
  nand_erase(bank_id, page_num);
  //read from same location and compare with first data
  //if there are data mismatches, issue in wpn functionality
  dma_op(READ, ocm_act_wr_addr, ocm_local_rd_addr, 0x0|(page_num<<16), 32, 1, 0);
  //write data in the same location of nand but at different location in ocm
  //to preserve the first data
  ocm_tmp_wr_addr = ocm_bank_base(bank_id) + 0x8000;
  ocm_tmp_wr_addr = ocm_tmp_wr_addr & 0x7fffffff;
  dma_op(WRITE, ocm_tmp_wr_addr, ocm_local_rd_addr, 0x0|(page_num<<16), 32, 1, 0xa5a5a5a5);
  //read from same location and compare with first data
  //if there are data mismatches, issue in wpn functionality
  dma_op(READ, ocm_act_wr_addr, ocm_local_rd_addr, 0x0|(page_num<<16), 32, 1, 0);


}
void nand_dma_dev_prot_test() {
  int ocm_act_wr_addr, ocm_tmp_wr_addr;
  int ocm_local_rd_addr, page_num;
  // datnguyen print("Hello World-SMV\n\r");
  // config to select the daughter card on which nand/nor/sram are
  // there.(cascade of TMA0030 & TMA0031 daughter cards)
  write(0x17040000, 0x02000011);

  nand_init();
  device_setup(BANK3, 1, 0, 3, bus_width);

  nand_buffer_addr(NAND_BUFFER_STARTADD, NAND_BUFFER_ENDADD);
  if (bus_width == 1) {
    nand_dma_setup(0, 0, 0, page_size/2, page_size/2);
  } else {
    nand_dma_setup(0, 0, 0, page_size, page_size);
  };
  ocm_act_wr_addr = ocm_bank_base(bank_id);
  ocm_act_wr_addr = ocm_act_wr_addr&0x7fffffff;
  ocm_local_rd_addr = ocm_act_wr_addr + 0x10000;
  ocm_local_rd_addr = ocm_local_rd_addr &0x7fffffff;
  page_num = rand_num(1,1000); 
  nand_erase(bank_id, page_num);
  //write data into NAND
  dma_op(WRITE, ocm_act_wr_addr, ocm_local_rd_addr, 0x0|(page_num<<16), 32, 1, 0);

  //####@@@@@ enable readonly bank usage config ####@@@@@
  // datnguyen print("configuring Bank as readonly");
  config_bank_usage(BANK3,0x1); // 
  //read data and compare
  dma_op(READ, ocm_act_wr_addr, ocm_local_rd_addr, 0x0|(page_num<<16), 32, 1, 0);
  //block erasebank_id
  
  nand_erase(bank_id, page_num);
  check_dma_dev_prot_interrupt(bank_id);

  //read from same location and compare with first data
  //if there are data mismatches, issue in wpn functionality
  dma_op(READ, ocm_act_wr_addr, ocm_local_rd_addr, 0x0|(page_num<<16), 32, 1, 0);
  //write data in the same location of nand but at different location in ocm
  //to preserve the first data
  ocm_tmp_wr_addr = ocm_bank_base(bank_id) + 0x8000;
  dma_op(WRITE, ocm_tmp_wr_addr, ocm_local_rd_addr, 0x0|(page_num<<16), 32, 1, 0xa5a5a5a5);
  check_dma_dev_prot_interrupt(bank_id);
  //read from same location and compare with first data
  //if there are data mismatches, issue in wpn functionality
  dma_op(READ, ocm_act_wr_addr, ocm_local_rd_addr, 0x0|(page_num<<16), 32, 1, 0);

  //####@@@@@ enable wroteonly bank usage config ####@@@@@
  // datnguyen print("configuring Bank as writeonly");
  config_bank_usage(BANK3,0x2); // 
  // read from the same location and disable the check
  dma_op(READ, ocm_act_wr_addr, ocm_local_rd_addr, 0x0|(page_num<<16), 32, 0, 0);
  check_dma_dev_prot_interrupt(bank_id);
  // erase the block
  nand_erase(bank_id, page_num);
  // write into same location, read back and compare
  dma_op(WRITE, ocm_act_wr_addr, ocm_local_rd_addr, 0x0|(page_num<<16), 32, 1, 0);
  dma_op(READ, ocm_act_wr_addr, ocm_local_rd_addr, 0x0|(page_num<<16), 32, 1, 0);

  //####@@@@@ config the bank as invalid ####@@@@@
  // datnguyen print("configuring Bank as invalid");
  device_setup(BANK3, 0, NAND, 3, bus_width);
  nand_erase(bank_id, page_num);
  check_dma_dev_prot_interrupt(bank_id);
  dma_op(WRITE, ocm_act_wr_addr, ocm_local_rd_addr, 0x0|(page_num<<16), 32, 1, 0);
  check_dma_dev_prot_interrupt(bank_id);
  dma_op(READ, ocm_act_wr_addr, ocm_local_rd_addr, 0x0|(page_num<<16), 32, 0, 0);
  check_dma_dev_prot_interrupt(bank_id);
}


void nand_dma(int dma_size){

  int i;
  int ecc_algo = 0;
  // int dma_size = 2;


  // datnguyen print("Wait for dma_cmd_valid.\n\r");
  wait_dma_valid();

  // write(0x17012000 + bank_id*0x1000, 0x00000131);       // Nand Bank Setup:  8-bit
  read(0x17012000 + bank_id*0x1000);

  // NAND DMA Specific Device Setup.
  //void nand_dma_setup(int ecc_en, int ecc_algo, int spo_en, int spo, int page_size)
  if (bus_width == 1) {
    nand_dma_setup(0, ecc_algo, 0, 0, page_size/2);
  } else {
    nand_dma_setup(0, ecc_algo, 0, 0, page_size);
  };

  // Put DMA Write and Read functionality in function.

  dma_op(WRITE, ocm_wr_addr, ocm_rd_addr, dev_addr, dma_size, 1, 0);
  dma_op(READ, ocm_wr_addr, ocm_rd_addr, dev_addr, dma_size, 1, 0);
};

// ==
// Basic ECC Test.
// TBD/Limitations:
// 1. Errors are introduced in only first page if dma_size is such that it spans multiple pages.
// 2. Improve spare area byte selection.
// ==
void nand_dma_ecc(int dev_addr, int dma_size, int ecc_algo, int num_errors, int err_loc){

  int i;
  int success, act_num_errors = 0;
  int col = 0x0000;
  int row;
  int togl;
  // Which chunk you want the errors.
  int chunk_no = 1;
  int chunk_size = 512;
  int max_corr_err = 1;

  row = (dev_addr >> 16) & 0x0000FFFF;
  
  // Erase the block before running test so that we don't have any pre-written "corrupt data". It would result in to more errors than expected.
  nand_erase(bank_id, row);

  // Set chunk parameters.
  switch(ecc_algo) {
  case 0:
    chunk_size = 256;
    break;
  case 1:
    chunk_size = 512;
    break;
  case 2:
    chunk_size = 512;
    break;
  };


  // datnguyen print("Wait for dma_cmd_valid.\n\r");
  wait_dma_valid();

  // write(0x17012000 + bank_id*0x1000, 0x00000131);       // Nand Bank Setup:  8-bit
  read(0x17012000 + bank_id*0x1000);

  // NAND DMA Specific Device Setup.
  //void nand_dma_setup(int ecc_en, int ecc_algo, int spo_en, int spo, int page_size)
  if (bus_width == 1) {
    nand_dma_setup(1, ecc_algo, 0, page_size/2, page_size/2);
  } else {
    nand_dma_setup(1, ecc_algo, 0, page_size, page_size);
  };

  // Put DMA Write and Read functionality in function.

  // datnguyen print("Writing NAND Device: dev_addr = ."); putnum(dev_addr); // datnguyen print("dev_addr=");putnum(dev_addr);// datnguyen print("\n\r");
  dma_op(WRITE, ocm_wr_addr, ocm_rd_addr, dev_addr, dma_size, 1, 0);

  chunk_no = rand_num(1, ((dma_size*64)/chunk_size));
  // void nand_corrupt_single_bit (int bank_id,int dev_addr_addr,int col_addr, int bit_position){
  for (i=0; i<num_errors; i=i+1) {
    if (err_loc > 1) { // Data, Spare Mix. Insert altearnate errors in data and spare.
       // datnguyen print ("Inserting Error in Data+Spare Area");// datnguyen print("\n\r");
// datnguyen       togl = rand()%2;
       // datnguyen print("togl = ");putnum(togl);// datnguyen print("\n\r");
       if(togl == 1) {
	      col = rand_num((chunk_size*(chunk_no-1)), (chunk_size*chunk_no)-1);
		   // datnguyen print("corrupting in the data area\n\r ");
	      if(bus_width == 1) {
            col = col/2;
            // datnguyen print("Calling corrupt function: row = "); putnum(row); // datnguyen print("col=");putnum(col);// datnguyen print("\n\r");
            success = nand_corrupt_single_bit (bank_id, row, col,0,15);
	      }
	      else
            success = nand_corrupt_single_bit (bank_id, row, col,0,7);
       } 
	   else { 
		  // datnguyen print("corrupting in the ecc area\n\r ");
	     success = corrupt_ecc_area(bank_id,ecc_algo,chunk_no,0,page_size,row,bus_width);
	   }
       
    } else {
      if (err_loc == 1) { // Data Area
	     // datnguyen print ("Inserting Error in Data Area");// datnguyen print("\n\r");
	     col = rand_num((chunk_size*(chunk_no-1)), (chunk_size*chunk_no)-1);
		 if(bus_width == 1) {
           col = col/2;
           // datnguyen print("Calling corrupt function: row = "); putnum(row); // datnguyen print("col=");putnum(col);// datnguyen print("\n\r");
           success = nand_corrupt_single_bit (bank_id, row, col,0,15);
		 }
		 else
           success = nand_corrupt_single_bit (bank_id, row, col,0,7);
      } else { // Spare Area
	     // datnguyen print ("Inserting Error in spare Area");// datnguyen print("\n\r");
	//col = rand_num(page_size, page_size+i);
		 success = corrupt_ecc_area(bank_id,ecc_algo,chunk_no,0,page_size,row,bus_width);
      };    
    };
    if (success == 0) {
      //// datnguyen print("Incrementing act_num_errors ...\n\r");
      act_num_errors = act_num_errors + 1;
    };

  };

  // datnguyen print("Actual Inserted Errors = ");putnum(act_num_errors);// datnguyen print("\tWhereas num_errors = ");putnum(num_errors);// datnguyen print("\n\r");

  // Recover the configuration if it is changed in corrupt function.
  if (bus_width == 1) {
    nand_dma_setup(1, ecc_algo, 0, page_size/2, page_size/2);
  } else {
    nand_dma_setup(1, ecc_algo, 0, page_size, page_size);
  };

  // datnguyen print("Reading NAND Device: dev_addr = ."); putnum(dev_addr); // datnguyen print("dev_addr=");putnum(dev_addr);// datnguyen print("\n\r");
  dma_op(READ, ocm_wr_addr, ocm_rd_addr, dev_addr, dma_size, 1, 0);
  

  read_ecc_err_cnt();

  failed_addr_t = (dev_addr)|col;

  switch (ecc_algo) {
  case 0:
    if (num_errors == 1) {
      exp_cor_err_t = act_num_errors;
      exp_uncor_err_t = 0;
      if (act_cor_err_t != 1) {
	// datnguyen print ("ERROR: Hamming: SEC Error Count: Exp: 1 Act: ");putnum(act_cor_err_t);// datnguyen print("\n\r");
	pass = 0;
      }
    } else if (num_errors == 2) {

      // Logic for Uncorrectable Error: In this case, ignore Data Errors.
      if (num_data_err < 3) {
	pass = 1;
      };

      exp_cor_err_t = 0;
      exp_uncor_err_t = 1;

      if (act_uncor_err_t != 1) {
	// datnguyen print ("ERROR: Hamming: DED Error Count: Exp: 1 Act: ");putnum(act_uncor_err_t);// datnguyen print("\n\r");
	pass = 0;
      } else {
	pass = 1;
      };
    } else {
    };
    
    break;
    
  case 1:
    if (num_errors <= 4) {
      exp_cor_err_t = act_num_errors;
      exp_uncor_err_t = 0;

      if (act_cor_err_t != act_num_errors) {
	// datnguyen print ("ERROR: BCH_4: SEC Error Count: Exp: ");putnum(act_num_errors);// datnguyen print("Act: ");putnum(act_cor_err_t);// datnguyen print("\n\r");
	pass = 0;
      }
    } else {

      // Logic for Uncorrectable Error: In this case, ignore Data Errors.
      pass = 1;

      exp_cor_err_t = 0;
      exp_uncor_err_t = 1;

      if (act_uncor_err_t != 1) {
	// datnguyen print ("ERROR: BCH_4: DED Error Count: Exp: 1 Act: ");putnum(act_uncor_err_t);// datnguyen print("\n\r");
	pass = 0;
      }
    };

    break;

  case 2:

    if (num_errors <= 8) {
      exp_cor_err_t = act_num_errors;
      exp_uncor_err_t = 0;

      if (act_cor_err_t != act_num_errors) {
	// datnguyen print ("ERROR: BCH_8: SEC Error Count: Exp: ");putnum(act_num_errors);// datnguyen print("\tAct: ");putnum(act_cor_err_t);// datnguyen print("\n\r");
	pass = 0;
      }
    } else {

      // Logic for Uncorrectable Error: In this case, ignore Data Errors.
      pass = 1;

      exp_cor_err_t = 0;
      exp_uncor_err_t = 1;

      if (act_uncor_err_t != 1) {
	// datnguyen print ("ERROR: BCH_8: DED Error Count: Exp: 1 Act: ");putnum(act_uncor_err_t);// datnguyen print("\n\r");
	pass = 0;
      }
    };
    
   break;
    
  };

  cnt_test_err();

};

void nand_erase(int bank_id, int blk_addr) {

  int read_data;
  int cmd_id = 0;
  int cmd_code = 2;
  int cmpl_th = 1;

  // datnguyen print("Erasing Bank::  @ 0x:"); putnum(bank_id); // datnguyen print("\t\tBlock Address:: 0x");  putnum(blk_addr);  // datnguyen print("\n\r");

  // datnguyen print("Wait for dma_cmd_valid.\n\r");
  wait_dma_valid();
/*
  if (bus_width == 1) {
    nand_dma_setup(0, 0, 0, 0, 1024);
  } else {
    nand_dma_setup(0, 0, 0, 0, 2*1024);
  };

*/  
  // Block Erase Command
   
  // Program Destination Address.

  write(0x1701202c + bank_id*0x1000, blk_addr<<16);
  read(0x1701202c + bank_id*0x1000);
  // TBD: Program 8 MBbs "0" for now.
  write(0x17012030 + bank_id*0x1000, 0x00000000);
  read(0x17012030 + bank_id*0x1000);
 
  // Program BLK_ERASE Command.
  read_data = read(0x17012020 + bank_id*0x1000);
  write(0x17012020 + bank_id*0x1000, read_data | (cmd_id << 3 | cmd_code << 7 | cmpl_th << 10 | 3));
  read(0x17012020 + bank_id*0x1000);

  
  wait_dma_completion(); 
  
  pop_completion();

};

void override_test() {
  
  int read_data;
  int dma_size = 2;

  if (bus_width == 1) {
    nand_dma_setup(0, 0, 0, 0, page_size/2);
  } else {
    nand_dma_setup(0, 0, 0, 0, page_size);
  };

  nand_erase(bank_id, block_num);

  // datnguyen print(" Pushing Multiple Commands. ==");// datnguyen print("\n\r");
  // Push 4 commands
  push_cmd(ocm_rd_addr, dev_addr, READ, 2, dma_size);
  wait_dma_completion(); 
  push_cmd(ocm_rd_addr, dev_addr+0x1000, READ, 2, dma_size);
  wait_dma_completion(); 
  push_cmd(ocm_rd_addr, dev_addr+0x2000, READ, 2, dma_size);
  wait_dma_completion(); 
  push_cmd(ocm_rd_addr, dev_addr+0x3000, READ, 2, dma_size);
  wait_dma_completion(); 
  // datnguyen print(" Pushing Multiple Commands. ==");// datnguyen print("\n\r");

  // datnguyen print(" Test Result: ==");// datnguyen print("\n\r");
  /*
  // Check if override interrupt is set.
  read_data = read(0x17012050 + bank_id*0x1000);
  if ((read_data & 0x00000200) != 0x00000200) {
    // datnguyen print("FAIL::  override_test:: @ 0x:"); putnum(read_data); // datnguyen print("\n\r");
    pass_vec = pass_vec << 1;
  } else {
    // datnguyen print("PASS::  override_test:: @ 0x:"); putnum(read_data); // datnguyen print("\n\r");
    pass_vec = ((pass_vec << 1) | 0x00000001);
  };
*/  

  // check_intr(int intr_reg, int exp_int, int mask) {
  check_intr(0x17012050 + bank_id*0x1000, 0x00000200, 0x000000004);

  // Pop Completion
  pop_completion();
  pop_completion();
  pop_completion();

  dma_op(WRITE, ocm_wr_addr, ocm_rd_addr, dev_addr+0x50000, dma_size, 1, 0);
  dma_op(READ, ocm_wr_addr, ocm_rd_addr, dev_addr+0x50000, dma_size, 1, 0);
  dma_op(READ, ocm_wr_addr, ocm_rd_addr, dev_addr+0x50000, dma_size, 1, 0);

  cnt_test_err();
};

void devprot_test() {
  
  int read_data, write_data;
  int dma_size = 2;

  if (bus_width == 1) {
    nand_dma_setup(0, 0, 0, 0, page_size/2);
  } else {
    nand_dma_setup(0, 0, 0, 0, page_size);
  };

  nand_erase(bank_id, block_num);


  // datnguyen print(" Normal Operation. ==");// datnguyen print("\n\r");
  dma_op(WRITE, ocm_wr_addr, ocm_rd_addr, dev_addr, dma_size, 1, 0);
  dma_op(READ, ocm_wr_addr, ocm_rd_addr, dev_addr, dma_size, 1, 0);
  /*
  // datnguyen print(" Write Protect. ==");// datnguyen print("\n\r");
  read_data = read(0x17012000 + bank_id*0x10000);
  write_data = (read_data & 0xffffffcf) | 0x00000010;
  write(0x17012000 + bank_id*0x1000, write_data);
  read_data = read(0x17012000 + bank_id*0x10000);

  ocm_write(ocm_rd_addr, dma_size*64, 100);
  dma_op(WRITE, ocm_wr_addr, ocm_rd_addr, dev_addr+0x20000, dma_size, 1, 0);
  dma_op(READ, ocm_wr_addr, ocm_rd_addr, dev_addr+0x20000, dma_size, 1, 0);
  // Check Interrupt.
  read_data = read(0x17012050 + bank_id*0x1000);
  if ((read_data & 0x00000100) != 0x00000100) {
    // datnguyen print("FAIL::  devprot_test:: @ 0x:"); putnum(read_data); // datnguyen print("\n\r");
    pass_vec = pass_vec << 1;
  } else {
    // datnguyen print("PASS::  devprot_test:: @ 0x:"); putnum(read_data); // datnguyen print("\n\r");
    pass_vec = ((pass_vec << 1) | 0x00000001);
  };
  write(0x17012050 + bank_id*0x1000, read_data);
  read_data = read(0x17012050 + bank_id*0x1000);
  */
  // datnguyen print(" Read Protect. ==");// datnguyen print("\n\r");

  read_data = read(0x17012000 + bank_id*0x1000);
  write_data = (read_data & 0xffffffcf) | 0x00000020;
  write(0x17012000 + bank_id*0x1000, write_data);
  dma_op(WRITE, ocm_wr_addr, ocm_rd_addr, dev_addr+0x30000, dma_size, 1, 0);
  dma_op(READ, ocm_wr_addr, ocm_rd_addr, dev_addr+0x30000, dma_size, 1, 0);

  // Check Interrupt.
  read_data = read(0x17012050 + bank_id*0x1000);
  if ((read_data & 0x00000100) != 0x00000100) {
    // datnguyen print("FAIL::  devprot_test:: @ 0x:"); putnum(read_data); // datnguyen print("\n\r");
    pass_vec = pass_vec << 1;
  } else {
    // datnguyen print("PASS::  devprot_test:: @ 0x:"); putnum(read_data); // datnguyen print("\n\r");
    pass_vec = ((pass_vec << 1) | 0x00000001);
  };
  write(0x17012050 + bank_id*0x1000, read_data);

  // datnguyen print(" All Protect. ==");// datnguyen print("\n\r");

  read_data = read(0x17012000 + bank_id*0x1000);
  write_data = (read_data & 0xffffffcf) | 0x00000000;
  write(0x17012000 + bank_id*0x1000, write_data);
  ocm_write(ocm_rd_addr, dma_size*64, 1000);
  dma_op(WRITE, ocm_wr_addr, ocm_rd_addr, dev_addr+0x40000, dma_size, 1, 0);
  dma_op(READ, ocm_wr_addr, ocm_rd_addr, dev_addr+0x40000, dma_size, 1, 1000);

  // Check Interrupt.
  read_data = read(0x17012050 + bank_id*0x1000);
  if ((read_data & 0x00000100) != 0x00000100) {
    // datnguyen print("FAIL::  devprot_test:: @ 0x:"); putnum(read_data); // datnguyen print("\n\r");
    pass_vec = pass_vec << 1;
  } else {
    // datnguyen print("PASS::  devprot_test:: @ 0x:"); putnum(read_data); // datnguyen print("\n\r");
    pass_vec = ((pass_vec << 1) | 0x00000001);
  };
  write(0x17012050 + bank_id*0x1000, read_data);

  // datnguyen print(" Normal Operation. ==");// datnguyen print("\n\r");
  read_data = read(0x17012000 + bank_id*0x1000);
  write_data = (read_data & 0xffffffcf) | 0x00000030;
  write(0x17012000 + bank_id*0x1000, write_data);

  dma_op(WRITE, ocm_wr_addr, ocm_rd_addr, dev_addr+0x5000, dma_size, 1, 0);
  dma_op(READ, ocm_wr_addr, ocm_rd_addr, dev_addr+0x5000, dma_size, 1, 0);

  cnt_test_err();
  
};

void dma_abort_test() {
  int dma_size = 8;
  int randn = 0;
  int trans_num = 100;

  // Random Operation.
  randn = rand_num(0,2);

  nand_erase(bank_id, block_num);

  // Trigger log DMA operation.

  // Prepare OCM.
  ocm_write(ocm_wr_addr, dma_size*64, 0);

  for (i=0; i<trans_num; i++) {
    // datnguyen print ("dma_abort_test: Transaction Number = "); putnum(i); // datnguyen print("\n\r");
    // Push Command.  
    // datnguyen print("DMA_ABORT: ==\n\r");
    if (randn == 0) {
      // datnguyen print("+++++ dma_abort_test: Write Command ++++");
      push_cmd(ocm_wr_addr, dev_addr, WRITE, 2, dma_size);
    } else if (randn == 1) {
      // datnguyen print("dma_abort_test: Read Command");
      push_cmd(ocm_rd_addr, dev_addr, READ, 2, dma_size);
    } else {
      // datnguyen print("dma_abort_test: Erase Command");
      // nand_erase(bank_id, 0x00000000+rand_num(0,1024));
      push_cmd(ocm_rd_addr, dev_addr, ERASE, 2, dma_size);
    };
    // datnguyen print("DMA_ABORT: ==\n\r");
    // push_cmd(ocm_rd_addr, dev_addr, ERASE, 2, dma_size);

    // Spend some time in dummy OCM Writes.
    ocm_write(0x9d0e0000, rand_num(256,2048), 0);
    
    // Abort in between.
    // datnguyen print("DMA_ABORT: ==\n\r");
    // datnguyen print("DMA_ABORT: Aborting Operation ....\n\r");
    // datnguyen print("DMA_ABORT: ==\n\r");
    dma_abort();
    
    wait_dma_completion(); 
    
    // Check Interrupts.
    check_intr(0x1701000c, 0x00004000, GLBL_MASK);
    
    // Pop Completion
    pop_completion();
    // datnguyen print("DMA_ABORT: Completion Popped.\n\r");
    
    // Check Normal Operations.
    nand_erase(bank_id, 0x00000000);
    dma_op(WRITE, ocm_wr_addr, ocm_rd_addr, dev_addr, 2, 1, 0);  
    dma_op(READ, ocm_wr_addr, ocm_rd_addr, dev_addr, 2, 1, 0);  

    cnt_test_err();
  };
};

void dma_timing_abort_test() {
  int dma_size = 16;


  nand_erase(bank_id, block_num);

  // Trigger log DMA operation.

  // Prepare OCM.
  ocm_write(ocm_wr_addr, dma_size*64, 0);
  
  // Push Command.
  push_cmd(ocm_wr_addr, dev_addr, WRITE, 2, dma_size);

  // Spend some time in dummy OCM Writes.
  ocm_write(0x9d0e0000, 1024, 0);

  // Timing_Abort in between.
  // datnguyen print("DMA_TIMING_ABORT: ==\n\r");
  // datnguyen print("DMA_TIMING_ABORT: Timing_Aborting Operation ....\n\r");
  // datnguyen print("DMA_TIMING_ABORT: ==\n\r");
  dma_timing_abort();
  
  wait_dma_completion(); 

  // Check Interrupts.
  check_intr(0x1701000c, 0x00004000, GLBL_MASK);
  
  // Pop Completion
  pop_completion();
  // datnguyen print("DMA_TIMING_ABORT: Completion Popped.\n\r");

  // Check Normal Operations.
  nand_erase(bank_id, 0x00000000);
  dma_op(WRITE, ocm_wr_addr, ocm_rd_addr, dev_addr, 2, 1, 0);  
  dma_op(READ, ocm_wr_addr, ocm_rd_addr, dev_addr, 2, 1, 0);  

  cnt_test_err();

};

void ecc_err_data_spare(num_trans, data_spare) {

  int indx;

  //row_addr = 0x000000bf;
  row_addr = rand_num(1,0x1ff);
  nand_erase(bank_id, row_addr);  
  nand_erase(bank_id, (row_addr+1));  


  for (indx=0; indx<num_trans; indx=indx+1) {

    // nand_dma_ecc((0x00000000+((row_addr)<<16)), 8, 0, 3, data_spare);


    // Single-bit Hamming
    // datnguyen print ("=== Single-bit Hamming ===\n\r");
    nand_dma_ecc((0x00000000+((row_addr)<<16)), 32, 0, 1, data_spare);

    // Double-bit Hamming  
    // datnguyen print ("=== Double-bit Hamming   ===\n\r");
    nand_dma_ecc((0x00000000+((row_addr)<<16)), 32, 0, 2, data_spare);
    
    // 1-bit BCH_4
    // datnguyen print ("=== 1-bit BCH_4 ===\n\r");
    nand_dma_ecc((0x00000000+((row_addr)<<16)), 32, 1, 1, data_spare);
    
    // 2-bit BCH_4
    // datnguyen print ("=== 2-bit BCH_4 ===\n\r");
    nand_dma_ecc((0x00000000+((row_addr)<<16)), 32, 1, 2, data_spare);

    // 3-bit BCH_4
    // datnguyen print ("=== 3-bit BCH_4 ===\n\r");
    nand_dma_ecc((0x00000000+((row_addr)<<16)), 32, 1, 3, data_spare);
    
    // 4-bit BCH_4
    // datnguyen print ("=== 4-bit BCH_4 ===\n\r");
    nand_dma_ecc((0x00000000+((row_addr)<<16)), 32, 1, 4, data_spare);

    // 1-bit BCH_8
    // datnguyen print ("=== 1-bit BCH_8 ===\n\r");
    nand_dma_ecc((0x00000000+((row_addr)<<16)), 32, 2, 1, data_spare);
    
    // 2-bit BCH_8
    // datnguyen print ("=== 2-bit BCH_8 ===\n\r");
    nand_dma_ecc((0x00000000+((row_addr)<<16)), 32, 2, 2, data_spare);
    
    // 3-bit BCH_8
    // datnguyen print ("=== 3-bit BCH_8 ===\n\r");
    nand_dma_ecc((0x00000000+((row_addr)<<16)), 32, 2, 3, data_spare);
    
    // 4-bit BCH_8
    // datnguyen print ("=== 4-bit BCH_8 ===\n\r");
    nand_dma_ecc((0x00000000+((row_addr)<<16)), 32, 2, 4, data_spare);
    
    // 5-bit BCH_8
    // datnguyen print ("=== 5-bit BCH_8 ===\n\r");
    nand_dma_ecc((0x00000000+((row_addr)<<16)), 32, 2, 5, data_spare);
    
    // 6-bit BCH_8
    // datnguyen print ("=== 6-bit BCH_8 ===\n\r");
    nand_dma_ecc((0x00000000+((row_addr)<<16)), 32, 2, 6, data_spare);
    
    // 7-bit BCH_8
    // datnguyen print ("=== 7-bit BCH_8 ===\n\r");
    nand_dma_ecc((0x00000000+((row_addr)<<16)), 32, 2, 7, data_spare);
    
    // 8-bit BCH_8
    // datnguyen print ("=== 8-bit BCH_8 ===\n\r");
    nand_dma_ecc((0x00000000+((row_addr)<<16)), 32, 2, 8, data_spare);

  };

};

// ===
// == End of Tests.
// ===

// ===
// == Tasks.
// ===


void nand_init() {
  // RAM Shutdown
  write(0x1701d070, 0x00000000);
  read(0x1701d070);

  // SRAM ECC Bypass
  write(0x1701d068, 0xd8b94ff6);
  read(0x1701d068);

  read(0x1701d074);
  read(0x1701d074);
  read(0x1701d074);

  // Scratch
  write(0x17010008, 0xdadababa);
  read(0x17010008);

  write(0x170100d0, 0x3ae00000);
  read(0x170100d0);

  write(0x17010074, 0x00100001);
  read(0x17010074);

  // Timing
  write(0x1701322c, 0x1b1c1b1f);
  read(0x1701322c);

  write(0x17013230, 0x070b0908);
  read(0x17013230);

  write(0x17013234, 0x11070408);
  read(0x17013234);

  write(0x17013238, 0x0014020a);
  read(0x17013238);

};

void wait_dma_completion(){
  int  a = 0x0;
  // int b = 0;
  int cnt = 0;
  printf("Polling for dma_done bit to set\n\r");
  a = read(0x17012034 + bank_id*0x1000);
  while((a & 0x1) == 0x0) {
    a = read(0x17012034 + bank_id*0x1000);
    cnt = cnt + 1;
    if (cnt == 10000) {
      b = 1;
      break;
    };
  };

  if (b == 0) {
    printf("dma_done bit set.\n\r");
	if((a&0x000000c0) != 0x00000040) { // flag error if cmpl status is not success
	printf("WARNING: DMA compl sts err");
	  //error(1);
	}
    printf("GFC INTERRUPT:\n\r");
    read(0x1701000c);
    printf("PER BANK INTERRUPT:\n\r");
    read(0x17012050 + bank_id*0x1000);
  } else {
    printf("dma_done bit not set ... timeout!!!.\n\r");
  };
};

void wait_dma_valid(){
	int  cnt = 0;
  int  a = 0x1;
  printf("Polling for dma_cmd_valid bit to clear: %d\n\r", bank_id);
  cnt =0;
  while((a & 0x1) == 0x1) {
    a = read(0x17012020 + bank_id*0x1000);
    printf("0x17010014 = 0x%08x\n\r", a);
    cnt = cnt+1;
    if (cnt >10) {
      //printf("\n= Manual Timeout for Start bit \n\r");
     break;
	}
  }
  printf("xxxxxxxxx  dma_cmd_valid bit clear.  xxxxxxxxxxxxxx\n\r");
};

// SMV: 071312

// SMV: 071812
void ocm_write(int addr, int size, int base) {
  int i;
  int j;
  int k;

  // SMV: STC.
  addr = addr | 0X80000000;

  // Prepare OCM
  // datnguyen print("Prepare Data in OCM ...\n\r");
  for(i =0; i<size/4; i=i+1) {
    /*
    j = i;
    for (k=1; k<8; k=k+1) {
      j = (i << k*4) | j;
    };
    */
    j = gen_next_data(i, 1);
    j = j | 0x55;
    write(addr+4*i, base+j);
    
  }
  for(i =0; i<size/4; i=i+1) {
    read(addr+4*i);
  }
};

void ocm_read(int addr, int size, int base) {
  int i;

  // SMV: STC.
  addr = addr | 0X80000000;

  // Prepare OCM
  // datnguyen print("Read Data From OCM ...\n\r");
  for(i =0; i<size/4; i=i+1) {
    read(addr+4*i);
  }
};


// Usage:
// bch_t: number of errors to be corrected. 0:4-bit, 1:8-bit
// ecc_algo: 0: Hamming, 1: BCH_4, 2: BCH_8
// page_size in words. for 16-bit device, num_bytes/2.
void nand_dma_setup(int ecc_en, int ecc_algo, int spo_en, int spo, int page_size) {
  int read_data;
  int write_data;
  int bch_n;
  // Actual Multiplication factor.
  int bch_t;
  // 4/8 bit setting in CSR.
  int bch_t_1;
  int ham_bch;
  int spare_offset = 0x800;

  // datnguyen print("ECC Parameters::\n\r");
  // datnguyen print("ALGORITHM: ");

  if (ecc_algo == 0) {
    // datnguyen print("HAMMING\n\r");
    ham_bch = 0;
    bch_t = 1;
    bch_t_1 = 0;
    bch_n = 0;
  } else if (ecc_algo == 1) {
    // datnguyen print("BCH_4\n\r");
    ham_bch = 1;
    bch_t = 4;
    bch_t_1 = 0;
    bch_n = 0x38;
  } else {
    // datnguyen print("BCH_8\n\r");
    ham_bch = 1;
    bch_t = 8;
    bch_t_1 = 1;
    bch_n = 0x68;
  };

  read_data = read(0x17012200 + bank_id*0x1000);
  write_data = (read_data & 0x00000000) | (ecc_en<<7 | ham_bch<<8 | spo_en<<9 | spo<<16);
  write(0x17012200 + bank_id*0x1000, write_data);       // Nand ECC Setup
  read(0x17012200 + bank_id*0x1000);
    
  // bch_n = 13*bch_t;
  read_data = read(0x1701220c + bank_id*0x1000);
  write_data = (read_data & 0x00000000) | (bch_n | bch_t_1<<16);
  write(0x1701220c + bank_id*0x1000, write_data);       // Nand ECC Setup
  read(0x1701220c + bank_id*0x1000);

  read_data = read(0x17012224 + bank_id*0x1000);
  write_data = (read_data & 0x00000000) | page_size;
  write(0x17012224 + bank_id*0x1000, write_data);       // Page Size:  2K
  read(0x17012224 + bank_id*0x1000);
};

// Usage:
// 
void push_cmd(int src_addr, int dst_addr, int cmd_code, int cmd_id, int dma_size) {
  int read_data;
  int write_data;

  // SMV: STC
  // dst_addr = dst_addr | 0x80000000;

  if (cmd_code == 0) { //READ
    write(0x17012024 + bank_id*0x1000, dst_addr);       // START_ADD0
    read(0x17012024 + bank_id*0x1000);
    write(0x17012028 + bank_id*0x1000, 0x00000000);       // START_ADD1
    read(0x17012028 + bank_id*0x1000);
    write(0x1701202c + bank_id*0x1000, src_addr);       // DEST_ADD0
    read(0x1701202c + bank_id*0x1000);
    write(0x17012030 + bank_id*0x1000, 0x00000000);       // DEST_ADD1
    read(0x17012030 + bank_id*0x1000);
  } else if (cmd_code == 1) {
    write(0x17012024 + bank_id*0x1000, src_addr);       // START_ADD0
    read(0x17012024 + bank_id*0x1000);
    write(0x17012028 + bank_id*0x1000, 0x00000000);       // START_ADD1
    read(0x17012028 + bank_id*0x1000);
    write(0x1701202c + bank_id*0x1000, dst_addr);       // DEST_ADD0
    read(0x1701202c + bank_id*0x1000);
    write(0x17012030 + bank_id*0x1000, 0x00000000);       // DEST_ADD1
    read(0x17012030 + bank_id*0x1000);
  } else if (cmd_code == 2) {
    // datnguyen print("Erasing Bank::  @ 0x:"); putnum(bank_id); // datnguyen print("\t\tBlock Address:: 0x");  putnum(dst_addr);  // datnguyen print("\n\r");
  
    // Block Erase Command
    
    // Program Destination Address.
    
    write(0x1701202c + bank_id*0x1000, dst_addr);
    read(0x1701202c + bank_id*0x1000);
    // TBD: Program 8 MBbs "0" for now.
    write(0x17012030 + bank_id*0x1000, 0x00000000);
    read(0x17012030 + bank_id*0x1000);
    
  } else {
    // datnguyen print("INVALID COMMAND!!!");putnum(cmd_code);// datnguyen print("\n\r");
  };
  
  write(0x17012220 + bank_id*0x1000, dma_size);       // DMA Size
  read(0x17012220 + bank_id*0x1000);

  read_data = read(0x17012020 + bank_id*0x1000);
  write_data = (read_data & 0xffffe000) | (1<<10 | cmd_id<<3 | cmd_code<<7 | 3);
  write(0x17012020 + bank_id*0x1000, write_data);
  read(0x17012020 + bank_id*0x1000);

  // write(0x17012020 + bank_id*0x1000, 0x00000483);       // DMA Control - Threshold = 1, NAND_WRITE, cmd_id = 0.
  // read(0x17012020 + bank_id*0x1000);
};

void pop_completion() {
  int read_data;

  // datnguyen print("Popping Completion ...\n\r");
  read_data = read(0x17012020 + bank_id*0x1000);
  read_data = read_data | 0x00000004;
  write(0x17012020 + bank_id*0x1000, read_data);
  read(0x17012020 + bank_id*0x1000);
  read(0x17012020 + bank_id*0x1000);
};

void read_ecc_err_cnt() {
  int read_data;

  // datnguyen print("ECC Error Status::\n\r");
  // datnguyen print("ECC Cor Errors ::\n\r");
  read_data = read(0x1701223c + bank_id*0x1000);
  act_cor_err_t = read_data;
  // datnguyen print("ECC Uncor Errors ::\n\r");
  read_data = read(0x17012240 + bank_id*0x1000);
  act_uncor_err_t = read_data;

};

dma_op(int wr_rd, int ocm_wr_addr, int ocm_rd_addr, int dev_addr, int dma_size, int check, int base) {
  // int pass = 1;
  int read_data = 0;
  int i, j;

  if (wr_rd == WRITE) {
    // Prepare OCM.
    ocm_write(ocm_wr_addr, dma_size*64, base);

    // Push Command.
    bw_trig();
    bw_trig();
    push_cmd(ocm_wr_addr, dev_addr, WRITE, 2, dma_size);

    
    wait_dma_completion(); 
    bw_trig();
    bw_msr();
    
    // Pop Completion
    pop_completion();
    // datnguyen print("NAND_WRITE: Completion Popped.\n\r");

  } else {
    // datnguyen print("Wait for dma_cmd_valid.\n\r");
    wait_dma_valid();
    // datnguyen print("Nand DMA Read\n\r");
    push_cmd(ocm_rd_addr, dev_addr, READ, 1, dma_size);
    
    wait_dma_completion(); 
    
    // Verify Read Data from NAND sitting in OCM.
    ocm_rd_addr = ocm_rd_addr | 0x80000000;
    ocm_wr_addr = ocm_wr_addr | 0x80000000;

    // datnguyen print ("++ check = ++ "); putnum(check);// datnguyen print("\n\r");

    // reset data error counter
    num_data_err = 0;

    for(i =0; i<dma_size*64/4; i=i+1) {
      read_data = read(ocm_rd_addr + i*4);
      if (check == 1) {
	// j = gen_next_data(i, 1);
	// j = j | 0xff;
	j =  read(ocm_wr_addr + i*4);
	if (read_data != j) {
	  // datnguyen print("DATA ERROR::  @ 0x:"); putnum(i); // datnguyen print(" Expected: 0x");  putnum(j);  // datnguyen print(" Received: 0x");  putnum(read_data);  // datnguyen print("\n\r");
	  num_data_err++;
	  pass = 0;
	};
      };
    }
    /*    
    if (check == 1) {
      if (pass != 1) {
	// datnguyen print("Test FAILED.\n\r");
	pass_vec = pass_vec << 1;
	// pass = 1;
      } else {
	// datnguyen print("Test PASSED.\n\r");
	pass_vec = ((pass_vec << 1) | 0x00000001);
      };
    };
    */
    // datnguyen print("Nand DMA Read Completed.\n\r");
    
    // Pop Completion
    pop_completion();

    // datnguyen print("NAND_READ: Completion Popped.\n\r");
  };
};

int gen_next_data(int indx, int sch) {
  int num1;
  int i;
  int j;

  switch (sch) {
  case 0:
    return indx+1;
    break;
  case 1:
    j = indx+1;
    for (i=1; i<8; i=i+1) {
      j = j | (indx<<(4*i));
    };
    return j;
    break;
  };
};

check_intr(int intr_reg, int exp_int, int mask) {
  int mask_1;
  int read_data;
  int res;

  read_data = read(intr_reg);
  // datnguyen print("Interrupt Register: "); putnum(intr_reg);// datnguyen print("Data: "); putnum(read_data); // datnguyen print("\n\r");
  mask_1 = mask | exp_int;
  
  res = mask_1 ^ read_data;
  // Check if unexpected interrupt is not set.
  if (res) {
    // datnguyen print("FAIL:: Unexpected Interrupts Set: "); putnum(res); // datnguyen print("\n\r");
  }

  res = read_data & exp_int;

  if (res) {
    // datnguyen print("PASS:: Expected Interrupts Set: "); putnum(res); // datnguyen print("\n\r");
  } else {
    // datnguyen print("PASS:: Expected Interrupts Not Set: "); putnum(res); // datnguyen print("\n\r");
  };

  write(intr_reg, read_data);

  
};

void dma_abort() {
  
  rd_mod_wr(0x17010060, 0x00000008);

};

void dma_timing_abort() {
  
  // Set DMA Timout Enable.
  rd_mod_wr(0x17010060, 0x00000004);

  // Set Timeout Count
  write(0x17010064, 0x00000001);
  read(0x17010064);
};

void rd_mod_wr(int dma_reg, int write_data) {
  int read_data;
  int mod_data;

  read_data = read(dma_reg);

  mod_data = read_data | write_data;

  write(dma_reg, mod_data);

  read(dma_reg);

};

void cnt_test_err() {

  if (pass == 0) {
    

    exp_cor_err[failed_test_indx] = exp_cor_err_t;
    act_cor_err[failed_test_indx] = act_cor_err_t;
    exp_uncor_err[failed_test_indx] = exp_uncor_err_t;
    act_uncor_err[failed_test_indx] = act_uncor_err_t;
    failed_addr[i] = failed_addr_t;
    failed_test_indx++;

    // datnguyen print("Test FAILED.\n\r");
    // test_err_arr[test_cnt] = 1;
    pass = 1;
    if (exit_on_first_err == 1) {
// datnguyen      exit(1);
    };
  } else {
    // datnguyen print("Test PASSED.\n\r");
    // test_err_arr[test_cnt] = 0;
  };
  test_cnt++;
  row_addr = rand_num(0,2048*64);

  if ((row_addr%64) == 0) {
    page_count = 0;
    block_num = row_addr;
    nand_erase(bank_id, block_num);
  } else {
    page_count++;
  }
  
};

int rand_num(int low, int high) {
  int randn = 0;
  int tmp;

  if (low > high) {
    tmp = low;
    low = high;
    high = tmp;
  };

  if (low == high) {
    randn = low;
  } else {
// datnguyen	  randn = (rand()%(high-low+1))+low;
  };
  // datnguyen print("Generating Random Number: ");putnum(randn);// datnguyen print("\twith lower limit: ");putnum(low);// datnguyen print("\twith upper limit: ");putnum(high);// datnguyen print("\n\r");
  return(randn);
};

// ===
// == This function triggers BW measurement. Each call would toggle *all* the start/stop bits.
// ===
void bw_trig() {
  int read_data;

  // Set Read BW Start.
  read_data = read(0x1701d014);
  write(0x1701d014, read_data ^ 0x1f);
  read(0x1701d014);
  
}; 
// ===
// == This function returns bandwidth in MBPS.
// == Start is triggered on push command and end is triggered on dma_done.
// == to compensate for rdybsy# time, 0.5*t is added.
// ===
void bw_msr() {
  int read_data;
  int byte_cnt;
  int clk_cnt;
  int bw;

  // Measure Master Read BW.
  byte_cnt = read(0x1701d028);
  clk_cnt = read(0x1701d024);
  bw = (byte_cnt/((clk_cnt+(clk_cnt/2))*CLK_PERIOD))*100;
  // datnguyen print ("+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=\n\r");
  // datnguyen print("Master Read: Byte Count = ");putnum(byte_cnt);// datnguyen print("\n\r");
  // datnguyen print("Master Read: Clock Count = ");putnum(clk_cnt);// datnguyen print("\n\r");
  // datnguyen print("Master Read: Bandwidth = ");putnum(bw);// datnguyen print("\n\r");
  // datnguyen print ("+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=\n\r");

  // Measure Master Write BW.
}
void config_wp_n(int bank_num, int wpn_en) {
  int rd_data;
  // datnguyen print("configuring wp_n\n\r");
  rd_data = read(0x17012000 + bank_num*0x1000);
  write((0x17012000 + bank_num*0x1000),(rd_data^(wpn_en<<8)));
}
void check_dma_dev_prot_interrupt(int bank_num) {
  int rd_data;
  rd_data = read(0x17012050 + bank_num*0x1000);
  if(rd_data&0x00000100 != 0x00000100) {
	  ;
	// datnguyen print("ERROR:DMA DEV PROT interrupt is not raised \n\r");
	  // datnguyen 	error(1);
  }
  else {
    // datnguyen print("clearing dev prot interrupt\n\r");
	write((0x17012050 + bank_num*0x1000),0x00000100);
  }
}
// ===
// == End of Tasks.
// ===
