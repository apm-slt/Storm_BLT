//#include <stdio.h>
#include "../include/platform.h"
#include "../include/test_util.h"
#include "../include/gfc_common.h"
#include "../include/gfc_nand.h"
#include "../include/gfc_nor.h"
#include "../include/gfc_dma.h"
#include "../include/gfc_sram.h"
#include "../include/gfc_sram_dma.h"
#include "../include/gfc_interleave.h"

//Tinh-SLT:
#define read read_gfc
#define write write_gfc


void sram_dma_test(){ 
//  //                           bank_id, burst_en, mux_en, twt, fwt, bwt, csn, oen, wbn, wbf, th,  aln, alh, bem)
//  nor_sram_timing_param_change(BANK1,   0x1,      0x0,    0x4, 0x4, 0x2, 0x1, 0x1, 0x1, 0x1, 0x1, 0x7, 0x2, 0x1);
//
//  // BME = 0
//  //sram_BME_enable_disabled(BANK1, 0x0);
//  // BME = 1
//  sram_BME_enable_disabled(BANK1, 0x1);
//
//  // BEM = 0
//  //sram_BEM_enable_disabled(BANK1, 0x0);
//  // BEM = 1
//  sram_BEM_enable_disabled(BANK1, 0x1);
//
//  // Configure SRAM device to use as 8bit device(Actually it is 16bit device)
//  //Configure_SRAM_NOR_8bit_dev(BANK1);
//
//  //// datnguyen print_SRAM_NOR_ctrl_regs(BANK1);
//  //sram_dma_write_OCM2SRAM_DAcheck();
//  //sram_dma_read_SRAM2OCM_DAcheck();
  sram_dma_writeANDread();

//  // Back 2 back SRAM DMA configuration for write and read
//  GFC_SRAM_multiple_DMA_wr_rd_data();
// datnguyen    return 0;
}

void DMA_setup(int bank_id, int src_add31to0, int dst_add31to0, int cmd_code, int cmd_id, int dma_size) {
  int read_data;
  int write_data;
  int cmd_valid = 1; 
  int cmd_push = 1;
  int complNum_4_intr = 1;

  if(GFC_DEBUG)
  {
;	  // datnguyen print("\n\rDMA setup\n\r");}
  }
  write(0x17012024 + (bank_id<<12), src_add31to0);   // START_ADD0
  write(0x17012028 + (bank_id<<12), 0x00000000);     // START_ADD1
  write(0x1701202c + (bank_id<<12), dst_add31to0);   // DEST_ADD0
  write(0x17012030 + (bank_id<<12), 0x00000000);     // DEST_ADD1
  write(0x17012220 + (bank_id<<12), dma_size);       // DMA Size

  read_data = read(0x17012020 + (bank_id<<12));
  write_data = (read_data & 0xffffe000) | ( complNum_4_intr<<10 | cmd_code<<7 | cmd_id<<3 |cmd_push<<1 |cmd_valid);
  write(0x17012020 + (bank_id<<12), write_data);

};

//////////////////////////////////////////////////////////////////////////////////////
//// Method Info:: This method is used to inject back 2 back DMA configuration for 
////               SRAM DMA.
////               Also data integrity is verified through OCM
//////////////////////////////////////////////////////////////////////////////////////
//void GFC_SRAM_multiple_DMA_wr_rd_data() {
//  int bank_id = BANK1;
//  int bus_width = BUS_WIDTH_16;
//  int sramdma_addr = 0x000000;  // should be the actual address going into the device
//  int ocmdma_addr = (0x00ffffff & ocm_bank_base(bank_id)) + OCM_BASE_SOC;
//
//  int wr_cmd_code = DMA_WRITE;
//  int rd_cmd_code = DMA_READ;
//  int cmd_id   = 0;
//  int dma_size = 10; 
//  int i;
//  int device_startadd;     
//  int NUM_DMA_CFG;
//  
//  // Configure SRAM devices for GFC reference
//  disable_norsram_banks(BANK0);
//  disable_norsram_banks(BANK1);
//  disable_norsram_banks(BANK2);
//  disable_norsram_banks(BANK3);
//  disable_norsram_banks(BANK4);
//  disable_norsram_banks(BANK5);
//  
//  setup_norsram_addrmap(BANK0, 0x0 , 0x40);
//  setup_norsram_addrmap(BANK1, 0x40, 0x80);
//  setup_norsram_addrmap(BANK4, 0x80, 0xc0);
//
//  //SRAM setup
//  device_setup (BANK1, BANKVALID, SRAM, READ_WRITE, bus_width);
//  device_startadd = (get_device_startadd32bit(bank_id)+GFC_BASE);
// 
//  //shif address by 1
//  if (bus_width == BUS_WIDTH_16)  {
//     write (0x17010074, 0x60008);
//  }
//  
//  //FPGA_MISC_0
//  if (bank_id == BANK0) {
//     write (0x17040000, 0x00000010); //FPGA_MISC_0, set to FPGA flash   / chipsope bus 2 selected
//  }
//  else {
//     write (0x17040000, 0x00000011); //FPGA_MISC_0, set to Daughter card   / chipsope bus 2 selected
//  }
//  
//  NUM_DMA_CFG = 2;
//  
//  // datnguyen print_SRAM_NOR_ctrl_regs(BANK1);
//
//  // First perform back to back DMA configuraiton and then wait for completion
//  for(i=0; i<NUM_DMA_CFG; i++) {  
//    if(i == 0) {
//	   // Write data to OCM as source data and as expected data for comparison purpose
//      gfc_write_pattern(BANK1, (ocm_bank_base(bank_id)+0),(ocm_bank_base(bank_id)+(dma_size*64)), pattern_rand, OCM, bus_width, NUMONYX, 0xdeadbeef);
//    
//      //setup DMA write
//      DMA_setup(bank_id, ocmdma_addr, sramdma_addr, wr_cmd_code, cmd_id, dma_size);
//	 }  else {
//      //setup DMA read
//      DMA_setup(bank_id, sramdma_addr, ((OCM_BASE_COMPARE & 0x00ffffff) + OCM_BASE_SOC), rd_cmd_code, cmd_id, dma_size);
//	 }
//  }	 
// 
//  // Wait for completion and then start comparing data
//  for(i=0; i<NUM_DMA_CFG; i++) {
//    //Wait for DMA Done
//    wait_dma_completion();
//
//    if(i == 0) {
//      //Used DA to read SRAM data 
//      gfc_read_pattern (BANK1,(device_startadd+0),(device_startadd+(dma_size*64)),SRAM_DMA, bus_width,NUMONYX, 0x00001234);
//	 } else {
//      //Used DA to read OCM_DMA data 
//      gfc_read_pattern (BANK1,(ocm_bank_base(bank_id)+0),(ocm_bank_base(bank_id)+(dma_size*64)), OCM_DMA, bus_width, NUMONYX, 0x00001234);
//	 }
//
//    //Pop completion
//    pop_completion();                                              			
//  }
//}

void SRAM_DMA_setup_wdata(int bank_id, int src_add31to0, int dst_add31to0, int cmd_code, int cmd_id, int dma_size, int data_pattern){

  //seup DMA data
  if (cmd_code == DMA_READ) {}
  else if (cmd_code == DMA_WRITE) {}


  //DMA cmd descriptor setup
  DMA_setup(bank_id, src_add31to0, dst_add31to0, cmd_code, cmd_id, dma_size);
}

int DMA_valid (int bank_id) {
  int csr_data;
  csr_data  = read(0x17012020 + bank_id*0x1000);
  return(csr_data & 0x1);
}

//void sram_dma_write_OCM2SRAM_DAcheck(){
//  int bank_id = BANK1;
//  int bus_width = BUS_WIDTH_16;
//  int dst_addr = 0x000000;  // should be the actual address going into the device
//  int src_addr = (0x00ffffff & OCM_BASE_COMPARE) + OCM_BASE_SOC;
//  int cmd_code = DMA_WRITE;
//  int cmd_id   = 0;
//  int dma_size = 256; 
//  int i;
//  int device_startadd;
//
//  disable_norsram_banks(BANK0);
//  disable_norsram_banks(BANK1);
//  disable_norsram_banks(BANK2);
//  disable_norsram_banks(BANK3);
//  disable_norsram_banks(BANK4);
//  disable_norsram_banks(BANK5);
//  
//  setup_norsram_addrmap(BANK0, 0x0 , 0x40);
//  setup_norsram_addrmap(BANK1, 0x40, 0x80);
//  setup_norsram_addrmap(BANK4, 0x80, 0xc0);
//
//  //SRAM setup
//  device_setup (BANK1, BANKVALID, SRAM, READ_WRITE, BUS_WIDTH_16);
//  device_startadd = (get_device_startadd32bit(bank_id)+GFC_BASE);
//  // datnguyen print("\n\rdevice_startadd = %0x"); putnum(device_startadd); // datnguyen print("\n\r");
// 
//  //shif address by 1
//  if (bus_width == BUS_WIDTH_16)  {
//     write (0x17010074, 0x60008);
//  }
//  
//  //FPGA_MISC_0
//  if (bank_id == BANK0) {
//     write (0x17040000, 0x00000010); //FPGA_MISC_0, set to FPGA flash   / chipsope bus 2 selected
//  }
//  else {
//     write (0x17040000, 0x00000011); //FPGA_MISC_0, set to Daughter card   / chipsope bus 2 selected
//  }
//  
//  //Write data to OCM, both Comparison OCM and OCM used for DMA  
//  gfc_write_pattern (BANK1, (ocm_bank_base(bank_id)+0),(ocm_bank_base(bank_id)+(dma_size*64)), pattern_rand, OCM_DMA, BUS_WIDTH_16, NUMONYX, 0xdeadbeef) ;
//
//  //double check OCM part
//  //gfc_read_pattern (BANK1, (ocm_bank_base(bank_id)+0),(ocm_bank_base(bank_id)+(dma_size*64)), OCM_DMA, BUS_WIDTH_16, NUMONYX, 0x00001234) ;
//  
//  //setup DMA write
//  DMA_setup(bank_id, src_addr, dst_addr, cmd_code, cmd_id, dma_size);
//  //// datnguyen print("\n\rDMA setup\n\r");
// 
//  
//  //Wait for DMA Done
//  wait_dma_completion();
//  // datnguyen print("\n\rDMA Done\n\r");
//
//  //Used DA to read SRAM data 
//  gfc_read_pattern (BANK1, (device_startadd+0),(device_startadd+(dma_size*64)),SRAM_DMA, BUS_WIDTH_16, NUMONYX,0x00001234) ;
//
//  //Pop completion
//  pop_completion();  
//
//
//}

//void sram_dma_read_SRAM2OCM_DAcheck(){
//  int bank_id = BANK1;
//  int bus_width = BUS_WIDTH_16;
//  int src_addr = 0x000000;
//  int dst_addr = (0x00ffffff & OCM_BASE_COMPARE) + OCM_BASE_SOC;
//  int cmd_code = DMA_READ;
//  int cmd_id   = 0;
//  int dma_size = 256; 
//  int i;
//  int device_startadd;
//  int user_pattern = 0x20d0;
//  int block_erase_en = 1;
//
//
//  disable_norsram_banks(BANK0);
//  disable_norsram_banks(BANK1);
//  disable_norsram_banks(BANK2);
//  disable_norsram_banks(BANK3);
//  disable_norsram_banks(BANK4);
//  disable_norsram_banks(BANK5);
//  
//  setup_norsram_addrmap(BANK0, 0x0 , 0x40);
//  setup_norsram_addrmap(BANK1, 0x40, 0x80);
//  setup_norsram_addrmap(BANK4, 0x80, 0xc0);
//
//  //SRAM setup
//  device_setup (BANK1, BANKVALID, SRAM, READ_WRITE, BUS_WIDTH_16);
//  device_startadd = (get_device_startadd32bit(bank_id)+GFC_BASE);
//  // datnguyen print("\n\rdevice_startadd = %0x"); putnum(device_startadd);
//
//  //shift address by 1
//  if (bus_width == BUS_WIDTH_16)  {
//     write (0x17010074, 0x60008);
//  }
//  
//  //FPGA_MISC_0
//  if (bank_id == BANK0) {
//     write (0x17040000, 0x00000010); //FPGA_MISC_0, set to FPGA flash   / chipsope bus 2 selected
//  }
//  else {
//     write (0x17040000, 0x00000011); //FPGA_MISC_0, set to Daughter card   / chipsope bus 2 selected
//  }
//  
//  ////Write data to SRAM, both Comparison OCM and OCM used for DMA  
//  gfc_write_pattern (BANK1, (device_startadd+0),(device_startadd+(dma_size*64)), pattern_rand, SRAM, BUS_WIDTH_16, NUMONYX, 0xdeadbeef) ;
//  gfc_read_pattern (BANK1, (device_startadd+0),(device_startadd+(dma_size*64)),SRAM, BUS_WIDTH_16, NUMONYX, 0x00001234) ;
//
//  //wait_dma ready
//  wait_dma_valid();
//  // datnguyen print("Wait for dma_cmd_valid.\n\r");
//
//  //setup DMA read
//  DMA_setup(bank_id, src_addr, dst_addr, cmd_code, cmd_id, dma_size);
//  // datnguyen print("\n\rDMA setup");
// 
//  
//  //Wait for DMA Done
//  wait_dma_completion();
//  // datnguyen print("\n\rDMA Done");
//
//  //Used DA to read OCM_DMA data 
//  gfc_read_pattern (BANK1, (ocm_bank_base(bank_id)+0),(ocm_bank_base(bank_id)+(dma_size*64)),OCM_DMA, BUS_WIDTH_16, NUMONYX, 0x00001234) ;
//
//  //Pop completion
//  pop_completion();  
//}


void sram_dma_writeANDread(){
  int bank_id = BANK1;
  int bus_width = BUS_WIDTH_16;
  int sramdma_addr = 0x000000;  // should be the actual address going into the device
  int ocmdma_addr = (0x00ffffff & ocm_bank_base(bank_id)) + OCM_BASE_SOC;
  int cmd_id   = 0;
  int dma_size = 256; 
  int i;
  int device_startadd;

  disable_norsram_banks(BANK0);
  disable_norsram_banks(BANK1);
  disable_norsram_banks(BANK2);
  disable_norsram_banks(BANK3);
  disable_norsram_banks(BANK4);
  disable_norsram_banks(BANK5);
  
  setup_norsram_addrmap(BANK0, 0x0 , 0x40);
  setup_norsram_addrmap(BANK3, 0x40, 0x80);
  setup_norsram_addrmap(BANK4, 0x80, 0xc0);

  //SRAM setup
  device_setup (BANK3, BANKVALID, SRAM, READ_WRITE, BUS_WIDTH_8);
  device_startadd = (get_device_startadd32bit(bank_id)+GFC_BASE);
  // datnguyen print("\n\rdevice_startadd = %0x"); putnum(device_startadd); // datnguyen print("\n\r");
 
  //shif address by 1
  if (bus_width == BUS_WIDTH_16)  {
     write (0x17010074, 0x60008);
  }
  
  //FPGA_MISC_0
  if (bank_id == BANK0) {
     write (0x17040000, 0x00000010); //FPGA_MISC_0, set to FPGA flash   / chipsope bus 2 selected
  }
  else {
     write (0x17040000, 0x00000011); //FPGA_MISC_0, set to Daughter card   / chipsope bus 2 selected
  }

  //***********************************
  //
  // DMA write to SRAM, from OCM BANK BASE
  //
  //***********************************

  //Write data to OCM DMA only
  gfc_write_pattern (BANK3, (ocm_bank_base(bank_id)+0),(ocm_bank_base(bank_id)+(dma_size*64)), pattern_rand, OCM, BUS_WIDTH_8, NUMONYX, 0xdeadbeef) ;

  //setup DMA write
  DMA_setup(bank_id, ocmdma_addr, sramdma_addr, DMA_WRITE, cmd_id, dma_size); // datnguyen check move data from OCM to SRAM with DMA mode.
  // datnguyen print("\n\rDMA WRITE setup \n\r");
  
  //Wait for DMA Done
  wait_dma_completion();
  // datnguyen print("\n\rDMA Write Done\n\r");

  //Pop completion
  pop_completion();
  // datnguyen print("\n\rPop Completion\n\r");

  
  //***********************************
  //
  // DMA read from SRAM, to OCM Comparison
  //
  //***********************************
  
  wait_dma_valid();
  // datnguyen print("Wait for dma_cmd_valid.\n\r");

  //setup DMA read
  DMA_setup(bank_id, sramdma_addr, ((OCM_BASE_COMPARE & 0x00ffffff) + OCM_BASE_SOC) , DMA_READ, cmd_id, dma_size);
  // datnguyen print("\n\rDMA READ setup\n\r");
 
  
  //Wait for DMA Done
  wait_dma_completion();
  // datnguyen print("\n\rDMA READ Done\n\r");

  //Pop completion
  pop_completion();  


  //***********************************
  //
  // Data Comparison between OCM BANK BASE and Comparison part
  //
  //***********************************

  //Used DA to read OCM_DMA data 
  gfc_read_pattern (BANK3, (ocm_bank_base(bank_id)+0),(ocm_bank_base(bank_id)+(dma_size*64)), pattern_f,OCM_DMA, BUS_WIDTH_8, NUMONYX, 0x00001234) ;

}

