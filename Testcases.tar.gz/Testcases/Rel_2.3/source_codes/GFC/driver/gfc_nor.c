/*
 *
 */

//#include <stdio.h>
#include "../include/platform.h"
#include "../include/test_util.h"
#include "../include/gfc_common.h"
#include "../include/gfc_nor.h"

//Tinh-SLT
#define read read_gfc
#define write write_gfc
#define read8 read8_gfc
#define write8 write8_gfc
#define read16 read16_gfc
#define write16 write16_gfc
#define error error_gfc

unsigned int nor_test() {
  unsigned int bstatus = 1;

//  spansion_nor_test_default0_Burst(BANK0, NOR, BUS_WIDTH_16, SPANSION, 0x80, 0xc0); //pass nov 09 2012
//  Numonyx_nor_test_default0_Burst(BANK0, NOR, BUS_WIDTH_16, NUMONYX, 0x0, 0x4000); //pass
//  nor_test_default0(BANK0, NOR, BUS_WIDTH_16, NUMONYX,  0x0,  0x4000);        //pass nov 09 2012
//  nor_test_default0(BANK0, NOR, BUS_WIDTH_16, SPANSION, 0x80, 0xc0);          //pass nov 09 2012
//  int nand_buffer_startadd = NAND_BUFFER_STARTADD = 0xc00000 ;
//   int nand_buffer_endadd   = NAND_BUFFER_ENDADD  = 0xffffff ;
//  bstatus = spansion_nor_test_default0(BANK0, NOR, BUS_WIDTH_16, SPANSION, 0x00, 0xFF); //pass nov 09 2012
  bstatus = spansion_nor_test_default0(BANK0, NOR, BUS_WIDTH_16, SPANSION, 0x00, 0xFF); //pass nov 09 2012
//  nor_test_basic0(BANK0, NOR, BUS_WIDTH_16,NUMONYX, 0x0, 0x4000);             //pass nov 09 2012
//  nor_test_boundary_block_check (BANK0, BUS_WIDTH_16, NUMONYX, 0x0, 0x4000);  //pass nov 09 2012
//  Nor_writeprotect_test_default(BANK0, NOR, BUS_WIDTH_16, NUMONYX, 0x0, 0x3ff);
//  Nor_writeprotect_test_default(BANK0, NOR, BUS_WIDTH_16, SPANSION, 0x80, 0xc0);
//  Nor_dev_prot_test_default(BANK0, NOR, BUS_WIDTH_16, NUMONYX, 0x0, 0x3ff);
//  Nor_dev_prot_test_default(BANK0, NOR, BUS_WIDTH_16, SPANSION, 0x80, 0xc0);
  return bstatus;
}


unsigned int nor_test_default0 (int bank_id, int device_type, int bus_width, int vendor, int device_startadd_bit29to16, int device_endadd_bit29to16) {
   unsigned int test_startadd;
   unsigned int test_endadd;
   unsigned int i;
   unsigned int tmp;
   unsigned int test_startblock;
   unsigned int test_endblock;
   unsigned int device_startadd;
   unsigned int incr_size;
   int          user_pattern = 0x20d0;
   int          block_erase_en = 1;
   int bstatus = 1;

   //Disable default BANK address range first
   disable_norsram_banks(BANK0);
   disable_norsram_banks(BANK1);
   disable_norsram_banks(BANK2);
   disable_norsram_banks(BANK3);
   disable_norsram_banks(BANK4);
   disable_norsram_banks(BANK5);

   //Set up bank info
   device_setup_w_add (bank_id, 1, device_type, READ_WRITE, bus_width, device_startadd_bit29to16, device_endadd_bit29to16);
   nor_sram_setup (bank_id, BURST_DIS, MUX_DIS, N_TWT, N_FWT, N_BWT, N_CSN, N_OEN, N_WBN, N_WBF, N_TH, N_ALN, N_ALH);

   //GFC CSR Read: IP Rev
   read (0x17010004);


   //FPGA_MISC_0
   if (bank_id == BANK0) {
     write (0x17040000, 0x00000010);                                 //FPGA_MISC_0, set to FPGA flash      / chipscope bus 2 selected
     if (bus_width == BUS_WIDTH_16) {write (0x17010074, 0x60008); }  //shif address by 1
   }
   else {

     write (0x17040000, 0x00000011);                                 //FPGA_MISC_0, set to Daughter card   / chipscope bus 2 selected
     if (bus_width == BUS_WIDTH_16) {write (0x17010074, 0x60000); }  //make sure no add shifted
   }

   //Get Device Start Add
   device_startadd = (get_device_startadd32bit(bank_id)+GFC_BASE);

   for (i=0; i<4; i++) {
       if (i==0)             {printf("==== BURST_DIS RELAX TIM==");
		                      nor_sram_setup (bank_id, BURST_DIS, MUX_DIS, 0x7F, 0x7F, 0x1F, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7);} //default timing parameters
       else if (i == 1)      {printf("==== BURST_EN RELAX TIM==");
		                      nor_sram_setup (bank_id, BURST_EN,  MUX_DIS, 0x7F, 0x7F, 0x1F, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7, 0x7);} //default timing parameters
       else if (i == 2)      {printf("==== BURST_DIS MIN TIM==");
		                      if(bank_id == BANK0)
		                        nor_sram_setup (bank_id, BURST_DIS, MUX_DIS, N_TWT, N_FWT, N_BWT, N_CSN, N_OEN, N_WBN, N_WBF, N_TH, N_ALN, N_ALH) ; //MIN timing parameters
	                          else if(bank_id == BANK4)
		                        nor_sram_setup (bank_id, BURST_DIS, MUX_DIS, S_TWT, S_FWT, S_BWT, S_CSN, S_OEN, S_WBN, S_WBF, S_TH, S_ALN, S_ALH) ;}  //MIN timing parameters
       else if (i == 3)      {printf("==== BURST_EN MIN TIM==");
		                      if(bank_id == BANK0)
		                        nor_sram_setup (bank_id, BURST_EN, MUX_DIS, N_TWT, N_FWT, N_BWT, N_CSN, N_OEN, N_WBN, N_WBF, N_TH, N_ALN, N_ALH) ; //MIN timing parameters
	                          else if(bank_id == BANK4)
		                        nor_sram_setup (bank_id, BURST_EN, MUX_DIS, S_TWT, S_FWT, S_BWT, S_CSN, S_OEN, S_WBN, S_WBF, S_TH, S_ALN, S_ALH) ;}  //MIN timing parameters
       bstatus = gfc_write_read (bank_id, (device_startadd+0x00000000),(device_startadd+0x00000002), block_erase_en, (device_startadd+0x00000000),(device_startadd+0x00000002),device_type, bus_width, pattern_rand       , vendor, user_pattern) ;
       bstatus = gfc_write_read (bank_id, (device_startadd+0x00001004),(device_startadd+0x00001006), block_erase_en, (device_startadd+0x00001004),(device_startadd+0x00001006),device_type, bus_width, pattern_walking0   , vendor, user_pattern) ;
       bstatus = gfc_write_read (bank_id, (device_startadd+0x00020060),(device_startadd+0x0002006a), block_erase_en, (device_startadd+0x00020060),(device_startadd+0x0002006a),device_type, bus_width, pattern_walking1   , vendor, user_pattern) ;
       bstatus = gfc_write_read (bank_id, (device_startadd+0x0007fffc),(device_startadd+0x0007fffe), block_erase_en, (device_startadd+0x0007fffc),(device_startadd+0x0007fffe),device_type, bus_width, pattern_incremental, vendor, user_pattern) ;
   }

   return bstatus;
}

unsigned int  spansion_nor_test_default0 (int bank_id, int device_type, int bus_width, int vendor, int device_startadd_bit29to16, int device_endadd_bit29to16) {

    unsigned int test_startadd;
    unsigned int test_endadd;
    unsigned int i;
    unsigned int tmp;
    unsigned int test_startblock;
    unsigned int test_endblock;
    unsigned int device_startadd;
    unsigned int incr_size;
    int          user_pattern = 0x20d0;
    int          block_erase_en = 1;
    int bstatus = 1;

//    disable_norsram_banks(BANK0);
//    disable_norsram_banks(BANK1);
//    disable_norsram_banks(BANK2);
//    disable_norsram_banks(BANK3);
//    disable_norsram_banks(BANK4);
//    disable_norsram_banks(BANK5);
    device_setup_w_add (bank_id, 1, device_type, READ_WRITE, bus_width, device_startadd_bit29to16, device_endadd_bit29to16);

    //GFC CSR Read: IP Rev
    read  (0x17010004);

    //make sure no shift address
    if (bus_width == BUS_WIDTH_16)  {
      write (0x17010074, 0x60000);
    }


    //Get Device Start Add
    device_startadd = (get_device_startadd32bit(bank_id) + GFC_NOR_BASE); //  need to check GFC_BASE
    printf("device_startadd = 0x%08x \r\n",device_startadd);
//     bstatus = gfc_write_read (bank_id, (device_startadd+0x00000000),(device_startadd+0x00000010), block_erase_en, (device_startadd+0x00000000),(device_startadd+0x00000010),device_type, bus_width, pattern_f    , vendor, 0xFFFFFFFF) ;
    bstatus = gfc_write_read (bank_id, (device_startadd+0x00000000),(device_startadd+0x00000010), block_erase_en, (device_startadd+0x00000000),(device_startadd+0x00000010),device_type, bus_width, pattern_1234    , vendor, pattern_1234) ;
 //   bstatus = gfc_write_read (bank_id, (device_startadd+0x00001004),(device_startadd+0x00001006), block_erase_en, (device_startadd+0x00001004),(device_startadd+0x00001006),device_type, bus_width, pattern_walking0   , vendor, user_pattern) ;
 //   bstatus = gfc_write_read (bank_id, (device_startadd+0x00020060),(device_startadd+0x0002006a), block_erase_en, (device_startadd+0x00020060),(device_startadd+0x0002006a),device_type, bus_width, pattern_walking1   , vendor, user_pattern) ;
 //   bstatus = gfc_write_read (bank_id, (device_startadd+0x0007fffc),(device_startadd+0x0007fffe), block_erase_en, (device_startadd+0x0007fffc),(device_startadd+0x0007fffe),device_type, bus_width, pattern_incremental, vendor, user_pattern) ;
 //   bstatus = gfc_write_read (bank_id, (device_startadd+0x00091100),(device_startadd+0x00091102), block_erase_en, (device_startadd+0x00091100),(device_startadd+0x00091102),device_type, bus_width, pattern_0, vendor, user_pattern) ;
//   bstatus = gfc_write_read (bank_id, (device_startadd+0x0007250a),(device_startadd+0x0007250c), block_erase_en, (device_startadd+0x0007250a),(device_startadd+0x0007250c),device_type, bus_width, pattern_f, vendor, user_pattern) ;
 //   bstatus = gfc_write_read (bank_id, (device_startadd+0x0000090e),(device_startadd+0x00000910), block_erase_en, (device_startadd+0x0000090e),(device_startadd+0x00000910),device_type, bus_width, pattern_5, vendor, user_pattern) ;
 //   bstatus = gfc_write_read (bank_id, (device_startadd+0x00000000),(device_startadd+0x00000002), block_erase_en, (device_startadd+0x00000000),(device_startadd+0x00000002),device_type, bus_width, pattern_a, vendor, user_pattern) ;

    return bstatus;
}

void nor_test_default1 (int bank_id, int device_type, int bus_width, int vendor) {
   unsigned int test_startadd;
   unsigned int test_endadd;
   unsigned int i;
   unsigned int tmp;
   unsigned int test_startblock;
   unsigned int test_endblock;
   unsigned int device_startadd;
   unsigned int incr_size;
   int          user_pattern = 0x20d0;
   int          block_erase_en = 1;

   //GFC CSR Read: IP Rev
   read  (0x17010004);

   //shif address by 1
   if (bus_width == BUS_WIDTH_16)  {
     write (0x17010074, 0x60008);
   }

   //FPGA_MISC_0
   if (bank_id == BANK0) {
     write (0x17040000, 0x00000010); //FPGA_MISC_0, set to FPGA flash   / chipscope bus 2 selected
   }
   else {
     write (0x17040000, 0x00000011); //FPGA_MISC_0, set to Daughter card   / chipscope bus 2 selected
   }

   //Get Device Start Add
   device_startadd = (get_device_startadd32bit(bank_id)+GFC_BASE);
   gfc_write_read (bank_id, (device_startadd+0x00000000),(device_startadd+0x00077ffe), block_erase_en, (device_startadd+0x00000000),(device_startadd+0x00077ffe),device_type, bus_width, pattern_rand       , vendor, user_pattern) ;
   gfc_write_read (bank_id, (device_startadd+0x00000000),(device_startadd+0x00077ffe), block_erase_en, (device_startadd+0x00000000),(device_startadd+0x00077ffe),device_type, bus_width, pattern_0          , vendor, user_pattern) ;
   gfc_write_read (bank_id, (device_startadd+0x00000000),(device_startadd+0x00077ffe), block_erase_en, (device_startadd+0x00000000),(device_startadd+0x00077ffe),device_type, bus_width, pattern_f          , vendor, user_pattern) ;
   gfc_write_read (bank_id, (device_startadd+0x00000000),(device_startadd+0x00077ffe), block_erase_en, (device_startadd+0x00000000),(device_startadd+0x00077ffe),device_type, bus_width, pattern_5          , vendor, user_pattern) ;
   gfc_write_read (bank_id, (device_startadd+0x00000000),(device_startadd+0x00077ffe), block_erase_en, (device_startadd+0x00000000),(device_startadd+0x00077ffe),device_type, bus_width, pattern_a          , vendor, user_pattern) ;
   gfc_write_read (bank_id, (device_startadd+0x00000000),(device_startadd+0x00077ffe), block_erase_en, (device_startadd+0x00000000),(device_startadd+0x00077ffe),device_type, bus_width, pattern_walking0   , vendor, user_pattern) ;
   gfc_write_read (bank_id, (device_startadd+0x00000000),(device_startadd+0x00077ffe), block_erase_en, (device_startadd+0x00000000),(device_startadd+0x00077ffe),device_type, bus_width, pattern_walking1   , vendor, user_pattern) ;
   gfc_write_read (bank_id, (device_startadd+0x00000000),(device_startadd+0x00077ffe), block_erase_en, (device_startadd+0x00000000),(device_startadd+0x00077ffe),device_type, bus_width, pattern_incremental, vendor, user_pattern) ;
   gfc_write_read (bank_id, (device_startadd+0x00000000),(device_startadd+0x00077ffe), block_erase_en, (device_startadd+0x00000000),(device_startadd+0x00077ffe),device_type, bus_width, pattern_userdefine , vendor, user_pattern) ;
   // datnguyen      return 0;

}
void nor_test_basic0 (int bank_id, int device_type, int bus_width, int vendor, int device_startadd_bit29to16, int device_endadd_bit29to16){
   unsigned int test_startadd;
   unsigned int test_endadd;
   unsigned int i;
   unsigned int tmp;
   unsigned int test_startblock;
   unsigned int test_endblock;
   unsigned int device_startadd;
   unsigned int incr_size;
   int          user_pattern = 0x02d0;
   int          block_erase_en = 1;

   //Disable default BANK address range first
   disable_norsram_banks(BANK0);
   disable_norsram_banks(BANK1);
   disable_norsram_banks(BANK2);
   disable_norsram_banks(BANK3);
   disable_norsram_banks(BANK4);
   disable_norsram_banks(BANK5);


   device_setup_w_add (bank_id, 1, device_type, READ_WRITE, bus_width, device_startadd_bit29to16, device_endadd_bit29to16);
   nor_sram_setup (bank_id, BURST_DIS, MUX_DIS, N_TWT, N_FWT, N_BWT, N_CSN, N_OEN, N_WBN, N_WBF, N_TH, N_ALN, N_ALH);

   //GFC CSR Read: IP Rev
   read  (0x17010004);

   if(bus_width == BUS_WIDTH_16) {
     //shif address by 1
     write (0x17010074, 0x60008);
   }

   //FPGA_MISC_0
   if (bank_id == BANK0) {
     write (0x17040000, 0x00000010); //FPGA_MISC_0, set to FPGA flash   / chipscope bus 2 selected
   }
   else {
     write (0x17040000, 0x00000011); //FPGA_MISC_0, set to Daughter card   / chipscope bus 2 selected
   }

   //Get Device Start Add
   device_startadd = (get_device_startadd32bit(bank_id)+GFC_BASE);

   //multiple block erase. write and read
   gfc_write_read (bank_id, (device_startadd+0x00004f30),(device_startadd+0x00004f40),block_erase_en, (device_startadd+0x00004f30),(device_startadd+0x00004f40), device_type, bus_width, pattern_userdefine , vendor, user_pattern) ;
   gfc_write_read (bank_id, (device_startadd+0x00053f30),(device_startadd+0x00053f40),block_erase_en, (device_startadd+0x00053f30),(device_startadd+0x00053f40), device_type, bus_width, pattern_rand , vendor, user_pattern) ;

   //within the same block as above, multiple single write and one single read
   gfc_write_pattern(bank_id, (device_startadd+0x00053f02), (device_startadd+0x00053f04), pattern_0, device_type, bus_width, vendor, user_pattern) ;
   gfc_write_pattern(bank_id, (device_startadd+0x00053f04), (device_startadd+0x00053f06), pattern_f, device_type, bus_width, vendor, user_pattern) ;
   gfc_write_pattern(bank_id, (device_startadd+0x00053f06), (device_startadd+0x00053f08), pattern_5, device_type, bus_width, vendor, user_pattern) ;
   gfc_write_pattern(bank_id, (device_startadd+0x00053f08), (device_startadd+0x00053f0a), pattern_walking0, device_type, bus_width, vendor, user_pattern) ;
   gfc_write_pattern(bank_id, (device_startadd+0x00053f0a), (device_startadd+0x00053f0c), pattern_walking1, device_type, bus_width, vendor, user_pattern) ;
   gfc_write_pattern(bank_id, (device_startadd+0x00053f0c), (device_startadd+0x00053f0e), pattern_incremental, device_type, bus_width, vendor, user_pattern) ;
   gfc_read_pattern( bank_id, (device_startadd+0x00053f08), (device_startadd+0x00053f0e), pattern_5, device_type, bus_width, vendor, user_pattern) ;
   gfc_read_pattern( bank_id, (device_startadd+0x00053f02), (device_startadd+0x00053f04), pattern_5,  device_type, bus_width, vendor, user_pattern) ;

   }

void nor_test_boundary_block_check (int bank_id, int bus_width, int vendor, int device_startadd_bit29to16, int device_endadd_bit29to16) {
   unsigned int test_startadd;
   unsigned int test_endadd;
   unsigned int i;
   int          user_pattern = 0x012f;
   int          block_erase_en = 1;

   //Disable default BANK address range first
   disable_norsram_banks(BANK0);
   disable_norsram_banks(BANK1);
   disable_norsram_banks(BANK2);
   disable_norsram_banks(BANK3);
   disable_norsram_banks(BANK4);
   disable_norsram_banks(BANK5);

   device_setup_w_add (bank_id, 1, NOR, READ_WRITE, bus_width, device_startadd_bit29to16, device_endadd_bit29to16);
   nor_sram_setup (bank_id, BURST_DIS, MUX_DIS, N_TWT, N_FWT, N_BWT, N_CSN, N_OEN, N_WBN, N_WBF, N_TH, N_ALN, N_ALH);

     if (bus_width == BUS_WIDTH_16) {
       //shif address by 1
       write (0x17010074, 0x60008);
     }

     //FPGA_MISC_0
     if (bank_id == BANK0) {
       write (0x17040000, 0x00000010); //FPGA_MISC_0, set to FPGA flash   / chipscope bus 2 selected
     }
     else {
       write (0x17040000, 0x00000011); //FPGA_MISC_0, set to Daughter card   / chipscope bus 2 selected
     }

     if(vendor== NUMONYX) {
     //The first 4 block: within OCM boundary
     for (i=0;i<4;i=i++) {
       test_startadd = 0x80000000+i*0x10000;
       test_endadd   = 0x80000010+i*0x10000;
       gfc_write_read (bank_id, test_startadd, test_endadd, block_erase_en, test_startadd, test_endadd, NOR, bus_width, i, NUMONYX, user_pattern) ;
     }

     //The last 4 block: out of OCM boundary
     for (i=0;i<4;i=i++) {
       test_startadd = 0x80740032+i*0x10000;
       test_endadd   = 0x80740036+i*0x10000;
       gfc_write_read (bank_id, test_startadd, test_endadd, block_erase_en, test_startadd, test_endadd, NOR, bus_width, i, NUMONYX, user_pattern) ;
     }
   }
     // datnguyen      return 0;

}



void nor_test_basic (void *test_startadd, void *test_endadd, int device_type, int bus_width, int testpattern, int vendor) {
   unsigned int i;
   unsigned int tmp;
   unsigned int test_startblock;
   unsigned int test_endblock;
   unsigned int device_startadd;
   unsigned int incr_size;
   int user_pattern = 0x0000;

   printf("\n\r===== nor_tes_basic_16 , start add= , end_add = , pattern =", test_startadd, test_endadd, testpattern);

   device_setup (BANK0, 1, NOR, READ_WRITE, BUS_WIDTH_16);
   nor_sram_setup (BANK0, BURST_DIS, MUX_DIS, N_TWT, N_FWT, N_BWT, N_CSN, N_OEN, N_WBN, N_WBF, N_TH, N_ALN, N_ALH);

   //GFC CSR Read: IP Rev
   read  (0x17010004);

   //shif address by 1
   write (0x17010074, 0x60008);

   //FPGA_MISC_0
   write (0x17040000, 0x00000010); //FPGA_MISC_0, set to FPGA flash   / chipscope bus 2 selected

   //Get Device Start Add
   device_startadd = (get_device_startadd32bit(BANK0)+GFC_BASE);


   if(vendor == NUMONYX){
     //Device ID: device address:0
     numonyx_clearstatus(test_startadd);
     numonyx_read_device_id(device_startadd);

     //block erase & unlock
     //block size: 64Kword(1 word = 16bit)
     test_startblock = numonyx_get_block_num (BANK0, test_startadd);
     test_endblock = numonyx_get_block_num (BANK0, test_endadd);

     for (i=test_startblock ; i<test_endblock; i++) {
       printf("\n\r==== device_startadd \n\r ", device_startadd);
       tmp = device_startadd+i*0x10000;
       numonyx_unlock(tmp);
       numonyx_BlockErase(tmp);

     }
   }
   else if (vendor == SPANSION){
   }
   gfc_write_pattern(BANK0, test_startadd, test_endadd, testpattern, device_type, bus_width, vendor, user_pattern) ;
   gfc_read_pattern(BANK0, test_startadd, test_endadd, testpattern, device_type, bus_width, vendor, user_pattern) ;

   // datnguyen      return 0;

}

void nor_numonyx_write_pattern(int bank_id, void *test_startadd, void *test_endadd, int bus_width, int testpattern) {
   unsigned int i;
   unsigned int tmp;
   unsigned int incr_size;

   printf("\n\r===== Write Start\n\r");
   tmp = test_endadd-test_startadd;
   if (bus_width == BUS_WIDTH_16) {
     incr_size = 2;
   }
   else {
     incr_size = 1;
   }

   if(testpattern == pattern_rand){
     for (i=0; i<tmp; i=i+incr_size) {
// datnguye ;;
//    	 numonyx_write(bank_id,test_startadd+i,rand(),bus_width);
     }
   }

   else if(testpattern == pattern_0){
     for (i=0; i<tmp; i=i+incr_size) {
       numonyx_write(bank_id,test_startadd+i,0x0,bus_width);
     }
   }
   else if(testpattern == pattern_f){
     for (i=0; i<tmp; i=i+incr_size) {
       numonyx_write(bank_id,test_startadd+i,0xffff,bus_width);
     }
   }
   else if(testpattern == pattern_5){
     for (i=0; i<tmp; i=i+incr_size) {
       numonyx_write(bank_id,test_startadd+i,0x5555,bus_width);
     }
   }

   else if(testpattern == pattern_a){
     for (i=0; i<tmp; i=i+incr_size) {
       numonyx_write(bank_id,test_startadd+i,0xaaaa,bus_width);
     }
   }
   else if(testpattern == pattern_walking1){
     for (i=0; i<tmp; i=i+incr_size) {
       numonyx_write(bank_id,test_startadd+i,1<<((i/2)%16),bus_width);
     }
   }

   else if(testpattern == pattern_walking0){
     for (i=0; i<tmp; i=i+incr_size) {
       numonyx_write(bank_id,test_startadd+i,~(1<<((i/2)%16)),bus_width);
     }
   }
   else if(testpattern == pattern_incremental){
     for (i=0; i<tmp; i=i+incr_size) {
       numonyx_write(bank_id,test_startadd+i,i,bus_width);
     }
   }

   // datnguyen      return 0;
}


void nor_numonyx_read_pattern(int bank_id,void *test_startadd, void *test_endadd, int bus_width, int testpattern) {
   unsigned int i;
   unsigned int tmp;
   unsigned int incr_size;

   tmp = test_endadd-test_startadd;
   if (bus_width == BUS_WIDTH_16) {
     incr_size = 2;
   }
   else {
     incr_size = 1;
   }

   printf("\n====== Put Device in Read mode\n\r");
   write (test_startadd, 0xff);

   printf("\n====== Read Start\n\r");
   for (i=0; i<tmp; i=i+incr_size){
     numonyx_read(bank_id, test_startadd+i,bus_width);
   }

   // datnguyen      return 0;
}

//nor_sram_setup(        bank_id,     BURST_EN,    MUX_DIS,   N_TWT,    N_FWT,   N_BWT,  N_CSN,    N_OEN,  N_WBN,   N_WBF,   N_TH,   N_ALN,  N_ALH);
void nor_sram_setup (int bank_id, int burst_en, int mux_en, int twt, int fwt, int bwt, int csn, int oen, int wbn, int wbf, int th, int aln, int alh){
  int read_data;
  int write_data;

  printf("\n================= NOR/SRAM Setup =================\r\n");
  read_data = read (0x17012100 + (bank_id<<12));
  write_data = (read_data & 0xfffffbff) | (mux_en<<10);
  write (0x17012100 + (bank_id<<12), write_data);

  read_data = read (0x17012104 + (bank_id<<12));
  write_data = (read_data & 0x60080c00) | (twt | fwt<<12 | bwt<<20 | alh<<25 |burst_en<<31);
  write (0x17012104 + (bank_id<<12), write_data);
  read_data = read (0x17012108 + (bank_id<<12));
  write_data = (read_data & 0xfe00000) | (csn | oen<<4 | wbn<<8 | wbf<<12 | th<<16 | aln<<28);
  write (0x17012108 + (bank_id<<12), write_data);
}

void numonyx_read_device_id (short *address){
  int rdata;
    printf("\n=== Read NUMONYX NOR Device ID\n\r");
    write16 (address, 0x90);
    rdata = read16  (address);
    if(rdata != 0x89){
	    printf("\nERROR:NUMONYX NOR Read Device ID Mismatch: Expected = 0x89, Actual = %0x \n\r", rdata);
// datnguyen      error(errOption);
    }
    numonyx_CheckStatus(address);
    numonyx_clearstatus(address);

}

void numonyx_write(int bank_id,void *address, int data, int bus_width){
    short *add_16bit;
    short data_16bit;
    short *OCMadd_16bit;

    char *add_8bit;
    char data_8bit;
    char *OCMadd_8bit;

    unsigned int add_temp = address;
    unsigned int device_startadd = (get_device_startadd32bit(bank_id)+GFC_BASE);
    unsigned int temp = (add_temp - device_startadd);

    unsigned int outOfOCM_bound = over_ocm_boundry(bank_id, temp);
    temp = ocm_bank_base(bank_id) + (temp&0x00ffffff);

    OCMadd_16bit = temp;
    OCMadd_8bit  = temp;

    if (bus_width == BUS_WIDTH_16){
      add_16bit = address;
      data_16bit = data;
      write16 (add_16bit, 0x40); //word write setup command
      write16 (add_16bit, data_16bit);
      if (outOfOCM_bound == 1) {
        printf("\n===== Warning: NUMONYX NOR WRITE, No data write to OCM, out of OCM bounday\n\r");

      }
      else {
        write16 (OCMadd_16bit, data_16bit);
      }

    }
    else {
      add_8bit = address;
      data_8bit = data;
      write8 (add_8bit, 0x40); //word write setup command
      write8 (add_8bit, data_8bit);

      if (outOfOCM_bound == 1) {
        printf("\n===== Warning: NUMONYX NOR WRITE, No data write to OCM, out of OCM bounday\n\r");
      }
      else {
        write8 (OCMadd_8bit, data_8bit);
      }
    }

    numonyx_CheckStatus(address);
    numonyx_clearstatus(address);
}



void numonyx_read(int bank_id,void *address, int bus_width){
  short *add_16bit;
  short data_16bit;
  short *OCMadd_16bit;
  short OCMdata_16bit;

  char *add_8bit;
  char data_8bit;
  char *OCMadd_8bit;
  char OCMdata_8bit;
  unsigned int add_temp = address;
  unsigned int device_startadd  = (get_device_startadd32bit(bank_id)+GFC_BASE);
  unsigned int temp = (add_temp - device_startadd);

  unsigned int outOfOCM_bound  = over_ocm_boundry(bank_id, temp);
  temp = ocm_bank_base(bank_id) + (temp&0x00ffffff);

  OCMadd_16bit = temp;
  OCMadd_8bit  = temp;

  //write16 (0x80000000, 0xff);
  if  (bus_width == BUS_WIDTH_16) {
    add_16bit  = address;
    data_16bit = read16 (add_16bit);

    if (outOfOCM_bound == 1) {
      printf("\n===== Warning: NUMONYX NOR READ, No data read from OCM, out of OCM bounday\n\r");
    }
    else {
      OCMdata_16bit = read16( OCMadd_16bit);

      if(OCMdata_16bit != data_16bit){
        printf("\nERROR: NOR 16bit Read Data Mismatch: Expected = %0x ,  Actual = %0x \n\r", OCMdata_16bit, data_16bit);
// datnguyen        error(errOption);
      }
    }
  }
  else {
    add_8bit  = address;
    data_8bit = read8 (add_8bit);
    if (outOfOCM_bound == 1) {
      printf("\n===== Warning: NUMONYX NOR READ, No data read from OCM, out of OCM bounday\n\r");
    }
    else {
      OCMdata_8bit = read8( OCMadd_8bit);

      if(OCMdata_8bit != data_8bit){
        printf("\nERROR: NOR 8bit Read Data Mismatch: Expected = %0x,  Actual = %0x\n\r", OCMdata_8bit, data_8bit);
// datnguyen        error(errOption);
      }
    }
  }

  numonyx_CheckStatus(address);
  numonyx_clearstatus(address);

}

void numonyx_BlockErase(short *address){
    printf("\n=== Block Erase\n\r");
    numonyx_clearstatus(address);

    write16 (address, 0x20);
    write16 (address, 0xd0);

    numonyx_CheckStatus(address);
}

void numonyx_CheckStatus(short *address){
    short a;
    int   cnt=0;
    //print("\n=== Check Status\n\r");
    write16 (address, 0x70);
    a = read16 (address);

   //while ((a & 0x80) == 0x0){
   while (a != 0x80){
     printf("\n= Wait for device ready \n\r");
     write16 (address, 0x70);
     a = read16 (address);
     cnt = cnt+1;
     if (cnt >1000) {
       printf("\n= Manual Device Ready Timeout\n\r");
// datnguyen       error(1);
     }
   }
   printf("\n=== Read Status Done\n\r");
}

void numonyx_lock(short *address){
    printf("\n=== lock\n\r");
    numonyx_clearstatus(address);

    write16 (address, 0x60);
    write16 (address, 0x01);

    numonyx_CheckStatus(address);
}
void numonyx_unlock(short *address){
    printf("\n=== Unlock\n\r");
    numonyx_clearstatus(address);

    write16 (address, 0x60);
    write16 (address, 0xd0);

    numonyx_CheckStatus(address);
}

void numonyx_ReadStatus(short *address){
    short a;
    printf("\n=== Read Status\n\r");
    write16 (address, 0x70);
    a = read16 (address);
}
void numonyx_clearstatus(short *address){
    //print("\n=== ClearStatus\n\r");
    write16 (address, 0x50);
}

//http://www.xilinx.com/support/documentation/data_sheets/ds617.pdf
//From above datasheet, block size is different within the 128Mbit ML605 built-in NORflash
//add <  0x7f0000, block size = 64Kword(1 word = 16bit)
//add >= 0x7f0000, block size = 16kword
unsigned int numonyx_get_block_num(int bank_id, int test_add){
  unsigned int block_num;
  unsigned int add = test_add;
  unsigned int dev_startadd;
  unsigned int test_baseadd;


  dev_startadd = get_device_startadd32bit(bank_id)+GFC_BASE;
  test_baseadd = add - dev_startadd;

  //64K block size
  if (test_baseadd <0x780000){
     block_num = (test_baseadd/0x10000);
  }

  //16K block size (total 4 block)
  else {
    printf ("\n=== ERROR: Address fall in Numoynx Parameter Block\n\r");
    printf ("\n=== bank id = , === test_add = 0x \n\r", bank_id, test_add);
// datnguyen    error(1);
    //block_num = (test_baseadd-0x7f0000)/0x4000+128;
  }

  return (block_num);
}




void chipscope_diagbus (){
    /*numonyx: 16bit*/
    write (0x17040000, 0x02000010); //FPGA_MISC_0, set to FPGA flash   / chipscope bus 2 selected
    write (0x17040004, 0x1);        //FPGA_MISC_1, select gfc diag bus
    write (0x1701d000, 0x6);        //GFC Diagmod, diag_axi_2[15:0]; If comment out this line, then default is the GFC device ID 05d0
}



void numonyx_write16(short *address, short data){
    write16 (address, 0x40); //word write setup command
    write16 (address, data);

    short *ocm_addr_int;
    int temp = address;
    temp = OCM_BASE + (temp&0x00ffffff);
    ocm_addr_int = temp;
    write16 (ocm_addr_int, data);

    numonyx_CheckStatus(address);
    numonyx_clearstatus(address);
}

short numonyx_read16(short *address){
  short *addr_int;
  addr_int = address;
  //write16 (0x80000000, 0xff);
  short rdata = read16 (addr_int);

  short *ocm_addr_int;
  int temp = address;
  temp = OCM_BASE + (temp&0x00ffffff);
  ocm_addr_int = temp;

  short ocm_rdata = read16 (ocm_addr_int);
  if(ocm_rdata != rdata){
    printf("\nERROR: NOR 16bit Read Data Mismatch: Expected = %0x,  Actual = %0x\n\r", ocm_rdata, rdata);
// datnguyen    error(errOption);
  }

  numonyx_CheckStatus(address);
  numonyx_clearstatus(address);

  return(rdata);
}

void spansion_reset (void *address, int bus_width){
  int address_8bit;
  int address_16bit;
    printf("=== Spansion reset\n\r");
    if (bus_width== BUS_WIDTH_8) {
      address_8bit = address;
      write8((address_8bit), 0xF0);
    }
    else if (bus_width== BUS_WIDTH_16) {
      address_16bit = address;
      write16((address_16bit), 0xF0);
    }
}

void spansion_unlock (void *address, int bus_width){
  int  address_8bit;
  int  address_16bit;

    if (bus_width== BUS_WIDTH_8) {
      address_8bit = address;
      write8((address_8bit+0xAAA), 0xAA); // datnguyen modify 0xAAA -> 0x555
      write8((address_8bit+0x555), 0x55); // datnguyen modify 0x555 -> 0x2AA
    }
    else if (bus_width== BUS_WIDTH_16) {
      address_16bit = address;
      printf("nunlock: add  = 0x%08x \n", address_16bit);
      write16((address_16bit+0xAAA), 0xAAAA); // datnguyen modify 0xAAA -> 0x555, 0xAA -> 0xAAAA
      write16((address_16bit+0x554), 0x5555); // datnguyen modify 0x554 -> 0x2AA, 0x55 -> 0x5555
    }
}

void spansion_unlock_prog (void *address, int bus_width){
  int address_8bit;
  int address_16bit;

    if (bus_width== BUS_WIDTH_8) {
      address_8bit = address;
      write8((address_8bit+0xAAA), 0xAA); // datnguyen modify 0xAAA -> 0x555
      write8((address_8bit+0x555), 0x55); // datnguyen modify 0x555 -> 0x2AA
      write8((address_8bit+0xAAA), 0xA0); // datnguyen modify 0xAAA -> 0x555
    }
    else if (bus_width== BUS_WIDTH_16) {
      address_16bit = address;
      write16((address_16bit+0xAAA), 0xAAAA); // datnguyen modify 0xAAA -> 0x555, 0xAA -> 0xAAAA
      write16((address_16bit+0x554), 0x5555); // datnguyen modify 0x554 -> 0x2AA, 0x55 -> 0x5555
      write16((address_16bit+0xAAA), 0xA0A0); // datnguyen modify 0xAAA -> 0x555, 0xA0 -> 0xA0A0
    }
}

void spansion_chip_erase(void *address, int bus_width){
  int address_8bit;
  int address_16bit;
    printf("\n=== SPANSION NOR CHIP ERASE \n\r");
    if (bus_width== BUS_WIDTH_8) {
      address_8bit = address;
      write8((address_8bit+0xAAA), 0xAA); // datnguyen modify 0xAAA -> 0x555
      write8((address_8bit+0x555), 0x55); // datnguyen modify 0x555 -> 0x2AA
      write8((address_8bit+0xAAA), 0x80); // datnguyen modify 0xAAA -> 0x555
      write8((address_8bit+0xAAA), 0xAA); // datnguyen modify 0xAAA -> 0x555
      write8((address_8bit+0x555), 0x55); // datnguyen modify 0x555 -> 0x2AA
      write8((address_8bit+0xAAA), 0x10); // datnguyen modify 0xAAA -> 0x555
    }
    else if (bus_width== BUS_WIDTH_16) {
      address_16bit = address;
      write16((address_16bit+0xAAA), 0xAAAA); // datnguyen modify 0xAAA -> 0x555, 0xAA -> 0xAAAA
      write16((address_16bit+0x554), 0x5555); // datnguyen modify 0x554 -> 0x2AA, 0x55 -> 0x5555
      write16((address_16bit+0xAAA), 0x8080); // datnguyen modify 0xAAA -> 0x555, 0x80 -> 0x8080
      write16((address_16bit+0xAAA), 0xAAAA); // datnguyen modify 0xAAA -> 0x555, 0xAA -> 0xAAAA
      write16((address_16bit+0x554), 0x5555); // datnguyen modify 0x554 -> 0x2AA, 0x55 -> 0x5555
      write16((address_16bit+0xAAA), 0x1010); // datnguyen modify 0xAAA -> 0x555, 0x10 -> 0x1010
    }

}


unsigned int spansion_get_sector_num(int bank_id, int test_add){ //S29WW512P
  unsigned int sector_num;
  unsigned int add = test_add;
  unsigned int dev_startadd;
  unsigned int test_baseadd;


  dev_startadd = get_device_startadd32bit(bank_id)+GFC_BASE; // datnguyen check GFC_BASE
  test_baseadd = add - dev_startadd;

  //32K sector size
  if (test_baseadd <0x10000){
     sector_num = (test_baseadd/0x8000);
  }

  //128k sector size
  else if (test_baseadd<0x1E00000){
      sector_num = ((test_baseadd-0x10000)/0x20000)+4;
  }

  //last 4 32k sectors
  else {
      sector_num = ((test_baseadd-0x1EF0000)/0x8000)+514;

  }
  printf("\n===  SPANSION NOR SECTOR = 0x%08x \n", sector_num);

  return (sector_num);
}

void spansion_sector_erase(int bank_id,void *address, int bus_width){
  unsigned int address_in = address;
  unsigned int device_startadd  = (get_device_startadd32bit(bank_id)+GFC_BASE);
  unsigned int sector_num = spansion_get_sector_num (bank_id, address);


    printf("\n=== SPANSION NOR SECTOR ERASE \n\r");
    if (bus_width== BUS_WIDTH_8) {
      write8((device_startadd+0xAAA), 0xAA); // datnguyen 0xAAA -> 0x555
      write8((device_startadd+0x555), 0x55); // datnguyen 0x555 -> 0x2AA
      write8((device_startadd+0xAAA), 0x80); // datnguyen 0xAAA -> 0x555
      write8((device_startadd+0xAAA), 0xAA); // datnguyen 0xAAA -> 0x555
      write8((device_startadd+0x555), 0x55); // datnguyen 0x555 -> 0x2AA
      write8(address_in, 0x30);
    }
    else if (bus_width== BUS_WIDTH_16) {
      write16((device_startadd+0xAAA), 0xAAAA); // datnguyen 0xAAA -> 0x555, 0xAA -> 0xAAAA
      write16((device_startadd+0x554), 0x5555); // datnguyen 0x554 -> 0x2AA, 0x55 -> 0x5555
      write16((device_startadd+0xAAA), 0x8080); // datnguyen 0xAAA -> 0x555, 0x80 -> 0x8080
      write16((device_startadd+0xAAA), 0xAAAA); // datnguyen 0xAAA -> 0x555, 0xAA -> 0xAAAA
      write16((device_startadd+0x554), 0x5555); // datnguyen 0x554 -> 0x2AA, 0x55 -> 0x5555
      write16(address_in, 0x30);
    }

}

void spansion_sector_erase_status(int bank_id, void *address, int bus_width){
  unsigned int device_startadd = (get_device_startadd32bit(bank_id)+GFC_BASE);
  unsigned int address_in = address;
  unsigned int rdata1;
  unsigned int rdata2;

  unsigned int rdata1_DQ6;
  unsigned int rdata2_DQ6;

  unsigned int rdata1_DQ2;
  unsigned int rdata2_DQ2;
  unsigned int cnt;

  printf("\n=== SPANSION NOR CHECK SECTOR ERASE STATUS \n\r");

  rdata1 = read (address_in);
  cnt =0;
  while ( (rdata1&0x80) != 0x80){
    rdata1 = read (address_in);
	cnt = cnt + 1;
	if(cnt>75) {
// printf("Manual timeout");
	  break;
	}

  }

  rdata1 = read (address_in);  rdata1_DQ6 = rdata1 & 0x40;  rdata1_DQ2 = rdata1 & 0x4;
  rdata2 = read (address_in);  rdata2_DQ6 = rdata2 & 0x40;  rdata2_DQ2 = rdata2 & 0x4;

  if (rdata1_DQ6 == rdata2_DQ6) {
    if  (rdata1_DQ2 == rdata2_DQ2)
    	printf("\n\r===== Spansion NOR Erase DONE add = 0x%08x \n", address_in);
    else
    	printf("\n\r===== Spansion NOR ERASE SUSPEND add = ", address_in);
  }
  else {
    printf("\n\r===== Reset Device becuase of Spansion NOR DEVICE ERR. add = 0x%08x \n\r", address_in);
    if (bus_width == BUS_WIDTH_8){      write8(device_startadd, 0xf0);} // datnguyen check reset command?
    else if (bus_width == BUS_WIDTH_16){write16(device_startadd, 0xf0);}
  }
}

void spansion_write_operation_status(void *address, int bus_width){
/*  unsigned int address_in = address;
  unsigned int rdata1;
  unsigned int rdata2;
  unsigned int rdata3;

  unsigned int data_valid;

  unsigned int rdata1_DQ6;
  unsigned int rdata2_DQ6;
  unsigned int rdata3_DQ6;

  unsigned int rdata1_DQ2;
  unsigned int rdata2_DQ2;
  unsigned int rdata3_DQ2;

  unsigned int done;
  unsigned int suspend;
  unsigned int timeout;
  unsigned int write_abort;

  print("\n=== SPANSION NOR CHECK WRITE OPERATION STATUS \n\r");

  if(bus_width== BUS_WIDTH_8) {      rdata1 = read8(address_in);  }
  else if(bus_width== BUS_WIDTH_16){ rdata1 = read16(address_in); }

  data_valid = (rdata1 & 0x80); //DQ7 =1

  if(data_valid == 0x80) {
     if(bus_width== BUS_WIDTH_8)      { rdata2 = read8(address_in);  rdata3 = read8(address_in); }
     else if(bus_width== BUS_WIDTH_16){ rdata2 = read16(address_in); rdata3 = read16(address_in);}
     rdata2_DQ6 = rdata2 & 0x40;
     rdata3_DQ6 = rdata3 & 0x40;

     rdata2_DQ2 = rdata2 & 0x4;
     rdata3_DQ2 = rdata3 & 0x4;



  }
  else {
  }
  write_abort = ( ((rdata1|rdata2) & 0x2) == 0x2  );  //DQ1
  timeout     = ( ((rdata1|rdata2) & 0x20)== 0x20 );  //DQ5

  rdata1_DQ6 = rdata1 & 0x40;
  rdata2_DQ6 = rdata1 & 0x40;

  rdata1_DQ2 = rdata1 & 0x4;
  rdata2_DQ2 = rdata1 & 0x4;

  if (write_abort == 0x1) {
     print("\n\r===== Spansion NOR Write Abort, add = "); putnum(address_in);  print("\n\r");
     print("\n\r===== Spansion NOR Status DQ[7:0] = "); putnum(rdata2); print("\n\r");
     error(errOption);
  }
  else if ((rdata1_DQ6 == rdata2_DQ6) & (rdata1_DQ2 == rdata2_DQ2)) {
    print("\n\r===== Spansion NOR Operation Done(write/erase), add = "); putnum(address_in);  print("\n\r");  //vickey

  }
  else if (timeout){
     print("\n\r===== Spansion NOR Timeout(write/erase), add = "); putnum(address_in);  print("\n\r");
     print("\n\r===== Spansion NOR Status DQ[7:0] = "); putnum(rdata2); print("\n\r");
     error(errOption);

  }
  else {

    if(bus_width== BUS_WIDTH_8) {
      rdata1 = read8(address_in);
      rdata2 = read8(address_in);
    }
    else if(bus_width== BUS_WIDTH_16) {
      rdata1 = read16(address_in);
      rdata2 = read16(address_in);
    }

    write_abort = ( ((rdata1|rdata2) & 0x2) == 0x2  );  //DQ1
    timeout     = ( ((rdata1|rdata2) & 0x20)== 0x20 );  //DQ5

    rdata1_DQ6 = rdata1 & 0x40;
    rdata2_DQ6 = rdata1 & 0x40;

    rdata1_DQ2 = rdata1 & 0x4;
    rdata2_DQ2 = rdata1 & 0x4;
  }

  return 0;
*/
}

unsigned int spansion_read_device_id (void *address, int bus_width){
  int rdata;
  int address_8bit;
  int address_16bit;
  int bstatus = 1;

    if (bus_width== BUS_WIDTH_8) {
      address_8bit = address;
      spansion_unlock(address_8bit, bus_width);
      write8((address_8bit + 0xAAA), 0x00000090); // datnguyen 0xAAA -> 0x555
      rdata = read8(address_8bit);

    }
    else if (bus_width== BUS_WIDTH_16) {
      address_16bit = address;
      spansion_unlock(address_16bit, bus_width);
      write16((address_16bit + 0xAAA), 0x9090); // datnguyen 0xAAA -> 0x555, 0x90 -> 0x9090
      rdata = read16(address_16bit);
    }
    printf("\n--- spansion nor ID rdata = 0x%08x  ---\r\n\r\n", rdata);
    if(rdata != 0x01){
    	bstatus = 1;
        printf("\nxxxxxxxxxx ID FAIL  xxxxxxxxxxx\r\n\r\n");
    }
    else
    {
    	bstatus = 0;
        printf("\nxxxxxxxxxx ID PASS  xxxxxxxxxxx\r\n\r\n");
    }
    return bstatus;
}

void spansion_write(int bank_id,void *address, int data, int bus_width){
    short *add_16bit;
    short data_16bit;
    short *OCMadd_16bit;

    char *add_8bit;
    char data_8bit;
    char *OCMadd_8bit;
    unsigned int add_temp = address;
    unsigned int device_startadd  = (get_device_startadd32bit(bank_id)+GFC_BASE);
    unsigned int temp = (add_temp - device_startadd);

    unsigned int outOfOCM_bound  = over_ocm_boundry(bank_id, temp);
    temp = ocm_bank_base(bank_id) + (temp&0x00ffffff);

    OCMadd_16bit = temp;
    OCMadd_8bit  = temp;
    if (bus_width == BUS_WIDTH_16){
      add_16bit = address;
      data_16bit = data;
      spansion_unlock_prog(device_startadd, BUS_WIDTH_16);
      write16 (add_16bit, data_16bit);
      if (outOfOCM_bound == 1) {
        printf("\n===== Warning: SPANSION NOR WRITE, No data write to OCM, out of OCM bounday\n\r");
      }
      else {
          printf("\n===== Nor_Addr_16bit = 0x%08x, Data_16bit = 0x%08x \n\r", add_16bit, data_16bit);
//        printf("\n===== OCM_Addr = 0x%08x, Nor_Addr_16bit = 0x%08x, Data_16bit = 0x%08x \n\r", OCMadd_16bit, add_16bit, data_16bit);
//        write16 (OCMadd_16bit, data_16bit);
      }

    }
    else if (bus_width == BUS_WIDTH_8) {
      add_8bit = address;
      data_8bit = data;
      spansion_unlock_prog(device_startadd, BUS_WIDTH_8);
      write8 (add_8bit, data_8bit);

      if (outOfOCM_bound == 1) {
        printf("\n===== Warning: SPANSION NOR WRITE, No data write to OCM, out of OCM bounday\n\r");
      }
      else {
          printf("\n===== Address_8bit = 0x%08x,Data_8bit = 0x%08x \n\r", OCMadd_8bit, data_8bit);
        write8 (OCMadd_8bit, data_8bit);
      }
    }

}
unsigned int spansion_read(int bank_id,void *address, int bus_width ,int user_pattern){
  short *add_16bit;
  short data_16bit;
  short *OCMadd_16bit;
  short OCMdata_16bit;

  char *add_8bit;
  char data_8bit;
  char *OCMadd_8bit;
  char OCMdata_8bit;
  int bstatus = 1;

  unsigned int add_temp = address;
  unsigned int device_startadd = (get_device_startadd32bit(bank_id)+GFC_NOR_BASE);
  unsigned int temp = (add_temp - device_startadd);

  unsigned int outOfOCM_bound  = over_ocm_boundry(bank_id, temp);
  temp = ocm_bank_base(bank_id) + (temp&0x00ffffff);

  OCMadd_16bit = temp;
  OCMadd_8bit  = temp;
//    printf("\n----------------- begin ocm_bank_base bstatus = 0x%08x ----------- \r\n", bstatus);

  if  (bus_width == BUS_WIDTH_16) {
    add_16bit  = address;
    data_16bit = read16 (add_16bit);
    printf("\n===== Nor_Addr_16bit = 0x%08x, data_16bit = 0x%08x =====\r\n", add_16bit, data_16bit);
    if ( data_16bit == user_pattern ) // data_16bit = pattern_5
    {
    	bstatus = 0;
    }
    else
    {
    	bstatus = 1;
        printf("\n\rERROR: NOR 16bit Read Data Mismatch: Expected = %0x Actual = %0x \n\r", user_pattern, data_16bit);
    }
////      printf("\n----------------- end ocm_bank_base bstatus = 0x%08x ----------- \r\n", bstatus);
//
//    if (outOfOCM_bound == 1) {
//      printf("\nr===== Warning: SPANSION NOR READ, No data read from OCM, out of OCM bounday\n\r");
//    }
//    else {
//      OCMdata_16bit = read16( OCMadd_16bit);
//
//      printf("\n NOR 16bit OCMadd_16bit = %0x add_16bit = %0x \n\r", OCMadd_16bit, add_16bit);
//
//
//      if(OCMdata_16bit != data_16bit){
//        printf("\n\rERROR: NOR 16bit Read Data Mismatch: Expected = %0x Actual = %0x \n\r", OCMdata_16bit, data_16bit);
////         error(errOption);
//      }
//    }
  }
  else {
    add_8bit  = address;
    data_8bit = read8 (add_8bit);
    if (outOfOCM_bound == 1) {
      printf("\n\r===== Warning: SPANSION NOR READ, No data read from OCM, out of OCM bounday\n\r");
    }
    else {
      OCMdata_8bit = read8( OCMadd_8bit);

      if(OCMdata_8bit != data_8bit){
        printf("\n\r ERROR: NOR 8bit Read Data Mismatch: Expected = %0x Actual = %0x \n\r", OCMdata_8bit, data_8bit);
        //  error(errOption);
      }
    }
  }

  return bstatus ;
}

void datacheck_16(short rxdata, short expdata) {
    if (rxdata != expdata) {
      printf("        === Data Mistmatch Found. Exp: received:\n\r", expdata, rxdata );
      // datnguyen error(errOption);
    }
    else {
      //print("        === Data Check OK. Exp: 0x: "); putnum(expdata); print(" received: "); putnum(rxdata); print("\n\r");
    }
}

//void gfc_datacheck(void *address, void expdata, int device_width) {
//
//    if (rxdata != expdata) {
//      print("        === Data Mistmatch Found. Exp: "); putnum(expdata); print(" received: "); putnum(rxdata);print("\n\r");
//      error(errOption);
//    }
//    else {
//      //print("        === Data Check OK. Exp: 0x: "); putnum(expdata); print(" received: "); putnum(rxdata); print("\n\r");
//    }
//}


void nor_test_basic_16(short *test_startadd, short *test_endadd, int testpattern) {
   unsigned int i;
   unsigned int tmp;
   unsigned int test_startblock;
   unsigned int test_endblock;
   unsigned int device_startadd;


   printf("\n===== nor_tes_basic_16: ,start add= %0x, end_add = %0x, pattern = %0x \n\r", test_startadd, test_endadd, testpattern);

//   device_setup (BANK0, 1, NOR, READ_WRITE, BUS_WIDTH_16);
//   nor_sram_setup (BANK0, BURST_DIS, MUX_DIS, N_TWT, N_FWT, N_BWT, N_CSN, N_OEN, N_WBN, N_WBF, N_TH, N_ALN, N_ALH);

   //GFC CSR Read: IP Rev
   read  (0x17010004);

   //shif address by 1
   write (0x17010074, 0x60008);

   //FPGA_MISC_0
   write (0x17040000, 0x00000010); //FPGA_MISC_0, set to FPGA flash   / chipscope bus 2 selected

   //Get Device Start Add
   device_startadd = (get_device_startadd32bit(BANK0)+GFC_BASE);

   //Device ID: device address:0
   numonyx_clearstatus(test_startadd);
   numonyx_read_device_id(device_startadd);

   //block erase & unlock
   //block size: 64Kword(1 word = 16bit)
   test_startblock = numonyx_get_block_num (BANK0, test_startadd);
   test_endblock = numonyx_get_block_num (BANK0, test_endadd);

   for (i=test_startblock ; i<test_endblock; i++) {
     printf("device_startadd \n\r", device_startadd);
     printf("i=", i);
     tmp = device_startadd+i*0x10000;
     numonyx_unlock(tmp);
	numonyx_BlockErase(tmp);
   }

   printf("\n========== Write Start\n\r");
   tmp = (test_endadd-test_startadd)/2;
   if(testpattern == pattern_rand){
     for (i=0; i<tmp; i=i++) {
       numonyx_write16(test_startadd+i,rand());
     }
   }

   else if(testpattern == pattern_0){
     for (i=0; i<tmp; i=i++) {
       printf("i=", i);
       numonyx_write16(test_startadd+i,0x0);
     }
   }
   else if(testpattern == pattern_f){
     for (i=0; i<tmp; i=i++) {
       printf("i=", i);
       numonyx_write16(test_startadd+i,0xffff);
     }
   }
   else if(testpattern == pattern_5){
     for (i=0; i<tmp; i=i++) {
       printf("i=", i);
       numonyx_write16(test_startadd+i,0x5555);
     }
   }

   else if(testpattern == pattern_a){
     for (i=0; i<tmp; i=i++) {
       printf("i=", i);
       numonyx_write16(test_startadd+i,0xaaaa);
     }
   }
   else if(testpattern == pattern_walking1){
     for (i=0; i<tmp; i=i++) {
       printf("i=", i);
       numonyx_write16(test_startadd+i,1<<((i/2)%16));
     }
   }

   else if(testpattern == pattern_walking0){
     for (i=0; i<tmp; i=i++) {
       printf("i=", i);
       numonyx_write16(test_startadd+i,~(1<<((i/2)%16)));
     }
   }
   else if(testpattern == pattern_incremental){
     for (i=0; i<tmp; i=i++) {
       printf("i=", i);
       numonyx_write16(test_startadd+i,i);
     }
   }

   printf("\n========== Put Device in Read mode\n\r");
   write16 (test_startadd, 0xff);

   printf("\n========== Read Start\n\r");
   for (i=0; i<tmp; i=i++){
     numonyx_read16(test_startadd+i);
   }

   // datnguyen      return 0;
}

void spansion_write_Burst(int bank_id, int *sector_add, int word_cnt, void *address, int data, int bus_width, int writetoocm){
    int *add_32bit;
    int data_32bit;
    int *OCMadd_32bit;
    int OCMdata_32bit;
    int i;
    unsigned int add_temp = address;
    unsigned int device_startadd  = (get_device_startadd32bit(bank_id)+GFC_BASE);
    unsigned int temp = (add_temp - device_startadd);

    unsigned int outOfOCM_bound  = over_ocm_boundry(bank_id, temp);
    temp = ocm_bank_base(bank_id) + (temp&0x00ffffff);

    OCMadd_32bit = temp;
    add_32bit = address;
    //data_32bit = data;
    printf("=== Spanstion Burst Write\n\r");
    spansion_unlock(device_startadd, bus_width);
    write16(sector_add, 0x25);  // datnguyen check the write Buffer command
    write16(sector_add, (word_cnt-1));
    //write  (add_32bit, data_32bit);

    for (i=0;i<(word_cnt/2); i++) {
      data_32bit = rand();
      write(add_32bit+i, data_32bit);

      if (outOfOCM_bound == 1) { printf("\n===== Warning: SPANSION NOR WRITE, No data write to OCM, out of OCM bounday\n\r");}
      else {
		if(writetoocm)
          write (OCMadd_32bit+i, data_32bit);
      }
    }

    //closing command
    write16(sector_add, 0x29);
}

void spansion_read_Burst(int bank_id,int word_cnt,void *address, int bus_width){
  int *add_32bit;
  int data_32bit;
  int *OCMadd_32bit;
  int OCMdata_32bit;
  int i;

  unsigned int add_temp = address;
  unsigned int device_startadd  = (get_device_startadd32bit(bank_id)+GFC_BASE);
  unsigned int temp = (add_temp - device_startadd);

  unsigned int outOfOCM_bound  = over_ocm_boundry(bank_id, temp);
  temp = ocm_bank_base(bank_id) + (temp&0x00ffffff);

  OCMadd_32bit = temp;
  add_32bit  = address;

  printf("=== Spanstion Burst Read\n\r");
  // put Spansion NOR in to Read mode
  write16(add_32bit, 0xf0);
  for (i=0; i<word_cnt/2; i++) {
     data_32bit = read  (add_32bit+i);

     if (outOfOCM_bound == 1) {printf("\n\r===== Warning: SPANSION NOR READ, No data read from OCM, out of OCM bounday\n\r");}
     else {
      OCMdata_32bit = read ( OCMadd_32bit+i);

      if(OCMdata_32bit != data_32bit){
        printf("\n\rERROR: NOR Read Data Mismatch: Expected = %0x, Actual = %0x \n\r", OCMdata_32bit, data_32bit);
// datnguyen        error(errOption);
      }
     }

  }
}

void Numonyx_write_Burst(int bank_id, int *sector_add, int word_cnt, void *address, int data, int bus_width, int writetoocm){
  int *add_32bit;
  int data_32bit;
  int *OCMadd_32bit;
  int OCMdata_32bit;
  int i;

  unsigned int add_temp = address;
  unsigned int device_startadd = (get_device_startadd32bit(bank_id)+GFC_BASE);
  unsigned int temp = (add_temp - device_startadd);

  unsigned int outOfOCM_bound = over_ocm_boundry(bank_id, temp);
  temp = ocm_bank_base(bank_id) + (temp&0x00ffffff);
  printf("Numonyx Burst Write\n\r");
  OCMadd_32bit = temp;
  add_32bit  = address;
  write16(sector_add,0xe8);
  write16(sector_add,word_cnt-1);
    for (i=0;i<(word_cnt/2); i++) {
      data_32bit = rand();
      write(add_32bit+i, data_32bit);

      if (outOfOCM_bound == 1) { printf("\n===== Warning: SPANSION NOR WRITE, No data write to OCM, out of OCM bounday\n\r");}
      else {
		if(writetoocm)
          write (OCMadd_32bit+i, data_32bit);
      }
    }
    //closing command
    write16(sector_add, 0xD0);

    numonyx_CheckStatus(address);
    numonyx_clearstatus(address);
}
void Numonyx_read_Burst(int bank_id,int word_cnt,void *address, int bus_width, int check_en){
  int *add_32bit;
  int data_32bit;
  int *OCMadd_32bit;
  int OCMdata_32bit;
  int i;

  unsigned int add_temp = address;
  unsigned int device_startadd = (get_device_startadd32bit(bank_id)+GFC_BASE);
  unsigned int temp = (add_temp - device_startadd);

  unsigned int outOfOCM_bound = over_ocm_boundry(bank_id, temp);
  temp = ocm_bank_base(bank_id) + (temp&0x00ffffff);

  OCMadd_32bit = temp;
  add_32bit  = address;
  printf("Numonyx Burst Read\n\r");
  // put Numonyx NOR in to Read mode
  write16(add_32bit, 0xff);
  for (i=0; i<word_cnt/2; i++) {
     data_32bit = read  (add_32bit+i);

     if (outOfOCM_bound == 1) {printf("\n\r===== Warning: Numonyx NOR BURST READ, No data read from OCM, out of OCM bounday\n\r");}
     else {
      OCMdata_32bit = read ( OCMadd_32bit+i);

      if(OCMdata_32bit != data_32bit && check_en == 0x1){
        printf("\n\rERROR: NOR Read Data Mismatch: Expected = %0x , Actual = %0x \n\r", OCMdata_32bit, data_32bit );
// datnguyen        error(errOption);
      }
     }

  }

  numonyx_CheckStatus(address);
  numonyx_clearstatus(address);

}

void spansion_nor_test_default0_Burst (int bank_id, int device_type, int bus_width, int vendor, int device_startadd_bit29to16, int device_endadd_bit29to16) {
   unsigned int test_startadd;
   unsigned int test_endadd;
   unsigned int i;
   unsigned int tmp;
   unsigned int test_startblock;
   unsigned int test_endblock;
   unsigned int device_startadd;
   unsigned int incr_size;
   int          user_pattern = 0x20d0;
   int          block_erase_en = 1;
   int          a;
   disable_norsram_banks(BANK0);
   disable_norsram_banks(BANK1);
   disable_norsram_banks(BANK2);
   disable_norsram_banks(BANK3);
   disable_norsram_banks(BANK4);
   disable_norsram_banks(BANK5);

   device_setup_w_add (bank_id, 1, device_type, READ_WRITE, bus_width, device_startadd_bit29to16, device_endadd_bit29to16);
   nor_sram_setup (bank_id, BURST_EN, MUX_DIS, S_TWT, S_FWT, S_BWT, S_CSN, S_OEN, S_WBN, S_WBF, S_TH, S_ALN, S_ALH);
   //GFC CSR Read: IP Rev
   read  (0x17010004);

   //FPGA_MISC_0
   if (bank_id == BANK0) {
     write (0x17040000, 0x00000010); //FPGA_MISC_0, set to FPGA flash   / chipscope bus 2 selected
   }
   else {
     //write (0x17040000, 0x00000011); //FPGA_MISC_0, set to Daughter card   / chipscope bus 2 selected
     write (0x17040000, 0x02000011); //FPGA_MISC_0, set to Daughter card   / chipscope bus 2 selected  //!!!!
   }

   //make sure no shift address
   if (bus_width == BUS_WIDTH_16)  {
     write (0x17010074, 0x60000);
   }


   device_startadd = (get_device_startadd32bit(bank_id)+GFC_BASE);

   gfc_write_read (bank_id, (device_startadd+0x00000000),(device_startadd+0x00000010), block_erase_en, (device_startadd+0x00000000),(device_startadd+0x00000010),device_type, bus_width, pattern_5    , vendor, user_pattern) ;

   ////
   int sector_add = 0;
   int word_cnt =(1+rand()%16)*2;
   tmp = get_device_startadd32bit(bank_id)+GFC_BASE+sector_add;


   spansion_read_device_id(0x80800000, bus_width);
   spansion_sector_erase(bank_id, tmp, bus_width);
   spansion_sector_erase_status(bank_id, tmp, bus_width);


   device_startadd = (get_device_startadd32bit(bank_id)+GFC_BASE);
   spansion_write_Burst(bank_id,(get_device_startadd32bit(bank_id)+GFC_BASE+sector_add), word_cnt, (device_startadd+0x0), 0xabcd1234, bus_width,0x1);

   printf("\n\r===== read now\n\r");
   spansion_read_Burst(bank_id,word_cnt,(device_startadd+0x0), bus_width);




   //return 0;

}


void Numonyx_nor_test_default0_Burst (int bank_id, int device_type, int bus_width, int vendor, int device_startadd_bit29to16, int device_endadd_bit29to16) {
   unsigned int test_startadd;
   unsigned int test_endadd;
   unsigned int i;
   unsigned int tmp;
   unsigned int test_startblock;
   unsigned int test_endblock;
   unsigned int device_startadd;
   unsigned int incr_size;
   int          user_pattern = 0x20d0;
   int          block_erase_en = 1;
   disable_norsram_banks(BANK0);
   disable_norsram_banks(BANK1);
   disable_norsram_banks(BANK2);
   disable_norsram_banks(BANK3);
   disable_norsram_banks(BANK4);
   disable_norsram_banks(BANK5);

   device_setup_w_add (bank_id, 1, device_type, READ_WRITE, bus_width, device_startadd_bit29to16, device_endadd_bit29to16);
   nor_sram_setup (bank_id, BURST_EN, MUX_DIS, N_TWT, N_FWT, N_BWT, N_CSN, N_OEN, N_WBN, N_WBF, N_TH, N_ALN, N_ALH);
   //GFC CSR Read: IP Rev
   read  (0x17010004);

   if (bank_id == BANK0) {
     write (0x17040000, 0x02000010); //FPGA_MISC_0, set to FPGA flash   / chipscope bus 2 selected
     if (bus_width == BUS_WIDTH_16) {write (0x17010074, 0x60008); }  //shif address by 1
   }
   else {
     //write (0x17040000, 0x00000011); //FPGA_MISC_0, set to Daughter card   / chipscope bus 2 selected
     write (0x17040000, 0x02000011); //FPGA_MISC_0, set to Daughter card   / chipscope bus 2 selected
     if (bus_width == BUS_WIDTH_16) {write (0x17010074, 0x60000); }  //make sure no add shifted
   }

   //Get Device Start Add
   device_startadd = (get_device_startadd32bit(bank_id)+GFC_BASE);

   gfc_write_read (bank_id, (device_startadd+0x00000000),(device_startadd+0x0000002), block_erase_en, (device_startadd+0x00000000),(device_startadd+0x00000002),device_type, bus_width, pattern_rand  , vendor, user_pattern) ;

   int sector_add = 0;
   int wr_test_startadd = 0;
   int word_cnt =(1+rand()%16)*2;
   tmp = get_device_startadd32bit(bank_id)+GFC_BASE+sector_add;
   wr_test_startadd = (device_startadd+0x0);
   numonyx_clearstatus(wr_test_startadd);
   numonyx_unlock(device_startadd);
   numonyx_read_device_id(device_startadd);
   test_startblock = numonyx_get_block_num (bank_id, wr_test_startadd);
       tmp = device_startadd+(test_startblock*0xffff0000);
       numonyx_unlock(tmp);
       numonyx_BlockErase(tmp);


       Numonyx_write_Burst(bank_id,(device_startadd+sector_add), word_cnt, wr_test_startadd, 0xabcd1234, bus_width,0x1);

   printf("\n\r===== read now\n\r");
   Numonyx_read_Burst(bank_id,word_cnt,wr_test_startadd, bus_width,0x1);

   // datnguyen      return 0;

}

void Nor_writeprotect_test_default(int bank_id, int device_type, int bus_width, int vendor, int device_startadd_bit29to16, int device_endadd_bit29to16) {
   int device_startadd;
   int sector_add;
   int word_cnt;
   int wr_test_startadd;
   disable_norsram_banks(BANK0);
   disable_norsram_banks(BANK1);
   disable_norsram_banks(BANK2);
   disable_norsram_banks(BANK3);
   disable_norsram_banks(BANK4);
   disable_norsram_banks(BANK5);

   device_setup_w_add (bank_id, 1, device_type, READ_WRITE, bus_width, device_startadd_bit29to16, device_endadd_bit29to16);
   //GFC CSR Read: IP Rev
   read  (0x17010004);

   if (bank_id == BANK0) {
     write (0x17040000, 0x02000010); //FPGA_MISC_0, set to FPGA flash   / chipscope bus 2 selected
     nor_sram_setup (bank_id, BURST_EN, MUX_DIS, N_TWT, N_FWT, N_BWT, N_CSN, N_OEN, N_WBN, N_WBF, N_TH, N_ALN, N_ALH);
     if (bus_width == BUS_WIDTH_16) {write (0x17010074, 0x60008); }  //shif address by 1
   }
   else {
     //write (0x17040000, 0x00000011); //FPGA_MISC_0, set to Daughter card   / chipscope bus 2 selected
     write (0x17040000, 0x02000011); //FPGA_MISC_0, set to Daughter card   / chipscope bus 2 selected
     nor_sram_setup (bank_id, BURST_EN, MUX_DIS, S_TWT, S_FWT, S_BWT, S_CSN, S_OEN, S_WBN, S_WBF, S_TH, S_ALN, S_ALH) ;  //MIN timing parameters
     if (bus_width == BUS_WIDTH_16) {write (0x17010074, 0x60000); }  //make sure no add shifted
   }

   //Get Device Start Add
   device_startadd = (get_device_startadd32bit(bank_id)+GFC_BASE);
   if(vendor == NUMONYX) {
     wr_test_startadd = (device_startadd+0x0);
     numonyx_clearstatus(wr_test_startadd);
     numonyx_unlock(device_startadd);
     numonyx_read_device_id(device_startadd);
     //test_startblock = numonyx_get_block_num (bank_id, wr_test_startadd);
     //tmp = device_startadd+(test_startblock*0x10000);
	 word_cnt = 32;
	 sector_add = wr_test_startadd&0xffff0000;
	 numonyx_unlock(sector_add);
	 numonyx_BlockErase(sector_add);
	 Numonyx_write_Burst(bank_id,sector_add, word_cnt, wr_test_startadd, 0xabcd1234, bus_width,0x1);
	 Numonyx_read_Burst(bank_id,word_cnt,wr_test_startadd, bus_width,0x1);
//     numonyx_lock(sector_add);
	 //enabling nor wp_n
	 printf("Enabling Write Protection\n\r");
	 config_nor_wp_n(bank_id,0x0); // 0 - activates wpn functionality
	 // in numonyx a locked block cannot be unlocked when wpn is low
	 // issure erase which should not happen
     numonyx_unlock(sector_add);
     numonyx_BlockErase(sector_add);
	 Numonyx_read_Burst(bank_id,word_cnt,wr_test_startadd, bus_width,0x1);
	 Numonyx_write_Burst(bank_id,sector_add, word_cnt, wr_test_startadd, 0xabcd1234, bus_width,0x0);
	 Numonyx_read_Burst(bank_id,word_cnt,wr_test_startadd, bus_width,0x1);
//
//	 config_nor_wp_n(bank_id,0x1); // 0 - activates wpn functionality
   }
   else if((vendor == SPANSION)){
	 spansion_reset(device_startadd,bus_width);
     wr_test_startadd = (device_startadd+0x0);
     sector_add = wr_test_startadd&0xffff0000;
     word_cnt = 32;
     spansion_read_device_id(device_startadd, bus_width);
     spansion_sector_erase(bank_id, sector_add, bus_width);
     spansion_sector_erase_status(bank_id, sector_add, bus_width);

     spansion_write_Burst(bank_id,sector_add, word_cnt, wr_test_startadd, 0xabcd1234, bus_width,0x1);
     spansion_read_Burst(bank_id,word_cnt,wr_test_startadd, bus_width);
	 printf("enabling write protect\n\r");
	 config_nor_wp_n(bank_id,0x0); // 0 - activates wpn functionality
     spansion_sector_erase(bank_id, sector_add, bus_width);
     spansion_sector_erase_status(bank_id, sector_add, bus_width);
     spansion_read_Burst(bank_id,word_cnt,wr_test_startadd, bus_width);
     spansion_write_Burst(bank_id,sector_add, word_cnt, wr_test_startadd, 0xabcd1234, bus_width,0x0);
     spansion_read_Burst(bank_id,word_cnt,wr_test_startadd, bus_width);
   }

}
void Nor_dev_prot_test_default(int bank_id, int device_type, int bus_width, int vendor, int device_startadd_bit29to16, int device_endadd_bit29to16) {
   int device_startadd;
   int sector_add;
   int word_cnt;
   int wr_test_startadd;
   disable_norsram_banks(BANK0);
   disable_norsram_banks(BANK1);
   disable_norsram_banks(BANK2);
   disable_norsram_banks(BANK3);
   disable_norsram_banks(BANK4);
   disable_norsram_banks(BANK5);

   device_setup_w_add (bank_id, 1, device_type, READ_WRITE, bus_width, device_startadd_bit29to16, device_endadd_bit29to16);
   //GFC CSR Read: IP Rev
   read  (0x17010004);

   if (bank_id == BANK0) {
     write (0x17040000, 0x02000010); //FPGA_MISC_0, set to FPGA flash   / chipscope bus 2 selected
     nor_sram_setup (bank_id, BURST_EN, MUX_DIS, N_TWT, N_FWT, N_BWT, N_CSN, N_OEN, N_WBN, N_WBF, N_TH, N_ALN, N_ALH);
     if (bus_width == BUS_WIDTH_16) {write (0x17010074, 0x60008); }  //shif address by 1
   }
   else {
     //write (0x17040000, 0x00000011); //FPGA_MISC_0, set to Daughter card   / chipscope bus 2 selected
     write (0x17040000, 0x02000011); //FPGA_MISC_0, set to Daughter card   / chipscope bus 2 selected
     nor_sram_setup (bank_id, BURST_EN, MUX_DIS, S_TWT, S_FWT, S_BWT, S_CSN, S_OEN, S_WBN, S_WBF, S_TH, S_ALN, S_ALH) ;  //MIN timing parameters
     if (bus_width == BUS_WIDTH_16) {write (0x17010074, 0x60000); }  //make sure no add shifted
   }

   //Get Device Start Add
   device_startadd = (get_device_startadd32bit(bank_id)+GFC_BASE);
   if(vendor == NUMONYX) {
     wr_test_startadd = (device_startadd+0x0);
     numonyx_clearstatus(wr_test_startadd);
     numonyx_unlock(device_startadd);
     numonyx_read_device_id(device_startadd);
     //test_startblock = numonyx_get_block_num (bank_id, wr_test_startadd);
     //tmp = device_startadd+(test_startblock*0x10000);
	 word_cnt = 32;
	 sector_add = wr_test_startadd&0xffff0000;
	 numonyx_unlock(sector_add);
	 numonyx_BlockErase(sector_add);
	 Numonyx_write_Burst(bank_id,sector_add, word_cnt, wr_test_startadd, 0xabcd1234, bus_width,0x1);
	 Numonyx_read_Burst(bank_id,word_cnt,wr_test_startadd, bus_width,0x1);
     //####@@@@@ enable readonly bank usage config ####@@@@@
     printf("configuring Bank as readonly\n\r");
     config_bank_usage(bank_id,0x1); //
	 write16(wr_test_startadd,0x50); // clear stsreg cmd
	 check_nor_dev_prot_interrupt(bank_id,0x0);
     //####@@@@@ enable writeonly bank usage config ####@@@@@
     printf("configuring Bank as writeonly\n\r");
     config_bank_usage(bank_id,0x2); //
     numonyx_ReadStatus(device_startadd);
     check_nor_dev_prot_interrupt(bank_id,0x1);
     //####@@@@@ config the bank as invalid ####@@@@@
     printf("configuring Bank as invalid\n\r");
     device_setup(bank_id, 0, device_type, 3, bus_width);
     write16 (device_startadd, 0x70);
     check_nor_dev_prot_interrupt(bank_id,0x0);
     read16 (device_startadd);
     check_nor_dev_prot_interrupt(bank_id,0x1);
     printf("configuring Bank as normal\n\r");
     device_setup(bank_id, 1, device_type, 3, bus_width);
     numonyx_read_device_id(device_startadd);

   }
   else if((vendor == SPANSION)){
	 spansion_reset(device_startadd,bus_width);
     wr_test_startadd = (device_startadd+0x0);
     sector_add = wr_test_startadd&0xffff0000;
     word_cnt = 32;
     spansion_read_device_id(device_startadd, bus_width);
     spansion_sector_erase(bank_id, sector_add, bus_width);
     spansion_sector_erase_status(bank_id, sector_add, bus_width);

     spansion_write_Burst(bank_id,sector_add, word_cnt, wr_test_startadd, 0xabcd1234, bus_width,0x1);
     spansion_read_Burst(bank_id,word_cnt,wr_test_startadd, bus_width);
     //####@@@@@ enable readonly bank usage config ####@@@@@
     printf("configuring Bank as readonly\n\r");
     config_bank_usage(bank_id,0x1); //
     write16((sector_add+0x555), 0xAA);  // datnguyen 0xAAA -> 0x555
     check_nor_dev_prot_interrupt(bank_id,0x0);
	 spansion_read(bank_id,wr_test_startadd,bus_width, 0x00001234);
     //####@@@@@ enable writeonly bank usage config ####@@@@@
     printf("configuring Bank as writeonly\n\r");
     config_bank_usage(bank_id,0x2); //
	 read16 (wr_test_startadd);
	 check_nor_dev_prot_interrupt(bank_id,0x1);
     //####@@@@@ config the bank as invalid ####@@@@@
     printf("configuring Bank as invalid\n\r");
     device_setup(bank_id, 0, device_type, 3, bus_width);
     write16((sector_add+0x555), 0xAA);  // datnguyen 0xAAA -> 0x555
     check_nor_dev_prot_interrupt(bank_id,0x0);
	 read16 (wr_test_startadd);
	 check_nor_dev_prot_interrupt(bank_id,0x1);
     printf("configuring Bank as normal\n\r");
     device_setup(bank_id, 1, device_type, 3, bus_width);
     spansion_read_device_id(device_startadd, bus_width);
   }

}

void config_nor_wp_n(int bank_num, int wpn_en) {
  int rd_data;
  rd_data = read (0x17012000 + bank_num*0x1000);
  write((0x17012000 + bank_num*0x1000),((rd_data&0xfffffdff)|(wpn_en<<9)));
}
void check_nor_dev_prot_interrupt(int bank_num,int rw_prot_err) {
  int rd_data;
  rd_data = read (0x17012050 + bank_num*0x1000);
  if(rd_data&0x00000400 != 0x00000400) {
	printf("ERROR:NOR/SRAM DEV PROT interrupt is not raised \n\r");
	// datnguyen  	error(1);
  }
  else {
    printf("clearing dev prot interrupt\n\r");
	write((0x17012050 + bank_num*0x1000),0x00000100);
	write(0x1701000c,0x00040000);
	rd_data = read (0x1701014c);
	/*
	if(rw_prot_err == 1) {
	  if( rd_data&&0x20!=0x20) {
	    print("ERROR: r_prot_err bit not set in gfc_err_info\n\r");
	    error(1);
	  }
	  else
	    write(0x1701014c, 0x20);
	}
	else {
	  if( rd_data&&0x40!=0x40) {
	    print("ERROR: w_prot_err bit not set in gfc_err_info\n\r");
	    error(1);
	  }
	  else
	    write(0x1701014c, 0x40);
	}
    */
  }
}
