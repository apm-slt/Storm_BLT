//#include <stdio.h>
#include "../include/platform.h"
#include "../include/test_util.h"
#include "../include/gfc_common.h"
#include "../include/gfc_nand.h"
#include "../include/gfc_nor.h"
#include "../include/gfc_dma.h"
#include "../include/gfc_interleave.h"

//Tinh-SLT
#define read read_gfc
#define write write_gfc


void interleave_test(){  
  interleave_basic(); 
  interleave_test1(); 
}

void interleave_basic(){ 
  ////bank0
 disable_norsram_banks(BANK0);
 disable_norsram_banks(BANK1);
 disable_norsram_banks(BANK2);
 disable_norsram_banks(BANK3);
 disable_norsram_banks(BANK4);
 disable_norsram_banks(BANK5);

 setup_norsram_addrmap(BANK0, 0x0 , 0x40);
 setup_norsram_addrmap(BANK1, 0x40, 0x80);
 setup_norsram_addrmap(BANK4, 0x80, 0xc0);
  
  //bank0
  // datnguyen print("\n\r===== NUMONYX NOR TEST START\n\r\n\r");
  nor_test_basic0(BANK0, NOR, BUS_WIDTH_16,NUMONYX, 0x0, 0x40);//1Gbyte
  
  //bank1
  // datnguyen print("\n\r===== SRAM TEST START\n\r\n\r");
  //device_setup_w_add (BANK0, 0, NOR, READ_WRITE, BUS_WIDTH_16, 0x200, 0x1ff);//disable bank 0 & force bank0 address invalid
  sram_test_default0(BANK1, SRAM, BUS_WIDTH_16, NUMONYX, 0x40, 0x80);//16Mbyte 
  
  
  //bank2
  nand_test_default1 (BANK2, NAND, BUS_WIDTH_8, ECC_OFF, BCH, ECC_BCH8);
  
  
  //bank3
  nand_test_default1 (BANK3, NAND, BUS_WIDTH_16, ECC_OFF, BCH, ECC_BCH8);

  //bank4
  // datnguyen print("\n\r===== SPANSION NOR TEST START\n\r\n\r");
  spansion_nor_test_default0(BANK4, NOR, BUS_WIDTH_16, SPANSION, 0x80, 0xc0); //pass

// datnguyen return 0;
}


void interleave_test1(){
      int sram_dma_operation;
      int sram_dma_size     = 20; //int sram_dma_size     = OCM_SIZE_BANK1/64;
      int sram_bus_width    = BUS_WIDTH_8;
      int sram_cmd_id       = 0;
      int sram_dma_w_srcadd = (ocm_bank_base(BANK1)& 0x00ffffff ) + OCM_BASE_SOC;
      int sram_dma_w_desadd = 0x000000;   
      int sram_dma_r_srcadd = 0x000000;   
      int sram_dma_r_desadd = (OCM_BASE_COMPARE & 0x00ffffff) + OCM_BASE_SOC;
      int total_valid_sram_dma_req  = 0;
      int i;
    
      int nand_buffer_startadd = NAND_BUFFER_STARTADD ;
      int nand_buffer_endadd   = NAND_BUFFER_ENDADD ;
      
      int bank_id = BANK1; //used for wait_dma_valid();
    
      int BANK2_bus_width   = BUS_WIDTH_8;
      int BANK2_device_size = 0x1000;
      int BANK2_block_size  = 0x80;
      int BANK2_page_size   = 0x1000;
      int BANK2_ecc_on_off  = ECC_ON;
      int BANK2_ecc_alg     = HAMMING;
      int BANK2_user_pattern= 0x20d0;
      int BANK2_nand_rowadd = 0x0;
      int BANK2_nand_coladd = 0x0;
      int BANK2_data_byte_size;
      int BANK2_test_type;  
     
      int BANK3_bus_width   = BUS_WIDTH_16;
      int BANK3_device_size = 0x1000;
      int BANK3_block_size  = 0x80;
      int BANK3_page_size   = 0x1000;
      int BANK3_ecc_on_off  = ECC_ON;
      int BANK3_ecc_alg     = BCH;
      int BANK3_user_pattern= 0x20d0;
      int BANK3_nand_rowadd = 0x0;
      int BANK3_nand_coladd = 0x0;
      int BANK3_data_byte_size;
      int BANK3_test_type;

      int BANK4_bus_width   = BUS_WIDTH_16;      
      int BANK4_device_startadd;
      int BANK4_block_erase_en = 1;
      int BANK4_user_pattern   = 0xbeef;
      int BANK4_test_type;    
      int BANK4_test_startadd;
      int BANK4_data_byte_size = 10;

      //***********************************
      //
      // Address MAP setup
      //
      //***********************************
      
      disable_norsram_banks(BANK0);
      disable_norsram_banks(BANK1);
      disable_norsram_banks(BANK2);
      disable_norsram_banks(BANK3);
      disable_norsram_banks(BANK4);
      disable_norsram_banks(BANK5);
      
      setup_norsram_addrmap(BANK0, 0x0 , 0x40);
      setup_norsram_addrmap(BANK1, 0x40, 0x80);
      setup_norsram_addrmap(BANK4, 0x80, 0xc0);
      
      //***********************************
      //
      // Device setup
      //
      //***********************************
      
      //bank1: used as 8 bit device to avoid address shifting
      device_setup (BANK1, BANKVALID, SRAM, READ_WRITE, sram_bus_width);
      nor_sram_setup (BANK1, BURST_DIS, MUX_DIS, N_TWT, N_FWT, N_BWT, N_CSN, N_OEN, N_WBN, N_WBF, N_TH, N_ALN, N_ALH);  
      
      //bank2
      device_setup(BANK2, BANKVALID, NAND, READ_WRITE, BANK2_bus_width);
      nand_setup (BANK2, BANK2_ecc_on_off, BANK2_ecc_alg, ECC_BCH8, BANK2_device_size, BANK2_block_size, BANK2_page_size);
      if (BANK2_ecc_on_off == ECC_ON) { BANK2_data_byte_size = 512; }
      else                            { BANK2_data_byte_size = 16;  }
      
      //bank3: address shifting is taken care by the daughter card, Erase make 0->1
      device_setup(BANK3, BANKVALID, NAND, READ_WRITE, BANK3_bus_width);
      nand_setup (BANK3, BANK3_ecc_on_off, BANK3_ecc_alg, ECC_BCH8, BANK3_device_size, BANK3_block_size, BANK3_page_size);
      if (BANK3_ecc_on_off == ECC_ON) { BANK3_data_byte_size = 512; }
      else                            { BANK3_data_byte_size = 16;  }
        
      //bank4: address shifting is taken care by the daughter card, Erase make 0->1
      device_setup (BANK4, BANKVALID, NOR, READ_WRITE, BANK4_bus_width);
      nor_sram_setup (BANK4, BURST_DIS, MUX_DIS, S_TWT, S_FWT, S_BWT, S_CSN, S_OEN, S_WBN, S_WBF, S_TH, S_ALN, S_ALH);// need to have tighten timing
      BANK4_device_startadd = (get_device_startadd32bit(BANK4)+GFC_BASE);
      BANK4_test_startadd   = BANK4_device_startadd;
      

      //***********************************
      //
      // ENV setup:
      // 1. EBUS signals go to Daughter Cards  
      // 2. Even boundary for NAND
      //
      //***********************************
      write (0x17040000, 0x00000011); //FPGA_MISC_0, set to Daughter card   / chipsope bus 2 selected
      write (0x17010074, 0xe0000);    //even bound = 1  //temp kumar
    
    
      //***********************************
      //
      // OCM Bank Associated part setup: NOR/NAND related set to 1, SRAM related
      //
      //***********************************
      gfc_write_pattern (BANK1, (ocm_bank_base(BANK1)+0),(ocm_bank_base(BANK1)+(sram_dma_size*64)), pattern_rand, OCM, sram_bus_width, NUMONYX, 0xdeadbeef); //SRAM DMA setup


      //if (1stTIMETEST) {
      //  gfc_write_pattern (BANK2, (ocm_bank_base(BANK2)+0),(ocm_bank_base(BANK2)+OCM_SIZE_BANK2),pattern_f, OCM, BUS_WIDTH_32, NUMONYX, 0xffffffff);//write ffff_ffff to NAND checking related OCM 
      //  gfc_write_pattern (BANK3, (ocm_bank_base(BANK3)+0),(ocm_bank_base(BANK3)+OCM_SIZE_BANK3),pattern_f, OCM, BUS_WIDTH_32, NUMONYX, 0xffffffff);//write ffff_ffff to NAND checking related OCM 
      //  gfc_write_pattern (BANK4, (ocm_bank_base(BANK4)+0),(ocm_bank_base(BANK4)+OCM_SIZE_BANK4),pattern_f, OCM, BUS_WIDTH_32, NUMONYX, 0xffffffff);//write ffff_ffff to NOR  checking related OCM 
      //} 
      //else {
      //  gfc_write_pattern (BANK2, (ocm_bank_base(BANK2)+0),(ocm_bank_base(BANK2)+BANK2_data_byte_size),pattern_f, OCM, BUS_WIDTH_32, NUMONYX, 0xffffffff);//write ffff_ffff to NAND checking related OCM 
      //  gfc_write_pattern (BANK3, (ocm_bank_base(BANK3)+0),(ocm_bank_base(BANK3)+BANK3_data_byte_size),pattern_f, OCM, BUS_WIDTH_32, NUMONYX, 0xffffffff);//write ffff_ffff to NAND checking related OCM 
      //
      //}
   
      
      //***********************************
      //
      // SRAM DMA Descriptors setup
      //
      //***********************************
       
      
      wait_dma_valid(); // datnguyen print("\n\rWrite DMA CMD descriptor\n\r");
      DMA_setup(BANK1, sram_dma_w_srcadd, sram_dma_w_desadd , DMA_WRITE, sram_cmd_id, sram_dma_size);   // datnguyen print("\n\r=============== DMA WRITE  \n\r");
    
      wait_dma_valid(); // datnguyen print("\n\rWrite DMA CMD descriptor\n\r");
      DMA_setup(BANK1, sram_dma_r_srcadd, sram_dma_r_desadd , DMA_READ,  sram_cmd_id, sram_dma_size);   // datnguyen print("\n\r=============== DMA READ \n\r");
    
      wait_dma_valid(); // datnguyen print("\n\rWrite DMA CMD descriptor\n\r");
      DMA_setup(BANK1, sram_dma_r_srcadd, sram_dma_r_desadd , DMA_READ,  sram_cmd_id, sram_dma_size);   // datnguyen print("\n\r=============== DMA READ \n\r");
                    
      //***********************************
      //
      // NOR/NAND DA
      //
      //***********************************
        

      //SPANSION NOR: BANK4
      //BANK4_test_type = rand() & 0x1;
      //BANK4_test_startadd  = rand()%OCM_SIZE_BANK4;
      //BANK4_data_byte_size = rand()%(OCM_SIZE_BANK4-BANK4_test_startadd);
      //gfc_write_pattern (BANK4, (ocm_bank_base(BANK4)+0),(ocm_bank_base(BANK4)+10),pattern_f, OCM, BUS_WIDTH_32, NUMONYX, 0xffffffff);//write ffff_ffff to NOR  checking related OCM 

      BANK4_test_type = WRITE_TEST; 
      gfc_write_read_test (BANK4, BANK4_test_type, (BANK4_device_startadd+0x0),(BANK4_device_startadd+0x40), BANK4_block_erase_en, (BANK4_device_startadd+0x0),(BANK4_device_startadd+0x10),NOR, BANK4_bus_width, pattern_5, SPANSION, BANK4_user_pattern) ;   
      
      //NAND: BANK3 
      //BANK3_test_type = rand() & 0x1; 
      BANK3_test_type = WRITE_TEST; 
      nand_test_interleave (BANK3, BANK3_test_type, BANK3_bus_width, BANK3_ecc_on_off, BANK3_ecc_alg, ECC_BCH8, BANK3_nand_rowadd, BANK3_nand_coladd, BANK3_data_byte_size, BANK3_user_pattern, nand_buffer_startadd, nand_buffer_endadd);
      
      //NAND: BANK2 
      //BANK2_test_type = rand() & 0x1;
      BANK2_test_type = WRITE_TEST;  
      nand_test_interleave (BANK2, BANK2_test_type, BANK2_bus_width, BANK2_ecc_on_off, BANK2_ecc_alg, ECC_BCH8, BANK2_nand_rowadd, BANK2_nand_coladd, BANK2_data_byte_size, BANK2_user_pattern, nand_buffer_startadd, nand_buffer_endadd);
      
      //***********************************
      //
      // SRAM DMA Data Comparison between OCM BANK BASE and Comparison part
      //
      //***********************************  
    
      for (i=0; i<3; i++ ) {
        wait_dma_completion();
        pop_completion();     
      }
      
      //Used DA to read OCM_DMA data 
      gfc_read_pattern (BANK1, ocm_bank_base(BANK1),(ocm_bank_base(BANK1)+(sram_dma_size*64)),pattern_f,OCM_DMA, BUS_WIDTH_8, NUMONYX, 0x00001234) ;
    
}




void interleave_test2(){
  int sram_dma_operation;
  int sram_dma_size  = 1; //int sram_dma_size     = OCM_SIZE_BANK1/64;
  int sram_bus_width = BUS_WIDTH_8;
  int sram_cmd_id    = 0;
  int sram_dma_w_srcadd = (0x00ffffff & ocm_bank_base(BANK1)) + OCM_BASE_SOC;
  int sram_dma_w_desadd = 0x000000;   
  int sram_dma_r_srcadd = 0x000000;   
  int sram_dma_r_desadd = (OCM_BASE_COMPARE & 0x00ffffff) + OCM_BASE_SOC;
  int total_valid_sram_dma_req  = 0;
  
  int i;

  int BANK2_device_size = 0x1000;
  int BANK2_block_size  = 0x80;
  int BANK2_page_size   = 0x1000;
  
  int BANK3_device_size = 0x1000;
  int BANK3_block_size  = 0x80;
  int BANK3_page_size   = 0x1000;

  //***********************************
  //
  // Address MAP setup
  //
  //***********************************
    
  disable_norsram_banks(BANK0);
  disable_norsram_banks(BANK1);
  disable_norsram_banks(BANK2);
  disable_norsram_banks(BANK3);
  disable_norsram_banks(BANK4);
  disable_norsram_banks(BANK5);
  
  setup_norsram_addrmap(BANK0, 0x0 , 0x40);
  setup_norsram_addrmap(BANK1, 0x40, 0x80);
  setup_norsram_addrmap(BANK4, 0x80, 0xc0);

 //***********************************
  //
  // Device setup
  //
  //***********************************

  //bank1: SRAM used as 8 bit device to avoid address shifting
  device_setup (BANK1, BANKVALID, SRAM, READ_WRITE, sram_bus_width);
  nor_sram_setup (BANK1, BURST_DIS, MUX_DIS, N_TWT, N_FWT, N_BWT, N_CSN, N_OEN, N_WBN, N_WBF, N_TH, N_ALN, N_ALH);  

 //bank2
  device_setup(BANK2, BANKVALID, NAND, READ_WRITE, BUS_WIDTH_8);
  nand_setup (BANK2, ECC_ON, BCH, ECC_BCH8, BANK2_device_size, BANK2_block_size, BANK2_page_size);
  
  //bank3: address shifting is taken care by the daughter card, Erase make 0->1
  device_setup(BANK3, BANKVALID, NAND, READ_WRITE, BUS_WIDTH_16);
  nand_setup (BANK3, ECC_ON, BCH, ECC_BCH8, BANK3_device_size, BANK3_block_size, BANK3_page_size);
  
  //bank4: address shifting is taken care by the daughter card, Erase make 0->1
  device_setup (BANK4, BANKVALID, NOR, READ_WRITE, BUS_WIDTH_16);
  nor_sram_setup (BANK4, BURST_DIS, MUX_DIS, S_TWT, S_FWT, S_BWT, S_CSN, S_OEN, S_WBN, S_WBF, S_TH, S_ALN, S_ALH);// need to have tighten timing

  //***********************************
  //
  // EBUS signals go to Daughter Cards
  //
  //***********************************

  //shif address by 1
  if (sram_bus_width == BUS_WIDTH_16)  {
     write (0x17010074, 0x60008);
  }
  
  //EBUS signals to Daughter card, FPGA_MISC_0
  write (0x17040000, 0x00000011); //FPGA_MISC_0, set to Daughter card   / chipsope bus 2 selected


  //***********************************
  //
  // DMA write to SRAM, from OCM BANK BASE
  //
  //***********************************

  //Write data to OCM DMA only
  gfc_write_pattern (BANK1, (ocm_bank_base(BANK1)+0),(ocm_bank_base(BANK1)+(sram_dma_size*64)), pattern_rand, OCM, sram_bus_width, NUMONYX, 0xdeadbeef) ;

  //setup DMA write
  DMA_setup(BANK1, sram_dma_w_srcadd, sram_dma_w_desadd, DMA_WRITE, sram_cmd_id, sram_dma_size);
  // datnguyen print("\n\rDMA WRITE setup \n\r");
  
  //Wait for DMA Done
  wait_dma_completion();
  // datnguyen print("\n\rDMA Write Done\n\r");

  //Pop completion
  pop_completion();
  // datnguyen print("\n\rPop Completion\n\r");

  
  //***********************************
  //
  // DMA read from SRAM, to OCM Comparison
  //
  //***********************************
  
  wait_dma_valid();
  // datnguyen print("Wait for dma_cmd_valid.\n\r");

  //setup DMA read
  //DMA_setup(BANK1, sramdma_addr, ((OCM_BASE_COMPARE & 0x00ffffff) + OCM_BASE_SOC) , DMA_READ, sram_cmd_id, sram_dma_size);
  DMA_setup(BANK1, sram_dma_r_srcadd, sram_dma_r_desadd, DMA_READ, sram_cmd_id, sram_dma_size);
  // datnguyen print("\n\rDMA READ setup\n\r");
 
  
  //Wait for DMA Done
  wait_dma_completion();
  // datnguyen print("\n\rDMA READ Done\n\r");

  //Pop completion
  pop_completion();  


  //***********************************
  //
  // Data Comparison between OCM BANK BASE and Comparison part
  //
  //***********************************

  //Used DA to read OCM_DMA data 
  gfc_read_pattern (BANK1, (ocm_bank_base(BANK1)+0),(ocm_bank_base(BANK1)+(sram_dma_size*64)),pattern_f,OCM_DMA, sram_bus_width, NUMONYX, 0x00001234) ;

}

