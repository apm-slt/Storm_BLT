/*
 * See global define in gfc_common.h
 */

//#include <stdio.h>
#include "../include/platform.h"
#include "../include/test_util.h"
#include "../include/gfc_common.h"
#include "../include/gfc_nor.h"
#include "../include/gfc_sram.h"
#include "../include/gfc_nand.h"
#include "../include/gfc_interleave.h"
#include "../include/gfc_dma.h"
#include "../include/gfc_sram_dma.h"

//Tinh-SLT:
#define read read_gfc
#define write write_gfc
#define write16 write16_gfc
#define write8 write8_gfc
#define read read_gfc
#define read8 read8_gfc
#define read16 read16_gfc

void device_setup (int bank_id, int bank_valid, int bank_type, int bank_usage , int bus_width) {
  int read_data;
  int write_data;

  read_data = read(0x17012000 + (bank_id<<12));
  write_data = (read_data & 0xffffff00) | (bank_valid | bank_type <<1 | bank_usage <<4 | bus_width<<6);
  write(0x17012000 + (bank_id<<12), write_data);
}
//  spansion_nor_test_default0(BANK4, NOR, BUS_WIDTH_16, SPANSION, 0x80, 0xc0); //pass nov 09 2012
void device_setup_w_add (int bank_id, int bank_valid, int bank_type, int bank_usage , int bus_width, int device_startadd_bit29to16, int device_endadd_bit29to16) {
  int read_data;
  int write_data;

  read_data = read(0x17012000 + (bank_id<<12));
  write_data = (read_data & 0xffffff00) | (bank_valid | bank_type <<1 | bank_usage <<4 | bus_width<<6);
  write(0x17012000 + (bank_id<<12), write_data);
  write(0x17012008 + (bank_id<<12), device_startadd_bit29to16);
  write(0x17012010 + (bank_id<<12), device_endadd_bit29to16);
  read_data = read(0x17012000 + (bank_id<<12));
  printf("\n---  bank_id = 0x%08x, read_data new = 0x%08x, write_data = 0x%08x ---\n\r", bank_id, read_data , write_data);
}
void config_bank_usage(int bank_num, int bank_usage) {
  int rd_data;
  //print("Changing Bank Usage:");putnum(bank_usage);print("\n\r");
  rd_data = read(0x17012000 + bank_num*0x1000);
  write((0x17012000 + bank_num*0x1000),(rd_data&0xffffffcf)|(bank_usage<<4));
} 

unsigned int get_device_startadd32bit (int bank_id) {
  unsigned int read_data;
  unsigned int device_startadd32bit;

  read_data = read(0x17012008 + (bank_id<<12));
  device_startadd32bit = read_data << 16;
//  printf("\n--- Start Address in GFC  = 0x%08x ---\r\n", device_startadd32bit);
  return(device_startadd32bit);

}

unsigned int get_device_baseadd32bit (int bank_id) {
  unsigned int read_data;
  unsigned int device_baseadd32bit;

  read_data = read(0x17012018 + (bank_id<<12));
  device_baseadd32bit = read_data;
  printf("\n\r=== Get Device Base Addr[31:0]= 0x%08x \n\r", device_baseadd32bit);
  return(device_baseadd32bit);

}

// This method is used to SRAM device as 8bit device 
void Configure_SRAM_NOR_8bit_dev(int bank_id){
  int read_data;
  int write_data;

  read_data = read(0x17012000 + (bank_id<<12));
  write_data = (read_data & 0xffffff3f) | 0x00000000;
  write (0x17012000 + (bank_id<<12), write_data);
  read_data = read(0x17012000 + (bank_id<<12));
  printf("\n gfc_ctrl0 = 0x%08x \n\r", read_data);
}

// Below task is used to configure NOR/SRAM controller parameters which includes BEM also which doesn't included in 
// existing nor_sram_setup method.
void nor_sram_timing_param_change(int bank_id, int burst_en, int mux_en, int twt, int fwt, int bwt, int csn, int oen, int wbn, int wbf, int th, int aln, int alh, int bem){
  int read_data;
  int write_data;

  printf("\n=== Setting NOR_SRAM timing valid ot 0x0 \n\r");
  // 0th bit is NAND valid = 1'b1
  // 1st bit is NOR/SRAM valid = 1'b0
  write_data = 0x1;
  write (0x17012004 + (bank_id<<12), write_data);


  printf("\n=== NOR/SRAM Setup \n\r");
  read_data = read(0x17012100 + (bank_id<<12));
  write_data = (read_data & 0xfffffbff) | (mux_en<<10);
  write (0x17012100 + (bank_id<<12), write_data);

  read_data = read(0x17012104 + (bank_id<<12));
  write_data = (read_data & 0x60080c00) | (twt | fwt<<12 | bwt<<20 | alh<<25 |burst_en<<31);
  write (0x17012104 + (bank_id<<12), write_data);
  read_data = read(0x17012108 + (bank_id<<12));
  write_data = (read_data & 0xfe00000) | (csn | oen<<4 | wbn<<8 | wbf<<12 | th<<16 | bem<<26 | aln<<28);
  write (0x17012108 + (bank_id<<12), write_data);

  printf("\n=== Setting NOR_SRAM timing valid ot 0x1 \n\r");
  // 0th bit is NAND valid = 1'b1
  // 1st bit is NOR/SRAM valid = 1'b0
  write_data = 0x3;
  write (0x17012004 + (bank_id<<12), write_data);

  // Print configure value for confirmation
  //print_SRAM_NOR_ctrl_regs(bank_id);
}

// This method is used to print SRAM/NOR control registers
void print_SRAM_NOR_ctrl_regs(int bank_id) {
  int read_data;

  printf("\n============================= \n\r"); printf("\n\r");
  printf("\n=== NOR/SRAM Setup for Bank = \n\r", bank_id);
  printf("\n============================= \n\r"); printf("\n\r");
  read_data = read(0x17012100 + (bank_id<<12)); printf("\n\r");
  printf("\n sram_nor_ctrl0 =  \n\r",read_data);    printf("\n\r");
  read_data = read(0x17012104 + (bank_id<<12)); printf("\n\r");
  printf("\n sram_nor_ctrl1 =  \n\r", read_data); printf("\n\r");
  read_data = read(0x17012108 + (bank_id<<12)); printf("\n\r");
  printf("\n sram_nor_ctrl2 =  \n\r", read_data); printf("\n\r");
  printf("\n============================= \n\r"); printf("\n\r");
}

// This method is used to enable/disable SRAM/NOR burst mode
void sram_BME_enable_disabled(int bank_id, int burst_en) {
  int read_data;
	int write_data;

  read_data = read(0x17012104 + (bank_id<<12));
  write_data = (read_data & 0xfffffffe) | (burst_en<<31);
  write (0x17012104 + (bank_id<<12), write_data);
  //print_SRAM_NOR_ctrl_regs(bank_id);
}

// This method is used to enable/disable SRAM/NOR BEM mode
void sram_BEM_enable_disabled(int bank_id, int bem) {
  int read_data;
	int write_data;

  read_data = read(0x17012108 + (bank_id<<12));
  write_data = (read_data & 0xffffffdf) | (bem<<26);
  write (0x17012108 + (bank_id<<12), write_data);
	//print_SRAM_NOR_ctrl_regs(bank_id);
}

void gfc_write_pattern(int bank_id,void *test_startadd, void *test_endadd, int testpattern, int device_type, int bus_width, int vendor, int user_pattern) {
   unsigned int i;
   unsigned int tmp;
   unsigned int incr_size;
   unsigned int burst_en;

   //test preparation
   tmp = test_endadd-test_startadd;


   //address incr_size based on device bus width
   if (bus_width == BUS_WIDTH_8) {       incr_size = 1; }
   else if (bus_width == BUS_WIDTH_16) { incr_size = 2; }
   else {                                incr_size = 4; }

   /*
   // nor-sram burst mode
   burst_en =  read(0x17012104 + (bank_id<<12));
   if(burst_en&0x80000000 == 0x80000000 && device_type != NAND)
	 incr_size = 4;
   */

//   printf("incr_size=", incr_size);
   //test data pattern selection
   if(testpattern == pattern_rand){
     for (i=0; i<tmp; i=i+incr_size) {
       if(device_type==NOR) {
    	   if(vendor == NUMONYX){        numonyx_write(bank_id,test_startadd+i,rand(),bus_width);  }
    	   else if (vendor == SPANSION){ spansion_write(bank_id,test_startadd+i,rand(),bus_width); }
       }
       else if (device_type==SRAM){
    	   sram_write(bank_id,test_startadd+i,rand(),bus_width);
       }
       else if (device_type==NAND) {
    	   nand_write(bank_id,test_startadd+i,rand(),bus_width);
       }
       else if (device_type==OCM_DMA) {
    	   ocm_dma_write(bank_id,test_startadd+i,rand(),bus_width);
       }
       else if ((device_type==OCM) | (device_type==SRAM_DMA)) {
    	 if (bus_width == BUS_WIDTH_32){      write  (test_startadd+i,rand()); }
         else if (bus_width == BUS_WIDTH_16){ write16(test_startadd+i,rand()); }
         else                               { write8 (test_startadd+i,rand()); }
       }
     }
   }
//   else if(testpattern == pattern_0){
//     for (i=0; i<tmp; i=i+incr_size) {
////         printf("i=0x%08x ",i);
//       if(device_type==NOR) {
//         if(vendor == NUMONYX){        numonyx_write(bank_id,test_startadd+i,0x0,bus_width);  }
//         else if (vendor == SPANSION){ spansion_write(bank_id,test_startadd+i,0x0,bus_width); }
//       }
//       else if (device_type==SRAM){
//    	 sram_write(bank_id,test_startadd+i,0x0,bus_width);
//       }
//       else if (device_type==NAND){
//    	 nand_write(bank_id,test_startadd+i,0x0,bus_width);
//       }
//       else if (device_type==OCM_DMA) {
//         ocm_dma_write(bank_id,test_startadd+i,0x0,bus_width);
//       }
//       else if ((device_type==OCM) | (device_type==SRAM_DMA)) {
//         if (bus_width == BUS_WIDTH_32){      write  (test_startadd+i,0x0); }
//         else if (bus_width == BUS_WIDTH_16){ write16(test_startadd+i,0x0); }
//         else                               { write8 (test_startadd+i,0x0); }
//       }
//     }
//   }
   else if(testpattern == pattern_f){
     for (i=0; i<tmp; i=i+incr_size) {
       if(device_type==NOR) {
         if(vendor == NUMONYX){        numonyx_write(bank_id,test_startadd+i,0xffffffff,bus_width); }
         else if (vendor == SPANSION){ spansion_write(bank_id,test_startadd+i,0xffffffff,bus_width); }
       }
       else if (device_type==SRAM){
    	 sram_write(bank_id,test_startadd+i,0xffffffff,bus_width);
       }
       else if (device_type==NAND){
    	 nand_write(bank_id,test_startadd+i,0xffffffff,bus_width);
       }
       else if (device_type==OCM_DMA) {
         ocm_dma_write(bank_id,test_startadd+i,0xffffffff,bus_width);
       }
       else if ((device_type==OCM) | (device_type==SRAM_DMA)) {
         if (bus_width == BUS_WIDTH_32){      write  (test_startadd+i,0xffffffff); }
         else if (bus_width == BUS_WIDTH_16){ write16(test_startadd+i,0xffff); }
         else                               { write8 (test_startadd+i,0xff); }
       }
     }
   }
   else if(testpattern == pattern_1234){
     for (i=0; i<tmp; i=i+incr_size) {
       if(device_type==NOR) {
         if(vendor == NUMONYX){        numonyx_write(bank_id,test_startadd+i,pattern_1234,bus_width); }
         else if (vendor == SPANSION){ spansion_write(bank_id,test_startadd+i,pattern_1234,bus_width); }
       }
       else if (device_type==SRAM){
    	 sram_write(bank_id,test_startadd+i,pattern_1234,bus_width);
       }
       else if (device_type==NAND){
    	 nand_write(bank_id,test_startadd+i,pattern_1234,bus_width);
       }
       else if (device_type==OCM_DMA) {
         ocm_dma_write(bank_id,test_startadd+i,pattern_1234,bus_width);
       }
       else if ((device_type==OCM) | (device_type==SRAM_DMA)) {
         if (bus_width == BUS_WIDTH_32){      write  (test_startadd+i,pattern_1234); }
         else if (bus_width == BUS_WIDTH_16)
         {
        	 sram_write(bank_id,test_startadd+i,pattern_1234,bus_width);
         }
         else                               { write8 (test_startadd+i,pattern_1234); }
       }
     }
   }
//   else if(testpattern == pattern_5){
//     for (i=0; i<tmp; i=i+incr_size) {
////         printf("i=0x%08x ",i);
//       if(device_type==NOR) {
//         if(vendor == NUMONYX){        numonyx_write(bank_id,test_startadd+i,0x55555555,bus_width); }
//         else if (vendor == SPANSION){ spansion_write(bank_id,test_startadd+i,0x55555555,bus_width); }
//       }
//       else if (device_type==SRAM){
//    	 sram_write(bank_id,test_startadd+i,0x55555555,bus_width);
//       }
//       else if (device_type==NAND){
//    	 nand_write(bank_id,test_startadd+i,0x55555555,bus_width);
//       }
//       else if (device_type==OCM_DMA) {
//         ocm_dma_write(bank_id,test_startadd+i,0x55555555,bus_width);
//       }
//       else if ((device_type==OCM) | (device_type==SRAM_DMA)) {
//         if (bus_width == BUS_WIDTH_32){      write  (test_startadd+i,0x55555555); }
//         else if (bus_width == BUS_WIDTH_16){ write16(test_startadd+i,0x5555); }
//         else                               { write8 (test_startadd+i,0x55); }
//       }
//     }
//   }

   else if(testpattern == pattern_a){
     for (i=0; i<tmp; i=i+incr_size) {
//         printf("i=0x%08x ",i);
       if(device_type==NOR) {
         if(vendor == NUMONYX){        numonyx_write(bank_id,test_startadd+i,0xaaaaaaaa,bus_width); }
         else if (vendor == SPANSION){ spansion_write(bank_id,test_startadd+i,0xaaaaaaaa,bus_width); }
       }
       else if (device_type==SRAM){
    	 sram_write(bank_id,test_startadd+i,0xaaaaaaaa,bus_width);
       }
       else if (device_type==NAND){
    	 nand_write(bank_id,test_startadd+i,0xaaaaaaaa,bus_width);
       }
       else if (device_type==OCM_DMA) {
         ocm_dma_write(bank_id,test_startadd+i,0xaaaaaaaa,bus_width);
       }
       else if ((device_type==OCM) | (device_type==SRAM_DMA)) {
         if (bus_width == BUS_WIDTH_32){      write  (test_startadd+i,0xaaaaaaaa); }
         else if (bus_width == BUS_WIDTH_16){ write16(test_startadd+i,0xaaaa); }
         else                               { write8 (test_startadd+i,0xaa); }
       }
     }
   }
//   else if(testpattern == pattern_walking1){
//     for (i=0; i<tmp; i=i+incr_size) {
////         printf("i=0x%08x ",i);
//       if(device_type==NOR) {
//         if(vendor == NUMONYX){        numonyx_write(bank_id,test_startadd+i,1<<((i/incr_size)%16),bus_width); }
//         else if (vendor == SPANSION){ spansion_write(bank_id,test_startadd+i,1<<((i/incr_size)%16),bus_width); }
//       }
//       else if (device_type==SRAM){
//    	 sram_write(bank_id,test_startadd+i,1<<((i/incr_size)%16),bus_width);
//       }
//       else if (device_type==NAND){
//    	 nand_write(bank_id,test_startadd+i,1<<((i/incr_size)%16),bus_width);
//       }
//       else if (device_type==OCM_DMA) {
//         ocm_dma_write(bank_id,test_startadd+i,1<<((i/incr_size)%16),bus_width);
//       }
//       else if ((device_type==OCM) | (device_type==SRAM_DMA)) {
//         if (bus_width == BUS_WIDTH_32){      write  (test_startadd+i,1<<((i/incr_size)%16)); }
//         else if (bus_width == BUS_WIDTH_16){ write16(test_startadd+i,1<<((i/incr_size)%16)); }
//         else                               { write8 (test_startadd+i,1<<((i/incr_size)%16)); }
//       }
//     }
//   }

//   else if(testpattern == pattern_walking0){
//     for (i=0; i<tmp; i=i+incr_size) {
//         //printf("i=0x%08x ",i);
//       if(device_type==NOR) {
//         if(vendor == NUMONYX){        numonyx_write(bank_id,test_startadd+i,(~(1<<((i/incr_size)%16))),bus_width); }
//         else if (vendor == SPANSION){ spansion_write(bank_id,test_startadd+i,(~(1<<((i/incr_size)%16))),bus_width); }
//       }
//       else if (device_type==SRAM){
//    	 sram_write(bank_id,test_startadd+i,~(1<<((i/incr_size)%16)),bus_width);
//       }
//       else if (device_type==NAND){
//    	 nand_write(bank_id,test_startadd+i,~(1<<((i/incr_size)%16)),bus_width);
//       }
//       else if (device_type==OCM_DMA) {
//         ocm_dma_write(bank_id,test_startadd+i,~(1<<((i/incr_size)%16)),bus_width);
//       }
//       else if ((device_type==OCM) | (device_type==SRAM_DMA)) {
//         if (bus_width == BUS_WIDTH_32){      write  (test_startadd+i,~(1<<((i/incr_size)%16))); }
//         else if (bus_width == BUS_WIDTH_16){ write16(test_startadd+i,~(1<<((i/incr_size)%16))); }
//         else                               { write8 (test_startadd+i,~(1<<((i/incr_size)%16))); }
//       }
//     }
//   }
//   else if(testpattern == pattern_incremental){
//     for (i=0; i<tmp; i=i+incr_size) {
////         printf("i=0x%08x ",i);
//       if(device_type==NOR) {
//         if(vendor == NUMONYX){        numonyx_write(bank_id,test_startadd+i,i,bus_width); }
//         else if (vendor == SPANSION){ spansion_write(bank_id,test_startadd+i,i,bus_width); }
//       }
//       else if (device_type==SRAM){
//    	 sram_write(bank_id,test_startadd+i,i,bus_width);
//       }
//       else if (device_type==NAND){
//    	 nand_write(bank_id,test_startadd+i,i,bus_width);
//       }
//       else if (device_type==OCM_DMA) {
//         ocm_dma_write(bank_id,test_startadd+i,test_startadd+i,bus_width);
//       }
//       else if ((device_type==OCM) | (device_type==SRAM_DMA)) {
//         if (bus_width == BUS_WIDTH_32){      write  (test_startadd+i,i); }
//         else if (bus_width == BUS_WIDTH_16){ write16(test_startadd+i,i); }
//         else                               { write8 (test_startadd+i,i); }
//       }
//     }
//   }
//
//   else if(testpattern == pattern_userdefine){
//     for (i=0; i<tmp; i=i+incr_size) {
//         //printf("i=0x%08x ",i);
//       if(device_type==NOR) {
//         if(vendor == NUMONYX){        numonyx_write(bank_id,test_startadd+i,user_pattern,bus_width); }
//         else if (vendor == SPANSION){ spansion_write(bank_id,test_startadd+i,user_pattern,bus_width); }
//       }
//       else if (device_type==SRAM){
//    	   sram_write(bank_id,test_startadd+i,user_pattern,bus_width);
//       }
//       else if (device_type==NAND){
//    	   nand_write(bank_id,test_startadd+i,user_pattern,bus_width);
//       }
//       else if (device_type==OCM_DMA) {
//         ocm_dma_write(bank_id,test_startadd+i,user_pattern,bus_width);
//       }
//       else if ((device_type==OCM) | (device_type==SRAM_DMA)) {
//         if (bus_width == BUS_WIDTH_32){      write  (test_startadd+i,user_pattern); }
//         else if (bus_width == BUS_WIDTH_16){ write16(test_startadd+i,user_pattern); }
//         else                               { write8 (test_startadd+i,user_pattern); }
//       }
//     }
//   }
   else if(testpattern == pattern_5678){
     for (i=0; i<tmp; i=i+incr_size) {
//         printf("i=0x%08x ",i);
       if(device_type==NOR) {
         if(vendor == NUMONYX){        numonyx_write(bank_id,test_startadd+i,0x55555555,bus_width); }
         else if (vendor == SPANSION){ spansion_write(bank_id,test_startadd+i,0x55555555,bus_width); }
       }
       else if (device_type==SRAM){
    	 sram_write(bank_id,test_startadd+i,pattern_5678,bus_width);
       }
       else if (device_type==NAND){
    	 nand_write(bank_id,test_startadd+i,pattern_5678,bus_width);
       }
       else if (device_type==OCM_DMA) {
         ocm_dma_write(bank_id,test_startadd+i,pattern_5678,bus_width);
       }
       else if ((device_type==OCM) | (device_type==SRAM_DMA)) {
         if (bus_width == BUS_WIDTH_32){      write  (test_startadd+i,0x55555555); }
         else if (bus_width == BUS_WIDTH_16)
         {
        	 //        	 write16(test_startadd+i,0x5555);
        	 printf("\n ---- bank_id = 0x%08x, test_startadd = 0x%08x, bus_width =  0x%08x ---- \r\n", bank_id, test_startadd,bus_width );
        	 sram_write(bank_id,test_startadd+i,pattern_5678,bus_width);
         }
         else                               { write8 (test_startadd+i,0x55); }
       }
     }
   }

//    return 0;
}


unsigned int gfc_read_pattern(int bank_id,void *test_startadd, void *test_endadd, int testpattern,  int device_type, int bus_width, int vendor, int user_pattern) {
   unsigned int i;
   unsigned int tmp;
   unsigned int incr_size;
   int bstatus = 1;

   //test preparation
   tmp = test_endadd-test_startadd;

   //address incr_size based on device bus width
   if (bus_width == BUS_WIDTH_8) {       incr_size = 1; }
   else if (bus_width == BUS_WIDTH_16) { incr_size = 2; }
   else {                                incr_size = 4; }

//   printf("\n====================  Reading SRAM ====================  \r\n");

   for (i=0; i<tmp; i=i+incr_size){
     if(device_type==NOR) {
         if(vendor == NUMONYX){
            printf("\n========== Put NUMONYX NOR in Read mode ========== \r\n");
            write(test_startadd, 0xff);
            numonyx_read(bank_id,test_startadd+i,bus_width);

         }
         else if (vendor == SPANSION){
//            printf("\n========== Put SPANSION NOR in Read mode==========  \r\n");
            if (bus_width == BUS_WIDTH_8){      write8(test_startadd, 0xf0);}
            else if (bus_width == BUS_WIDTH_16){write16(test_startadd, 0xf0);}
//            printf("\n;=;=;=; bank_id = 0x%08x,test_startadd+i = 0x%08x,bus_width = 0x%08x ;=;;=;=;=\r\n", bank_id, test_startadd+i, bus_width);
//            printf("\n----------------- begin spansion_read bstatus = 0x%08x, user_pattern = 0x%08x ----------- \r\n", bstatus, user_pattern);
            bstatus = spansion_read(bank_id,test_startadd+i,bus_width,user_pattern);
//            printf("\n----------------- end spansion_read bstatus = 0x%08x, user_pattern = 0x%08x ----------- \r\n", bstatus, user_pattern);

         }
     }
     else if ((device_type== SRAM)|(device_type== SRAM_DMA)){
    	 bstatus = sram_read(bank_id,test_startadd+i, testpattern, bus_width);
     }
     else if (device_type==NAND){
    	 nand_read(bank_id,test_startadd+i,bus_width);
     }
     else if (device_type == OCM_DMA) {
       ocm_dma_read(bank_id, test_startadd+i, bus_width);

     }
     else if (device_type == OCM) {
         if (bus_width == BUS_WIDTH_32){      read  (test_startadd+i); }
         else if (bus_width == BUS_WIDTH_16){ read16(test_startadd+i); }
         else                               { read8 (test_startadd+i); }

     }
   }
//   printf("\n----------------- End Reading SRAM, bstatus = 0x%08x ----------- \r\n", bstatus);

   return bstatus;
}
void ocm_dma_write(int bank_id, void *address, int data, int bus_width){
    int *add_32bit;
    int data_32bit;      //OCM Bank Base data
    int *OCMadd_32bit;

    short *add_16bit;
    short data_16bit;    //OCM Comparison data
    short *OCMadd_16bit;

    char *add_8bit;
    char data_8bit;
    char *OCMadd_8bit;

    unsigned int add_temp = address;
    unsigned int temp ; //= (add_temp - ocm_bank_base(bank_id));

    unsigned int outOfOCM_bound; // = over_ocm_boundry(bank_id, temp);
//    temp = OCM_BASE_COMPARE + (temp&0x00ffffff);

    //  OCMadd_32bit = temp;
    //  OCMadd_16bit = temp;
    //  OCMadd_8bit  = temp;

      OCMadd_32bit = address;
      OCMadd_16bit = address;
      OCMadd_8bit  = address;

    if (outOfOCM_bound == 1) {
        printf("\n===== Warning: SRAM WRITE, No data write to OCM, out of OCM bounday\n\r");
      if (bus_width == BUS_WIDTH_32){
        add_32bit = address;
        data_32bit = data;
        write (add_32bit, data_32bit);
      }
      else if (bus_width == BUS_WIDTH_16){
        add_16bit = address;
        data_16bit = data;
        write16 (add_16bit, data_16bit);
      }
      else {
        add_8bit = address;
        data_8bit = data;
        write8 (add_8bit, data_8bit);
      }

    }
    else {

      if (bus_width == BUS_WIDTH_32){
        add_32bit = address;
        data_32bit = data;
        write (add_32bit, data_32bit);
        write (OCMadd_32bit, data_32bit);
      }
      else if (bus_width == BUS_WIDTH_16){
        add_16bit = address;
        data_16bit = data;
        write16 (add_16bit, data_16bit);
        write16 (OCMadd_16bit, data_16bit);
      }
      else {
        add_8bit = address;
        data_8bit = data;
        write8 (add_8bit, data_8bit);
        write8 (OCMadd_8bit, data_8bit);
      }
    }
}


void ocm_dma_read(int bank_id, void *address, int bus_width){
  int *add_32bit;
  int data_32bit;        //OCM BANK BASE data
  int *OCMadd_32bit;
  int OCMdata_32bit;     //OCM Comparison data

  short *add_16bit;
  short data_16bit;
  short *OCMadd_16bit;
  short OCMdata_16bit;

  char *add_8bit;
  char data_8bit;
  char *OCMadd_8bit;
  char OCMdata_8bit;

  unsigned int add_temp = address;

  unsigned int temp; // = (add_temp - ocm_bank_base(bank_id));
  unsigned int outOfOCM_bound ; //= over_ocm_boundry(bank_id, temp);
//  temp = OCM_BASE_COMPARE + (temp&0x00ffffff);

//  OCMadd_32bit = temp;
//  OCMadd_16bit = temp;
//  OCMadd_8bit  = temp;

  OCMadd_32bit = address;
  OCMadd_16bit = address;
  OCMadd_8bit  = address;

  if (outOfOCM_bound == 1) {
    printf("\n===== Warning: OCM READ, No data read from OCM, out of OCM bounday\n\r");
  }
  else {

    if  (bus_width == BUS_WIDTH_32) {
      add_32bit  = address;
      data_32bit = read (add_32bit);
      OCMdata_32bit = read( OCMadd_32bit);

      if(OCMdata_32bit != data_32bit){
        printf("ERROR: OCM DMA 32bit Read Data Mismatch: Expected = %0x,  Actual = %0x \n\r", OCMdata_32bit, data_32bit);
        // datnguyen              error(0);
      }

    }
    else if  (bus_width == BUS_WIDTH_16) {
      add_16bit  = address;
      data_16bit = read16 (add_16bit);
      OCMdata_16bit = read16( OCMadd_16bit);

      if(OCMdata_16bit != data_16bit){
        printf("ERROR: OCM DMA 16bit Read Data Mismatch: Expected = %0x,  Actual = %0x \n\r", OCMdata_16bit, data_16bit);
// datnguyen        error(0);
      }

    }
    else {
      add_8bit  = address;
      data_8bit = read8 (add_8bit);
      OCMdata_8bit = read8( OCMadd_8bit);

      if(OCMdata_8bit != data_8bit){
        printf("ERROR: OCM DMA 8bit Read Data Mismatch: Expected = %0x,  Actual = %0x \n\r", OCMdata_8bit, data_8bit);
        // datnguyen                error(0);
      }
    }
  }
}

void da_base_test(void *test_startadd, void *test_endadd, int device_type, int bus_width, int testpattern, int vendor) {
   unsigned int i;
   unsigned int tmp;
   unsigned int test_startblock;
   unsigned int test_endblock;
   unsigned int device_startadd;
   unsigned int incr_size;

   printf("\n===== nor_tes_basic_16:, start add= 0x%08x ,  end_add = 0x%08x,  pattern = 0x%08x \n\r", test_startadd, test_endadd, testpattern);

   device_setup (BANK0, 1, device_type, READ_WRITE, bus_width);
   nor_sram_setup (BANK0, BURST_DIS, MUX_DIS, N_TWT, N_FWT, N_BWT, N_CSN, N_OEN, N_WBN, N_WBF, N_TH, N_ALN, N_ALH);

   //GFC CSR Read: IP Rev
   read(0x17010004);

   //shif address by 1
   write(0x17010074, 0x60008);

   //FPGA_MISC_0
   write(0x17040000, 0x00000010); //FPGA_MISC_0, set to FPGA flash   / chipsope bus 2 selected

   //Get Device Start Add
   device_startadd = (get_device_startadd32bit(BANK0)+GFC_BASE);

   //Device ID: device address:0
   numonyx_clearstatus(test_startadd);
   numonyx_read_device_id(device_startadd);

   //block erase & unlock
   //block size: 64Kword(1 word = 16bit)
   test_startblock = numonyx_get_block_num (BANK0, test_startadd);
   test_endblock = numonyx_get_block_num (BANK0, test_endadd);

   for (i=test_startblock ; i<test_endblock; i++) {
     printf("device_startadd", device_startadd);
     printf("i=", i);
     tmp = device_startadd+i*0x10000;
     numonyx_BlockErase(tmp);
     numonyx_unlock(tmp);
   }
   gfc_write_pattern(BANK0,test_startadd, test_endadd, testpattern, device_type, bus_width, vendor, 0x00) ;
   gfc_read_pattern(BANK0,test_startadd, test_endadd, testpattern, device_type, bus_width, vendor, 0x00001234) ;

// datnguyen   return 0;
}
unsigned int gfc_write_read(int bank_id, void *wr_test_startadd, void *wr_test_endadd, int block_erase_en, void *rd_test_startadd, void *rd_test_endadd, int device_type, int bus_width, int testpattern, int vendor, int user_pattern) {
	   unsigned int i;
	   unsigned int tmp;
	   unsigned int test_startblock;
	   unsigned int test_endblock;
	   unsigned int device_startadd;
	   unsigned int incr_size;
	   int bstatus = 1;
	   char c;
	   device_startadd = (get_device_startadd32bit(bank_id)+GFC_NOR_BASE);
	    printf("device_startadd0 = 0x%08x \r\n",device_startadd);
	   if (device_type == NOR) {

	     if(vendor == NUMONYX){
	       //Device ID: device address:0
	       numonyx_clearstatus(wr_test_startadd);
	       numonyx_unlock(device_startadd);
	       numonyx_read_device_id(device_startadd);

	       //block erase & unlock
	       //block size: 64Kword(1 word = 16bit)
	       test_startblock = numonyx_get_block_num (bank_id, wr_test_startadd);
	       test_endblock = numonyx_get_block_num (bank_id, wr_test_endadd);

	       for (i=0 ; i<=(test_endblock-test_startblock); i++) {

	         printf("\nNumonyx NOR test_startblock = 0x%08x\n\r ", test_startblock);
	         printf("\nNumonyx NOR test_endblock = 0x%08x\n\r", test_endblock);

	         tmp = device_startadd+((test_startblock+i)*0x10000);
	         numonyx_unlock(tmp);
	         numonyx_BlockErase(tmp);

	       }

	     }
	     else if (vendor == SPANSION){
	       printf("\n==================== spansion_read_device_id =====================\r\n");
	  	   spansion_reset(device_startadd,bus_width);
	       //bstatus = spansion_read_device_id(device_startadd, bus_width);

	       //sector erase & unlock
	       //sector size: 32KByte(sector0-3 and 517) or 128 Byte(rest sectors)
	       test_startblock = spansion_get_sector_num (bank_id, wr_test_startadd);
	       test_endblock   = spansion_get_sector_num (bank_id, wr_test_endadd);

	       for (i=0 ; i<=(test_endblock-test_startblock); i++) {

	         if((test_startblock+i)<4)           {tmp = device_startadd+((test_startblock+i)*0x8000);         }
	         else if ((test_startblock+i) < 517) {tmp = device_startadd+0x10000+((test_startblock+i-4)*0x20000);}
	         else if ((test_startblock+i) ==517) {tmp = 0x1FFC000;}
	         spansion_sector_erase(bank_id, tmp, bus_width);
	         spansion_sector_erase_status(bank_id, tmp, bus_width);

	       }
	     }
	   }

	    printf("\n======================= Write data to NOR ========================\r\n");
		arch_timer_msdelay(1000);
		gfc_write_pattern(bank_id, wr_test_startadd, wr_test_endadd, testpattern, device_type, bus_width, vendor, user_pattern) ;
		arch_timer_msdelay(1000);
	    printf("\n======================= Read data from NOR ========================\r\n");
	    bstatus = gfc_read_pattern(bank_id, rd_test_startadd, rd_test_endadd, testpattern, device_type, bus_width, vendor, user_pattern) ;
		arch_timer_msdelay(1000);

   return bstatus;

}


void gfc_write_read_test(int bank_id, int test_type, void *wr_test_startadd, void *wr_test_endadd, int block_erase_en, void *rd_test_startadd, void *rd_test_endadd, int device_type, int bus_width, int testpattern, int vendor, int user_pattern) {
   unsigned int i;
   unsigned int tmp;
   unsigned int test_startblock;
   unsigned int test_endblock;
   unsigned int device_startadd;
   unsigned int incr_size;

   //Get Device Start Add
   device_startadd = (get_device_startadd32bit(bank_id)+GFC_BASE);

   if (device_type == NOR) {

     if(vendor == NUMONYX){
       //Device ID: device address:0
       numonyx_clearstatus(wr_test_startadd);
       numonyx_unlock(device_startadd);
       numonyx_read_device_id(device_startadd);

       //block erase & unlock
       //block size: 64Kword(1 word = 16bit)
       test_startblock = numonyx_get_block_num (bank_id, wr_test_startadd);
       test_endblock = numonyx_get_block_num (bank_id, wr_test_endadd);

       for (i=0 ; i<=(test_endblock-test_startblock); i++) {

         printf("\nNumonyx NOR test_startblock = 0x%08x \n\r", test_startblock);
         printf("\nNumonyx NOR test_endblock = 0x%08x \n\r", test_endblock);

         tmp = device_startadd+((test_startblock+i)*0x10000);
         numonyx_unlock(tmp);
         numonyx_BlockErase(tmp);

       }

     }
     else if (vendor == SPANSION){
       spansion_read_device_id(device_startadd, bus_width);

       //sector erase & unlock
       //sector size: 32KByte(sector0-3 and 517) or 128 Byte(rest sectors)
       test_startblock = spansion_get_sector_num (bank_id, wr_test_startadd);
       test_endblock   = spansion_get_sector_num (bank_id, wr_test_endadd);

       for (i=0 ; i<=(test_endblock-test_startblock); i++) {

         printf("\nSpansion NOR test_startsector = ", test_startblock);
         printf("\nSpansion NOR test_endsector = ", test_endblock);

         if((test_startblock+i)<4)           {tmp = device_startadd+((test_startblock+i)*0x8000);         }
         else if ((test_startblock+i) < 517) {tmp = device_startadd+0x10000+((test_startblock+i-4)*0x20000);}
         else if ((test_startblock+i) ==517) {tmp = 0x1FFC000;}
         spansion_sector_erase(bank_id, tmp, bus_width);
         spansion_sector_erase_status(bank_id, tmp, bus_width);

       }
     }
   }

   if(test_type==WRITE_TEST) {  gfc_write_pattern(bank_id, wr_test_startadd, wr_test_endadd, testpattern, device_type, bus_width, vendor, user_pattern) ;}
   gfc_read_pattern(bank_id, rd_test_startadd, rd_test_endadd, testpattern, device_type, bus_width, vendor, user_pattern) ;

// datnguyen   return 0;

}


void gfc_status_check() {
  int rdata;
  int i;

  printf("\n========== Check CSR: gfc_fifo_empty0\n\r");
  csr_check(0x170100d4, 0xffffffff, 0xffffffff);

  printf("\n========== Check CSR: gfc_fifo_empty1\n\r");
  csr_check(0x170100d8, 0xffffffff, 0xffffffff);

  printf("\n========== Check CSR: gfc_fifo_full0\n\r");
  csr_check(0x170100dc, 0x0, 0xffffffff);

  printf("\n========== Check CSR: gfc_fifo_full1\n\r");
  csr_check(0x170100e0, 0x0, 0xffffffff);

  printf("\n========== Check CSR: gfc_fifo_overflow0\n\r");
  csr_check(0x170100e4, 0x0, 0xffffffff);

  printf("\n========== Check CSR: gfc_fifo_overflow1\n\r");
  csr_check(0x170100e8, 0x0, 0xffffffff);

  printf("\n========== Check CSR: gfc_fifo_underflow0\n\r");
  csr_check(0x170100ec, 0x0, 0xffffffff);

  printf("\n========== Check CSR: gfc_fifo_underflow1\n\r");
  csr_check(0x170100f0, 0x0, 0xffffffff);

  for(i=0; i<6; i++) {
    printf("\n========== Check CSR: gfc_bank", i);
    csr_check((0x1701223c+(i<<12)), 0x0, 0xffffffff);

    printf("\n========== Check CSR: gfc_bank 0x%08x_nand_uncor_err\n\r", i);
    csr_check((0x17012240+(i<<12)), 0x0, 0xffffffff);
  }

  printf("\n========== Check CSR: gfc_interrupt\n\r");
  rdata = read(0x1701000c);
  csr_check(0x1701000c, 0x0, 0x5C083);

  printf("\n========== Check CSR: gfc_err_info\n\r");
  rdata = read(0x1701014c);
  csr_check(0x1701014c,  0x0, 0x1F0);

  printf("\n========== Check CSR: gfc_nand_pio_ecc_err_col\n\r");
  rdata = read(0x17010090);
  csr_check(0x17010090, 0x0, 0x80000);

}

void csr_check(int *csradd, int expdata, int mask) {
    int rxdata = read(csradd) & mask;

    if (rxdata != expdata) {
      printf("\n========== CSR Status Mistmatch Found - ADDRESS: 0x ,Exp: 0x,Received: 0x \n\r", csradd, expdata, rxdata);
// datnguyen      error(errOption);
    }
    else {
      //print("\n========== Data Check OK. Exp: "); putnum(expdata); print(" Received: "); putnum(rxdata); print("\n\r");
    }
}


int nand_corrupt_single_bit (int bank_id,int row_addr,int col_addr,int bit_pos_min,int bit_pos_max) {
  int read_data;
  int write_data;
  int bus_width;
  int bit_position;

  //Determine bus width
  read_data = read(0x17012000 + (bank_id<<12));
  bus_width = ((read_data & 0xc0) == 0)? 8 : 16;

  // Turn off ecc:
  read_data = read(0x17012200 + (bank_id<<12));
  int ecc_on_off = read_data & 0x00000080;
  write_data = read_data ^ ecc_on_off;
  write (0x17012200 + (bank_id<<12), write_data);

  // Read data from Nand
  nand_pio_rd_setup(bank_id, row_addr, col_addr, 4);
  wait_completion();
  read_data = read(GFC_BASE | NAND_BUFFER_STARTADD);
  printf("read_data at source = \n\r", read_data);
  flush_pio_rd_buffer();

  //check whether data is not all 0
  if(((read_data&0x000000ff == 0x00000000) && (bus_width==8)) || (read_data&0x0000ffff == 0x00000000)){
    printf("Single-bit corruption unsuccessful. Data is all 0");
    return(1);
  } else {
    printf("Single-bit corruption is possible. bus_width = 0x%08x, read_data = 0x%08x\n\r", bus_width, read_data);
  };

  // Corrupt data, and write back
  bit_position = find_random_index_1(read_data, bit_pos_min, bit_pos_max );
  if (bit_position == 0xff) {
    printf("Return: Data is all 0\n\r");
    return(1);
  } else {
    write_data = read_data ^ (1<<bit_position);
    nand_pio_wr_setup(bank_id, row_addr, col_addr, 4, 0xABABABAB);
    write((GFC_BASE | NAND_BUFFER_STARTADD), write_data);
    wait_completion();
    printf("Nand: Corrupted Single bit at Row addr = %0x, Col addr = %0x, Orig Data = %0x, Corrupted Data = %0x \n\r", row_addr, col_addr, read_data, write_data);

    // Turn on ecc:
    read_data = read(0x17012200 + (bank_id<<12));
    write_data = read_data | ecc_on_off;
    write (0x17012200 + (bank_id<<12), write_data);
    return(0);
  };
}


int find_random_index_1(int data, int bit_pos_min,int bit_pos_max){
  int i, j=0;
  int a[16];
  int found = 0;
  printf("bit_pos_min= 0x%08x, tbit_pos_max= 0x%08x \n\r", bit_pos_min, bit_pos_max);

  for(i=bit_pos_min; i<bit_pos_max; i=i+1){
    if((data & (1<<i)) != 0){
      a[j] = i;
      found = 1;
      j= j+1;
    }
  }
  i = ((j-1)==0) ? 0 : rand()%(j-1);
  printf("i =  0x%08x, tbit_pos =  0x%08x\n\r", i, a[i]);
  if (found == 1) {
    return(a[i]);
  } else {
    printf("All bits are zeros.\n\r");
    return(0xff);
  }
}
int corrupt_ecc_area(int bank_id, int ecc_algo, int chunk_num,int ecc_even_bound,int nand_page_size,int row_addr,int bus_width) {
   int col_addr;
   int min_val,max_val;
   int success;
   if(bus_width == 1) {
	  switch(ecc_algo) {
         case 0:if(ecc_even_bound){
	      		  min_val =(nand_page_size/2) +  ((chunk_num-1)*4)/2;
	      	      max_val = min_val +1;
                  col_addr = rand_num(min_val,max_val);
				  if(col_addr%2 == 0)
                    success = nand_corrupt_single_bit (bank_id, row_addr, col_addr,0,15);
				  else
                    success = nand_corrupt_single_bit (bank_id, row_addr, col_addr,0,6);
				}
	      	    else {
				  printf("ecc_even_bound is 0 for hamming\n\r");
	      		  min_val =(nand_page_size/2) + ((chunk_num-1)*3)/2;
	      	      max_val = min_val +1;
                  col_addr = rand_num(min_val,max_val);
                  //print("Calling corrupt function: row = "); putnum(row_addr); print("col=");putnum(col_addr);print("\n\r");
	      		  if(chunk_num%2==1 && col_addr == max_val)
                    success = nand_corrupt_single_bit (bank_id, row_addr, col_addr,0,6);
	      		  else if(chunk_num%2==0 && col_addr == min_val)
                    success = nand_corrupt_single_bit (bank_id, row_addr, col_addr,8,15);
	      		  else if(chunk_num%2==0 && col_addr == max_val)
                    success = nand_corrupt_single_bit (bank_id, row_addr, col_addr,0,13);
	      		  else
                    success = nand_corrupt_single_bit (bank_id, row_addr, col_addr,0,15);
	      	  }
	      	  break;
         case 1:if(ecc_even_bound) {
	      		  min_val =(nand_page_size/2) +  ((chunk_num-1)*8)/2;
	      	      max_val = min_val +3;
	      	      col_addr = rand_num(min_val,max_val);
				  if(col_addr == max_val)
                    success = nand_corrupt_single_bit (bank_id, row_addr, col_addr,0,3);
				  else
                    success = nand_corrupt_single_bit (bank_id, row_addr, col_addr,0,15);
				}
	      	    else {
				  printf("ecc_even_bound is 0 for BCH_4\n\r");
	      		  min_val =(nand_page_size/2) +  ((chunk_num-1)*7)/2;
	      	      max_val = min_val +3;
	      	      col_addr = rand_num(min_val,max_val);
                  //print("Calling corrupt function: row = "); putnum(row_addr); print("col=");putnum(col_addr);print("\n\r");
	      		  if(chunk_num%2==1 && col_addr == max_val)
                    success = nand_corrupt_single_bit (bank_id, row_addr, col_addr,0,3);
	      		  else if(chunk_num%2==0 && col_addr == min_val)
                    success = nand_corrupt_single_bit (bank_id, row_addr, col_addr,8,15);
	      		  else if(chunk_num%2==0 && col_addr == max_val)
                    success = nand_corrupt_single_bit (bank_id, row_addr, col_addr,0,11);
	      		  else
                    success = nand_corrupt_single_bit (bank_id, row_addr, col_addr,0,15);
	      	    }
	      	    break;
         case 2:if(ecc_even_bound) {
	      		  min_val =(nand_page_size/2) +  ((chunk_num-1)*16)/2;
	      	      max_val = min_val + 6;
	      	      col_addr = rand_num(min_val,max_val);
				  if(col_addr == max_val)
                    success = nand_corrupt_single_bit (bank_id, row_addr, col_addr,0,7);
				  else
                    success = nand_corrupt_single_bit (bank_id, row_addr, col_addr,0,15);
				}
	      	    else {
			      printf("ecc_even_bound is 0 for BCH_8\n\r");
	      	      min_val = (nand_page_size/2) + ((chunk_num-1)*13)/2;
	      	      max_val = min_val + 6;
                  col_addr = rand_num(min_val,max_val);
                  //print("Calling corrupt function: row = "); putnum(row_addr); print("col=");putnum(col_addr);print("\n\r");
	      	      if(chunk_num%2==1 && col_addr == max_val)
                    success = nand_corrupt_single_bit (bank_id, row_addr, col_addr,0,7);
	      	      else if(chunk_num%2==0 && col_addr == min_val)
                    success = nand_corrupt_single_bit (bank_id, row_addr, col_addr,8,15);
	      	      else if(chunk_num%2==0 && col_addr == max_val)
                    success = nand_corrupt_single_bit (bank_id, row_addr, col_addr,0,7);
	      	      else
                    success = nand_corrupt_single_bit (bank_id, row_addr, col_addr,0,15);
	      	    }
	      	    break;
	  }
   }
   else { //8-bit case
	  switch(ecc_algo) {
	    case 0: min_val = nand_page_size + ((chunk_num-1)*3);
	      	    max_val = min_val +2;
	      	    col_addr = rand_num(min_val,max_val);
				if(col_addr == max_val)
                  success = nand_corrupt_single_bit (bank_id, row_addr, col_addr,0,5);
				else
                  success = nand_corrupt_single_bit (bank_id, row_addr, col_addr,0,7);
				break;
	    case 1: min_val = nand_page_size + ((chunk_num-1)*7);
	      	    max_val = min_val +6;
	      	    col_addr = rand_num(min_val,max_val);
				if(col_addr == max_val)
                  success = nand_corrupt_single_bit (bank_id, row_addr, col_addr,0,3);
				else
                  success = nand_corrupt_single_bit (bank_id, row_addr, col_addr,0,7);
				break;
	    case 2: min_val = nand_page_size + ((chunk_num-1)*13);
	      	    max_val = min_val +12;
	      	    col_addr = rand_num(min_val,max_val);
                success = nand_corrupt_single_bit (bank_id, row_addr, col_addr,0,7);
	  }

   }
   return(success);
}

void disable_norsram_banks(int bank_id){
  setup_norsram_addrmap(bank_id, 1, 0);
}

void setup_norsram_addrmap(int bank_id, int device_startadd_bit29to16, int device_endadd_bit29to16){
  printf("\n======== start device setup bank_id = 0x%08x ===========\n\r", bank_id);
  write(0x17012008 + (bank_id<<12), device_startadd_bit29to16);
  write(0x17012010 + (bank_id<<12), device_endadd_bit29to16);
}


unsigned int over_ocm_boundry (int bank_id, unsigned int data_offset) {
  int over_OCM_bound;
    if(bank_id == BANK0)      {over_OCM_bound = ((data_offset&0x00ffffff)> OCM_SIZE_BANK0);}
    else if(bank_id == BANK1) {over_OCM_bound = ((data_offset&0x00ffffff)> OCM_SIZE_BANK1);}
    else if(bank_id == BANK2) {over_OCM_bound = ((data_offset&0x00ffffff)> OCM_SIZE_BANK2);}
    else if(bank_id == BANK3) {over_OCM_bound = ((data_offset&0x00ffffff)> OCM_SIZE_BANK3);}
    else if(bank_id == BANK4) {over_OCM_bound = ((data_offset&0x00ffffff)> OCM_SIZE_BANK4);}
    return(over_OCM_bound);
}

int ocm_bank_base( int bank_id) {
  int bank_base;
    if(bank_id == BANK0)      {bank_base = OCM_BASE_BANK0;}
    else if(bank_id == BANK1) {bank_base = OCM_BASE_BANK1;}
    else if(bank_id == BANK2) {bank_base = OCM_BASE_BANK2;}
    else if(bank_id == BANK3) {bank_base = OCM_BASE_BANK3;}
    else if(bank_id == BANK4) {bank_base = OCM_BASE_BANK4;}
    return(bank_base);

}
