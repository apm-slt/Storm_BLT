/*
 */
#ifndef __GFC_NAND_H_
#define __GFC_NAND_H_
unsigned int nand();
unsigned int nand_test();
unsigned int nand_test_default1 (int bank_id, int device_type, int bus_width, int ecc_on_off, int ecc_alg, int bch_t);
void nand_test_interleave (int bank_id, int test_type, int bus_width, int ecc_on_off, int ecc_alg, int bcht, int nand_rowadd, int nand_coladd, int data_byte_size, int user_pattern, int nand_buffer_startadd, int nand_buffer_endadd);
void nand_buffer_addr(int start_addr, int end_addr);
void nand_ecc_setup (int bank_id, int ecc_on_off, int ecc_algo, int bch_t);
void nand_pio_reset(int bank_id);
void nand_pio_erase(int bank_id, int row_addr);
unsigned int get_nand_piobuffer_startadd32bit ();
unsigned int nand_device_id(int bank_id, int bus_width);
void wait_completion();
void nand_pio_wr_setup(int bank_id,int row_addr,int col_addr,int data_size, int data_patern);
void nand_pio_wr_data(int *start_addr, int* data, int data_size_in_bytes);
unsigned int nand_pio_rd_setup(int bank_id,int row_addr2,int col_addr2,int data_size);
unsigned int nand_pio_rd_data(int *start_addr,int data_size_in_bytes);
void nand_write(int bank_id,void *address, int data, int bus_width);
void nand_read(int bank_id,void *address, int bus_width);
void flush_pio_rd_buffer();
void nand_setup (int bank_id, int ecc_on_off, int ecc_alg, int bch_t, int device_size, int block_size, int page_size);
void nand_bank_ctrl0 (int bank_id, int ecc_on_off, int ecc_alg, int force_spare_offset);
void nand_bank_bch (int bank_id, int bch_n, int bch_t, int bch_k);
void nand_dma_ctrl1 (int bank_id, int dma_data_size);
void nand_size_setup (int bank_id, int device_size, int block_size, int page_size);
void nand_timing_para_setup (int bank_id,
                             int t_ccs, int t_rhw, int t_wb, int t_adl,
                             int t_dh_wh, int t_ds_wp, int t_als_cls_cs, int t_alh_clh_ch, 
                             int t_rp, int t_reh, int t_rr, int t_ar_clr_whr_ir) ;
void nand_pio_ecc_test (int bank_id, int bus_width ); 
void pio_ecc_err_data_spare(int bank_id, int bus_width, int num_trans, int data_spare); 
void nand_pio_ecc(int bank_id, int row_addr, int col_addr, int pio_size, int bus_width, int ecc_algo, int num_errors, int err_loc);
void nand_pio_force_status_read(int bank_id); 
#endif
