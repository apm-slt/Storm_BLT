/*
 */
#define READ 0
#define WRITE 1
#define ERASE 2
#define RESET 3

#ifndef __GFC_DMA_H_
#define __GFC_DMA_H_

unsigned int dma_test();

void nand_dma();
void wait_dma_completion();
void wait_dma_valid();
void ocm_write(int addr, int size, int base);
void nand_dma_setup(int ecc_en, int ecc_algo, int spo_en, int spo, int page_size);
void push_cmd(int src_addr, int dst_addr, int cmd_code, int cmd_id, int dma_size);
void config_wp_n(int bank_num, int wpn_en); 
void check_dma_dev_prot_interrupt(int bank_id);
unsigned int nand_dma_multibank_ecc();
#endif
