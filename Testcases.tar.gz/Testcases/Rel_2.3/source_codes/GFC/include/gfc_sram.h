/*
 */
#ifndef __GFC_SRAM_H_
#define __GFC_SRAM_H_

unsigned int sram_test();
void sram_test_default0 (int bank_id, int device_type, int bus_width, int vendor, int device_startadd_bit29to16, int device_endadd_bit29to16);
unsigned int sram_test_basic0 (int bank_id, int device_type, int bus_width, int vendor, int device_startadd_bit29to16, int device_endadd_bit29to16);
void sram_write(int bank_id,void *address, int data, int bus_width);
unsigned int sram_read(int bank_id,void *address, int testpattern, int bus_width);
void sram_write_32(int bank_id,void *address, int data, int bus_width);
unsigned int sram_read_32(int bank_id,void *address, int bus_width);
unsigned int sram_test_default0_32 (int bank_id, int device_type, int bus_width, int vendor, int device_startadd_bit29to16, int device_endadd_bit29to16);
#endif
