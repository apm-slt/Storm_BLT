/*
 */
#ifndef __GFC_NOR_H_
#define __GFC_NOR_H_

unsigned int  nor_test();
void nor_test_default1 (int bank_id, int device_type, int bus_width, int vendor);
void spansion_nor_test_default1 (int bank_id, int device_type, int bus_width, int vendor);
void nor_test_boundary_block_check (int bank_id, int bus_width, int vendor, int device_startadd_bit29to16, int device_endadd_bit29to16);
void nor_test_basic (void *test_startadd, void *test_endadd, int device_type, int bus_width, int testpattern, int vendor);

void nor_numonyx_write_pattern(int bank_id,void *test_startadd, void *test_endadd, int bus_width, int testpattern) ;
void nor_numonyx_read_pattern(int bank_id,void *test_startadd, void *test_endadd, int bus_width, int testpattern);
void nor_sram_setup (int bank_id, int burst_en, int mux_en, int twt, int fwt, int bwt, int csn, int oen, int wbn, int wbf, int th, int aln, int alh);


//numonyx
void numonyx_read_device_id (short *address);
void numonyx_write(int bank_id,void *address, int data, int bus_width);
void numonyx_read(int bank_id,void *address, int bus_width);
void numonyx_BlockErase(short *address);
void numonyx_ReadStatus(short *address);
void numonyx_ClearStatus(short *address);
void numonyx_clearstatus(short *address);
void numonyx_unlock(short *address);
unsigned int numonyx_get_block_num(int bank_id, int test_add);
void numonyx_write16(short *address, short data);
short numonyx_read16(short *address);


//spansion
unsigned int spansion_nor_test_default0 (int bank_id, int device_type, int bus_width, int vendor, int device_startadd_bit29to16, int device_endadd_bit29to16);
unsigned int nor_test_default0 (int bank_id, int device_type, int bus_width, int vendor, int device_startadd_bit29to16, int device_endadd_bit29to16) ;
//unsigned int nor_test_default0 (int bank_id, int device_type, int bus_width, int vendor, int device_startadd_bit29to16, int device_endadd_bit29to16);
void spansion_reset (void *address, int bus_width);
void spansion_unlock (void *address, int bus_width);
void spansion_unlock_prog (void *address, int bus_width);
void spansion_chip_erase(void *address, int bus_width);
unsigned int spansion_get_sector_num(int bank_id, int test_add);
void spansion_sector_erase(int bank_id,void *address, int bus_width);
void spansion_sector_erase_status(int bank_id, void *address, int bus_width);
void spansion_write_operation_status(void *address, int bus_width);
unsigned int spansion_read_device_id (void *address, int bus_width);
void spansion_write(int bank_id,void *address, int data, int bus_width);
unsigned int spansion_read(int bank_id,void *address, int bus_width, int user_pattern);


//general nor
void chipscope_diagbus();
void datacheck_16(short rxdata, short expdata);
void nor_test_basic_16(short *test_startadd, short *test_endadd, int testpattern) ;
#endif
