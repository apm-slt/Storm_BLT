#ifndef GFC_MACROS
#define GFC_MACROS
//#include <linux/types.h>
#include <types.h>

//Tinh-SLT:
//function defined here
#define read read_gfc
#define write write_gfc
#define read32 read32_gfc
#define write32 write32_gfc
#define read8 read8_gfc
#define write8 write8_gfc
#define read16 read16_gfc
#define write16 write16_gfc



typedef unsigned int uint32_t;
static unsigned int	next=1;

int read(unsigned int *addr){
	return *(volatile unsigned int*)addr;
}

void write(unsigned int *addr, int value){
	*(volatile unsigned int*)addr=(int)value;
}

char read8(char *addr){
	return *(volatile char*)addr;
}

void write8(char *addr, char value){
	*(volatile char*)addr=(char)value;
}

short read16(short *addr){
	return *(volatile short*)addr;
}

void write16(short *addr, short value){
	*(volatile short*)addr=(short)value;
}

int read32(unsigned int  *addr){
	return *(volatile int*)addr;
}

void write32(unsigned int *addr, int value){
	*(volatile unsigned int*)addr=(int)value;
}

uint32_t gfc_read32(uint32_t *addr){
	return *(volatile uint32_t*)addr;
}

void gfc_write32(uint32_t *addr, uint32_t value){
	*(volatile uint32_t*)addr=(uint32_t)value;
}
/*
int rand()
{

   next=next* 1103515245+ 12345;
   return((unsigned int)(next/65536)%32768);
}
*/
#endif
