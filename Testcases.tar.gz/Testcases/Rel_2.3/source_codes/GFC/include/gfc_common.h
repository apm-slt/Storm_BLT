/*
 */
#ifndef __GFC_COMMON_H_
#define __GFC_COMMON_H_


#define GFC_DEBUG 0

#define OCM_BASE_BANK0   0x1d000000 // datnguyen 0x9d000000 -> 0x1d000000
#define OCM_BASE_BANK1   0x1d040000 // datnguyen 0x9d040000 -> 0x1d040000
#define OCM_BASE_BANK2   0x1d060000 // datnguyen 0x9d060000 -> 0x1d060000
#define OCM_BASE_BANK3   0x1d080000 // datnguyen 0x9d080000 -> 0x1d080000
#define OCM_BASE_BANK4   0x1d0c0000 // datnguyen 0x9d0c0000 -> 0x1d0c0000
#define OCM_BASE_COMPARE 0x1d0e0000 // datnguyen 0x9d0e0000 -> 0x1d0e0000


#define OCM_SIZE_BANK0   0x40000 //256KB 
#define OCM_SIZE_BANK1   0x20000 //128KB
#define OCM_SIZE_BANK2   0x20000 //128KB
#define OCM_SIZE_BANK3   0x40000 //256KB
#define OCM_SIZE_BANK4   0x20000 //128KB
#define OCM_SIZE_COMPARE 0x20000 //128KB

#define OCM_BASE_SOC  0x1d000000  // datnguyen 0x9d000000 -> 0x1d000000
#define OCM_BASE      0x1d000000
#define GFC_BASE      0x00C00000 //Nand 0x00100000 //Nor 0x00000000 0x17010000 ?
#define GFC_SRAM_BASE     0x00C00000 //Nand 0x00100000 //Nor 0x00000000 0x17010000 ?
#define GFC_NOR_BASE      0x00C10000 //Nand 0x00100000 //Nor 0x00000000 0x17010000 ?
#define GFC_NAND_BASE     0x00C80000 //Nand 0x00100000 //Nor 0x00000000 0x17010000 ?
#define OCM_SIZE      0x00080000 //512kByte //#define OCM_SIZE 0x00100000 //1MByte
#define OCM_DMA_BASE (OCM_BASE_BANK1+OCM_SIZE_BANK1)

#define pattern_rand          0
#define pattern_0             1
#define pattern_f             2
#define pattern_5             3
#define pattern_a             4
#define pattern_walking0      5
#define pattern_walking1      6
#define pattern_incremental   7 
#define pattern_userdefine    8
#define pattern_1234          0x000000AB
#define pattern_5678          0x0000FFFF


#define BANK0 0
#define BANK1 1
#define BANK2 2
#define BANK3 3
#define BANK4 4
#define BANK5 5

#define BANKVALID 1

#define DMA_READ   0
#define DMA_WRITE  1
#define DMA_ERASE  2
#define DMA_RESET  3

#define READ_TEST  0
#define WRITE_TEST 1

#define BUS_WIDTH_8   0
#define BUS_WIDTH_16  1
#define BUS_WIDTH_32  2

#define NAND     0
#define NOR      1
#define SRAM     2
#define OCM      3
#define SRAM_DMA 4
#define OCM_DMA  5 

#define SPANSION 100
#define NUMONYX  200
#define VENDOR_INFO_NONEED 300

#define READ_ONLY   1
#define WRITE_ONLY  2
#define READ_WRITE  3     

#define BURST_EN 1
#define MUX_EN 1
#define BURST_DIS 0
#define MUX_DIS 0

#define DAM_READ          0
#define DMA_WRITE         1
#define DMA_NAND_BlKERASE 2
#define DMA_NAND_RST      3


/*numonyx*///

//#define N_TWT 6
//#define N_FWT 6
//#define N_BWT 6
//#define N_CSN 1
//#define N_OEN 1
//#define N_WBN 1
//#define N_WBF 2
//#define N_TH  1
//#define N_ALN 4
//#define N_ALH 2

#define N_TWT 17
#define N_FWT 17
#define N_BWT 5
#define N_CSN 0
#define N_OEN 14
#define N_WBN 1
#define N_WBF 1
#define N_TH  1
#define N_ALN 4     
#define N_ALH 2

/*spansion*/
#define S_TWT 6
#define S_FWT 6
#define S_BWT 6
#define S_CSN 1
#define S_OEN 1
#define S_WBN 1
#define S_WBF 2
#define S_TH  1
#define S_ALN 4
#define S_ALH 2

// control for error()
#define JumpOutTest 1
#define StayInTest  0
#define errOption   StayInTest   

#define OPCODE_READ            0x0
#define OPCODE_CHG_RD_COL      0x5
#define OPCODE_ERASE           0x60
#define OPCODE_RD_STATUS       0x70
#define OPCODE_CHG_WR_COL      0x85
#define OPCODE_RD_ID           0x90
#define OPCODE_RD_PARAM_PG     0xEC
#define OPCODE_PROGRAM         0x80
#define OPCODE_RESET           0xFF
#define OPCODE_PROGRAM_LAST    0x10
#define OPCODE_READ_LAST       0x30
#define OPCODE_ERASE_LAST      0xD0
#define OPCODE_CHG_RD_COL_LAST 0xe0    
#define OPCODE_RD_DEVICE_ID    0x00200090           

#define HAMMING  0
#define BCH      1
#define ECC_ON   1
#define ECC_OFF  0
#define ECC_BCH4 0x0
#define ECC_BCH8 0x1 

// Mode0 values with gfc_clk = 33MHz
#define NAND0_T_CCS               0x11 
#define NAND0_T_RHW               0x07
#define NAND0_T_WB                0x07
#define NAND0_T_ADL               0x07
#define NAND0_T_DH_WH             0x01 
#define NAND0_T_DS_WP             0x02 
#define NAND0_T_ALS_CLS_CS        0x03
#define NAND0_T_ALH_CLH_CH        0x01
#define NAND0_T_RP                0x02
#define NAND0_T_REH               0x01
#define NAND0_T_RR                0x02
#define NAND0_T_AR_CLR_WHR_IR     0x04

#define NAND0_BCH_N 0
#define NAND0_BCH_T 0
#define NAND0_BCH_K 0
#define NAND0_ECC_ERRTEST     1
#define NAND0_ECC_ERRTEST_BIT 8

#define NAND_BUFFER_STARTADD 0xC80000
#define NAND_BUFFER_ENDADD   0xCA0000



void device_setup (int bank_id, int bank_valid, int bank_type, int bank_usage , int bus_width);
void device_setup_w_add (int bank_id, int bank_valid, int bank_type, int bank_usage , int bus_width, int device_startadd_bit29to16, int device_endadd_bit29to16);
unsigned int get_device_startadd32bit (int bank_id);
unsigned int get_device_baseadd32bit (int bank_id);
unsigned int gfc_write_read (int bank_id, void *wr_test_startadd, void *wr_test_endadd, int block_erase_en, void *rd_test_startadd, void *rd_test_endadd, int device_type, int bus_width, int testpattern, int vendor, int user_pattern);
void gfc_write_read_test (int bank_id, int test_type, void *wr_test_startadd, void *wr_test_endadd, int block_erase_en, void *rd_test_startadd, void *rd_test_endadd, int device_type, int bus_width, int testpattern, int vendor, int user_pattern);
void gfc_write_pattern(int bank_id,void *test_startadd, void *test_endadd, int testpattern, int device_type, int bus_width, int vendor, int user_pattern);
unsigned int gfc_read_pattern(int bank_id,void *test_startadd, void *test_endadd, int testpattern, int device_type, int bus_width, int vendor, int user_pattern);
void ocm_dma_write(int bank_id, void *address, int data, int bus_width);
void ocm_dma_read (int bank_id, void *address, int bus_width);
void da_base_test ();
void gfc_status_check();
void csr_check(int *csradd, int expdata, int mask);
int nand_corrupt_single_bit (int bank_id,int row_addr,int col_addr,int bit_pos_min,int bit_pos_max);
int find_random_index_1(int data, int bit_pos_min,int bit_pos_max);
void disable_norsram_banks(int bank_id);
void setup_norsram_addrmap(int bank_id, int device_startadd_bit29to16, int device_endadd_bit29to16);
unsigned int over_ocm_boundry (int bank_id, unsigned int data_offset);
int ocm_bank_base( int bank_id) ;
int corrupt_ecc_area(int bank_id, int ecc_algo, int chunk_num,int ecc_even_bound,int nand_page_size,int row_addr,int bus_width);
void config_bank_usage(int bank_num, int bank_usage);
int nand_corrupt_single_bit (int bank_id,int row_addr,int col_addr,int bit_pos_min,int bit_pos_max) ;
#endif



