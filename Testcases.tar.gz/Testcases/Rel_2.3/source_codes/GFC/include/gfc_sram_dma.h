/*
 */
#ifndef __GFC_SRAM_DMA_H_
#define __GFC_SRAM_DMA_H_

void sram_dma_test();
void DMA_setup(int bank_id, int src_add31to0, int dst_add31to0, int cmd_code, int cmd_id, int dma_size);
int  DMA_valid (int bank_id);
void sram_dma_write_OCM2SRAM_DAcheck();
void sram_dma_read_SRAM2OCM_DAcheck();
void sram_dma_writeANDread();
void GFC_SRAM_multiple_DMA_wr_rd_data();

#endif
