/* Author: automation@apm.com
*  Company: Applied Micro Circuits Corporation (AMCC)
*
* Describe the purpose of your Test here
*   - Include all common functions here
*/
#ifndef __SHOW_RESULT__
#define __SHOW_RESULT__

//Tinh-SLT
//function defined here
#define printPASS printPASS_gfc
#define printFAIL printFAIL_gfc

//#define READ8(a) (*(volatile unsigned char *)(a))
//#define READ32(a) (*(volatile unsigned *)(a))
//#define WRITE8(a, d)  *(unsigned char *)(a) = (unsigned char)(d)
//#define WRITE32(a, d) *(unsigned *)(a) = (unsigned )(d)

void printPASS(void) {
	printf("\n\n");
	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
	printf ("$$$$ RESULT: TEST PASS $$$$\n");
	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
	printf("\n\n");
}

void printFAIL(void) {
	printf("\n\n");
	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
	printf ("$$$$ RESULT: TEST FAILED $$$$\n"); 
	printf ("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
	printf("\n\n");
}
#endif
