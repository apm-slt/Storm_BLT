/*
 * Copyright (c) 2012 APM  All rights reserved.
 *
 */

#ifndef __TEST_UTIL_H_
#define __TEST_UTIL_H_

//Tinh-SLT:
#define read32 read32_gfc
#define write32 write32_gfc
#define read read_gfc
#define write write_gfc
#define read16 read16_gfc
#define write16 write16_gfc
#define read8 read8_gfc
#define write8 write8_gfc
#define ocm_init ocm_init_gfc
#define end_test end_test_gfc
#define get_file get_file_gfc


int   read32(unsigned int *address);
void  write32(unsigned int *address, int data);

int   read(unsigned int *address);
void  write(unsigned int *address, int data);


short read16(short *address);
void  write16(short *address, short data);
char  read8(char *address);
void  write8(char *address, char data);
void  read_svn_id ();
void  ocm_init();
void error(int exit);
void end_test();
void get_file(int *start_address, int size_in_bytes);
void  ddr_init();

#endif

